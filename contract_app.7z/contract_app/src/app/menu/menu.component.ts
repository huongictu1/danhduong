import { Component, OnInit } from '@angular/core';
//import { RealtimeService } from '../security/realtime.service';
import { SecurityService } from '../security/security.service';
import { NotificationService } from './notifycation.service';

@Component({
  selector: 'app-menu',
  templateUrl: './menu.component.html',
  styleUrls: ['./menu.component.scss']
})
export class MenuComponent implements OnInit {
  notifications: any;
  //notificationCount: Number;
  messages = '';
  lenMess = 0;
  
  constructor(public securityService : SecurityService, public notificationService: NotificationService) { 
    // this.notificationCount = 0;
    // this.notificationService.notificationCountChanged.subscribe(count => {
    //   this.notificationCount = count;
    // });
    if(securityService.isAuthenticated()){
      this.notificationService.notificationChanged.subscribe(data => {
        this.notifications = data;
        this.lenMess = data.length;
      });
    }
    
  }

  ngOnInit(): void {
    if(this.securityService.isAuthenticated()){
      this.notificationService.countNotification();
    }
    
  }
}
