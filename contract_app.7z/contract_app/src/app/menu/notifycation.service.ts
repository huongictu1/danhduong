import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { EventEmitter, Injectable, Output } from '@angular/core';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';
import { Router } from '@angular/router';

@Injectable({
  providedIn: 'root'
})
export class NotificationService {

  constructor(private http: HttpClient,private router: Router) { }


  private apiHome = environment.apiURL + "/home";
  @Output() notificationCountChanged = new EventEmitter<number>();
  @Output() notificationChanged = new EventEmitter<any>();
  countNotification() {
    // this.countNotification1().subscribe(data => {
    //   this.notificationCountChanged.emit(data);
    // });
    this.getListNotification().subscribe(data => {
      this.notificationChanged.emit(data);
    });
  }
  countNotification1() {
    return this.http.get<any>(`${this.apiHome}/countNotification`);
  }
  getListNotification() {
    return this.http.get<any>(`${this.apiHome}/listNotification`);
  }
}
