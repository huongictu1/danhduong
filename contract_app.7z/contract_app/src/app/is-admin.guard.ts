import { Injectable } from '@angular/core';
import { CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot, UrlTree, Router } from '@angular/router';
import { Observable } from 'rxjs';
import { SecurityService } from './security/security.service';
import { NotificationService } from './menu/notifycation.service';

@Injectable({
  providedIn: 'root'
})
export class IsAdminGuard implements CanActivate {

  /**
   *
   */
  constructor(private securityService: SecurityService, private router: Router, private notificationService: NotificationService) {

  }

  canActivate(
    route: ActivatedRouteSnapshot,
    state: RouterStateSnapshot): Observable<boolean | UrlTree> | Promise<boolean | UrlTree> | boolean | UrlTree {
      
      if (this.securityService.getRole().includes('la-admin')){
        this.notificationService.countNotification();
        return true;
      }

      this.router.navigate(['/login']);      
      return false;
  }
  
}
