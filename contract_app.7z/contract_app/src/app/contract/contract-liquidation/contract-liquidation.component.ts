import { Component, OnInit } from '@angular/core';
import { FormArray, FormBuilder, FormControl, Validators } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';
import { Department } from 'src/app/departments/department.model';
import { DepartmentService } from 'src/app/departments/department.service';
import Swal from 'sweetalert2';
import { ContractService } from '../contract.service';

@Component({
  selector: 'app-contract-liquidation',
  templateUrl: './contract-liquidation.component.html',
  styleUrls: ['./contract-liquidation.component.scss']
})
export class ContractLiquidationComponent implements OnInit {
  public departments: Department[];
  public appendix: any;
  public LiquidationAttachments: string[];
  public masterCasualData: any;
  public masterCasual = new FormArray([]);
  public contractId: string;

  public contractForm = this.fb.group({
    ContractId: new FormControl(''),
    ContractNo: new FormControl(''),
    DeptId: new FormControl(''),
    ContractName: new FormControl(''),
    SupplierName: new FormControl(''),
    LegalRepresentative: new FormControl(''),
    // SupplierTax: new FormControl(''),
    Address: new FormControl(''),
    EffectiveDate: new FormControl(''),
    ExpiredDate: new FormControl(''),
    SignerCvn: new FormControl(''),
    SignerSupplier: new FormControl(''),
    SignerCvnPosition: new FormControl(''),
    SignerSupplierPosition: new FormControl(''),
    TerminationDate: new FormControl(''),
    TerminationTerm: new FormControl(''),
    ContractLiquidation: new FormControl('')
  });

  constructor(
    public departmentService: DepartmentService,
    public contractService: ContractService,
    public fb: FormBuilder,
    public router: Router,
    public route: ActivatedRoute,
    ) {

    }

  ngOnInit(): void {
    this.route.paramMap
      .subscribe(params => {
        this.contractId = params.get("contractId");
      }
    );
    this.loadDepartment();
    this.loadContract();
    this.loadRouteApproval();
    this.masterCasual.push(new FormControl('', [Validators.required]));
    this.masterCasual.push(new FormControl('', [Validators.required]));
    this.masterCasual.push(new FormControl('', [Validators.required]));
    this.masterCasual.push(new FormControl('', [Validators.required]));
    this.masterCasual.push(new FormControl('', [Validators.required]));
    this.masterCasual.push(new FormControl('', [Validators.required]));
  }
  loadDepartment() {
    this.departmentService.getDeptByUser().subscribe((data) => {
      this.departments = data;
    });
  }

  loadContract() {
    this.contractService.getAllAppendix().subscribe((data) => {
      this.appendix = data;
    });
    if(this.contractId != null && this.contractId != ''){
      this.contractForm.get("ContractId").setValue(this.contractId);
      this.loadReference();
    }
  }

  loadReference()
  {
    if (this.contractForm.value.ContractId) {
      this.contractService.getDetailContract(this.contractForm.value.ContractId).subscribe((data) => {
        console.log("ReferenceContract",data);
        this.contractForm.controls['ContractNo'].setValue(data.contractNo);
        this.contractForm.controls['ContractName'].setValue(data.contractName);
        // this.contractForm.controls['RequestKind'].setValue(data.requestKindId);
        this.contractForm.controls['DeptId'].setValue(data.deptId);
        this.contractForm.controls['SupplierName'].setValue(this.checkValueNullString(data.supplierName));
        // this.contractForm.controls['SupplierTax'].setValue(this.checkValueNullString(data.supplierTax));
        this.contractForm.controls['Address'].setValue(this.checkValueNullString(data.supplierAddress));
        this.contractForm.controls['LegalRepresentative'].setValue(this.checkValueNullString(data.supplierRepresentative));

        this.contractForm.controls['SignerCvn'].setValue(this.checkValueNullString(data.signerCvn));
        this.contractForm.controls['SignerSupplier'].setValue(this.checkValueNullString(data.signerSupplier));
        this.contractForm.controls['SignerSupplierPosition'].setValue(this.checkValueNullString(data.signerSupplierPosition));
        this.contractForm.controls['SignerCvnPosition'].setValue(this.checkValueNullString(data.signerCvnPosition));
        this.loadRouteApproval();
      })
    } else {
      this.contractForm.controls['ContractNo'].setValue("");
      this.contractForm.controls['ContractName'].setValue("");
      // this.contractForm.controls['RequestKind'].setValue(data.requestKindId);
      this.contractForm.controls['DeptId'].setValue("");
      this.contractForm.controls['SupplierName'].setValue("");
      // this.contractForm.controls['SupplierTax'].setValue(this.checkValueNullString(data.supplierTax));
      this.contractForm.controls['Address'].setValue("");
      this.contractForm.controls['LegalRepresentative'].setValue("");

      this.contractForm.controls['SignerCvn'].setValue("");
      this.contractForm.controls['SignerSupplier'].setValue("");
      this.contractForm.controls['SignerSupplierPosition'].setValue("");
      this.contractForm.controls['SignerCvnPosition'].setValue("");
    }
  }
  convertPaymentTerm(value) {
    return value ? 'Usual' : 'Unusual';
  }

  checkValueNullString(value)
  {
    return (value && value != 'null') ? value : '';
  }
  submitForm()
  {
    console.log(this.contractForm.value);
    if (!this.LiquidationAttachments)
    {
      Swal.fire('Please att files.', 'Bad request', 'error');
      return;
    } else if (!this.masterCasualData) {
      Swal.fire('Please input full require!', 'Bad request', 'error');
      return;
    } else {
      let formData = new FormData();
      for (const property in this.contractForm.value) {
        if (property != 'LiquidationAttachments') {
          formData.append(property, this.contractForm.value[property]);
        }
      }

      for (let i = 0; i < this.LiquidationAttachments.length; i++) {
        formData.append('LiquidationAttachments', this.LiquidationAttachments[i]);
      }
      for (let i = 0; i < this.masterCasualData.length; i++) {
        formData.append(
          'lstCasualComment',
          JSON.stringify({
            comment: '',
            cmtOrder: i + 1,
            approver: this.masterCasual.controls[i].value,
            deptId: this.masterCasualData[i].deptId ?? 0,
            grade: this.masterCasualData[i].detailGrade,
            special: this.contractForm.value.Unusual,
            sendMulti: this.masterCasualData[i].sendMulti,
            stepName: this.masterCasualData[i].stepName,
          })
        );
      }
      this.contractService.newLiquidation(this.contractForm.value.ContractId, formData).subscribe((data) => {
        console.log(data);
        if (!data.error) {
          this.router.navigate(['/main/liquidation', data.message]);
        } else {
          Swal.fire(data.message, 'Bad request', 'error');
        }
      }, (errors) => {
        Swal.fire(errors.message, 'Bad request', 'error');
      })
    }
  }
  onDocumentSelect(event) {
    this.LiquidationAttachments = [];
    let target_file_length = event.target.files.length;
    if (target_file_length > 0) {
      for (var i = 0; i < event.target.files.length; i++) {
        this.LiquidationAttachments.push(event.target.files[i]);
      }
    }
  }

  loadRouteApproval() {
    console.log("Call loadRouteApproval")
    if (this.contractForm.value.DeptId) {
      this.loadMasterCasual(
        11,
        this.contractForm.value.DeptId,
        "Unusual"
      );
    }
  }

  loadMasterCasual(status: Number, deptId: Number, paymentTermStr: string) {
    this.contractService
    .masterCasual(status, deptId, paymentTermStr, null)
    .subscribe((data) => {
      this.masterCasualData = data;
      for(let i = 0; i < data.length; i++)
      {
        if (this.masterCasualData[i].lstApprover[0].userName) {
          this.masterCasual.controls[i].setValue(this.masterCasualData[i].lstApprover[0].userName)
        }
      }
    });
  }
}
