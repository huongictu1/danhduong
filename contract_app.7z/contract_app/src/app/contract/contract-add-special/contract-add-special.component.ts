import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-contract-add-special',
  templateUrl: './contract-add-special.component.html',
  styleUrls: ['./contract-add-special.component.scss']
})
export class ContractAddSpecialComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
