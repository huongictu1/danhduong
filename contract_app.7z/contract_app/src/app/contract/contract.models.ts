export interface ContractSearchParameters {
    page: number;
    recordsPerPage: number;
    search: string;
    contractNo: string;
    contractNoOrderType: number;
    contractName: string;
    contractNameOrderType: number;
    venderName: string;
    venderNameOrderType: number;
    status: number;
    deptId: any;
    expiredDate: Date;
    contractKind: number;
    requestKind: number;
}
export interface ContractInforView {
    id: any;
    applicationNo: string;
    deptId: number;
    requestKind: number;
    contractKind: number;
    contactNumber: string;
    contractNo: string;
    appendixId: any;
    signModel: any;
    contractName: string;
    venderName: string;
    contractDate: Date;
    expiredDate: Date;
    contractValues: number;
    statusId: number;
    active: Boolean;
    createdDate: Date;
    createdBy: string;
    modifiedDate: Date;
    modifiedBy: string;
    unusual: Boolean;
    contractDocument: string;
    attachments: string;
    dept: string;
    status: string;
    lstStatus: ContractStatusView[];
    contractContent: string;
}
export interface ContractStatusView{
    submittedModel: any;
    id: any;
    contractId: any;
    issuedDate: any;
    approvalDate: any;
    statusId: string;
    document: string;
    statusOrder: number;
    statusName: string;
    applicationNo: string;
    contractNo: string;
    contractName: string;
    contractContent: string;
    contractKind: string;
    requestKind: string;
    department: string;
    createdDate: string;
    contractDocument: string;
    applicant: string;
    isNextApprover: Boolean;
    currentStep: Number;
    lstCasual: ContractCommentCasualView[]
    casualComments: ContractCommentCasualView[],
    checkingModel: any,
    officialComments: any,
    approvalRoute: string,
    revisingModel: any,
    doubleCheckModel: any
}
export interface ContractCommentCasualView{
    id: any;
    comment: string;
    cmtOrder: number;
    cmtDate: any;
    approver: string;
    approverName: string;
    deptId: number;
    gradeSys: string;
    cmtStatus: Boolean;
    deptName: string;
    cmtStatusString: string;
}
export interface ContractDraftDTO {
    id: any;
    applicationNo: string;
    deptId: number;
    requestKind: number;
    contractKind: number;
    contractNo: string;
    appendixId: number;
    contractName: string;
    venderName: string;
    contractDate: Date;
    expiredDate: Date;
    contractValues: number;
    statusId: number;
    unusual: Boolean;
    contractDocument: string;
    document: any;
    attachments: string;
    attachment: any;
    contractContent: string;
}

export interface approveDraftParams
{
    commentContent: string,
    commentType: Number,
    currentOrder: Number
    //lay theo status_order
}

export interface NewConversationComment
{
    cmtContent: string,
    contractStatusId: string
}

export interface NewOfficialComment
{
    cmtArticle: string,
    cmtContent: string,
    cmtProblem: string,
    cmtSuggestion: string,
    cmtOrder: Number,
    contractStatusId: string
}

export interface EditOfficialComment
{
    cmtArticle: string,
    cmtContent: string,
    cmtProblem: string,
    cmtSuggestion: string,
    cmtOrder: Number,
    contractStatusId: string
}
