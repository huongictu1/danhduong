import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-contract-edit',
  templateUrl: './contract-edit.component.html',
  styleUrls: ['./contract-edit.component.scss']
})
export class ContractEditComponent implements OnInit {
  public action: string;
  constructor() { }

  ngOnInit(): void {
  }

}
