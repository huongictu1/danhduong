import { Component, OnInit, AfterViewInit, NgModule } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { ContractService } from '../contract.service';
import { ActivatedRoute, Route } from '@angular/router';
import { ContractInforView, ContractStatusView } from '../contract.models'
import { Router } from '@angular/router';
import { splitLink, isPdf, isDocx, isOffice, splitPathFile, concatLink, isExcel, isPowerpoint } from 'src/app/utilities/utils';
import Swal from 'sweetalert2';
import { formatDate } from 'src/app/utilities/utils';
//import { Editor, Toolbar } from 'ngx-editor';
import { CKEditorComponent } from 'ckeditor4-angular';
// import * as ClassicEditor from '@ckeditor/ckeditor5-build-classic';
import { timer } from 'rxjs';
import { SecurityService } from 'src/app/security/security.service';
import { NotificationService } from 'src/app/menu/notifycation.service';
// declare var CKEDITOR: any;



@Component({
  selector: 'app-contract-detail-status',
  templateUrl: './contract-detail-status.component.html',
  styleUrls: ['./contract-detail-status.component.scss']
})
export class ContractDetailStatusComponent implements OnInit {
  public Editor = CKEditorComponent;
  // public Editor: any = ClassicEditor;
  public config = {
    versionCheck: false
  }
  //public Editor = ClassicEditor;
  public editorConfig = {
    removePlugins: 'scayt, wsc',
    versionCheck: false
  };

  public contractDetailStatus: ContractStatusView;
  public userApplicant: any;
  public statusId: string;
  public contractId: string;
  public isLoading = true;
  public reason: string;
  public listConversationByStatus: any;
  public listOfficialCommentByStatus: any;
  public listFeedbackCommentByStatus: any;
  public conversationComment: string;

  public officialArticle: string;
  public officialContent: string;
  public officialProblem: string;
  public officialSuggestion: string;
  public attachment: string;
  public attachmentFile: string[] = [];
  public officialFile: string[] = [];

  public feedbackArticle: string;
  public feedbackContent: string;
  public feedbackNote: string;
  public fbAttachment: string;
  public fbAttachmentFile: string[] = [];


  public officialArticle2: string;
  public officialContent2: string;
  public officialProblem2: string;
  public officialSuggestion2: string;
  public attachment2: string;
  public attachmentFile2: string[] = [];
  public officialId2: string;

  public feedbackArticle2: string;
  public feedbackContent2: string;
  public feedbackNote2: string;
  public fbAttachment2: string;
  public fbAttachmentFile2: string[] = [];
  public feedbackId2: string;

  public approvalRoute: string;

  public remainDate: Date;
  public checkboxRemainDate: Boolean;
  public isFirstApprover: Boolean;
  public canEditRequest: Boolean;
  public canFeedbackRequest: Boolean;
  public document: string[] = [];
  $: any;

  // editor: Editor;
  // toolbar: Toolbar = [
  //   ['bold', 'italic'],
  //   ['underline', 'strike'],
  //   ['code', 'blockquote'],
  //   ['ordered_list', 'bullet_list'],
  //   [{ heading: ['h1', 'h2', 'h3', 'h4', 'h5', 'h6'] }],
  //   ['link', 'image'],
  //   ['text_color', 'background_color'],
  //   ['align_left', 'align_center', 'align_right', 'align_justify'],
  // ];
  // public officialGroupNew = new FormGroup({
  //   editorContent: new FormControl()
  // });
  isApiCallInProgress = false;
  constructor(
    public contractService: ContractService,
    public fb: FormBuilder,
    public route: ActivatedRoute,
    public router: Router,
    public securityService: SecurityService,
    public notificationService: NotificationService
  ) { }

  ngOnInit(): void {
    
    // this.editor = new Editor();
    this.contractId = this.route.snapshot.paramMap.get('contractId');
    this.statusId = this.route.snapshot.paramMap.get('statusId');
    this.loadDetailContractStatus();
    this.reason = "";
    this.getListConversationByStatus();
    this.checkboxRemainDate = false;
    this.getListOfficialCommentByStatus();
    this.getListFeedbackCommentByStatus();
  }
  // ngAfterViewInit() {
  //   CKEDITOR.replace('editor');
  // }
  public onReady(editor) {
    // editor.ui.getEditableElement().parentElement.insertBefore(
    //   editor.ui.view.toolbar.element,
    //   editor.ui.getEditableElement()
    // );
  }
  sampleDownload() {
    var link = document.createElement('a');
    link.href = concatLink('/common/sampleOfficial');
    link.target = '_blank';
    link.download = "Official comment.xls";
    //console.log(link);
    link.click();
  }
  importOfficial() {
    let formData = new FormData();
      formData.append('contractStatusId', this.statusId);
      for (var i = 0; i < this.officialFile.length; i++) {
        formData.append('attachmentFile', this.officialFile[i]);
      }

      this.contractService.importOfficialComment(formData).subscribe(data => {

        if (data.status == 200) {
          window.location.reload();
        }
        else if (data.status == 400) {
          Swal.fire(data.message, "Bad request", "error");
        }
      });
  }
  loadDetailContractStatus() {
    this.contractService.getDetailContractStatus(this.statusId).subscribe(data => {
      this.contractDetailStatus = data;
      //console.log(data);
      switch (data.approvalRoute) {
        case 1: {
          this.approvalRoute = "approveDraft";
          break;
        }
        case 2: {
          this.approvalRoute = "approveSubmitted";
          break;
        }
        case 3: {
          this.approvalRoute = "approveChecking";
          break;
        }
        case 4: {
          this.approvalRoute = "approveRevising";
          break;
        }
        case 10: {
          this.approvalRoute = "approveDoublecheck";
          break;
        }
        case 6: {
          this.approvalRoute = "approveSigning";
          break;
        }
        default: {
          this.approvalRoute = "approveDraft";
          break;
        }
      }
      this.isLoading = false;
    });
    this.contractService.isFirstApprover(this.contractId).subscribe(data => {
      this.isFirstApprover = data;
    });
    this.contractService.canEditRequest(this.contractId).subscribe(data => {
      this.canEditRequest = data;
    });
    this.contractService.canFeedbackRequest(this.statusId).subscribe(data => {
      this.canFeedbackRequest = data;
    });
  }

  splitLink(link: string) {
    return splitLink(link);
  }
  concatLink(link) {
    return concatLink(link);
  }
  logData() {
    // console.log("this.contractDetailStatus", this.contractDetailStatus);
    // console.log("getListConversationByStatus", this.listConversationByStatus);
    // console.log("this.contractDetailStatus.officialComments", this.contractDetailStatus.officialComments);
  }
  onDocumentSelect(event) {
    this.document = [];
    let target_file_length = event.target.files.length;
    if (target_file_length > 0) {
      for (var i = 0; i < event.target.files.length; i++) {
        this.document.push(event.target.files[i]);
      }
    }
  }
  watermark() {
    this.isLoading = true;
    this.contractService.watermark(this.statusId).subscribe(data => {
      if (data.status == 400) {
        this.isLoading = false;
        Swal.fire(data.message, "Bad request", "error");
      }
      else if (data.status == 200) {
        this.isLoading = false;
        Swal.fire(data.message, "Success", "success");
        location.reload();
      }
    })
  }
  mgrAbsent() {
    this.isLoading = true;
    this.contractService.mgrAbsent(this.statusId).subscribe(data => {
      if (data.status == 400) {
        this.isLoading = false;
        Swal.fire(data.message, "Bad request", "error");
      }
      else if (data.status == 200) {
        this.isLoading = false;
        Swal.fire(data.message, "Success", "success");
        location.reload();
      }
    })
  }
  wordtopdf() {
    this.isLoading = true;
    this.contractService.wordtopdf(this.statusId).subscribe(data => {
      if (data.status == 400) {
        this.isLoading = false;
        Swal.fire(data.message, "Bad request", "error");
      }
      else if (data.status == 200) {
        this.isLoading = false;
        Swal.fire(data.message, "Success", "success");
        location.reload();
      }
    })
  }
  updateDocuments() {
    let formData = new FormData();
    for (var i = 0; i < this.document.length; i++) {
      formData.append('document', this.document[i]);
    }
    this.contractService.replaceDocument(formData, this.statusId).subscribe(data => {

      if (data.status == 200) {
        document.getElementById('btnCloseModalUpdateDocument').click();
        location.reload();
      }
      else if (data.status == 400) {
        Swal.fire(data.message, "Bad request", "error");
      }
    })
  }
  actionApprove(commentType: Number) {
    document.getElementById("btn-close-modal").click();
    if (!this.isApiCallInProgress) {
      this.isApiCallInProgress = true;
      this.contractService.approve({
        commentContent: this.reason,
        commentType: commentType,
        currentOrder: this.contractDetailStatus.currentStep
        //lay theo status_order
      }, this.contractDetailStatus.id, this.approvalRoute).subscribe(data => {
        if (data.status == 400) {
          Swal.fire(data.message, "Bad request", "error");
          this.isApiCallInProgress = false;
        }
        else if (data.status == 200) {
          this.notificationService.countNotification();
          this.router.navigate(['main/detail', this.contractId]);
          this.isApiCallInProgress = false
        }
      });

    }
    // this.contractService.approve({
    //   commentContent: this.reason,
    //   commentType: commentType,
    //   currentOrder: this.contractDetailStatus.currentStep
    //   //lay theo status_order
    // }, this.contractDetailStatus.id, this.approvalRoute).subscribe(data => {
    //   if (data.status == 400) {
    //     Swal.fire(data.message, "Bad request", "error");
    //   }
    //   if (data.status == 200) {
    //     this.router.navigate(['main/detail', this.contractId]);
    //   }
    // });
  }
  actionRequest(action: string) {
    // Approval = 1
    // Reject = 0
    // Return = -1

    let commentType = 1;
    if (action == 'reject') {
      commentType = 0;
    }
    if (action == 'return') {
      commentType = -1;
    }
    if ((action == "reject" || action == "return") && this.reason == "") {
      Swal.fire("Please input reason !", "Warning", "error");
    } else {
      this.actionApprove(commentType);
    }
  }

  closeModalUpdateDocument() {
    document.getElementById("btnCloseModalUpdateDocument").click();
  }

  isDocx(fileName) {
    return isDocx(fileName);
  }

  isPdf(fileName) {
    return isPdf(fileName);
  }
  isExcel(fileName) {
    return isExcel(fileName);
  }
  isPowerpoint(fileName) {
    return isPowerpoint(fileName);
  }
  isOffice(fileName) {
    return isOffice(fileName);
  }
  getFilenameWithoutGuid(link) {
    var fileFullName = splitPathFile(link);
    var fileName = fileFullName[fileFullName.length - 1];
    return fileName.substring(37);
  }
  submitNewConversationComment() {
    if (this.conversationComment) {
      let comment = {
        cmtContent: this.conversationComment,
        contractStatusId: this.statusId
      }
      this.contractService.newConversationComment(comment).subscribe(data => {
        // console.log("submitNewConversationComment", data);
        if (data.status == 400) {
          Swal.fire(data.message, "Bad request", "error");
        }
        if (data.status == 200) {
          this.conversationComment = "";
          document.getElementById("btn-close-modal-new-conversation").click();
          window.location.reload();
          // this.getListConversationByStatus();
        }
      })
    } else {
      Swal.fire("Please input casual comment !", "Bad request", "error");
    }

  }

  removeOfficialComment(id) {
    this.contractService.removeOfficialComment(id).subscribe(data => {
      if (data.status == 400) {
        Swal.fire(data.message, "Bad request", "error");
      }
      if (data.status == 200) {
        // this.getListOfficialCommentByStatus();
        window.location.reload();
      }
    })
  }
  removeFeedbackComment(id) {
    this.contractService.removeFeedbackComment(id).subscribe(data => {
      if (data.status == 400) {
        Swal.fire(data.message, "Bad request", "error");
      }
      if (data.status == 200) {
        window.location.reload();
      }
    })
  }
  returnByFeedback(id) {
    this.contractService.returnByFeedback(id).subscribe(data => {
      if (data.status == 400) {
        Swal.fire(data.message, "Bad request", "error");
      }
      if (data.status == 200) {
        window.location.reload();
      }
    })
  }
  acceptReviseContract(statusId) {
    Swal.fire(statusId, "Information", "success");
  }
  denyReviseContract(statusId) {
    Swal.fire(statusId, "Information", "info");
  }

  officialCommentById(id) {
    //console.log("official by id", id);
    this.contractService.officialCommentById(id).subscribe(data => {
      //console.log(data);
      this.officialId2 = data.id;
      this.officialContent2 = data.cmtContent;
      this.officialProblem2 = data.cmtProblem;
      this.officialSuggestion2 = data.cmtSuggestion;
      this.officialArticle2 = data.cmtArticle;
      this.attachment = data.attachment;
    })
  }
  feedbackCommentById(id) {
    //console.log("feedback by id", id);
    this.contractService.feedbackCommentById(id).subscribe(data => {
      //console.log(data);
      this.feedbackId2 = data.id;
      this.feedbackContent2 = data.fbContent;
      this.feedbackArticle2 = data.fbArticle;
      this.feedbackNote2 = data.fbNote;
      this.fbAttachment2 = data.fbAttachment;
    })
  }
  editOfficialComment() {
    let formData = new FormData();
    formData.append('cmtArticle', this.officialArticle2);
    formData.append('cmtContent', this.officialContent2);
    formData.append('cmtProblem', this.officialProblem2);
    formData.append('cmtSuggestion', this.officialSuggestion2);
    formData.append('cmtOrder', '0');
    formData.append('contractStatusId', this.statusId);
    for (var i = 0; i < this.attachmentFile2.length; i++) {
      formData.append('attachmentFile', this.attachmentFile2[i]);
    }

    this.contractService.editOfficialComment(this.officialId2, formData).subscribe(data => {

      if (data.status == 200) {
        //document.getElementById('btn-close-officialComments-modalO2').click();
        window.location.reload();
      }
      else if (data.status == 400) {
        Swal.fire(data.message, "Bad request", "error");
      }
    });
  }
  editFeedbackComment() {
    let formData = new FormData();
    formData.append('fbArticle', this.feedbackArticle2);
    formData.append('fbContent', this.feedbackContent2);
    formData.append('fbNote', this.feedbackNote2);
    formData.append('contractStatusId', this.statusId);
    for (var i = 0; i < this.fbAttachmentFile2.length; i++) {
      formData.append('attachment', this.fbAttachmentFile2[i]);
    }

    this.contractService.editFeedbackComment(this.feedbackId2, formData).subscribe(data => {

      if (data.status == 200) {
        //document.getElementById('btn-close-feedbackComments-modalO2').click();
        window.location.reload();
      }
      else if (data.status == 400) {
        Swal.fire(data.message, "Bad request", "error");
      }
    });
  }

  getListConversationByStatus() {
    this.contractService.listConversationByStatus(this.statusId).subscribe(data => {
      this.listConversationByStatus = data;
    })
  }

  getListOfficialCommentByStatus() {
    this.contractService.listOfficialCommentByStatus(this.statusId).subscribe(data => {
      this.listOfficialCommentByStatus = data;
    })
  }

  getListFeedbackCommentByStatus() {
    this.contractService.listFeedbackCommentByStatus(this.statusId).subscribe(data => {
      this.listFeedbackCommentByStatus = data;
    })
  }

  submitNewOfficialComment() {
    if (this.officialArticle && this.officialContent && this.officialProblem) {
      let formData = new FormData();
      formData.append('cmtArticle', this.officialArticle);
      formData.append('cmtContent', this.officialContent);
      formData.append('cmtProblem', this.officialProblem);
      formData.append('cmtSuggestion', this.officialSuggestion);
      formData.append('cmtOrder', '0');
      formData.append('contractStatusId', this.statusId);
      for (var i = 0; i < this.attachmentFile.length; i++) {
        formData.append('attachmentFile', this.attachmentFile[i]);
      }

      this.contractService.newOfficialComment(formData).subscribe(data => {

        if (data.status == 200) {
          //document.getElementById('btn-close-officialComments-modalO1').click();
          window.location.reload();
        }
        else if (data.status == 400) {
          Swal.fire(data.message, "Bad request", "error");
        }
      });
    } else {
      Swal.fire("Required all field for official comment !", "Warning", "warning");
    }
  }
  submitNewFeedbackComment() {
    if (this.feedbackArticle && this.feedbackContent) {
      let formData = new FormData();
      formData.append('fbArticle', this.feedbackArticle);
      formData.append('fbContent', this.feedbackContent);
      formData.append('fbNote', this.feedbackNote);
      formData.append('contractStatusId', this.statusId);
      for (var i = 0; i < this.fbAttachmentFile.length; i++) {
        formData.append('attachment', this.fbAttachmentFile[i]);
      }

      this.contractService.newFeedbackComment(formData).subscribe(data => {

        if (data.status == 200) {
          //document.getElementById('btn-close-feedbackComments-modalO1').click();
          window.location.reload();
        }
        else if (data.status == 400) {
          Swal.fire(data.message, "Bad request", "error");
        }
      });
    } else {
      Swal.fire("Required all field for feedback !", "Warning", "warning");
    }
  }
  onOfficialAttachmentSelect(event) {
    this.attachmentFile = [];
    let target_file_length = event.target.files.length;
    if (target_file_length > 0) {
      for (var i = 0; i < event.target.files.length; i++) {
        this.attachmentFile.push(event.target.files[i]);
      }
    }
  }
  onOfficialImportSelect(event) {
    this.officialFile = [];
    let target_file_length = event.target.files.length;
    if (target_file_length > 0) {
      for (var i = 0; i < event.target.files.length; i++) {
        this.officialFile.push(event.target.files[i]);
      }
    }
  }
  onFeedbackAttachmentSelect(event) {
    this.fbAttachmentFile = [];
    let target_file_length = event.target.files.length;
    if (target_file_length > 0) {
      for (var i = 0; i < event.target.files.length; i++) {
        this.fbAttachmentFile.push(event.target.files[i]);
      }
    }
  }
  onFeedbackAttachmentSelect2(event) {
    this.fbAttachmentFile2 = [];
    let target_file_length = event.target.files.length;
    if (target_file_length > 0) {
      for (var i = 0; i < event.target.files.length; i++) {
        this.fbAttachmentFile2.push(event.target.files[i]);
      }
    }
  }
  canOfficialComment() {
    // isAdmin, isEdit, canOfficial
    return (this.contractDetailStatus.submittedModel.canOfficial)
      || (this.contractDetailStatus.doubleCheckModel.canOfficial);
  }
  canCasualComment() {
    // isAdmin, isEdit, canOfficial
    return this.contractDetailStatus.submittedModel.canCasual || this.contractDetailStatus.checkingModel.canCasual || this.contractDetailStatus.revisingModel.canCasual || this.contractDetailStatus.doubleCheckModel.canCasual;
  }
  markRevise() {
    let today = new Date(formatDate(new Date()));
    if (new Date(this.remainDate) > today) {
      document.getElementById("btn-close-modal3").click();
      let reviseDto = {
        "remainDate": this.remainDate,
        "isRevise": this.checkboxRemainDate
      }
      this.contractService.markRevise(this.statusId, reviseDto).subscribe(data => {
        if (data.status == 400) {
          Swal.fire(data.message, "Bad request", "error");
        }
        if (data.status == 200) {
          this.router.navigate(['main/status/' + this.contractId + "/" + this.statusId]);
        }
      });

    } else {
      Swal.fire("Remain date is required and valid!", "Warning", "warning");
    }
  }

  acceptRevise(accept: Boolean) {
    this.contractService.acceptRevise(this.statusId, accept).subscribe(data => {
      if (data.status == 400) {
        Swal.fire(data.message, "Bad request", "error");
      }
      if (data.status == 200) {
        this.router.navigate(['main/status/' + this.contractId + "/" + this.statusId]);
      }
    });
  }
  modifyRequest(require: Boolean) {
    this.contractService.modifyRequest(this.statusId, require).subscribe(data => {
      if (data.status == 400) {
        Swal.fire(data.message, "Bad request", "error");
      }
      if (data.status == 200) {
        this.router.navigate(['main/status/' + this.contractId + "/" + this.statusId]);
      }
    });
  }
}
