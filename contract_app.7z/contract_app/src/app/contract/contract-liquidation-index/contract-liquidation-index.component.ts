import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl } from '@angular/forms';
import { Router } from '@angular/router';
import { Department } from 'src/app/departments/department.model';
import { DepartmentService } from 'src/app/departments/department.service';
import { contractKindDTO } from 'src/app/masters/contractkind/contract-kind.model';
import { ContractKindService } from 'src/app/masters/contractkind/contract-kind.service';
import { MasterService } from 'src/app/masters/masters.service';
import { requestKindDTO } from 'src/app/masters/requestkind/request-kind.model';
import { RequestKindService } from 'src/app/masters/requestkind/request-kind.service';
import { ContractService } from '../contract.service';

@Component({
  selector: 'app-contract-liquidation-index',
  templateUrl: './contract-liquidation-index.component.html',
  styleUrls: ['./contract-liquidation-index.component.scss']
})
export class ContractLiquidationIndexComponent implements OnInit {
  public isLoading: Boolean;
  public page = 1;
  public recordsPerPage: Number;
  public currentPage: number;
  public totalRecords: number;
  public fromRecord: number;
  public toRecord: number;
  public search: String;
  public contractKinds: contractKindDTO[];
  public requestKinds: requestKindDTO[];
  public departments: Department[];
  public statusData: any;
  public contractData: any;
  public optionSort = [
    {"id" : 0, "value" : "Contains"},
    {"id" : 1, "value" : "Begin with"},
    {"id" : -1, "value" : "End with"}
  ]
  public optionUrgent = [
    {"id" : 0, "value" : "All"},
    {"id" : 1, "value" : "Normal"},
    {"id" : -1, "value" : "Urgent/backdate"}
  ]
  constructor(
    public contractKindService: ContractKindService,
    public fb: FormBuilder,
    public requestKindService: RequestKindService,
    public departmentService: DepartmentService,
    public masterService: MasterService,
    public router: Router,
    public contactService: ContractService
  ) { }
  contractForm = this.fb.group({
    contractNo: new FormControl(""),
    contractName: new FormControl(""),
    supplierName: new FormControl(""),
    deptId: new FormControl([]),
    contractTerm: new FormControl(""),
    page: new FormControl(1)
  });
  ngOnInit(): void {
    this.loadDepartment();
    this.searchData(1);
  }
  loadDepartment() {
    this.departmentService.getAll().subscribe(data => {
      this.departments = data;
      // this.searchData(1);
    });
  }
  searchData(page)
  {
    this.contractForm.controls['page'].setValue(page);
    this.page = page;
    console.log(this.contractForm.value);
    this.contactService.filterContractLiquidation(this.contractForm.value).subscribe((data) => {
      console.log("contractData", data);
      this.contractData = data;
      this.totalRecords = data.totalRecords;
      this.fromRecord = data.fromRecord;
      this.toRecord = data.toRecord;
      this.currentPage = data.currentPage;
      this.recordsPerPage = data.recordPerPage;
    })
  }
  pageChanged(event) {
    this.contractForm.controls['page'].setValue(event);
    this.page = event;
    this.searchData(this.page);
    // this.logData();
  }
}
