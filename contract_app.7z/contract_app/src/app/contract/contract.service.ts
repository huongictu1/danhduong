import { HttpClient, HttpHeaders, HttpRequest, HttpResponse } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable, share } from 'rxjs';
import { environment } from 'src/environments/environment';
import { ContractSearchParameters, ContractDraftDTO , approveDraftParams, NewConversationComment, NewOfficialComment, EditOfficialComment} from './contract.models';

@Injectable({
  providedIn: 'root'
})
export class ContractService {
  constructor(private http: HttpClient) { }

  private apiURL = environment.apiURL + '/contract';
  private apiURLCommon = environment.apiURL + '/common';
  private apiURLMaster = environment.apiURL + '/master';

  getAllAppendix(): Observable<any> {
    return this.http.get<any>(`${this.apiURL}/allAppendix`);
  }

  getTutorialAppendix(): Observable<any> {
    return this.http.get<any>(`${this.apiURL}/tutorialAppendix`);
  }

  getListContract(params, selectedRadio): Observable<any> {
    return this.http.post<any>(`${this.apiURL}/filterContract`, {
      "page": params.page,
      "recordsPerPage": params.recordsPerPage,
      "search": params.search,
      "contractNo": params.contractNo,
      "contractNoOrderType": params.contractNoOrderType,
      "applicationNo": params.applicationNo,
      "applicationNoOrderType": params.applicationNoOrderType,
      "contractName": params.contractName,
      "contractNameOrderType": params.contractNameOrderType,
      "supplierName": params.supplierName,
      "supplierNameOrderType": params.supplierNameOrderType,
      "status": params.status,
      "deptId": params.deptId,
      "expiredDate": params.expiredDate == "" ? null: params.expiredDate,
      "contractDate": params.contractDate == "" ? null: params.contractDate,
      "expiredDate2": params.expiredDate2 == "" ? null: params.expiredDate2,
      "contractDate2": params.contractDate2 == "" ? null: params.contractDate2,
      "contractKind": params.contractKind,
      "requestKind": params.requestKind,
      "urgentType": params.urgentType,
      "contractContent": params.contractContent,
      "earlyTerminate": params.earlyTerminate,
      "autoRenew" : params.autoRenew,
      "attachmentName" : params.attachmentName,
      "attachmentNameOrderType": params.attachmentNameOrderType,
      "myContract": params.myContract,
      "selectedRadio": selectedRadio,
    });
  }
  exportListContract(params, user_name, selectedRadio): Observable<any> {
    return this.http.post<any>(`${this.apiURLCommon}/exportContract/${user_name}`, {
      "page": params.page,
      "recordsPerPage": params.recordsPerPage,
      "search": params.search,
      "contractNo": params.contractNo,
      "contractNoOrderType": params.contractNoOrderType,
      "applicationNo": params.applicationNo,
      "applicationNoOrderType": params.applicationNoOrderType,
      "contractName": params.contractName,
      "contractNameOrderType": params.contractNameOrderType,
      "supplierName": params.supplierName,
      "supplierNameOrderType": params.supplierNameOrderType,
      "status": params.status,
      "deptId": params.deptId,
      "expiredDate": params.expiredDate == "" ? null: params.expiredDate,
      "contractDate": params.contractDate == "" ? null: params.contractDate,
      "contractKind": params.contractKind,
      "requestKind": params.requestKind,
      "urgentType": params.urgentType,
      "contractContent": params.contractContent,
      "earlyTerminate": params.earlyTerminate,
      "autoRenew" : params.autoRenew,
      "attachmentName" : params.attachmentName,
      "attachmentNameOrderType": params.attachmentNameOrderType,
      "myContract": params.myContract,
      "selectedRadio": selectedRadio,
    },{responseType:"blob" as 'json'});
  }
  exportListContract22(params, user_name, selectedRadio): Observable<any> {
    return this.http.post<any>(`${this.apiURLCommon}/exportContract22/${user_name}/${selectedRadio}`, {
      "page": params.page,
      "recordsPerPage": params.recordsPerPage,
      "search": params.search,
      "contractNo": params.contractNo,
      "contractNoOrderType": params.contractNoOrderType,
      "applicationNo": params.applicationNo,
      "applicationNoOrderType": params.applicationNoOrderType,
      "contractName": params.contractName,
      "contractNameOrderType": params.contractNameOrderType,
      "supplierName": params.supplierName,
      "supplierNameOrderType": params.supplierNameOrderType,
      "status": params.status,
      "deptId": params.deptId,
      "expiredDate": params.expiredDate == "" ? null: params.expiredDate,
      "contractDate": params.contractDate == "" ? null: params.contractDate,
      "expiredDate2": params.expiredDate2 == "" ? null: params.expiredDate2,
      "contractDate2": params.contractDate2 == "" ? null: params.contractDate2,
      "contractKind": params.contractKind,
      "requestKind": params.requestKind,
      "urgentType": params.urgentType,
      "contractContent": params.contractContent,
      "earlyTerminate": params.earlyTerminate,
      "autoRenew" : params.autoRenew,
      "attachmentName" : params.attachmentName,
      "attachmentNameOrderType": params.attachmentNameOrderType,
      "myContract": params.myContract,
      "A": params.A,
      "B": params.B,
      "C": params.C,
      "D": params.D,
      "E": params.E,
      "F": params.F,
      "G": params.G,
      "H": params.H,
      "I": params.I,
      "J": params.J,
      "K": params.K,
      "L": params.L,
      "M": params.M,
      "Q": params.Q,
      "R": params.R,
      "S": params.S,
      "T": params.T,
      "U": params.U
    },{responseType:"blob" as 'json'});
  }
  exportContract(params, selectedRadio): Observable<any> {
    return this.http.post(`${this.apiURLCommon}/exportList`
      , {
        "page": params.page,
        "recordsPerPage": params.recordsPerPage,
        "search": params.search,
        "contractNo": params.contractNo,
        "contractNoOrderType": params.contractNoOrderType,
        "applicationNo": params.applicationNo,
        "applicationNoOrderType": params.applicationNoOrderType,
        "contractName": params.contractName,
        "contractNameOrderType": params.contractNameOrderType,
        "supplierName": params.supplierName,
        "supplierNameOrderType": params.supplierNameOrderType,
        "status": params.status,
        "deptId": params.deptId,
        "expiredDate": params.expiredDate,
        "contractKind": params.contractKind,
        "requestKind": params.requestKind,
        "selectedRadio": selectedRadio
      }
    , {
      responseType: "blob",
      // headers: new HttpHeaders().append("Content-Type", "application/json")
      // .append("Access-Control-Allow-Origin", "*")
      // .append("Access-Control-Allow-Methods", "GET, POST")
    }
    );
  }
  // exportContract(params) {
  //   return this.http.get(`${this.apiURLCommon}/exportListToFile`
  //     , JSON.parse(JSON.stringify(params))
  //   );
  // }
  setHeaders(params) {
    const reqData = {

    };
    if(params) {
        let reqParams = {};
        Object.keys(params).map(k =>{
            reqParams[k] = params[k];
        });
        reqData['parameters'] = reqParams;
    }
    return reqData;
}
  getDetailContract(contractId): Observable<any> {
    return this.http.get<any>(`${this.apiURL}/getDetailContract?contractId=` + contractId, {

    });
  }
  checkEditPermission(contractId): Observable<any> {
    return this.http.get<any>(`${this.apiURL}/checkEditPermission?contractId=` + contractId, {
    });
  }
  checkEditPermissionTemp(contractId): Observable<any> {
    return this.http.get<any>(`${this.apiURL}/checkEditPermissionTemp?contractId=` + contractId, {
    });
  }
  getDetailContractTemp(contractId): Observable<any> {
    return this.http.get<any>(`${this.apiURL}/getDetailContractTemp?contractId=` + contractId, {

    });
  }
  getDetailContractStatus(statusId): Observable<any> {
    return this.http.get<any>(`${this.apiURL}/getDetailContractStatus?statusId=` + statusId, {
    });
  }
  getApplicationNo(): Observable<any> {
    return this.http.get<string>(`${this.apiURL}/getApplicationNo`, {
    });
  }
  newContract(params): Observable<any> {
    return this.http.post<any>(`${this.apiURL}/newContract`, params);
    // if (this.someDataObservable) {
    //   return this.someDataObservable;
    // } else {
    //   this.someDataObservable = this.http.post<any>(`${this.apiURL}/newContract`, params).pipe(share());
    //   return this.someDataObservable;
    // }
  }
  saveDraft(params): Observable<any> {
    return this.http.post<any>(`${this.apiURL}/saveDraft`, params);
  }
  newSpecial(params): Observable<any> {
    return this.http.put<any>(`${this.apiURL}/newSpecial`, params);
    // if (this.someDataObservable) {
    //   return this.someDataObservable;
    // } else {
    //   this.someDataObservable = this.http.put<any>(`${this.apiURL}/newSpecial`, params).pipe(share());
    //   return this.someDataObservable;
    // }
  }
  saveSpecial(params, contractID: string): Observable<any> {
    return this.http.put<any>(`${this.apiURL}/saveSpecial?tempId=`+contractID, params);
  }
  editContract(params: any, contractId: string): Observable<any> {
    return this.http.put<any>(`${this.apiURL}/editContract?contractId=${contractId}`, params);
  }
  removeDocuments(contractId: string, typeDoc: any): Observable<any> {
    return this.http.get<any>(`${this.apiURL}/removeDocuments?contractId=${contractId}&typeDoc=${typeDoc}`);
  }
  masterCasual(statusId: Number, deptId: Number, paymentTermStr: string, contractId: string): Observable<any> {
    let url = `${this.apiURL}/masterCasual?statusId=${statusId}&deptId=${deptId}&paymentTermStr=${paymentTermStr}`;
    if (contractId)
    {
      url = url +`&contractId=${contractId}`;
    }
    return this.http.get<any>(url);
  }
 
  // approve(params: approveDraftParams, statusId: string, approvalRoute: string): Observable<any>
  // {
  //   return this.http.put<any>(`${this.apiURL}/`+approvalRoute+`?statusId=`+statusId, params);
  // }
  someDataObservable: Observable<any>;
  approve(params: approveDraftParams, statusId: string, approvalRoute: string): Observable<any>
  {
    if (this.someDataObservable) {
      return this.someDataObservable;
    } else {
      this.someDataObservable = this.http.put<any>(`${this.apiURL}/`+approvalRoute+`?statusId=`+statusId, params).pipe(share());
      return this.someDataObservable;
    }
  }
  cancelRequest(contractId: string): Observable<any>
  {
    return this.http.get<any>(`${this.apiURL}/cancelRequest?contractId=`+contractId);
  }
  cancelRequest1(contractId: string): Observable<any>
  {
    return this.http.get<any>(`${this.apiURL}/cancelRequest1?contractId=`+contractId);
  }
  cancelRequest2(contractId: string): Observable<any>
  {
    return this.http.get<any>(`${this.apiURL}/cancelRequest2?contractId=`+contractId);
  }
  renewContract(contractId: string): Observable<any>
  {
    return this.http.get<any>(`${this.apiURL}/renew-contract?contractId=`+contractId);
  }
  sentOriginal(contractId: string): Observable<any>
  {
    return this.http.get<any>(`${this.apiURL}/sent-original?contractId=`+contractId);
  }
  actionForExpired(contractId: string, action: string): Observable<any>
  {
    return this.http.get<any>(`${this.apiURL}/action-expired?contractId=`+contractId+'&action='+action);
  }
  newConversationComment(params: NewConversationComment): Observable<any>
  {
    return this.http.post<any>(`${this.apiURL}/newConversationComment`, params);
  }

  listConversationByStatus(statusId: string): Observable<any>
  {
    return this.http.get<string>(`${this.apiURL}/listConversationByStatus?statusId=`+statusId);
  }

  listOfficialCommentByStatus(statusId: string): Observable<any>
  {
    return this.http.get<string>(`${this.apiURL}/listOfficialCommentByStatus?statusId=`+statusId);
  }

  listFeedbackCommentByStatus(statusId: string): Observable<any>
  {
    return this.http.get<string>(`${this.apiURL}/listFeedbackCommentByStatus?statusId=`+statusId);
  }

  officialCommentById(id: string): Observable<any>
  {
    return this.http.get<any>(`${this.apiURL}/officialCommentById?id=`+id);
  }
  feedbackCommentById(id: string): Observable<any>
  {
    return this.http.get<any>(`${this.apiURL}/feedbackCommentById?id=`+id);
  }

  newOfficialComment(params: any): Observable<any>
  {
    return this.http.post<any>(`${this.apiURL}/newOfficialComment`, params);
  }
  importOfficialComment(params: any): Observable<any>
  {
    return this.http.post<any>(`${this.apiURL}/importOfficialComment`, params);
  }
  newFeedbackComment(params: any): Observable<any>
  {
    return this.http.post<any>(`${this.apiURL}/newFeedbackComment`, params);
  }

  editOfficialComment(id: string, params: any): Observable<any>
  {
    return this.http.put<any>(`${this.apiURL}/editOfficialComment?id=` + id, params);
  }
  editFeedbackComment(id: string, params: any): Observable<any>
  {
    return this.http.put<any>(`${this.apiURL}/editFeedbackComment?id=` + id, params);
  }

  removeOfficialComment(id: string): Observable<any>{
    return this.http.delete<any>(`${this.apiURL}/removeOfficialComment?id=` + id);
  }
  removeFeedbackComment(id: string): Observable<any>{
    return this.http.delete<any>(`${this.apiURL}/removeFeedbackComment?id=` + id);
  }
  returnByFeedback(id: string): Observable<any>{
    return this.http.get<any>(`${this.apiURL}/returnByFeedback?id=` + id);
  }
  markRevise(statusId: string, params: any): Observable<any>
  {
    return this.http.put<any>(`${this.apiURL}/markRevise?statusId=`+statusId, params);
  }

  acceptRevise(statusId: string, accept: Boolean): Observable<any>
  {
    return this.http.put<any>(`${this.apiURL}/acceptRevise?statusId=`+statusId, accept);
  }

  modifyRequest(statusId: string, require: Boolean): Observable<any>
  {
    return this.http.put<any>(`${this.apiURL}/modifyRequest?statusId=`+statusId, require);
  }


  uploadSigned(params: any, contractID: string): Observable<any>
  {
    
    if (this.someDataObservable) {
      return this.someDataObservable;
    } else {
      this.someDataObservable = this.http.put<any>(`${this.apiURL}/uploadSigned?contractID=`+contractID, params).pipe(share());
      return this.someDataObservable;
    }
  }
  replaceDocument(params: any, statusID: string): Observable<any>
  {
    return this.http.put<any>(`${this.apiURL}/replaceDocument?statusID=`+statusID, params);
  }

  checkViewPermission(contractID: string): Observable<any>
  {
    return this.http.get<any>(`${this.apiURL}/checkViewPermission?contractID=`+contractID);
  }

  canCancel(contractID: string): Observable<any>
  {
    return this.http.get<Boolean>(`${this.apiURL}/canCancel?contractID=`+contractID);
  }
  canEditRequest(contractID: string): Observable<any>
  {
    return this.http.get<Boolean>(`${this.apiURL}/canEditRequest?contractID=`+contractID);
  }
  canFeedbackRequest(contractStatusID: string): Observable<any>
  {
    return this.http.get<Boolean>(`${this.apiURL}/canFeedbackRequest?contractStatusId=`+contractStatusID);
  }

  isFirstApprover(contractID: string): Observable<any>
  {
    return this.http.get<Boolean>(`${this.apiURL}/isFirstApprover?contractID=`+contractID);
  }

  remindNextApprover(contractID: string): Observable<any>
  {
    return this.http.put<any>(`${this.apiURL}/remindNextApprover?contractID=`+contractID, {});
  }

  getSignerList(grade: string, department: any[]): Observable<any>
  {
    return this.http.post<any>(`${this.apiURL}/getSignerList?grade=`+grade, department);
  }

  sendInformSigner(contractId: string, signer: Number[]): Observable<any>
  {
    return this.http.post<any>(`${this.apiURL}/sendInformSigner?contractId=`+contractId, signer);
  }
  shareContract(contractId: string, depts: Number[]): Observable<any>
  {
    return this.http.post<any>(`${this.apiURLMaster}/add-contract-shared?contractId=`+contractId, depts);
  }
  remindExpired(contractId: string, userId: Number[]): Observable<any>
  {
    return this.http.post<any>(`${this.apiURL}/remindExpired?contractId=`+contractId, userId);
  }

  remindUploadScan(contractId: string, userId: Number[]): Observable<any>
  {
    return this.http.post<any>(`${this.apiURL}/remindFinalChecked?contractId=`+contractId, userId);
  }

  getRelatedAppendix(contractId: string): Observable<any>
  {
    return this.http.get<any>(`${this.apiURL}/getRelatedAppendix?contractId=`+contractId);
  }

  newLiquidation(contractId: string, liquidation: any): Observable<any>
  {
    return this.http.put<any>(`${this.apiURL}/newLiquidation?contractId=`+contractId, liquidation);
  }

  filterContractLiquidation(filterData: any): Observable<any>
  {
    return this.http.post<any>(`${this.apiURL}/filterContractLiquidation`, filterData);
  }

  getDetailContractLiquidation(contractId: string): Observable<any>
  {
    return this.http.get<any>(`${this.apiURL}/getDetailContractLiquidation?contractId=`+contractId);
  }
  getDetailDraft(username: string): Observable<any>
  {
    return this.http.get<any>(`${this.apiURL}/getDetailDraft?username=`+username);
  }
  cancelLiquidation(contractId: string): Observable<any>
  {
    return this.http.get<any>(`${this.apiURL}/cancelLiquidation?contractId=`+contractId);
  }

  canCancelLiquidation(contractId: string): Observable<any>
  {
    return this.http.get<any>(`${this.apiURL}/canCancelLiquidation?contractId=`+contractId);
  }

  approveLiquidation(contractId: string, params: any): Observable<any>
  {
    if (this.someDataObservable) {
      return this.someDataObservable;
    } else {
      this.someDataObservable = this.http.put<any>(`${this.apiURL}/approveLiquidation?contractId=`+contractId, params).pipe(share());
      return this.someDataObservable;
    }
  }

  watermark(statusId: any): Observable<any>
  {
    return this.http.put<any>(`${this.apiURL}/watermark?statusId=`+statusId, {});
  }
  mgrAbsent(statusId: any): Observable<any>
  {
    return this.http.put<any>(`${this.apiURL}/absentMgr?statusId=`+statusId, {});
  }
  wordtopdf(statusId: any): Observable<any>
  {
    return this.http.put<any>(`${this.apiURL}/wordtopdf?statusId=`+statusId, {});
  }
}
