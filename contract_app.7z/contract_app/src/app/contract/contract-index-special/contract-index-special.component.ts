import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-contract-index-special',
  templateUrl: './contract-index-special.component.html',
  styleUrls: ['./contract-index-special.component.scss']
})
export class ContractIndexSpecialComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
