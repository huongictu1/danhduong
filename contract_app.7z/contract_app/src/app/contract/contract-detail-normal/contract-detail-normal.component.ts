import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-contract-detail-normal',
  templateUrl: './contract-detail-normal.component.html',
  styleUrls: ['./contract-detail-normal.component.scss']
})
export class ContractDetailNormalComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
