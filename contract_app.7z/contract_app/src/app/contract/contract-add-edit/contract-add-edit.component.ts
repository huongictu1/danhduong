import { Component, Input, OnInit } from '@angular/core';
import { contractKindDTO } from 'src/app/masters/contractkind/contract-kind.model';
import { ContractKindService } from 'src/app/masters/contractkind/contract-kind.service';
import { FormBuilder } from '@angular/forms';
import { RequestKindService } from 'src/app/masters/requestkind/request-kind.service';
import { requestKindDTO } from 'src/app/masters/requestkind/request-kind.model';
import { DepartmentService } from 'src/app/departments/department.service';
import { Department } from 'src/app/departments/department.model';
import { ContractService } from '../contract.service';
import {
  FormControl,
  FormArray,
  Validators
} from '@angular/forms';
import { MasterService } from 'src/app/masters/masters.service';
import { ActivatedRoute, Router } from '@angular/router';
import { getImageSrc, isDocx, isOffice, isPdf, isExcel, splitLink, splitPathFile } from 'src/app/utilities/utils';
import Swal from 'sweetalert2';
import { concatLink, formatDate } from 'src/app/utilities/utils';
import { SecurityService } from 'src/app/security/security.service';
// import { TourService } from '@ngx-tour/ngx-bootstrap';
import { yearsPerPage } from '@angular/material/datepicker';
@Component({
  selector: 'app-contract-add-edit',
  templateUrl: './contract-add-edit.component.html',
  styleUrls: ['./contract-add-edit.component.scss']
})
export class ContractAddEditComponent implements OnInit {
  numberRegEx = /\-?\d*\.?\d{1,2}/;
  contractDetail: any;
  public document_file: any;
  public DocumentDraft: string[] = [];
  public DocumentSupplier: string[] = [];
  public AttorneySupplierAttachment: string[] = [];
  public DocumentProposal: string[] = [];
  public AttorneyCvnAttachment: string[] = [];
  public DocumentQuotation: string[] = [];
  public DocumentOthers: string[] = [];
  public ItRelatedAttachmentFiles: string[] = [];
  public UrgentAttachmentFiles: string[] = [];
  public contractKinds: contractKindDTO[];
  public requestKinds: requestKindDTO[];
  public departments: Department[];
  public contracts: any;
  public deptById: any;
  public masterCasualData: any;
  public masterCasual = new FormArray([]);
  public appendix: any;
  public checkIT: Boolean;
  public autoRenew: Boolean;
  public checkUrgent: Boolean;
  public checkUnusual: Boolean;
  public contractId: string;
  public previousId: string;
  public checkLetterOfAttorney = false;
  public checkLetterOfAttorneySupplier = false;
  public checkInputSignerCvn = false;
  public Title: string;
  public hidePaymentTerm = false;
  statusId: string;
  allDepartment: any;
  allGrade: any;
  contractForm = this.fb.group({
    ContractNo: new FormControl('', [Validators.required]),
    ContractKind: new FormControl('', [Validators.required]),
    DeptId: new FormControl('', [Validators.required]),
    ContractName: new FormControl('', [Validators.required]),
    ContractContent: new FormControl('', [Validators.required]),
    SupplierName: new FormControl('', [Validators.required]),
    ContractDate: new FormControl('', [Validators.required]),
    ExpiredDate: new FormControl('', [Validators.required]),
    ContractValues: new FormControl(0),
    ContractValuesUnit: new FormControl('USD'),
    RequestKind: new FormControl('', [Validators.required]),
    ItRelated: new FormControl(false),
    AutoRenew: new FormControl(false),
    ItRelatedDetail: new FormControl(''),
    ItRelatedAttachment: new FormControl(''),
    SupplierTax: new FormControl(null, [Validators.required]),
    SupplierAddress: new FormControl(null, [Validators.required]),
    SupplierRepresentative: new FormControl(null, [Validators.required]),
    ContractValuesEstimate: new FormControl(''),
    AppendixId: new FormControl(0),
    PreviousId: new FormControl(0),
    PaymentTermStr: new FormControl('Usual'),
    Urgent: new FormControl(false),
    UrgentDetail: new FormControl(''),
    PaymentTermDetail: new FormControl(''),
    PaydateMonthly: new FormControl(1, [Validators.max(31), Validators.min(1)]),
    SignerCvn: new FormControl(''),
    SignerCvnInput: new FormControl(''),
    SignerDeptId: new FormControl(),
    SignerSupplier: new FormControl(''),
    SignerCvnPosition: new FormControl(''),
    SignerSupplierPosition: new FormControl(''),
    AttorneyCvn: new FormControl(false),
    AttorneySupplier: new FormControl(false),
    ReferenceContract: new FormControl(),
    TerminationTerm: new FormControl(''),
    departmentSigner: new FormControl(),
    ContactNumber: new FormControl("", [Validators.required])
  });
  gradeSigner: any;
  signer: any;
  departmentSigner: any;
  allSigner: any;
  @Input()
  isEdit: boolean = false;
  @Input()
  isSpecial: boolean = false;
  @Input()
  isTutorial: boolean = false;
  constructor(
    public contractKindService: ContractKindService,
    public requestKindService: RequestKindService,
    public departmentService: DepartmentService,
    public contractService: ContractService,
    public masterService: MasterService,
    public fb: FormBuilder,
    public router: Router,
    public route: ActivatedRoute,
    public securityService: SecurityService,
    // private tourService: TourService
  ) { 
    
  }
  startTour(){
    // this.tourService.initialize([
    //   { anchorId: 'step0', enableBackdrop: true, content: 'The first, please check rule.' },
    //   { anchorId: 'step1', enableBackdrop: true, content: 'Select reference contract.' },
    //   { anchorId: 'step2', enableBackdrop: true, content: '* Input your Contract Number.', placement: 'right'},
    //   { anchorId: 'step3', enableBackdrop: true, content: '* Select your department.', placement: 'right'},
    //   { anchorId: 'step4', enableBackdrop: true, content: '* Input Contract Name.', placement: 'right'},
    //   { anchorId: 'step5', enableBackdrop: true, content: '* Select Contract kind.', placement: 'right'},
    //   { anchorId: 'step6', enableBackdrop: true, content: 'If related to IT, please attach form.', placement: 'right'},
    //   { anchorId: 'step7', enableBackdrop: true, content: '* Input PHS/Ext/phone number of PIC.', placement: 'right'},
    //   { anchorId: 'step8', enableBackdrop: true, content: '* Choose Request Kind.', placement: 'right'},
    //   { anchorId: 'step9', enableBackdrop: true, content: '* Choose Payment term (follow note as bellows).', placement: 'right'}
    // ]);
    // this.tourService.start();
  }
  ngOnInit(): void {
    this.Title = "";
    this.loadContractKind();
    this.loadRequestKind();
    this.loadDepartment();
    this.loadContract();
    this.masterCasual.push(new FormControl('', [Validators.required]));
    this.masterCasual.push(new FormControl('', [Validators.required]));
    this.masterCasual.push(new FormControl('', [Validators.required]));
    this.masterCasual.push(new FormControl('', [Validators.required]));
    this.masterCasual.push(new FormControl('', [Validators.required]));
    this.masterCasual.push(new FormControl('', [Validators.required]));
    this.checkIT = false;
    this.autoRenew = false;
    this.checkUnusual = false;
    this.checkUrgent = false;
    this.contractId = this.route.snapshot.paramMap.get('contractId');
    this.previousId = this.route.snapshot.paramMap.get('previousId');
    this.statusId = this.route.snapshot.paramMap.get('statusId');
    if (this.isEdit) {
      if (!this.isSpecial) {
        this.checkEditPermission();
        this.loadGetDetailContract();
      } else {
        this.checkEditPermissionTemp();
        this.loadGetDetailTempContract();
      }
    }
    if(this.isTutorial){
      this.startTour();
    }
    this.departmentService.getAll().subscribe(data => {
      this.allDepartment = data;
    })
    this.allGrade = [
      { name: "MGR" },
      { name: "AGM" },
      { name: "GM" },
      { name: "SGM" },
      { name: "FM" },
      { name: "GD" },
    ];
    if (!this.isEdit && this.previousId != null && this.previousId != '') {
      this.contractForm.get("ReferenceContract").setValue(this.previousId);
      this.contractForm.value.ReferenceContract = this.previousId;
      if(!this.isTutorial){
        this.loadReference();
      }
    }
  }

  logData() {
    //console.log(this.contractForm.value);
  }

  loadContractKind() {
    this.contractKindService.getContractKinds().subscribe((data) => {
      this.contractKinds = data;
    });
  }

  loadRequestKind() {
    this.requestKindService.getRequestKinds().subscribe((data) => {
      this.requestKinds = data;
    });
  }

  loadDepartment() {
    this.departmentService.getDeptByUser().subscribe((data) => {
      this.departments = data;
    });
  }

  loadContract() {
    if(!this.isTutorial){
      this.contractService.getAllAppendix().subscribe((data) => {
        this.appendix = data;
      });
    }
    else{
      this.contractService.getTutorialAppendix().subscribe((data) => {
        this.appendix = data;
      });
    }
  }

  loadFindApprover(grade: Number, deptId: Number) {
    this.masterService.getFindApprover(grade, deptId).subscribe((data) => {
      this.contracts = data;
    });
  }

  loadMasterCasual(status: Number, deptId: Number, paymentTermStr: string) {
    try {
      //console.log("loadMasterCasual")
      let createBy = "";
      if (this.contractDetail && this.contractDetail.createdBy != "") {
        createBy = this.contractDetail.createdBy;
      } else {
        createBy = this.securityService.getFieldFromJWT('user_name') ?? "";
      }

      if (this.isNeedApproval()) {
        this.contractService
          .masterCasual(status, deptId, paymentTermStr, this.contractId)
          .subscribe((data) => {
            this.masterCasualData = data;
            //console.log("this.masterCasualData", this.masterCasualData);
            for (let i = 0; i < data.length; i++) {
              if (this.masterCasualData[i].lstApprover[0] && this.masterCasualData[i].lstApprover[0].userName) {
                this.masterCasual.controls[i].setValue(this.masterCasualData[i].lstApprover[0].userName)
                if (i == 0) {
                  for (let j = 0; j < this.masterCasualData[i].lstApprover.length; j++) {
                    if (this.masterCasualData[i].lstApprover[j].userName == createBy) {
                      this.masterCasual.controls[i].setValue(createBy)
                    }
                  }
                }
              } else {
                Swal.fire("Please contact Co Legal to set PIC Approval", 'Bad request', 'error');
              }
            }
          });
      }
    } catch (error) {
      Swal.fire("Please contact Co Legal to set PIC Approval", 'Bad request', 'error');
    }

    //console.log("this.masterCasual", this.masterCasual)
  }
  onFormSubmit() {
    if (this.DocumentDraft == null || this.DocumentDraft.length == 0) {
      Swal.fire("Please add contract documents ! ", 'Lack of Contract documents', 'error');
      return;
    }
    else if (this.contractForm.value.ItRelated == true && (this.ItRelatedAttachmentFiles == null || this.ItRelatedAttachmentFiles.length == 0) && !this.isEdit) {
      Swal.fire("Please add attachment form IT Related", 'Lack of IT related form', 'error');
      return;
    }
    else if (this.contractForm.value.ContractNo == null || this.contractForm.value.ContractNo == '') {
      Swal.fire("Required contract no", 'Lack of information', 'error');
      return;
    } else if (this.contractForm.value.ContractKind == null) {
      Swal.fire("Required contract kind", 'Lack of information', 'error');
      return;
    } else if (this.contractForm.value.DeptId == null) {
      Swal.fire("Required department", 'Lack of information', 'error');
      return;
    } else if (this.contractForm.value.ContractName == null || this.contractForm.value.ContractName == '') {
      Swal.fire("Required contract name", 'Lack of information', 'error');
      return;
    } else if (this.contractForm.value.ContractContent == null || this.contractForm.value.ContractContent == '') {
      Swal.fire("Required contract content", 'Lack of information', 'error');
      return;
    } else if (this.contractForm.value.SupplierName == null || this.contractForm.value.SupplierName == '') {
      Swal.fire("Required supplier name", 'Lack of information', 'error');
      return;
    }
    else if (this.contractForm.value.ContractDate == null || this.contractForm.value.ContractDate == '') {
      Swal.fire("Required effective date", 'Lack of information', 'error');
      return;
    }
    else if (this.contractForm.value.ExpiredDate == null || this.contractForm.value.ExpiredDate == '') {
      Swal.fire("Required expired date", 'Lack of information', 'error');
      return;
    } else if (this.contractForm.value.PaymentTermStr != 'N/A' && (this.contractForm.value.ContractValues == null || this.contractForm.value.ContractValues == 0) && (this.contractForm.value.ContractValuesEstimate == null || this.contractForm.value.ContractValuesEstimate == 0 || this.contractForm.value.ContractValuesEstimate == '')) {
      Swal.fire("Required contract values", 'Lack of information', 'error');
      return;
    } else if (this.contractForm.value.RequestKind == null) {
      Swal.fire("Required request kind", 'Lack of information', 'error');
      return;
    } else if (this.contractForm.value.SupplierTax == null || this.contractForm.value.SupplierTax == '') {
      Swal.fire("Required supplier tax", 'Lack of information', 'error');
      return;
    } else if (this.contractForm.value.SupplierAddress == null || this.contractForm.value.SupplierAddress == '') {
      Swal.fire("Required supplier address", 'Lack of information', 'error');
      return;
    } else if (this.contractForm.value.SupplierRepresentative == null || this.contractForm.value.SupplierRepresentative == '') {
      Swal.fire("Required supplier representative", 'Lack of information', 'error');
      return;
    } else if (!this.hidePaymentTerm && (this.contractForm.value.PaymentTermDetail == null || this.contractForm.value.PaymentTermDetail == '')) {
      Swal.fire("Required payment term details", 'Lack of information', 'error');
      return;
    } else if (this.contractForm.value.ContactNumber == null || this.contractForm.value.ContactNumber == '') {
      Swal.fire("Required Contact Number", 'Lack of information', 'error');
      return;
    } else if (this.contractForm.value.SignerCvnPosition == null || this.contractForm.value.SignerCvnPosition == '') {
      Swal.fire("Required CVN Signer Position", 'Lack of information', 'error');
      return;
    }
    else if (this.contractForm.value.SignerSupplier == null || this.contractForm.value.SignerSupplier == '') {
      Swal.fire("Required Signer Supplier Name", 'Lack of information', 'error');
      return;
    }
    else if (this.contractForm.value.SignerSupplierPosition == null || this.contractForm.value.SignerSupplierPosition == '') {
      Swal.fire("Required Signer Supplier Position", 'Lack of information', 'error');
      return;
    }
    else if (this.contractForm.value.SignerDeptId == null || this.contractForm.value.SignerDeptId == '') {
      Swal.fire("Required CVN Signer Department", 'Lack of information', 'error');
      return;
    } else if (this.checkInputSignerCvn == false && (this.contractForm.value.SignerCvn == null || this.contractForm.value.SignerCvn == '')) {
      Swal.fire("Required CVN Signer Name", 'Lack of information', 'error');
      return;
    } else if (this.checkInputSignerCvn == true && (this.contractForm.value.SignerCvnInput == null || this.contractForm.value.SignerCvnInput == '')) {
      Swal.fire("Required CVN Signer Code", 'Lack of information', 'error');
      return;
    } else if (this.checkInputSignerCvn == true && (this.contractForm.value.SignerCvnInput.length < 1)) {
      Swal.fire("Required CVN Signer Code/Name", 'Wrong code', 'error');
      return;
    } else if (this.contractForm.value.ContractValues >= 300000 && this.contractForm.value.ContractValuesUnit == 'USD' && (this.contractForm.value.SignerCvnPosition != 'GD')) {
      Swal.fire("Please check CVN Signer: GD", 'Wrong signer', 'error');
      return;
    } else if (this.contractForm.value.ContractValues >= 7000000000 && this.contractForm.value.ContractValuesUnit == 'VND' && (this.contractForm.value.SignerCvnPosition != 'GD')) {
      Swal.fire("Please check CVN Signer: GD", 'Wrong signer', 'error');
      return;
    } else if (this.contractForm.value.ContractValues >= 47000000 && this.contractForm.value.ContractValuesUnit == 'JPY' && (this.contractForm.value.SignerCvnPosition != 'GD')) {
      Swal.fire("Please check CVN Signer: GD", 'Wrong signer', 'error');
      return;
    } else if (this.contractForm.value.ContractValuesEstimate >= 300000 && this.contractForm.value.ContractValuesUnit == 'USD' && (this.contractForm.value.SignerCvnPosition != 'GD')) {
      Swal.fire("Please check CVN Signer: GD", 'Wrong signer', 'error');
      return;
    } else if (this.contractForm.value.ContractValuesEstimate >= 7000000000 && this.contractForm.value.ContractValuesUnit == 'VND' && (this.contractForm.value.SignerCvnPosition != 'GD')) {
      Swal.fire("Please check CVN Signer: GD", 'Wrong signer', 'error');
      return;
    } else if (this.contractForm.value.ContractValuesEstimate >= 47000000 && this.contractForm.value.ContractValuesUnit == 'JPY' && (this.contractForm.value.SignerCvnPosition != 'GD')) {
      Swal.fire("Please check CVN Signer: GD", 'Wrong signer', 'error');
      return;
    }
    else if (this.contractForm.value.Urgent == true && (this.UrgentAttachmentFiles == null || this.UrgentAttachmentFiles.length == 0) && !this.isEdit) {
      Swal.fire("Please add attachment form Urgent/Backdate", 'Lack of urgent/backdate form', 'error');
      return;
    }

    // // // //check nếu ngày effective date mà trong vòng 14 ngày thì prevent
    // // // const contractDate = this.contractForm.value.ContractDate;
    // // // const fourteenDaysLaterTimestamp = this.addDays(14);
    // // // console.log(contractDate)
    // // // console.log(fourteenDaysLaterTimestamp)
    // // // if (contractDate < fourteenDaysLaterTimestamp && this.contractForm.value.Urgent == false) {
    // // //   Swal.fire('Inappropriate effective date', "Please input Effective date at least 14 days since submission date or attach Back-date explanation !", 'error');
    // // //   return;
    // // // }
    let formData = new FormData();
    for (const property in this.contractForm.value) {
      if (property != 'DocumentDraft'
        && property != 'DocumentSupplier'
        && property != 'DocumentProposal'
        && property != 'DocumentAttorney'
        && property != 'AttorneySupplierAttachment'
        && property != 'AttorneyCvnAttachment'
        && property != 'DocumentOthers'
        && property != 'DocumentQuotation'
        && property != 'UrgentAttachment'
        && property != 'ItRelatedAttachment') {
        formData.append(property, this.contractForm.value[property]);
      }
    }

    for (let i = 0; i < this.DocumentDraft.length; i++) {
      formData.append('DocumentDraft', this.DocumentDraft[i]);
    }
    for (let i = 0; i < this.DocumentSupplier.length; i++) {
      formData.append('DocumentSupplier', this.DocumentSupplier[i]);
    }
    for (let i = 0; i < this.DocumentProposal.length; i++) {
      formData.append('DocumentProposal', this.DocumentProposal[i]);
    }
    for (let i = 0; i < this.AttorneySupplierAttachment.length; i++) {
      formData.append('AttorneySupplierAttachment', this.AttorneySupplierAttachment[i]);
    }
    for (let i = 0; i < this.AttorneyCvnAttachment.length; i++) {
      formData.append('AttorneyCvnAttachment', this.AttorneyCvnAttachment[i]);
    }
    for (let i = 0; i < this.DocumentOthers.length; i++) {
      formData.append('DocumentOthers', this.DocumentOthers[i]);
    }
    for (let i = 0; i < this.DocumentQuotation.length; i++) {
      formData.append('DocumentQuotation', this.DocumentQuotation[i]);
    }
    for (let i = 0; i < this.ItRelatedAttachmentFiles.length; i++) {
      formData.append('ItRelatedAttachment', this.ItRelatedAttachmentFiles[i]);
    }
    for (let i = 0; i < this.UrgentAttachmentFiles.length; i++) {
      formData.append('UrgentAttachment', this.UrgentAttachmentFiles[i]);
    }
    if (this.contractForm.value.ReferenceContract) {
      this.contractForm.value.PreviousId = this.contractForm.value.ReferenceContract ?? null;
    }

    //Khong phai hop dong special thi chua can duong approval
    if (this.isNeedApproval()) {
      for (let i = 0; i < this.masterCasualData.length; i++) {
        formData.append(
          'lstCasualComment',
          JSON.stringify({
            comment: '',
            cmtOrder: i + 1,
            approver: this.masterCasual.controls[i].value,
            deptId: this.masterCasualData[i].deptId ?? 0,
            grade: this.masterCasualData[i].detailGrade,
            special: this.contractForm.value.Unusual,
            sendMulti: this.masterCasualData[i].sendMulti,
            stepName: this.masterCasualData[i].stepName,
          })
        );
      }
    }
    if (this.isTutorial == false) {
      // them moi hop dong thong thuong
      if (!this.isSpecial && !this.isEdit) {
        this.contractService.newContract(formData).subscribe((data) => {
          // console.log("response",data)
          if (data.status == 400) {
            Swal.fire(data.message, 'Bad request', 'error');
          }
          if (data.status == 200) {
            this.router.navigate(['/main/detail', data.message]);
          }
        }, (error) => {
          Swal.fire(error.errors, 'Bad request', 'error');
        });
      }
      //sua hop dong thuong
      if (!this.isSpecial && this.isEdit) {
        this.contractService.editContract(formData, this.contractId).subscribe((data) => {
          // console.log("response",data)
          if (data.status == 400) {
            Swal.fire(data.message, 'Bad request', 'error');
          }
          if (data.status == 200) {
            this.router.navigate(['/main/detail', this.contractId]);
          }
        }, (error) => {
          Swal.fire(error.errors, 'Bad request', 'error');
        });
      }
      //them moi hop dong special
      if (this.isSpecial && !this.isEdit) {
        this.contractService.newSpecial(formData).subscribe((data) => {
          // console.log("response",data)
          if (data.status == 400) {
            Swal.fire(data.message, 'Bad request', 'error');
          }
          if (data.status == 200) {
            this.router.navigate(['/main/detail', data.message]);
          }
        }, (error) => {
          Swal.fire(error.errors, 'Bad request', 'error');
        });
      }
      //sua special
      if (this.isSpecial && this.isEdit) {
        this.contractService.saveSpecial(formData, this.contractId).subscribe((data) => {
          // console.log("sua hop dong special",data)
          if (data.status == 400) {
            Swal.fire(data.message, 'Fail request', 'error');
          }
          if (data.status == 200) {
            this.router.navigate(['/main/detail', data.message]);
          }
        }, (error) => {
          Swal.fire(error.errors, 'Bad request', 'error');
        });
      }
    }



  }
  onSaveDraft() {
    let formData = new FormData();
    for (const property in this.contractForm.value) {
      if (property != 'DocumentDraft'
        && property != 'DocumentSupplier'
        && property != 'DocumentProposal'
        && property != 'DocumentAttorney'
        && property != 'AttorneySupplierAttachment'
        && property != 'AttorneyCvnAttachment'
        && property != 'DocumentOthers'
        && property != 'DocumentQuotation'
        && property != 'UrgentAttachment'
        && property != 'ItRelatedAttachment') {
        formData.append(property, this.contractForm.value[property]);
      }
    }
    this.contractService.saveDraft(formData).subscribe((data) => {
      // console.log("response",data)
      if (data.status == 400) {
        Swal.fire(data.message, 'Bad request', 'error');
      }
      if (data.status == 200) {
        Swal.fire(data.message, 'Notice', 'success');
      }
    }, (error) => {
      Swal.fire(error.errors, 'Bad request', 'error');
    });


  }
  // addDays(days: number): Date {
  //   const result = new Date();
  //   result.setDate(result.getDate() + days);
  //   return result;
  // }
  sampleDownload() {
    var link = document.createElement('a');
    link.href = concatLink('/common/sampleUrgentForm');
    link.target = '_blank';
    link.download = "Urgent form.xls";
    //console.log(link);
    link.click();
  }
  loadDraft() {
    this.contractService.getDetailDraft(this.securityService.getUsername()).subscribe((data) => {
      if (data != null) {
        //console.log("ReferenceContract", data);
        this.contractForm.controls['ContractNo'].setValue(data.contractNo);
        this.contractForm.controls['ContractName'].setValue(data.contractName);
        this.contractForm.controls['ContactNumber'].setValue(data.contactNumber);
        this.contractForm.controls['AutoRenew'].setValue(data.autoRenew);
        this.contractForm.controls['ContractKind'].setValue(data.contractKindId);
        this.contractForm.controls['RequestKind'].setValue(data.requestKindId);
        this.contractForm.controls['DeptId'].setValue(data.deptId);
        this.contractForm.controls['ContractContent'].setValue(this.checkValueNullString(data.contractContent));
        this.contractForm.controls['TerminationTerm'].setValue(this.checkValueNullString(data.terminationTerm));
        this.contractForm.controls['SignerCvn'].setValue(this.checkValueNullString(data.signerCvn));
        this.contractForm.controls['SignerCvnInput'].setValue(this.checkValueNullString(data.signerCvn));
        this.contractForm.controls['SignerSupplier'].setValue(this.checkValueNullString(data.signerSupplier));
        this.contractForm.controls['SignerSupplierPosition'].setValue(this.checkValueNullString(data.signerSupplierPosition));
        this.contractForm.controls['SignerCvnPosition'].setValue(this.checkValueNullString(data.signerCvnPosition));
        this.contractForm.controls['SupplierName'].setValue(this.checkValueNullString(data.supplierName));
        this.contractForm.controls['SupplierRepresentative'].setValue(this.checkValueNullString(data.supplierRepresentative));
        this.contractForm.controls['SupplierAddress'].setValue(this.checkValueNullString(data.supplierAddress));
        this.contractForm.controls['SupplierTax'].setValue(this.checkValueNullString(data.supplierTax));
        this.contractForm.controls['PaymentTermDetail'].setValue(this.checkValueNullString(data.paymentTermDetail));
        this.contractForm.controls['PaydateMonthly'].setValue(this.checkValueNullString(data.paydateMonthly));
        this.contractForm.controls['PaymentTermStr'].setValue(this.checkValueNullString(data.paymentTermStr));
        this.hidePaymentTerm = data.paymentTermStr == 'N/A';
      }

    })
  }
  cancelRequest() {
    this.contractService.cancelRequest(this.contractId).subscribe((data) => {
      if (data.status == 400) {
        Swal.fire(data.message, 'Fail request', 'error');
      }
      if (data.status == 200) {
        this.router.navigate(['/home']);
      }
    }, (error) => {
      Swal.fire(error.errors, 'Bad request', 'error');
    });
  }

  onDocumentDraftSelect(event) {
    this.DocumentDraft = [];
    let target_file_length = event.target.files.length;
    if (target_file_length > 0) {
      for (var i = 0; i < event.target.files.length; i++) {
        let file_name = event.target.files[i].name;
        if (isDocx(file_name) || isPdf(file_name) || isExcel(file_name)) {
          this.DocumentDraft.push(event.target.files[i]);
        } else {
          this.document_file = '';
          Swal.fire(
            'Contract document require pdf, excel or word file',
            'Warning',
            'warning'
          );
        }
      }
    }
  }

  onDocumentSupplierSelect(event) {
    this.DocumentSupplier = [];
    let target_file_length = event.target.files.length;
    if (target_file_length > 0) {
      for (var i = 0; i < event.target.files.length; i++) {
        this.DocumentSupplier.push(event.target.files[i]);
      }
    }
  }

  onDocumentProposalSelect(event) {
    this.DocumentProposal = [];
    let target_file_length = event.target.files.length;
    if (target_file_length > 0) {
      for (var i = 0; i < event.target.files.length; i++) {
        this.DocumentProposal.push(event.target.files[i]);
      }
    }
  }

  onAttorneyCvnAttachmentSelect(event) {
    this.AttorneyCvnAttachment = [];
    let target_file_length = event.target.files.length;
    if (target_file_length > 0) {
      for (var i = 0; i < event.target.files.length; i++) {
        this.AttorneyCvnAttachment.push(event.target.files[i]);
      }
    }
  }

  onDocumentQuotationSelect(event) {
    this.DocumentQuotation = [];
    let target_file_length = event.target.files.length;
    if (target_file_length > 0) {
      for (var i = 0; i < event.target.files.length; i++) {
        this.DocumentQuotation.push(event.target.files[i]);
      }
    }
  }

  onDocumentOthersSelect(event) {
    this.DocumentOthers = [];
    let target_file_length = event.target.files.length;
    if (target_file_length > 0) {
      for (var i = 0; i < event.target.files.length; i++) {
        this.DocumentOthers.push(event.target.files[i]);
      }
    }
  }

  onItRelatedAttachmentFilesSelect(event) {
    this.ItRelatedAttachmentFiles = [];
    let target_file_length = event.target.files.length;
    if (target_file_length > 0) {
      for (var i = 0; i < event.target.files.length; i++) {
        this.ItRelatedAttachmentFiles.push(event.target.files[i]);
      }
    }
  }
  onUrgentAttachmentFilesSelect(event) {
    this.UrgentAttachmentFiles = [];
    let target_file_length = event.target.files.length;
    if (target_file_length > 0) {
      for (var i = 0; i < event.target.files.length; i++) {
        this.UrgentAttachmentFiles.push(event.target.files[i]);
      }
    }
  }
  onAttorneySupplierAttachmentSelect(event) {
    this.AttorneySupplierAttachment = [];
    let target_file_length = event.target.files.length;
    if (target_file_length > 0) {
      for (var i = 0; i < event.target.files.length; i++) {
        this.AttorneySupplierAttachment.push(event.target.files[i]);
      }
    }
  }

  loadRouteApproval() {
    var paymentTermNotNA = this.contractForm.value.PaymentTermStr == 'Unusual' ? 'Unusual' : 'Usual';
    this.hidePaymentTerm = this.contractForm.value.PaymentTermStr == 'N/A';
    if (this.contractForm.value.DeptId) {
      if (this.contractDetail) {
        this.loadMasterCasual(
          this.contractDetail.statusId,
          this.contractForm.value.DeptId,
          paymentTermNotNA
        );
      }
      else {
        this.loadMasterCasual(
          this.isSpecial ? 6 : 1,
          this.contractForm.value.DeptId,
          paymentTermNotNA
        );
      }
    }
  }

  checkEditPermission() {
    this.contractService.checkEditPermission(this.contractId).subscribe((data) => {
      if (data.status == 400) {
        this.router.navigate(['']);
      }
    });
  }
  checkEditPermissionTemp() {
    this.contractService.checkEditPermissionTemp(this.contractId).subscribe((data) => {
      if (data.status == 400) {
        this.router.navigate(['']);
      }
    });
  }

  concatLink(link) {
    return concatLink(link);
  }
  loadGetDetailContract() {

    this.contractService.getDetailContract(this.contractId).subscribe((data) => {
      this.contractDetail = data;
      //console.log("this contractDetail", data);
      this.checkUrgent = this.contractDetail.urgent;
      this.checkIT = this.contractDetail.itRelated;
      this.autoRenew = this.contractDetail.autoRenew;
      this.setContractData();
      this.loadRouteApproval();
    })
  }
  loadGetDetailTempContract() {
    this.contractService.getDetailContractTemp(this.contractId).subscribe((data) => {
      this.contractDetail = data;
      this.checkUrgent = this.contractDetail.urgent;
      this.checkIT = this.contractDetail.itRelated;
      this.autoRenew = this.contractDetail.autoRenew;
      this.Title = this.contractDetail.title;
      this.setContractData();
      this.loadRouteApproval();
    })
  }

  setContractData() {
    //console.log("this.contractDetail",this.contractDetail);
    this.contractForm.controls['ContractNo'].setValue(this.contractDetail.contractNo);
    this.contractForm.controls['PaymentTermStr'].setValue(this.contractDetail.paymentTermStr);
    this.hidePaymentTerm = this.contractDetail.paymentTermStr == 'N/A';
    this.contractForm.controls['ItRelatedDetail'].setValue(this.contractDetail.itRelatedDetail);
    this.contractForm.controls['UrgentDetail'].setValue(this.contractDetail.urgentDetail);
    this.contractForm.controls['PaymentTermDetail'].setValue(this.contractDetail.paymentTermDetail);
    this.contractForm.controls['Urgent'].setValue(this.contractDetail.urgent);
    this.contractForm.controls['ItRelated'].setValue(this.contractDetail.itRelated);
    this.contractForm.controls['AutoRenew'].setValue(this.contractDetail.autoRenew);
    this.contractForm.controls['ContractName'].setValue(this.contractDetail.contractName);
    this.contractForm.controls['ContactNumber'].setValue(this.contractDetail.contactNumber);
    this.contractForm.controls['TerminationTerm'].setValue(this.contractDetail.terminationTerm);
    this.contractForm.controls['ContractContent'].setValue(this.contractDetail.contractContent);
    this.contractForm.controls['SupplierName'].setValue(this.contractDetail.supplierName);
    this.contractForm.controls['ContractValues'].setValue(this.contractDetail.contractValues);
    this.contractForm.controls['DeptId'].setValue(this.contractDetail.deptId);
    this.contractForm.controls['RequestKind'].setValue(this.contractDetail.requestKindId);
    this.contractForm.controls['ContractKind'].setValue(this.contractDetail.contractKindId);
    this.contractForm.controls['SupplierTax'].setValue(this.contractDetail.supplierTax);
    this.contractForm.controls['SupplierAddress'].setValue(this.contractDetail.supplierAddress);
    this.contractForm.controls['SupplierRepresentative'].setValue(this.contractDetail.supplierRepresentative);
    this.contractForm.controls['ContractValues'].setValue(this.contractDetail.contractValues);
    this.contractForm.controls['ContractValuesEstimate'].setValue(this.contractDetail.contractValuesEstimate);
    this.contractForm.controls['ExpiredDate'].setValue(formatDate(this.contractDetail.expiredDate));
    this.contractForm.controls['ContractDate'].setValue(formatDate(this.contractDetail.contractDate));
    this.contractForm.controls['PaydateMonthly'].setValue(this.contractDetail.paydateMonthly);
    this.contractForm.controls['ContractValuesUnit'].setValue(this.contractDetail.contractValuesUnit);
    this.contractForm.controls['SignerCvn'].setValue(this.contractDetail.signerCvnCode);
    this.contractForm.controls['SignerCvnInput'].setValue(this.contractDetail.signerCvnCode);
    this.contractForm.controls['SignerSupplier'].setValue(this.contractDetail.signerSupplier);
    this.contractForm.controls['SignerCvnPosition'].setValue(this.contractDetail.signerCvnPosition);
    this.contractForm.controls['SignerSupplierPosition'].setValue(this.contractDetail.signerSupplierPosition);
    this.contractForm.controls['AttorneyCvn'].setValue(this.contractDetail.attorneyCvn);
    this.contractForm.controls['AttorneySupplier'].setValue(this.contractDetail.attorneySupplier);
    this.contractForm.controls['SignerDeptId'].setValue(this.contractDetail.signerDeptId);
    this.contractForm.controls['AppendixId'].setValue(this.contractDetail.appendixId ?? null);
    this.contractForm.controls['ReferenceContract'].setValue(this.contractDetail.previousId ?? null);
    this.getSignerList();
  }

  getFilenameWithoutGuid(link) {
    var fileFullName = splitPathFile(link);
    var fileName = fileFullName[fileFullName.length - 1];
    return fileName.substring(37);
  }
  changePaymentTerm() {
    this.loadRouteApproval();
  }

  splitLink(link) {
    return splitLink(link);
  }

  isDocx(fileName) {
    return isDocx(fileName);
  }

  isPdf(fileName) {
    return isPdf(fileName);
  }

  isOffice(fileName) {
    return isOffice(fileName);
  }

  getImageSrc(link) {
    return getImageSrc(link);
  }

  isNeedApproval(): boolean {
    // if (!this.isSpecial) {
    //   return true;
    // } else {
    //   if (this.isEdit) {
    //     return true;
    //   } else {
    //     return false;
    //   }
    // }
    return true;
  }

  loadReference() {
    if (this.contractForm.value.ReferenceContract) {
      this.contractService.getDetailContract(this.contractForm.value.ReferenceContract).subscribe((data) => {
        //console.log("ReferenceContract", data);
        this.contractForm.controls['ContractNo'].setValue(data.contractNo);
        this.contractForm.controls['ContractName'].setValue(data.contractName);
        this.contractForm.controls['ContactNumber'].setValue(data.contactNumber);
        this.contractForm.controls['AutoRenew'].setValue(data.autoRenew);
        this.contractForm.controls['ContractKind'].setValue(data.contractKindId);
        this.contractForm.controls['RequestKind'].setValue(data.requestKindId);
        //this.contractForm.controls['DeptId'].setValue(data.deptId);
        this.contractForm.controls['ContractContent'].setValue(this.checkValueNullString(data.contractContent));
        this.contractForm.controls['TerminationTerm'].setValue(this.checkValueNullString(data.terminationTerm));
        this.contractForm.controls['SignerCvn'].setValue(this.checkValueNullString(data.signerCvn));
        this.contractForm.controls['SignerCvnInput'].setValue(this.checkValueNullString(data.signerCvn));
        this.contractForm.controls['SignerSupplier'].setValue(this.checkValueNullString(data.signerSupplier));
        this.contractForm.controls['SignerSupplierPosition'].setValue(this.checkValueNullString(data.signerSupplierPosition));
        this.contractForm.controls['SignerCvnPosition'].setValue(this.checkValueNullString(data.signerCvnPosition));
        this.contractForm.controls['SupplierName'].setValue(this.checkValueNullString(data.supplierName));
        this.contractForm.controls['SupplierRepresentative'].setValue(this.checkValueNullString(data.supplierRepresentative));
        this.contractForm.controls['SupplierAddress'].setValue(this.checkValueNullString(data.supplierAddress));
        this.contractForm.controls['SupplierTax'].setValue(this.checkValueNullString(data.supplierTax));
        this.contractForm.controls['PaymentTermDetail'].setValue(this.checkValueNullString(data.paymentTermDetail));
        this.contractForm.controls['PaydateMonthly'].setValue(this.checkValueNullString(data.paydateMonthly));
        this.contractForm.controls['PaymentTermStr'].setValue(this.checkValueNullString(data.paymentTermStr));
        this.hidePaymentTerm = data.paymentTermStr == 'N/A';
        this.loadRouteApproval();
      })
    } else {
      this.contractForm.controls['AutoRenew'].setValue(false);
      this.contractForm.controls['ContractKind'].setValue("");
      this.contractForm.controls['RequestKind'].setValue("");
      this.contractForm.controls['RequestKind'].setValue("");
      this.contractForm.controls['DeptId'].setValue("");
      this.contractForm.controls['SignerCvn'].setValue("");
      this.contractForm.controls['SignerCvnInput'].setValue("");
      this.contractForm.controls['SignerSupplier'].setValue("");
      this.contractForm.controls['SignerSupplierPosition'].setValue("");
      this.contractForm.controls['SignerCvnPosition'].setValue("");
      this.contractForm.controls['SupplierName'].setValue("");
      this.contractForm.controls['SupplierRepresentative'].setValue("");
      this.contractForm.controls['SupplierAddress'].setValue("");
      this.contractForm.controls['SupplierTax'].setValue("");
      this.contractForm.controls['PaymentTermDetail'].setValue("");
      this.contractForm.controls['PaydateMonthly'].setValue("");
      this.contractForm.controls['PaymentTermStr'].setValue("Usual");
      this.hidePaymentTerm = false;
      this.loadRouteApproval();
    }
  }

  convertPaymentTerm(value) {
    return value ? 'Usual' : 'Unusual';
  }

  checkValueNullString(value) {
    return (value && value != 'null') ? value : '';
  }

  changeGrade() {
    this.getSignerList();
    this.contractForm.controls['SignerCvn'].setValue([]);
    this.contractForm.controls['SignerCvnInput'].setValue([]);
  }
  changeDepartment() {
    //console.log(this.contractForm.value.SignerDeptId)
    this.getSignerList();
    this.contractForm.controls['SignerCvn'].setValue([]);
    this.contractForm.controls['SignerCvnInput'].setValue([]);
  }
  getSignerList() {
    this.contractService.getSignerList(this.contractForm.value.SignerCvnPosition, [this.contractForm.value.SignerDeptId]).subscribe(data => {
      this.allSigner = data;
    });
  }
  removeDraftDocuments() {
    this.confirmDeleteDocs(1);//1 là draft documents
  }
  removeAttorneyDocuments() {
    this.confirmDeleteDocs(2);//2 là attorney documents
  }
  removeProposalDocuments() {
    this.confirmDeleteDocs(3);//3 là proposal documents
  }
  removeQuotationDocuments() {
    this.confirmDeleteDocs(4);//4 là quotation documents
  }
  removeSupplierDocuments() {
    this.confirmDeleteDocs(5);//5 là supplier documents
  }
  removeOtherDocuments() {
    this.confirmDeleteDocs(6);//6 là other documents
  }
  removeITDocuments() {
    this.confirmDeleteDocs(7);//7 là IT related documents
  }
  removeUrgentDocuments() {
    this.confirmDeleteDocs(8);//8 là urgent documents
  }
  removeCvnAttorneyDocuments() {
    this.confirmDeleteDocs(9);//9 là cvn attorney documents
  }
  confirmDeleteDocs(typeDoc) {
    this.contractService.removeDocuments(this.contractId, typeDoc).subscribe();
    window.location.reload();
  }
  changeRequestKind() {
    //console.log(this.contractForm.value.RequestKind)
    if (this.contractForm.value.RequestKind != 4 && this.contractForm.value.RequestKind != 3) {
      this.contractForm.controls['AppendixId'].setValue('');
    }
  }
}
