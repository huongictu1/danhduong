import { Component, OnInit } from '@angular/core';
import { contractKindDTO } from 'src/app/masters/contractkind/contract-kind.model';
import { ContractKindService } from 'src/app/masters/contractkind/contract-kind.service';
import { RequestKindService } from 'src/app/masters/requestkind/request-kind.service';
import { requestKindDTO } from 'src/app/masters/requestkind/request-kind.model';
import { DepartmentService } from 'src/app/departments/department.service';
import { Department } from 'src/app/departments/department.model';
import { MasterService } from 'src/app/masters/masters.service';
import { ActivatedRoute, Router } from '@angular/router';
import { FormBuilder, ReactiveFormsModule, FormsModule, FormControl, FormGroup, FormArray, Validators } from '@angular/forms'
import { ContractService } from '../contract.service';
import { splitLink, isDocx, isPdf, concatLink, isOffice, getImageSrc, splitPathFile } from 'src/app/utilities/utils';
import Swal from 'sweetalert2';
import { SecurityService } from 'src/app/security/security.service';

@Component({
  selector: 'app-contract-index',
  templateUrl: './contract-index.component.html',
  styleUrls: ['./contract-index.component.scss']
})
export class ContractIndexComponent implements OnInit {
  public isLoading: Boolean;
  public page = 1;
  public recordsPerPage: Number;
  public currentPage: number;
  public totalRecords: number;
  public fromRecord: number;
  public toRecord: number;
  public search: String;
  public contractKinds: contractKindDTO[];
  public requestKinds: requestKindDTO[];
  public departments: Department[];
  public statusData: any;
  public contractData: any;
  public showSearch: boolean;
  public selectedRadio: String;
  public optionSort = [
    { "id": 0, "value": "Contains with" },
    { "id": 1, "value": "Begin with" },
    { "id": -1, "value": "End with" }
  ]
  public optionUrgent = [
    { "id": 0, "value": "All" },
    { "id": 1, "value": "Normal" },
    { "id": -1, "value": "Urgent/backdate" }
  ]
  public optionAttachment = [
    { "id": 0, "value": "Contract Documents" },
    { "id": 1, "value": "Letter of Attorney" },
    { "id": 2, "value": "Approved proposal for Contract/ Appendix" },
    { "id": 3, "value": "Valid and official Quotation" },
    { "id": 4, "value": "Legal document of Supplier" },
    { "id": 5, "value": "Other document" },
    { "id": 6, "value": "IT Related attachments" },
    { "id": 7, "value": "Urgent attachments" },
    { "id": 8, "value": "Attorney Cvn attachments" },
    { "id": 9, "value": "Attorney Supplier attachments" }
  ]
  contractForm = this.fb.group({
    //contractKind: new FormControl(0),
    //requestKind: new FormControl(0),
    contractKindSelected: new FormControl(),
    requestKindSelected: new FormControl(),
    departmentSelected: new FormControl(),
    statusSelected: new FormControl(),
    deptId: new FormControl([]),
    //status: new FormControl("All"),
    contractKind: new FormControl([]),
    requestKind: new FormControl([]),
    status: new FormControl([]),
    contractNoOrderType: new FormControl(0),
    contractNo: new FormControl(""),
    applicationNoOrderType: new FormControl(0),
    applicationNo: new FormControl(""),
    contractNameOrderType: new FormControl(0),
    contractName: new FormControl(""),
    supplierNameOrderType: new FormControl(0),
    supplierName: new FormControl(""),
    attachmentNameOrderType: new FormControl(0),
    attachmentName: new FormControl(""),
    expiredDate: new FormControl(),
    contractDate: new FormControl(),
    expiredDate2: new FormControl(),
    contractDate2: new FormControl(),
    page: new FormControl(this.page),
    recordsPerPage: new FormControl(10),
    search: new FormControl(""),
    urgentType: new FormControl(0),
    contractContent: new FormControl(""),
    earlyTerminate: new FormControl(false),
    autoRenew: new FormControl(false),
    myContract: new FormControl(false),
    A: new FormControl(true),
    B: new FormControl(true),
    C: new FormControl(true),
    D: new FormControl(true),
    E: new FormControl(true),
    F: new FormControl(false),
    G: new FormControl(true),
    H: new FormControl(true),
    I: new FormControl(true),
    J: new FormControl(true),
    K: new FormControl(true),
    L: new FormControl(false),
    M: new FormControl(true),
    Q: new FormControl(true),
    R: new FormControl(false),
    S: new FormControl(false),
    T: new FormControl(false),
    U: new FormControl(false)
  });
  public searchType: string;
  constructor(
    public contractKindService: ContractKindService,
    public fb: FormBuilder,
    public requestKindService: RequestKindService,
    public departmentService: DepartmentService,
    public masterService: MasterService,
    public router: Router,
    public route: ActivatedRoute,
    public contactService: ContractService,
    public securityService: SecurityService
  ) {
  }

  ngOnInit(): void {
    this.route.paramMap
      .subscribe(params => {
        this.searchType = params.get("searchType");
        if (this.searchType == "firstCheck") {
          this.contractForm.controls['status'].setValue(["First checking"]);
        }
        else if (this.searchType == "doubleCheck") {
          this.contractForm.controls['status'].setValue(["Double checking"]);
        }
        else if (this.searchType == "finalChecked") {
          this.contractForm.controls['status'].setValue(["Final Checked"]);
        }
        else if (this.searchType == "signed") {
          this.contractForm.controls['status'].setValue(["Signed contract"]);
        }
        else if (this.searchType == "master") {
          this.contractForm.controls['status'].setValue(["Signed contract - Mastered"]);
        }
      });
    this.route.params = null;
    this.showSearch = true;
    this.isLoading = true;
    this.selectedRadio = 'new';
    this.loadContractKind();
    this.loadRequestKind();
    this.loadDepartment();
    this.loadContractStatus();
    this.page = 1;

  }

  loadContractKind() {
    this.contractKindService.getContractKindsAll().subscribe(data => {
      this.contractKinds = data;
    });;
  }

  loadRequestKind() {
    this.requestKindService.getRequestKindsAll().subscribe(data => {
      this.requestKinds = data;
    });
  }

  loadDepartment() {
    this.departmentService.getAll().subscribe(data => {
      this.departments = data;
      this.searchData(1);
    });
  }

  loadContractStatus() {
    this.masterService.getContractStatusAll().subscribe(data => {
      this.statusData = data;
    });
  }

  searchData(page) {
    //console.log("this.contractForm.value",this.contractForm.value);
    
    this.contractForm.controls['page'].setValue(page);
    this.page = page;
    this.contractData = [];
    this.contactService.getListContract(this.contractForm.value, this.selectedRadio).subscribe(data => {
      this.contractData = data;
      this.isLoading = false;
      this.totalRecords = data.totalRecords;
      this.fromRecord = data.fromRecord;
      this.toRecord = data.toRecord;
      this.currentPage = data.currentPage;
      this.recordsPerPage = data.recordPerPage;
    })
  }

  exportData(user_name) {
    Swal.fire("The system is processing, the file will be downloaded after completion", 'Notice', 'success');
    document.getElementById("modal-close1").click();
    this.contactService.exportListContract22(this.contractForm.value, user_name, this.selectedRadio).subscribe(data => {
      const contentType = 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet';
      const blob = new Blob([data], { type: contentType });

      const url = window.URL.createObjectURL(blob);
      //Open a new window to download
      var anchor = document.createElement("a");
      anchor.download = "ListContract.xlsx";
      anchor.href = url;
      anchor.click();
    })
  }
  downloadFile(data) {
    var link = document.createElement('a');
    link.href = concatLink('/common/showfile/samples/ListofContractTemp.xlsx');
    link.target = '_blank';
    link.download = "ListofContract.xlsx";
    console.log(link);
    link.click();
  }
  exportList(user_name) {
    var link = document.createElement('a');
    link.href = concatLink('/common/exportList/' + user_name);
    link.target = '_blank';
    link.download = "ListofContract.xlsx";
    console.log(link);
    link.click();
  }
  splitLink(link) {
    return splitLink(link);
  }

  concatLink(link) {
    return concatLink(link);
  }

  isDocx(fileName) {
    return isDocx(fileName);
  }

  isPdf(fileName) {
    return isPdf(fileName);
  }
  isOffice(fileName) {
    return isOffice(fileName);
  }

  pageChanged(event) {
    this.contractForm.controls['page'].setValue(event);
    this.page = event;
    this.searchData(this.page);
  }

  getImageSrc(link) {
    return getImageSrc(link);
  }

  getFilenameWithoutGuid(link) {
    var fileFullName = splitPathFile(link);
    var fileName = fileFullName[fileFullName.length - 1];
    return fileName.substring(37);
  }

  onRadioChange(event){
    const inputElement = event.target as HTMLInputElement;
    this.selectedRadio = inputElement.value;
    this.searchData(1);
  }
}
