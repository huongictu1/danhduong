import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { MasterService } from 'src/app/masters/masters.service';
import { concatLink, getImageSrc, splitPathFile } from 'src/app/utilities/utils';
import Swal from 'sweetalert2';
import { ContractService } from '../contract.service';

@Component({
  selector: 'app-contract-liquidation-detail',
  templateUrl: './contract-liquidation-detail.component.html',
  styleUrls: ['./contract-liquidation-detail.component.scss']
})
export class ContractLiquidationDetailComponent implements OnInit {

  contractDetail: any;
  contractId: string;
  canCancel: Boolean;
  reason: string;
  userApplicant: any;
  constructor(
    public contractService: ContractService,
    public route: ActivatedRoute,
    public router: Router,
    public masterService: MasterService
  ) {
      this.reason = "";
      this.contractId = this.route.snapshot.paramMap.get('contractId');
      this.getContract();
      this.canCancelLiquidation();
  }

  ngOnInit(): void {
  }

  getContract()
  {
    this.contractService.getDetailContractLiquidation(this.contractId).subscribe((data) => {
      console.log(data);
      this.contractDetail = data;
      this.loadUserApplicant(data.createdBy);
    })
  }

  cancelRequest()
  {
    this.contractService.cancelLiquidation(this.contractId).subscribe((data)=> {
      console.log("cancel",data);
      if (data.status == 200) {
        Swal.fire({
          title: 'Cancel successful!',
        }).then((result) => {
          if (result.isConfirmed) {
            this.router.navigate(['main/contract-liquidation-index']);
          }
        })
      }
    })
  }

  canCancelLiquidation()
  {
    this.contractService.canCancelLiquidation(this.contractId).subscribe((data) => {
      console.log("can cancel", data);
      this.canCancel = data;
    })
  }
  concatLink(link) {
    return concatLink(link);
  }
  getImageSrc(link) {
    return getImageSrc(link);
  }

  getFilenameWithoutGuid(link) {
    var fileFullName = splitPathFile(link);
    var fileName = fileFullName[fileFullName.length - 1];
    return fileName.substring(37);
  }

  actionRequest(action: string)
  {
    // Approval = 1
    // Reject = 0
    // Return = -1
    console.log("action", action);
    let commentType = 1;
    if (action == 'reject') {
      commentType = 0;
    }
    if (action == 'return') {
      commentType = -1;
    }
    if((action === "reject" || action === "return") && this.reason == "")
    {
      Swal.fire("Please input reason !", "Warning", "error");
    } else {
      this.actionApprove(commentType);
    }
  }
  actionApprove(commentType: Number)
  {
    // Approval = 1
    // Reject = 0
    // Return = -1
    document.getElementById("btn-close-modal").click();

    this.contractService.approveLiquidation(this.contractId, {
      commentContent: this.reason,
      commentType: commentType,
      currentOrder: this.contractDetail.currentStep
      //lay theo status_order
    }).subscribe((data) =>
      {
        if (data.status == 400) {
          Swal.fire(data.message, "Bad request", "error");
        }
        if (data.status == 200) {
          location.reload();
        }
        console.log(data);
      }, (error) => {
        Swal.fire(error.message, "Bad request", "error");
      });
  }

  loadUserApplicant(username: string) {
    this.masterService.getUserDetailByUsername(username).subscribe(data => {
      this.userApplicant = data;
    });
  }

}
