import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-contract-detail-special',
  templateUrl: './contract-detail-special.component.html',
  styleUrls: ['./contract-detail-special.component.scss']
})
export class ContractDetailSpecialComponent implements OnInit {
    constructor(
    ) {}

    ngOnInit(): void {
    }
}
