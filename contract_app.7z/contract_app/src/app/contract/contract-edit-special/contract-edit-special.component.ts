import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-contract-edit-special',
  templateUrl: './contract-edit-special.component.html',
  styleUrls: ['./contract-edit-special.component.scss']
})
export class ContractEditSpecialComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
