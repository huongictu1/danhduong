import { Component, Input, OnInit } from '@angular/core';
import { ContractKindService } from 'src/app/masters/contractkind/contract-kind.service';
import { FormBuilder } from '@angular/forms';
import { RequestKindService } from 'src/app/masters/requestkind/request-kind.service';
import { DepartmentService } from 'src/app/departments/department.service';
import { ContractService } from '../contract.service';
import { MasterService } from 'src/app/masters/masters.service';
import { ActivatedRoute, Router } from '@angular/router';
import { ContractInforView } from '../contract.models'
import { splitLink, isDocx, isPdf, isOffice, concatLink, getImageSrc, splitPathFile, replaceWhiteSpace, isExcel, isPowerpoint } from 'src/app/utilities/utils';
import Swal from 'sweetalert2';
import { SecurityService } from 'src/app/security/security.service';

@Component({
  selector: 'app-contract-detail',
  templateUrl: './contract-detail.component.html',
  styleUrls: ['./contract-detail.component.scss']
})
export class ContractDetailComponent implements OnInit {
  public contractDetail: ContractInforView;
  public userApplicant: any;
  public contractId: string;
  public isLoading: Boolean;
  public canCancel: Boolean;
  public contractFiles: string[] = [];
  public expandTable = "";
  public allDepartment: any;
  public allGrade: any;
  public grade: string;
  public department: Number[] = [];
  public allSigner: any;
  public signer: any;
  public relatedAppendix: any = [];
  public hidePaymentNA = false;
  @Input()
  isSpecial: boolean = false;
  constructor(
    public contractKindService: ContractKindService,
    public requestKindService: RequestKindService,
    public departmentService: DepartmentService,
    public contractService: ContractService,
    public masterService: MasterService,
    public fb: FormBuilder,
    public route: ActivatedRoute,
    public router: Router,
    public securityService: SecurityService
  ) {
    this.isLoading = true;
    this.contractId = this.route.snapshot.paramMap.get('contractId');
    this.getRelatedAppendix();
  }

  ngOnInit(): void {
    this.loadDetailContract();
    if (!this.isSpecial) {
      this.checkViewPermission();
    }
    this.departmentService.getAll().subscribe(data => {
      this.allDepartment = data;
      //console.log(this.allDepartment);
    })
    this.allGrade = [
      { name: "MGR" },
      { name: "GM" },
      { name: "FM" },
      { name: "GD" },
    ]
  }

  loadDetailContract() {
    if (!this.isSpecial) {
      this.contractService.getDetailContract(this.contractId).subscribe(data => {

        this.contractDetail = data;
        //console.log(this.contractDetail.createdBy)
        this.loadUserApplicant(this.contractDetail.createdBy);
        //console.log("contractDetail", data);
      });
    } else {
      this.contractService.getDetailContractTemp(this.contractId).subscribe(data => {
        this.contractDetail = data;
        //console.log(this.contractDetail.createdBy)
        this.loadUserApplicant(this.contractDetail.createdBy);
        //console.log(data);
      });
    }
    if(this.securityService.isAdmin()){
      this.canCancel = true;
    }
    else{
      this.contractService.canCancel(this.contractId).subscribe(data => {
        this.canCancel = data;
      });
    }
    
  }

  loadUserApplicant(username: string) {
    this.masterService.getUserDetailByUsername(username).subscribe(data => {
      this.userApplicant = data;
      this.isLoading = false;
    });
  }

  logData() {
    //console.log("this.contractDetail", this.contractDetail);
    // console.log("this.userApplicant",this.userApplicant);
  }

  splitLink(link) {
    return splitLink(link);
  }

  getFilenameWithoutGuid(link) {
    var fileFullName = splitPathFile(link);
    var fileName = fileFullName[fileFullName.length - 1];
    return fileName.substring(37);
  }
  replaceWs(str: string) {
    return replaceWhiteSpace(str);
  }
  isDocx(fileName) {
    return isDocx(fileName);
  }

  isPdf(fileName) {
    return isPdf(fileName);
  }
  isExcel(fileName) {
    return isExcel(fileName);
  }
  isPowerpoint(fileName) {
    return isPowerpoint(fileName);
  }
  isOffice(fileName) {
    return isOffice(fileName);
  }

  concatLink(link) {
    return concatLink(link);
  }

  getImageSrc(link) {
    return getImageSrc(link);
  }

  isSignModel() {
    return this.contractDetail.signModel && this.contractDetail.signModel.isEdit;
  }

  onContractFileSelect(event) {
    this.contractFiles = [];
    let target_file_length = event.target.files.length;
    if (target_file_length > 0) {
      for (var i = 0; i < target_file_length; i++) {
        this.contractFiles.push(event.target.files[i]);
      }
    }
  }

  onChangeHideShow() {
    if (this.expandTable == "") {
      this.expandTable = "d-none";
    } else {
      this.expandTable = "";
    }

  }

  uploadContract() {
    if (this.contractFiles.length == 0) {
      Swal.fire("Please choose file contract", "Bad request", "error");
    } else {
      let formData = new FormData();
      for (let i = 0; i < this.contractFiles.length; i++) {
        formData.append('documents', this.contractFiles[i]);
      }
      this.contractService.uploadSigned(formData, this.contractId).subscribe((data) => {
        if (data.status == 400) {
          Swal.fire(data.message, "Bad request", "error");
        } else {
          Swal.fire("Uploaded ! Please confirm information & approve it", "Notice", "success");
          window.location.reload();
        }
      });
    }
  }

  checkViewPermission() {
    if(!this.securityService.isAdmin()){
      this.contractService.checkViewPermission(this.contractId).subscribe((data) => {
        if (data.status == 400) {
          this.router.navigate(['']);
        }
      });
    }
  }

  remindNextApprover() {
    this.contractService.remindNextApprover(this.contractId).subscribe((data) => {
      if (data.status == 400) {
        //console.log(data);
      } else if (data.status == 200) {
        Swal.fire("Reminded ! " + data.message, "", "success");
      }
    });
  }
  changeGrade() {
    //console.log(this.grade);
    this.getSignerList();
    this.signer = [];
  }
  changeDepartment() {
    //console.log(this.department)
    this.getSignerList();
    this.signer = [];
  }
  getSignerList() {
    this.contractService.getSignerList(this.grade, this.department).subscribe(data => {
      //console.log(data);
      this.allSigner = data;
    })
  }

  sendInformSigner() {
    this.contractService.sendInformSigner(this.contractId, this.signer).subscribe(data => {
      //console.log(data);
      if (data.status == 200) {
        document.getElementById('modal-close').click();
        Swal.fire("Send email to signer!", "", "success");
      }
    })
  }
  shareContract() {
    this.contractService.shareContract(this.contractId, this.department).subscribe(data => {
      //console.log(data);
      if (data == 1) {
        document.getElementById('modal-close1').click();
        Swal.fire("Share contract to department!", "", "success");
      }
      else{
        Swal.fire("Error ! Unsuccessfull !", "", "error");
      }
    })
  }
  cancelRequest() {
    this.contractService.cancelRequest2(this.contractId).subscribe(data => {
      if (data.status == 400) {
        Swal.fire(data.message, "Bad request", "error");
      }
      if (data.status == 200) {
        this.router.navigate(['main']);
      }
    });
  }

  getRelatedAppendix() {
    this.contractService.getRelatedAppendix(this.contractId).subscribe(data => {
      this.relatedAppendix = data;
      // console.log("getRelatedAppendix", this.relatedAppendix);
      // console.log("getRelatedAppendix", this.relatedAppendix.length);

    })
  }

  renewContract() {
    this.contractService.renewContract(this.contractId).subscribe(data => {
      if (data.status == 400) {
        Swal.fire(data.message, "Bad request", "error");
      }
      if (data.status == 200) {
        location.reload();
      }
    });
  }
  sentOriginal() {
    this.contractService.sentOriginal(this.contractId).subscribe(data => {
      if (data.status == 400) {
        Swal.fire(data.message, "Bad request", "error");
      }
      if (data.status == 200) {
        location.reload();
      }
    });
  }
  actionForExpired(action: string) {
    this.contractService.actionForExpired(this.contractId, action).subscribe(data => {
      if (data.status == 400) {
        Swal.fire(data.message, "Bad request", "error");
      }
      if (data.status == 200) {
        if(action.includes('Early')){
          Swal.fire("Confirmed action ! Next step, submit liquidation request", "Notice", "success")
          .then((result) => {
            if (result.isConfirmed) {
              window.location.href = '#/main/contract-liquidation/' + this.contractId;
            }
          });
        }
        else if(action.includes('Renew')){
          Swal.fire("Confirmed action ! Next step, you need to issue new request", "Notice", "success")
          .then((result) => {
            if (result.isConfirmed) {
              window.location.href = '#/main/create/' + this.contractId;
            }
          });
        }
        else{
          Swal.fire("Confirmed action !", "Notice", "success");
        }
      }
    });
  }
}
