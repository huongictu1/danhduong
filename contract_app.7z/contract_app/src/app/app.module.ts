import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {HttpClientModule, HTTP_INTERCEPTORS} from '@angular/common/http';
import {SweetAlert2Module} from '@sweetalert2/ngx-sweetalert2'
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import {ReactiveFormsModule, FormsModule} from '@angular/forms'
import {MarkdownModule} from 'ngx-markdown';
import {LeafletModule} from '@asymmetrik/ngx-leaflet';
import {MaterialModule} from './material/material.module';
import { HomeComponent } from './home/home.component';
import { AuthorizeViewComponent } from './security/authorize-view/authorize-view.component';
import { LoginComponent } from './security/login/login.component';
import { AuthenticationFormComponent } from './security/authentication-form/authentication-form.component';
import { JwtInterceptorService } from './security/jwt-interceptor.service';
import { IndexUsersComponent } from './users/index-users/index-users.component';
import { NgxPaginationModule } from 'ngx-pagination';
import { ContractKindComponent } from './masters/contractkind/contract-kind/contract-kind.component';
import { NgSelectModule } from '@ng-select/ng-select';
import { ContractStatusComponent } from './masters/contractstatus/contract-status/contract-status.component';
import { FactoryComponent } from './masters/factory/factory/factory.component';
import { GroupPageComponent } from './masters/grouppage/group-page/group-page.component';
import { PageComponent } from './masters/page/page/page.component';
import { RequestKindComponent } from './masters/requestkind/request-kind/request-kind.component';
import { LogoutComponent } from './logout/logout.component';
import { ContractIndexComponent } from './contract/contract-index/contract-index.component';
import { ContractDetailComponent } from './contract/contract-detail/contract-detail.component';
import { ContractDetailStatusComponent } from './contract/contract-detail-status/contract-detail-status.component';
import { NgChartsModule } from 'ng2-charts';
import { NgxDocViewerComponent, NgxDocViewerModule } from 'ngx-doc-viewer';
import { NgxEditorModule } from 'ngx-editor';
import { CKEditorModule } from 'ckeditor4-angular';
// import { CKEditorModule } from '@ckeditor/ckeditor5-angular';
import { ForgetPasswordComponent } from './forget-password/forget-password.component';
import { ResetPasswordComponent } from './reset-password/reset-password.component';
import { ChangePasswordComponent } from './change-password/change-password.component';
import { MenuComponent } from './menu/menu.component';
import { ContractEditSpecialComponent } from './contract/contract-edit-special/contract-edit-special.component';
import { ContractDetailSpecialComponent } from './contract/contract-detail-special/contract-detail-special.component';
import { ContractIndexSpecialComponent } from './contract/contract-index-special/contract-index-special.component';
import { ContractAddEditComponent } from './contract/contract-add-edit/contract-add-edit.component';
import { ContractAddComponent } from './contract/contract-add/contract-add.component';
import { ContractEditComponent } from './contract/contract-edit/contract-edit.component';
import { ContractAddSpecialComponent } from './contract/contract-add-special/contract-add-special.component';
import { ContractDetailNormalComponent } from './contract/contract-detail-normal/contract-detail-normal.component';
import { Ng2SearchPipeModule } from 'ng2-search-filter';
import { ReferenceComponent } from './masters/reference/reference.component';
import { DictionaryComponent } from './masters/dictionary/dictionary.component';
import { HelpReferenceComponent } from './help/help-reference/help-reference.component';
import { HelpDictionaryComponent } from './help/help-dictionary/help-dictionary.component';
import { LoginSsoComponent } from './login-sso/login-sso.component';
import { SsologinComponent } from './security/ssologin/ssologin.component';
import { ContractLiquidationComponent } from './contract/contract-liquidation/contract-liquidation.component';
import { ContractLiquidationIndexComponent } from './contract/contract-liquidation-index/contract-liquidation-index.component';
import { ContractLiquidationDetailComponent } from './contract/contract-liquidation-detail/contract-liquidation-detail.component';
import { CreateUsersComponent } from './users/create-users/create-users.component';
import { DashboardComponent } from './home/dashboard/dashboard.component';
import { ElasticComponent } from './home/elastic/elastic.component';
import { ElasticScrollComponent } from './home/elastic-scroll/elastic-scroll.component';
import { ChatRoomComponent } from './home/chat-room/chat-room.component';
import { KibanaViewComponent } from './home/kibana-view/kibana-view.component';
import { CorsInterceptor } from './cors.interceptor';
import { SummaryDashboardComponent } from './home/summary-dashboard/summary-dashboard.component';
import { HelpPostComponent } from './help/help-post/help-post.component';
import { PortalSiteComponent } from './help/portal-site/portal-site.component';
import { CiceForumComponent } from './help/cice-forum/cice-forum.component';
import { ForumDetailComponent } from './help/cice-forum/forum-detail/forum-detail.component';
// import {TourNgxBootstrapModule} from '@ngx-tour/ngx-bootstrap';
// import { NgxbTourService, TourNgxBootstrapModule } from 'ngx-tour-ngx-bootstrap'
import { TutorialComponent } from './help/tutorial/tutorial.component'; 
@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    AuthorizeViewComponent,
    LoginComponent,
    AuthenticationFormComponent,
    IndexUsersComponent,
    ContractKindComponent,
    ContractStatusComponent,
    FactoryComponent,
    GroupPageComponent,
    PageComponent,
    RequestKindComponent,
    IndexUsersComponent,
    LogoutComponent,
    ContractIndexComponent,
    ContractDetailComponent,
    ContractDetailStatusComponent,
    ForgetPasswordComponent,
    ResetPasswordComponent,
    ChangePasswordComponent,
    MenuComponent,
    ContractEditSpecialComponent,
    ContractDetailSpecialComponent,
    ContractIndexSpecialComponent,
    ContractAddEditComponent,
    ContractAddComponent,
    ContractEditComponent,
    ContractAddSpecialComponent,
    ContractDetailNormalComponent,
    ReferenceComponent,
    DictionaryComponent,
    HelpReferenceComponent,
    HelpDictionaryComponent,
    LoginSsoComponent,
    SsologinComponent,
    ContractLiquidationComponent,
    ContractLiquidationIndexComponent,
    ContractLiquidationDetailComponent,
    CreateUsersComponent,
    DashboardComponent,
    ElasticComponent,
    ElasticScrollComponent,
    ChatRoomComponent,
    KibanaViewComponent,
    SummaryDashboardComponent,
    HelpPostComponent,
    PortalSiteComponent,
    CiceForumComponent,
    ForumDetailComponent,
    TutorialComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    BrowserAnimationsModule,
    // MaterialModule,
    ReactiveFormsModule,
    FormsModule,
    LeafletModule,
    HttpClientModule,
    MarkdownModule.forRoot(),
    SweetAlert2Module.forRoot(),
    NgxPaginationModule,
    NgSelectModule,
    NgChartsModule,
    //NgxDocViewerModule,
    //NgxEditorModule,
    Ng2SearchPipeModule,
    CKEditorModule,
    // TourNgxBootstrapModule.forRoot()
    
  ],
  providers: [{
    provide: HTTP_INTERCEPTORS,
    useClass: JwtInterceptorService,
    multi: true
  }],
  bootstrap: [AppComponent]
})
export class AppModule { }
