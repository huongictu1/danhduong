import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { BehaviorSubject, Observable } from 'rxjs';
import { environment } from 'src/environments/environment';
@Injectable({
  providedIn: 'root'
})
export class ElasticService {
  private apiUrl = environment.apiURL + '/elastic'
  private scrollId: string | null = null
  private dataSubject = new BehaviorSubject<any[]>([]);
  public data$ = this.dataSubject.asObservable();
  constructor(private http: HttpClient) { }
  fetchData(pageSize: number = 10){
    let url = `${this.apiUrl}/elastic-scroll-contract?phase=bên`
    // if(this.scrollId){
    //   url = `${this.apiUrl}/elastic-scroll-contract?phase=bên`
    // }
    this.http.get<any>(url).subscribe((data) => {
      if(data && data.lenth > 0){
        const currentData = this.dataSubject.getValue()
        this.dataSubject.next([...currentData, ...data])
        // this.scrollId = data[data.lenth - 1]._scroll_id
      }
    })
  }

  getUrl(content): any{
    return this.http.get<any>(`${this.apiUrl}/elastic-get-iframe?content=${content}`);
  }
  getContent(url: string): Observable<string>{
    const headers = new HttpHeaders({
      'Content-Type': 'application/json',
      'Access-Control-Allow-Origin': 'http://cvn-datalake01:5601' // Replace '*' with the appropriate origin or remove this line if not needed
    });
    return this.http.get(url, {headers, responseType: 'text'});
  }
}
