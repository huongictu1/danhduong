import { Component, OnInit, ElementRef, ViewChild } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { ElasticService } from '../elastic.service';
import { SecurityService } from 'src/app/security/security.service';
import { DomSanitizer } from '@angular/platform-browser';

@Component({
  selector: 'app-kibana-view',
  templateUrl: './kibana-view.component.html',
  styleUrls: ['./kibana-view.component.scss']
})
export class KibanaViewComponent implements OnInit {
  content: string;
  constructor(public service: ElasticService, public secu: SecurityService, private route: ActivatedRoute, private sanitizer: DomSanitizer){}
  ngOnInit() {
    // this.route.paramMap.subscribe(params => {
    //   const url = "http://cvn-datalake01:5601/s/la/app/dashboards?auth_provider_hint=viewer#/view/40001070-d4d3-4760-94be-4007d6f9437a?_g=(refreshInterval:(pause:!t,value:60000),time:(from:now-15m,to:now))&_a=()"
    //   if(url){
    //     this.loadContent(url);
    //   }
    // });
    this.checkBrowser();
  }
  checkBrowser(){
    if(navigator.userAgent.indexOf('Firefox') === -1){
      alert('This feature is recommended for FireFox. Some functionalities may not work as expected on your current browser.')
      location.href = '#'
    }
  }
  loadContent(url: string){
    this.service.getContent(url).subscribe(res => {
      this.content = res;
    })
  }
  getSafeUrl(){
    var url = 'http://cvn-datalake01:5601/app/dashboards?auth_provider_hint=viewer#/view/ada9b1e0-eb4e-11ee-9c28-6d4a1e41afa3?_g=(refreshInterval:(pause:!f,value:10000),time:(from:now%2Fd%2B8h,to:now))&_a=(controlGroupInput:(chainingSystem:HIERARCHICAL,controlStyle:oneLine,ignoreParentSettings:(ignoreFilters:!f,ignoreQuery:!f,ignoreTimerange:!f,ignoreValidations:!f),panels:(\'0d5b4617-c195-487b-a4b3-61789283193f\':(explicitInput:(dataViewId:e5eca300-77b3-4a21-8277-3b9ca47537b6,enhancements:(),fieldName:fields.processing_time,grow:!f,id:\'0d5b4617-c195-487b-a4b3-61789283193f\',title:\'Processing%20Time\',width:small),grow:!f,order:6,type:rangeSliderControl,width:medium),\'110821a8-eccd-4ec0-b321-7856a95ca660\':(explicitInput:(dataViewId:e5eca300-77b3-4a21-8277-3b9ca47537b6,enhancements:(),existsSelected:!f,fieldName:fields.application.keyword,grow:!t,id:\'110821a8-eccd-4ec0-b321-7856a95ca660\',selectedOptions:!(Contract),title:Application,width:small),grow:!f,order:0,type:optionsListControl,width:small),\'24d70c88-ece5-439b-99b7-ba47421dbc4a\':(explicitInput:(dataViewId:e5eca300-77b3-4a21-8277-3b9ca47537b6,enhancements:(),existsSelected:!f,fieldName:fields.window_user.keyword,grow:!f,id:\'24d70c88-ece5-439b-99b7-ba47421dbc4a\',selectedOptions:!(),title:\'User%20Name\',width:small),grow:!f,order:2,type:optionsListControl,width:small),\'570016e2-a7b3-43f5-a6fb-1923cdd0479c\':(explicitInput:(dataViewId:e5eca300-77b3-4a21-8277-3b9ca47537b6,enhancements:(),fieldName:fields.message.keyword,grow:!t,id:\'570016e2-a7b3-43f5-a6fb-1923cdd0479c\',searchTechnique:wildcard,title:Message,width:medium),grow:!t,order:7,type:optionsListControl,width:medium),\'58452664-ef3f-4a42-aa6b-023b9b700e4d\':(explicitInput:(dataViewId:e5eca300-77b3-4a21-8277-3b9ca47537b6,enhancements:(),fieldName:fields.machine.keyword,grow:!f,id:\'58452664-ef3f-4a42-aa6b-023b9b700e4d\',searchTechnique:wildcard,title:\'PC%20Name\',width:small),grow:!f,order:5,type:optionsListControl,width:small),c5032c58-57e9-4743-a42a-1ed1b6f3e914:(explicitInput:(dataViewId:e5eca300-77b3-4a21-8277-3b9ca47537b6,enhancements:(),fieldName:level.keyword,grow:!f,id:c5032c58-57e9-4743-a42a-1ed1b6f3e914,selectedOptions:!(),title:\'Log%20Level\',width:small),grow:!f,order:1,type:optionsListControl,width:small),d32bd304-11a1-4f0b-8b3d-325321b49c91:(explicitInput:(dataViewId:e5eca300-77b3-4a21-8277-3b9ca47537b6,enhancements:(),fieldName:fields.controller.keyword,grow:!f,id:d32bd304-11a1-4f0b-8b3d-325321b49c91,title:Function,width:small),grow:!f,order:3,type:optionsListControl,width:small),da976d4d-55ef-4153-9e63-674e44d906b2:(explicitInput:(dataViewId:e5eca300-77b3-4a21-8277-3b9ca47537b6,enhancements:(),fieldName:fields.action_name.keyword,grow:!f,id:da976d4d-55ef-4153-9e63-674e44d906b2,searchTechnique:wildcard,selectedOptions:!(),title:Action,width:small),grow:!f,order:4,type:optionsListControl,width:small))))';
    return this.sanitizer.bypassSecurityTrustResourceUrl(url);
  }
  // getUrl(){
  //   this.service.getUrl("Visualization").subscribe(data => {
  //     this.url = data.message;
  //     console.log(this.url)
  //   })
  // }
}
