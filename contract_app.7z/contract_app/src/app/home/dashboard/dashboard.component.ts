import { Component, OnInit, ViewChild } from '@angular/core';
import DatalabelsPlugin from 'chartjs-plugin-datalabels';
import { Chart, ChartConfiguration, ChartData, ChartType } from 'chart.js';
import { BaseChartDirective } from 'ng2-charts';
import { HomeService } from 'src/app/home/home.service';
import { capitalizeFirstLetter } from 'src/app/utilities/utils';
import Swal from 'sweetalert2';
import { DepartmentService } from 'src/app/departments/department.service';
import { ContractService } from 'src/app/contract/contract.service';
import { UserService } from 'src/app/users/user.service';
import { SecurityService } from 'src/app/security/security.service';
import { environment } from 'src/environments/environment';
import { HttpClient } from '@angular/common/http';
import { Color } from 'chartjs-plugin-datalabels/types/options';
@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.scss']
})
export class DashboardComponent implements OnInit {
  isLoading: Boolean = true;
  data: any;
  public employee_code: string;

  url = environment.uRL;
  ngOnInit() {
    this.getData();
  }

  constructor(
    public homeService: HomeService,
    public departmentService: DepartmentService,
    public contractService: ContractService,
    public userService: UserService,
    public securityService: SecurityService,
    private http: HttpClient
  ) {
    this.isLoading = false;
  }
  @ViewChild(BaseChartDirective) chart: BaseChartDirective | undefined;

  public deptChartData: ChartData<'doughnut', number[], string | string[]> = {
    labels: [],
    datasets: [{
      data: []
    }],
  };
  public statusChartData: ChartData<'doughnut', number[], string | string[]> = {
    labels: [],
    datasets: [{
      data: []
    }],
  };
  public requestChartData: ChartData<'doughnut', number[], string | string[]> = {
    labels: [],
    datasets: [{
      data: []
    }],
  };
  public contractChartData: ChartData<'doughnut', number[], string | string[]> = {
    labels: [],
    datasets: [{
      data: []
    }],
  };
  public monthChartData: ChartData<'bar', number[], string | string[]> = {
    labels: [],
    datasets: [{
      data: []
    }],
  };
  public pieChartType: ChartType = 'pie';
  public barChartType: ChartType = 'bar';
  public pieChartPlugins = [DatalabelsPlugin];
  lendata: any = '';
  getData() {
    this.isLoading = true;
    // this.homeService.viewLens1().subscribe(data => {
    //   this.lendata = data;
    // });
    this.homeService.analysisElastic().subscribe(data => {
      for(var i = 0; i < data.length; i ++){
        if(data[i].target == 'Department'){
          this.deptChartData = {
            labels: data[i].lstResult.map(x => x.value),
            datasets: [{
              data: data[i].lstResult.map(x => x.quantity)
            }],
          };
        }
        else if(data[i].target == 'Status'){
          this.statusChartData = {
            labels: data[i].lstResult.map(x => x.value),
            datasets: [{
              data: data[i].lstResult.map(x => x.quantity)
            }],
          };
        }
        else if(data[i].target == 'Request Kind'){
          this.requestChartData = {
            labels: data[i].lstResult.map(x => x.value),
            datasets: [{
              data: data[i].lstResult.map(x => x.quantity)
            }],
          };
        }
        else if(data[i].target == 'Contract Kind'){
          this.contractChartData = {
            labels: data[i].lstResult.map(x => x.value),
            datasets: [{
              data: data[i].lstResult.map(x => x.quantity)
            }],
          };
        }
      }
      this.isLoading = false;
    });
    this.homeService.dateElastic().subscribe(data => {
      for(var i = 0; i < data.length; i ++){
        this.monthChartData = {
          labels: data.map(x => x.value),
          datasets: [
            {
              label: 'Expired Qty',
              data: data.map(x => x.expiredQty),
            },
            {
              label: 'Issued Qty',
              data: data.map(x => x.issueQty),
            },
            {
              label: 'Effective Qty',
              data: data.map(x => x.effectQty),
            }
            ],
        };
      }
      this.isLoading = false;
    });
  }
}
