import { Component, OnInit } from '@angular/core';
import { SignalrService } from 'src/app/security/signalr.service';
import { environment } from 'src/environments/environment';
import { HttpClient } from '@angular/common/http';
import { SecurityService } from 'src/app/security/security.service';
@Component({
  selector: 'app-chat-room',
  templateUrl: './chat-room.component.html',
  styleUrls: ['./chat-room.component.scss']
})
export class ChatRoomComponent implements OnInit {

  constructor(public realtime: SignalrService, private http: HttpClient,public security: SecurityService) { }
  url = environment.uRL;
  newMessage: ''
  messages: any[]
  fullName = this.security.getFieldFromJWT('full_name');
  ngOnInit(): void {
    this.realtime.addTransferDataListener(); 
    this.realtime.addBroadcastDataListener(); 
    this.startHttpRequest();
    this.realtime.addUserOnlineListener();
  }
  private startHttpRequest = () => {
    this.http.get(this.url + 'api/realtime')
      .subscribe(res => {
        //console.log(res);
      })
  }
  sendMessage(){
    this.realtime.broadcastData("<span class='text-danger text-bold'>" + this.fullName + '</span>: ' + this.newMessage);
    this.newMessage = '';
  }
}
