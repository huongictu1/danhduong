import { Component, OnInit } from '@angular/core';
import { ElasticService } from '../elastic.service';

@Component({
  selector: 'app-elastic-scroll',
  templateUrl: './elastic-scroll.component.html',
  styleUrls: ['./elastic-scroll.component.scss']
})
export class ElasticScrollComponent implements OnInit {

  constructor(public service: ElasticService) { }

  ngOnInit(): void {
    this.service.fetchData();
  }
  loadMore(){
    this.service.fetchData();
  }
}
