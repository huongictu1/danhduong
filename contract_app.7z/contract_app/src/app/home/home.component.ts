import { Component, OnInit, ViewChild } from '@angular/core';
import DatalabelsPlugin from 'chartjs-plugin-datalabels';
import { ChartData, ChartOptions, ChartType } from 'chart.js';
import { BaseChartDirective } from 'ng2-charts';
import { HomeService } from './home.service';
import { capitalizeFirstLetter } from '../utilities/utils';
import Swal from 'sweetalert2';
import { DepartmentService } from '../departments/department.service';
import { ContractService } from '../contract/contract.service';
import { UserService } from '../users/user.service';
import { SecurityService } from 'src/app/security/security.service';
import { environment } from 'src/environments/environment';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css'],
})
export class HomeComponent implements OnInit {
  isLoading: Boolean = true;
  summaryData: number[] = [];
  labelData: string[] = [];
  title1: string;
  expiredcontract: any;
  listNoticeLiquidation: any;
  widgetSummaryByYear: any;
  listNotification: any;
  listNotification2: any;
  listNotification3: any;
  listNotification4: any;
  totalExpired: any;
  listExpired: any;
  listWillExpired: any;
  listWillExpiredRenew: any;
  listFinalChecked: any;
  listDeadline: any;
  totalUser: any;
  totalMaster: any;
  data: any;
  filterTerm_listExpired!: string;
  filterTerm_listWillExpired!: string;
  filterTerm_listWillExpiredRenew!: string;
  filterTerm_listFinalChecked!: string;
  filterTerm_listDeadline!: string;
  filterTerm_listNotification!: string;
  filterTerm_listNotification2!: string;
  filterTerm_listNotification3!: string;
  filterTerm_listNotification4!: string;
  filterTerm_listNoticeLiquidation!: string;
  public allDepartment: any;
  public allGrade: any;
  public grade: string;
  public department: Number[] = [];
  public allSigner: any[] = [];
  public signer: any[] = [];
  public contractId: string;
  public employee_code: string;

  url = environment.uRL;
  ngOnInit() {
    this.allGrade = [
      { name: "MGR" },
      { name: "GM" },
      { name: "FM" },
      { name: "GD" },
    ];
  }
  constructor(
    public homeService: HomeService,
    public departmentService: DepartmentService,
    public contractService: ContractService,
    public userService: UserService,
    public securityService: SecurityService,
    private http: HttpClient
  ) {
    this.isLoading = true;
    this.getWidgetSummaryData();
    this.getData();
    this.title1 = "Summary chart";
    this.isLoading = false;
  }
  private startHttpRequest = () => {
    this.http.get(this.url + 'api/realtime')
      .subscribe(res => {
        console.log(res);
      })
  }

  @ViewChild(BaseChartDirective) chart: BaseChartDirective | undefined;

  public pieChartData: ChartData<'doughnut', number[], string | string[]> = {
    labels: [],
    datasets: [{
      data: []
    }],
  };
  public pieChartType: ChartType = 'doughnut';
  public pieChartPlugins = [DatalabelsPlugin];
  // events
  public chartClicked({ event, active }: { event: MouseEvent, active: {}[] }): void {
    //console.log(event, active);
  }

  public chartHovered({ event, active }: { event: MouseEvent, active: {}[] }): void {
    //console.log('chart hovered');
    //this.signalrService.broadcastData();
  }
  getWidgetSummaryData() {
    this.homeService.getWidgetSummary().subscribe(data => {
      for (const property in data.data) {
        // if(property == 'expired'){
        //   this.summaryData.push(data.data[property]);
        //   this.labelData.push('Expired');
        // }
        
        
        
        if(property == 'firstCheck'){
          this.summaryData.push(data.data[property]);
          this.labelData.push('FirstCheck');
        }
        else if(property == 'doubleCheck'){
          this.summaryData.push(data.data[property]);
          this.labelData.push('DoubleCheck');
        }
        else if(property == 'finalChecked'){
          this.summaryData.push(data.data[property]);
          this.labelData.push('FinalChecked');
        }
        else if(property == 'signed'){
          this.summaryData.push(data.data[property]);
          this.labelData.push('Signed');
        }
        else if(property == 'master'){
          this.summaryData.push(data.data[property]);
          this.labelData.push('Master');
        }
      }

      // console.log("this.labelData", this.labelData);
      // console.log("this.this.summaryData", this.summaryData);
      this.pieChartData =
      {
        labels: this.labelData,
        datasets: [{
          data: this.summaryData,
          backgroundColor: ['#36a2eb','#ff6384','#ffcd56','#0dcaf0','#4bc0c0'],
          borderColor: ['#36a2eb','#ff6384','#ffcd56','#0dcaf0','#4bc0c0']
        }],
      };
      this.isLoading = false;
    });
  }

  getData() {
    this.homeService.listNoticeLiquidation().subscribe(data => {
      //console.log("listNoticeLiquidation", data);
      this.listNoticeLiquidation = data;
    });
    this.homeService.listNotification().subscribe(data => {
      this.listNotification = data;
    });
    this.homeService.listNotification2().subscribe(data => {
      this.listNotification2 = data;
    });
    this.homeService.listNotification3().subscribe(data => {
      // this.listNotification3 = data.filter(x => x.title == 'Special waiting');
      this.listNotification4 = data.filter(x => x.title == 'Signed waiting');
    });
    // this.homeService.getTotalExpired().subscribe(data => {
    //   this.totalExpired = data;
    // });
    this.homeService.getListWillExpired().subscribe(data => {
      this.listWillExpired = data;
    });
    // this.homeService.getListWillExpiredRenew().subscribe(data => {
    //   this.listWillExpiredRenew = data;
    // });
    this.homeService.getListFinalChecked().subscribe(data => {
      this.listFinalChecked = data;
    });
    this.homeService.getListDeadline().subscribe(data => {
      this.listDeadline = data;
    });
    this.homeService.getTotalMaster().subscribe(data => {
      this.totalMaster = data;
    });
    this.homeService.getTotalUser().subscribe(data => {
      this.totalUser = data;
    });
  }
  remindExpired(contractId: string) {
    this.homeService.remindExpired(contractId).subscribe(data => {
      if (data.status == 400) {
        Swal.fire(data.message, "Bad request", "error");
      }
      if (data.status == 200) {
        Swal.fire(data.message, "Notice", "success");
      }
    });
  }

  changeGrade() {
    //console.log(this.grade);
    this.getSignerList();
    this.signer = [];
  }
  changeDepartment() {
    //console.log(this.department)
    this.getSignerList();
    this.signer = [];
  }
  getSignerList() {
    this.contractService.getSignerList(this.grade, this.department).subscribe(data => {
      //console.log(data);
      this.allSigner = data;
    })
  }

  sendRemind() {
    //console.log('this.signer', this.signer);
    this.contractService.remindExpired(this.contractId, this.signer).subscribe(data => {
      //console.log("send remind", data);
      if (data.status == 200) {
        document.getElementById('modal-close').click();
        Swal.fire("Send email remind!", "", "success");
        this.homeService.getListWillExpired().subscribe(data => {
          this.listWillExpired = data;
        });
      }
    })
  }
  sendRemindUpload() {
    //console.log('this.signer', this.signer);
    this.contractService.remindUploadScan(this.contractId, this.signer).subscribe(data => {
      //console.log("send remind", data);
      if (data.status == 200) {
        document.getElementById('modal-close1').click();
        Swal.fire("Send email remind!", "", "success");
        this.homeService.getListFinalChecked().subscribe(data => {
          this.listFinalChecked = data;
        });
      }
    })
  }
  getRelatedDept(contactId: string) {
    //console.log("this.contractId", contactId);
    this.contractId = contactId;
    // this.department = [];
    // this.signer = [];
    // this.departmentService.getRelatedDept(contactId).subscribe(data => {
    //   this.allDepartment = data;
    //   console.log("this.allDepartment",this.allDepartment);
    // })
  }
  openListContract(event: any){
    var type1 = event.active[0].index;
    if(type1 == 0){
      window.location.href = "#/maino/firstCheck";
    }
    else if(type1 == 1){
      window.location.href = "#/maino/doubleCheck";
    }
    else if(type1 == 2){
      window.location.href = "#/maino/finalChecked";
    }
    else if(type1 == 3){
      window.location.href = "#/maino/signed";
    }
    else if(type1 == 4){
      window.location.href = "#/maino/master";
    }
    //window.location.href = "#/maino/:searchType";
  }
  onKeyUp(e) {
    if (e.key === 'Enter' || e.keyCode === 13) {
      this.searchUser(this.employee_code);
    }
  }

  searchUser(employee: string) {
    this.userService.getAll(1, 15, employee).subscribe(data => {
      let containEmployee = this.allSigner.findIndex((value, index, array) => {
        return (array[index].userName == employee);
      })
      if (containEmployee == -1) {
        this.allSigner = [...this.allSigner, {
          id: data.lstModel[0].id,
          fullName: data.lstModel[0].fullName,
          userName: data.lstModel[0].userName,
          grade: data.lstModel[0].grade
        }];
      }
      this.signer = [...this.signer, data.lstModel[0].id];
    })
  }
  addNote(id:string, noteType: string, event: any){
    this.homeService.noteContract(id, noteType, event).subscribe(data => {
      Swal.fire(data.message, "", "success");
    })
  }

  
}
