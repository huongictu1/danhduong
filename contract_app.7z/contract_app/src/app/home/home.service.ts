import { Injectable } from '@angular/core';
import { environment } from 'src/environments/environment';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
@Injectable({
  providedIn: 'root'
})
export class HomeService {

  constructor(private http: HttpClient) { }

  private apiURL = environment.apiURL + '/home'
  private apiURL2 = environment.apiURL + '/contract'
  private apiURL3 = environment.apiURL + '/accounts'

  getWidgetSummary(): any{
    return this.http.get<any>(`${this.apiURL}/getWidgetSummary`);
  }
  expiredcontract(): any{
    return this.http.get<any>(`${this.apiURL}/expiredcontract`);
  }
  getWidgetSummaryByYear(): any{
    return this.http.get<any>(`${this.apiURL}/getWidgetSummaryByYear`);
  }
  listNotification(): any{
    return this.http.get<any>(`${this.apiURL}/listNotification`);
  }
  listNotification2(): any{
    return this.http.get<any>(`${this.apiURL}/listWaitingSign`);
  }
  listNotification3(): any{
    return this.http.get<any>(`${this.apiURL}/listWaitingSign2`);
  }
  listNotification4(): any{
    return this.http.get<any>(`${this.apiURL}/listWaitingSign3`);
  }
  getTotalExpired(): any{
    return this.http.get<any>(`${this.apiURL}/getTotalExpired`);
  }
  getListExpired(): any{
    return this.http.get<any>(`${this.apiURL}/getListExpired`);
  }
  getListWillExpired(): any{
    return this.http.get<any>(`${this.apiURL}/getWillExpired`);
  }
  getListWillExpiredRenew(): any{
    return this.http.get<any>(`${this.apiURL}/getWillExpiredRenew`);
  }
  getListFinalChecked(): any{
    return this.http.get<any>(`${this.apiURL}/getFinalChecked`);
  }
  getListDeadline(): any{
    return this.http.get<any>(`${this.apiURL}/getListDeadline`);
  }
  getTotalUser(): any{
    return this.http.get<any>(`${this.apiURL}/getTotalUser`);
  }
  getTotalMaster(): any{
    return this.http.get<any>(`${this.apiURL}/getTotalMaster`);
  }
  remindExpired(contractId: string)
  {
    return this.http.get<any>(`${this.apiURL2}/remindExpired?contractId=`+contractId);
  }
  listNoticeLiquidation()
  {
    return this.http.get<any>(`${this.apiURL}/listNoticeLiquidation`);
  }
  noteContract(contractId: string, noteType: string, content: string): Observable<any>
  {
    return this.http.get<any>(`${this.apiURL2}/noteContract?contractId=`+contractId+`&noteType=${noteType}&content=${content}`);
  }
  getDashboardData()
  {
    return this.http.get<any>(`${this.apiURL}/getDashboardData`);
  }

  searchElastic(phase: any): any{
    return this.http.get<any>(`${this.apiURL3}/elastic-search-contract?phase=${phase}`);
  }
  analysisElastic(): any{
    return this.http.get<any>(`${this.apiURL3}/elastic-analysis-contract`);
  }
  dateElastic(): any{
    return this.http.get<any>(`${this.apiURL3}/elastic-date-contract`);
  }
  loginKibana(): any{
    return this.http.get<any>(`http://elastic:Smf$iot23@cts-vsmf02:5601`);
  }
  viewLens1(): any{
    return this.http.get<any>(`http://cts-vsmf02:5601/app/dashboards?auth_provider_hint=viewer#/view/12107eb0-85c0-11ee-bb9b-018e52d6a23d?embed=true&_g=(refreshInterval:(pause:!t,value:10000),time:(from:now-8h,to:now))&_a=()&hide-filter-bar=true`);
  }
  
}
