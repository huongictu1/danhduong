import { Component, OnInit, ViewChild } from '@angular/core';
import { Chart, ChartData, ChartOptions, ChartType } from 'chart.js';
import DatalabelsPlugin from 'chartjs-plugin-datalabels';
import { BaseChartDirective } from 'ng2-charts';
import { environment } from 'src/environments/environment';
import { HttpClient } from '@angular/common/http';
import { Color } from 'chartjs-plugin-datalabels/types/options';
import { HomeService } from '../home.service';
import 'chartjs-plugin-datalabels';
@Component({
  selector: 'app-summary-dashboard',
  templateUrl: './summary-dashboard.component.html',
  styleUrls: ['./summary-dashboard.component.scss']
})
export class SummaryDashboardComponent implements OnInit {
  isLoading: Boolean = true;
  public total = 0;
  public checking = 0;
  public cost = 0;
  public pending = 0;
  public expired = 0;
  public lblStatus: any = [];
  public lblKind: any = [];
  public lblRequest: any = [];
  public valStatus: any = [];
  public valKind: any = [];
  public valRequest: any = [];
  public lstTermEx: any = [];
  public lstTermEf: any = [];
  
  constructor(public home: HomeService) { this.isLoading = false;}

  ngOnInit(): void {
    this.isLoading = true;
    this.home.getDashboardData().subscribe(data => {
       this.total = data.total;
       this.checking = data.checking;
       this.cost = data.cost;
       this.expired = data.expired;
       this.pending = data.pending;
       this.lblStatus = data.lstLblStatus;
       this.lblKind = data.lstLblKind;
       this.lblRequest = data.lstLblRequest;
       this.valStatus = data.lstValStatus;
       this.valKind = data.lstValKind;
       this.valRequest = data.lstValRequest;
       this.lstTermEx = data.lstTermEx;
       this.lstTermEf = data.lstTermEf;

       this.initEffectChart();
       this.initProcessChart();
       this.initTypeChart();
       this.initRequestChart();
       this.isLoading = false;
    });
    
  }
  @ViewChild(BaseChartDirective) chart: BaseChartDirective | undefined;
  public effectChartData: ChartData<'bar', number[], string | string[]> = {
    labels: [],
    datasets: [{
      data: []
    }]
  };
  public processData: ChartData<'doughnut', number[], string | string[]> = {
    labels: [],
    datasets: [{
      data: []
    }]
  };
  public typeData: ChartData<'doughnut', number[], string | string[]> = {
    labels: [],
    datasets: [{
      data: []
    }],
  };
  public requestData: ChartData<'doughnut', number[], string | string[]> = {
    labels: [],
    datasets: [{
      data: []
    }]
  };
  initEffectChart() {

    const labels = ['Short term', 'Mid term', 'Long term'];
    this.effectChartData = {
      labels: labels,
      datasets: [
        {
          label: 'Expired',
          data: this.lstTermEx,
          backgroundColor: '#E74C3C',
          maxBarThickness: 30,
        },
        {
          label: 'Effective',
          data: this.lstTermEf,
          backgroundColor: '#27AE60',
          maxBarThickness: 30,
        }
      ]
    };
    this.effectiveChart = new Chart('canvas1', {
      type: 'bar',
      data: this.effectChartData,
      options: {
        indexAxis: 'y',
        plugins: {
          title: {
            display: true,
            text: 'Effective Contract Status'
          },
        },
        //responsive: true,
        scales: {
          x: {
            stacked: true,
          },
          y: {
            stacked: true,
          }
        }
      }
    });
  }
  initProcessChart() {

    const labels = this.lblStatus;
    this.processData = {
      labels: labels,
      datasets: [
        {
          label: 'Contract Qty',
          data: this.valStatus,
          backgroundColor: ['#F39C12','#3498DB','#7F8C8D']
        }
      ],
      
    };
    this.processChart = new Chart('canvas2', {
      type: 'doughnut',
      data: this.processData,
      options: {
        responsive: true,
        plugins: {
          legend: {
            position: 'top',
            display: false
          },
          title: {
            display: true,
            text: 'Checking status'
          },
          datalabels: {
            formatter: (value, ctx) => {
              const label = ctx.chart.data.labels[ctx.dataIndex];
              return label + ': ' + value;
            },
          },
        }
      }
    });
  }
  initTypeChart() {

    const labels = this.lblKind;
    this.typeData = {
      labels: labels,
      datasets: [
        {
          label: 'Contract Qty',
          data: this.valKind,
          backgroundColor: ['#3498DB','#E74C3C','#27AE60','#F39C12','#D35400','#8E44AD','#16A085','#7F8C8D'],
        }
      ]
    };
    this.typeChart = new Chart('canvas3', {
      type: 'doughnut',
      data: this.typeData,
      options: {
        responsive: true,
        plugins: {
          legend: {
            position: 'top',
            display: false
          },
          title: {
            display: true,
            text: 'Contract qty by category'
          }
        }
      }
    });
  }
  initRequestChart() {
    const labels = this.lblRequest;
    this.requestData = {
      labels: labels,
      datasets: [
        {
          label: 'Contract Qty',
          data: this.valRequest,
          backgroundColor: ['#3498DB','#F39C12','#27AE60', '#7F8C8D'],
        }
      ]
    };
    this.requestChart = new Chart('canvas4', {
      type: 'doughnut',
      data: this.requestData,
      options: {
        responsive: true,
        plugins: {
          legend: {
            position: 'top',
            display: false
          },
          title: {
            display: true,
            text: 'Contract qty by request'
          },
          datalabels: {
            display: true,
            formatter: (value, ctx) => {
              const label = ctx.chart.data.labels[ctx.dataIndex];
              return label + ': ' + value;
            },
          },
        }
      }
    });
  }
  public effectiveChart: any = [];
  public processChart: any = [];
  public typeChart: any = [];
  public requestChart: any = [];
  public ChartPlugin = [DatalabelsPlugin]
  viewTotal(){
    location.href = '#/main';
  }
  viewChecking(){
    location.href = '#/maino/other';
  }
  viewExpired(){
    location.href = '#/maino/expired';
  }
  viewHome(){
    location.href = '#/home';
  }
}
