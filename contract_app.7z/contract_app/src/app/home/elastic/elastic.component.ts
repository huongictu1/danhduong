import { Component, OnInit, ViewChild } from '@angular/core';
import DatalabelsPlugin from 'chartjs-plugin-datalabels';
import { Chart, ChartConfiguration, ChartData, ChartType } from 'chart.js';
import { BaseChartDirective } from 'ng2-charts';
import { HomeService } from '../home.service';
import Swal from 'sweetalert2';
import { SecurityService } from 'src/app/security/security.service';
import { environment } from 'src/environments/environment';
import { HttpClient } from '@angular/common/http';
import { Color } from 'chartjs-plugin-datalabels/types/options';
import { splitLink, isDocx, isPdf, isOffice, concatLink, getImageSrc, splitPathFile, replaceWhiteSpace, isExcel, isPowerpoint } from 'src/app/utilities/utils';

@Component({
  selector: 'app-elastic',
  templateUrl: './elastic.component.html',
  styleUrls: ['./elastic.component.scss']
})
export class ElasticComponent implements OnInit {

  constructor(public service: HomeService, public sec: SecurityService) { }
  searchVal: string;
  results: any;
  loading: boolean;
  ngOnInit(): void {
    this.searchVal = "";
    this.results = null;
    this.loading = false;
  }
  searchEngine(){
    if(this.searchVal == null || this.searchVal == ''){
      
    }
    else{
      this.loading = true;
      this.service.searchElastic(this.searchVal).subscribe(x=>{
        this.results = x;
        this.loading = false;
      });
    }
    
  }
  getFilenameWithoutGuid(link) {
    var fileFullName = splitPathFile(link);
    var fileName = fileFullName[fileFullName.length - 1];
    return fileName.substring(37);
  }
}
