import { Component, OnInit } from '@angular/core';
import { AbstractControl, FormBuilder, FormGroup, ValidationErrors, ValidatorFn, Validators } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';
import Swal from 'sweetalert2';
import { SecurityService } from '../security/security.service';

@Component({
  selector: 'app-reset-password',
  templateUrl: './reset-password.component.html',
  styleUrls: ['./reset-password.component.scss']
})
export class ResetPasswordComponent implements OnInit {

  constructor(
    public securityService: SecurityService,
    public router: Router,
    public route: ActivatedRoute,
    private formBuilder: FormBuilder
  ) { }
  form: FormGroup;
  token: string;
  username: string;
  isLoading: Boolean;
  ngOnInit(): void {
    this.token = this.route.snapshot.paramMap.get('token');
    this.username = this.route.snapshot.paramMap.get('username');
    this.isLoading = false;
    this.form = this.formBuilder.group({
      password: ['', {
        validators: [Validators.required]
      }],
      confirmPassword: ['', {
        validators: [Validators.required]
      }]
    }, { validators: this.checkPasswords });
  }

  onSubmit()
  {
    this.securityService.resetPassword({
      'token': this.token,
      'password': this.form.value.password,
    }).subscribe(data => {
      if(data.status == 200) {
        Swal.fire('Reset password successful', '', 'success')
        this.router.navigateByUrl('login');
      } else if (data.status == 400){
        Swal.fire('Reset password fail', data.message, 'warning')
      }
    })
  }

  checkPasswords: ValidatorFn = (group: AbstractControl):  ValidationErrors | null => {
    let pass = group.get('password').value;
    let confirmPass = group.get('confirmPassword').value
    return pass === confirmPass ? null : { notSame: true }
  }

}
