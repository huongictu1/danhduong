import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import Swal from 'sweetalert2';
import { Router } from '@angular/router';
import { SecurityService } from '../security.service';

@Component({
  selector: 'app-ssologin',
  templateUrl: './ssologin.component.html',
  styleUrls: ['./ssologin.component.scss']
})
export class SsologinComponent implements OnInit {
  constructor(public securityService: SecurityService, public router: Router,
    public route: ActivatedRoute) {
    // this.route.paramMap.subscribe(params => {
    //   this.uname = params.get('uname');
    //   this.sid = params.get('sid');
    // })
    this.uname = this.route.snapshot.paramMap.get('uname');
    this.sid = this.route.snapshot.paramMap.get('sid');
    this.execute();
  }

  uname: any;
  sid: any;

  ngOnInit(): void {
    // this.execute();
  }
  // public uname: string;
  // public sid: string;
  // constructor(
  //   public securityService: SecurityService,
  //   public router: Router,
  //   public route: ActivatedRoute,
  // ) {

  // }

  // ngOnInit(): void {
  //   this.route.paramMap
  //     .subscribe(params => {
  //       this.uname = params.get("uname");
  //       this.sid = params.get("sid");
  //     }
  //   );
  //   this.securityService.clearToken();
  //   this.execute();
  // }
  execute() {
    this.securityService.clearToken();
    this.securityService.loginSso(this.uname, this.sid).subscribe(data => {
      // console.log(data);
      this.securityService.saveToken(data);
      var tk = this.securityService.getToken();
      if (tk != null && tk != '') {
        this.router.navigate(["/"]);
      }
      else {
        this.execute();
      }
    });
  }
}
