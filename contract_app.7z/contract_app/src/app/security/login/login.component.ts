import { Component, OnDestroy, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { SecurityService } from '../security.service';
import { ActivatedRoute } from '@angular/router';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import Swal from 'sweetalert2';
import { SignalrService } from '../signalr.service';
@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css'],
})
export class LoginComponent implements OnInit, OnDestroy {
  constructor(
    public securityService: SecurityService,
    public router: Router,
    public route: ActivatedRoute,
    private formBuilder: FormBuilder
  ) {
    let params = this.route.snapshot.queryParams;
    if (params['redirectURL']) {
      this.redirectURL = params['redirectURL'];
    }
  }
  redirectURL: any;
  form: FormGroup;
  isLoading: Boolean;
  ssoLink = '';
  ngOnDestroy(): void {
    document.body.classList.remove('bg-img');
  }
  ngOnInit(): void {
    document.body.classList.add('bg-img');



    this.form = this.formBuilder.group({
      username: ['', {
        validators: [Validators.required]
      }],
      password: ['', {
        validators: [Validators.required]
      }],
      remember: [
        false
      ]
    });
    this.isLoading = false;
    this.securityService.checkAuthSso().subscribe(res => {
      this.ssoLink = res.message;
    });
  }

  login() {
    this.isLoading = true;
    var vm = this;
    this.securityService
      .login(this.form.value)
      .subscribe((authenticationResponse) => {
        this.securityService.saveToken(authenticationResponse);
        if (this.redirectURL) {
          this.router.navigate([this.redirectURL]);
        } else {
          if (this.form.value.password == 'User@2021' || this.form.value.password == 'v' + this.form.value.username) {
            Swal.fire("Login success !", "Please change password when using default password", "success");
            this.router.navigate(["changePassword"]);
          } else {
            window.location.reload();
          }
        }
      }, function (error) {
        vm.isLoading = false;
        Swal.fire("Login failed ! " + error, "Bad request", "error");
      });
  }
}
