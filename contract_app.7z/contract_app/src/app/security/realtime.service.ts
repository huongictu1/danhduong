import { Injectable } from '@angular/core';
import { HubConnection, HubConnectionBuilder } from '@aspnet/signalr';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class RealtimeService1 {
  private hubConnection: HubConnection;
  private url = environment.uRL;
  constructor() {
    // this.buildConnection();
    // this.startConnection();
  }

  // private buildConnection() {
  //   this.hubConnection = new HubConnectionBuilder()
  //     .withUrl(this.url + 'realtime')
  //     .build();
  // }

  // private startConnection() {
  //   this.hubConnection
  //     .start()
  //     .then(() => console.log('Connection started'))
  //     .catch(err => console.log('Error while starting connection: ' + err));
  // }

  // receiveMessage() {
  //   return this.hubConnection.on('ReceiveMessage', (data: any) => {
  //     console.log(data);
  //   });
  // }
}
