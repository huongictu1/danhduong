export interface userCredentials{
    username: string;
    password: string;
    remember: Boolean
}
export interface userCredentialsSso{
    uname: string;
    sid: string;
}

export interface authenticationResponse{
    token: string;
    expiration: Date;
    role: string;
    user_name: string;
}

export interface userDTO{
    id: string;
    username: string;
}
