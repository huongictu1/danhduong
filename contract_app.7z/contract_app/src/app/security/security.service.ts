import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { EventEmitter, Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';
import { authenticationResponse, userCredentials, userDTO , userCredentialsSso} from './security.models';
import { Router } from '@angular/router';
import { SignalrService } from './signalr.service';

@Injectable({
  providedIn: 'root'
})
export class SecurityService {

  constructor(private http: HttpClient,private router: Router, private signalrService: SignalrService) { }

  private apiURL = environment.apiURL + "/accounts";

  private apiHome = environment.apiURL + "/home";
  private apiEmail = environment.apiURL + "/email";

  private readonly tokenKey: string = 'token';
  private readonly expirationTokenKey: string = 'token-expiration'
  private readonly roleField = "role";
  private readonly usernameField = "user_name";
  private readonly gradeField = "gradesys";

  getUsers(page: number, recordsPerPage: number): Observable<any>{
    let params = new HttpParams();
    return this.http.get<userDTO[]>(`${this.apiURL}/listusers`,{observe: 'response', params});
  }
  getListNotification() {
    return this.http.get<any>(`${this.apiHome}/listNotification`);
  }

  makeAdmin(userId: string){
    const headers = new HttpHeaders('Content-Type: application/json');
    return this.http.post(`${this.apiURL}/makeadmin`, JSON.stringify(userId), {headers});
  }

  removeAdmin(userId: string){
    const headers = new HttpHeaders('Content-Type: application/json');
    return this.http.post(`${this.apiURL}/removeadmin`, JSON.stringify(userId), {headers});
  }

  isAuthenticated(): boolean{
    const token = localStorage.getItem(this.tokenKey);

    if (!token){
      return false;
    }

    const expiration = localStorage.getItem(this.expirationTokenKey);
    const expirationDate = new Date(expiration);

    if (expirationDate <= new Date()){
      this.logout();
      return false;
    }

    return true;
  }

  getFieldFromJWT(field: string): string {
    const token = localStorage.getItem(this.tokenKey);
    if (!token){return '';}
    const base64Url = token.split('.')[1];
    const base64 = base64Url.replace(/-/g,'+').replace(/_/g,'/');
    const jsonPayload = decodeURIComponent(atob(base64).split('').map(function(c){
      return '%' + ('00' + c.charCodeAt(0).toString(16)).slice(-2);
    }).join(''));
    const decodedToken = JSON.parse(jsonPayload);
    return decodedToken[field];
  }
  logout(){
    this.clearToken();
    this.router.navigate(['/login']);
  }
  clearToken(){
    localStorage.removeItem(this.tokenKey);
    localStorage.removeItem(this.expirationTokenKey);
    //this.signalrService.userOnline();
  }
  getRole(): string {
    return this.getFieldFromJWT(this.roleField);
  }
  getGrade(): string {
    return this.getFieldFromJWT(this.gradeField);
  }
  getUsername(): string {
    return this.getFieldFromJWT(this.usernameField);
  }
  register(userCredentials: userCredentials): Observable<authenticationResponse>{
    return this.http.post<authenticationResponse>(this.apiURL + "/create", userCredentials);
  }

  login(userCredentials: userCredentials): Observable<authenticationResponse>{
    return this.http.post<authenticationResponse>(this.apiURL + "/login", userCredentials);
  }

  loginSso(userName: any, sid:any) {
    var link = this.apiURL + "/loginsso/" + userName + "/" + sid;
    return this.http.get<any>(link.replace("/undefined", ""));
  }
  checkAuthSso() {
    var link = this.apiURL + "/checkAuthSso";
    return this.http.get<any>(link.replace("/undefined", ""));
  }
  saveToken(authenticationResponse: authenticationResponse){
    localStorage.setItem(this.tokenKey, authenticationResponse.token);
    localStorage.setItem(this.roleField, authenticationResponse.role);
    localStorage.setItem(this.usernameField, authenticationResponse.user_name);
    localStorage.setItem(this.expirationTokenKey, authenticationResponse.expiration.toString());
    //this.signalrService.userOnline();
  }

  getToken(){
    return localStorage.getItem(this.tokenKey);
  }

  isAdmin()
  {
    return (this.getRole() == 'la-admin');
  }

  forgetPassword(username: string)
  {
    return this.http.get<any>(this.apiURL + "/forgot-password?username="+username);
  }
  changePassword(changePasswordDTO: any)
  {
    return this.http.post<any>(this.apiURL + "/change-password", changePasswordDTO);
  }

  resetPassword(changePasswordDTO: any)
  {
    return this.http.post<any>(this.apiURL + "/reset-password", changePasswordDTO);
  }
  downloadFile(url){
    this.http.get(url, { responseType: 'blob' }).subscribe((response: Blob) => {
      const fileURL = URL.createObjectURL(response);
      window.open(fileURL);
    });
  }
}
