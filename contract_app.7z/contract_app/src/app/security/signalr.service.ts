import { Injectable } from '@angular/core';
import * as signalR from "@microsoft/signalr";
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class SignalrService {
  public data: string;
  public url = environment.uRL;
  public clientId: string;
  private hubConnection: signalR.HubConnection
  constructor(){
    this.hubConnection = new signalR.HubConnectionBuilder()
      .withUrl(this.url + 'realtime')
      .build();
        this.hubConnection.start()
      .then(() => {
        console.log('Connection started');
        this.clientId = this.hubConnection.connectionId;
      })
      .catch(err => console.log('Error while starting connection: ' + err))
  } 
  // public disconnect(id) {
  //   this.hubConnection.send("Disconnect", id)
  //     .then(() => {
  //       this.hubConnection.stop();
  //     });
  // }
  // public connect(username) {
  //   this.hubConnection.send("Connect", username)
  //     .then(() => {
  //       this.hubConnection.start();
  //     });
  // }
  public addTransferDataListener = () => {
    this.hubConnection.on('transferdata', (data) => {
      this.data = data;
      //console.log(data);
    });
  }
  public broadcastData(dt: any){
    this.hubConnection.invoke('broadcastdata', dt)
      .catch(err => console.error(err));
  }
  public userOnline = () => {
    this.hubConnection.invoke('useronline')
      .catch(err => console.error(err));
  }
  public bradcastedData: string = '';
  public addBroadcastDataListener = () => {
    this.hubConnection.on('broadcastdata', (dt1) => {
      this.bradcastedData += '\n' + dt1;
      //console.log(this.bradcastedData);
    })
  }
  public countUserOnline: string;
  public addUserOnlineListener = () => {
    this.hubConnection.on('useronline', (data) => {
      this.countUserOnline = data;
      //console.log(this.countUserOnline);
    })
  }
}