import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, Validators } from '@angular/forms';
import { DepartmentService } from 'src/app/departments/department.service';
import { GroupService } from 'src/app/groups/group.service';
import Swal from 'sweetalert2';
import { UserService } from '../user.service';

@Component({
  selector: 'app-create-users',
  templateUrl: './create-users.component.html',
  styleUrls: ['./create-users.component.scss']
})
export class CreateUsersComponent implements OnInit {

  constructor(
    public departmentService: DepartmentService,
    public fb: FormBuilder,
    public groupService: GroupService,
    public userService: UserService
    ) {

  }
  filterGroups: any;
  userForm = this.fb.group({
    userName: new FormControl('', [Validators.required]),
    fullName: new FormControl('', [Validators.required]),
    email: new FormControl('', [Validators.required]),
    lstIdDept: new FormControl([], [Validators.required]),
    lstIdGroup: new FormControl([], [Validators.required]),
    gender: new FormControl('', [Validators.required]),
    grade: new FormControl('', [Validators.required]),
  });
  grade: any;
  department: any;
  selectedDepartment: any;
  ngOnInit(): void {
    this.departmentService.getAll().subscribe(data => {
      this.department = data;
      console.log("department", this.department);
    })

    this.groupService.getAll().subscribe(groups => {
      this.filterGroups = groups;
      console.log(this.filterGroups)
    });
  }

  onSubmit()
  {
    console.log("valid", this.userForm.valid)
    console.log(this.userForm.value)
    this.userService.saveUser(this.userForm.value).subscribe((data) => {
      console.log("Save user", data)
      if (data.error) {
        Swal.fire(data.message, '', 'error')
      } else {
        Swal.fire(data.message, '', 'success')
      }
    })
  }

}
