import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';
import { userDTO } from './user.model';

@Injectable({
  providedIn: 'root'
})
export class UserService {

  constructor(private http: HttpClient) { }

  private apiURL = environment.apiURL + '/master'

  getAll(page = 1, recordPerPage = 15, search = ""){
    return this.http.post<any>(`${this.apiURL}/listusers`, {
      "page": page,
      "recordsPerPage": recordPerPage,
      "search": search
    });
  }

  updateUser(idUser: Number, lstIdDept: any, lstIdGroup: any, grade: string)
  {
    return this.http.put<any>(`${this.apiURL}/user-groupdept/` + idUser, {
      "lstIdDept": lstIdDept,
      "lstIdGroup": lstIdGroup,
      "grade": grade
    });
  }

  changeUserStatus(idUser: Number)
  {
    return this.http.put<any>(`${this.apiURL}/user-status?id=` + idUser, {
      
    });
  }
  saveUser(userInfo: any)
  {
    return this.http.post<any>(`${this.apiURL}/add-user`, userInfo);
  }
}
