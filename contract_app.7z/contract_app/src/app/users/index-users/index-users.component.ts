import { Component, OnInit } from '@angular/core';
import { userDTO } from '../user.model';
import { UserService } from '../user.service';
import { DepartmentService } from 'src/app/departments/department.service';
import { Department } from 'src/app/departments/department.model';
import { GroupService } from 'src/app/groups/group.service';
import { Observable, Subject } from 'rxjs';
import { WebSocketSubject, webSocket } from 'rxjs/webSocket';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-index-users',
  templateUrl: './index-users.component.html',
  styleUrls: ['./index-users.component.css']
})
export class IndexUsersComponent implements OnInit {

  isLoading: Boolean;
  users: userDTO[];
  user_edit: any;
  departments: Department[];
  filterDepartments: Department[];
  filterGroups: Department[];
  selectedDepartment: any;
  grade: string;
  selectedGroup: any;
  groups: any;
  recordPerPage = 15;
  totalPage = 0;
  totalRecords = 0;
  page = 1;
  search = "";
  fromRecord = 0;
  toRecord = 0;

  constructor(
    public usersService: UserService,
    public departmentService: DepartmentService,
    public groupService: GroupService
  ) {
    this.loadDepartment();
    this.isLoading = true;
  }
  ngOnInit(): void {
    
  }

  loadUsers(page = 1, recordPerPage = 15, search = "") {
    this.isLoading = true;
    this.usersService.getAll(page, recordPerPage, search).subscribe(data => {
      this.users = data.lstModel;
      this.totalPage = data.totalPage;
      this.totalRecords = data.totalRecords;
      this.fromRecord = data.fromRecord;
      this.toRecord = data.toRecord;
      //console.log('this.users', this.users);
      this.isLoading = false;
    });
  }

  pageChanged(event) {
    this.page = event;
    this.loadUsers(event, this.recordPerPage, this.search);
  }

  searchChange() {
    this.users = [];
    this.loadUsers(1, this.recordPerPage, this.search);
    this.page = 1;
  }
  onKeyUp(e) {
    if (e.key === 'Enter' || e.keyCode === 13) {
      this.users = [];
      this.loadUsers(1, this.recordPerPage, this.search);
    }
  }
  loadDepartment() {
    this.departmentService.getAllByKey().subscribe(departments => {
      this.departments = departments;
      this.loadGroups();
    })
    this.departmentService.getAll().subscribe(departments => {
      this.filterDepartments = departments;
    })
  }
  loadGroups() {
    this.groupService.getAllByKey().subscribe(groups => {
      this.groups = groups;
      //console.log(this.groups);
      this.loadUsers();
    });
    this.groupService.getAll().subscribe(groups => {
      this.filterGroups = groups;
    });
  }

  load_modal(user) {
    this.user_edit = user;
    this.selectedDepartment = user.deptId;
    this.selectedGroup = user.groupId[0];
    this.grade = user.gradeSys;
    // console.log(this.selectedDepartment);
    // console.log(this.selectedGroup);
    //console.log("user_id", user.id);
  }



  updateUser() {
    this.updateUserAction(this.user_edit.id, this.selectedDepartment, [this.selectedGroup], this.grade);
    document.getElementById("btn-close-modal").click();
    this.searchChange();
  }
  changeUserStatus(user) {
    this.usersService.changeUserStatus(user.id).subscribe(data => {
      this.loadUsers(this.page, this.recordPerPage, this.search);
    });
  }
  updateUserAction(idUser, lstIdDept, lstIdGroup, grade) {
    this.usersService.updateUser(idUser, lstIdDept, lstIdGroup, grade).subscribe(data => {
      this.loadUsers(this.page, this.recordPerPage, this.search);
    });
  }
}
