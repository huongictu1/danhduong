export interface userDTO {
    id: number;
    userName: string;
    fullName: string;
    email: string;
    gender: string;
    department: string;
    grade: any;
    group: string;
    deptId: any;
    groupId: any;
    active: Boolean;
    gradeSys: string;
}

export interface userUpdateDTO {
    idUser: number;
    lstIdDept: Number[];
    lstIdGroup: Number[];
}