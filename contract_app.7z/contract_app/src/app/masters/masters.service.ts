import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class MasterService {

  constructor(private http: HttpClient) { }

  private apiURL = environment.apiURL + '/master'

  getFindApprover(grade: Number, deptId: Number){
    return this.http.get<any>(this.apiURL + '/find-approver?grade='+grade+'&deptId='+deptId);
  }

  getUserDetailByUsername(username: string){
    return this.http.get<any>(this.apiURL + '/user-detail-by-username?username='+username);
  }

  getContractStatus() {
    return this.http.get<string>(`${this.apiURL}/contract-status`);
  }

  getContractStatusAll() {
    return this.http.get<string>(`${this.apiURL}/contract-status-by-all`);
  }
}
