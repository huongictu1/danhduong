export interface pageDTO{
    id: number;
    pageName: string;
    pageLink: string;
    pageClass: string;
    pageAlias: string;
    active: Boolean;
    pageOrder: number;
}