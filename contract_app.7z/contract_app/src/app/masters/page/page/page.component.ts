import { Component, OnInit } from '@angular/core';
import { pageDTO } from '../page.model';
import { PageService } from '../page.service';

@Component({
  selector: 'app-page',
  templateUrl: './page.component.html',
  styleUrls: ['./page.component.css']
})
export class PageComponent implements OnInit {

  pages: pageDTO[];
  headers = ['ID', 'Full name', 'Short name', 'Active'];
  constructor(private pageService: PageService) { }
  ngOnInit(): void {
   this.loadPages();
  }
  loadPages(){
    this.pageService.getPages().subscribe(data => {
      this.pages = data;
    });
  }
}
