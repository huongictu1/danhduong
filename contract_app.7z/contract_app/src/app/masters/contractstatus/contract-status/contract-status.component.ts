import { Component, OnInit } from '@angular/core';
import { contractStatusDTO } from '../contract-status.model';
import { ContractStatusService } from '../contract-status.service';

@Component({
  selector: 'app-contract-status',
  templateUrl: './contract-status.component.html',
  styleUrls: ['./contract-status.component.css']
})
export class ContractStatusComponent implements OnInit {

  contractStatus: contractStatusDTO[];
  headers = ['ID', 'Full name', 'Short name', 'Active'];
  constructor(private masterService: ContractStatusService) { }
  ngOnInit(): void {
   this.loadContractStatus();
  }
  loadContractStatus(){
    this.masterService.getContractStatuses().subscribe(data => {
      this.contractStatus = data;
    });
  }
  changeContractStatusStatus(ck) {
    this.masterService.changeContractStatusStatus(ck.id).subscribe(data => {
      this.loadContractStatus();
    });
  }
}
