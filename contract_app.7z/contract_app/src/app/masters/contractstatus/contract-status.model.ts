export interface contractStatusDTO{
    id: number;
    statusOrder: number;
    statusName: string;
    active: Boolean;
}