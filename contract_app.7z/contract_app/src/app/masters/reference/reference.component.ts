import { Component, OnInit } from '@angular/core';
import { ReferenceService } from './reference.service';
import Swal from 'sweetalert2';
import { splitLink , isDocx, isPdf, concatLink, isOffice, getImageSrc, splitPathFile} from 'src/app/utilities/utils';


@Component({
  selector: 'app-reference',
  templateUrl: './reference.component.html',
  styleUrls: ['./reference.component.scss']
})
export class ReferenceComponent implements OnInit {
  references: any[];
  public docName: string;
  public docVersion: string;
  public docAuthor: string;
  public document: string[] = [];

  public id2: string;
  public docName2: string;
  public docVersion2: string;
  public docAuthor2: string;
  public document2: string[] = [];

  constructor(private masterService: ReferenceService) { }

  ngOnInit(): void {
    this.loadReferences();
  }
  loadReferences(){
    this.masterService.getReferences().subscribe(data => {
      this.references = data;
    });
  }
  changeReferenceStatus(ck) {
    this.masterService.changeReferenceStatus(ck.id).subscribe(data => {
      this.loadReferences();
    });
  }
  concatLink(link){
    return concatLink(splitLink(link)[0]);
  }
  splitLink(link){
    return splitLink(link)[0];
  }
  getFilenameWithoutGuid(link) {
    var fileFullName = splitPathFile(link);
    var fileName = fileFullName[fileFullName.length - 1];
    return fileName.substring(37);
  }
  onDocumentSelect(event) {
    this.document = [];
    let target_file_length = event.target.files.length;
    if (target_file_length > 0) {
      for (var i = 0; i < event.target.files.length; i++) {
        this.document.push(event.target.files[i]);
      }
    }
  }
  onDocumentSelect2(event) {
    this.document2 = [];
    let target_file_length = event.target.files.length;
    if (target_file_length > 0) {
      for (var i = 0; i < event.target.files.length; i++) {
        this.document2.push(event.target.files[i]);
      }
    }
  }
  onFormSubmit()
  {
    
    this.references = null;
    if (this.docName && this.docVersion && this.docAuthor) {
      let formData = new FormData();
      formData.append('docName', this.docName);
      formData.append('docVersion', this.docVersion);
      formData.append('docAuthor', this.docAuthor);
      formData.append('document', this.document[0]);
      this.masterService.addDocument(formData).subscribe(data => {
        
        if (data == 1) {
          this.loadReferences();
          document.getElementById('btn-close-modal3').click();
        }
        else if (data != 1) {
          Swal.fire(data.message, "Bad request", "error");
        }
      })
    } else {
      Swal.fire("Require name, file, version & author !", "Warning", "warning");
    }
  }
  onFormSave()
  {
    
    this.references = null;
    if (this.docName2 && this.docVersion2 && this.docAuthor2) {
      let formData = new FormData();
      formData.append('docName', this.docName2);
      formData.append('docVersion', this.docVersion2);
      formData.append('docAuthor', this.docAuthor2);
      formData.append('document', this.document2[0]);
      this.masterService.saveDocument(this.id2, formData).subscribe(data => {
        if (data == 1) {
          this.loadReferences();
          document.getElementById('btn-close-modal4').click();
        }
        else if (data != 1) {
          Swal.fire(data.message, "Bad request", "error");
        }
      })
    } else {
      Swal.fire("Require name, file, version & author !", "Warning", "warning");
    }
  }
  editDocument(id)
  {
    
    this.masterService.detailDocument(id).subscribe(data => {
      console.log(data);
        this.id2 = id;
        this.docAuthor2 = data.docAuthor;
        this.docVersion2 = data.docVersion;
        this.docName2 = data.docName;
    })
  }
}
