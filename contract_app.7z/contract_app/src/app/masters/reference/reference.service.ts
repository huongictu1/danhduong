import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class ReferenceService {

  constructor(private http: HttpClient) { }

  private apiURL = environment.apiURL + '/master'

  getReferences(){
    return this.http.get<any>(this.apiURL + '/help-documents');
  }

  changeReferenceStatus(id: string)
  {
    return this.http.put<any>(`${this.apiURL}/active-help-document?id=` + id, {
      
    });
  }

  addDocument(params) {
    return this.http.post<any>(`${this.apiURL}/add-help-document`, params);
  }

  detailDocument(id) {
    return this.http.get<any>(`${this.apiURL}/detail-help-document?id=`+id);
  }
  saveDocument(id: string, params: any)
  {
    return this.http.put<any>(`${this.apiURL}/edit-help-document?id=` + id, params);
  }
}
