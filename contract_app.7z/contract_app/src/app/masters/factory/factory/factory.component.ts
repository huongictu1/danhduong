import { Component, OnInit } from '@angular/core';
import { factoryDTO } from '../factory.model';
import { FactoryService } from '../factory.service';

@Component({
  selector: 'app-factory',
  templateUrl: './factory.component.html',
  styleUrls: ['./factory.component.css']
})
export class FactoryComponent implements OnInit {

  factory: factoryDTO[];
  headers = ['ID', 'Fact ID', 'Full name', 'Short name', 'Active'];
  constructor(private factoryService: FactoryService) { }
  ngOnInit(): void {
   this.loadFactory();
  }
  loadFactory(){
    this.factoryService.getFactories().subscribe(data => {
      this.factory = data;
    });
  }
  changeFactoryStatus(ck) {
    this.factoryService.changeFactoryStatus(ck.id).subscribe(data => {
      this.loadFactory();
    });
  }
}
