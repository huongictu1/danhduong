export interface factoryDTO {
    id: number;
    factId: number;
    factFullName: string;
    factShortName: string;
    active: Boolean;
}