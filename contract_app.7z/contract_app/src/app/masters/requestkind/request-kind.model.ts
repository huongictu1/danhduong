export interface requestKindDTO{
    id: number;
    requestFullType: string;
    requestShortType: string;
    active: Boolean;
}