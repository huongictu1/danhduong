import { Component, OnInit } from '@angular/core';
import { requestKindDTO } from '../request-kind.model';
import { RequestKindService } from '../request-kind.service';

@Component({
  selector: 'app-request-kind',
  templateUrl: './request-kind.component.html',
  styleUrls: ['./request-kind.component.css']
})
export class RequestKindComponent implements OnInit {

  requestKind: requestKindDTO[];
  headers = ['ID', 'Full name', 'Short name', 'Active'];
  constructor(private requestKindService: RequestKindService) { }
  ngOnInit(): void {
   this.loadRequestKind();
  }
  loadRequestKind(){
    this.requestKindService.getRequestKinds().subscribe(data => {
      this.requestKind = data;
    });
  }
  changeRequestKindStatus(ck) {
    this.requestKindService.changeRequestKindStatus(ck.id).subscribe(data => {
      this.loadRequestKind();
    });
  }
}
