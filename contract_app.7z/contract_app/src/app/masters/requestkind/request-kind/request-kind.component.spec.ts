import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RequestKindComponent } from './request-kind.component';

describe('RequestKindComponent', () => {
  let component: RequestKindComponent;
  let fixture: ComponentFixture<RequestKindComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ RequestKindComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(RequestKindComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
