import { Component, OnInit } from '@angular/core';
import { DictionaryService } from './dictionary.service';
import Swal from 'sweetalert2';
import { splitLink , isDocx, isPdf, concatLink, isOffice, getImageSrc, splitPathFile} from 'src/app/utilities/utils';


@Component({
  selector: 'app-dictionary',
  templateUrl: './dictionary.component.html',
  styleUrls: ['./dictionary.component.scss']
})
export class DictionaryComponent implements OnInit {
  dictionaries: any[];
  public dicPhrase: string;
  public dicEnglish: string;
  public dicVietnamese: string;
  public dicExplanation: string;

  public id2: string;
  public dicPhrase2: string;
  public dicEnglish2: string;
  public dicVietnamese2: string;
  public dicExplanation2: string;
  constructor(private masterService: DictionaryService) { }

  ngOnInit(): void {
    this.loadDictionaries();
  }
  loadDictionaries(){
    this.masterService.getDictionaries().subscribe(data => {
      this.dictionaries = data;
    });
  }
  changeDictionaryStatus(ck) {
    this.masterService.changeDictionaryStatus(ck.id).subscribe(data => {
      this.loadDictionaries();
    });
  }
  concatLink(link){
    return concatLink(splitLink(link)[0]);
  }
  splitLink(link){
    return splitLink(link)[0];
  }
  getFilenameWithoutGuid(link) {
    var fileFullName = splitPathFile(link);
    var fileName = fileFullName[fileFullName.length - 1];
    return fileName.substring(37);
  }
  onFormSubmit()
  {
    
    this.dictionaries = null;
    if (this.dicPhrase && this.dicEnglish && this.dicVietnamese) {
      let formData = new FormData();
      formData.append('dicPhrase', this.dicPhrase);
      formData.append('dicEnglish', this.dicEnglish);
      formData.append('dicVietnamese', this.dicVietnamese);
      formData.append('dicExplanation', this.dicExplanation);
      this.masterService.addDictionary(formData).subscribe(data => {
        
        if (data == 1) {
          this.loadDictionaries();
          document.getElementById('btn-close-modal3').click();
        }
        else if (data != 1) {
          Swal.fire(data.message, "Bad request", "error");
        }
      })
    } else {
      Swal.fire("Require phrase, English, Vietnamese explanation !", "Warning", "warning");
    }
  }
  onFormSave()
  {
    
    this.dictionaries = null;
    if (this.dicPhrase2 && this.dicEnglish2 && this.dicVietnamese2) {
      let formData = new FormData();
      formData.append('dicPhrase', this.dicPhrase2);
      formData.append('dicEnglish', this.dicEnglish2);
      formData.append('dicVietnamese', this.dicVietnamese2);
      formData.append('dicExplanation', this.dicExplanation2);
      this.masterService.saveDictionary(this.id2, formData).subscribe(data => {
        if (data == 1) {
          this.loadDictionaries();
          document.getElementById('btn-close-modal4').click();
        }
        else if (data != 1) {
          Swal.fire(data.message, "Bad request", "error");
        }
      })
    } else {
      Swal.fire("Require phrase, English, Vietnamese explanation !", "Warning", "warning");
    }
  }
  editDictionary(id)
  {
    
    this.masterService.detailDictionary(id).subscribe(data => {
      console.log(data);
        this.id2 = id;
        this.dicPhrase2 = data.dicPhrase;
        this.dicEnglish2 = data.dicEnglish;
        this.dicVietnamese2 = data.dicVietnamese;
        this.dicExplanation2 = data.dicExplanation;
    })
  }
}
