import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class DictionaryService {

  constructor(private http: HttpClient) { }

  private apiURL = environment.apiURL + '/master'

  getDictionaries(){
    return this.http.get<any>(this.apiURL + '/help-dictionaries');
  }

  changeDictionaryStatus(id: string)
  {
    return this.http.put<any>(`${this.apiURL}/active-help-dictionary?id=` + id, {
      
    });
  }
  addDictionary(params) {
    return this.http.post<any>(`${this.apiURL}/add-help-dictionary`, params);
  }

  detailDictionary(id) {
    return this.http.get<any>(`${this.apiURL}/detail-help-dictionary?id=`+id);
  }
  saveDictionary(id: string, params: any)
  {
    return this.http.put<any>(`${this.apiURL}/edit-help-dictionary?id=` + id, params);
  }
}
