import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class ContractKindService {

  constructor(private http: HttpClient) { }

  private apiURL = environment.apiURL + '/master'

  getContractKinds(){
    return this.http.get<any>(this.apiURL + '/contract-kind');
  }

  getContractKindsAll(){
    return this.http.get<any>(this.apiURL + '/contract-kind-by-all');
  }

  changeContractKindStatus(id: Number)
  {
    return this.http.put<any>(`${this.apiURL}/contractkind-status?id=` + id, {
      
    });
  }
}
