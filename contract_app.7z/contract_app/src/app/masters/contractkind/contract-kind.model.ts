export interface contractKindDTO{
    id: number;
    kindFullName: string;
    kindShortName: string;
    active: Boolean;
}