import { Component, OnInit } from '@angular/core';
import { contractKindDTO } from '../contract-kind.model';
import { ContractKindService } from '../contract-kind.service';

@Component({
  selector: 'app-contract-kind',
  templateUrl: './contract-kind.component.html',
  styleUrls: ['./contract-kind.component.css']
})
export class ContractKindComponent implements OnInit {

  contractKind: contractKindDTO[];
  headers = ['ID', 'Full name', 'Short name', 'Active'];
  constructor(private masterService: ContractKindService) { }
  ngOnInit(): void {
   this.loadContractKind();
  }
  loadContractKind(){
    this.masterService.getContractKinds().subscribe(data => {
      this.contractKind = data;
    });
  }
  changeContractKindStatus(ck) {
    this.masterService.changeContractKindStatus(ck.id).subscribe(data => {
      this.loadContractKind();
    });
  }
}
