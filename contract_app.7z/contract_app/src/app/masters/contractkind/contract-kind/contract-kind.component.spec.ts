import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ContractKindComponent } from './contract-kind.component';

describe('ContractKindComponent', () => {
  let component: ContractKindComponent;
  let fixture: ComponentFixture<ContractKindComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ContractKindComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ContractKindComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
