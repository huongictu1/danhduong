export interface pageGroupDTO{
    id: number;
    groupId: number;
    pageId: number;
    active: Boolean;
}