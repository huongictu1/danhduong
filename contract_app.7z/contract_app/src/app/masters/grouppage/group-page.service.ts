import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class GroupPageService {

  constructor(private http: HttpClient) { }

  private apiURL = environment.apiURL + '/master'

  getPageGroups(){
    return this.http.get<any>(this.apiURL + '/pagegroup');
  }

  changeGroupPageStatus(id: Number)
  {
    return this.http.put<any>(`${this.apiURL}/grouppage-status?id=` + id, {
      
    });
  }
}
