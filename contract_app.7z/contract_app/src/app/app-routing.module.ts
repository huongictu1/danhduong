import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { HomeComponent } from './home/home.component';
import { IsAdminGuard } from './is-admin.guard';
import { LoginComponent } from './security/login/login.component';
import { IndexUsersComponent } from './users/index-users/index-users.component';
import {ContractKindComponent} from './masters/contractkind/contract-kind/contract-kind.component';
import {ContractStatusComponent} from './masters/contractstatus/contract-status/contract-status.component';
import {FactoryComponent} from './masters/factory/factory/factory.component';
import {GroupPageComponent} from './masters/grouppage/group-page/group-page.component';
import { PageComponent } from './masters/page/page/page.component';
import { RequestKindComponent } from './masters/requestkind/request-kind/request-kind.component';
import { LogoutComponent } from './logout/logout.component';
import { ContractIndexComponent } from './contract/contract-index/contract-index.component';
// import { ContractCreateComponent } from './contract/contract-create/contract-create.component';
import { ContractDetailComponent } from './contract/contract-detail/contract-detail.component';
import { ContractDetailStatusComponent } from './contract/contract-detail-status/contract-detail-status.component';
import { AuthGuard } from './auth.guard';
import { ForgetPasswordComponent } from './forget-password/forget-password.component';
import { ResetPasswordComponent } from './reset-password/reset-password.component';
import { ChangePasswordComponent } from './change-password/change-password.component';
import { GuestGuard } from './guest.guard';
import { ContractDetailSpecialComponent } from './contract/contract-detail-special/contract-detail-special.component';
import { ContractEditSpecialComponent } from './contract/contract-edit-special/contract-edit-special.component';
import { ContractAddComponent } from './contract/contract-add/contract-add.component';
import { ContractEditComponent } from './contract/contract-edit/contract-edit.component';
import { ContractAddSpecialComponent } from './contract/contract-add-special/contract-add-special.component';
import { ContractDetailNormalComponent } from './contract/contract-detail-normal/contract-detail-normal.component';
import { ReferenceComponent } from './masters/reference/reference.component';
import { DictionaryComponent } from './masters/dictionary/dictionary.component';
import { HelpReferenceComponent } from './help/help-reference/help-reference.component';
import { HelpDictionaryComponent } from './help/help-dictionary/help-dictionary.component';
import { SsologinComponent } from './security/ssologin/ssologin.component';
import { ContractLiquidationComponent } from './contract/contract-liquidation/contract-liquidation.component';
import { ContractLiquidationIndexComponent } from './contract/contract-liquidation-index/contract-liquidation-index.component';
import { ContractLiquidationDetailComponent } from './contract/contract-liquidation-detail/contract-liquidation-detail.component';
import { CreateUsersComponent } from './users/create-users/create-users.component';
import { DashboardComponent } from './home/dashboard/dashboard.component';
import { ElasticComponent } from './home/elastic/elastic.component';
import { ElasticScrollComponent } from './home/elastic-scroll/elastic-scroll.component';
import { ChatRoomComponent } from './home/chat-room/chat-room.component';
import { KibanaViewComponent } from './home/kibana-view/kibana-view.component';
import { SummaryDashboardComponent } from './home/summary-dashboard/summary-dashboard.component';
import { HelpPostComponent } from './help/help-post/help-post.component';
import { PortalSiteComponent } from './help/portal-site/portal-site.component';
import { CiceForumComponent } from './help/cice-forum/cice-forum.component';
import { ForumDetailComponent } from './help/cice-forum/forum-detail/forum-detail.component';
import { TutorialComponent } from './help/tutorial/tutorial.component';
const routes: Routes = [
  {path: '', component: HomeComponent, canActivate: [AuthGuard]},
  {path: 'home', component: HomeComponent, canActivate: [AuthGuard]},
  {path: 'dashboard', component: DashboardComponent, canActivate: [AuthGuard]},
  {path: 'summary-dashboard', component: SummaryDashboardComponent, canActivate: [AuthGuard]},
  {path: 'esearch', component: ElasticComponent, canActivate: [AuthGuard]},
  {path: 'esearch-scroll', component: ElasticScrollComponent, canActivate: [IsAdminGuard]},
  {path: 'visualization', component: KibanaViewComponent, canActivate: [IsAdminGuard]},
  {path: 'echat', component: ChatRoomComponent, canActivate: [AuthGuard]},
  {path: 'login', component: LoginComponent, canActivate: [GuestGuard]},
  {path: 'forget-password', component: ForgetPasswordComponent, canActivate: [GuestGuard]},
  {path: 'changePassword', component: ChangePasswordComponent, canActivate: [AuthGuard]},
  {path: 'reset-password/:username/:token', component: ResetPasswordComponent, canActivate: [GuestGuard]},
  {path: 'sso/:uname/:sid', component: SsologinComponent, canActivate: [GuestGuard]},
  {path: 'logout', component: LogoutComponent},
  {path: 'users', component: IndexUsersComponent, canActivate: [IsAdminGuard]},
  {path: 'users/create', component: CreateUsersComponent, canActivate: [IsAdminGuard]},
  {path: 'main', component: ContractIndexComponent, canActivate: [AuthGuard]},
  {path: 'maino/:searchType', component: ContractIndexComponent, canActivate: [AuthGuard]},
  {path: 'main/create', component: ContractAddComponent, canActivate: [AuthGuard]},
  {path: 'main/create/:previousId', component: ContractAddComponent, canActivate: [AuthGuard]},
  {path: 'main/contract-liquidation', component: ContractLiquidationComponent, canActivate: [AuthGuard]},
  {path: 'main/contract-liquidation/:contractId', component: ContractLiquidationComponent, canActivate: [AuthGuard]},
  {path: 'main/contract-liquidation-index', component: ContractLiquidationIndexComponent, canActivate: [AuthGuard]},
  {path: 'main/liquidation/:contractId', component: ContractLiquidationDetailComponent, canActivate: [AuthGuard]},
  {path: 'main/create-special', component: ContractAddSpecialComponent, canActivate: [AuthGuard]},
  {path: 'main/detail/:contractId', component: ContractDetailNormalComponent, canActivate: [AuthGuard]},
  {path: 'main/special/detail/:contractId', component: ContractDetailSpecialComponent, canActivate: [AuthGuard]},
  {path: 'main/edit/:contractId', component: ContractEditComponent, canActivate: [AuthGuard]},
  {path: 'main/special/edit/:contractId', component: ContractEditSpecialComponent, canActivate: [IsAdminGuard]},
  {path: 'main/status/:contractId/:statusId', component: ContractDetailStatusComponent, canActivate: [AuthGuard]},
  {path: 'help/reference', component: HelpReferenceComponent, canActivate: [AuthGuard]},
  {path: 'help/dictionary', component: HelpDictionaryComponent, canActivate: [AuthGuard]},
  {path: 'help/post', component: HelpPostComponent, canActivate: [AuthGuard]},
  {path: 'help/tour', component: TutorialComponent, canActivate: [AuthGuard]},
  {path: 'help/portal-site', component: PortalSiteComponent, canActivate: [AuthGuard]},
  {path: 'help/cice-forum', component: CiceForumComponent, canActivate: [AuthGuard]},
  {path: 'help/forum-detail/:id', component: ForumDetailComponent, canActivate: [AuthGuard]},
  {path: 'users', component: IndexUsersComponent, canActivate: [IsAdminGuard]},
  {path: 'contractkind', component: ContractKindComponent, canActivate: [IsAdminGuard]},
  {path: 'contractstatus', component: ContractStatusComponent, canActivate: [IsAdminGuard]},
  {path: 'reference', component: ReferenceComponent, canActivate: [IsAdminGuard]},
  {path: 'dictionary', component: DictionaryComponent, canActivate: [IsAdminGuard]},
  {path: 'factory', component: FactoryComponent, canActivate: [IsAdminGuard]},
  {path: 'grouppage', component: GroupPageComponent, canActivate: [IsAdminGuard]},
  {path: 'page', component: PageComponent, canActivate: [IsAdminGuard]},
  {path: 'requestkind', component: RequestKindComponent, canActivate: [IsAdminGuard]},
  {path: '**', redirectTo: ''}
];

@NgModule({
  imports: [RouterModule.forRoot(routes, {useHash: true})],//, {onSameUrlNavigation: 'reload', useHash: true}
  exports: [RouterModule]
})
export class AppRoutingModule { }
