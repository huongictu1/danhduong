import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import Swal from 'sweetalert2';
import { SecurityService } from '../security/security.service';
@Component({
  selector: 'app-login-sso',
  templateUrl: './login-sso.component.html',
  styleUrls: ['./login-sso.component.scss']
})
export class LoginSsoComponent implements OnInit {
  constructor(public securityService: SecurityService, public router: Router,
    public route: ActivatedRoute) {
    this.route.paramMap.subscribe(params => {
      this.uname = params.get('uname');
      this.sid = params.get('sid');
    })
  }

  uname: any;
  sid: any;

  ngOnInit(): void {
    this.login();
  }

  // public uname: string;
  // public sid: string;

  // constructor(
  //   public securityService: SecurityService,
  //   public router: Router,
  //   public route: ActivatedRoute,
  // ) {

  // }

  // ngOnInit(): void {
  //   this.route.queryParams
  //     .subscribe(params => {
  //       this.uname = params.uname;
  //       this.sid = params.sid;
  //       this.login();
  //     }
  //   );
  // }

  login() {
    this.securityService.clearToken();
    this.securityService.loginSso(this.uname, this.sid).subscribe(data => {
      // console.log(data);
      this.securityService.saveToken(data);
      var tk = this.securityService.getToken();
      if (tk != null && tk != '') {
        this.router.navigate(["/"]);
      }
      else {
        this.login();
      }
    });
  }
}
