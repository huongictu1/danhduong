export class Department {
    id:number
    deptId:number
    deptShortName:string
    deptFullName:string
    factId:number
    factShortName:string
    factFullName:string
    active:string
}
