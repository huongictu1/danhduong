import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';
import { Department } from './department.model';

@Injectable({
  providedIn: 'root'
})
export class DepartmentService {
  departments: Department[];

  constructor(private http: HttpClient) { }

  private apiURL = environment.apiURL + '/master'
  private apiURLContract = environment.apiURL + '/contract'

  getAllByKey(): Observable<Department[]>{
    return this.http.get<Department[]>(`${this.apiURL}/department`);
  }

  getAll(): Observable<Department[]>{
    return this.http.get<Department[]>(`${this.apiURL}/department2`);
  }

  getRelatedDept(contractId: string): Observable<Department[]>{
    return this.http.post<Department[]>(`${this.apiURLContract}/getRelatedDept?contractId=`+contractId, {});
  }

  getDeptByUser(): Observable<Department[]>{
    return this.http.get<Department[]>(`${this.apiURL}/deptByUser`);
  }
}
