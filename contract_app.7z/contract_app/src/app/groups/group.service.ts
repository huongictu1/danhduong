import { Injectable } from '@angular/core';
import { environment } from 'src/environments/environment';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class GroupService {

  constructor(private http: HttpClient) { }

  private apiURL = environment.apiURL + '/master'

  getAllByKey(): any{
    return this.http.get<any>(`${this.apiURL}/group`);
  }

  getAll(): any{
    return this.http.get<any>(`${this.apiURL}/group2`);
  }
}
