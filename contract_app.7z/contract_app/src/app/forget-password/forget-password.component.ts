import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';
import Swal from 'sweetalert2';
import { SecurityService } from '../security/security.service';

@Component({
  selector: 'app-forget-password',
  templateUrl: './forget-password.component.html',
  styleUrls: ['./forget-password.component.scss']
})
export class ForgetPasswordComponent implements OnInit {

  constructor(
    public securityService: SecurityService,
    public router: Router,
    public route: ActivatedRoute,
    private formBuilder: FormBuilder
  ) { }
  isLoading: Boolean;
  form: FormGroup;
  ngOnInit(): void {
    this.isLoading = false;
    this.form = this.formBuilder.group({
      username: ['', {
        validators: [Validators.required]
      }]
    });
  }

  onSubmit()
  {
    this.securityService.forgetPassword(this.form.value.username).subscribe(data => {
      console.log(data);
      if (data.status == 200) {
        Swal.fire(data.message, "", "success");
        this.router.navigateByUrl('login');
      }
    });
  }
}
