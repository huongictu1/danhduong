import { environment} from 'src/environments/environment';

export function toBase64(file: File){
    return new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.readAsDataURL(file);
        reader.onload = () => resolve(reader.result);
        reader.onerror = (error) => reject(error);
    })
}

export function parseWebAPIErrors(response: any): string[] {
    const result: string[] = [];

    if (response.error){
        if (typeof response.error === 'string'){
            result.push(response.error);
        } else if (Array.isArray(response.error)) {
            response.error.forEach(value => result.push(value.description));
        } else{
            const mapErrors = response.error.errors;
            const entries = Object.entries(mapErrors);
            entries.forEach((arr: any[]) => {
                const field = arr[0];
                arr[1].forEach(errorMessage => {
                    result.push(`${field}: ${errorMessage}`);
                })
            })
        }
    }

    return result;
}

export function formatDateFormData(date: Date){
    date = new Date(date);
    const format = new Intl.DateTimeFormat('en', {
        year: 'numeric',
        month: '2-digit',
        day: '2-digit'
    });

    const [
        {value: month},,
        {value: day},,
        {value: year}
    ] = format.formatToParts(date);

    // yyyy-MM-dd
    return `${year}-${month}-${day}`;
}

export function splitLink(link: string)
{
  let array_link = [];
  if (link) {
    array_link = link.split(";");
  }
  return array_link;
}
export function splitPathFile(link: string)
{
  let array_link = [];
  if (link) {
    array_link = link.split("/");
  }
  return array_link;
}

export function replaceWhiteSpace(str: string){
  return str.replace('\t','&nbsp;')
  .replace('\r\n','&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;')
  .replace('\r','&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;')
  .replace('\n','&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;');
}

export function concatLink(link: string)
{
  return environment.apiURL + link;
}

export function getExtensionFile(fileName: string)
{
    return fileName.split('.').pop();
}

export function isPdf(fileName: string)
{
    let ext = getExtensionFile(fileName).toLowerCase();
    return ext == "pdf";
}

export function isDocx(fileName: string)
{
    let ext = getExtensionFile(fileName).toLowerCase();
    return ext == "doc" || ext == "docx";
}

export function isExcel(fileName: string)
{
    let ext = getExtensionFile(fileName).toLowerCase();
    return ext == "xlsx" || ext == "xls" || ext == "xlsm" || ext == "xlsb";
}

export function isPowerpoint(fileName: string)
{
    let ext = getExtensionFile(fileName).toLowerCase();
    return ext == "ppt" || ext == "pptx" || ext == "pptm";
}

export function isOffice(fileName: string)
{
    let ext = getExtensionFile(fileName).toLowerCase();
    return ext != "doc" && ext != "docx" && ext != "pdf" 
    && ext != "pptx" && ext != "ppt" && ext != "xls" && ext != "xlsx";
}

export function capitalizeFirstLetter(string) {
    return string.charAt(0).toUpperCase() + string.slice(1);
}

export function formatDate(date) {
  var d = new Date(date),
    month = '' + (d.getMonth() + 1),
    day = '' + d.getDate(),
    year = d.getFullYear();

  if (month.length < 2) month = '0' + month;
  if (day.length < 2) day = '0' + day;

  return [year, month, day].join('-');
}

export function getImageSrc(link_file: string)
{
  if (isDocx(link_file)) {
    return "assets/images/word-icon.png";
  }
  else if (isPdf(link_file)) {
    return "assets/images/pdf-icon.png";
  }
  else if (isExcel(link_file)) {
    return "assets/images/excel-icon.png";
  }
  else if (isPowerpoint(link_file)) {
    return "assets/images/ppt-icon.png";
  }
  else {
    return "assets/images/office-icon.png";
  }
}
