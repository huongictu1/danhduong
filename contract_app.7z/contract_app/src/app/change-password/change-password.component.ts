import { Component, OnInit } from '@angular/core';
import { AbstractControl, FormBuilder, FormGroup, ValidationErrors, ValidatorFn, Validators } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';
import Swal from 'sweetalert2';
import { SecurityService } from '../security/security.service';

@Component({
  selector: 'app-change-password',
  templateUrl: './change-password.component.html',
  styleUrls: ['./change-password.component.scss']
})
export class ChangePasswordComponent implements OnInit {
  form: FormGroup;
  isLoading: Boolean;
  constructor(
    public securityService: SecurityService,
    public router: Router,
    public route: ActivatedRoute,
    private formBuilder: FormBuilder
  ) {
   }

  ngOnInit(): void {
    this.isLoading = false;
    this.form = this.formBuilder.group({
      username: [ this.securityService.getFieldFromJWT('user_name'), {
        validators: [Validators.required]
      }],
      oldPassword: ['', {
        validators: [Validators.required]
      }],
      newPassword: ['', {
        validators: [Validators.required]
      }],
      confirmPassword: ['', {
        validators: [Validators.required]
      }]
    }, { validators: this.checkPasswords });
  }

  onSubmit()
  {
    if(this.form.value.newPassword == this.form.value.oldPassword) {
      Swal.fire('Please not using new password same old password', '', 'warning')
    } else {
      this.securityService.changePassword(this.form.value).subscribe(data => {
        if(data.status == 200) {
          Swal.fire('Change password successful', '', 'success')
          this.router.navigateByUrl('/');

        } else if (data.status == 400){
          Swal.fire('Change password fail', data.message, 'warning')
        }
      });
    }
  }

  checkPasswords: ValidatorFn = (group: AbstractControl):  ValidationErrors | null => {
    let pass = group.get('newPassword').value;
    let confirmPass = group.get('confirmPassword').value
    return pass === confirmPass ? null : { notSame: true }
  }
}
