import { Component, OnDestroy, OnInit } from '@angular/core';
import { SecurityService } from './security/security.service';
import { Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {

  isLoading: Boolean;
  public notifications: any;
  public counter: Number;

  constructor(public securityService: SecurityService, public router: Router,private http: HttpClient) {
    this.counter = 0;
  }

  ngOnInit(): void {
    if(!this.securityService.isAuthenticated()) {
      // this.router.navigateByUrl('login');
    } else {
      // this.securityService.getListNotification().subscribe(data => {
      //   this.notifications = data;
      //   this.counter = data.length;
      // });
      // this.securityService.notificationCountChanged.subscribe(count => {
      //   this.counter = count;
      // });
    }
  }
}
