import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-portal-site',
  templateUrl: './portal-site.component.html',
  styleUrls: ['./portal-site.component.scss']
})
export class PortalSiteComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
