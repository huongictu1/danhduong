import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class CiceForumService {

  constructor(private http: HttpClient) { }

  private apiURL = environment.apiURL + '/service'

  getListArticle(){
    return this.http.get<any>(this.apiURL + '/la-forum');
  }
}
