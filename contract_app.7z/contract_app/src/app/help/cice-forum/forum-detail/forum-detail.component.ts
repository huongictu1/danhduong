import { Component, OnInit } from '@angular/core';
import { DomSanitizer } from '@angular/platform-browser';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-forum-detail',
  templateUrl: './forum-detail.component.html',
  styleUrls: ['./forum-detail.component.scss']
})
export class ForumDetailComponent implements OnInit {
  public articleId: string;
  constructor(public route: ActivatedRoute,
    public router: Router, private sanitizer: DomSanitizer) { 
    this.articleId = this.route.snapshot.paramMap.get('id');
  }

  ngOnInit(): void {
  }

  getSafeUrl(){
    var url = 'http://cice-training.cvn.canon.co.jp/#/forum/forum_detail/' + this.articleId;
    return this.sanitizer.bypassSecurityTrustResourceUrl(url);
  }
}
