import { Component, OnInit } from '@angular/core';
import { CiceForumService } from './cice-forum.service';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Route } from '@angular/router';
import { Router } from '@angular/router';
import { splitLink, isPdf, isDocx, isOffice, splitPathFile, concatLink, isExcel, isPowerpoint } from 'src/app/utilities/utils';
import Swal from 'sweetalert2';
import { formatDate } from 'src/app/utilities/utils';
//import { Editor, Toolbar } from 'ngx-editor';
import { CKEditorComponent } from 'ckeditor4-angular';
import { timer } from 'rxjs';

@Component({
  selector: 'app-cice-forum',
  templateUrl: './cice-forum.component.html',
  styleUrls: ['./cice-forum.component.scss']
})
export class CiceForumComponent implements OnInit {

  constructor(private service: CiceForumService) { }
  articles: any[];
  public title: string;
  public content: string;
  public category: string;
  loading: boolean;
  ngOnInit(): void {
    this.loadPosts();
  }
  loadPosts(){
    this.loading = true;
    this.service.getListArticle().subscribe(data => {
      this.articles = data;
      this.loading = false;
    });
  }

}
