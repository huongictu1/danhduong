import { Component, OnInit } from '@angular/core';
import { HelpReferenceService } from './help-reference.service';
import { splitLink , isDocx, isPdf, concatLink, isOffice, getImageSrc, splitPathFile} from 'src/app/utilities/utils';

@Component({
  selector: 'app-help-reference',
  templateUrl: './help-reference.component.html',
  styleUrls: ['./help-reference.component.scss']
})
export class HelpReferenceComponent implements OnInit {

  references: any[];
  constructor(private masterService: HelpReferenceService) { }

  ngOnInit(): void {
    this.loadReferences();
  }
  loadReferences(){
    this.masterService.getReferences().subscribe(data => {
      this.references = data;
    });
  }
  concatLink(link){
    return concatLink(splitLink(link)[0]);
  }
  splitLink(link){
    return splitLink(link)[0];
  }
  getFilenameWithoutGuid(link) {
    var fileFullName = splitPathFile(link);
    var fileName = fileFullName[fileFullName.length - 1];
    return fileName.substring(37);
  }
}
