import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class HelpPostService {

  constructor(private http: HttpClient) { }

  private apiURL = environment.apiURL + '/master'

  getReferences(){
    return this.http.get<any>(this.apiURL + '/help-posts1');
  }

  changeReferenceStatus(id: string)
  {
    return this.http.put<any>(`${this.apiURL}/active-help-post?id=` + id, {
      
    });
  }

  addDocument(params) {
    return this.http.post<any>(`${this.apiURL}/add-help-post`, params);
  }

  detailDocument(id) {
    return this.http.get<any>(`${this.apiURL}/detail-help-post?id=`+id);
  }
  saveDocument(id: string, params: any)
  {
    return this.http.put<any>(`${this.apiURL}/edit-help-post?id=` + id, params);
  }
}
