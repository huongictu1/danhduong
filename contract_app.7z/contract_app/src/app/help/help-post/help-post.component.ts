import { Component, OnInit, AfterViewInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { HelpPostService } from './help-post.service';
import { ActivatedRoute, Route } from '@angular/router';
import { Router } from '@angular/router';
import { splitLink, isPdf, isDocx, isOffice, splitPathFile, concatLink, isExcel, isPowerpoint } from 'src/app/utilities/utils';
import Swal from 'sweetalert2';
import { formatDate } from 'src/app/utilities/utils';
//import { Editor, Toolbar } from 'ngx-editor';
import { CKEditorComponent } from 'ckeditor4-angular';
import { timer } from 'rxjs';

@Component({
  selector: 'app-help-post',
  templateUrl: './help-post.component.html',
  styleUrls: ['./help-post.component.scss']
})
export class HelpPostComponent implements OnInit {
  public Editor = CKEditorComponent;
  references: any[];
  public title: string;
  public content: string;
  public category: string;
  $: any;
  constructor(private masterService: HelpPostService) { }

  ngOnInit(): void {
    this.loadPosts();
  }
  loadPosts(){
    this.masterService.getReferences().subscribe(data => {
      this.references = data;
    });
  }
  public onReady(editor) {
    // editor.ui.getEditableElement().parentElement.insertBefore(
    //   editor.ui.view.toolbar.element,
    //   editor.ui.getEditableElement()
    // );
  }
  changeReferenceStatus(ck) {
    this.masterService.changeReferenceStatus(ck.id).subscribe(data => {
      this.loadPosts();
    });
  }
  concatLink(link){
    return concatLink(splitLink(link)[0]);
  }
  splitLink(link){
    return splitLink(link)[0];
  }
  getFilenameWithoutGuid(link) {
    var fileFullName = splitPathFile(link);
    var fileName = fileFullName[fileFullName.length - 1];
    return fileName.substring(37);
  }
  
  onFormSubmit()
  {
    
    this.references = null;
    if (this.title && this.content && this.category) {
      let formData = new FormData();
      formData.append('title', this.title);
      formData.append('content', this.content);
      formData.append('category', this.category);
      this.masterService.addDocument(formData).subscribe(data => {
        
        if (data == 1) {
          this.loadPosts();
          document.getElementById('btn-close-modal3').click();
        }
        else if (data != 1) {
          Swal.fire(data.message, "Bad request", "error");
        }
      })
    } else {
      Swal.fire("Require title, content !", "Warning", "warning");
    }
  }
  

}
