import { Component, OnInit } from '@angular/core';
import { HelpDictionaryService } from './help-dictionary.service';

@Component({
  selector: 'app-help-dictionary',
  templateUrl: './help-dictionary.component.html',
  styleUrls: ['./help-dictionary.component.scss']
})
export class HelpDictionaryComponent implements OnInit {
  dictionaries: any[];
  constructor(private masterService: HelpDictionaryService) { }

  ngOnInit(): void {
    this.loadDictionaries();
  }
  loadDictionaries(){
    this.masterService.getDictionaries().subscribe(data => {
      this.dictionaries = data;
    });
  }

}
