import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, CanActivate, RouterStateSnapshot, UrlTree } from '@angular/router';
import { Observable } from 'rxjs';
import { SecurityService } from './security/security.service';
import { Router } from '@angular/router';
import { NotificationService } from './menu/notifycation.service';
@Injectable({
  providedIn: 'root'
})
export class AuthGuard implements CanActivate {

  constructor(
    private securityService: SecurityService,
    private router: Router,
    private notificationService: NotificationService
  )
  {

  }

  canActivate(
    route: ActivatedRouteSnapshot,
    state: RouterStateSnapshot): Observable<boolean | UrlTree> | Promise<boolean | UrlTree> | boolean | UrlTree {
    if(!this.securityService.isAuthenticated()) {
      this.router.navigate(['login'],{queryParams:{'redirectURL':state.url}});
      return false;
    } else {
      this.notificationService.countNotification();
      return true;
    }
  }
  
}
