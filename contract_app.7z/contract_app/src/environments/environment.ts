export const environment = {
  production: false,
  apiURL: 'http://localhost:5107/api',
  uRL: 'http://localhost:5107/'
};
