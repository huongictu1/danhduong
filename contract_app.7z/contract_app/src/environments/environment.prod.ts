export const environment = {
  production: true,
  apiURL: 'http://cvn-contract:5107/api',
  uRL: 'http://cvn-contract:5107/'
};
