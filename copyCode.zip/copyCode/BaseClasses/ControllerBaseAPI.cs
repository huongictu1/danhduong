﻿using System.Text.Json;
using Microsoft.AspNetCore.Mvc;
using PDCProjectApi.Data;
using PDCProjectApi.Services;

namespace PDCProjectApi.BaseClasses
{
    
    public class ControllerBaseAPI : ControllerBase
    {
        public List<string> LstBlockCode
        {
            get
            {
                var result = new List<string>();
                try
                {
                    result = HttpContext.Request.Headers["block_code"].ToString().Split(',').ToList();
                    result = result.Where(x => x != "").ToList();
                }
                catch (Exception)
                {

                }
                return result;
            }
        }
        public List<string> LstProduct
        {
            get
            {
                var result = new List<string>();
                try
                {
                    result = HttpContext.Request.Headers["product"].ToString().Split(',').ToList();
                    result = result.Where(x => x != "").ToList();
                }
                catch (Exception)
                {

                }
                return result;
            }
        }
    }
}
