﻿namespace PDCProjectApi.BaseClasses
{
    public class GlobalBaseClass
    {
    }
}
