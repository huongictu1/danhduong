﻿using System;
using System.Collections.Generic;

namespace PDCProjectApi.Data;

public partial class VlinkageEucLbpJ1001
{
    public string? QtDelvLot { get; set; }

    public string? QtSnp { get; set; }

    public string? NoParts { get; set; }

    public string? CdSply { get; set; }

    public string? NoArrange { get; set; }

    public string? CdOrdClass { get; set; }

    public string? PdPoIssue { get; set; }
}
