﻿using System;
using System.Collections.Generic;

namespace PDCProjectApi.Data;

public partial class TodTodOutput1TotalDetailIj
{
    public DateOnly TodDate { get; set; }

    public Guid CommonId { get; set; }

    public double TodValue { get; set; }
}
