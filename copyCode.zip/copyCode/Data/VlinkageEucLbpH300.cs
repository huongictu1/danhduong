﻿using System;
using System.Collections.Generic;

namespace PDCProjectApi.Data;

public partial class VlinkageEucLbpH300
{
    public string? CdFact { get; set; }

    public string? NoParts { get; set; }

    public string? NoAdjDim { get; set; }

    public string? CdBlock { get; set; }

    public string? TmStoreLead { get; set; }

    public string? PdProcess { get; set; }
}
