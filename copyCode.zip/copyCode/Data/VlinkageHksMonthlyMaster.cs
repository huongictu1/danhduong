﻿using System;
using System.Collections.Generic;

namespace PDCProjectApi.Data;

public partial class VlinkageHksMonthlyMaster
{
    public string? CodeControl { get; set; }

    public DateTime? DateEntry { get; set; }

    public string? UserEntry { get; set; }

    public DateTime? DateUpdate { get; set; }

    public string? UserUpdate { get; set; }

    public string? LineNo { get; set; }

    public string? Merchandise { get; set; }

    public int? OpQt { get; set; }

    public int? SppQt { get; set; }

    public int? LdQt { get; set; }

    public double? WorkFactor { get; set; }

    public double? StdTime { get; set; }

    public int? TarQt { get; set; }

    public int? OtQt { get; set; }

    public int? NorTime { get; set; }

    public int? OtTime { get; set; }

    public string? MealTime { get; set; }

    public int? OldopQt { get; set; }

    public int? NewopQt { get; set; }

    public DateOnly? MonthLine { get; set; }

    public string? TypeTimeDay { get; set; }

    public string? TypeTimeNight { get; set; }

    public string? WeekNo { get; set; }

    public int? Status { get; set; }

    public DateOnly? StartDate { get; set; }
}
