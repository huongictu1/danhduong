﻿using System;
using System.Collections.Generic;

namespace PDCProjectApi.Data;

public partial class TodStructureTemporaryConnect
{
    public Guid Id { get; set; }

    public string TempNo { get; set; } = null!;

    public string PartNo { get; set; } = null!;

    public string PartName { get; set; } = null!;

    public string Vendor { get; set; } = null!;

    public string Model { get; set; } = null!;

    public string Merchandise { get; set; } = null!;

    public double Usage { get; set; }

    public double Ratio { get; set; }

    public DateOnly EfffectiveFrom { get; set; }

    public DateOnly? EffectiveTo { get; set; }

    public string? InventoryBy { get; set; }

    public string? Reason { get; set; }

    public DateTime? CreatedDate { get; set; }

    public string? CreatedBy { get; set; }

    public DateTime? ApprovedDate { get; set; }

    public string? ApprovedBy { get; set; }

    public bool? Active { get; set; }

    public bool? Status { get; set; }

    public string? ModifiedBy { get; set; }

    public DateTime? ModifiedDate { get; set; }

    public string? Bc { get; set; }

    public string? EcnLevel { get; set; }
}
