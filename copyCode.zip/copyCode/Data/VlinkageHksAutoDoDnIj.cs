﻿using System;
using System.Collections.Generic;

namespace PDCProjectApi.Data;

public partial class VlinkageHksAutoDoDnIj
{
    public int? No { get; set; }

    public string? PartNo { get; set; }

    public string? Vendor { get; set; }

    public string? DeliveryKey { get; set; }

    public string? Location { get; set; }

    public string? DeteDelivery { get; set; }

    public string? TimeDelivery { get; set; }

    public string? PlanQty { get; set; }

    public string? PoStatus { get; set; }

    public string? BcUse { get; set; }
}
