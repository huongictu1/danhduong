﻿using System;
using System.Collections.Generic;

namespace PDCProjectApi.Data;

/// <summary>
/// xác định luồng approval, step nào cho nhóm nào, toàn bộ nhóm đó sẽ nhận dc mail
/// </summary>
public partial class AdmMasterApprovalProcess
{
    public DateTime? CreatedDate { get; set; }

    public string? CreatedBy { get; set; }

    public DateTime? ModifiedDate { get; set; }

    public string? ModifiedBy { get; set; }

    public bool? Active { get; set; }

    public Guid Id { get; set; }

    public string ApprName { get; set; } = null!;

    public int ApprOrder { get; set; }

    public string ApprDisplay { get; set; } = null!;

    public Guid GroupId { get; set; }

    public string ApprDept { get; set; } = null!;

    public string FuncName { get; set; } = null!;

    public virtual AdmMasterGroup Group { get; set; } = null!;
}
