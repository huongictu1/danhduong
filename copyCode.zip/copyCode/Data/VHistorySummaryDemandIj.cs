﻿using System;
using System.Collections.Generic;

namespace PDCProjectApi.Data;

public partial class VHistorySummaryDemandIj
{
    public string? PartNo { get; set; }

    public string? Bc { get; set; }

    public string? Vendor { get; set; }

    public double? TodayValue { get; set; }

    public double? TomorrowValue { get; set; }
}
