﻿using System;
using System.Collections.Generic;

namespace PDCProjectApi.Data;

public partial class VClaimCardIjJ5302
{
    public string? CdSply { get; set; }

    public string? NmSplyEng { get; set; }
}
