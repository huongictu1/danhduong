﻿using System;
using System.Collections.Generic;

namespace PDCProjectApi.Data;

public partial class PcPaOp22Hand
{
    public int? IndividualOrderFlag { get; set; }

    public string? Factory { get; set; }

    public string Vendor { get; set; } = null!;

    public string? VendorFctry { get; set; }

    public string PartNo { get; set; } = null!;

    public string? Dim { get; set; }

    public string? Pr { get; set; }

    public string? IndividualOrder { get; set; }

    public string? Taping { get; set; }

    public string? DrawingNo { get; set; }

    public string? EcnNo { get; set; }

    public string? Cp { get; set; }

    public string? ReqDeliveryTime { get; set; }

    public string? OrderQty { get; set; }

    public string? Unit { get; set; }

    public string? DeliveryLot { get; set; }

    public string? DeliveryLocation { get; set; }

    public string? InspectionMethod { get; set; }

    public string? UsedBlockCode { get; set; }

    public string? InventoryCode { get; set; }

    public string? CncrDlvOdrM { get; set; }

    public string? OrderReasonCode { get; set; }

    public string? LimitationMark { get; set; }

    public string? ItemCategory { get; set; }

    public string? StrtM { get; set; }

    public string? ItemTypr { get; set; }

    public string? AssessmentItemType { get; set; }

    public string? AssessmentItemCode { get; set; }

    public string? MainBodyYorn { get; set; }

    public string? TransportMethod { get; set; }

    public string? DeparturePort { get; set; }

    public string? ArrivalPort { get; set; }

    public string? ReceivingPointCode { get; set; }

    public string? ContainerLoadingCode { get; set; }

    public string? EquipmentBudgetCode { get; set; }

    public string? WithdrawQty { get; set; }

    public string? WarrantyShotCount { get; set; }

    public string? DieNumber { get; set; }

    public string? DieFatory { get; set; }

    public string? DieSeriviceLife { get; set; }

    public string? CustPoNo { get; set; }

    public string? PackingClass { get; set; }

    public string? StandardPack { get; set; }

    public string? BoxCode { get; set; }

    public string? ProductAbbrName { get; set; }

    public string? ResponsibleDiv { get; set; }

    public string? QuotationPic { get; set; }

    public string? Buyer { get; set; }

    public string? OrginCountry { get; set; }

    public string? PartsName { get; set; }

    public string? RequestorComment { get; set; }

    public string? ApproverComment { get; set; }

    public string? Approver { get; set; }

    public DateTime? CreatedDate { get; set; }

    public string? CreatedBy { get; set; }

    public DateTime? ModifiedDate { get; set; }

    public string? ModifiedBy { get; set; }

    public bool? Active { get; set; }

    public Guid? RequestId { get; set; }

    public Guid Id { get; set; }

    public string? ReqDeliveryDate { get; set; }
}
