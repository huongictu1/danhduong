﻿using System;
using System.Collections.Generic;

namespace PDCProjectApi.Data;

public partial class LtFormRegistrationLogItem
{
    public DateTime? CreatedDate { get; set; }

    public string? CreatedBy { get; set; }

    public DateTime? ModifiedDate { get; set; }

    public string? ModifiedBy { get; set; }

    public bool? Active { get; set; }

    public Guid Id { get; set; }

    public string? PartNo { get; set; }

    public string? PartName { get; set; }

    public string? Vendor { get; set; }

    public string? PcsBox { get; set; }

    public string? Model { get; set; }

    public string? Layout { get; set; }

    public string? Khsx { get; set; }

    public string? ChangingReason { get; set; }

    public string? ChangingSupplyGroup { get; set; }

    public DateOnly? RequestEffectiveDate { get; set; }

    public string? MovingRecStoreSupplyQty { get; set; }

    public string? MovingRecStoreCycleSupply { get; set; }

    public string? MovingRecStoreCycleTime { get; set; }

    public string? MovingRecStoreReceivingTime { get; set; }

    public string? MovingRecStoreFrom { get; set; }

    public string? MovingRecStoreTo { get; set; }

    public string? MovingRecStoreDistance { get; set; }

    public string? MovingRecStoreTransportation { get; set; }

    public string? MovingRecStoreMovingTime { get; set; }

    public string? MovingRecStoreInputStock { get; set; }

    public string? MovingAssyStorePickupTime { get; set; }

    public string? MovingAssyStoreFromLocation { get; set; }

    public string? MovingAssyStoreToLocation { get; set; }

    public string? MovingAssyStoreDistance { get; set; }

    public string? MovingAssyStoreTransportation { get; set; }

    public string? MovingAssyStoreCrossPoint { get; set; }

    public string? MovingAssyStoreMovingTime { get; set; }

    public string? MovingAssyStoreSuppyTime { get; set; }

    public string? MovingAssyStoreSafetyQty { get; set; }

    public string? TotalLeadtime { get; set; }

    public string? Note { get; set; }

    public string? MovingAssyStoreFromAddress { get; set; }

    public string? MovingAssyStoreToAddress { get; set; }

    public string? ApprovedBy { get; set; }

    public DateTime? ApprovedDate { get; set; }

    public int? ApprovedStatus { get; set; }

    public string? RequestNo { get; set; }
}
