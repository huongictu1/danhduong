﻿using System;
using System.Collections.Generic;

namespace PDCProjectApi.Data;

public partial class PcSimulationWarningOverOp10Lbp
{
    public DateTime? CreatedDate { get; set; }

    public string? CreatedBy { get; set; }

    public DateTime? ModifiedDate { get; set; }

    public string? ModifiedBy { get; set; }

    public bool? Active { get; set; }

    public Guid Id { get; set; }

    public string Bc { get; set; } = null!;

    public string PartNo { get; set; } = null!;

    public string? Dim { get; set; }

    public string? PartMovingRoute { get; set; }

    public string PartName { get; set; } = null!;

    public string Vendor { get; set; } = null!;

    public string MoqOrder { get; set; } = null!;

    public string? Model { get; set; }

    public string? Destination { get; set; }

    public string? MainAlt { get; set; }

    public string? Factory { get; set; }

    public string? Ratio { get; set; }

    public string? EffectivedateChange { get; set; }

    public string? RatioChange { get; set; }

    public string? DoPic { get; set; }

    public string? PoPic { get; set; }

    public string? Pair { get; set; }

    public DateOnly? DeadlineDate { get; set; }

    public TimeOnly? DeadlineTime { get; set; }

    public string? Reason { get; set; }

    public string? Action { get; set; }

    public double? DeadlineOverQty { get; set; }

    public DateOnly? DeadlineInclDate { get; set; }

    public TimeOnly? DeadlineInclTime { get; set; }

    public string? Notice { get; set; }

    public double? DeadlineOverPallet { get; set; }
}
