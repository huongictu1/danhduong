﻿using System;
using System.Collections.Generic;

namespace PDCProjectApi.Data;

public partial class AdmMasterGroup
{
    public DateTime? CreatedDate { get; set; }

    public string? CreatedBy { get; set; }

    public DateTime? ModifiedDate { get; set; }

    public string? ModifiedBy { get; set; }

    public bool? Active { get; set; }

    public Guid Id { get; set; }

    public string? GroupName { get; set; }

    public string? Note { get; set; }

    public virtual ICollection<AdmDetailPageGroup> AdmDetailPageGroups { get; set; } = new List<AdmDetailPageGroup>();

    public virtual ICollection<AdmDetailUserGroup> AdmDetailUserGroups { get; set; } = new List<AdmDetailUserGroup>();

    public virtual ICollection<AdmDetailUserPageReadOnly> AdmDetailUserPageReadOnlies { get; set; } = new List<AdmDetailUserPageReadOnly>();

    public virtual ICollection<AdmMasterApprovalProcess> AdmMasterApprovalProcesses { get; set; } = new List<AdmMasterApprovalProcess>();

    public virtual ICollection<PcPaRequestRevisePoProcess> PcPaRequestRevisePoProcesses { get; set; } = new List<PcPaRequestRevisePoProcess>();
}
