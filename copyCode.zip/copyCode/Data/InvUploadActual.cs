﻿using System;
using System.Collections.Generic;

namespace PDCProjectApi.Data;

public partial class InvUploadActual
{
    public DateTime? CreatedDate { get; set; }

    public string? CreatedBy { get; set; }

    public DateTime? ModifiedDate { get; set; }

    public string? ModifiedBy { get; set; }

    public bool? Active { get; set; }

    public Guid Id { get; set; }

    public string? PartNo { get; set; }

    public string? Vendor { get; set; }

    public double? RemainLastDay { get; set; }

    public double[]? StoreIn { get; set; }

    public Guid? StoreInoutId { get; set; }

    public double? RemainCalculate { get; set; }

    public double? ActualRemain { get; set; }

    public double? Differ { get; set; }

    public string? Reason { get; set; }

    public string? LendingNo { get; set; }

    public string? SlipNo { get; set; }

    public DateOnly? FromDate { get; set; }

    public DateOnly? ToDate { get; set; }

    public string? Product { get; set; }

    public double[]? StoreOut { get; set; }

    public virtual InvStoreInout? StoreInout { get; set; }
}
