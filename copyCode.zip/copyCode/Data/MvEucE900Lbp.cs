﻿using System;
using System.Collections.Generic;

namespace PDCProjectApi.Data;

public partial class MvEucE900Lbp
{
    public string? Term { get; set; }

    public string? NoParts { get; set; }

    public double? Sum { get; set; }
}
