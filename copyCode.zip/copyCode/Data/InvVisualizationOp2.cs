﻿using System;
using System.Collections.Generic;

namespace PDCProjectApi.Data;

public partial class InvVisualizationOp2
{
    public DateTime? CreatedDate { get; set; }

    public string? CreatedBy { get; set; }

    public DateTime? ModifiedDate { get; set; }

    public string? ModifiedBy { get; set; }

    public bool? Active { get; set; }

    public Guid Id { get; set; }

    public string? PartNo { get; set; }

    public string? PartName { get; set; }

    public string? Model { get; set; }

    public string? Unit { get; set; }

    public DateOnly? Date { get; set; }

    public double? MoLastRemain { get; set; }

    public double? MoStoreIn { get; set; }

    public double? MoStoreOut { get; set; }

    public double? MoRemain { get; set; }

    public double? PcbLastRemain { get; set; }

    public double? PcbPdc2Supply { get; set; }

    public double? PcbLendingBorrow { get; set; }

    public double? PcbLendingReturn { get; set; }

    public double? PcbRpUnit { get; set; }

    public double? PcbRemain { get; set; }

    public double? Pdc2LastRemain { get; set; }

    public double? Pdc2PoReceive { get; set; }

    public double? Pdc2InhouseSupply { get; set; }

    public double? Pdc2TlTransfer { get; set; }

    public double? Pdc2TsTransfer { get; set; }

    public double? Pdc2LendingBorrow { get; set; }

    public double? Pdc2LendingReturn { get; set; }

    public double? Pdc2SupplyPcb { get; set; }

    public double? Pdc2Remain { get; set; }

    public double? TotalRemainMo { get; set; }

    public double? TotalMoStock { get; set; }

    public double? TotalPdc2Stock { get; set; }

    public double? TotalPcbStock { get; set; }

    public double? TotalLending { get; set; }

    public double? TotalTtlRemain { get; set; }

    public string? Product { get; set; }

    public string? Vendor { get; set; }
}
