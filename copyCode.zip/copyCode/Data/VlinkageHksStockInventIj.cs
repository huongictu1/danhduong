﻿using System;
using System.Collections.Generic;

namespace PDCProjectApi.Data;

public partial class VlinkageHksStockInventIj
{
    public string? PartNo { get; set; }

    public string? Dim { get; set; }

    public string? Cp { get; set; }

    public string? Bc { get; set; }

    public string? Sp { get; set; }

    public string? Sply { get; set; }

    public string? Pccc { get; set; }

    public string? InvQty { get; set; }

    public string? Flag { get; set; }

    public string? PalletDate { get; set; }

    public string? UserEntry { get; set; }

    public string? DateEntry { get; set; }
}
