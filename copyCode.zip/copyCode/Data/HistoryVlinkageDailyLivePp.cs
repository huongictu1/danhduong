﻿using System;
using System.Collections.Generic;

namespace PDCProjectApi.Data;

public partial class HistoryVlinkageDailyLivePp
{
    public Guid Id { get; set; }

    public string Model { get; set; } = null!;

    public string FromTime { get; set; } = null!;

    public string? Plan { get; set; }

    public string? Actual { get; set; }

    public string? Product { get; set; }

    public string? PalletDate { get; set; }

    public DateTime? CreatedDate { get; set; }

    public string? Shift { get; set; }
}
