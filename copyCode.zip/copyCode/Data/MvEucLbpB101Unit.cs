﻿using System;
using System.Collections.Generic;

namespace PDCProjectApi.Data;

public partial class MvEucLbpB101Unit
{
    public string? BKey { get; set; }

    public string? BValue { get; set; }

    public DateTime? BDate { get; set; }
}
