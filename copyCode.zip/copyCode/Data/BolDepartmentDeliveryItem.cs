﻿using System;
using System.Collections.Generic;

namespace PDCProjectApi.Data;

public partial class BolDepartmentDeliveryItem
{
    public DateTime? CreatedDate { get; set; }

    public string? CreatedBy { get; set; }

    public DateTime? ModifiedDate { get; set; }

    public string? ModifiedBy { get; set; }

    public bool? Active { get; set; }

    public Guid Id { get; set; }

    public string? ApplicationNo { get; set; }

    public string? Department { get; set; }

    public string? Model { get; set; }

    public string? Phase { get; set; }

    public string? CodeDestination { get; set; }

    public string? NameDestination { get; set; }

    public double? Qty { get; set; }

    public DateOnly? DeliveryDate { get; set; }

    public double? QtyDelivery { get; set; }

    public string? BodyNo { get; set; }

    public string? Category { get; set; }

    public string? Brand { get; set; }

    public string? PartNo { get; set; }

    public string? PartName { get; set; }

    public string? PartLevel { get; set; }

    public string? ShipFrom { get; set; }

    public string? DeliveryPlace { get; set; }

    public string? RequestNo { get; set; }

    public double? QtyRemain { get; set; }

    public string? ApplicationNoDelivery { get; set; }

    public Guid? ParentId { get; set; }

    public Guid? DeptDeliveryId { get; set; }

    public string? TypeDie { get; set; }
}
