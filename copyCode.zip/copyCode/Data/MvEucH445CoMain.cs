﻿using System;
using System.Collections.Generic;

namespace PDCProjectApi.Data;

public partial class MvEucH445CoMain
{
    public string? CoKey { get; set; }

    public long? OrderNo { get; set; }

    public DateTime? CreatedDate { get; set; }
}
