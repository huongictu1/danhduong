﻿using System;
using System.Collections.Generic;

namespace PDCProjectApi.Data;

public partial class VLbpTodPairSingle
{
    public string? Pair { get; set; }

    public long? Sl { get; set; }
}
