﻿using System;
using System.Collections.Generic;

namespace PDCProjectApi.Data;

public partial class FcdelPsDestination
{
    public DateTime? CreatedDate { get; set; }

    public DateTime? ModifiedDate { get; set; }

    public string? CreatedBy { get; set; }

    public string? ModifiedBy { get; set; }

    public bool? Active { get; set; }

    public Guid Id { get; set; }

    public string? PicCode { get; set; }

    public string PicName { get; set; } = null!;

    public string Model { get; set; } = null!;

    public string Destination { get; set; } = null!;

    public DateTime DateChecking { get; set; }

    public bool? Status { get; set; }

    public virtual ICollection<FcdelPsDestinationValue> FcdelPsDestinationValues { get; set; } = new List<FcdelPsDestinationValue>();
}
