﻿using System;
using System.Collections.Generic;

namespace PDCProjectApi.Data;

public partial class FirstRecordDate
{
    public DateTime? CreatedDate { get; set; }
}
