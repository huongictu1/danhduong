﻿using System;
using System.Collections.Generic;

namespace PDCProjectApi.Data;

public partial class TodTodOutput1StockInclLbp
{
    public DateTime? CreatedDate { get; set; }

    public string? CreatedBy { get; set; }

    public DateTime? ModifiedDate { get; set; }

    public string? ModifiedBy { get; set; }

    public bool? Active { get; set; }

    public Guid Id { get; set; }

    public string PartNo { get; set; } = null!;

    public string? Alternative { get; set; }

    public string? Bc { get; set; }

    public string? OrderMethod { get; set; }

    public string? PartName { get; set; }

    public string? Model { get; set; }

    public string? Des { get; set; }

    public string? Deadline { get; set; }

    public double? Adjustment { get; set; }

    public int? Moq { get; set; }

    public int? PcsPallet { get; set; }

    public string? Vendor { get; set; }

    public string? CalcType { get; set; }

    public int? CalcOrder { get; set; }

    public DateOnly[]? TodDate { get; set; }

    public double[]? TodValue { get; set; }

    public string? Location { get; set; }

    public string? Pair { get; set; }
}
