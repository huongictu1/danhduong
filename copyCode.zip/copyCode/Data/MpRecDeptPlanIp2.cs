﻿using System;
using System.Collections.Generic;

namespace PDCProjectApi.Data;

/// <summary>
/// từng phòng up kế hoạch tuyển người
/// </summary>
public partial class MpRecDeptPlanIp2
{
    public DateTime? CreatedDate { get; set; }

    public string? CreatedBy { get; set; }

    public DateTime? ModifiedDate { get; set; }

    public string? ModifiedBy { get; set; }

    public bool? Active { get; set; }

    public Guid Id { get; set; }

    public string Model { get; set; } = null!;

    public string DeptName { get; set; } = null!;

    public DateOnly[] RecDate { get; set; } = null!;

    public int[] RecPlanF { get; set; } = null!;

    public string[] RecExplain { get; set; } = null!;

    public int[] RecPlanM { get; set; } = null!;

    public int[]? RecPlanVc { get; set; }

    public Guid? PeriodId { get; set; }

    public string? AprroveBy { get; set; }

    public DateOnly? ApproveDate { get; set; }

    public int? Status { get; set; }

    public virtual MpRecMasterPeriod? Period { get; set; }
}
