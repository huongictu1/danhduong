﻿using System;
using System.Collections.Generic;

namespace PDCProjectApi.Data;

public partial class MvDailyLivePpLbp
{
    public string? ProductCode { get; set; }

    public string? PalletDate { get; set; }

    public string? FromTime { get; set; }

    public string? ToTime { get; set; }

    public decimal? Plan { get; set; }

    public decimal? Actual { get; set; }

    public DateTime? CreatedDate { get; set; }

    public string? Shift { get; set; }
}
