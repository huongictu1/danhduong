﻿using System;
using System.Collections.Generic;

namespace PDCProjectApi.Data;

public partial class LinkageHkLivePpIj
{
    public DateTime? CreatedDate { get; set; }

    public string? CreatedBy { get; set; }

    public DateTime? ModifiedDate { get; set; }

    public string? ModifiedBy { get; set; }

    public bool? Active { get; set; }

    public Guid Id { get; set; }

    public string? ProductCode { get; set; }

    public string? LineNo { get; set; }

    public DateOnly? PalletDate { get; set; }

    public string? Shift { get; set; }

    public DateTime? FromTime { get; set; }

    public DateTime? ToTime { get; set; }

    public double? PlanQty { get; set; }

    public string? Merchandise { get; set; }

    public string? Destination { get; set; }

    public double? Actual { get; set; }
}
