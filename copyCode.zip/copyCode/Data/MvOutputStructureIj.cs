﻿using System;
using System.Collections.Generic;

namespace PDCProjectApi.Data;

public partial class MvOutputStructureIj
{
    public DateTime? DtEntry0 { get; set; }

    public string? Bc1 { get; set; }

    public string? EcnNo2 { get; set; }

    public string? EffectiveDate3 { get; set; }

    public string? EcnLevel4 { get; set; }

    public string? EffectiveDate5 { get; set; }

    public string? Ratio6 { get; set; }

    public string? PartNo8 { get; set; }

    public string? Dim9 { get; set; }

    public string? Pr10 { get; set; }

    public string? PartName11 { get; set; }

    public string? Bc12 { get; set; }

    public string? Unit13 { get; set; }

    public string? Factory17 { get; set; }

    public string? Ratio18 { get; set; }

    public string? Type19 { get; set; }

    public string? Comain22 { get; set; }

    public string? Com23 { get; set; }

    public string? MethodDelivery24 { get; set; }

    public string? Location125 { get; set; }

    public string? Location226 { get; set; }

    public string? Location327 { get; set; }

    public string? RouteDelivery28 { get; set; }

    public string? PartDelMoving29 { get; set; }

    public int? Day30 { get; set; }

    public int? Night31 { get; set; }

    public int? Week32 { get; set; }

    public string? DelLot33 { get; set; }

    public string? StdPacking34 { get; set; }

    public int? Moq35 { get; set; }

    public int? Pcsbox36 { get; set; }

    public int? Boxpl37 { get; set; }

    public int? Pcspl38 { get; set; }

    public string? Polt39 { get; set; }

    public string? Storelt40 { get; set; }

    public string? Process41 { get; set; }

    public string? DelAdjust42 { get; set; }

    public string? DoPic43 { get; set; }

    public string? PoPic44 { get; set; }

    public string[]? Model45 { get; set; }

    public string[]? Merchandise46 { get; set; }

    public string[]? MerCode47 { get; set; }

    public string[]? Value48 { get; set; }
}
