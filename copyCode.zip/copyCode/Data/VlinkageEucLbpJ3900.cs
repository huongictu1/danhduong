﻿using System;
using System.Collections.Generic;

namespace PDCProjectApi.Data;

public partial class VlinkageEucLbpJ3900
{
    public string? CdDataCntl { get; set; }

    public string? NoInvoice { get; set; }

    public string? NoPo { get; set; }

    public string? CdUseBlock { get; set; }

    public string? CdSply { get; set; }

    public string? NoParts { get; set; }

    public string? NoAdjDim { get; set; }

    public string? QtOrd { get; set; }

    public string? QtCustClea { get; set; }

    public string? DtDelv { get; set; }

    public string? PrUnitPurch { get; set; }

    public string? DtEtd { get; set; }

    public string? DtEta { get; set; }

    public string? DtCustClea { get; set; }

    public string? DtEntry { get; set; }

    public string? NmEntryPerson { get; set; }

    public string? DtRenew { get; set; }

    public string? NmRenewPerson { get; set; }

    public string? DtActResRec { get; set; }
}
