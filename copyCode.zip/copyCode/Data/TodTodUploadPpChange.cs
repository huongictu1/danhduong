﻿using System;
using System.Collections.Generic;

namespace PDCProjectApi.Data;

public partial class TodTodUploadPpChange
{
    public DateTime? CreatedDate { get; set; }

    public string? CreatedBy { get; set; }

    public DateTime? ModifiedDate { get; set; }

    public string? ModifiedBy { get; set; }

    public bool? Active { get; set; }

    public Guid Id { get; set; }

    public string MerchandiseCode { get; set; } = null!;

    public int QtyChange { get; set; }

    public DateOnly DateChange { get; set; }

    public string ReasonChange { get; set; } = null!;

    public DateTime? ApprovedDate { get; set; }

    public string? ApprovedBy { get; set; }

    public string Model { get; set; } = null!;

    public string? Product { get; set; }

    public bool? IsChange { get; set; }
}
