﻿using System;
using System.Collections.Generic;

namespace PDCProjectApi.Data;

public partial class VHksAiRestTimeIj2
{
    public string? LineNo { get; set; }

    public int? FromHour { get; set; }

    public int? FromMinute { get; set; }

    public int? ToHour { get; set; }

    public int? ToMinute { get; set; }

    public int[]? RestBlock { get; set; }

    public string[]? RestTime { get; set; }

    public string? Note { get; set; }
}
