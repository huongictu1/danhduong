﻿using System;
using System.Collections.Generic;

namespace PDCProjectApi.Data;

public partial class InvIp2Packing
{
    public DateTime? CreatedDate { get; set; }

    public string? CreatedBy { get; set; }

    public DateTime? ModifiedDate { get; set; }

    public string? ModifiedBy { get; set; }

    public bool? Active { get; set; }

    public Guid Id { get; set; }

    public string? Product { get; set; }

    public string? PartNo { get; set; }

    public string? Vendor { get; set; }

    public string? PackingMethod { get; set; }

    public string? InvMethod { get; set; }

    public DateOnly? InvDate { get; set; }

    public double? PiQty { get; set; }

    public DateOnly? PiDate { get; set; }

    public double? OmittedQty { get; set; }

    public DateOnly? OmittedDate { get; set; }

    public double? UrgentQt { get; set; }

    public DateOnly? UrgentDate { get; set; }
}
