﻿using System;
using System.Collections.Generic;

namespace PDCProjectApi.Data;

public partial class VlinkageEucLbpE900
{
    public string? NoTransaction { get; set; }

    public string? CdFact { get; set; }

    public string? NoParts { get; set; }

    public string? NoAdjDim { get; set; }

    public string? NoInventCntlPoi { get; set; }

    public string? NoSlip { get; set; }

    public string? MkProcess { get; set; }

    public string? CdOccurrenceArea { get; set; }

    public string? CdResponsArea { get; set; }

    public double? QtFluct { get; set; }

    public double? CtAll { get; set; }

    public double? Amount { get; set; }

    public string? CdLossPartsReason { get; set; }

    public string? CdInoutStorage { get; set; }

    public string? DtInventFluct { get; set; }
}
