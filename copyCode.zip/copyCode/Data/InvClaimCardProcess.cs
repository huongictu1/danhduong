﻿using System;
using System.Collections.Generic;

namespace PDCProjectApi.Data;

public partial class InvClaimCardProcess
{
    public DateTime? CreatedDate { get; set; }

    public string? CreatedBy { get; set; }

    public DateTime? ModifiedDate { get; set; }

    public string? ModifiedBy { get; set; }

    public bool? Active { get; set; }

    public Guid Id { get; set; }

    public string ClaimCardNo { get; set; } = null!;

    public string? ConfirmBy { get; set; }

    public string? CheckBy { get; set; }

    public string? ApproveBy { get; set; }

    public int? Step { get; set; }

    public bool? Next { get; set; }

    public bool? IsSupplier { get; set; }

    public string? GroupName { get; set; }

    public DateOnly? DateConfirm { get; set; }
}
