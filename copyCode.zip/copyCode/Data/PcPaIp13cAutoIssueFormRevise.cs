﻿using System;
using System.Collections.Generic;

namespace PDCProjectApi.Data;

/// <summary>
/// với bảng 13a action bằng Revise &amp; Hand &amp; hand
/// </summary>
public partial class PcPaIp13cAutoIssueFormRevise
{
    public DateTime? CreatedDate { get; set; }

    public string? CreatedBy { get; set; }

    public DateTime? ModifiedDate { get; set; }

    public string? ModifiedBy { get; set; }

    public bool? Active { get; set; }

    public Guid Id { get; set; }

    public string PartNo { get; set; } = null!;

    public string Vendor { get; set; } = null!;

    public string? Dim { get; set; }

    public string? Drawing { get; set; }

    public int? OrderQuantity { get; set; }

    public string? DeliveryDate { get; set; }

    public string? MainBody { get; set; }

    public string? Action { get; set; }

    public string? Product { get; set; }

    public string? UsedBy { get; set; }

    public string? IndividualOrder { get; set; }

    public string? Um { get; set; }

    public string? ShippingMethod { get; set; }

    public string? TransportMethod { get; set; }

    public string? Reason { get; set; }

    public string? Remark { get; set; }

    public string? No { get; set; }

    public Guid? RqId { get; set; }

    public string? DeliveryKeyNo { get; set; }

    public virtual PcPaRequestRevisePo? Rq { get; set; }
}
