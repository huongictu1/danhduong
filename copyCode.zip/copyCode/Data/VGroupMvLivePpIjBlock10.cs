﻿using System;
using System.Collections.Generic;

namespace PDCProjectApi.Data;

public partial class VGroupMvLivePpIjBlock10
{
    public string? BKey { get; set; }

    public double? ActualQty { get; set; }

    public double? PlanQty { get; set; }
}
