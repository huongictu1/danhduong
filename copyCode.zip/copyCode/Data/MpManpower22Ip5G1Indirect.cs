﻿using System;
using System.Collections.Generic;

namespace PDCProjectApi.Data;

public partial class MpManpower22Ip5G1Indirect
{
    public DateTime? CreatedDate { get; set; }

    public string? CreatedBy { get; set; }

    public DateTime? ModifiedDate { get; set; }

    public string? ModifiedBy { get; set; }

    public bool? Active { get; set; }

    public Guid Id { get; set; }

    public string? Group { get; set; }

    public string? Fixed { get; set; }

    public string? Kind { get; set; }

    public int? OrderNo { get; set; }

    public string? DeptCode { get; set; }

    public string? IjValue { get; set; }

    public string? LbpValue { get; set; }
}
