﻿using System;
using System.Collections.Generic;

namespace PDCProjectApi.Data;

public partial class VHksLivePpPriority
{
    public string? DateTime { get; set; }

    public string? ProductCode { get; set; }

    public string? LineNo { get; set; }

    public string? Merchandise { get; set; }

    public string? Priority { get; set; }

    public string? Destination { get; set; }

    public string? Shift { get; set; }

    public double? TotalPlanQty { get; set; }

    public string? Product { get; set; }
}
