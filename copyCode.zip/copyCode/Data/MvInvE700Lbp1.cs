﻿using System;
using System.Collections.Generic;

namespace PDCProjectApi.Data;

public partial class MvInvE700Lbp1
{
    public string? NoParts { get; set; }

    public string? NoSlip { get; set; }

    public int? DtInventFluct { get; set; }

    public int? TmInventFluct { get; set; }

    public string? CdInoutStorage { get; set; }

    public string? NoFlctToStockPoi { get; set; }

    public string? NoFlctFrmStockPoi { get; set; }

    public double? QtFlctAfterFrm { get; set; }

    public double? QtFlctAfterTo { get; set; }

    public double? QtFluct { get; set; }

    public DateTime? CreatedDate { get; set; }
}
