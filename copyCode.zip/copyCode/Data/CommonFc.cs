﻿using System;
using System.Collections.Generic;

namespace PDCProjectApi.Data;

public partial class CommonFc
{
    public string? DeliveryRoute { get; set; }

    public string? Location { get; set; }

    public string? VendorCode { get; set; }

    public string? VendorName { get; set; }
}
