﻿using System;
using System.Collections.Generic;

namespace PDCProjectApi.Data;

public partial class HistoryTodStructureMasterDelivery
{
    public Guid? Id { get; set; }

    public DateTime? CreatedDate { get; set; }

    public string? CreatedBy { get; set; }

    public string? ApprovedBy { get; set; }

    public DateTime? ApprovedDate { get; set; }

    public string? Product { get; set; }

    public string? VendorCode { get; set; }

    public string? Location1 { get; set; }

    public string? Location2 { get; set; }

    public string? Location3 { get; set; }

    public string? MethodDelivery { get; set; }

    public string? RouteDelivery { get; set; }

    public string? DelivFreqType { get; set; }

    public int? DelivFreqDay { get; set; }

    public int? DelivFreqNight { get; set; }

    public int? DelivFreqWeek { get; set; }

    public string? DelivLocaNpis { get; set; }

    public string? DelivLocaActual { get; set; }

    public string? PartDelivMoving { get; set; }

    public int? TotalPartOrder { get; set; }

    public bool? Active { get; set; }

    public Guid IdHistory { get; set; }

    public DateTime? DateHistory { get; set; }
}
