﻿using System;
using System.Collections.Generic;

namespace PDCProjectApi.Data;

public partial class LtFormRegistrationIhInfor
{
    public DateTime? CreatedDate { get; set; }

    public string? CreatedBy { get; set; }

    public DateTime? ModifiedDate { get; set; }

    public string? ModifiedBy { get; set; }

    public bool? Active { get; set; }

    public Guid Id { get; set; }

    public string? RequestNo { get; set; }

    public string? RequestBy { get; set; }

    public string? Department { get; set; }

    public int? Status { get; set; }

    public string? Note { get; set; }
}
