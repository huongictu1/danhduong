﻿using System;
using System.Collections.Generic;

namespace PDCProjectApi.Data;

public partial class LtFormRegistrationAssyProcess
{
    public DateTime? CreatedDate { get; set; }

    public string? CreatedBy { get; set; }

    public DateTime? ModifiedDate { get; set; }

    public string? ModifiedBy { get; set; }

    public bool? Active { get; set; }

    public Guid Id { get; set; }

    public string? RequestNo { get; set; }

    public string? Approver { get; set; }

    public string? ApprovedDate { get; set; }

    public string? Comment { get; set; }

    public bool? Next { get; set; }

    public int? Status { get; set; }

    public int? OrderNo { get; set; }

    public string? Grade { get; set; }

    public string? ApproverName { get; set; }
}
