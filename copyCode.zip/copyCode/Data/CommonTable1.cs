﻿using System;
using System.Collections.Generic;

namespace PDCProjectApi.Data;

public partial class CommonTable1
{
    public DateTime? CreatedDate { get; set; }

    public string? CreatedBy { get; set; }

    public DateTime? ModifiedDate { get; set; }

    public string? ModifiedBy { get; set; }

    public bool? Active { get; set; }

    public Guid Id { get; set; }
}
