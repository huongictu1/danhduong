﻿using System;
using System.Collections.Generic;

namespace PDCProjectApi.Data;

public partial class AdmUserInformation
{
    public DateTime? CreatedDate { get; set; }

    public string? CreatedBy { get; set; }

    public DateTime? ModifiedDate { get; set; }

    public string? ModifiedBy { get; set; }

    public bool? Active { get; set; }

    public Guid Id { get; set; }

    public string? EmployeeCode { get; set; }

    public string? Password { get; set; }

    public bool? Status { get; set; }

    public string? PathImage { get; set; }

    public string? Token { get; set; }

    public string? FullName { get; set; }

    public string? Email { get; set; }

    public bool? IsAdmin { get; set; }

    public Guid? StatusId { get; set; }

    public string? Approver { get; set; }

    public DateTime? ApproveDate { get; set; }

    public string? RegisteredBy { get; set; }

    public string? Purpose { get; set; }

    public virtual ICollection<AdmDetailUserDept> AdmDetailUserDepts { get; set; } = new List<AdmDetailUserDept>();

    public virtual ICollection<AdmDetailUserGroup> AdmDetailUserGroups { get; set; } = new List<AdmDetailUserGroup>();

    public virtual ICollection<AdmDetailUserPageReadOnly> AdmDetailUserPageReadOnlies { get; set; } = new List<AdmDetailUserPageReadOnly>();

    public virtual AdmMasterStatus? StatusNavigation { get; set; }
}
