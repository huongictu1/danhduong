﻿using System;
using System.Collections.Generic;

namespace PDCProjectApi.Data;

public partial class PcSimulationSmTimeOp8Lbp
{
    public DateTime? CreatedDate { get; set; }

    public string? CreatedBy { get; set; }

    public DateTime? ModifiedDate { get; set; }

    public string? ModifiedBy { get; set; }

    public bool? Active { get; set; }

    public Guid Id { get; set; }

    public string Bc { get; set; } = null!;

    public string PartNo { get; set; } = null!;

    public string? Dim { get; set; }

    public string? PartMovingRoute { get; set; }

    public string PartName { get; set; } = null!;

    public string Vendor { get; set; } = null!;

    public string MoqOrder { get; set; } = null!;

    public string? Model { get; set; }

    public string? Destination { get; set; }

    public string? MainAlt { get; set; }

    public string? Factory { get; set; }

    public string? Ratio { get; set; }

    public string? EffectivedateChange { get; set; }

    public string? RatioChange { get; set; }

    public string? DoPic { get; set; }

    public string? PoPic { get; set; }

    public string? Pair { get; set; }

    public DateOnly? DeadlineDate { get; set; }

    public TimeOnly? DeadlineTime { get; set; }

    public string? Reason { get; set; }

    public string? Action { get; set; }

    public DateOnly[] DateRange { get; set; } = null!;

    public double[] DsStock { get; set; } = null!;

    public double[] DsPp { get; set; } = null!;

    public double[] DsDo { get; set; } = null!;

    public double[] DsRemain { get; set; } = null!;

    public double[] NsPp { get; set; } = null!;

    public double[] NsDo { get; set; } = null!;

    public double[] NsRemain { get; set; } = null!;

    public string[]? DateDeadline { get; set; }

    public double[]? DsLackover { get; set; }

    public double[]? NsLackover { get; set; }

    public string? Hightlight { get; set; }
}
