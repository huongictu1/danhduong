﻿using System;
using System.Collections.Generic;

namespace PDCProjectApi.Data;

public partial class VEucJ1001
{
    public string? Vendor { get; set; }

    public string? PartNo { get; set; }

    public string? OrderMethod1 { get; set; }

    public string? PoLeadTime { get; set; }

    public string? Product { get; set; }
}
