﻿using System;
using System.Collections.Generic;

namespace PDCProjectApi.Data;

public partial class MpManpower2Op4
{
    public DateTime? CreatedDate { get; set; }

    public string? CreatedBy { get; set; }

    public DateTime? ModifiedDate { get; set; }

    public string? ModifiedBy { get; set; }

    public bool? Active { get; set; }

    public Guid Id { get; set; }

    public DateOnly? Date { get; set; }

    public string? Model { get; set; }

    public string? Cell { get; set; }

    public string? Type { get; set; }

    public DateOnly? HireDate { get; set; }

    public DateOnly? MpDate { get; set; }

    public string? OpCellAssy { get; set; }

    public string? OpCellPdc2 { get; set; }

    public string? Remark { get; set; }

    public string? Fact { get; set; }

    public string? Color { get; set; }

    public string? Group { get; set; }

    public string? Version { get; set; }

    public string? Product { get; set; }
}
