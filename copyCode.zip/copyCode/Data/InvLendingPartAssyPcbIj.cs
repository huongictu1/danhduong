﻿using System;
using System.Collections.Generic;

namespace PDCProjectApi.Data;

public partial class InvLendingPartAssyPcbIj
{
    public string? PartNumber { get; set; }

    public double? QtyBorrow { get; set; }

    public double? QtyReturn { get; set; }

    public double? QtyDefect { get; set; }

    public DateOnly? BorrowDate { get; set; }

    public Guid Id { get; set; }

    public DateOnly? CreatedDate { get; set; }
}
