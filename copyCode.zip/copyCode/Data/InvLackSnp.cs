﻿using System;
using System.Collections.Generic;

namespace PDCProjectApi.Data;

public partial class InvLackSnp
{
    public DateTime? CreatedDate { get; set; }

    public string? CreatedBy { get; set; }

    public DateTime? ModifiedDate { get; set; }

    public string? ModifiedBy { get; set; }

    public bool? Active { get; set; }

    public Guid Id { get; set; }

    public string? Term { get; set; }

    public string? ClaimCardNo { get; set; }

    public DateOnly? DetectedDate { get; set; }

    public string? Vendor { get; set; }

    public string? KindOfPart { get; set; }

    public string? Sp { get; set; }

    public string? PartNo { get; set; }

    public string? PartName { get; set; }

    public string? MmPic { get; set; }

    public double? Snp { get; set; }

    public double? ActualQty { get; set; }

    public double? LackingQty { get; set; }

    public string? ProductionOnDate { get; set; }

    public DateOnly? DeliveryDate { get; set; }

    public string? DetectBy { get; set; }

    public DateOnly? IssuedDate { get; set; }

    public DateOnly? SendingPurDate { get; set; }

    public string? Issuer { get; set; }

    public DateOnly? PlanReceive { get; set; }

    public DateOnly? ActualReceiveDate { get; set; }

    public double? QtyReceive { get; set; }

    public string? NotReplace { get; set; }

    public string? FinalStatus { get; set; }

    public string? Remark { get; set; }

    public int? RepeatTime { get; set; }

    public string? VendorFeedback { get; set; }

    public string? BuyerConfirm { get; set; }

    public string? Product { get; set; }

    public int? Time { get; set; }

    public string? PurConfirmPlan { get; set; }

    public bool? IsPurStep { get; set; }
}
