﻿using System;
using System.Collections.Generic;

namespace PDCProjectApi.Data;

public partial class PcPaOp23Revise
{
    public string? ProcessingFlag { get; set; }

    public string? Factory { get; set; }

    public string Vendor { get; set; } = null!;

    public string PartsNo { get; set; } = null!;

    public string? OrderNo { get; set; }

    public string? PartialPoNo { get; set; }

    public string? CrDrawingNumber { get; set; }

    public string? CrChangeHistoryCode { get; set; }

    public string? CrDeliveryDate { get; set; }

    public string? CrDeliveryTime { get; set; }

    public string? CrQty { get; set; }

    public string? CrDeliveryLocation { get; set; }

    public string? CrUsedbyBc { get; set; }

    public string? CrReceivingPointCode { get; set; }

    public string? CrTransportMethod { get; set; }

    public string? CrDepartingPort { get; set; }

    public string? CrArrivingPort { get; set; }

    public string? CrContainerLoading { get; set; }

    public DateTime? CreatedDate { get; set; }

    public string? CreatedBy { get; set; }

    public DateTime? ModifiedDate { get; set; }

    public string? ModifiedBy { get; set; }

    public bool? Active { get; set; }

    public Guid? RequestId { get; set; }

    public Guid Id { get; set; }
}
