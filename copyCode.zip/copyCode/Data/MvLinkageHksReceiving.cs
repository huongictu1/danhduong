﻿using System;
using System.Collections.Generic;

namespace PDCProjectApi.Data;

public partial class MvLinkageHksReceiving
{
    public string? DateEntry { get; set; }

    public string? UserEntry { get; set; }

    public string? DateUpdate { get; set; }

    public string? UserUpdate { get; set; }

    public string? PartNo { get; set; }

    public string? Vendor { get; set; }

    public string? QtyPlan { get; set; }

    public string? Location { get; set; }

    public string? DeliveryKey { get; set; }

    public string? ActQty { get; set; }

    public string? DifferQty { get; set; }

    public string? Unloading { get; set; }

    public string? TimeReceive { get; set; }

    public string? UserReceive { get; set; }

    public string? Reason { get; set; }

    public string? Remark { get; set; }

    public string? TimeLate { get; set; }

    public string? TruckSize { get; set; }

    public string? LeaderConfirm { get; set; }

    public string? TimeConfirm { get; set; }

    public string? DateDelivery { get; set; }

    public string? TimeDelivery { get; set; }

    public string? Status { get; set; }

    public string? Flag { get; set; }

    public string? SubfixActual { get; set; }

    public string? DtEntry { get; set; }

    public string? PoStatus { get; set; }

    public string? BoxQty { get; set; }

    public string? UnitQty { get; set; }

    public string? BoxCode { get; set; }

    public string? Inspection { get; set; }

    public string? InsReviseFlag { get; set; }

    public string? Ecn { get; set; }

    public string? NoDraw { get; set; }

    public string? CdDestin { get; set; }

    public string? UnitBox { get; set; }

    public string? Gate { get; set; }

    public string? Ins { get; set; }

    public string? LateInput { get; set; }

    public string? DateUpdateInput { get; set; }

    public string? UserUpdateInput { get; set; }

    public string? PucUserConfirm { get; set; }

    public string? PucDateConfirm { get; set; }

    public string? NgQty { get; set; }

    public string? InvoiceNo { get; set; }

    public string? RpNo { get; set; }

    public string? NoDs { get; set; }

    public string? SubfixPlan { get; set; }

    public string? MhConfirm { get; set; }

    public string? Solution { get; set; }

    public string? Approve { get; set; }

    public string? PurConfirm { get; set; }

    public string? PurSolution { get; set; }

    public string? PurApprove { get; set; }

    public string? PurClose { get; set; }

    public string? LogConfirm { get; set; }

    public string? LogSolution { get; set; }

    public string? LogApprove { get; set; }

    public string? LogClose { get; set; }

    public string? PurAttack { get; set; }

    public string? UserCheck { get; set; }

    public string? Pdc2Check { get; set; }

    public string? StatusCheck { get; set; }

    public string? FinalDept { get; set; }

    public string? StatusRec { get; set; }

    public string? StatusMh { get; set; }

    public string? StatusPur { get; set; }

    public string? StatusLog { get; set; }

    public string? UserMhConfirm { get; set; }

    public string? UserPurConfirm { get; set; }

    public string? UserLogConfirm { get; set; }

    public string? Responsibility { get; set; }

    public string? TimeMhConfirm { get; set; }

    public string? TimePurConfirm { get; set; }

    public string? TimeLogConfirm { get; set; }

    public string? MhClose { get; set; }

    public string? FinishTime { get; set; }

    public string? SyntheticStatus { get; set; }

    public string? TotalTime { get; set; }

    public string? UserUpdateStatus { get; set; }

    public string? DateUpdateStatus { get; set; }

    public string? QrcodeQty { get; set; }

    public string? Finished { get; set; }

    public string? IdStt { get; set; }

    public string? CheckEcnNo { get; set; }

    public string? KindOfItem { get; set; }

    public string? TimeSendRp { get; set; }

    public string? ApprovalRp { get; set; }

    public string? DateApprovalRp { get; set; }

    public string? ApprovalRpCancel { get; set; }

    public string? DateApprovalRpCancel { get; set; }

    public string? UploadNew { get; set; }

    public string? UploadNewCancel { get; set; }

    public string? TimeReceiveOld { get; set; }

    public string? FinishSendRp { get; set; }

    public string? UserApprovalRp { get; set; }

    public DateTime? CreatedDate { get; set; }
}
