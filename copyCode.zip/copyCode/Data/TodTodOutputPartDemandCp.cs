﻿using System;
using System.Collections.Generic;

namespace PDCProjectApi.Data;

public partial class TodTodOutputPartDemandCp
{
    public DateTime? CreatedDate { get; set; }

    public string? CreatedBy { get; set; }

    public DateTime? ModifiedDate { get; set; }

    public string? ModifiedBy { get; set; }

    public bool? Active { get; set; }

    public Guid Id { get; set; }

    public string UserBy { get; set; } = null!;

    public string PartNo { get; set; } = null!;

    public string Bc { get; set; } = null!;

    public string Ratio { get; set; } = null!;

    public string[]? MerName { get; set; }

    public double[]? MerValue { get; set; }

    public DateOnly[]? ChangeDate { get; set; }

    public double[]? ChangeValue { get; set; }
}
