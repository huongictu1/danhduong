﻿using System;
using System.Collections.Generic;

namespace PDCProjectApi.Data;

public partial class TodTodOutput4CommonIj
{
    public DateTime? CreatedDate { get; set; }

    public string? CreatedBy { get; set; }

    public DateTime? ModifiedDate { get; set; }

    public string? ModifiedBy { get; set; }

    public bool? Active { get; set; }

    public Guid Id { get; set; }

    public string? Bc { get; set; }

    public string? PartNo { get; set; }

    public string? Alternative { get; set; }

    public string? PartName { get; set; }

    public string? Vendor { get; set; }

    public string? Model { get; set; }

    public string? Destination { get; set; }

    public double? UnitPrice { get; set; }

    public string? OrderMethod { get; set; }

    public string? Location1 { get; set; }

    public double? StockPlan { get; set; }

    public double? StockActual { get; set; }

    public double? AbnormalStockPcs { get; set; }

    public double? AbnormalStockPallet { get; set; }

    public double? ToPlan { get; set; }

    public double? ToActual { get; set; }

    public double? StockPlanPallet { get; set; }

    public double? StockActualPallet { get; set; }

    public double? InvPlan { get; set; }

    public double? InvActual { get; set; }

    public double? InvAbnormal { get; set; }

    public DateOnly? CalcDate { get; set; }

    public double? PcsPallet { get; set; }
}
