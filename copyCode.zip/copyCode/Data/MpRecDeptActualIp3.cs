﻿using System;
using System.Collections.Generic;

namespace PDCProjectApi.Data;

/// <summary>
/// thực tế tuyển dụng tại phòng ban
/// </summary>
public partial class MpRecDeptActualIp3
{
    public DateTime? CreatedDate { get; set; }

    public string? CreatedBy { get; set; }

    public DateTime? ModifiedDate { get; set; }

    public string? ModifiedBy { get; set; }

    public bool? Active { get; set; }

    public Guid Id { get; set; }

    public string Model { get; set; } = null!;

    public string DeptName { get; set; } = null!;

    public DateOnly[] RecDate { get; set; } = null!;

    public int[] RecActualF { get; set; } = null!;

    public int[] RecActualM { get; set; } = null!;

    public int[] RecActualVc { get; set; } = null!;

    public Guid? PeriodId { get; set; }

    public virtual MpRecMasterPeriod? Period { get; set; }
}
