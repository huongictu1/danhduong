﻿using System;
using System.Collections.Generic;

namespace PDCProjectApi.Data;

public partial class VGroupMvLivePpIjBlock10CountLine
{
    public string? PalletDate { get; set; }

    public string? Merchandise { get; set; }

    public string? BTime { get; set; }

    public long? CountLine { get; set; }
}
