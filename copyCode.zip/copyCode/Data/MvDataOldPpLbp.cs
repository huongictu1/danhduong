﻿using System;
using System.Collections.Generic;

namespace PDCProjectApi.Data;

public partial class MvDataOldPpLbp
{
    public string? ProductCode { get; set; }

    public string? DateTime { get; set; }

    public decimal? Plan { get; set; }

    public decimal? Actual { get; set; }
}
