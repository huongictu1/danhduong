﻿using System;
using System.Collections.Generic;

namespace PDCProjectApi.Data;

public partial class LinkageEucIjD101
{
    public Guid Id { get; set; }

    public DateTime? CreatedDate { get; set; }

    public bool? Active { get; set; }

    public string NoParts { get; set; } = null!;

    public string NoAdjDim { get; set; } = null!;

    public string? NoInventCntlPoi { get; set; }

    public string? CtAll { get; set; }

    public string CdBlock { get; set; } = null!;

    public string? NmPartsLocal { get; set; }
}
