﻿using System;
using System.Collections.Generic;

namespace PDCProjectApi.Data;

public partial class Schema
{
    public int Version { get; set; }
}
