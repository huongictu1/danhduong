﻿using System;
using System.Collections.Generic;

namespace PDCProjectApi.Data;

public partial class InvSnpDetail
{
    public DateTime? CreatedDate { get; set; }

    public string? CreatedBy { get; set; }

    public DateTime? ModifiedDate { get; set; }

    public string? ModifiedBy { get; set; }

    public bool? Active { get; set; }

    public Guid Id { get; set; }

    public double? SnpCheck { get; set; }

    public double? Actual { get; set; }

    public double? Differ { get; set; }

    public double? Ratio { get; set; }

    public string? DetectedBy { get; set; }

    public DateOnly? CheckDate { get; set; }

    public Guid SnpId { get; set; }

    public int? Time { get; set; }

    public string? ProductionLot { get; set; }

    public virtual InvSnp Snp { get; set; } = null!;
}
