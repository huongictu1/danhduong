﻿using System;
using System.Collections.Generic;

namespace PDCProjectApi.Data;

/// <summary>
/// danh sách các phòng sử dụng manpower
/// </summary>
public partial class MpRecMasterDept
{
    public DateTime? CreatedDate { get; set; }

    public string? CreatedBy { get; set; }

    public DateTime? ModifiedDate { get; set; }

    public string? ModifiedBy { get; set; }

    public bool? Active { get; set; }

    public Guid Id { get; set; }

    public string DeptName { get; set; } = null!;

    public int DeptOrder { get; set; }

    public Guid[]? DeptId { get; set; }
}
