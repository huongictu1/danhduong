﻿using System;
using System.Collections.Generic;

namespace PDCProjectApi.Data;

public partial class VlinkageHksDailyMaster
{
    public string? CodeControl { get; set; }

    public DateTime? DateEntry { get; set; }

    public string? UserEntry { get; set; }

    public DateTime? DateUpdate { get; set; }

    public string? UserUpdate { get; set; }

    public string? LineNo { get; set; }

    public string? Merchandise { get; set; }

    public int? OpQt { get; set; }

    public string? SppQt { get; set; }

    public int? LdQt { get; set; }

    public int? StopLine { get; set; }

    public double? WorkFactor { get; set; }

    public double? StdTime { get; set; }

    public int? TarQt { get; set; }

    public int? OtQt { get; set; }

    public int? NorTime { get; set; }

    public string? OtTime { get; set; }

    public string? MealTime { get; set; }

    public int? OldopQt { get; set; }

    public int? NewopQt { get; set; }

    public string? PalletDate { get; set; }

    public string? TypeTime { get; set; }

    public string? SubTime { get; set; }

    public string? OtFrom { get; set; }

    public string? OtTo { get; set; }

    public string? EntryT { get; set; }

    public string? Absent { get; set; }

    public string? Support { get; set; }

    public string? Multi { get; set; }

    public string? AttRate { get; set; }

    public string? StopTime { get; set; }
}
