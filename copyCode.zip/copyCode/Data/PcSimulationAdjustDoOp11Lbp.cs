﻿using System;
using System.Collections.Generic;

namespace PDCProjectApi.Data;

public partial class PcSimulationAdjustDoOp11Lbp
{
    public DateTime? CreatedDate { get; set; }

    public string? CreatedBy { get; set; }

    public DateTime? ModifiedDate { get; set; }

    public string? ModifiedBy { get; set; }

    public bool? Active { get; set; }

    public Guid Id { get; set; }

    public string Bc { get; set; } = null!;

    public string PartNo { get; set; } = null!;

    public string Vendor { get; set; } = null!;

    public double? AdjustQty { get; set; }

    public string? DateDelivery { get; set; }

    public string? TimeDelivery { get; set; }

    public string? PoKey { get; set; }

    public string? Note { get; set; }
}
