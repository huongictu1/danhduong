﻿using System;
using System.Collections.Generic;

namespace PDCProjectApi.Data;

public partial class InvVisualizationOp1
{
    public DateTime? CreatedDate { get; set; }

    public string? CreatedBy { get; set; }

    public DateTime? ModifiedDate { get; set; }

    public string? ModifiedBy { get; set; }

    public bool? Active { get; set; }

    public Guid Id { get; set; }

    public string? PartNo { get; set; }

    public string? PartName { get; set; }

    public string? Model { get; set; }

    public string? Dest { get; set; }

    public DateOnly? Date { get; set; }

    public double? MoLastRemain { get; set; }

    public double? MoStoreIn { get; set; }

    public double? MoStoreOut { get; set; }

    public double? MoStoreOutS { get; set; }

    public double? MoRemain { get; set; }

    public double? MsdLastRemain { get; set; }

    public double? MsdStoreIn { get; set; }

    public double? MsdStoreOut { get; set; }

    public double? MsdStoreOutS { get; set; }

    public double? MsdRemain { get; set; }

    public double? PcbLastRemain { get; set; }

    public double? PcbStoreIn { get; set; }

    public double? PcbStoreOut { get; set; }

    public double? PcbStoreOutS { get; set; }

    public double? PcbRemain { get; set; }

    public double? Pdc2LastRemain { get; set; }

    public double? Pdc2PoReceive { get; set; }

    public double? Pdc2InhouseTransfer { get; set; }

    public double? Pdc2Shikyu { get; set; }

    public double? Pdc2LendingBorrow { get; set; }

    public double? Pdc2LendingReturn { get; set; }

    public double? Pdc2SupplyAssy { get; set; }

    public double? Pdc2Remain { get; set; }

    public double? LogLastRemain { get; set; }

    public double? LogPoReceive { get; set; }

    public double? LogLendingBorrow { get; set; }

    public double? LogLendingReturn { get; set; }

    public double? LogSupplyAssy { get; set; }

    public double? LogRemain { get; set; }

    public double? AssyLastRemain { get; set; }

    public double? AssyPdc2Supply { get; set; }

    public double? AssyLendingBorrow { get; set; }

    public double? AssyLendingReturn { get; set; }

    public double? AssyRpMachine { get; set; }

    public double? AssyRemain { get; set; }

    public double? TotalRemainMo { get; set; }

    public double? TotalRemainMsd { get; set; }

    public double? TotalRemainPcb { get; set; }

    public double? TotalRemainPdc2Rec { get; set; }

    public double? TotalRemainPdc2Store { get; set; }

    public double? TotalRemainLog { get; set; }

    public double? TotalRemainAssy { get; set; }

    public double? TotalRemainLending { get; set; }

    public double? TotalRemainTtl { get; set; }

    public string? Product { get; set; }

    public string? Vendor { get; set; }

    public double? Pdc2LastRemainStore { get; set; }

    public double? Pdc2RemainStore { get; set; }
}
