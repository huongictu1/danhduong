﻿using System;
using System.Collections.Generic;

namespace PDCProjectApi.Data;

public partial class InvLendingPartPdcIj
{
    public Guid Id { get; set; }

    public string? PartNumber { get; set; }

    public double? QtyBorrow { get; set; }

    public double? QtyReturn { get; set; }

    public DateOnly? BorrowDate { get; set; }

    public DateOnly? CreatedDate { get; set; }
}
