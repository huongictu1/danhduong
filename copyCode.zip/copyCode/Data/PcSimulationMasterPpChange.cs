﻿using System;
using System.Collections.Generic;

namespace PDCProjectApi.Data;

public partial class PcSimulationMasterPpChange
{
    public DateTime? CreatedDate { get; set; }

    public string? CreatedBy { get; set; }

    public DateTime? ModifiedDate { get; set; }

    public string? ModifiedBy { get; set; }

    public bool? Active { get; set; }

    public Guid Id { get; set; }

    public string Model { get; set; } = null!;

    public string Merchandise { get; set; } = null!;

    public string LineNo { get; set; } = null!;

    public DateTime FromDate { get; set; }

    public DateTime ToDate { get; set; }

    public string Shift { get; set; } = null!;

    public double Step { get; set; }

    public string? Reason { get; set; }

    public double AdjQty { get; set; }

    public string? ApprovedBy { get; set; }

    public DateTime? ApprovedDate { get; set; }

    public string? Product { get; set; }
}
