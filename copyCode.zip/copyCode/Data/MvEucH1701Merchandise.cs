﻿using System;
using System.Collections.Generic;

namespace PDCProjectApi.Data;

public partial class MvEucH1701Merchandise
{
    public string? MerKey { get; set; }

    public string? Merchandise { get; set; }

    public DateTime? CreatedDate { get; set; }
}
