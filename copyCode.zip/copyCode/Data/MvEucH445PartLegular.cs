﻿using System;
using System.Collections.Generic;

namespace PDCProjectApi.Data;

public partial class MvEucH445PartLegular
{
    public string? PartsKey { get; set; }

    public string? NoLegular { get; set; }

    public DateTime? CreatedDate { get; set; }
}
