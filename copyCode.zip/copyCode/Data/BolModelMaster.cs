﻿using System;
using System.Collections.Generic;

namespace PDCProjectApi.Data;

public partial class BolModelMaster
{
    public DateTime? CreatedDate { get; set; }

    public string? CreatedBy { get; set; }

    public DateTime? ModifiedDate { get; set; }

    public string? ModifiedBy { get; set; }

    public bool? Active { get; set; }

    public Guid Id { get; set; }

    public string? Model { get; set; }

    public string? Phase { get; set; }

    public string? Brand { get; set; }

    public DateOnly? DeadlineDisposal { get; set; }

    public DateOnly? MtDate { get; set; }

    public DateOnly? MpDate { get; set; }

    public DateOnly? MarketDate { get; set; }

    public string? ModelMemberList { get; set; }

    public string? Evidence { get; set; }

    public DateOnly? DateCanDisposal { get; set; }

    public DateOnly? ActualDiscardDate { get; set; }
}
