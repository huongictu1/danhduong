﻿using System;
using System.Collections.Generic;

namespace PDCProjectApi.Data;

public partial class AdmMasterCalendar
{
    public Guid Id { get; set; }

    public DateOnly DateOfDate { get; set; }

    public string DayOfWeek { get; set; } = null!;

    public bool? IjOff { get; set; }

    public bool? LbpOff { get; set; }
}
