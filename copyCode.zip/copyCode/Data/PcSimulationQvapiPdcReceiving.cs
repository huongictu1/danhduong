﻿using System;
using System.Collections.Generic;

namespace PDCProjectApi.Data;

public partial class PcSimulationQvapiPdcReceiving
{
    public DateTime? CreatedDate { get; set; }

    public string? CreatedBy { get; set; }

    public DateTime? ModifiedDate { get; set; }

    public string? ModifiedBy { get; set; }

    public bool? Active { get; set; }

    public Guid Id { get; set; }

    public string? PartNo { get; set; }

    public string? Vendor { get; set; }

    public string? QtyPlan { get; set; }

    public string? Location { get; set; }

    public string? DeliveryKey { get; set; }

    public string? DateDelivery { get; set; }

    public string? TimeDelivery { get; set; }

    public string? PoStatus { get; set; }

    public string? Product { get; set; }

    public string? Bc { get; set; }
}
