﻿using System;
using System.Collections.Generic;

namespace PDCProjectApi.Data;

public partial class TodFcdelOutputShiftDeliveryVolumeIj
{
    public DateTime? CreatedDate { get; set; }

    public string? CreatedBy { get; set; }

    public DateTime? ModifiedDate { get; set; }

    public string? ModifiedBy { get; set; }

    public bool? Active { get; set; }

    public Guid Id { get; set; }

    public string? PartNo { get; set; }

    public string? PartName { get; set; }

    public string? Vendor { get; set; }

    public double? Ratio { get; set; }

    public double? MaxGap { get; set; }

    public int? MoqOrder { get; set; }

    public int? PcsBox { get; set; }

    public int? BoxPallet { get; set; }

    public int? PcsPallet { get; set; }

    public string? DeliveryFrequencyType { get; set; }

    public string? Model { get; set; }

    public string? Destination { get; set; }

    public DateOnly[]? ShiftDeliveryDate { get; set; }

    public double[]? ShiftDeliveryVolumeDay { get; set; }

    public double[]? ShiftDeliveryVolumeNight { get; set; }

    public string? DeliveryRoute { get; set; }

    public string? Location { get; set; }

    public string? VendorName { get; set; }

    public string? Bc { get; set; }

    public string? Location2 { get; set; }

    public string? Location3 { get; set; }
}
