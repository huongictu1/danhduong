﻿using System;
using System.Collections.Generic;

namespace PDCProjectApi.Data;

public partial class MvEucEcnLv2Ij
{
    public string? CdModelGrp { get; set; }

    public string? CdFact { get; set; }

    public string? NoChgNotification { get; set; }

    public string? NoHistChange { get; set; }

    public string? NoHistChangeSfx { get; set; }

    public string? CdChgObj { get; set; }

    public string? CfReClss { get; set; }

    public string? NoParts { get; set; }

    public string? NoAdjDim { get; set; }

    public string? NoInventCntlPoi { get; set; }

    public string? MkCfSupply { get; set; }

    public string? CdBlock { get; set; }

    public string? CdSplyFact { get; set; }

    public string? NoPost { get; set; }

    public string? CdProcess { get; set; }

    public string? NoHistory { get; set; }

    public string? NoDraw { get; set; }

    public string? RkEmg { get; set; }

    public string? MkPdmLayer { get; set; }

    public string? CdPdmPartsRev { get; set; }

    public string? ArPdmChangeOrder { get; set; }

    public string? FgPdmIntchgFlg { get; set; }

    public string? ArPdmRelation { get; set; }

    public string? CdPdmCause { get; set; }

    public string? CdPiece { get; set; }

    public string? CdPartsKind { get; set; }

    public string? CdProcurPerson { get; set; }

    public string? MaMkOpe { get; set; }

    public string? MaDtBValid { get; set; }

    public string? NoChldParts { get; set; }

    public string? NoChldAdjDim { get; set; }

    public string? NoChldInventCtlPoi { get; set; }

    public string? CdChldTape { get; set; }

    public string? CdChldSply { get; set; }

    public string? MkChldDbl { get; set; }

    public string? CdChldProcurPerson { get; set; }

    public string? QtConsumption { get; set; }

    public string? QtDivision { get; set; }

    public string? QtChg { get; set; }

    public string? CfSupplyClass { get; set; }

    public string? CfOdrClass { get; set; }

    public string? BoMkOpe { get; set; }

    public string? BoDtBValid { get; set; }

    public string? NoSubstitParts { get; set; }

    public string? NoSubstitAdjDim { get; set; }

    public string? MkOpe { get; set; }

    public string? DtScplEntry { get; set; }

    public string? CdDataCntl { get; set; }

    public string? DtEntry { get; set; }

    public string? NmEntryPerson { get; set; }

    public string? DtRenew { get; set; }

    public string? NmRenewPerson { get; set; }

    public string? CdTrans { get; set; }

    public string? CfChgStatClss { get; set; }

    public string? DtBValid { get; set; }

    public string? PartName { get; set; }

    public DateTime? CreatedDate { get; set; }
}
