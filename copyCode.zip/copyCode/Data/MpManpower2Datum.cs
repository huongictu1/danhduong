﻿using System;
using System.Collections.Generic;

namespace PDCProjectApi.Data;

public partial class MpManpower2Datum
{
    public DateTime? CreatedDate { get; set; }

    public string? CreatedBy { get; set; }

    public DateTime? ModifiedDate { get; set; }

    public string? ModifiedBy { get; set; }

    public bool? Active { get; set; }

    public Guid Id { get; set; }

    public string? Group { get; set; }

    public DateOnly Date { get; set; }

    public string? Model { get; set; }

    public string? Cell { get; set; }

    public string? Value { get; set; }

    public string? Shift { get; set; }

    public bool? IsNumber { get; set; }

    public string? Count { get; set; }

    public string? Fact { get; set; }

    public string? Color { get; set; }

    public string? Product { get; set; }

    public string? Version { get; set; }
}
