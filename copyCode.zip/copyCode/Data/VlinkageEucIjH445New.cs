﻿using System;
using System.Collections.Generic;

namespace PDCProjectApi.Data;

public partial class VlinkageEucIjH445New
{
    public string? DtDate { get; set; }

    public string? NoSeq { get; set; }

    public string? NoConsistantSeq { get; set; }

    public string? CdInFact { get; set; }

    public string? NoInParts { get; set; }

    public string? NoInAdjDim { get; set; }

    public string? NoInInventCtlPoi { get; set; }

    public string? NoInLine { get; set; }

    public string? CdInBlock { get; set; }

    public string? NoInConstPatt { get; set; }

    public string? CfInChgStatClss { get; set; }

    public string? DtInDate { get; set; }

    public string? MkInUnused { get; set; }

    public string? MkInLt { get; set; }

    public string? DtInShipEnable { get; set; }

    public string? NoConstruction { get; set; }

    public string? NoLevel { get; set; }

    public string? NoPath { get; set; }

    public string? NoConsumpDiviPath { get; set; }

    public string? CfSupplyClassAll { get; set; }

    public string? CfOdrClassAll { get; set; }

    public string? MkStock { get; set; }

    public string? MkNextExist { get; set; }

    public string? MkProducts { get; set; }

    public double? QtSupplyCnt { get; set; }

    public string? MkReClss { get; set; }

    public double? QtMotherDelivLevel { get; set; }

    public string? MkMotherDeliv { get; set; }

    public double? QtConsumpDivi { get; set; }

    public double? QtConsumptionAll { get; set; }

    public double? QtDivisionAll { get; set; }

    public string? MkConsumpDiviAll { get; set; }

    public double? QtConsumpDiviAll { get; set; }

    public double? QtConsumpDiviAllSum { get; set; }

    public double? QtConsumpDiviAllCnt { get; set; }

    public string? CfChildBase { get; set; }

    public string? CdPiece { get; set; }

    public string? NmPartsEng { get; set; }

    public string? NmPartsLocal { get; set; }

    public double? PdLeadTimeAll { get; set; }

    public string? ArPartsFlow { get; set; }

    public string? DtStartExpec { get; set; }

    public string? DtShipEnable { get; set; }

    public string? DtMotherStartExpec { get; set; }

    public string? DtChldShipEnable { get; set; }

    public string? DtStartExpecSlide { get; set; }

    public string? DtShipEnableSlide { get; set; }

    public string? DtMotherStartExpecSlide { get; set; }

    public string? DtChldShipEnableSlide { get; set; }

    public string? CdFact { get; set; }

    public string? NoMotherParts { get; set; }

    public string? NoMotherAdjDim { get; set; }

    public string? NoMotherInventCtlPoi { get; set; }

    public string? NoMotherLine { get; set; }

    public string? CdBlock { get; set; }

    public string? NoChldParts { get; set; }

    public string? NoChldAdjDim { get; set; }

    public string? NoChldInventCtlPoi { get; set; }

    public string? NoChldLine { get; set; }

    public string? NoHistChange { get; set; }

    public string? NoHistChangeSfx { get; set; }

    public string? CfChgStatClss { get; set; }

    public string? NoChgNotification { get; set; }

    public string? DtBValid { get; set; }

    public string? DtEValid { get; set; }

    public string? MkOpe { get; set; }

    public string? CdChgObj { get; set; }

    public string? DtEntryDate { get; set; }

    public string? DtEntryTime { get; set; }

    public string? NoHistChangeH001 { get; set; }

    public string? NoHistChangeSfxH001 { get; set; }

    public string? CfChgStatClssH001 { get; set; }

    public string? NoChgNotificationH001 { get; set; }

    public string? CdBlockH001 { get; set; }

    public string? CdProcessH001 { get; set; }

    public string? NoDrawH001 { get; set; }

    public string? DtBValidH001 { get; set; }

    public string? DtEValidH001 { get; set; }

    public string? MkOpeH001 { get; set; }

    public string? CdChgObjH001 { get; set; }

    public string? CfReClssH001 { get; set; }

    public string? DtEntryDateH001 { get; set; }

    public string? DtEntryTimeH001 { get; set; }

    public string? NoPostH002 { get; set; }

    public string? DtBValidH003 { get; set; }

    public string? DtEValidH003 { get; set; }

    public string? MkSubstitH003 { get; set; }

    public string? NoPartsH003 { get; set; }

    public string? NoAdjDimH003 { get; set; }

    public string? CdBlockH003 { get; set; }

    public string? NoLegularPartsH003 { get; set; }

    public string? NoLegularAdjDimH003 { get; set; }

    public string? NoSubstitPartsH003 { get; set; }

    public string? NoSubstitAdjDimH003 { get; set; }

    public double? PtSubstitH003 { get; set; }

    public string? CdBlockH005 { get; set; }

    public double? RkPrioDiviH005 { get; set; }

    public double? PtRatioH005 { get; set; }

    public string? DtBValidH005 { get; set; }

    public string? DtEValidH005 { get; set; }

    public double? TmStoreLeadH005 { get; set; }

    public double? PdProcessH005 { get; set; }

    public string? CfIoH005 { get; set; }

    public string? MkPilePrioH005 { get; set; }

    public string? CfSupplyClassH007 { get; set; }

    public string? CfOdrClassH007 { get; set; }

    public double? QtConsumptionH007 { get; set; }

    public double? QtDivisionH007 { get; set; }

    public double? PdLtEntryH007 { get; set; }

    public string? CdDataCntl { get; set; }

    public DateOnly? DtEntry { get; set; }

    public string? NmEntryPerson { get; set; }

    public DateOnly? DtRenew { get; set; }

    public string? NmRenewPerson { get; set; }

    public string? CdTrans { get; set; }
}
