﻿using System;
using System.Collections.Generic;

namespace PDCProjectApi.Data;

/// <summary>
/// upload by user, using for calculate output 7 for part parallel
/// </summary>
public partial class PcSimulationMasterParallel
{
    public DateTime? CreatedDate { get; set; }

    public string? CreatedBy { get; set; }

    public DateTime? ModifiedDate { get; set; }

    public string? ModifiedBy { get; set; }

    public bool? Active { get; set; }

    public Guid Id { get; set; }

    public string Bc { get; set; } = null!;

    public string Vendor { get; set; } = null!;

    public string PartNo { get; set; } = null!;

    public DateOnly PlanDate { get; set; }

    public double DoQty { get; set; }

    public double? Ratio { get; set; }

    public string Product { get; set; } = null!;

    public DateTime? ApprovalDate { get; set; }

    public string? ApprovalBy { get; set; }
}
