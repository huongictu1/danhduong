﻿using System;
using System.Collections.Generic;

namespace PDCProjectApi.Data;

public partial class PcSimulationLeadtimeLbp
{
    public DateTime? CreatedDate { get; set; }

    public string? CreatedBy { get; set; }

    public DateTime? ModifiedDate { get; set; }

    public string? ModifiedBy { get; set; }

    public bool? Active { get; set; }

    public Guid Id { get; set; }

    public string PartNo { get; set; } = null!;

    public string Vendor { get; set; } = null!;

    public string Ratio { get; set; } = null!;

    public string Model { get; set; } = null!;

    public string Destination { get; set; } = null!;

    public double[] LtValue { get; set; } = null!;

    public int DayQty { get; set; }

    public string? Bc { get; set; }

    public string? Dim { get; set; }

    public string? PartName { get; set; }

    public string? RatioChangeEffectiveDate { get; set; }

    public string? RatioChangeRatio { get; set; }

    public string? PicDo { get; set; }

    public string? PicPo { get; set; }

    public DateTime[] DateVal { get; set; } = null!;

    public bool[] HasPlan { get; set; } = null!;

    public double[] QtyKeepArr { get; set; } = null!;

    public double QtyKeepCell { get; set; }

    public double Leadtime { get; set; }

    public double[] TotalLt { get; set; } = null!;

    public string? Cell { get; set; }

    public double[]? DemandArr { get; set; }
}
