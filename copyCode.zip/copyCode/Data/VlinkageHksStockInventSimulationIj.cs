﻿using System;
using System.Collections.Generic;

namespace PDCProjectApi.Data;

public partial class VlinkageHksStockInventSimulationIj
{
    public string? PartNo { get; set; }

    public string? Dim { get; set; }

    public int? Cp { get; set; }

    public string? Bc { get; set; }

    public string? Sp { get; set; }

    public string? Sply { get; set; }

    public string? Pccc { get; set; }

    public double? InvQty { get; set; }

    public int? Flag { get; set; }

    public string? PalletDate { get; set; }

    public string? UserEntry { get; set; }

    public DateTime? DateEntry { get; set; }
}
