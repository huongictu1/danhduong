﻿using System;
using System.Collections.Generic;

namespace PDCProjectApi.Data;

public partial class PcSimulationPpLineLbp
{
    public DateTime? CreatedDate { get; set; }

    public string? CreatedBy { get; set; }

    public DateTime? ModifiedDate { get; set; }

    public string? ModifiedBy { get; set; }

    public bool? Active { get; set; }

    public Guid Id { get; set; }

    public string PalletDate { get; set; } = null!;

    public string Model { get; set; } = null!;

    public string Cell { get; set; } = null!;

    public double ActualQuantity { get; set; }

    public string Destination { get; set; } = null!;

    public string Shift { get; set; } = null!;

    public double PlanQuantity { get; set; }

    public double[] PpValue { get; set; } = null!;
}
