﻿using System;
using System.Collections.Generic;

namespace PDCProjectApi.Data;

public partial class AdmMasterPage
{
    public DateTime? CreatedDate { get; set; }

    public string? CreatedBy { get; set; }

    public DateTime? ModifiedDate { get; set; }

    public string? ModifiedBy { get; set; }

    public bool? Active { get; set; }

    public Guid Id { get; set; }

    public string? PageName { get; set; }

    public string? Link { get; set; }

    public string? Icon { get; set; }

    public int? OrderNo { get; set; }

    public Guid? ParentId { get; set; }

    public virtual ICollection<AdmDetailPageGroup> AdmDetailPageGroups { get; set; } = new List<AdmDetailPageGroup>();

    public virtual ICollection<AdmDetailUserPageReadOnly> AdmDetailUserPageReadOnlies { get; set; } = new List<AdmDetailUserPageReadOnly>();
}
