﻿using System;
using System.Collections.Generic;

namespace PDCProjectApi.Data;

/// <summary>
/// bảng này cho biết tiến trình approval của request revise po
/// </summary>
public partial class PcPaRequestRevisePoProcess
{
    public DateTime? CreatedDate { get; set; }

    public string? CreatedBy { get; set; }

    public DateTime? ModifiedDate { get; set; }

    public string? ModifiedBy { get; set; }

    public bool? Active { get; set; }

    public Guid Id { get; set; }

    public Guid RequestId { get; set; }

    public int? AprOrder { get; set; }

    public string? AprGrade { get; set; }

    public string? AprDept { get; set; }

    public string? AprComment { get; set; }

    public bool? AprStatus { get; set; }

    public bool? AprNext { get; set; }

    public string? Note { get; set; }

    public Guid? GroupId { get; set; }

    public virtual AdmMasterGroup? Group { get; set; }

    public virtual PcPaRequestRevisePo Request { get; set; } = null!;
}
