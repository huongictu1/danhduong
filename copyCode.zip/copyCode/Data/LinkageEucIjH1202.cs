﻿using System;
using System.Collections.Generic;

namespace PDCProjectApi.Data;

public partial class LinkageEucIjH1202
{
    public string? CdFact { get; set; }

    public string? NoParts { get; set; }

    public string? NoAdjDim { get; set; }

    public string? CdBlock { get; set; }

    public string? NoLegularParts { get; set; }

    public string? NoLegularAdjDim { get; set; }

    public string? NoSubstitParts { get; set; }

    public string? NoSubstitAdjDim { get; set; }

    public string? NmPartsEng { get; set; }

    public string? MkSubsit { get; set; }

    public string? DtBValid { get; set; }

    public string? PtSubstit { get; set; }

    public string? DtEValid { get; set; }

    public string? DtSubstitLead { get; set; }

    public string? MkDelete { get; set; }

    public string? NoSubstitSeq { get; set; }

    public string? CdDataCntl { get; set; }

    public string? DtEntry { get; set; }

    public string? NmEntryPerson { get; set; }

    public string? DtRenew { get; set; }

    public string? NmRenewPerson { get; set; }

    public string? CdTrans { get; set; }

    public Guid Id { get; set; }

    public DateTime? CreatedDate { get; set; }

    public DateTime? DtEntryD { get; set; }

    public bool? Active { get; set; }
}
