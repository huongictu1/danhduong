﻿using System;
using System.Collections.Generic;

namespace PDCProjectApi.Data;

public partial class VlinkageHksAiTime
{
    public string? CodeControl { get; set; }

    public DateTime? DateEntry { get; set; }

    public string? UserEntry { get; set; }

    public DateTime? DateUpdate { get; set; }

    public string? UserUpdate { get; set; }

    public string? TypeTime { get; set; }

    public string? WorkTime { get; set; }

    public string? WorkFrom { get; set; }

    public string? WorkTo { get; set; }

    public int? BreakCount { get; set; }

    public int? BreakTotal { get; set; }

    public string? Break1 { get; set; }

    public int? Total1 { get; set; }

    public string? Break2 { get; set; }

    public int? Total2 { get; set; }

    public string? Break3 { get; set; }

    public int? Total3 { get; set; }

    public string? Break4 { get; set; }

    public int? Total4 { get; set; }

    public string? Break5 { get; set; }

    public int? Total5 { get; set; }

    public string? Break6 { get; set; }

    public int? Total6 { get; set; }

    public string? SubTime { get; set; }

    public string? Note { get; set; }
}
