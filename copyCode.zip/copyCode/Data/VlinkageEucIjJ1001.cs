﻿using System;
using System.Collections.Generic;

namespace PDCProjectApi.Data;

public partial class VlinkageEucIjJ1001
{
    public string? ProcessingFlag { get; set; }

    public string? Factory { get; set; }

    public string? Vendor { get; set; }

    public string? PartsNo { get; set; }

    public string? Dim { get; set; }

    public string? OrderMethod { get; set; }

    public string? DeliveryLot { get; set; }

    public string? StandardPack { get; set; }

    public string? PoLeadTime { get; set; }
}
