﻿using System;
using System.Collections.Generic;

namespace PDCProjectApi.Data;

public partial class TodFcdelPsLivePp
{
    public string? ProductCode { get; set; }

    public string? PalletDate { get; set; }

    public string? Shift { get; set; }

    public string? Merchandise { get; set; }

    public double? SumQty { get; set; }

    public Guid Id { get; set; }

    public DateTime? CreatedDate { get; set; }

    public string? ProductName { get; set; }
}
