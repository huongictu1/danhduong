﻿using System;
using System.Collections.Generic;

namespace PDCProjectApi.Data;

public partial class MpManpower22Ip2StdCell
{
    public DateTime? CreatedDate { get; set; }

    public string? CreatedBy { get; set; }

    public DateTime? ModifiedDate { get; set; }

    public string? ModifiedBy { get; set; }

    public bool? Active { get; set; }

    public Guid Id { get; set; }

    public string? DeptCode { get; set; }

    public string? Model { get; set; }

    public string? Kind { get; set; }

    public DateOnly? From { get; set; }

    public DateOnly? To { get; set; }

    public double? Workload8h { get; set; }

    public double? MediaG1 { get; set; }

    public double? ReplaceG1 { get; set; }

    public double? Service { get; set; }

    public double? Kitting { get; set; }

    public double? Pallet { get; set; }

    public double? Inspection { get; set; }

    public double? Workload7h { get; set; }
}
