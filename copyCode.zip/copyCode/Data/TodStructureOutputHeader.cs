﻿using System;
using System.Collections.Generic;

namespace PDCProjectApi.Data;

public partial class TodStructureOutputHeader
{
    public Guid Id { get; set; }

    public bool? Active { get; set; }

    public DateTime? CreatedDate { get; set; }

    public DateOnly DateEntry { get; set; }

    public string Product { get; set; } = null!;

    public string[] Model { get; set; } = null!;

    public string[] Merchandise { get; set; } = null!;

    public string[] MerCode { get; set; } = null!;
}
