﻿using System;
using System.Collections.Generic;

namespace PDCProjectApi.Data;

public partial class MvLivePpIjBlock10PartMaster
{
    public string? PalletDate { get; set; }

    public string? Merchandise { get; set; }

    public string? BTime { get; set; }

    public double? BActual { get; set; }

    public double? BQuantity { get; set; }

    public DateTime? BDate { get; set; }
}
