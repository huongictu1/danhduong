﻿using System;
using System.Collections.Generic;

namespace PDCProjectApi.Data;

/// <summary>
/// part control - part adjustment - part job assignment
/// </summary>
public partial class PcPaPartJobAssignment
{
    public DateTime? CreatedDate { get; set; }

    public string? CreatedBy { get; set; }

    public DateTime? ModifiedDate { get; set; }

    public string? ModifiedBy { get; set; }

    public bool? Active { get; set; }

    public Guid Id { get; set; }

    public string PartNo { get; set; } = null!;

    public string Vendor { get; set; } = null!;

    public string PicPo { get; set; } = null!;

    public string? Buyer { get; set; }

    public string? ApprovalBy { get; set; }

    public DateTime? ApprovalDate { get; set; }

    public string? Note { get; set; }

    public string? DoPic { get; set; }

    public string? Product { get; set; }
}
