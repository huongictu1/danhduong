﻿using System;
using System.Collections.Generic;

namespace PDCProjectApi.Data;

public partial class InvClaimCardInfo
{
    public DateTime? CreatedDate { get; set; }

    public string? CreatedBy { get; set; }

    public DateTime? ModifiedDate { get; set; }

    public string? ModifiedBy { get; set; }

    public bool? Active { get; set; }

    public Guid Id { get; set; }

    public string ClaimCardNo { get; set; } = null!;

    public string? WhereInfo { get; set; }

    public string? WhenInfo { get; set; }

    public string? WhoInfo { get; set; }

    public string? Image1 { get; set; }

    public string? Image2 { get; set; }

    public string? Image3 { get; set; }

    public string? Image4 { get; set; }

    public string? Reason { get; set; }

    public string? Countermeasure { get; set; }

    public string? Attachment { get; set; }

    public bool? SupplierRequest { get; set; }
}
