﻿using System;
using System.Collections.Generic;

namespace PDCProjectApi.Data;

public partial class VlinkageHksLivePpPriorityIj
{
    public string? UserEntry { get; set; }

    public DateOnly? DateEntry { get; set; }

    public string? UserUpdate { get; set; }

    public DateOnly? DateUpdate { get; set; }

    public string? DateTime { get; set; }

    public string? LineNo { get; set; }

    public string? Merchandise { get; set; }

    public string? ProductCode { get; set; }

    public string? Destination { get; set; }

    public double? PlanQty { get; set; }

    public string? Shift { get; set; }

    public string? Priority { get; set; }

    public double? IdProduction { get; set; }

    public string? PartNo { get; set; }

    public double? Dummy { get; set; }

    public double? Dandori { get; set; }

    public DateOnly? DpalletDate { get; set; }
}
