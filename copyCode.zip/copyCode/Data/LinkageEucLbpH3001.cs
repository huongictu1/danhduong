﻿using System;
using System.Collections.Generic;

namespace PDCProjectApi.Data;

public partial class LinkageEucLbpH3001
{
    public string? CdFact { get; set; }

    public string? CdUseBlock { get; set; }

    public string? NoParts { get; set; }

    public string? NoAdjDim { get; set; }

    public string? DtBValid { get; set; }

    public string? PdDecimalLead { get; set; }

    public Guid Id { get; set; }

    public DateTime? CreatedDate { get; set; }

    public bool? Active { get; set; }
}
