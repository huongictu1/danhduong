﻿using System;
using System.Collections.Generic;

namespace PDCProjectApi.Data;

public partial class VInvStructure
{
    public string? PartNo8 { get; set; }

    public string? Comain22 { get; set; }

    public string? Product { get; set; }
}
