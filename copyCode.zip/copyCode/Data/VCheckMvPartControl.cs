﻿using System;
using System.Collections.Generic;

namespace PDCProjectApi.Data;

public partial class VCheckMvPartControl
{
    public string? DataSource { get; set; }

    public string? CreatedDate { get; set; }

    public long? RowsTotal { get; set; }
}
