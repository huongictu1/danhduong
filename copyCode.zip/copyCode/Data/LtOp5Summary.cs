﻿using System;
using System.Collections.Generic;

namespace PDCProjectApi.Data;

public partial class LtOp5Summary
{
    public DateTime? CreatedDate { get; set; }

    public string? CreatedBy { get; set; }

    public DateTime? ModifiedDate { get; set; }

    public string? ModifiedBy { get; set; }

    public bool? Active { get; set; }

    public Guid Id { get; set; }

    public string? Model { get; set; }

    public double? Pdc2Rec { get; set; }

    public double? Pdc2Supply { get; set; }

    public double? AssyMain { get; set; }

    public double? AssyKitting { get; set; }

    public double? AssySubc { get; set; }

    public double? AssySilk { get; set; }

    public double? AssyMedia { get; set; }

    public double? AssyMip { get; set; }

    public double? AssyCounter { get; set; }

    public double? AssySubp { get; set; }

    public double? Ih { get; set; }

    public double? Other { get; set; }

    public double? Total { get; set; }

    public string? Product { get; set; }
}
