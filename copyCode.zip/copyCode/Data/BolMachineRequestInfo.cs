﻿using System;
using System.Collections.Generic;

namespace PDCProjectApi.Data;

public partial class BolMachineRequestInfo
{
    public DateTime? CreatedDate { get; set; }

    public string? CreatedBy { get; set; }

    public DateTime? ModifiedDate { get; set; }

    public string? ModifiedBy { get; set; }

    public bool? Active { get; set; }

    public Guid Id { get; set; }

    public string? Department { get; set; }

    public string? Brand { get; set; }

    public string? Factory { get; set; }

    public string? Model { get; set; }

    public string? Phase { get; set; }

    public string? Category { get; set; }

    public string? UrgentLevel { get; set; }

    public string? Purpose { get; set; }

    public string? RequestNo { get; set; }

    public int? Status { get; set; }
}
