﻿using System;
using System.Collections.Generic;

namespace PDCProjectApi.Data;

public partial class MvEucIjB101Unit
{
    public string? BKey { get; set; }

    public string? BValue { get; set; }

    public DateTime? BDate { get; set; }
}
