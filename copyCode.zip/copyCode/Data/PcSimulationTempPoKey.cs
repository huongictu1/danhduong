﻿using System;
using System.Collections.Generic;

namespace PDCProjectApi.Data;

/// <summary>
/// lay PO Key tu NPIS (file shared of cvn-icampas)
/// </summary>
public partial class PcSimulationTempPoKey
{
    public DateTime? CreatedDate { get; set; }

    public string? CreatedBy { get; set; }

    public DateTime? ModifiedDate { get; set; }

    public string? ModifiedBy { get; set; }

    public bool? Active { get; set; }

    public Guid Id { get; set; }

    public string DeliveryDate { get; set; } = null!;

    public string? DeliveryInstruction { get; set; }

    public string DeliveryKey { get; set; } = null!;

    public string? Dim { get; set; }

    public string? Drawing { get; set; }

    public string? Ecn { get; set; }

    public double OrderQty { get; set; }

    public string PartNo { get; set; } = null!;

    public string Vendor { get; set; } = null!;

    public string Product { get; set; } = null!;
}
