﻿using System;
using System.Collections.Generic;

namespace PDCProjectApi.Data;

public partial class LtFormRegistrationIhItem
{
    public DateTime? CreatedDate { get; set; }

    public string? CreatedBy { get; set; }

    public DateTime? ModifiedDate { get; set; }

    public string? ModifiedBy { get; set; }

    public bool? Active { get; set; }

    public Guid Id { get; set; }

    public string? PartNo { get; set; }

    public string? PartName { get; set; }

    public string? Model { get; set; }

    public string? ChangingReason { get; set; }

    public string? ChangingMethod { get; set; }

    public DateOnly? RequestEffectiveDate { get; set; }

    public string? PartMovingRoute { get; set; }

    public string? DandoriTime { get; set; }

    public string? CycleTime { get; set; }

    public string? Cycle1st { get; set; }

    public string? InsideTransportation { get; set; }

    public string? OutsideTransportation { get; set; }

    public string? AssyShift { get; set; }

    public string? InhouseCapacity { get; set; }

    public string? McTrouble { get; set; }

    public string? StopForMaintaince { get; set; }

    public string? ProductionSpecial { get; set; }

    public string? LotSize { get; set; }

    public string? ApprovedBy { get; set; }

    public DateTime? ApprovedDate { get; set; }

    public int? ApprovedStatus { get; set; }

    public string? RequestNo { get; set; }

    public string? StockActualFirst { get; set; }

    public string? StockActualLast { get; set; }
}
