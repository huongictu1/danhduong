﻿using System;
using System.Collections.Generic;

namespace PDCProjectApi.Data;

public partial class VHksAiRestTimeIj
{
    public DateOnly? MonthLine { get; set; }

    public string? LineNo { get; set; }

    public string? TypeTimeDay { get; set; }

    public string? TypeTimeNight { get; set; }

    public string? WorkTime { get; set; }

    public string? WorkFrom { get; set; }

    public string? WorkTo { get; set; }

    public int[]? RestBlock { get; set; }

    public string[]? RestTime { get; set; }

    public string? Note { get; set; }

    public long? Rn { get; set; }

    public string? Model { get; set; }
}
