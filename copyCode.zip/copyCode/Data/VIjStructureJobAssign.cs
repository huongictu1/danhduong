﻿using System;
using System.Collections.Generic;

namespace PDCProjectApi.Data;

public partial class VIjStructureJobAssign
{
    public string? Product { get; set; }

    public string? Bc { get; set; }

    public string? VendorCode { get; set; }

    public string? DoPic { get; set; }

    public string? PoPic { get; set; }

    public string? Remark { get; set; }
}
