﻿using System;
using System.Collections.Generic;

namespace PDCProjectApi.Data;

public partial class MvEucH4452
{
    public string? BKey { get; set; }

    public string? BValue { get; set; }

    public DateTime? BCreated { get; set; }
}
