﻿using System;
using System.Collections.Generic;

namespace PDCProjectApi.Data;

public partial class MpManpowerItem
{
    public DateTime? CreatedDate { get; set; }

    public string? CreatedBy { get; set; }

    public DateTime? ModifiedDate { get; set; }

    public string? ModifiedBy { get; set; }

    public bool? Active { get; set; }

    public Guid Id { get; set; }

    public string? Item { get; set; }

    public DateOnly[]? Date { get; set; }

    public string[]? Value { get; set; }

    public int? OrderNo { get; set; }

    public DateTime? ApprovedDate { get; set; }

    public string? ApprovedBy { get; set; }

    public string? ApprovedName { get; set; }

    public string? Product { get; set; }

    public DateOnly? From { get; set; }

    public DateOnly? To { get; set; }

    public string? Dept { get; set; }

    public string? RejectedBy { get; set; }

    public DateTime? RejectedDate { get; set; }

    public string? Version { get; set; }

    public string? TypePs { get; set; }
}
