﻿using System;
using System.Collections.Generic;

namespace PDCProjectApi.Data;

/// <summary>
/// Part control - Part Adjustment - Master individual
/// </summary>
public partial class PcPaMasterIndividual
{
    public DateTime? CreatedDate { get; set; }

    public string? CreatedBy { get; set; }

    public DateTime? ModifiedDate { get; set; }

    public string? ModifiedBy { get; set; }

    public bool? Active { get; set; }

    public Guid Id { get; set; }

    public string? Factory { get; set; }

    public string Product { get; set; } = null!;

    public string? Dept { get; set; }

    public string? Description { get; set; }

    public string Model { get; set; } = null!;

    public string? Phase { get; set; }

    public string Individual { get; set; } = null!;

    public string? Remark { get; set; }

    public string? ApprovalBy { get; set; }

    public string? Note { get; set; }

    public DateTime? ApprovalDate { get; set; }
}
