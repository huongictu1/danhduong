﻿using System;
using System.Collections.Generic;

namespace PDCProjectApi.Data;

public partial class MpManpower22Ip1StdForSilk
{
    public DateTime? CreatedDate { get; set; }

    public string? CreatedBy { get; set; }

    public DateTime? ModifiedDate { get; set; }

    public string? ModifiedBy { get; set; }

    public bool? Active { get; set; }

    public Guid Id { get; set; }

    public string? DeptCode { get; set; }

    public string? Model { get; set; }

    public double? SilkStd { get; set; }

    public double? SilkRatio { get; set; }

    public double? PregStd { get; set; }

    public double? PregRatio { get; set; }

    public double? AutoStd { get; set; }

    public double? AutoRatio { get; set; }
}
