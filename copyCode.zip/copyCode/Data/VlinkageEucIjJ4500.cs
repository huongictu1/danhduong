﻿using System;
using System.Collections.Generic;

namespace PDCProjectApi.Data;

public partial class VlinkageEucIjJ4500
{
    public string? CdSply { get; set; }

    public string? CdSplyFact { get; set; }

    public string? NoParts { get; set; }

    public string? NoAdjDim { get; set; }

    public string? Pr { get; set; }

    public string? NoDraw { get; set; }

    public string? EcnNo { get; set; }

    public string? PoStatus { get; set; }

    public string? DelvKeyNo { get; set; }

    public string? OrderDate { get; set; }

    public string? QtOrd { get; set; }

    public string? QtDelvBal { get; set; }

    public string? DtDelv { get; set; }

    public string? Unit { get; set; }

    public string? NoInvoice { get; set; }

    public string? CdDelvPlace { get; set; }

    public string? BuyerCode { get; set; }

    public string? PurchasePrice { get; set; }

    public string? ItemCategory { get; set; }

    public string? NoOrdClass { get; set; }

    public string? FreeOfCharge { get; set; }

    public string? TradeCondition { get; set; }

    public string? TradeConditionPName { get; set; }

    public string? DtEntry { get; set; }

    public string? DtRenew { get; set; }

    public string? CdUseBlock { get; set; }

    public string? CfTranspMeth { get; set; }

    public string? CdLeavPort { get; set; }

    public string? IndividualOrder { get; set; }

    public string? FinalDueDate { get; set; }

    public string? DtEtd { get; set; }

    public string? NoCustClea { get; set; }

    public string? NoContainer { get; set; }

    public string? HmlndLt { get; set; }

    public string? TrnspLt { get; set; }
}
