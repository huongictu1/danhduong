﻿using System;
using System.Collections.Generic;

namespace PDCProjectApi.Data;

public partial class BolMachineRequestProcess
{
    public DateTime? CreatedDate { get; set; }

    public string? CreatedBy { get; set; }

    public DateTime? ModifiedDate { get; set; }

    public string? ModifiedBy { get; set; }

    public bool? Active { get; set; }

    public Guid Id { get; set; }

    public string RequestNo { get; set; } = null!;

    public string? ApproveBy { get; set; }

    public int? Step { get; set; }

    public bool? Next { get; set; }

    public string? GroupName { get; set; }

    public DateOnly? DateConfirm { get; set; }

    public string? CostCenter { get; set; }

    public string? Comment { get; set; }

    public string? Acknowledger { get; set; }
}
