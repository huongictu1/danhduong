﻿using System;
using System.Collections.Generic;

namespace PDCProjectApi.Data;

public partial class TodTodOutput7Fcdo
{
    public DateTime? CreatedDate { get; set; }

    public string? CreatedBy { get; set; }

    public DateTime? ModifiedDate { get; set; }

    public string? ModifiedBy { get; set; }

    public bool? Active { get; set; }

    public Guid Id { get; set; }

    public string Code { get; set; } = null!;

    public string Kind { get; set; } = null!;

    public string PartNo { get; set; } = null!;

    public string? Dim { get; set; }

    public string? Cp { get; set; }

    public string Vendor { get; set; } = null!;

    public string Bc { get; set; } = null!;

    public string PoDate { get; set; } = null!;

    public double PoQty { get; set; }

    public string Product { get; set; } = null!;
}
