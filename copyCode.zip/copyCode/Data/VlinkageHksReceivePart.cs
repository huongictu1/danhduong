﻿using System;
using System.Collections.Generic;

namespace PDCProjectApi.Data;

public partial class VlinkageHksReceivePart
{
    public string? PartNo { get; set; }

    public string? Vendor { get; set; }

    public string? DeliveryKey { get; set; }

    public string? DateDelivery { get; set; }

    public string? TimeDelivery { get; set; }

    public string? Location { get; set; }

    public double? QtyPlan { get; set; }

    public double? ActQty { get; set; }

    public double? DifferQty { get; set; }

    public string? ErrorsName { get; set; }

    public DateTime? TimeReceive { get; set; }

    public string? UserReceive { get; set; }

    public DateOnly? Unloading { get; set; }

    public string? Remark { get; set; }

    public string? LeaderConfirm { get; set; }

    public DateOnly? TimeConfirm { get; set; }

    public string? SubfixPlan { get; set; }

    public string? SubfixActual { get; set; }

    public string? KindOfItem { get; set; }
}
