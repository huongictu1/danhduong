﻿using System;
using System.Collections.Generic;

namespace PDCProjectApi.Data;

public partial class VInvD800
{
    public string? NoParts { get; set; }

    public double? CtAll { get; set; }

    public string? NoStockPoi { get; set; }

    public double? QtStock { get; set; }

    public string? Product { get; set; }
}
