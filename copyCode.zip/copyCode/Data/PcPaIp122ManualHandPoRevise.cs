﻿using System;
using System.Collections.Generic;

namespace PDCProjectApi.Data;

public partial class PcPaIp122ManualHandPoRevise
{
    public DateTime? CreatedDate { get; set; }

    public string? CreatedBy { get; set; }

    public DateTime? ModifiedDate { get; set; }

    public string? ModifiedBy { get; set; }

    public bool? Active { get; set; }

    public Guid Id { get; set; }

    public string? No { get; set; }

    public string Vendor { get; set; } = null!;

    public string PartNo { get; set; } = null!;

    public string? Dim { get; set; }

    public string UsedBy { get; set; } = null!;

    public string? DeliveryLocation { get; set; }

    public string? DeliveryDate { get; set; }

    public int? OrderQuantity { get; set; }

    public string? Drawing { get; set; }

    public string? ShippingMethod { get; set; }

    public string? MainBody { get; set; }

    public string? TransportMethod { get; set; }

    public string? Reason { get; set; }

    public string? Remark { get; set; }

    public string? TransportMethod2 { get; set; }

    public string? MainBody2 { get; set; }

    public string? Drawing2 { get; set; }

    public int? OrderQuantity2 { get; set; }

    public string? DeliveryDate2 { get; set; }

    public string? UsedBy2 { get; set; }

    public string? DeliveryLocation2 { get; set; }

    public string? DeliveryKeyNo { get; set; }

    public string? Product { get; set; }

    public Guid? RqId { get; set; }

    public virtual PcPaRequestRevisePo? Rq { get; set; }
}
