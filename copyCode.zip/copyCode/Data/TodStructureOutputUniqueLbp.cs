﻿using System;
using System.Collections.Generic;

namespace PDCProjectApi.Data;

public partial class TodStructureOutputUniqueLbp
{
    public DateTime? CreatedDate { get; set; }

    public string? CreatedBy { get; set; }

    public DateTime? ModifiedDate { get; set; }

    public string? ModifiedBy { get; set; }

    public bool? Active { get; set; }

    public Guid Id { get; set; }

    public string? Kind { get; set; }

    public string? Merchandise { get; set; }

    public string? Bc1 { get; set; }

    public string? PartNo8 { get; set; }

    public string? PartName9 { get; set; }

    public string? Bc12 { get; set; }

    public string? Name20 { get; set; }

    public string? LdPo { get; set; }

    public string? Stock { get; set; }

    public string? DoPo { get; set; }

    public string? LdDo { get; set; }
}
