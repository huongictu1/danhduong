﻿using System;
using System.Collections.Generic;

namespace PDCProjectApi.Data;

/// <summary>
/// các block time của working day, gồm có day shift và night shift,
/// simulation sẽ dựa vào đây để trích xuất ra, nó là master nên cố định
/// </summary>
public partial class PcSimulationMasterBlockTime
{
    public DateTime? CreatedDate { get; set; }

    public string? CreatedBy { get; set; }

    public DateTime? ModifiedDate { get; set; }

    public string? ModifiedBy { get; set; }

    public bool? Active { get; set; }

    public Guid Id { get; set; }

    public TimeOnly StartTime { get; set; }

    public TimeOnly EndTime { get; set; }

    public string Shift { get; set; } = null!;

    public int OrderTime { get; set; }
}
