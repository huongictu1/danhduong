﻿using System;
using System.Collections.Generic;

namespace PDCProjectApi.Data;

public partial class MvEucH1701Mother
{
    public string? PartsKey { get; set; }

    public string? NoMotherParts { get; set; }

    public DateTime? CreatedDate { get; set; }
}
