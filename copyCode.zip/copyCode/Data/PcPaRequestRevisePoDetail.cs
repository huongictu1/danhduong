﻿using System;
using System.Collections.Generic;

namespace PDCProjectApi.Data;

public partial class PcPaRequestRevisePoDetail
{
    public DateTime? CreatedDate { get; set; }

    public string? CreatedBy { get; set; }

    public DateTime? ModifiedDate { get; set; }

    public string? ModifiedBy { get; set; }

    public bool? Active { get; set; }

    public Guid Id { get; set; }

    /// <summary>
    /// xác định thuộc request no nào
    /// </summary>
    public Guid RequestId { get; set; }

    public string? Reason { get; set; }

    public string? Vendor { get; set; }

    public string? PartNo { get; set; }

    public string? Dim { get; set; }

    public string? UsedBy { get; set; }

    public string? IndividualOrder { get; set; }

    public string? DeliveryDate { get; set; }

    public string? OrderQuantity { get; set; }

    public string? Um { get; set; }

    public string? Drawing { get; set; }

    public string? ShippingMethod { get; set; }

    public string? Remark { get; set; }

    /// <summary>
    /// xác định tương ứng nguồn ban đầu nào
    /// </summary>
    public Guid IpId { get; set; }

    public virtual PcPaRequestRevisePo Request { get; set; } = null!;
}
