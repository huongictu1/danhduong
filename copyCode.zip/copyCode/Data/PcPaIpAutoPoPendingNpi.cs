﻿using System;
using System.Collections.Generic;

namespace PDCProjectApi.Data;

/// <summary>
/// nơi chứa dữ liệu ban đầu khi nhận từ NPIS
/// </summary>
public partial class PcPaIpAutoPoPendingNpi
{
    public DateTime? CreatedDate { get; set; }

    public string? CreatedBy { get; set; }

    public DateTime? ModifiedDate { get; set; }

    public string? ModifiedBy { get; set; }

    public bool? Active { get; set; }

    public Guid Id { get; set; }

    public string PartNo { get; set; } = null!;

    public string Vendor { get; set; } = null!;

    public string DeliveryKey { get; set; } = null!;

    public string? Dim { get; set; }

    public string? Drawing { get; set; }

    public string? Ecn { get; set; }

    public int? OrderQuantity { get; set; }

    public string? OrderMethod { get; set; }

    public string? DeliveryDate { get; set; }

    public string? DeliveryInstruction { get; set; }

    public string? LimitationMark { get; set; }

    public string? MainBody { get; set; }

    public string? PoOrdered { get; set; }

    public string? Action { get; set; }
}
