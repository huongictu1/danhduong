﻿using System;
using System.Collections.Generic;

namespace PDCProjectApi.Data;

public partial class InvOutputPartHi
{
    public DateTime? CreatedDate { get; set; }

    public string? CreatedBy { get; set; }

    public DateTime? ModifiedDate { get; set; }

    public string? ModifiedBy { get; set; }

    public bool? Active { get; set; }

    public Guid Id { get; set; }

    public string? PartNo { get; set; }

    public string? Dim { get; set; }

    public string? Cp { get; set; }

    public string? PartName { get; set; }

    public string? Vendor { get; set; }

    public string? CoMain { get; set; }

    public string? Model { get; set; }

    public string? DesCom { get; set; }

    public string? OrderMethod { get; set; }

    public string? UnitPrice { get; set; }

    public string? SnpBox { get; set; }

    public string? PackingMethod { get; set; }

    public string? KindOfPart { get; set; }

    public string? TypeOfPart { get; set; }

    public string? ProcessUsing { get; set; }

    public string? QtyKeepLine { get; set; }

    public string? TotalLt { get; set; }

    public string? Sp { get; set; }

    public string? InvControlMethod { get; set; }

    public string? SpCheckHis { get; set; }

    public string? PiResultHis { get; set; }

    public string? OmmitedHis { get; set; }

    public string? Term { get; set; }

    public string[]? UrgentCase { get; set; }

    public string? Product { get; set; }

    public string? DefectHis { get; set; }
}
