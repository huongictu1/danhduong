﻿using System;
using System.Collections.Generic;

namespace PDCProjectApi.Data;

public partial class LinkageEucIjB101
{
    public Guid Id { get; set; }

    public DateTime? CreatedDate { get; set; }

    public bool? Active { get; set; }

    public string CdFact { get; set; } = null!;

    public string NoParts { get; set; } = null!;

    public string? NoAdjDim { get; set; }

    public string? NoInventCntlPoi { get; set; }

    public string CdUseBlock { get; set; } = null!;

    public string? DtNecessExpecYearMonth { get; set; }

    public string? DtNecessExpec { get; set; }

    public string? TmNecessExpec { get; set; }

    public string? QtNecessExpec { get; set; }

    public string? QtNoShipDem { get; set; }

    public string? CfDemCre { get; set; }

    public string? CfDemStat { get; set; }

    public string? NoPartsUpperItem { get; set; }

    public string? DtDelUpperOrdYearMonth { get; set; }

    public string? DtDeliberyUpperOrd { get; set; }

    public string? QtArgmetUpperOrd { get; set; }
}
