﻿using System;
using System.Collections.Generic;

namespace PDCProjectApi.Data;

public partial class HistoryTodStructureMasterPacking
{
    public Guid? Id { get; set; }

    public DateTime? CreatedDate { get; set; }

    public string? CreatedBy { get; set; }

    public DateTime? ApprovedDate { get; set; }

    public string? ApprovedBy { get; set; }

    public string? PartNo { get; set; }

    public string? Vendor { get; set; }

    public int? Moq { get; set; }

    public int? PcsBox { get; set; }

    public int? BoxPallet { get; set; }

    public bool? Active { get; set; }

    public Guid IdHistory { get; set; }

    public DateTime? DateHistory { get; set; }
}
