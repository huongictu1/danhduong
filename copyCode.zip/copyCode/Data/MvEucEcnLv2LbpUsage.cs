﻿using System;
using System.Collections.Generic;

namespace PDCProjectApi.Data;

public partial class MvEucEcnLv2LbpUsage
{
    public string? MerKey { get; set; }

    public double? Usage { get; set; }

    public DateTime? CreatedDate { get; set; }
}
