﻿using System;
using System.Collections.Generic;

namespace PDCProjectApi.Data;

public partial class LtFormRegistrationAssyItem
{
    public DateTime? CreatedDate { get; set; }

    public string? CreatedBy { get; set; }

    public DateTime? ModifiedDate { get; set; }

    public string? ModifiedBy { get; set; }

    public bool? Active { get; set; }

    public Guid Id { get; set; }

    public string? PartNo { get; set; }

    public string? PartName { get; set; }

    public string? Model { get; set; }

    public string? ChangingReason { get; set; }

    public string? ChangingMethod { get; set; }

    public DateOnly? RequestEffectiveDate { get; set; }

    public string? MinQty { get; set; }

    public string? MaxQty { get; set; }

    public string? ProcessingArea { get; set; }

    public string? ProcessWork { get; set; }

    public string? TotalStation { get; set; }

    public string? UsingStation { get; set; }

    public string? UnitStocker { get; set; }

    public string? SafetyQty { get; set; }

    public string? SupplyQty { get; set; }

    public string? PickupTime { get; set; }

    public string? FromLocation { get; set; }

    public string? ToLocation { get; set; }

    public string? Distance { get; set; }

    public string? Transportation { get; set; }

    public string? CrossPoint { get; set; }

    public string? SuppyTime { get; set; }

    public string? Note { get; set; }

    public string? FromAddress { get; set; }

    public string? ToAddress { get; set; }

    public string? ApprovedBy { get; set; }

    public DateTime? ApprovedDate { get; set; }

    public int? ApprovedStatus { get; set; }

    public string? RequestNo { get; set; }
}
