﻿using System;
using System.Collections.Generic;

namespace PDCProjectApi.Data;

public partial class HistoryTodStructureMasterMerchandise
{
    public Guid? Id { get; set; }

    public DateTime? CreatedDate { get; set; }

    public string? Model { get; set; }

    public string? Merchandise { get; set; }

    public string? DestName { get; set; }

    public string? Status { get; set; }

    public string? Product { get; set; }

    public string? Factory { get; set; }

    public DateOnly? StartProductionDate { get; set; }

    public string? FcVolumeDel { get; set; }

    public string? Remark { get; set; }

    public string? CreatedBy { get; set; }

    public string? ApprovedBy { get; set; }

    public DateTime? ApprovedDate { get; set; }

    public bool? Active { get; set; }

    public Guid IdHistory { get; set; }

    public DateTime? DateHistory { get; set; }

    public string? Bc { get; set; }
}
