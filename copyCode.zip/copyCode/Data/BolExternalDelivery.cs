﻿using System;
using System.Collections.Generic;

namespace PDCProjectApi.Data;

public partial class BolExternalDelivery
{
    public DateTime? CreatedDate { get; set; }

    public string? CreatedBy { get; set; }

    public DateTime? ModifiedDate { get; set; }

    public string? ModifiedBy { get; set; }

    public bool? Active { get; set; }

    public Guid Id { get; set; }

    public string? Model { get; set; }

    public string? Phase { get; set; }

    public string? CodeDestination { get; set; }

    public string? NameDestination { get; set; }

    public string? BodyNo { get; set; }

    public string? ApplicationDlvNo { get; set; }

    public string? Order { get; set; }

    public string? SCode { get; set; }

    public double? QtyShip { get; set; }

    public string? ShipFrom { get; set; }

    public string? DeliveryPlace { get; set; }

    public string? Dept { get; set; }

    public string? Attn { get; set; }

    public string? Po { get; set; }

    public string? InvNo { get; set; }

    public string? Status { get; set; }

    public string? Category { get; set; }

    public string? Brand { get; set; }

    public string? TypeDie { get; set; }

    public DateOnly? EtdFactory { get; set; }

    public DateOnly? EtdPort { get; set; }

    public DateOnly? EtaDeliveryPlace { get; set; }

    public DateOnly? EtaPort { get; set; }

    public double? QtyDelivery { get; set; }
}
