﻿using System;
using System.Collections.Generic;

namespace PDCProjectApi.Data;

public partial class MvEucEcnLv2IjMerchandise
{
    public string? MerKey { get; set; }

    public string? Merchandise { get; set; }

    public DateTime? CreatedDate { get; set; }
}
