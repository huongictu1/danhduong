﻿using System;
using System.Collections.Generic;

namespace PDCProjectApi.Data;

public partial class VlinkageHksLivePpLbp
{
    public string? ProductCode { get; set; }

    public string? LineNo { get; set; }

    public string? PalletDate { get; set; }

    public string? Shift { get; set; }

    public string? FromTime { get; set; }

    public string? ToTime { get; set; }

    public string? PlanQty { get; set; }

    public string? Merchandise { get; set; }

    public string? Destination { get; set; }

    public string? Actual { get; set; }

    public string? TimeWithin { get; set; }
}
