﻿using System;
using System.Collections.Generic;

namespace PDCProjectApi.Data;

public partial class VlinkageHksStoreInOut
{
    public DateTime? DateEntry { get; set; }

    public string? UserEntry { get; set; }

    public string? PalletDate { get; set; }

    public string? PartNo { get; set; }

    public string? DeptName { get; set; }

    public string? FullName { get; set; }

    public string? LotNo { get; set; }

    public string? CardName { get; set; }

    public double? IOut { get; set; }

    public double? Qty { get; set; }

    public string? ToSpace { get; set; }

    public string? Pic { get; set; }

    public string? Remark { get; set; }

    public string? Machine { get; set; }

    public string? PicPdc2 { get; set; }

    public double? Pdc2QtyOut { get; set; }
}
