﻿using System;
using System.Collections.Generic;

namespace PDCProjectApi.Data;

public partial class TodTodOutput2DeadlineIj
{
    public DateTime? CreatedDate { get; set; }

    public string? CreatedBy { get; set; }

    public DateTime? ModifiedDate { get; set; }

    public string? ModifiedBy { get; set; }

    public bool? Active { get; set; }

    public Guid Id { get; set; }

    public string? Bc { get; set; }

    public string? PartNo { get; set; }

    public string? Alternative { get; set; }

    public string? PartName { get; set; }

    public string? Vendor { get; set; }

    public string? Model { get; set; }

    public string? Destination { get; set; }

    public string? DeadlinePlan { get; set; }

    public string? DeadlineActual { get; set; }

    public string? DeadlineIncl { get; set; }

    public string? Pic { get; set; }
}
