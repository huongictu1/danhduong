﻿using System;
using System.Collections.Generic;

namespace PDCProjectApi.Data;

public partial class AdmDetailUserDept
{
    public DateTime? CreatedDate { get; set; }

    public string? CreatedBy { get; set; }

    public DateTime? ModifiedDate { get; set; }

    public string? ModifiedBy { get; set; }

    public bool? Active { get; set; }

    public Guid Id { get; set; }

    public Guid? UserId { get; set; }

    public Guid? DeptId { get; set; }

    public virtual AdmMasterDepartment? Dept { get; set; }

    public virtual AdmUserInformation? User { get; set; }
}
