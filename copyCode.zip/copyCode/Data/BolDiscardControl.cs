﻿using System;
using System.Collections.Generic;

namespace PDCProjectApi.Data;

public partial class BolDiscardControl
{
    public DateTime? CreatedDate { get; set; }

    public string? CreatedBy { get; set; }

    public DateTime? ModifiedDate { get; set; }

    public string? ModifiedBy { get; set; }

    public bool? Active { get; set; }

    public Guid Id { get; set; }

    public string? ApplicationNo { get; set; }

    public string? Department { get; set; }

    public string? Model { get; set; }

    public string? Phase { get; set; }

    public string? CodeDestination { get; set; }

    public string? NameDestination { get; set; }

    public double? Qty { get; set; }

    public DateOnly? ReceivedDate { get; set; }

    public double? QtyDiscard { get; set; }

    public string? BodyNo { get; set; }

    public string? Category { get; set; }

    public string? Brand { get; set; }

    public string? PartNo { get; set; }

    public string? PartName { get; set; }

    public string? PartLevel { get; set; }

    public string? ApplicationDlvNo { get; set; }

    public string? TypeDie { get; set; }

    public DateOnly? RegisterDiscardDate { get; set; }

    public DateOnly? DiscardDate { get; set; }

    public string? DiscardLetter { get; set; }

    public Guid? IdDelivery { get; set; }

    public DateOnly? DeadlineDisposal { get; set; }
}
