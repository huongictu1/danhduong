﻿using System;
using System.Collections.Generic;

namespace PDCProjectApi.Data;

public partial class LinkageEucIjJ1001
{
    public string? Factory { get; set; }

    public string? Vendor { get; set; }

    public string? PartsNo { get; set; }

    public string? Dim { get; set; }

    public string? OrderMethod { get; set; }

    public string? DeliveryLot { get; set; }

    public string? StandardPack { get; set; }

    public string? PoLeadTime { get; set; }

    public Guid Id { get; set; }

    public DateTime? CreatedDate { get; set; }

    public bool? Active { get; set; }
}
