﻿using System;
using System.Collections.Generic;

namespace PDCProjectApi.Data;

public partial class LtFormRegistrationOther
{
    public DateTime? CreatedDate { get; set; }

    public string? CreatedBy { get; set; }

    public DateTime? ModifiedDate { get; set; }

    public string? ModifiedBy { get; set; }

    public bool? Active { get; set; }

    public Guid Id { get; set; }

    public string? PartNo { get; set; }

    public string? Vendor { get; set; }

    public string? Reason { get; set; }

    public DateOnly? EffectiveDate { get; set; }

    public string? LeadTime { get; set; }

    public string? Process { get; set; }

    public DateTime? ApprovedDate { get; set; }

    public string? ApprovedBy { get; set; }

    public string? Model { get; set; }
}
