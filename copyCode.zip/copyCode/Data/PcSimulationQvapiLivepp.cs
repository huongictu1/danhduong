﻿using System;
using System.Collections.Generic;

namespace PDCProjectApi.Data;

public partial class PcSimulationQvapiLivepp
{
    public string? ProductCode { get; set; }

    public string? LineNo { get; set; }

    public string? PalletDate { get; set; }

    public string? Shift { get; set; }

    public string? FromTime { get; set; }

    public string? ToTime { get; set; }

    public string? PlanQty { get; set; }

    public string? Merchandise { get; set; }

    public string? Destination { get; set; }

    public string? Actual { get; set; }

    public string? TimeWithin { get; set; }

    public DateTime? CreatedDate { get; set; }

    public string? CreatedBy { get; set; }

    public DateTime? ModifiedDate { get; set; }

    public string? ModifiedBy { get; set; }

    public bool? Active { get; set; }

    public Guid Id { get; set; }
}
