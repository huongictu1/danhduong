﻿using System;
using System.Collections.Generic;

namespace PDCProjectApi.Data;

public partial class MvEucH445MerUsage
{
    public string? MerKey { get; set; }

    public double? Usage { get; set; }

    public DateTime? CreatedDate { get; set; }
}
