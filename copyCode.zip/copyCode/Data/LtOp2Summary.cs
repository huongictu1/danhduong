﻿using System;
using System.Collections.Generic;

namespace PDCProjectApi.Data;

public partial class LtOp2Summary
{
    public DateTime? CreatedDate { get; set; }

    public string? CreatedBy { get; set; }

    public DateTime? ModifiedDate { get; set; }

    public string? ModifiedBy { get; set; }

    public bool? Active { get; set; }

    public Guid Id { get; set; }

    public string? PartNo { get; set; }

    public string? PartName { get; set; }

    public string? Vendor { get; set; }

    public string? Model { get; set; }

    public string? OrderMethod { get; set; }

    public string? KindOfPart { get; set; }

    public string? MovingRoute { get; set; }

    public double? Moq { get; set; }

    public double? PcsBox { get; set; }

    public double? BoxPl { get; set; }

    public double? PcsPl { get; set; }

    public double? WorkingTime { get; set; }

    public double? MaxPpShift { get; set; }

    public double? Pdc2Rec { get; set; }

    public double? Pdc2Pickup { get; set; }

    public double? Pdc2Moving { get; set; }

    public double? Pdc2Supply { get; set; }

    public double? Pdc2Safety { get; set; }

    public double? Pdc2Total { get; set; }

    public string? AssyMainArea { get; set; }

    public double? AssyMainPickup { get; set; }

    public double? AssyMainMoving { get; set; }

    public double? AssyMainSupply { get; set; }

    public double? AssyMainProcess { get; set; }

    public double? AssyMainStock { get; set; }

    public double? AssyMainTotal { get; set; }

    public string? AssyKittingArea { get; set; }

    public double? AssyKittingPickup { get; set; }

    public double? AssyKittingMoving { get; set; }

    public double? AssyKittingSupply { get; set; }

    public double? AssyKittingProcess { get; set; }

    public double? AssyKittingStock { get; set; }

    public double? AssyKittingTotal { get; set; }

    public string? AssySubcArea { get; set; }

    public double? AssySubcPickup { get; set; }

    public double? AssySubcMoving { get; set; }

    public double? AssySubcSupply { get; set; }

    public double? AssySubcProcess { get; set; }

    public double? AssySubcStock { get; set; }

    public double? AssySubcTotal { get; set; }

    public string? AssySilkArea { get; set; }

    public double? AssySilkPickup { get; set; }

    public double? AssySilkMoving { get; set; }

    public double? AssySilkSupply { get; set; }

    public double? AssySilkProcess { get; set; }

    public double? AssySilkStock { get; set; }

    public double? AssySilkTotal { get; set; }

    public string? AssyMediaArea { get; set; }

    public double? AssyMediaPickup { get; set; }

    public double? AssyMediaMoving { get; set; }

    public double? AssyMediaSupply { get; set; }

    public double? AssyMediaProcess { get; set; }

    public double? AssyMediaStock { get; set; }

    public double? AssyMediaTotal { get; set; }

    public string? AssyMipArea { get; set; }

    public double? AssyMipPickup { get; set; }

    public double? AssyMipMoving { get; set; }

    public double? AssyMipSupply { get; set; }

    public double? AssyMipProcess { get; set; }

    public double? AssyMipStock { get; set; }

    public double? AssyMipTotal { get; set; }

    public string? AssyCounterArea { get; set; }

    public double? AssyCounterPickup { get; set; }

    public double? AssyCounterMoving { get; set; }

    public double? AssyCounterSupply { get; set; }

    public double? AssyCounterProcess { get; set; }

    public double? AssyCounterStock { get; set; }

    public double? AssyCounterTotal { get; set; }

    public string? AssySubpArea { get; set; }

    public double? AssySubpPickup { get; set; }

    public double? AssySubpMoving { get; set; }

    public double? AssySubpSupply { get; set; }

    public double? AssySubpProcess { get; set; }

    public double? AssySubpStock { get; set; }

    public double? AssySubpTotal { get; set; }

    public string? IhArea { get; set; }

    public double? IhProcess { get; set; }

    public double? IhTransportation { get; set; }

    public double? IhSafety { get; set; }

    public double? IhBuild { get; set; }

    public double? IhTotal { get; set; }

    public double? OtherProcess { get; set; }

    public double? OtherLt { get; set; }

    public double? OtherTotal { get; set; }

    public double? TotalLtPdc2 { get; set; }

    public double? TotalLtAssy { get; set; }

    public double? TotalLtIh { get; set; }

    public double? TotalLtOther { get; set; }

    public double? TotalLtTotal { get; set; }

    public double? DoQty { get; set; }

    public double? DoLt { get; set; }

    public double? MaxUsage { get; set; }

    public string? DoDelivery { get; set; }

    public string? Product { get; set; }

    public double? MainQty { get; set; }

    public double? KittingQty { get; set; }

    public double? SubcQty { get; set; }

    public double? SilkQty { get; set; }

    public double? MediaQty { get; set; }

    public double? MipQty { get; set; }

    public double? SubpQty { get; set; }

    public double? CounterQty { get; set; }
}
