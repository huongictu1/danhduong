﻿using System;
using System.Collections.Generic;

namespace PDCProjectApi.Data;

public partial class TableColumns2
{
    public string? StringAgg { get; set; }
}
