﻿using System;
using System.Collections.Generic;

namespace PDCProjectApi.Data;

public partial class MvLinkageIjE700
{
    public string? NoTransaction { get; set; }

    public string? CdFact { get; set; }

    public string? NoParts { get; set; }

    public string? NoAdjDim { get; set; }

    public string? NoInventCntlPoi { get; set; }

    public string? NoLine { get; set; }

    public string? MkProcess { get; set; }

    public string? CdBlockFrm { get; set; }

    public string? NoFlctFrmStockPoi { get; set; }

    public string? QtFlctAfterFrm { get; set; }

    public string? CfSupplyFrmClass { get; set; }

    public string? CdBlockTo { get; set; }

    public string? NoFlctToStockPoi { get; set; }

    public string? QtFlctAfterTo { get; set; }

    public string? CfSupplyToClass { get; set; }

    public string? QtFluct { get; set; }

    public string? CtAll { get; set; }

    public string? Amount { get; set; }

    public string? CdInoutStorage { get; set; }

    public string? CfJournalClss { get; set; }

    public string? DtInventFluct { get; set; }

    public string? TmInventFluct { get; set; }

    public string? NoSlip { get; set; }

    public string? CfChildBase { get; set; }

    public string? CfOrd { get; set; }

    public string? CfTransOrdTo { get; set; }

    public string? NoPoNo { get; set; }

    public string? CdInspJudg { get; set; }

    public string? CdLossPartsReason { get; set; }

    public string? CdOccurrenceArea { get; set; }

    public string? CdResponsArea { get; set; }

    public string? CdUpdateTerminal { get; set; }

    public string? NoHistChange { get; set; }

    public string? NoHistChangeSfx { get; set; }

    public string? QtAppPrice { get; set; }

    public string? Consumption { get; set; }

    public string? QtDivision { get; set; }

    public string? CdDataCntl { get; set; }

    public string? DtEntry { get; set; }

    public string? NmEntryPerson { get; set; }

    public string? DtRenew { get; set; }

    public string? NmRenewPerson { get; set; }

    public string? CdTrans { get; set; }

    public string? DateInput { get; set; }

    public DateTime? CreatedDate { get; set; }
}
