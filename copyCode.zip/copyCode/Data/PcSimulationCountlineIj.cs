﻿using System;
using System.Collections.Generic;

namespace PDCProjectApi.Data;

public partial class PcSimulationCountlineIj
{
    public DateTime? CreatedDate { get; set; }

    public string? CreatedBy { get; set; }

    public DateTime? ModifiedDate { get; set; }

    public string? ModifiedBy { get; set; }

    public bool? Active { get; set; }

    public Guid Id { get; set; }

    public string PartNo { get; set; } = null!;

    public string Vendor { get; set; } = null!;

    public string Ratio { get; set; } = null!;

    public string Model { get; set; } = null!;

    public string Merchandise { get; set; } = null!;

    public double[] CountValue { get; set; } = null!;

    public int DayQty { get; set; }

    public string Bc { get; set; } = null!;

    public string? Dim { get; set; }

    public string PartName { get; set; } = null!;

    public string? Factory { get; set; }

    public string EffectiveDateChange { get; set; } = null!;

    public string? RatioChange { get; set; }

    public string? DoPic { get; set; }

    public string? PoPic { get; set; }

    public DateTime[]? DateVal { get; set; }

    public string? Destination { get; set; }
}
