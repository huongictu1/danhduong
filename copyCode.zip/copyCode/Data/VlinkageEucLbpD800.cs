﻿using System;
using System.Collections.Generic;

namespace PDCProjectApi.Data;

public partial class VlinkageEucLbpD800
{
    public string? DtYm { get; set; }

    public string? CdFact { get; set; }

    public string? NoParts { get; set; }

    public string? NoAdjDim { get; set; }

    public string? NoInventCntlPoi { get; set; }

    public string? NoStockPoi { get; set; }

    public string? CdBlock { get; set; }

    public string? MkProcess { get; set; }

    public string? CdSettlement { get; set; }

    public string? CfSgrp { get; set; }

    public string? CfFact { get; set; }

    public string? CfChildBase { get; set; }

    public string? CdCstmPrnt { get; set; }

    public string? CfSupplyClass { get; set; }

    public string? MkFamily { get; set; }

    public double? QtStock { get; set; }

    public double? CtAll { get; set; }

    public double? CtCntrl { get; set; }

    public double? CtAllAmt { get; set; }

    public double? CtVariable { get; set; }

    public double? CtProduct { get; set; }

    public double? CtCntrlAmt { get; set; }

    public double? CtIndirect { get; set; }

    public double? CtInvAddValue { get; set; }

    public double? PtAddValue { get; set; }

    public string? NmPartsLocal { get; set; }

    public double? CtVariableAmt { get; set; }

    public double? CtPrductAmt { get; set; }

    public double? CtIndirectAmt { get; set; }

    public double? CtInvAddValueAmt { get; set; }

    public string? CdDataCntl { get; set; }

    public DateOnly? DtEntry { get; set; }

    public string? NmEntryPerson { get; set; }

    public DateOnly? DtRenew { get; set; }

    public string? NmRenewPerson { get; set; }

    public string? CdTrans { get; set; }
}
