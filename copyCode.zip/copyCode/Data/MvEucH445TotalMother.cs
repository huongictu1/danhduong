﻿using System;
using System.Collections.Generic;

namespace PDCProjectApi.Data;

public partial class MvEucH445TotalMother
{
    public string? BKey { get; set; }

    public string? Mother { get; set; }

    public DateTime? CreatedDate { get; set; }
}
