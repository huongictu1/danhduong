﻿using System;
using System.Collections.Generic;

namespace PDCProjectApi.Data;

public partial class TodTodUploadContSchedule
{
    public DateTime? CreatedDate { get; set; }

    public string? CreatedBy { get; set; }

    public DateTime? ModifiedDate { get; set; }

    public string? ModifiedBy { get; set; }

    public bool? Active { get; set; }

    public Guid Id { get; set; }

    public string? Vendor { get; set; }

    public DateTime? ApprovedDate { get; set; }

    public string? ApprovedBy { get; set; }

    public string? ContainerNo { get; set; }

    public string? InvoiceNo { get; set; }

    public string? Location { get; set; }

    public DateOnly? EtaHp { get; set; }

    public DateOnly? EtaCvn { get; set; }

    public bool? IsChange { get; set; }
}
