﻿using System;
using System.Collections.Generic;

namespace PDCProjectApi.Data;

public partial class AdmMasterDepartment
{
    public DateTime? CreatedDate { get; set; }

    public string? CreatedBy { get; set; }

    public DateTime? ModifiedDate { get; set; }

    public string? ModifiedBy { get; set; }

    public bool? Active { get; set; }

    public Guid Id { get; set; }

    public string? DeptFullName { get; set; }

    public string? DeptShortName { get; set; }

    public string? Division { get; set; }

    public Guid? FactId { get; set; }

    public string? CostCenter { get; set; }

    public int? HrmId { get; set; }

    public virtual ICollection<AdmDetailUserDept> AdmDetailUserDepts { get; set; } = new List<AdmDetailUserDept>();

    public virtual AdmMasterFactory? Fact { get; set; }
}
