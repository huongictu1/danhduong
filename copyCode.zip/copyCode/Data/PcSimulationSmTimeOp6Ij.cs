﻿using System;
using System.Collections.Generic;

namespace PDCProjectApi.Data;

public partial class PcSimulationSmTimeOp6Ij
{
    public DateTime? CreatedDate { get; set; }

    public string? CreatedBy { get; set; }

    public DateTime? ModifiedDate { get; set; }

    public string? ModifiedBy { get; set; }

    public bool? Active { get; set; }

    public Guid Id { get; set; }

    public string Bc { get; set; } = null!;

    public string PartNo { get; set; } = null!;

    public string? Dim { get; set; }

    public string? PartMovingRoute { get; set; }

    public string PartName { get; set; } = null!;

    public string Vendor { get; set; } = null!;

    public string? MoqOrder { get; set; }

    public string? Model { get; set; }

    public string? Destination { get; set; }

    public string? MainAlt { get; set; }

    public string? Factory { get; set; }

    public string? Ratio { get; set; }

    public string? EffectivedateChange { get; set; }

    public string? RatioChange { get; set; }

    public string? DoPic { get; set; }

    public string? PoPic { get; set; }

    public double[] Demand { get; set; } = null!;

    public double[] DemandCp { get; set; } = null!;

    public string? Pair { get; set; }

    public double[] OtherOrder { get; set; } = null!;

    public DateTime[] BlockTime { get; set; } = null!;

    public double[] DoVal { get; set; } = null!;

    public double[] LeadTime { get; set; } = null!;

    public double[] Remain { get; set; } = null!;

    public double[] RemainIncl { get; set; } = null!;

    public double[] AbnormalPcs { get; set; } = null!;

    public double[] AbnormalPallet { get; set; } = null!;

    public double Inventory { get; set; }

    public int Gap { get; set; }

    public string? Pcsbox { get; set; }

    public double[]? OverStockPcs { get; set; }
}
