﻿using System;
using System.Collections.Generic;

namespace PDCProjectApi.Data;

public partial class PcSimulationFcdoLbp
{
    public DateTime? CreatedDate { get; set; }

    public string? CreatedBy { get; set; }

    public DateTime? ModifiedDate { get; set; }

    public string? ModifiedBy { get; set; }

    public bool? Active { get; set; }

    public Guid Id { get; set; }

    public string Bc { get; set; } = null!;

    public string PartNo { get; set; } = null!;

    public string Vendor { get; set; } = null!;

    public double? Snp { get; set; }

    public double? Snp1 { get; set; }

    public string? KindOfProcess { get; set; }

    public double? OrderQty { get; set; }

    public string? DateDelivery { get; set; }

    public string? TimeDelivery { get; set; }

    public string? Moq { get; set; }

    public string? DoPic { get; set; }

    public string? PoPic { get; set; }

    public string? PoKey { get; set; }

    public string? DeliveryLocation { get; set; }

    public string? TermIssue { get; set; }

    public bool? InTerm { get; set; }
}
