﻿using System;
using System.Collections.Generic;

namespace PDCProjectApi.Data;

public partial class MvLinkageLbpD101Dict
{
    public string? BKey { get; set; }

    public double? BValue { get; set; }

    public DateTime? BDate { get; set; }
}
