﻿using System;
using System.Collections.Generic;

namespace PDCProjectApi.Data;

public partial class PcSimulationTempLivepp
{
    public string? PalletDate { get; set; }

    public string? ProductCode { get; set; }

    public string? LineNo { get; set; }

    public string? Merchandise { get; set; }

    public string? Shift { get; set; }

    public string? BTime { get; set; }

    public double? BActual { get; set; }

    public double? BQuantity { get; set; }

    public DateTime? BDate { get; set; }
}
