﻿using System;
using System.Collections.Generic;

namespace PDCProjectApi.Data;

/// <summary>
/// tự tạo request dựa trên các bảng ip
/// </summary>
public partial class PcPaRequestRevisePo
{
    public DateTime? CreatedDate { get; set; }

    public string? CreatedBy { get; set; }

    public DateTime? ModifiedDate { get; set; }

    public string? ModifiedBy { get; set; }

    public bool? Active { get; set; }

    public Guid Id { get; set; }

    public string RequestNo { get; set; } = null!;

    public string? Requester { get; set; }

    public string? Status { get; set; }

    public string? NextApproval { get; set; }

    public string? ConfirmSendRq { get; set; }

    public string? ConfirmUpdateNpis { get; set; }

    public DateTime? IssuedDate { get; set; }

    public string? Product { get; set; }

    public virtual ICollection<PcPaIp11AutoEriIssue> PcPaIp11AutoEriIssues { get; set; } = new List<PcPaIp11AutoEriIssue>();

    public virtual ICollection<PcPaIp121ManualHandPoHand> PcPaIp121ManualHandPoHands { get; set; } = new List<PcPaIp121ManualHandPoHand>();

    public virtual ICollection<PcPaIp122ManualHandPoRevise> PcPaIp122ManualHandPoRevises { get; set; } = new List<PcPaIp122ManualHandPoRevise>();

    public virtual ICollection<PcPaIp13aAutoPoPendingNpi> PcPaIp13aAutoPoPendingNpis { get; set; } = new List<PcPaIp13aAutoPoPendingNpi>();

    public virtual ICollection<PcPaIp13bAutoIssueFormRevise> PcPaIp13bAutoIssueFormRevises { get; set; } = new List<PcPaIp13bAutoIssueFormRevise>();

    public virtual ICollection<PcPaIp13cAutoIssueFormRevise> PcPaIp13cAutoIssueFormRevises { get; set; } = new List<PcPaIp13cAutoIssueFormRevise>();

    public virtual ICollection<PcPaIp13dAutoIssueFormRevise> PcPaIp13dAutoIssueFormRevises { get; set; } = new List<PcPaIp13dAutoIssueFormRevise>();

    public virtual ICollection<PcPaRequestRevisePoProcess> PcPaRequestRevisePoProcesses { get; set; } = new List<PcPaRequestRevisePoProcess>();
}
