﻿using System;
using System.Collections.Generic;

namespace PDCProjectApi.Data;

public partial class MvEucH4451
{
    public string? BKey { get; set; }

    public double? BValue { get; set; }

    public DateTime? BCreated { get; set; }
}
