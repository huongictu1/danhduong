﻿using System;
using System.Collections.Generic;

namespace PDCProjectApi.Data;

public partial class HistoryTodFcdelMasterMaxGaplot
{
    public DateTime? CreatedDate { get; set; }

    public string? CreatedBy { get; set; }

    public DateTime? ModifiedDate { get; set; }

    public string? ModifiedBy { get; set; }

    public bool? Active { get; set; }

    public Guid Id { get; set; }

    public string Vendor { get; set; } = null!;

    public double? MaxGapDs { get; set; }

    public double? MaxGapNs { get; set; }

    public int Month { get; set; }

    public int Year { get; set; }

    public string? ApprovalBy { get; set; }

    public DateTime? ApprovalDate { get; set; }

    public Guid HistoryId { get; set; }

    public DateTime? HistoryDate { get; set; }
}
