﻿using System;
using System.Collections.Generic;

namespace PDCProjectApi.Data;

public partial class TodFcdelOutputSumupVendorLbp
{
    public DateTime? CreatedDate { get; set; }

    public string? CreatedBy { get; set; }

    public DateTime? ModifiedDate { get; set; }

    public string? ModifiedBy { get; set; }

    public bool? Active { get; set; }

    public string? VendorCode { get; set; }

    public string? VendorName { get; set; }

    public string? DeliveryRoute { get; set; }

    public DateOnly[]? SumupDate { get; set; }

    public double[]? SumupValueDayByShift { get; set; }

    public double[]? SumupValueNightByShift { get; set; }

    public Guid Id { get; set; }

    public double[]? SumupValueDayByLot { get; set; }

    public double[]? SumupValueNightByLot { get; set; }
}
