﻿using System;
using System.Collections.Generic;

namespace PDCProjectApi.Data;

/// <summary>
/// kỳ tuyển người
/// </summary>
public partial class MpRecMasterPeriod
{
    public DateTime? CreatedDate { get; set; }

    public string? CreatedBy { get; set; }

    public DateTime? ModifiedDate { get; set; }

    public string? ModifiedBy { get; set; }

    public bool? Active { get; set; }

    public Guid Id { get; set; }

    public string PeriodName { get; set; } = null!;

    public DateOnly DateFrom { get; set; }

    public DateOnly DateTo { get; set; }

    public string? Note { get; set; }

    public virtual ICollection<MpRecAllMaintainIp4> MpRecAllMaintainIp4s { get; set; } = new List<MpRecAllMaintainIp4>();

    public virtual ICollection<MpRecDeptActualIp3> MpRecDeptActualIp3s { get; set; } = new List<MpRecDeptActualIp3>();

    public virtual ICollection<MpRecDeptPlanIp2> MpRecDeptPlanIp2s { get; set; } = new List<MpRecDeptPlanIp2>();
}
