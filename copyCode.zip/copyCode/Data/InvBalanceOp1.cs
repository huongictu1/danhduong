﻿using System;
using System.Collections.Generic;

namespace PDCProjectApi.Data;

public partial class InvBalanceOp1
{
    public DateTime? CreatedDate { get; set; }

    public string? CreatedBy { get; set; }

    public DateTime? ModifiedDate { get; set; }

    public string? ModifiedBy { get; set; }

    public bool? Active { get; set; }

    public Guid Id { get; set; }

    public string? PartNo { get; set; }

    public string? PartName { get; set; }

    public string? Vendor { get; set; }

    public double? UnitPrice { get; set; }

    public string? Set { get; set; }

    public DateOnly? FromDate { get; set; }

    public DateOnly? ToDate { get; set; }

    public string[]? Department { get; set; }

    public double[]? ActualStock { get; set; }

    public double? TotalActual { get; set; }

    public double? LendingRemain { get; set; }

    public double? NpisStock { get; set; }

    public double? SuspenseStock { get; set; }

    public double? QtySlip { get; set; }

    public double? DifferQty { get; set; }

    public double? DifferAmount { get; set; }

    public string? Reason { get; set; }

    public string? SlipNoPending { get; set; }

    public string? Product { get; set; }
}
