﻿using System;
using System.Collections.Generic;

namespace PDCProjectApi.Data;

public partial class BolMachineDeliveryInfo
{
    public DateTime? CreatedDate { get; set; }

    public string? CreatedBy { get; set; }

    public DateTime? ModifiedDate { get; set; }

    public string? ModifiedBy { get; set; }

    public bool? Active { get; set; }

    public Guid Id { get; set; }

    public string? RequestNo { get; set; }

    public string? Requester { get; set; }

    public string? Department { get; set; }

    public int? Status { get; set; }

    public string? ApplicationNo { get; set; }
}
