﻿using System;
using System.Collections.Generic;

namespace PDCProjectApi.Data;

public partial class VlinkageEucLbpJ5302
{
    public string? CdDataCntl { get; set; }

    public string? CdSplyClass { get; set; }

    public string? CdGlblSply { get; set; }

    public string? CdFact { get; set; }

    public string? CdSply { get; set; }

    public string? CfInventDem { get; set; }

    public string? NoArrange { get; set; }

    public string? CdSplyFact { get; set; }

    public string? CdSplyOficClass { get; set; }

    public string? NmSplyLocal { get; set; }

    public string? NmSplyEng { get; set; }

    public string? NmPresid { get; set; }

    public double? AmCapital { get; set; }

    public string? CdCurr { get; set; }

    public string? MkSubcon { get; set; }

    public double? PdObligPurch { get; set; }

    public string? DtContr { get; set; }

    public string? DtWinsContr { get; set; }

    public string? DtBusinStart { get; set; }

    public string? CdPost { get; set; }

    public string? AdSply { get; set; }

    public string? NmSplySect { get; set; }

    public string? NmPerson { get; set; }

    public string? NoTel { get; set; }

    public string? NoFax { get; set; }

    public string? AdMail { get; set; }

    public string? MkDirectDelvPosb { get; set; }

    public string? MkFixDelvDirctQty { get; set; }

    public string? MkWinsInstal { get; set; }

    public string? MkOrdEdi { get; set; }

    public string? MkEstimEdi { get; set; }

    public string? MkGuartEdi { get; set; }

    public string? MkInventEdi { get; set; }

    public string? MkProxyAcptcEdi { get; set; }

    public string? MkInspResultEdi { get; set; }

    public string? MkPayEdi { get; set; }

    public string? MkDrawEdi { get; set; }

    public string? MkDeducEdi { get; set; }

    public string? CdOrdClassDef { get; set; }

    public string? CdProcurPersonDef { get; set; }

    public string? CdEstimPersonDef { get; set; }

    public double? PdDelvDirctDef { get; set; }

    public double? PdFixPeriodRequiDef { get; set; }

    public double? PdPoIssueDef { get; set; }

    public double? PdPrdcGuartDef { get; set; }

    public double? PdMtrlGuartDef { get; set; }

    public double? PdPrdcInfoDef { get; set; }

    public string? PdDelvQtyRoundDef { get; set; }

    public string? MkResvBalOrdDef { get; set; }

    public string? MkProcurAuthDef { get; set; }

    public string? CdTradeTermsDef { get; set; }

    public string? CdCorpo { get; set; }

    public string? SpCorpo { get; set; }

    public string? WdSplySprvisr { get; set; }

    public string? CdCosmosMaker { get; set; }

    public string? CdMaker { get; set; }

    public string? InPhyciDis { get; set; }

    public string? ArRemk { get; set; }

    public string? MkGratChar { get; set; }

    public string? CdProcClass { get; set; }

    public string? PdEta { get; set; }

    public string? CfReturn { get; set; }

    public string? CfRet { get; set; }

    public DateOnly? DtEntry { get; set; }

    public string? NmEntryPerson { get; set; }

    public DateOnly? DtRenew { get; set; }

    public string? NmRenewPerson { get; set; }

    public string? CdTrans { get; set; }
}
