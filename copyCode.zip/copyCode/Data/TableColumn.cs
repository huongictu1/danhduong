﻿using System;
using System.Collections.Generic;

namespace PDCProjectApi.Data;

public partial class TableColumn
{
    public string? StringAgg { get; set; }
}
