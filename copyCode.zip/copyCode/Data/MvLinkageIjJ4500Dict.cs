﻿using System;
using System.Collections.Generic;

namespace PDCProjectApi.Data;

public partial class MvLinkageIjJ4500Dict
{
    public string? BKey { get; set; }

    public string? BValue { get; set; }

    public DateTime? CreatedDate { get; set; }
}
