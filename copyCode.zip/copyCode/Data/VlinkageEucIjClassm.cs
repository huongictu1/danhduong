﻿using System;
using System.Collections.Generic;

namespace PDCProjectApi.Data;

public partial class VlinkageEucIjClassm
{
    public string? CdInFact { get; set; }

    public string? NoInParts { get; set; }

    public string? CdInBlock { get; set; }

    public string? QtConsumpDivi { get; set; }

    public string? QtConsumptionAll { get; set; }

    public string? QtConsumpDiviAll { get; set; }

    public string? QtConsumpDiviAllSum { get; set; }

    public string? CdPiece { get; set; }

    public string? NmPartsEng { get; set; }

    public string? NoMotherParts { get; set; }

    public string? CdBlock { get; set; }

    public string? NoChldParts { get; set; }

    public string? NoChldAdjDim { get; set; }

    public string? CfChgStatClssH001 { get; set; }

    public string? NoChgNotificationH001 { get; set; }

    public string? CdBlockH001 { get; set; }

    public string? CdProcessH001 { get; set; }

    public string? DtBValidH001 { get; set; }

    public string? MkSubstitH003 { get; set; }

    public string? NoPartsH003 { get; set; }

    public string? NoAdjDimH003 { get; set; }

    public string? NoLegularPartsH003 { get; set; }

    public string? NoLegularAdjDimH003 { get; set; }

    public string? NoSubstitPartsH003 { get; set; }

    public string? PtSubstitH003 { get; set; }

    public string? CdBlockH005 { get; set; }

    public string? RkPrioDiviH005 { get; set; }

    public string? PtRatioH005 { get; set; }

    public string? DtEnty { get; set; }

    public string? NoPath { get; set; }

    public string? CfSupplyClassAll { get; set; }
}
