﻿using System;
using System.Collections.Generic;

namespace PDCProjectApi.Data;

public partial class TodTodOutput1TurnOverDayIj
{
    public DateTime? CreatedDate { get; set; }

    public string? CreatedBy { get; set; }

    public DateTime? ModifiedDate { get; set; }

    public string? ModifiedBy { get; set; }

    public bool? Active { get; set; }

    public Guid Id { get; set; }

    public string PartNo { get; set; } = null!;

    public DateOnly[]? TodDate { get; set; }

    public double[]? TodValue1 { get; set; }

    public string[]? CalcType { get; set; }

    public int[]? CalcOrder { get; set; }

    public string[]? Alternative { get; set; }

    public double[]? TodValue3 { get; set; }

    public double[]? TodValue4 { get; set; }

    public double[]? TodValue5 { get; set; }

    public double[]? TodValue6 { get; set; }

    public double[]? TodValue7 { get; set; }

    public double[]? TodValue8 { get; set; }

    public double[]? TodValue9 { get; set; }

    public double[]? TodValue10 { get; set; }

    public double[]? TodValue11 { get; set; }

    public double[]? TodValue12 { get; set; }

    public double[]? TodValue13 { get; set; }

    public double[]? TodValue14 { get; set; }

    public double[]? TodValue15 { get; set; }

    public double[]? TodValue16 { get; set; }

    public double[]? TodValue17 { get; set; }

    public double[]? TodValue18 { get; set; }

    public double[]? TodValue19 { get; set; }

    public double[]? TodValue20 { get; set; }

    public double[]? TodValue21 { get; set; }

    public double[]? TodValue22 { get; set; }

    public double[]? TodValue23 { get; set; }

    public string[]? Bc { get; set; }

    public string[]? OrderMethod { get; set; }

    public string[]? PartName { get; set; }

    public string[]? Model { get; set; }

    public string[]? Des { get; set; }

    public string[]? Deadline { get; set; }

    public string[]? Vendor { get; set; }

    public double[]? Adjustment { get; set; }

    public int[]? Moq { get; set; }

    public int[]? PcsPallet { get; set; }

    public string[]? Location { get; set; }
}
