﻿using System;
using System.Collections.Generic;

namespace PDCProjectApi.Data;

public partial class InvPartList
{
    public DateTime? CreatedDate { get; set; }

    public string? CreatedBy { get; set; }

    public DateTime? ModifiedDate { get; set; }

    public string? ModifiedBy { get; set; }

    public bool? Active { get; set; }

    public Guid Id { get; set; }

    public string? Product { get; set; }

    public string? PartNo { get; set; }

    public string? Vender { get; set; }

    public string? Schedule { get; set; }
}
