﻿using System;
using System.Collections.Generic;

namespace PDCProjectApi.Data;

public partial class LtOutput0PartListIj
{
    public DateTime? CreatedDate { get; set; }

    public string? CreatedBy { get; set; }

    public DateTime? ModifiedDate { get; set; }

    public string? ModifiedBy { get; set; }

    public bool? Active { get; set; }

    public Guid Id { get; set; }

    public string? PartNo { get; set; }

    public string? PartName { get; set; }

    public string? Vendor { get; set; }

    public string? Ratio { get; set; }

    public string? Model { get; set; }

    public string? LeadTime { get; set; }

    public double? MaxUsage { get; set; }

    public string? OrderMethod { get; set; }

    public int? Moq { get; set; }

    public int? PcsBox { get; set; }

    public int? BoxPl { get; set; }

    public int? PcsPl { get; set; }

    public string? Product { get; set; }

    public DateOnly? Deadline { get; set; }

    public string? LackProcess { get; set; }
}
