﻿using System;
using System.Collections.Generic;

namespace PDCProjectApi.Data;

public partial class PcSimulationMasterTimetableDelivery
{
    public DateTime? CreatedDate { get; set; }

    public string? CreatedBy { get; set; }

    public DateTime? ModifiedDate { get; set; }

    public string? ModifiedBy { get; set; }

    public bool? Active { get; set; }

    public Guid Id { get; set; }

    public string Route { get; set; } = null!;

    public string Gate { get; set; } = null!;

    public string Vendor { get; set; } = null!;

    public string LotNo { get; set; } = null!;

    public string Eta { get; set; } = null!;

    public string Shift { get; set; } = null!;

    public string Product { get; set; } = null!;

    public DateTime? ApprovedDate { get; set; }

    public string? ApprovedBy { get; set; }

    public DateOnly? FromDate { get; set; }

    public DateOnly? ToDate { get; set; }

    public bool? Status { get; set; }

    public string? Bc { get; set; }
}
