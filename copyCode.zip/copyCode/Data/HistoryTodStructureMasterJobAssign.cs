﻿using System;
using System.Collections.Generic;

namespace PDCProjectApi.Data;

public partial class HistoryTodStructureMasterJobAssign
{
    public Guid? Id { get; set; }

    public DateTime? CreatedDate { get; set; }

    public string? Product { get; set; }

    public string? Bc { get; set; }

    public string? VendorCode { get; set; }

    public string? DoPic { get; set; }

    public string? PoPic { get; set; }

    public string? Remark { get; set; }

    public string? CreatedBy { get; set; }

    public string? ApprovedBy { get; set; }

    public DateTime? ApprovedDate { get; set; }

    public bool? Active { get; set; }

    public Guid IdHistory { get; set; }

    public DateTime? DateHistory { get; set; }
}
