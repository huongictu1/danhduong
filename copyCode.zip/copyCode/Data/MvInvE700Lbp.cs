﻿using System;
using System.Collections.Generic;

namespace PDCProjectApi.Data;

public partial class MvInvE700Lbp
{
    public string? NoParts { get; set; }

    public string? NoSlip { get; set; }

    public string? QtFluct { get; set; }
}
