﻿using PDCProjectApi.Services;
using StackExchange.Redis;

namespace PDCProjectApi.Common
{
    public class RedisConnectionManager
    {
        private static ConnectionMultiplexer _redisConnection;
        private static readonly object _lockObject = new object();
        private static readonly IGlobalVariable global = new GlobalVariable();
        private static readonly string redisServer = global.ReturnRedisServer();

        private RedisConnectionManager() { }

        public static ConnectionMultiplexer GetRedisConnection()
        {
            lock (_lockObject)
            {
                if (_redisConnection == null)
                {
                    var redisConfig = ConfigurationOptions.Parse(redisServer);
                    redisConfig.SyncTimeout = 1200000; /*1200000*/
                    redisConfig.AllowAdmin = true;
                    _redisConnection = ConnectionMultiplexer.Connect(redisConfig);
                }
            }

            return _redisConnection;
        }

        //public void Dispose()
        //{
        //    _redisConnection?.Dispose();
        //}
       
    }

}
