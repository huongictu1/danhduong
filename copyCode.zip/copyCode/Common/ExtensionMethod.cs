﻿using DocumentFormat.OpenXml.Spreadsheet;
using Microsoft.AspNetCore.StaticFiles;
using Microsoft.EntityFrameworkCore.Storage.ValueConversion;
using Newtonsoft.Json;
using OfficeOpenXml.FormulaParsing.Excel.Functions;
using OfficeOpenXml.FormulaParsing.Excel.Functions.DateTime;
using PDCProjectApi.Data;
using PDCProjectApi.Model.Chart;
using PDCProjectApi.Model.Response;
using PDCProjectApi.Model.View;
using PDCProjectApi.Services;
using System.Collections;
using System.Collections.Concurrent;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.Net;
using System.Reflection;
using System.Security.Cryptography;
using System.Text;
using System.Text.RegularExpressions;

namespace PDCProjectApi.Common
{
    public static class ExtensionMethod
    {
        public static string ToSha256(this string value)
        {
            StringBuilder Sb = new StringBuilder();
            using (var hash = SHA256.Create())
            {
                Encoding enc = Encoding.UTF8;
                byte[] result = hash.ComputeHash(enc.GetBytes(value));
                foreach (byte b in result)
                {
                    Sb.Append(b.ToString("x2"));
                }
            }
            return Sb.ToString();
        }
        public static double FormatDouble(this double obj)
        {
            return Math.Round(obj, 2);
        }
        public static double FormatDouble4(this double obj)
        {
            return Math.Round(obj, 4);
        }
        public static string ToFormattedDateString(this string input)
        {
            if (!DateTime.TryParseExact(input, "yyyyMMdd", CultureInfo.InvariantCulture, DateTimeStyles.None, out DateTime date))
            {
                return input; // Hoặc bạn có thể ném ra một exception ở đây
            }

            return date.ToString("dd-MM-yyyy");
        }
        public static string ToFormattedDateString1(this string input)
        {
            if (!DateTime.TryParseExact(input, "yyyy-MM-dd", CultureInfo.InvariantCulture, DateTimeStyles.None, out DateTime date))
            {
                return input; // Hoặc bạn có thể ném ra một exception ở đây
            }

            return date.ToString("dd-MM-yyyy");
        }
        public static string ToFormattedDateString3(this string input)
        {
            string[] arr = input.Split('-');
            return $"{arr[2]}-{arr[1]}-{arr[0]}";
        }
        public static void ToFormattedDateString2(ref string palletDate, ref string fromTime, ref string toTime)
        {
            if (DateTime.TryParseExact(fromTime, "yyyy-MM-dd HH:mm", CultureInfo.InvariantCulture, DateTimeStyles.None, out DateTime fromTimeD)
                && DateTime.TryParseExact(toTime, "yyyy-MM-dd HH:mm", CultureInfo.InvariantCulture, DateTimeStyles.None, out DateTime toTimeD)
                && DateTime.TryParseExact(palletDate, "yyyy-MM-dd", CultureInfo.InvariantCulture, DateTimeStyles.None, out DateTime palletDateD))
            {
                palletDate = palletDateD.ToString("dd-MM-yyyy");
                if(fromTimeD.Hour < 8)
                {
                    fromTime = $"{palletDateD.AddDays(1).ToString("yyyy-MM-dd")} {fromTimeD.ToString("HH:mm:ss")} AD";
                    toTime = $"{palletDateD.AddDays(1).ToString("yyyy-MM-dd")} {toTimeD.ToString("HH:mm:ss")} AD";
                }
                else
                {
                    fromTime = $"{palletDateD.ToString("yyyy-MM-dd")} {fromTimeD.ToString("HH:mm:ss")} AD";
                    toTime = $"{palletDateD.ToString("yyyy-MM-dd")} {toTimeD.ToString("HH:mm:ss")} AD";
                }
            }
        }
        public static List<string> ReturnRestBlockTime(this string[]? break2)
        {
            var list = new List<string>();//11251215
            if (break2 == null || break2.Length < 1)
            {
                return list;
            }
            
            for (int j = 0; j < break2.Length; j++)
            {
                int startHour = Convert.ToInt32(break2[j].Substring(0, 2));
                int startMinute = Convert.ToInt32(break2[j].Substring(2, 2));
                int endHour = Convert.ToInt32(break2[j].Substring(4, 2));
                int endMinute = Convert.ToInt32(break2[j].Substring(6, 2));
                TimeOnly toStart = new TimeOnly(startHour, startMinute);
                TimeOnly toEnd = new TimeOnly(endHour, endMinute);
                if (toStart.Minute % 10 == 5)
                {
                    toStart = toStart.AddMinutes(5);
                }
                if (toEnd.Minute % 10 == 5)
                {
                    toEnd = toEnd.AddMinutes(-5);
                }
                for (TimeOnly ti = toStart; ti < toEnd; ti = ti.AddMinutes(10))
                {
                    list.Add(ti.ToString("HH:mm"));
                }
            }

            return list;
        }
        public static (TimeOnly, TimeOnly) ReturnOTBlockTime(this string otTime)//HHmmHHmm
        {
            if (otTime == null || otTime.Length != 8)
            {
                return (new TimeOnly(17, 10), new TimeOnly(19, 00));
            }

            TimeOnly time1 = TimeOnly.ParseExact(otTime.Substring(0, 4), "HHmm", null);
            TimeOnly time2 = TimeOnly.ParseExact(otTime.Substring(4, 4), "HHmm", null);
            return (time1, time2);
        }
        public static List<string> ReturnRestBlockTime2(this string[]? break2)
        {
            var list = new List<string>();//11251215
            if (break2 == null || break2.Length < 1)
            {
                return list;
            }

            for (int j = 0; j < break2.Length; j++)
            {
                int startHour = Convert.ToInt32(break2[j].Substring(0, 2));
                int startMinute = Convert.ToInt32(break2[j].Substring(2, 2));
                int endHour = Convert.ToInt32(break2[j].Substring(4, 2));
                int endMinute = Convert.ToInt32(break2[j].Substring(6, 2));
                TimeOnly toStart = new TimeOnly(startHour, startMinute);
                TimeOnly toEnd = new TimeOnly(endHour, endMinute);
                if (toStart.Minute % 10 == 5)
                {
                    toStart = toStart.AddMinutes(5);
                }
                if (toEnd.Minute % 10 == 5)
                {
                    toEnd = toEnd.AddMinutes(-5);
                }
                for (TimeOnly ti = toStart; ti < toEnd; ti = ti.AddMinutes(10))
                {
                    list.Add(ti.ToString("HHmm"));
                }
            }

            return list;
        }
        public static double DoubleAble(double[]? obj, int index)
        {
            if (obj == null || index < 0 || index >= obj.Length)
            {
                return 0;
            }

            try
            {
                if (obj.Any(x => x != 0))
                {
                    return obj[index];
                }
            }
            catch (Exception)
            {
                // Xử lý lỗi nếu cần
            }

            return 0;
        }
        public static string ReturnDetailException(this Exception e)
        {
            string txtContent = @$"<p>Message: {e.Message}</p><p>Data: {e.Data.Values.ToString()}</p>
<p>StackTrace: {e.StackTrace}</p>
<p>HelpLink: {e.HelpLink ?? ""}</p>
<p>Source: {e.Source ?? ""}</p>";
            if (e.Message.Contains("inner exception") && e.InnerException != null)
            {
                txtContent +=
            @$"<p></p><p></p><p></p><p>Inner Message: {e.InnerException?.Message.ToString()}</p>
                <p>Inner StackTrace: {e.InnerException?.StackTrace}</p>
                <p>Inner Source: {e.InnerException?.Source}</p>";
                if (e.InnerException?.Data.Count > 0)
                {
                    StringBuilder result = new StringBuilder();
                    foreach (DictionaryEntry entry in e.InnerException.Data)
                    {
                        result.Append($"<p>{entry.Key}: {entry.Value};</p>");
                    }
                    string finalString = result.ToString();
                    txtContent += finalString;
                }
            }
            return txtContent;
        }
        public static string ReturnDetailExceptionSimple(this Exception e)
        {
            string txtContent = @$"Message: {e.Message}\n
                StackTrace: {e.StackTrace}\n
                Source: {e.Source ?? ""}\n";
            if (e.InnerException != null)
            {
                txtContent +=
            @$"Inner Message: {e.InnerException?.Message.ToString()}\n
                Inner StackTrace: {e.InnerException?.StackTrace}\n
                Inner Source: {e.InnerException?.Source}\n";
                if (e.InnerException?.Data.Count > 0)
                {
                    StringBuilder result = new StringBuilder();
                    foreach (DictionaryEntry entry in e.InnerException.Data)
                    {
                        result.Append($"{entry.Key}: {entry.Value};\n");
                    }
                    string finalString = result.ToString();
                    txtContent += finalString;
                }
            }
            return txtContent;
        }
        public static double DoubleAbleList(double[]? obj, List<int> index)
        {
            try
            {
                double result = 0;
                if (obj == null) { return 0; }
                if (obj.Any(x => x != 0))
                {
                    foreach (var item in index)
                    {
                        result += obj[item];
                    }
                }
                return result;
            }
            catch (Exception)
            {
                return 0;
            }
        }
        public static double DevideForce(double d1, int? i2)
        {
            try
            {
                if(i2 == null || i2 == 0)
                {
                    return 0;
                }
                return d1 / i2.Value;
            }
            catch (Exception)
            {
                return 0;
            }
        }
        public static DateTime StringToDatetime(this string datetimeString)
        {
            DateTime parsedDate = DateTime.Now.AddDays(-10);
            DateTime.TryParseExact(datetimeString, "yyyyMMddHHmmss", CultureInfo.InvariantCulture, DateTimeStyles.None, out parsedDate);
            if(parsedDate.Minute % 10 != 0)
            {
                parsedDate = parsedDate.AddMinutes(-(parsedDate.Minute % 10));
            }
            return parsedDate;
        }
        public static TimeOnly StringToTimeOnly(this string timeString)
        {
            TimeOnly parsedTime = TimeOnly.MinValue;
            TimeOnly.TryParseExact(timeString, "HHmm", CultureInfo.InvariantCulture, DateTimeStyles.None, out parsedTime);
            if (parsedTime.Minute % 10 != 0)
            {
                parsedTime = parsedTime.AddMinutes(-1 * (parsedTime.Minute % 10));
            }
            return parsedTime;
        }
        public static double FormatDouble2(this double obj)
        {
            return Math.Round(obj, 2);
        }
        public static decimal FormatDecimal(this decimal obj)
        {
            return Math.Round(obj, 2);
        }
        public static DateTime? FromDateOnly(this DateOnly? date)
        {
            if (date == null)
            {
                return null;
            }
            return new DateTime(date.Value.Year, date.Value.Month, date.Value.Day);
        }
        public static DateTime FromDateOnly(this DateOnly date)
        {
            return new DateTime(date.Year, date.Month, date.Day);
        }
        public static DataTable ToDataTable<T>(this List<T> items)
        {
            DataTable dataTable = new DataTable(typeof(T).Name);
            PropertyInfo[] Props = typeof(T).GetProperties(BindingFlags.Public | BindingFlags.Instance);
            foreach (PropertyInfo prop in Props)
            {
                dataTable.Columns.Add(prop.Name);
            }
            foreach (T item in items)
            {
                var values = new object[Props.Length];
                for (int i = 0; i < Props.Length; i++)
                {
#pragma warning disable CS8601 // Possible null reference assignment.
                    values[i] = Props[i].GetValue(item, null);
                }
                dataTable.Rows.Add(values);
            }
            return dataTable;

        }
        public static List<T> ConvertDatatableToList<T>(DataTable dt)
        {
            List<T> data = new List<T>();
            foreach (DataRow row in dt.Rows)
            {
                T item = GetItem<T>(row);
                data.Add(item);
            }
            return data;
        }
        private static T GetItem<T>(DataRow dr)
        {
            Type temp = typeof(T);
            T obj = Activator.CreateInstance<T>();
            foreach (DataColumn column in dr.Table.Columns)
            {
                foreach (PropertyInfo pro in temp.GetProperties())
                {
                    if (pro.Name == column.ColumnName)
                    {
                        pro.SetValue(obj, dr[column.ColumnName], null);
                    }
                    else
                    {
                        continue;
                    }
                }
            }
            return obj;
        }
        public static DateTime SetKindUtc(this DateTime dateTime)
        {
            if (dateTime.Kind == DateTimeKind.Utc) { return dateTime.AddHours(-7); }
            return DateTime.SpecifyKind(dateTime.AddHours(-7), DateTimeKind.Utc);
        }
        public static DateTime UnsetKindUtc(this DateTime dateTime)
        {
            if (dateTime.Kind == DateTimeKind.Utc) { return dateTime.AddHours(7); }
            return DateTime.SpecifyKind(dateTime.AddHours(7), DateTimeKind.Utc);
        }
        public static DateTime SetStartTime(this DateTime dateTime)
        {
            return new DateTime(dateTime.Year, dateTime.Month, dateTime.Day, 0, 0, 0);
        }
        public static DateTime SetEndTime(this DateTime dateTime)
        {
            return new DateTime(dateTime.Year, dateTime.Month, dateTime.Day, 23, 59, 59);
        }
        public static string NewPassword()
        {
            const string chars = "0123456789qwertyuiopasdfghjklzxcvbnmQWERTYUIOPASDFGHJKLZXCVBNM";
            StringBuilder newpass = new StringBuilder();
            Random rnd = new Random();
            for (int i = 0; i < 8; i++)
            {
                int index = rnd.Next(chars.Length);
                newpass.Append(chars[index]);
            }
            return newpass.ToString();
        }
        public static string ReplaceSpecialChar(this string fileName)
        {
            Regex reg = new Regex("[*'\",_&#^@+=$%!`~;:/\\|><]");
            fileName = reg.Replace(fileName, string.Empty);
            return fileName;
        }
        public static string ReplaceSpecialChar(this string fileName, char c)
        {
            Regex reg = new Regex("[" + c + "]");
            fileName = reg.Replace(fileName, string.Empty);
            return fileName;
        }
        public static string ReplaceSpecialChar1(this string fileName)
        {
            Regex reg = new Regex("[\0]");
            fileName = reg.Replace(fileName, string.Empty);
            return fileName;
        }
        public static bool IsPasswordValid(this string password)
        {
            var hasNumber = new Regex(@"[0-9]+");
            var hasUpperChar = new Regex(@"[A-Z]+");
            var hasLowerChar = new Regex(@"[a-z]+");
            var hasSpecialSymbol = new Regex("[*'\",_&#^@+=$%!`~;:/\\|><]+");
            var hasMinimum8Chars = new Regex(@".{8,}");

            var isValidated = hasNumber.IsMatch(password) && hasUpperChar.IsMatch(password) && hasLowerChar.IsMatch(password) && hasSpecialSymbol.IsMatch(password) && hasMinimum8Chars.IsMatch(password);
            return isValidated;
        }
        public static string RemoveSpace(this string name)
        {
            return new string(name.ToCharArray()
                .Where(c => !Char.IsWhiteSpace(c))
                .ToArray());
        }
        public static int? StringToIntAble(this string? str)
        {
            try
            {
                if(string.IsNullOrEmpty(str) || string.IsNullOrWhiteSpace(str))
                {
                    return null;
                }
                return Convert.ToInt32(str);
            }
            catch (Exception)
            {
                return null;
            }
        }
        public static int StringToInt(this string? str)
        {
            int.TryParse(str, out var result);
            return result;
        }
        public static DateOnly? StringToDateAble(this string? str)
        {
            try
            {
                if (string.IsNullOrEmpty(str) || string.IsNullOrWhiteSpace(str))
                {
                    return null;
                }
                return DateOnly.Parse(str);
            }
            catch (Exception)
            {
                return null;
            }
        }
        public static TimeOnly StringToTimeAble(this string? str)
        {
            try
            {
                if (string.IsNullOrEmpty(str) || string.IsNullOrWhiteSpace(str))
                {
                    return new TimeOnly(0, 0);
                }
                if (TimeOnly.TryParse(str, out TimeOnly time))
                {
                    // Chuyển đổi thành công, sử dụng biến time
                    return time;
                }
                else
                {
                    // Chuyển đổi thất bại, xử lý lỗi
                    return new TimeOnly(0, 0);
                }
            }
            catch (Exception)
            {
                return new TimeOnly(0, 0);
            }
        }
        public static string ObjToStringAble(this object? obj)
        {
            try
            {
                if (obj == null)
                {
                    return "";
                }
                return obj.ToString().Trim();
            }
            catch (Exception)
            {
                return "";
            }
        }
        public static List<string> ObjToListStringAble(this object? obj)
        {
            try
            {
                if (obj == null)
                {
                    return new List<string>();
                }
                return obj.ToString().Split(',').ToList();
            }
            catch (Exception)
            {
                return new List<string>();
            }
        }
        public static int ObjToIntAble(this object? obj)
        {
            try
            {
                if (obj == null)
                {
                    return 0;
                }
                return Convert.ToInt32(obj);
            }
            catch (Exception)
            {
                return 0;
            }
        }
        public static string ZeroToBlank(this int obj)
        {
            try
            {
                if (obj == 0)
                {
                    return "";
                }
                return obj.ToString();
            }
            catch (Exception)
            {
                return "";
            }
        }
        public static double ObjToDoubleAble(this object? obj)
        {
            try
            {
                if (obj == null)
                {
                    return 0;
                }
                return Convert.ToDouble(obj.ToString().Trim());
            }
            catch (Exception)
            {
                return 0;
            }
        }
        public static string ObjToStringDatetimeAble(this object? obj)
        {
            try
            {
                if (obj == null)
                {
                    return "";
                }
                return Convert.ToDateTime(obj).ToString("yyyyMMddHHmmss");
            }
            catch (Exception)
            {
                try
                {
                    DateTime dateTimeValue = DateTime.FromOADate((double)obj);
                    return dateTimeValue.ToString("yyyyMMddHHmmss");
                }
                catch (Exception)
                {
                    try
                    {
                        string dateString = obj.ToString();
                        string format = "M/d/yyyy h:mm:ss tt";
                        CultureInfo provider = CultureInfo.InvariantCulture;
                        DateTime result = DateTime.ParseExact(dateString, format, provider);
                        return result.ToString("yyyyMMddHHmmss");
                    }
                    catch (Exception)
                    {
                        return obj.ObjToStringAble();
                    }
                    
                }
            }
        }
        public static DateTime? ObjToDatetimeAble(this object? obj)
        {
            try
            {
                if (obj == null)
                {
                    return null;
                }
                return DateTime.Parse(obj.ObjToStringAble());
            }
            catch (Exception)
            {
                try
                {
                    DateTime dateTimeValue = DateTime.FromOADate((double)obj);
                    return dateTimeValue;
                }
                catch (Exception)
                {
                    return null;
                }
            }
        }
        public static DateOnly? ObjToDateonlyAble(this object? obj)
        {
            try
            {
                if (obj == null)
                {
                    return null;
                }
                return DateOnly.FromDateTime(DateTime.Parse(obj.ObjToStringAble()));
            }
            catch (Exception)
            {
                try
                {
                    DateTime dateTimeValue = DateTime.FromOADate((double)obj);
                    return DateOnly.FromDateTime(dateTimeValue);
                }
                catch (Exception)
                {
                    return null;
                }
            }
        }
        public static DateOnly ObjToDateonly(this object? obj)
        {
            try
            {
                return DateOnly.FromDateTime(Convert.ToDateTime(obj));
            }
            catch (Exception)
            {
                try
                {
                    DateTime dateTimeValue = DateTime.FromOADate((double)obj);
                    return DateOnly.FromDateTime(dateTimeValue);
                }
                catch (Exception)
                {
                    return DateOnly.FromDateTime(DateTime.Today);
                }
            }
        }
        public static DateTime? ObjToStartDatetimeAble(this object? obj)
        {
            try
            {
                if (obj == null)
                {
                    return null;
                }
                return Convert.ToDateTime(obj).Date;
            }
            catch (Exception)
            {
                try
                {
                    DateTime dateTimeValue = DateTime.FromOADate((double)obj).Date;
                    return dateTimeValue;
                }
                catch (Exception)
                {
                    try
                    {
                        string dateString = obj.ToString();
                        string format = "M/d/yyyy h:mm:ss tt";
                        CultureInfo provider = CultureInfo.InvariantCulture;
                        DateTime result = DateTime.ParseExact(dateString, format, provider);
                        return result.Date;
                    }
                    catch (Exception)
                    {
                        return null;
                    }
                }
            }
        }

        public static Dictionary<string, List<string>> ListToDicGroupBySubstringNumber(this List<string> lst1)
        {
            // Tạo một Dictionary để lưu trữ các nhóm
            Dictionary<string, List<string>> groups = new Dictionary<string, List<string>>();

            // Sử dụng Regex để tìm các substring là số
            Regex regex = new Regex(@"\d+");

            foreach (string str in lst1)
            {
                // Tìm các substring là số trong chuỗi
                MatchCollection matches = regex.Matches(str);

                if (matches.Count > 0)
                {
                    string number = matches[0].Value; // Lấy giá trị số từ substring

                    // Kiểm tra xem nhóm đã tồn tại hay chưa
                    if (!groups.ContainsKey(number))
                    {
                        groups[number] = new List<string>();
                    }

                    // Thêm chuỗi vào nhóm tương ứng
                    groups[number].Add(str);
                }
            }

            //// In kết quả
            //foreach (KeyValuePair<string, List<string>> group in groups)
            //{
            //    Console.WriteLine("Nhóm {0}:", group.Key);
            //    foreach (string str in group.Value)
            //    {
            //        Console.WriteLine(str);
            //    }
            //    Console.WriteLine();
            //}
            return groups;
        }
        public static TodTodOutput1TotalIj SumToTotal_M_1(this List<TodTodOutput1SummaryIj> lstSum, int gap)
        {
            var item1 = lstSum.First();
            var valResult = item1.TodValue;
            var pairs = item1.Pair ?? "";
            string deadl = "";
            try
            {
                var valArr = lstSum.Select(x => x.TodValue).ToList();
                valResult = valArr.Aggregate((arr1, arr2) => arr1.Zip(arr2, (x, y) => x + y).ToArray());
                pairs = string.Join(',', lstSum.Select(x => x.Pair).Distinct().ToList());
                if (item1.CalcOrder == 6 || item1.CalcOrder == 7 || item1.CalcOrder == 9)
                {
                    deadl = item1.TodDate[Array.FindIndex(valResult, 0, x => x < 0)].ToString("yyyyMMdd");
                    if(item1.CalcOrder == 6 || item1.CalcOrder == 9)
                    {
                        var highlightDeadline = lstSum.Any(x => x.CalcOrder == item1.CalcOrder && x.Deadline != null && x.Deadline.Length > 8);
                        if (highlightDeadline)
                        {
                            deadl = deadl + "(r)";
                        }
                    }
                }
            }
            catch (Exception)
            {

            }
            return new TodTodOutput1TotalIj()
            {
                Active = true,
                Pair = pairs,
                Adjustment = item1.Adjustment,
                Alternative = lstSum.Select(y => y.PartNo ?? "").ToArray(),
                PartNo = item1.PartNo,
                Bc = lstSum.Select(y => y.Bc ?? "").ToArray(),
                CalcOrder = item1.CalcOrder,
                CalcType = item1.CalcType,
                CreatedBy = "System",
                Des = item1.Des,
                Id = Guid.NewGuid(),
                Inventory = lstSum.Sum(y => y.Inventory ?? 0),
                Location = item1.Location,
                Model = item1.Model,
                Moq = item1.Moq,
                OrderMethod = item1.OrderMethod,
                PartName = item1.PartName,
                PcsPallet = item1.PcsPallet,
                Vendor = lstSum.Select(y => y.Vendor ?? "").ToArray(),
                TodDate = item1.TodDate,
                TodValue = valResult,
                Gap = gap,
                Deadline = deadl
            };
        }
        public static TodTodOutput1TotalIj SumToTotal_M_1_Special67(this List<TodTodOutput1SummaryIj> lstSum, int gap, List<double[]> val13)
        {
            var item1 = lstSum.First();
            var lastInvent = item1.Inventory ?? 0;
            var valArr = lstSum.Select(x => x.TodValue).ToList();
            var valResult = valArr.Aggregate((arr1, arr2) => arr1.Zip(arr2, (x, y) => x + y).ToArray());
            var valArr2 = val13.Aggregate((arr1, arr2) => arr1.Zip(arr2, (x, y) => x + y).ToArray());
            var valResult2 = valResult.Zip(valArr2, (a, b) => {
                var result = a + b - lastInvent; // Trừ lastInvent từ a + b
                lastInvent = a + b; // Cập nhật lastInvent
                return result;
            }).ToArray();
            var pairs = string.Join(',', lstSum.Select(x => x.Pair).Distinct().ToList());
            string deadl = item1.Deadline ?? "";
            try
            {
                deadl = item1.TodDate[Array.FindIndex(valResult2, 0, x => x < 0)].ToString("yyyyMMdd");
            }
            catch (Exception)
            {

            }
            return new TodTodOutput1TotalIj()
            {
                Active = true,
                Pair = pairs,
                Adjustment = item1.Adjustment,
                Alternative = lstSum.Select(y => y.PartNo ?? "").ToArray(),
                PartNo = item1.PartNo,
                Bc = lstSum.Select(y => y.Bc ?? "").ToArray(),
                CalcOrder = item1.CalcOrder,
                CalcType = item1.CalcType,
                CreatedBy = "System",
                Des = item1.Des,
                Id = Guid.NewGuid(),
                Inventory = item1.Inventory ?? 0,
                Location = item1.Location,
                Model = item1.Model,
                Moq = item1.Moq,
                OrderMethod = item1.OrderMethod,
                PartName = item1.PartName,
                PcsPallet = item1.PcsPallet,
                Vendor = lstSum.Select(y => y.Vendor ?? "").ToArray(),
                TodDate = item1.TodDate,
                TodValue = valResult2,
                Gap = gap,
                Deadline = deadl
            };
        }
        public static TodTodOutput1TotalIj SumToTotal_1_1(this TodTodOutput1SummaryIj sum, int gap)
        {
            return new TodTodOutput1TotalIj()
            {
                Active = true,
                Pair = sum.Pair,
                Adjustment = sum.Adjustment,
                Alternative = new string[] {},
                PartNo = sum.PartNo,
                Bc = new string[] {sum.Bc},
                CalcOrder = sum.CalcOrder,
                CalcType = sum.CalcType,
                CreatedBy = "System",
                Des = sum.Des,
                Id = Guid.NewGuid(),
                Inventory = sum.Inventory,
                Location = sum.Location,
                Model = sum.Model,
                Moq = sum.Moq,
                OrderMethod = sum.OrderMethod,
                PartName = sum.PartName,
                PcsPallet = sum.PcsPallet,
                Vendor = new string[] { sum.Vendor },
                TodDate = sum.TodDate,
                TodValue = sum.TodValue,
                Gap = gap,
                Deadline = sum.Deadline
            };
        }
        public static TodTodOutput1TotalIj SumNullToTotal_N_1(this TodTodOutput1SummaryIj sum, int gap)
        {
            return new TodTodOutput1TotalIj()
            {
                Active = true,
                Pair = sum.Pair,
                Adjustment = sum.Adjustment,
                Alternative = new string[] { },
                PartNo = sum.PartNo,
                Bc = new string[] { sum.Bc },
                CalcOrder = sum.CalcOrder,
                CalcType = sum.CalcType,
                CreatedBy = "System",
                Des = sum.Des,
                Id = Guid.NewGuid(),
                Inventory = sum.Inventory,
                Location = sum.Location,
                Model = sum.Model,
                Moq = sum.Moq,
                OrderMethod = sum.OrderMethod,
                PartName = sum.PartName,
                PcsPallet = sum.PcsPallet,
                Vendor = new string[] { sum.Vendor },
                TodDate = sum.TodDate,
                TodValue = sum.TodValue,
                Gap = gap,
                Deadline = sum.Deadline
            };
        }
        public static TodTodOutput1TotalLbp SumNullToTotal_N_1(this TodTodOutput1SummaryLbp sum, int gap)
        {
            return new TodTodOutput1TotalLbp()
            {
                Active = true,
                Pair = sum.Pair,
                Adjustment = sum.Adjustment,
                Alternative = new string[] { },
                PartNo = sum.PartNo,
                Bc = new string[] { sum.Bc },
                CalcOrder = sum.CalcOrder,
                CalcType = sum.CalcType,
                CreatedBy = "System",
                Des = sum.Des,
                Id = Guid.NewGuid(),
                Inventory = sum.Inventory,
                Location = sum.Location,
                Model = sum.Model,
                Moq = sum.Moq,
                OrderMethod = sum.OrderMethod,
                PartName = sum.PartName,
                PcsPallet = sum.PcsPallet,
                Vendor = new string[] { sum.Vendor },
                TodDate = sum.TodDate,
                TodValue = sum.TodValue,
                Gap = gap,
                Deadline = sum.Deadline
            };
        }
        public static string StringAbleToString(this string? obj)
        {
            try
            {
                if (obj == null)
                {
                    return "";
                }
                return obj.ToString().Trim();
            }
            catch (Exception)
            {
                return "";
            }
        }
        public static double StringAbleToDouble(this string? obj)
        {
            try
            {
                if (obj == null)
                {
                    return 0;
                }
                return Convert.ToDouble(obj);
            }
            catch (Exception)
            {
                return 0;
            }
        }
        public static double MathRound2(this double? obj)
        {
            try
            {
                if (obj == null)
                {
                    return 0;
                }
                return Math.Round((double)obj,2);
            }
            catch (Exception)
            {
                return 0;
            }
        }
        public static T ToObject<T>(this Object fromObject)
        {
            return JsonConvert.DeserializeObject<T>(JsonConvert.SerializeObject(fromObject));
        }
        public static string[]? RemoveAt(this string[]? arr1, int index)
        {
            string[]? result = arr1;
            try
            {
                if (index >= 0 && index < arr1.Length)
                {
                    string[] newArray = new string[arr1.Length - 1];

                    Array.Copy(arr1, 0, newArray, 0, index);
                    Array.Copy(arr1, index + 1, newArray, index, arr1.Length - index - 1);

                    result = newArray;
                }
                else
                {
                    
                }
            }
            catch (Exception)
            {

            }
            return result;
        }
        public static string[]? RemoveAtMulti(this string[]? myArray, int[] indexesToRemove)
        {
            try
            {
                // Sắp xếp các chỉ số giảm dần để tránh ảnh hưởng đến các chỉ số còn lại sau khi xóa
                indexesToRemove = indexesToRemove.OrderByDescending(i => i).ToArray();

                foreach (int index in indexesToRemove)
                {
                    if (index >= 0 && index < myArray.Length)
                    {
                        myArray = myArray.Where((value, i) => i != index).ToArray();
                    }
                    else
                    {
                        
                    }
                }
            }
            catch (Exception)
            {

            }
            return myArray;
        }
        public static List<T> ToObjectList<T>(this Object fromObject)
        {
            return JsonConvert.DeserializeObject<List<T>>(JsonConvert.SerializeObject(fromObject));
        }
        public static int Compare(string x, string y)
        {
            // Chuyển đổi chuỗi thành DateTime để so sánh
            DateTime timeX = DateTime.ParseExact(x, "HH:mm", null);
            DateTime timeY = DateTime.ParseExact(y, "HH:mm", null);

            // So sánh theo thứ tự tăng dần
            return timeX.CompareTo(timeY);
        }
        public static List<DailyLivePPTimelyByModel> SortStartShiftTime(this List<DailyLivePPTimelyByModel> result)
        {
            result.Sort((x, y) => Compare(x.FromTime, y.FromTime));
            List<DailyLivePPTimelyByModel> tempObjects = new List<DailyLivePPTimelyByModel>();
            foreach (var obj in result)
            {
                var hour = Convert.ToInt32(obj.FromTime.Substring(0, 2));
                if (hour < 8)
                {
                    tempObjects.Add(obj);
                }
                else
                {
                    break;
                }
            }
            // Xóa các phần tử đã di chuyển vào danh sách tạm thời khỏi danh sách gốc
            foreach (DailyLivePPTimelyByModel obj in tempObjects)
            {
                result.Remove(obj);
            }
            // Thêm các phần tử trong danh sách tạm thời vào cuối danh sách gốc
            result.AddRange(tempObjects);
            return result;
        }
        public static TimeOnly TimeOnlyFromString(this string eta)
        {
            int.TryParse(eta, out int i);
            string timeAsString = i.ToString("0000");
            TimeOnly time = TimeOnly.ParseExact(timeAsString, "HHmm", null);
            if(time.Minute % 10 == 5)
            {
                time = time.AddMinutes(-5);
            }
            return time;
        }
        public static void ThrowIfCancellationRequested(this CancellationToken token, string message = "Operation was cancelled")
        {
            try
            {
                if (token.IsCancellationRequested)
                {
                    token.ThrowIfCancellationRequested();
                    //Console.WriteLine($"Now: {DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")} </br> Memory: {GC.GetTotalMemory(false)}</br> Message:{message}");
                }
                return;
            }
            catch (OperationCanceledException ce)
            {
                //Console.WriteLine($"Now: {DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")} </br> Memory: {GC.GetTotalMemory(false)}</br> Message:{message} </br>Exception:{ce.Message}");
                return;
            }
            catch (Exception)
            {
                return;
            }
        }
        public static void ThrowIfCancellationRequested(this CancellationToken token, Action onCancellation)
        {
            try
            {
                if (token.IsCancellationRequested)
                {
                    onCancellation?.Invoke();
                    token.ThrowIfCancellationRequested();
                }
                return;
            }
            catch (OperationCanceledException)
            {
                //Console.WriteLine($"Now: {DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")} </br> Memory: {GC.GetTotalMemory(false)}</br> Message:{message} </br>Exception:{ce.Message}");
                return;
            }
            catch (Exception)
            {
                return;
            }
        }
        public static List<FcDoSubCustomObject> MatchShifts(this List<VSimulationIp3TimeTableDelivery> originalList)
        {
            List<FcDoSubCustomObject> customList = new List<FcDoSubCustomObject>();
            try
            {
                var shiftDList = originalList.Where(x => x.Shift == "D").OrderBy(x => x.RowNum).ToList();
                var shiftNList = originalList.Where(x => x.Shift == "N").OrderBy(x => x.RowNum).ToList();
                var shiftDListAfter13h = originalList.Where(x => x.Shift == "D" && int.Parse(x.Eta) > 1300).OrderBy(x => x.RowNum).ToList();

                foreach (var shiftN in shiftNList)
                {
                    try
                    {
                        var matchingShiftD = shiftDList.FirstOrDefault(x => x.RowNum == shiftN.RowNum);

                        if (matchingShiftD == null)
                        {
                            matchingShiftD = shiftDList.LastOrDefault();
                        }
                        else if (int.Parse(matchingShiftD.Eta) > 1300)
                        {
                            matchingShiftD = shiftDList.LastOrDefault(x => int.Parse(x.Eta) <= 1300);
                        }
                        customList.Add(new FcDoSubCustomObject
                        {
                            ShiftN = shiftN.Shift,
                            EtaN = shiftN.Eta,
                            RowNumN = shiftN.RowNum.ObjToIntAble(),
                            ShiftD = matchingShiftD?.Shift,
                            EtaD = matchingShiftD?.Eta,
                            RowNumD = (matchingShiftD?.RowNum ?? -1).ObjToIntAble() // Use -1 if no matching Shift D is found
                        });
                    }
                    catch (Exception)
                    {
                        continue;
                    }
                    
                }
                foreach (var shiftD in shiftDListAfter13h)
                {
                    try
                    {
                        if (int.Parse(shiftD.Eta) > 1300)
                        {
                            var md = shiftDList.LastOrDefault(x => int.Parse(x.Eta) <= 1300);
                            if(md != null)
                            {
                                customList.Add(new FcDoSubCustomObject
                                {
                                    ShiftN = shiftD.Shift,
                                    EtaN = shiftD.Eta,
                                    RowNumN = shiftD.RowNum.ObjToIntAble(),
                                    ShiftD = "D",
                                    EtaD = md.Eta,
                                    RowNumD = md.RowNum.ObjToIntAble() // Use -1 if no matching Shift D is found
                                });
                            }
                        }
                        
                    }
                    catch (Exception)
                    {
                        continue;
                    }

                }

            }
            catch (Exception)
            {

            }
            return customList;
        }
        public static List<FcDoSubCustomObject> MatchShifts1(this List<VSimulationIp3TimeTableDeliveryExceptIp6> originalList)
        {
            List<FcDoSubCustomObject> customList = new List<FcDoSubCustomObject>();
            try
            {
                var shiftDList = originalList.Where(x => x.Shift == "D").OrderBy(x => x.RowNum).ToList();
                var shiftNList = originalList.Where(x => x.Shift == "N").OrderBy(x => x.RowNum).ToList();
                var shiftDListAfter13h = originalList.Where(x => x.Shift == "D" && int.Parse(x.Eta) > 1300).OrderBy(x => x.RowNum).ToList();

                foreach (var shiftN in shiftNList)
                {
                    try
                    {
                        var matchingShiftD = shiftDList.FirstOrDefault();

                        if (matchingShiftD == null)
                        {
                            matchingShiftD = shiftDList.LastOrDefault();
                        }
                        else if (int.Parse(matchingShiftD.Eta) > 1300)
                        {
                            matchingShiftD = shiftDList.LastOrDefault(x => int.Parse(x.Eta) <= 1300);
                        }
                        customList.Add(new FcDoSubCustomObject
                        {
                            ShiftN = shiftN.Shift,
                            EtaN = shiftN.Eta,
                            RowNumN = shiftN.RowNum.ObjToIntAble(),
                            ShiftD = matchingShiftD?.Shift,
                            EtaD = matchingShiftD?.Eta,
                            RowNumD = (matchingShiftD?.RowNum ?? -1).ObjToIntAble() // Use -1 if no matching Shift D is found
                        });
                    }
                    catch (Exception)
                    {
                        continue;
                    }

                }
                foreach (var shiftD in shiftDListAfter13h)
                {
                    try
                    {
                        if (int.Parse(shiftD.Eta) > 1300)
                        {
                            var md = shiftDList.LastOrDefault(x => int.Parse(x.Eta) <= 1300);
                            if (md != null)
                            {
                                customList.Add(new FcDoSubCustomObject
                                {
                                    ShiftN = shiftD.Shift,
                                    EtaN = shiftD.Eta,
                                    RowNumN = shiftD.RowNum.ObjToIntAble(),
                                    ShiftD = "D",
                                    EtaD = md.Eta,
                                    RowNumD = md.RowNum.ObjToIntAble() // Use -1 if no matching Shift D is found
                                });
                            }
                        }

                    }
                    catch (Exception)
                    {
                        continue;
                    }

                }

            }
            catch (Exception)
            {

            }
            return customList;
        }
        public static List<FcDoSubCustomObject> MatchShifts2(this List<VSimulationIp3TimeTableDeliveryByIp6> originalList)
        {
            List<FcDoSubCustomObject> customList = new List<FcDoSubCustomObject>();
            try
            {
                var shiftDList = originalList.Where(x => x.Shift == "D").OrderBy(x => x.RowNum).ToList();
                var shiftNList = originalList.Where(x => x.Shift == "N").OrderBy(x => x.RowNum).ToList();
                var shiftDListAfter13h = originalList.Where(x => x.Shift == "D" && int.Parse(x.Eta) > 1300).OrderBy(x => x.RowNum).ToList();

                foreach (var shiftN in shiftNList)
                {
                    try
                    {
                        var matchingShiftD = shiftDList.FirstOrDefault();

                        if (matchingShiftD == null)
                        {
                            matchingShiftD = shiftDList.LastOrDefault();
                        }
                        else if (int.Parse(matchingShiftD.Eta) > 1300)
                        {
                            matchingShiftD = shiftDList.LastOrDefault(x => int.Parse(x.Eta) <= 1300);
                        }
                        customList.Add(new FcDoSubCustomObject
                        {
                            ShiftN = shiftN.Shift,
                            EtaN = shiftN.Eta,
                            RowNumN = shiftN.RowNum.ObjToIntAble(),
                            ShiftD = matchingShiftD?.Shift,
                            EtaD = matchingShiftD?.Eta,
                            RowNumD = (matchingShiftD?.RowNum ?? -1).ObjToIntAble() // Use -1 if no matching Shift D is found
                        });
                    }
                    catch (Exception)
                    {
                        continue;
                    }

                }
                foreach (var shiftD in shiftDListAfter13h)
                {
                    try
                    {
                        if (int.Parse(shiftD.Eta) > 1300)
                        {
                            var md = shiftDList.LastOrDefault(x => int.Parse(x.Eta) <= 1300);
                            if (md != null)
                            {
                                customList.Add(new FcDoSubCustomObject
                                {
                                    ShiftN = shiftD.Shift,
                                    EtaN = shiftD.Eta,
                                    RowNumN = shiftD.RowNum.ObjToIntAble(),
                                    ShiftD = "D",
                                    EtaD = md.Eta,
                                    RowNumD = md.RowNum.ObjToIntAble() // Use -1 if no matching Shift D is found
                                });
                            }
                        }

                    }
                    catch (Exception)
                    {
                        continue;
                    }

                }

            }
            catch (Exception)
            {

            }
            return customList;
        }
        public static List<int> FindPositions(List<DateTime> arrA, List<TimeOnly> arrB, int ignore)
        {
            List<int> positions = new List<int>();

            foreach (var time in arrB)
            {
                var pos = arrA.FindIndex(ignore, dt => new TimeOnly(dt.Hour, dt.Minute) == time);
                positions.Add(pos);
            }

            return positions;
        }

        public static List<int> FindPositionsWithCondition(List<DateTime> arrA, List<TimeOnly> arrB, List<TimeOnly> arrC, int ignore)
        {
            List<int> positions = new List<int>();

            for (int i = 0; i < arrB.Count; i++)
            {
                var timeB = arrB[i];
                var timeC = arrC[i];
                var posB = arrA.FindIndex(ignore, dt => new TimeOnly(dt.Hour, dt.Minute) == timeB);
                if (posB == -1)
                {
                    positions.Add(-1);
                    continue;
                }

                var posC = arrA.FindIndex(ignore, dt => new TimeOnly(dt.Hour, dt.Minute) < timeC && new TimeOnly(dt.Hour, dt.Minute) > timeB);
                positions.Add(posC);
            }

            return positions;
        }

        public static string ReplaceDotCommaAtEnd(this string original)
        {
            if (original.EndsWith(";"))
            {
                return original.Substring(0, original.Length - 1);
            }
            return original;
        }
        

        #region Các extendsion method dùng cho digital simulation
        public static void DSim_Lt_CalcOp4Leadtime(this int[] arrActive, int lengthHasPlan, int LeadtimeBlock, double ratio, double QtyKeepCell, double[] PpValue,
            ref double[] leadTime, ref double[] qtyKeepCell)
        {
            for (int i = 0; i < arrActive.Length; i++)
            {
                qtyKeepCell[arrActive[i]] = QtyKeepCell * ratio / 100;// * cellQty[arrActive[i]] fix = 1;
                double sum = 0;
                for (int j = i + 1; j < i + LeadtimeBlock + 1; j++)
                {
                    if (j >= arrActive.Length || arrActive[j] >= lengthHasPlan)
                    {
                        break;
                    }
                    sum += PpValue[arrActive[j]];
                }
                if (sum > 0 || PpValue[arrActive[i]] > 0)
                {
                    leadTime[arrActive[i]] = sum;

                }

                //totalLeadtime[arrActive[i]] += sum + qtyKeepCell[arrActive[i]];
            }
        }
        public static void DSim_Lt_CalcOp4Leadtime2(this int[] arrActive, double[] PpValue, int slice,
            ref double[] qtyKeepCell)
        {
            for (int i = arrActive.Length - 1; i > 0; i--)
            {
                if (PpValue[arrActive[i]] == 0 && PpValue[arrActive[i - 1]] > 0)
                {
                    int startBackSlice = Math.Max(i - slice, 0);
                    //Console.WriteLine($"Pos {i} slice {slice}");
                    for (int j = startBackSlice; j <= i - 1; j++)
                    {
                        //if (j < 0)
                        //{
                        //    break;
                        //}
                        //Console.Write($"Cacl {j}");
                        qtyKeepCell[arrActive[j]] = 0;
                    }
                }
            }
        }
        public static void DSim_Lt_CalcOp4Leadtime3(this int[] arrActive, double[] PpValue, int slice, double[] leadTime,
            ref double[] qtyKeepCell, ref double[] totalLeadtime)
        {
            for (int i = 0; i < arrActive.Length; i++)
            {
                if (/*leadTime[arrActive[i]] == 0 && */PpValue[arrActive[i]] == 0)
                {
                    qtyKeepCell[arrActive[i]] = 0;
                }
                totalLeadtime[arrActive[i]] = leadTime[arrActive[i]] + qtyKeepCell[arrActive[i]];
            }
        }
        public static void DSim_Lt_CalcOp4Leadtime4(this int[] arrInactive, ref double[] totalLeadtime)
        {
            for (int i = 0; i < arrInactive.Length; i++)
            {
                totalLeadtime[arrInactive[i]] = totalLeadtime[arrInactive[i] - 1];
            }
        }
        public static double DSim_RemainIncl_RoundNegative1Decimal(this double number)
        {
            // Lấy phần nguyên và phần thập phân
            var checkNegative = number < 0 ? true : false;
            number = Math.Abs(number);
            int integralPart = (int)Math.Truncate(number);
            decimal fractionalPart = (decimal)number - (decimal)integralPart;

            // Kiểm tra điều kiện và làm tròn
            if (fractionalPart < 0.1m)
            {
                // Làm tròn xuống: giữ nguyên giá trị tuyệt đối phần nguyên
                return integralPart * (checkNegative ? -1: 1);
            }
            else
            {
                // Làm tròn lên: Tăng giá trị tuyệt đối của phần nguyên lên 1 đơn vị
                //Nếu là số âm thì *(-1) để trả về đúng giá trị âm
                return (integralPart + 1) * (checkNegative ? -1: 1);
            }
        }
        public static double DSim_CeilingOfAbs(this double mincheck, double futureRatio, double moq)
        {
            var result = Math.Ceiling(Math.Abs((decimal)mincheck * (decimal)futureRatio / 100) / (decimal)moq) * (decimal)moq;
            return (double)result;
        }
        public static double DSim_CeilingOfAbsIncludeTotal(this double mincheck, double futureRatio, double moq, double totalValue)
        {
            var result = Math.Ceiling(Math.Abs((decimal)mincheck * (decimal)futureRatio / 100 + (decimal)totalValue) / (decimal)moq) * (decimal)moq;
            return (double)result;
        }
        public static bool IsBetween(this int a, int b, int c)
        {
            return a >= b && a <= c;
        }
        public static void DSim_Sum2DoubleArray(this double[] fcDo, ref double[] sumFcDo)
        {
            for(int i = 0; i < fcDo.Length; i++)
            {
                sumFcDo[i] += fcDo[i];
            }
        }
        public static void DSim_ParseStringOrderRatio(this string strOrderRatio, out int indexStart, out int indexEnd, out double ratio)
        {
            int.TryParse(strOrderRatio.Split('_')[0], out indexStart);
            int.TryParse(strOrderRatio.Split('_')[1], out indexEnd);
            double.TryParse(strOrderRatio.Split('_')[2], out ratio);
        }
        public static void DSim_ReturnRatioGapSpecial(this string? mainAlt, ref double ratio)
        {
            if (mainAlt != null && mainAlt.Contains("S"))
            {
                ratio = 100;
            }
        }
        public static void DSim_SumRangeOfArray(this double[] arrayOriginal, int startIndex, int endIndex, out double sumResult)
        {
            sumResult = arrayOriginal[startIndex..(endIndex + 1)].Sum();
        }
        public static void DSim_AdjustRatioBySumDemandNDoQty(this double sumDemand, double doQty, out double adjustRatio)
        {
            adjustRatio = 0;
            if(sumDemand != 0)
            {
                adjustRatio = ((double)doQty / sumDemand) * 100;
            }
        }
        public static void DSim_FillDoubleArray(this double adjustRatio, ref double[] arrayRatio, int startIdx, int endIdx)
        {
            Array.Fill(arrayRatio, adjustRatio, startIdx, endIdx - startIdx + 1);
        }
        public static void DSim_InitialDoubleArray(this double value, int length, out double[] result)
        {
            result = new double[length];
            Array.Fill(result, value);
        }
        public static void DSim_ResetDoubleArray(this int length, ref double[] result)
        {
            result = new double[length];
        }
        public static void DSim_ReturnFutureRatio(this ConcurrentBag<string>? orderRatio, double[] demand, ref double[] futureRatio, ref ConcurrentBag<string> bagStringUpdateRatioToIP4, string bcPartnoVendor)
        {
            if (orderRatio != null && orderRatio.Count > 0)
            {
                foreach (var posRatio in orderRatio)
                {
                    try
                    {
                        posRatio.DSim_ParseStringOrderRatio(out int startIdx, out int endIdx, out double doQty);
                        demand.DSim_SumRangeOfArray(startIdx, endIdx, out double sumDemand);
                        //Console.WriteLine($"Da vao day ! {posRatio} sum demand = {sumDemand} doQty = {doQty}");
                        sumDemand.DSim_AdjustRatioBySumDemandNDoQty(doQty, out double adjRatio);
                        bagStringUpdateRatioToIP4.Add($"{adjRatio}_{startIdx}_{endIdx}_{bcPartnoVendor}");
                        adjRatio.DSim_FillDoubleArray(ref futureRatio, startIdx, endIdx);
                    }
                    catch (Exception)
                    {
                        continue;
                    }

                }
            }
        }
        public static void DSim_CalculateFCDO_NormalStep(this double[] remainIncl, int[] Item1, 
            double[] arrRatio, ref string consoleResult, 
            double moqD, bool debugMode, ref double currentValue, 
            ref double totalValue, ref double[] fcDo, bool isSpecialPart, double[] demand, double[] leadtime, double dPcsbox)
        {
            for (int k = 0; k < Item1.Length - 1; k++)
            {
                var mincheck = remainIncl[Item1[k]..(Item1[k + 1] + 1)].Min().DSim_RemainIncl_RoundNegative1Decimal();
                if (debugMode) consoleResult += $"Min {Item1[k]} to {Item1[k + 1]} = {mincheck}\n";
                if (mincheck < -0.1)
                {
                    currentValue = Math.Ceiling(Math.Abs(mincheck * arrRatio[Item1[k]] / 100) / moqD) * moqD;
                    var notNegative = Math.Max(0, currentValue - totalValue);
                    fcDo[Item1[k]] += notNegative;
                    totalValue += notNegative;
                    if (debugMode) consoleResult += $"FCDO[{Item1[k]}] at k = {k}, \t== {fcDo[Item1[k]]}\t ratio[{Item1[k]}]={arrRatio[Item1[k]]}\n";

                    //if (isSpecialPart)
                    //{
                    //    //////if (debugMode) consoleResult += $"Special part\n";
                    //    int kti = Item1[k];
                    //    if (demand[kti] > 0 && demand[kti + 1] == 0 && leadtime[kti] == 0)
                    //    {
                    //        //tìm vị trí gần nhất trước đó
                    //        var idxNearest = fcDo[0..(kti - 1)].Select((value, index) => new { value, index }).Where(kii => kii.value != 0).LastOrDefault();
                    //        if (debugMode) consoleResult += $"Special KTTT at {kti} idxNearest = {idxNearest}\n";
                    //        if (idxNearest != null)
                    //        {
                    //            fcDo[idxNearest.index] = remainIncl[kti] < 0 ? Math.Ceiling(((Math.Abs(remainIncl[kti].DSim_RemainIncl_RoundNegative1Decimal()) * arrRatio[kti] / 100) - fcDo[0..(idxNearest.index - 1)].Sum()) / dPcsbox) * dPcsbox : 0;
                    //            if (debugMode) consoleResult += $"RemainIncl[{kti}] = {remainIncl[kti]}, ratio[{arrRatio[kti]}] = {arrRatio[kti]}, pcsBox = {dPcsbox}, idxNearest = {idxNearest.index}, fcDo[{idxNearest.index}] = {fcDo[idxNearest.index]}, sum fcDo[0..{idxNearest.index - 1}] = {fcDo[0..(idxNearest.index - 1)].Sum()}\n";
                    //        }
                    //    }
                    //}
                }
            }
        }
        public static string DSim_ReturnRangtimeBasedOnPalletDateAndTime(this int index, DateOnly dt, TimeOnly to)
        {
            if(to.Hour < 8)
            {
                var dt1 = dt.AddDays(1);
                var timeFrom = new DateTime(dt1.Year, dt1.Month, dt1.Day, to.Hour, to.Minute, to.Second);
                var timeTo = timeFrom.AddMinutes(10);
                return $"{timeFrom.ToString("yyyy-MM-dd HH:mm")}_{timeTo.ToString("yyyy-MM-dd HH:mm")}";
            }
            else
            {
                var dt1 = dt;
                var timeFrom = new DateTime(dt1.Year, dt1.Month, dt1.Day, to.Hour, to.Minute, to.Second);
                var timeTo = timeFrom.AddMinutes(10);
                return $"{timeFrom.ToString("yyyy-MM-dd HH:mm")}_{timeTo.ToString("yyyy-MM-dd HH:mm")}";
            }
        }
        public static void DSim_CalculateFCDO_PartSub(this bool debugMode, List<int> lstIndexNight, List<int> lstIndexDay, int Item3, 
            ref string consoleResult, ref double[] fcDo)
        {
            if (lstIndexNight.Count == lstIndexDay.Count)
            {
                if (debugMode) consoleResult += "\n\nStep part SUB\n";
                for (int k = 0; k <= Item3; k++)
                {
                    fcDo[k] = 0;
                    if (debugMode) consoleResult += ($"fcDo[{k}] = 0 \n");
                }
                for (int nd = 0; nd < lstIndexNight.Count; nd++)
                {
                    fcDo[lstIndexDay[nd]] += fcDo[lstIndexNight[nd]];
                    fcDo[lstIndexNight[nd]] = 0;
                    if (debugMode) consoleResult += ($"fcDo[{lstIndexDay[nd]}] = {fcDo[lstIndexDay[nd]]} \tfcDo[{lstIndexNight[nd]}] = 0 \n");
                }
            }
        }
        public static void DSim_CalculateFCDO_SpecialVendor(this double dPcsbox, double[] demand, double[] leadtime, double[] remainIncl, 
            bool debugMode, int length, double[] arrRatio, ref string consoleResult, ref double[] fcDo)
        {
            if (dPcsbox != 0)
            {
                //xác định logic chỗ nào kết thúc thị trường
                if (debugMode) consoleResult += "\n\nStep KTTT 3 Vendor special\n";
                for (int kti = 0; kti < length - 1; kti++)
                {
                    if (demand[kti] > 0 && demand[kti + 1] == 0 && leadtime[kti] == 0)
                    {
                        //tìm vị trí gần nhất trước đó
                        var idxNearest = fcDo[0..(kti - 1)].Select((value, index) => new { value, index }).Where(kii => kii.value != 0).LastOrDefault();
                        if (idxNearest != null)
                        {
                            fcDo[idxNearest.index] = remainIncl[kti] < 0 ? Math.Ceiling(((Math.Abs(remainIncl[kti].DSim_RemainIncl_RoundNegative1Decimal()) * arrRatio[kti] / 100) - fcDo[0..(idxNearest.index - 1)].Sum()) / dPcsbox) * dPcsbox : 0;
                            if (debugMode) consoleResult += $"RemainIncl[{kti}] = {remainIncl[kti]}, ratio[{arrRatio[kti]}] = {arrRatio[kti]}, pcsBox = {dPcsbox}, idxNearest = {idxNearest.index}, fcDo[{idxNearest.index}] = {fcDo[idxNearest.index]}, sum fcDo[0..{idxNearest.index - 1}] = {fcDo[0..(idxNearest.index - 1)].Sum()}\n";
                        }
                    }
                }
            }
        }
        public static void DSim_CalculateFCDO_PullIn(this int ignoredIndex, double[] demand, double[] leadtime, 
            bool debugMode, int length, int numberBlock, int[] Item1,
            ref string consoleResult, ref double[] fcDo)
        {
            for (int kti = ignoredIndex; kti < length - 1; kti++)
            {
                if (demand[kti] > 0 && demand[kti + 1] == 0 && leadtime[kti] == 0)
                {
                    try
                    {
                        var hasDemand = demand[0..kti].Select((value, index) => new { value, index }).Where(ktii => ktii.value != 0).Reverse().Take(numberBlock).Reverse().ToArray();
                        if (hasDemand == null || hasDemand.Length < 1) continue;
                        double doPPP = 0;
                        //if (hasDemand == null || hasDemand.Length == 0) Console.WriteLine($"No demand with kti = {kti}");
                        foreach (var ihd in hasDemand.Select(ihdd => ihdd.index).ToArray())
                        {
                            doPPP += Math.Max(0, fcDo[ihd]);
                            fcDo[ihd] = 0;
                            if (debugMode) consoleResult += ($"value fcDo++ = {doPPP}, fcDo[{ihd}] = 0\n");
                        }
                        if (Item1 != null && Item1.Length > 0)
                        {
                            var idxPull = Item1.Where(iii => iii < hasDemand[0].index).LastOrDefault();
                            fcDo[idxPull] += doPPP;
                            if (debugMode) consoleResult += ($"fcDo[{idxPull}] = {fcDo[idxPull]}, firstCheckPos = {hasDemand[0].index}\n");
                        }
                    }
                    catch (Exception)
                    {
                        //errorList += $"\nError when scan KTTT position {kti} of {itemAdd.PartNo}_{itemAdd.Vendor}_{itemAdd.Bc} {ex1.Message}";
                        continue;
                    }
                }
            }
        }
        public static void DSim_ParseFCDOToModel(this int ignoredIndex, ref double[] fcDo, Dictionary<TimeOnly, 
            string> Item2, DateTime[] lstBlockTimeAll, PcSimulationSmTimeOp6Lbp item,
            ref ConcurrentBag<PcSimulationFcdoLbp> lstResult)
        {
            var fcDoScan = fcDo.Select((value, index) => new { value, index }).Skip(ignoredIndex - 1).Where(s => s.value > 0).ToList();
            Array.Fill(fcDo, 0);
            foreach (var ks in fcDoScan)
            {
                if (Item2.TryGetValue(TimeOnly.FromDateTime(lstBlockTimeAll[ks.index]), out string? timeOri))
                {
                    Console.WriteLine($"Da vao day {timeOri}");
                    lstResult.Add(new PcSimulationFcdoLbp()
                    {
                        Active = true,
                        Bc = item.Bc,
                        Moq = item.MoqOrder,
                        PartNo = item.PartNo,
                        Vendor = item.Vendor,
                        OrderQty = ks.value,
                        DateDelivery = lstBlockTimeAll[ks.index].ToString("yyyy-MM-dd"),
                        TimeDelivery = string.IsNullOrEmpty(timeOri) ? lstBlockTimeAll[ks.index].ToString("HHmm") : timeOri,
                        DoPic = item.DoPic,
                        PoPic = item.PoPic
                    });
                    fcDo[ks.index] = ks.value;
                }
            }
        }
        public static void DSim_ParseFCDOToModel(this int ignoredIndex, ref double[] fcDo, Dictionary<TimeOnly,
            string> Item2, DateTime[] lstBlockTimeAll, string bc, string partNo, string vendor, double moqD, string? dopic, string? popic,
            ref ConcurrentBag<PcSimulationFcdoLbp> lstResult)
        {
            var fcDoScan = fcDo.Select((value, index) => new { value, index }).Skip(ignoredIndex - 1).Where(s => s.value > 0).ToList();
            Array.Fill(fcDo, 0);
            foreach (var ks in fcDoScan)
            {
                if (Item2.TryGetValue(TimeOnly.FromDateTime(lstBlockTimeAll[ks.index]), out string? timeOri))
                {
                    lstResult.Add(new PcSimulationFcdoLbp()
                    {
                        Active = true,
                        Bc = bc,
                        Moq = moqD.ToString(),
                        PartNo = partNo,
                        Vendor = vendor,
                        OrderQty = ks.value,
                        DateDelivery = lstBlockTimeAll[ks.index].ToString("yyyy-MM-dd"),
                        TimeDelivery = string.IsNullOrEmpty(timeOri) ? lstBlockTimeAll[ks.index].ToString("HHmm") : timeOri,
                        DoPic = dopic,
                        PoPic = popic
                    });
                    fcDo[ks.index] = ks.value;
                }
            }
        }
        public static void DSim_ParseAdjustDOToModel(this double[] adjustDO, int ignored, ref ConcurrentBag<PcSimulationAdjustDoOp11Lbp> lstResult, 
            Dictionary<TimeOnly, string> Item2, DateTime[] lstBlockTimeAll, string bc, string partNo, string vendor)
        {
            var adjustDoScan = adjustDO.Select((value, index) => new { value, index }).Skip(ignored - 1).Where(s => s.value > 0).ToList();
            foreach (var ks in adjustDoScan)
            {
                if (Item2.TryGetValue(TimeOnly.FromDateTime(lstBlockTimeAll[ks.index]), out string? timeOri))
                {
                    lstResult.Add(new PcSimulationAdjustDoOp11Lbp()
                    {
                        Active = true,
                        AdjustQty = ks.value,
                        Bc = bc,
                        PartNo = partNo,
                        Vendor = vendor,
                        DateDelivery = lstBlockTimeAll[ks.index].ToString("yyyy-MM-dd"),
                        TimeDelivery = timeOri == null || timeOri == "" ? lstBlockTimeAll[ks.index].ToString("HHmm") : timeOri,
                        PoKey = "(undefined)"
                    });
                }
            }
        }
        public static void DSim_IndexIP3_Ignored_Off_Production(this List<SimualationIp3GetEtaOff>? arrOff, List<SimualationIp3GetEta>? arr1, 
            ref int[]? filter, DateTime[] lstBlockTimeAll, TimeOnly[]? lstAllTimeOnly)
        {
            var lstOffPos = new List<int>();
            if (arrOff != null && arrOff.Count > 0)
            {
                foreach (var iioff in arrOff)
                {
                    if (iioff.LstBlockOff != null && iioff.LstBlockOff.Length > 0)
                    {
                        foreach (var iio in iioff.LstBlockOff)
                        {
                            lstOffPos.Add(Array.IndexOf(lstBlockTimeAll, iio));
                        }
                    }
                }
                if (lstOffPos != null && lstOffPos.Count > 0 && lstAllTimeOnly != null && arr1 != null)
                {
                    filter = lstAllTimeOnly.Select((value, index) => new { value, index }).Where(x => !lstOffPos.Contains(x.index) && arr1.Select(y => y.TimeOnlyValue).Contains(x.value)).Select(x => x.index).OrderBy(z => z).ToArray();
                }

            }
        }
        public static void DSim_ListToDictionary(this List<(string, TimeOnly)> lstOriTime, out Dictionary<TimeOnly, string> dictMapOriTime)
        {
            dictMapOriTime = new Dictionary<TimeOnly, string>();
            foreach (var iori in lstOriTime)
            {
                dictMapOriTime.TryAdd(iori.Item2, iori.Item1);
            }
        }
        public static void DSim_ListToDictionary(this List<(string, double)> ltMd, ref ConcurrentDictionary<string, double> dictLeadtime)
        {
            foreach (var ilt in ltMd)
            {
                dictLeadtime.TryAdd(ilt.Item1, ilt.Item2);
            }
        }
        public static void DSim_ListToDictionary(this List<(string, string)>? lstModel, ref ConcurrentDictionary<string, string> dictResult)
        {
            if(lstModel == null)
            {
                return;
            }
            foreach (var ilt in lstModel)
            {
                dictResult.AddOrUpdate(ilt.Item2, ilt.Item1, (key, oldValue) => $"{oldValue},{ilt.Item1}");
            }
        }
        public static void DSim_ListObjToDictionary(this List<PcSimulationOp6CalcCustom1> lstObject, ref Dictionary<string, double[]> dictObject)
        {
            if(lstObject != null)
            {
                return;
            }
            foreach(var obj in lstObject)
            {
                dictObject.TryAdd($"{obj.Bc}_{obj.PartNo}_{obj.Vendor}", obj.ValueArr);
            }
        }
        public static void DSim_CalculateInventory(this string PartNo, 
            ConcurrentDictionary<(string, string), double> dictInventoryByOtherOrder, ConcurrentDictionary<(string, string), double> dictInventory,
            ref string tempString, string Bc, string Vendor, ref double Inventory)
        {
            foreach (var iiv in PartNo.Split(','))
            {
                var iib = Bc.Split(',');
                if (tempString.Contains(iiv))
                {
                    continue;
                }
                if (dictInventoryByOtherOrder.TryGetValue((iiv, iib[0]), out double a))
                {
                    Inventory += a;
                    tempString += (iiv);
                }
                else
                {
                    if (dictInventory.TryGetValue((iiv, iib[0]), out double b))
                    {
                        Inventory += b;
                        tempString += (iiv);
                    }
                }
            }
        }
        public static void DSim_CalculateDO(this string PartNo,
            ref string tempString, string Bc, string Vendor, int length, ConcurrentDictionary<(string, string, string, string), double> dictOtherOrder,
            DateTime[] lstBlockTimeAll, ConcurrentDictionary<(string, string, DateTime), double> dictDO, ref double[] doVal, ref double[] otherVal)
        {
            for (int k = 0; k < length; k++)
            {
                tempString = "";
                for (int z = 0; z < PartNo.Split(',').Length; z++)
                {
                    if (tempString.Contains(PartNo.Split(',')[z] + Bc.Split(',')[z] + Vendor.Split(',')[z]))
                    {
                        continue;
                    }
                    else
                    {
                        if (dictOtherOrder.TryGetValue((PartNo.Split(',')[z], Vendor.Split(',')[z], Bc.Split(',')[z], lstBlockTimeAll[k].ToString("yyyy-MM-dd HH:mm")), out double c))
                        {
                            otherVal[k] += c;
                        }
                    }
                    if (tempString.Contains(PartNo.Split(',')[z] + Bc.Split(',')[z]))
                    {
                        continue;
                    }
                    else
                    {
                        if (dictDO.TryGetValue((PartNo.Split(',')[z], Bc.Split(',')[z], lstBlockTimeAll[k]), out double b))
                        {
                            doVal[k] += b;
                        }
                        if (dictDO.TryGetValue((PartNo.Split(',')[z], "null", lstBlockTimeAll[k]), out double nu))
                        {
                            doVal[k] += nu;
                        }
                    }
                    tempString += (PartNo.Split(',')[z] + Bc.Split(',')[z] + Vendor.Split(',')[z]);
                }
            }
        }
        public static void DSim_CalculateRemain(this double inventory, double[] demand, double[] demandCp, double[] otherOrder, 
            double[] doVal, int length, ref double[] remainVal)
        {
            remainVal[0] = inventory + doVal[0] - (demand[0] + demandCp[0] + otherOrder[0]);
            for (int k = 1; k < length; k++)
            {
                remainVal[k] = remainVal[k - 1] + doVal[k] - (demand[k] + demandCp[k] + otherOrder[k]);
            }
        }
        public static void DSim_CalculateRemainIncl(this double inventory, double[] remain, double[] leadtime, ref double[] remainIncl, int length)
        {
            for (int k = 0; k < length - 1; k++)
            {
                remainIncl[k] = remain[k] - leadtime[k + 1];
            }
            remainIncl[length - 1] = remain[length - 1];
        }
        public static void DSim_CalculateAbnormalPcs(this double inventory, double[] doVal, double[] remainIncl, ref double[] abnormalPcs, int length, double moq)
        {
            for (int k = 0; k < length - 1; k++)
            {
                if (doVal[k + 1] > 0 && moq > 0)
                {
                    if (remainIncl[k] > moq)
                    {
                        abnormalPcs[k] = Math.Ceiling(-remainIncl[k] / moq) * moq;
                    }
                    else
                    {
                        if (remainIncl[k] < 0)
                        {
                            abnormalPcs[k] = Math.Ceiling(Math.Abs(remainIncl[k]) / moq) * moq;
                        }
                    }
                }
            }
        }
        public static void DSim_CalculateAbnormalPallet(this double inventory, double[] abnormalPcs, ref double[] abnormalPallet, double pcspallet)
        {
            if (pcspallet > 0)
            {
                var abnormalPcsScan1 = abnormalPcs.Select((value, index) => new { value, index }).Where(s => s.value != 0);
                foreach (var ks in abnormalPcsScan1)
                {
                    abnormalPallet[ks.index] = abnormalPcs[ks.index] / pcspallet;
                }
            }
        }
        public static void DSim_AdjustDO(this double inventory, double[] abnormalPcs, ref double[] adjustDO, int length)
        {
            for (int k = 0; k < length; k++)
            {
                adjustDO[k] = abnormalPcs[k] == 0 ? 0 : abnormalPcs[k] - adjustDO[0..k].Sum();
            }
        }

        public static void POKey_ReturnMinValue(this double op7Qty, double poQty, out double minValue, out string minItem)
        {
            minValue = 0;
            minItem = "";
            minValue = Math.Min(op7Qty, poQty);
            if (op7Qty < poQty)
            {
                minItem = "OP7";
            }
            else if (poQty < op7Qty)
            {
                minItem = "PO";
            }
            else
            {
                minItem = "";
            }
        }
        public static void DSim_ReturnDictIP32(this string termIssueDo, Dictionary<TimeOnly, string> dictMapOriTime,
            string vendor, IGrouping<string?, VSimulationIp3TimeTableDelivery>? iip31, List<(DateTime, int)> lstBlockTimeAllIndex,
            ref int[] filter, ref ConcurrentDictionary<string, (int[], Dictionary<TimeOnly, string>)> dictIp3_2, ref ConcurrentDictionary<string, (List<int>, List<int>, int)> dictIp3_4)
        {
            if (string.IsNullOrEmpty(termIssueDo))
            {
                return;
            }
            int ignored = 0;
            int ignored0 = 0;
            if (termIssueDo == "N-D+1")
            {
                ignored = 109;
                ignored0 = 54;
            }
            else if (termIssueDo == "D+1-N+1")
            {
                ignored = 109;
                ignored0 = 109;
            }
            else if (termIssueDo == "D+2-N+2")
            {
                ignored = 219;
                ignored0 = 219;
            }
            filter = filter.Where(z => z > ignored0).ToArray();
            dictIp3_2.TryAdd(vendor, (filter, dictMapOriTime));
            if(iip31 == null || iip31.Count() < 1)
            {
                return;
            }
            ///phần dành cho FC DO part SUB
            if (!iip31.Any(ip => ip.Shift == "D"))//nếu không có lot ca ngày thì không phải làm gì cả
            {
                
            }
            if (!iip31.Any(ip => ip.Shift == "D" && ip.Eta.ObjToIntAble() <= 1300))//nếu không có lot nào trước 13h thì đưa tất cả DO NS về lot 1 DS
            {
                var lot1DS = iip31.Where(ipp => ipp.Shift == "D" && ipp.RowNum == 1).FirstOrDefault();
                if (lot1DS != null)
                {
                    //chuyển all lot Night về lot 1 Day
                    var tod = new TimeOnly(Convert.ToInt32(lot1DS.Eta.Substring(0, 2)), Convert.ToInt32(lot1DS.Eta.Substring(2, 1) + "0"));
                    List<int> lstIndexNight = new List<int>();
                    List<int> lstIndexDay = new List<int>();
                    var lstIpp33 = iip31.Where(ipp => ipp.Shift == "N").Select(ipp => ipp.Eta).ToList();
                    foreach (var item in lstIpp33)
                    {
                        var ton = new TimeOnly(Convert.ToInt32(item.Substring(0, 2)), Convert.ToInt32(item.Substring(2, 1) + "0"));
                        var idxN = lstBlockTimeAllIndex.Where(k => k.Item2 > ignored && TimeOnly.FromDateTime(k.Item1) == ton).Select(k => k.Item2).ToList();
                        foreach (var itemN in idxN)
                        {
                            try
                            {
                                var itemD = lstBlockTimeAllIndex.Where(k => k.Item2 > ignored && k.Item2 < itemN && TimeOnly.FromDateTime(k.Item1) == tod).Max(k => k.Item2);
                                lstIndexNight.Add(itemN);
                                lstIndexDay.Add(itemD);
                            }
                            catch (Exception)
                            {
                                
                            }

                        }
                    }
                    dictIp3_4.TryAdd(vendor, (lstIndexNight, lstIndexDay, ignored));
                }
            }
            else if (iip31.Any(ip => ip.Shift == "D" && ip.Eta.ObjToIntAble() <= 1300))
            {
                var lstIpp33 = iip31.ToList().MatchShifts();
                //Console.WriteLine($"Vendor {vendor}");
                List<int> lstIndexNight = new List<int>();
                List<int> lstIndexDay = new List<int>();
                foreach (var item in lstIpp33)
                {

                    var ton = new TimeOnly(Convert.ToInt32(item.EtaN.Substring(0, 2)), Convert.ToInt32(item.EtaN.Substring(2, 1) + "0"));
                    var tod = new TimeOnly(Convert.ToInt32(item.EtaD.Substring(0, 2)), Convert.ToInt32(item.EtaD.Substring(2, 1) + "0"));
                    var idxN = lstBlockTimeAllIndex.Where(k => k.Item2 > ignored && TimeOnly.FromDateTime(k.Item1) == ton).Select(k => k.Item2).ToList();
                    foreach (var itemN in idxN)
                    {
                        try
                        {
                            var itemD = lstBlockTimeAllIndex.Where(k => k.Item2 > ignored && k.Item2 < itemN && TimeOnly.FromDateTime(k.Item1) == tod).Max(k => k.Item2);
                            lstIndexNight.Add(itemN);
                            lstIndexDay.Add(itemD);
                        }
                        catch (Exception)
                        {
                            
                        }

                    }
                }
                dictIp3_4.TryAdd(vendor, (lstIndexNight, lstIndexDay, ignored));
            }
        }
        #endregion

        public static string ReturnShiftOfTime(this DateTime time)
        {
            var check = time.ToString("HHmm").StringAbleToDouble();
            if (time.ToString("HHmm").StringAbleToDouble() >= 800 && time.ToString("HHmm").StringAbleToDouble() < 2100)
            { 
                return "DAY";
            }
            else
            {
                return "NIGHT";
            }
        }

        public static double RounDownNumber(this double number)
        {
            try
            {
                if (number == null)
                {
                    return 0;
                }
                double roundedNumber = Math.Floor(number / 10) * 10;
                return roundedNumber;
            }
            catch (Exception)
            {
                return 0;
            }
        }
        public static double RounUpNumber(this double number)
        {
            try
            {
                if (number == null)
                {
                    return 0;
                }
                double roundedNumber = Math.Ceiling(number / 10) * 10;
                return roundedNumber;
            }
            catch (Exception)
            {
                return 0;
            }
        }
    }
    public class FileFunction
    {
        public static string GetContentType(string fileName)
        {
            var provider = new FileExtensionContentTypeProvider();
            string contentType;
            if (!provider.TryGetContentType(fileName, out contentType))
            {
                contentType = "application/octet-stream";
            }
            return contentType;
        }
    }
}
