﻿using AutoMapper;
using ClosedXML.Excel;
using Microsoft.EntityFrameworkCore;
using OfficeOpenXml;
using PDCProjectApi.Data;
using PDCProjectApi.Model.Response;
using System.Diagnostics;
using System.Net;
using StackExchange.Redis;
using Newtonsoft.Json;
using Npgsql;
using PDCProjectApi.Model.View;
using NuGet.Packaging;
using System.Collections.Concurrent;
using OfficeOpenXml.Style;
using System.Drawing;
using System.Globalization;
using PDCProjectApi.Model.Request;
using System.IO;
using System.Text.RegularExpressions;
using PDCProjectApi.Services;
using DocumentFormat.OpenXml.Drawing.Charts;
using Microsoft.AspNetCore.SignalR;
using System.Net.Http.Headers;
using Hangfire;
using System.Runtime.ConstrainedExecution;

namespace PDCProjectApi.Common.Job
{
    public interface IManualJob
    {
        Task AutoCheckAllIJ();
        Task RefreshMvH445();
        Task AutoCheckIJ_H1202();
        Task AutoCheckIJ_H3001();
        Task AutoCheckIJ_H501();
        Task AutoCheckIJ_H300();
        Task AutoCheckIJ_J1001();
        Task RefreshMvEcnLv2Ij();
        Task HeadersIJ();
        Task GetOutputIJ(bool saveDel);
        Task GetOutputIJALLExcel();
        Task UpdateMasterDeliveryIJ();
        Task CalcChangingPointIJ();
        Task CalcUniquePartIJ();

        Task AutoCheckLBP_H300();
        Task AutoCheckLBP_J1001();
        Task AutoCheckLBP_H501();
        Task AutoCheckLBP_H1202();
        Task AutoCheckLBP_H3001();
        Task RefreshMvEcnLv2LBP();
        Task AutoCheckAllLBP();
        Task HeadersLBP();
        Task GetOutputLBP(bool saveDel);
        Task GetOutputLBPALLExcel();
        Task UpdateMasterDeliveryLBP();
        Task CalcChangingPointLBP();
        Task CalcUniquePartLBP();

        Task SaveD101IJRedis();
        Task SaveD101LBPRedis();
        Task SaveJ4500IJRedis();
        Task SaveJ4500LBPRedis();
        Task GetOutputECNLV2IJ();
        Task GetOutputECNLV2LBP();
        Task RunStructureIJ();
        Task RunStructureLBP();
        Task CheckSourceBeforeRunStructure(string product);
        Task UpdatePicOPStructureAferApproved(string product);
        Task UpdateStructureAfterApproved(string masterType, string product);
        ValueTask DisposeAsync();
        Task GetOutputMerExcel(string product);
    }
    public class ManualJob : IManualJob, IAsyncDisposable
    {
        private readonly object lockObj = new object();

        private readonly IGlobalVariable global = new GlobalVariable();
        private List<string> lstITMail;
        private string pathServer;
        private readonly IHubContext<RealTimeHub> _hubContext;
        private static ConnectionMultiplexer redis = RedisConnectionManager.GetRedisConnection();
        private static IDatabase database = redis.GetDatabase();
        private static string date = DateTime.Now.ToString("d-M-yyyy");
        private string Factory = "";
        private List<string> lstPDCMail = new List<string>();
        private readonly IBackgroundJobClient _jobClient;
        public ManualJob(PdcsystemContext context, IHubContext<RealTimeHub> hubContext, IBackgroundJobClient _backgroundJobClient)
        {
            //this.ctx = context;

            this.lstITMail = global.ReturnITMail();
            this.pathServer = global.ReturnPathServer();
            this._hubContext = hubContext;
            this.Factory = global.ReturnFactory();
            this.lstPDCMail = this.global.ReturnPDCMail();
            this._jobClient = _backgroundJobClient;
            //this.database = RedisConnectionManager.GetDatabase();
        }

        private bool disposed = false;
        public async ValueTask DisposeAsync()
        {
            await DisposeAsyncCore(true);
            GC.SuppressFinalize(this);
        }
        protected virtual async ValueTask DisposeAsyncCore(bool disposing)
        {
            if (!disposed)
            {
                //if (database != null)
                //{
                //     redis.Dispose();
                //}
                disposed = true;
            }
        }

        #region IJ
        public async Task AutoCheckAllIJ()
        {

            try
            {
                Task task1 = RefreshMvH445();
                Task task2 = AutoCheckIJ_H1202();
                Task task3 = AutoCheckIJ_H3001();
                Task task4 = AutoCheckIJ_H501();
                Task task5 = AutoCheckIJ_H300();
                Task task6 = AutoCheckIJ_J1001();
                Task task7 = RefreshMvEcnLv2Ij();
                await Task.WhenAll(task1, task2, task3, task4, task5, task6, task7);

            }
            catch (Exception e)
            {
                new EmailService().Initial(lstITMail, " Faile get all view", e.Message);
            }
        }
        public async Task RefreshMvH445()
        {

            try
            {

                string job0 = _jobClient.Enqueue(() => ADO.RefreshMaterializeViewWithContext("mv_euc_h445"));
                _jobClient.ContinueJobWith(job0, () => ADO.RefreshMaterializeViewWithContext("mv_euc_h445_co_main"));
                _jobClient.ContinueJobWith(job0, () => ADO.RefreshMaterializeViewWithContext("mv_euc_h445_mer_usage"));
                _jobClient.ContinueJobWith(job0, () => ADO.RefreshMaterializeViewWithContext("mv_euc_h445_merchandise"));
                _jobClient.ContinueJobWith(job0, () => ADO.RefreshMaterializeViewWithContext("mv_euc_h445_mother"));
                _jobClient.ContinueJobWith(job0, () => ADO.RefreshMaterializeViewWithContext("mv_euc_h445_part_legular"));
                _jobClient.ContinueJobWith(job0, () => ADO.RefreshMaterializeViewWithContext("mv_euc_h445_total_mother"));
                await Task.Run(() => Console.WriteLine("Done H445"));
            }
            catch (Exception e)
            {
                new EmailService().Initial(lstITMail, "Faile refresh mv euc445", e.Message);
            }
        }
        public async Task AutoCheckIJ_H1202()
        {

            try
            {
                //string job1 = _jobClient.Enqueue(() => ADO.RefreshMaterializeViewWithContext("mv_euc_h1202_ij"));
                ADO.RefreshMaterializeViewWithContext("mv_euc_h1202_ij");
                await Task.Run(() => Console.WriteLine("Done H1202"));

            }
            catch (Exception e)
            {
                new EmailService().Initial(lstITMail, " Faile get euch1202_ij", e.Message);

            }
        }
        public async Task AutoCheckIJ_H3001()
        {

            try
            {             
                string job1 = _jobClient.Enqueue(() => ADO.RefreshMaterializeViewWithContext("mv_euc_h3001_ij"));
                await Task.Run(() => Console.WriteLine("Done H3001"));

            }
            catch (Exception e)
            {
                new EmailService().Initial(lstITMail, " Faile get euch3001_ij", e.Message);

            }
        }
        public async Task AutoCheckIJ_H501()
        {

            try
            {
               
                string job1 = _jobClient.Enqueue(() => ADO.RefreshMaterializeViewWithContext("mv_euc_h501_ij"));
                await Task.Run(() => Console.WriteLine("Done mv_euc_h501_ij"));
            }
            catch (Exception e)
            {
                new EmailService().Initial(lstITMail, " Faile get euch501_ij", e.Message);
            }
        }
        public async Task AutoCheckIJ_H300()
        {

            try
            {
                string job1 = _jobClient.Enqueue(() => ADO.RefreshMaterializeViewWithContext("mv_euc_h300_ij"));
                await Task.Run(() => Console.WriteLine("Done mv_euc_h300_ij"));

            }
            catch (Exception e)
            {
                new EmailService().Initial(lstITMail, " Faile get euch300_ij", e.Message);

            }
        }
        public async Task AutoCheckIJ_J1001()
        {

            try
            {
              
                string job1 = _jobClient.Enqueue(() => ADO.RefreshMaterializeViewWithContext("mv_euc_j1001_ij"));
                await Task.Run(() => Console.WriteLine("Done mv_euc_j1001_ij"));

            }
            catch (Exception e)
            {
                new EmailService().Initial(lstITMail, " Faile get eucj1001_ij", e.Message);

            }
        }
        public async Task RefreshMvEcnLv2Ij()
        {

            try
            {

                string job6 = _jobClient.Enqueue(() => ADO.RefreshMaterializeViewWithContext("mv_euc_ecn_lv2_ij"));
                _jobClient.ContinueJobWith(job6, () => ADO.RefreshMaterializeViewWithContext("mv_euc_ecn_lv2_ij_usage"));
                _jobClient.ContinueJobWith(job6, () => ADO.RefreshMaterializeViewWithContext("mv_euc_ecn_lv2_ij_merchandise"));
                await Task.Run(() => Console.WriteLine("Done EcnLv2"));
            }
            catch (Exception e)
            {
                new EmailService().Initial(lstITMail, "Faile refresh mv ecn_lv2_ij", e.Message);
            }
        }     
        public async Task HeadersIJ()
        {
            using (var ctx = new PdcsystemContext())
            {

                var lstDtEntry = ctx.MvEucH445s.Select(x => x.DtEnty).Distinct().ToList();
                try
                {

                    var ijMerchandise = ctx.TodStructureMasterMerchandises.Where(x => x.Active == true
                     && x.Model != null && x.DestName != null && x.Merchandise != null
                     && x.Product != null && x.Product.Equals("IJ") && x.ApprovedBy != null && x.ApprovedDate != null && x.Status == "Run").ToList().OrderBy(x => x.Bc).ThenBy(x => x.Model).ThenBy(x => x.Merchandise).GroupBy(x => new { x.Model, x.DestName, x.Merchandise }).Select(g => g.First());
                    if (ijMerchandise.Count() > 0)
                    {
                        var activeHeader = await ctx.TodStructureOutputHeaders.Where(x => x.Active == true && x.Product.Equals("IJ")).ToListAsync();
                        activeHeader.ForEach(x => x.Active = false);
                        ctx.TodStructureOutputHeaders.UpdateRange(activeHeader);

                        var arrModel45 = ijMerchandise.ToList().Select((x, index) => $"{index}:{x.Model ?? ""}").ToArray(); ;
                        var arrMerchandise46 = ijMerchandise.ToList().Select((x, index) => $"{index}:{x.DestName ?? ""}").ToArray();
                        var arrMercode47 = ijMerchandise.ToList().Select((x, index) => $"{index}:{x.Merchandise ?? ""}").ToArray();
                        var arrValue48 = ijMerchandise.Select(x => "").ToList();

                        lstDtEntry.ForEach(x =>
                        {
                            ctx.TodStructureOutputHeaders.Add(new TodStructureOutputHeader()
                            {
                                Active = true,
                                DateEntry = DateOnly.FromDateTime(DateTime.Parse(x)),
                                Merchandise = arrMerchandise46,
                                MerCode = arrMercode47,
                                Model = arrModel45,
                                Product = "IJ"
                            });
                            ctx.SaveChanges();
                        });
                        // HeadersToRedisIJ();
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                }

            }

        }
        public async Task GetOutputIJ(bool saveDel)
        {
            var lstOut = new List<TodStructureOutputContentIj>();
            //////var context = new PdcsystemContext();
            using (var context = new PdcsystemContext())
            {
                try
                {
                    var mveucH445 = context.MvEucH445s.AsQueryable();
                    var ijMerchandise = new List<TodStructureMasterMerchandise>();
                    ijMerchandise = await context.TodStructureMasterMerchandises.Where(x => x.Active == true
                   && x.Model != null && x.DestName != null && x.Merchandise != null
                   && x.Product != null && x.Product.Equals("IJ") && x.ApprovedBy != null && x.ApprovedDate != null && x.Status == "Run")
                       .OrderBy(x => x.Model).ThenBy(x => x.Merchandise)
                       .ToListAsync();

                    //var lstMer = ijMerchandise.Select(y => y.Merchandise + "_" + y.Bc).Distinct().ToList();
                    //var merh445 = await mveucH445.Select(x => x.NoInParts + "_" + x.CdBlock).Distinct().ToListAsync();
                    //if (merh445.Count >= lstMer.Count)
                    //{
                    Console.WriteLine("Start: " + DateTime.Now);
                    string content = "<p style='font-weight: bold;'>Dear [Mrs/Mr]. All,</p>";
                    content += "<p>" + "Start calc at : " + DateTime.Now + "</p>";
                    var config = new MapperConfiguration(cfg =>
                    {
                        cfg.CreateMap<TodStructureOutputContentIj, TodStructureOutputContentIj>().ForMember(x => x.Id, opt => opt.Ignore()); ;
                    });
                    var mapper = new Mapper(config);
                    var masterpacking = await context.TodStructureMasterPackings.Where(x => x.Active == true && x.ApprovedDate != null && x.ApprovedBy != null).AsNoTracking().ToListAsync();
                    var masterjob = await context.PcPaPartJobAssignments.Where(x => x.Active == true && x.ApprovalDate != null && x.ApprovalBy != null && x.Product.ToUpper() == "IJ").AsNoTracking().ToListAsync();
                    var masterdelivery = await context.TodStructureMasterDeliveries.Where(x => x.Active == true && x.ApprovedDate != null && x.ApprovedBy != null && x.Product.ToUpper() == "IJ").AsNoTracking().ToListAsync();
                    var lstBc = global.ReturnBlockCode();

                    var dictPacking = new ConcurrentDictionary<(string, string), (int, int, int, int)>();
                    foreach (var ip in masterpacking)
                    {
                        dictPacking.TryAdd((ip.PartNo, ip.Vendor), (ip.Moq ?? 0, ip.PcsBox ?? 0, ip.BoxPallet ?? 0, ip.PcsPallet ?? 0));
                    }
                    var dictAssignJob = new ConcurrentDictionary<(string, string), (string, string)>();
                    foreach (var ip in masterjob)
                    {
                        dictAssignJob.TryAdd((ip.PartNo, ip.Vendor), (ip.DoPic ?? "", ip.PicPo ?? ""));
                    }
                    var dictDelivery = new ConcurrentDictionary<string, string>();
                    foreach (var ip in masterdelivery)
                    {
                        dictDelivery.TryAdd(ip.VendorCode, $"{ip.MethodDelivery ?? ""}_{ip.Location1 ?? ""}_{ip.Location2 ?? ""}_{ip.Location3 ?? ""}_{ip.RouteDelivery ?? ""}_{ip.PartDelivMoving ?? ""}_{ip.DelivFreqDay ?? 0}_{ip.DelivFreqNight ?? 0}_{ip.DelivFreqWeek ?? 0}_{ip.Name ?? ""}");
                    }

                    var arrValue48 = new List<string>();


                    var header = await context.TodStructureOutputHeaders.Where(x => x.Active == true && x.Product.ToUpper().Contains("IJ")).AsNoTracking().FirstAsync();
                    arrValue48 = header.Merchandise.Select(x => "").ToList();
                    // var dicDateIndex = calendarActual.Select((item, index) => new { Key = item.DateOfDate, Value = index }).ToDictionary(x => x.Key, x => x.Value);
                    var dicIndexMer = header.MerCode.ToList().Select(x => new { Key = x.Split(":")[1], Index = x.Split(":")[0] }).ToDictionary(x => x.Key, x => x.Index);
                    var dicIndexModel = header.Model.ToList().Select(x => new { Key = x.Split(":")[0], Index = x.Split(":")[1] }).ToDictionary(x => x.Key, x => x.Index);
                    var dicIndexDes = header.Merchandise.ToList().Select(x => new { Key = x.Split(":")[0], Index = x.Split(":")[1] }).ToDictionary(x => x.Key, x => x.Index);


                    var euch445 = await mveucH445.GroupBy(x => new { x.CdBlock, x.NoChldParts, x.CdBlockH001, x.Ratio, x.NoChldAdjDim }).Select(g => g.First()).ToListAsync();

                    if (saveDel == true)
                    {
                        context.Database.ExecuteSqlRaw("DELETE FROM public.tod_structure_output_content_ij where active = true;");
                    }
                    else
                    {
                        ////tắt trigger
                        context.Database.ExecuteSqlRaw("ALTER TABLE public.tod_structure_output_content_ij DISABLE TRIGGER ALL");
                        //xóa output
                        context.Database.ExecuteSqlRaw("DELETE FROM public.tod_structure_output_content_ij where active = true;");
                        ////bật trigger
                        context.Database.ExecuteSqlRaw("ALTER TABLE public.tod_structure_output_content_ij Enable TRIGGER ALL");

                    }
                    var euch445CoMain = await context.MvEucH445CoMains.ToDictionaryAsync(x => x.CoKey, x => x.OrderNo);
                    var euch445MerUsage = await context.MvEucH445MerUsages.ToDictionaryAsync(x => x.MerKey, x => x.Usage);
                    var euch445Merchandise = await context.MvEucH445Merchandises.ToDictionaryAsync(x => x.MerKey, x => x.Merchandise);
                    var euch445PartLegular = await context.MvEucH445PartLegulars.ToDictionaryAsync(x => x.PartsKey, x => x.NoLegular);
                    var euch1202 = await context.MvEucH1202Ijs.ToListAsync();
                    var dict1202 = new ConcurrentDictionary<(string, string), (string, string)>();
                    foreach (var ip in euch1202)
                    {
                        dict1202.TryAdd((ip.NoParts, ip.NoSubstitParts), (ip.DtBValid, ip.PtSubstit));
                    }
                    var euch3001 = await context.MvEucH3001Ijs.ToListAsync();
                    var dict3001 = new ConcurrentDictionary<string, string>();
                    foreach (var ip in euch3001)
                    {
                        dict3001.TryAdd(ip.NoParts, ip.PdDecimalLead);
                    }
                    var euch5001 = await context.MvEucH501Ijs.ToListAsync();
                    var dict5001 = new ConcurrentDictionary<(string, string), (string, string)>();
                    foreach (var ip in euch5001)
                    {
                        dict5001.TryAdd((ip.NoParts, ip.CdBlock), (ip.DtBValid, ip.PtRatio));
                    }
                    var euch300 = await context.MvEucH300Ijs.ToListAsync();
                    var dict300 = new ConcurrentDictionary<(string, string, string), (string, string)>();
                    foreach (var ip in euch300)
                    {
                        dict300.TryAdd((ip.NoParts, ip.CdBlock, ip.NoAdjDim), (ip.TmStoreLead, ip.PdProcess));
                    }
                    var eucj1001 = await context.MvEucJ1001Ijs.ToListAsync();
                    var dict1001 = new ConcurrentDictionary<(string, string), (string, string, string, string)>();
                    foreach (var ip in eucj1001)
                    {
                        dict1001.TryAdd((ip.PartsNo, ip.Vendor), (ip.OrderMethod, ip.DeliveryLot, ip.StandardPack, ip.PoLeadTime));
                    }

                    content += "<p>" + " Master Delivery: " + masterdelivery.Count + "</p>";
                    content += "<p>" + " Master Job Assign: " + masterjob.Count + "</p>";
                    content += "<p>" + " Master Merchandise: " + ijMerchandise.Count + "</p>";
                    content += "<p>" + " Master Packing: " + masterpacking.Count + "</p>";
                    content += "<p>" + " EUC445: " + euch445.Count + "</p>";
                    content += "<p>" + " EUC1202: " + euch1202.Count + "</p>";
                    content += "<p>" + " EUC501: " + euch5001.Count + "</p>";
                    content += "<p>" + " EUC1001: " + eucj1001.Count + "</p>";
                    content += "<p>" + " EUC300: " + euch300.Count + "</p>";
                    content += "<p>" + " EUC3001: " + euch3001.Count + "</p>";
                    List<TodStructureOutputContentIj> batchRecords = new List<TodStructureOutputContentIj>();
                    List<TodStructureOutputContentIj> lstTemporary = new List<TodStructureOutputContentIj>();
                    var i = 0;
                    batchRecords = euch445.AsParallel().Select(item =>
                    {
                        var im = new TodStructureOutputContentIj();

                        var dt_entry_only = item.DtEnty;
                        im.DtEntry0 = DateTime.Parse(item.DtEnty);
                        im.Bc1 = item.CdBlock;
                        im.CreatedDate = DateTime.Now;
                        im.EcnNo2 = item.NoChgNotificationH001;
                        im.OldEcnNo2 = item.NoChgNotificationH001;
                        im.EffectiveDate3 = item.DtBValidH001;
                        im.EcnLevel4 = item.CfChgStatClssH001;
                        if (dict5001.TryGetValue((item.NoChldParts, item.CdBlockH001), out var i500))
                        {
                            im.EffectiveDate5 = i500.Item1;
                            im.Ratio6 = i500.Item2;
                        }
                        else
                        {
                            if (dict1202.TryGetValue((item.NoMotherParts, item.NoChldParts), out var i1202))
                            {
                                im.EffectiveDate5 = i1202.Item1;
                                im.Ratio6 = i1202.Item2;
                            }
                        }
                        im.PartNo8 = item.NoChldParts;
                        im.Dim9 = item.NoChldAdjDim;
                        im.Pr10 = item.CdProcessH001;
                        im.PartName11 = item.NmPartsEng;
                        im.Bc12 = item.CdBlockH001;
                        im.Unit13 = item.CdPiece;
                        im.Factory17 = "";
                        im.Ratio18 = item.Ratio.ToString();
                        im.Comain22 = "";
                        im.Com23 = "";
                        if (dict3001.TryGetValue(item.NoChldParts, out var i3001))
                        {
                            im.DelAdjust42 = i3001;
                        }
                        im.Value48 = arrValue48.ToArray();

                        if (dictDelivery.TryGetValue(item.CdBlockH001, out var iDel))
                        {
                            string[] iDelVal = iDel.Split('_');
                            im.MethodDelivery24 = iDelVal[0];
                            im.Location125 = iDelVal[1];
                            im.Location226 = iDelVal[2];
                            im.Location327 = iDelVal[3];
                            im.RouteDelivery28 = iDelVal[4];
                            im.PartDelMoving29 = iDelVal[5];
                            im.Day30 = Convert.ToInt32(iDelVal[6]);
                            im.Night31 = Convert.ToInt32(iDelVal[7]);
                            im.Week32 = Convert.ToInt32(iDelVal[8]);
                            im.Name20 = iDelVal[9];
                        }
                        if (dict1001.TryGetValue((item.NoChldParts, item.CdBlockH001), out var i1001))
                        {
                            im.Type19 = i1001.Item1;
                            im.DelLot33 = i1001.Item2;
                            im.StdPacking34 = i1001.Item3;
                            im.Polt39 = i1001.Item4;
                        }
                        if (dictPacking.TryGetValue((item.NoChldParts, item.CdBlockH001), out var iPackVal))
                        {
                            im.Moq35 = iPackVal.Item1;
                            im.Pcsbox36 = iPackVal.Item2;
                            im.Boxpl37 = iPackVal.Item3;
                            im.Pcspl38 = iPackVal.Item4;
                        }
                        if (dict300.TryGetValue((item.NoChldParts, item.CdBlockH001, item.NoChldAdjDim), out var i300))
                        {
                            im.Storelt40 = i300.Item1;
                            im.Process41 = i300.Item2;
                        }
                        if (dictAssignJob.TryGetValue((item.NoChldParts, item.CdBlockH001), out var valJob))
                        {
                            im.DoPic43 = valJob.Item1;
                            im.PoPic44 = valJob.Item2;
                        }
                        im.Comain22 = null;
                        if (item.PtRatioH005.StringAbleToDouble() > 0 && item.PtRatioH005.StringAbleToDouble() < 100)
                        {
                            im.Comain22 = lstBc.Contains(item.CdBlockH001) ? "CO - Parallel" : "CO";
                        }
                        if (item.PtSubstitH003.StringAbleToDouble() <= 100)
                        {
                            if (!string.IsNullOrEmpty(item.NoLegularPartsH003.Trim()))
                            {
                                if (euch445PartLegular.TryGetValue(item.NoChldParts + "_" + item.CdBlock, out var nolegularpart))
                                {
                                    if (euch445CoMain.TryGetValue(nolegularpart + "_" + item.CdBlock, out var key_comain))
                                    {
                                        string? coMain = key_comain == null ? null : key_comain.ToString();
                                        im.Comain22 = im.Comain22 == null ? coMain : im.Comain22 + "_" + coMain;
                                    }
                                }

                            }
                        }
                        string model45 = null, des46 = null, mer47 = null;
                            //đếm các mer để so sánh tìm ra des21
                        var count_mer = 0;
                        List<string> merchandiseList = new List<string>();
                        var ratio = item.Ratio;
                        if (euch445Merchandise.TryGetValue(item.CdBlock + "_" + item.NoChldParts + "_" + item.CdBlockH001 + "_" + im.Ratio18 + "_" + im.Dim9, out var value))
                        {
                            if (!string.IsNullOrEmpty(value))
                            {
                                string[] merchandiseArray = value?.Split(new[] { ',' }, StringSplitOptions.RemoveEmptyEntries);
                                foreach (var mer in merchandiseArray)
                                {
                                        //////var key_usage = euch445MerUsage[item.CdBlock + "_" + item.NoChldParts + "_" + item.CdBlockH001 + "_" + mer + "_" + ratio + "_" + im.Dim9];
                                    if (euch445MerUsage.TryGetValue(item.CdBlock + "_" + item.NoChldParts + "_" + item.CdBlockH001 + "_" + mer + "_" + ratio + "_" + im.Dim9, out var key_usage))
                                    {
                                        if (key_usage != null)
                                        {
                                            var usage = key_usage;
                                            try
                                            {
                                                    // var eucValue = JsonConvert.DeserializeObject<LinkageEucIjH445>(euc445);
                                                    //////var index = dicIndexMer[mer];
                                                dicIndexMer.TryGetValue(mer, out var index);
                                                    // database.StringGet("ij_" +mer);
                                                var susage = usage == 0 ? "0" : usage.ToString();
                                                im.Value48[int.Parse(index)] = susage;
                                                if (usage > 0)
                                                {
                                                        //////var model = dicIndexModel[index];
                                                    dicIndexModel.TryGetValue(index, out var model);
                                                        //database.StringGet("model_" + index.ToString());
                                                        //////var desname = dicIndexDes[index];
                                                    dicIndexDes.TryGetValue(index, out var desname);
                                                        //database.StringGet("desname_" + index.ToString());
                                                    model45 = model45 == null || model45 == "" ? model : model45 + "," + model;
                                                    des46 = des46 == null || des46 == "" ? desname : des46 + "," + desname;
                                                    mer47 = mer47 == null || mer47 == "" ? mer : mer47 + "," + mer;
                                                    count_mer++;
                                                }
                                            }
                                            catch
                                            {
                                                    //return im;
                                            }
                                        }
                                    }


                                }
                            }

                        }

                        im.Model45 = model45;
                        im.Merchandise46 = des46;
                        im.MerCode47 = mer47;

                            //check mer để tìm ra des21
                        var count_mer_from_model = ijMerchandise.Where(x => model45 != null && model45.Split(",").Distinct().ToList().Contains(x.Model) && x.Bc == im.Bc1).Count();
                        if (count_mer >= count_mer_from_model)
                        {
                            im.Des21 = "Com";
                        }
                        else
                        {
                            im.Des21 = "Des";
                        }
                        i++;
                            //////Console.WriteLine(i);
                        return im;

                    }).ToList();



                    var masterTemp = context.TodStructureTemporaryConnects.Where(x => x.Active == true &&
                    ijMerchandise.Select(y => y.Merchandise).ToList().Contains(x.Merchandise)
                    && x.EfffectiveFrom <= DateOnly.FromDateTime(DateTime.Now)
                    && x.EffectiveTo >= DateOnly.FromDateTime(DateTime.Now) && x.ApprovedBy != null).ToList();

                    foreach (var temp in masterTemp)
                    {
                        dicIndexMer.TryGetValue(temp.Merchandise, out var index);
                        dicIndexModel.TryGetValue(index, out var model);
                        dicIndexDes.TryGetValue(index, out var desname);
                        var checkPart = batchRecords.Any(x => x.PartNo8 == temp.PartNo && x.EcnLevel4 == temp.EcnLevel);
                        if (checkPart == true)
                        {
                            var checkexist = batchRecords.FirstOrDefault(x => x.PartNo8 == temp.PartNo && x.Bc12 == temp.Vendor && x.Bc1 == temp.Bc && x.Value48[int.Parse(index)] != "" && x.EcnLevel4 == temp.EcnLevel);
                            if (checkexist != null)
                            {
                                try
                                {

                                    var usage = temp.Usage;
                                    checkexist.Ratio18 = temp.Ratio.ToString();
                                    checkexist.EcnNo2 = temp.TempNo + (checkexist.EcnNo2.Contains("Temp") ? "+" + checkexist.EcnNo2 : null);
                                    var susage = usage == 0 ? "0" : usage.ToString();
                                    checkexist.Value48[int.Parse(index)] = susage;

                                    if (usage == 0)
                                    {
                                        int indexModel45 = checkexist.Model45.LastIndexOf(model.ToString());
                                        if (indexModel45 >= 0)
                                        {
                                            checkexist.Model45 = checkexist.Model45.Remove(indexModel45, model.ToString().Length);
                                        }
                                        int indexMer46 = checkexist.Merchandise46.LastIndexOf(desname.ToString());
                                        if (indexMer46 >= 0)
                                        {
                                            checkexist.Merchandise46 = checkexist.Merchandise46.Remove(indexMer46, desname.ToString().Length);
                                        }

                                        int indexMer47 = checkexist.MerCode47.LastIndexOf(temp.Merchandise);
                                        if (indexMer47 >= 0)
                                        {
                                            checkexist.MerCode47 = checkexist.MerCode47.Remove(indexMer47, temp.Merchandise.Length);
                                        }

                                    }
                                    else
                                    {
                                        checkexist.Model45 = checkexist.Model45 == null || checkexist.Model45 == "" ? model : checkexist.Model45 + "," + model;
                                        checkexist.Merchandise46 = checkexist.Merchandise46 == null || checkexist.Merchandise46 == "" ? desname : checkexist.Merchandise46 + "," + desname;
                                        checkexist.MerCode47 = checkexist.MerCode47 == null || checkexist.MerCode47 == "" ? temp.Merchandise : checkexist.MerCode47 + "," + temp.Merchandise;
                                    }
                                    var count_mer_from_model = ijMerchandise.Where(x => checkexist.Model45 != null && checkexist.Model45.Split(",").Distinct().ToList().Contains(x.Model) && x.Bc == temp.Bc).Count();
                                    var count_value = checkexist.Value48.Where(x => x != "" && x != "0").Count();
                                    if (count_value >= count_mer_from_model)
                                    {
                                        checkexist.Des21 = "Com";
                                    }
                                    else
                                    {
                                        checkexist.Des21 = "Des";
                                    }

                                }
                                catch
                                {

                                    continue;
                                }
                            }
                            else
                            {
                                var im = batchRecords.FirstOrDefault(x => x.PartNo8 == temp.PartNo);
                                try
                                {
                                    var imCopy = mapper.Map<TodStructureOutputContentIj, TodStructureOutputContentIj>(im);

                                    var usage = temp.Usage;
                                    imCopy.Ratio18 = temp.Ratio.ToString();
                                    imCopy.EcnNo2 = temp.TempNo;
                                    imCopy.Bc12 = temp.Vendor;
                                    imCopy.Bc1 = temp.Bc;
                                    imCopy.EcnLevel4 = temp.EcnLevel;
                                    var susage = usage == 0 ? "0" : usage.ToString();
                                    imCopy.Value48 = arrValue48.ToArray();
                                    imCopy.Value48[int.Parse(index)] = susage;
                                    im.Comain22 = null;
                                    if (usage > 0)
                                    {
                                        imCopy.Model45 = model;
                                        imCopy.Merchandise46 = desname;
                                        imCopy.MerCode47 = temp.Merchandise;

                                    }
                                    else
                                    {
                                        imCopy.Model45 = null;
                                        imCopy.Merchandise46 = null;
                                        imCopy.MerCode47 = null;
                                    }

                                    imCopy.Des21 = "Des";
                                    var imCopyClone = mapper.Map<TodStructureOutputContentIj, TodStructureOutputContentIj>(imCopy);
                                    lstTemporary.Add(imCopyClone);
                                }
                                catch
                                {
                                }
                            }
                        }
                        else
                        {
                            var dt_entry = batchRecords.FirstOrDefault().DtEntry0;

                            ////var i3001 = euch3001.FirstOrDefault(x => x.NoParts == temp.PartNo);


                            var im = new TodStructureOutputContentIj()
                            {
                                DtEntry0 = dt_entry,
                                Bc1 = temp.Bc,
                                CreatedDate = DateTime.Now,
                                EcnNo2 = temp.TempNo,
                                OldEcnNo2 = temp.TempNo,
                                EffectiveDate3 = temp.EfffectiveFrom.ToString(),
                                EcnLevel4 = temp.EcnLevel,
                                PartNo8 = temp.PartNo,
                                PartName11 = temp.PartName,
                                Bc12 = temp.Vendor,
                                Ratio18 = temp.Ratio.ToString(),
                                //DelAdjust42 = i3001?.PdDecimalLead.StringAbleToDouble().ToString() ?? "",
                                Value48 = arrValue48.ToArray()
                            };
                            if (dictDelivery.TryGetValue(temp.Vendor, out var iDel))
                            {
                                string[] iDelVal = iDel.Split('_');
                                im.MethodDelivery24 = iDelVal[0];
                                im.Location125 = iDelVal[1];
                                im.Location226 = iDelVal[2];
                                im.Location327 = iDelVal[3];
                                im.RouteDelivery28 = iDelVal[4];
                                im.PartDelMoving29 = iDelVal[5];
                                im.Day30 = Convert.ToInt32(iDelVal[6]);
                                im.Night31 = Convert.ToInt32(iDelVal[7]);
                                im.Week32 = Convert.ToInt32(iDelVal[8]);
                                im.Name20 = iDelVal[9];
                            }
                            if (dictPacking.TryGetValue((temp.PartNo, temp.Vendor), out var iPackVal))
                            {
                                im.Moq35 = iPackVal.Item1;
                                im.Pcsbox36 = iPackVal.Item2;
                                im.Boxpl37 = iPackVal.Item3;
                                im.Pcspl38 = iPackVal.Item4;
                            }
                            if (dictAssignJob.TryGetValue((temp.PartNo, temp.Vendor), out var valJob))
                            {
                                im.DoPic43 = valJob.Item1;
                                im.PoPic44 = valJob.Item2;
                            }
                            if (dict1001.TryGetValue((temp.PartNo, temp.Vendor), out var i1001))
                            {
                                im.Type19 = i1001.Item1;
                                im.DelLot33 = i1001.Item2;
                                im.StdPacking34 = i1001.Item3;
                                im.Polt39 = i1001.Item4;
                            }
                            if (dict3001.TryGetValue(temp.PartNo, out var i3001))
                            {
                                im.DelAdjust42 = i3001;
                            }

                            var usage = temp.Usage;
                            var susage = usage == 0 ? "0" : usage.ToString();
                            im.Value48[int.Parse(index)] = susage;

                            if (usage > 0)
                            {
                                im.Model45 = model;
                                im.Merchandise46 = desname;
                                im.MerCode47 = temp.Merchandise;

                            }
                            else
                            {
                                im.Model45 = null;
                                im.Merchandise46 = null;
                                im.MerCode47 = null;
                            }
                            lstTemporary.Add(im);
                        }
                    }

                    var lstTemp = lstTemporary.Where(x => x.Merchandise46 != null && x.MerCode47 != null && x.Model45 != null).GroupBy(x => new { x.Bc12, x.PartNo8, x.Ratio18 }).Select(g => g.First()).ToList();

                    foreach (var item in lstTemp)
                    {

                        var existingItem = lstTemporary.DistinctBy(x => x.EcnNo2).Where(x => x.Bc12 == item.Bc12 && x.PartNo8 == item.PartNo8 && x.EcnNo2 != item.EcnNo2 && x.Ratio18 == item.Ratio18).ToList();
                        foreach (var item1 in existingItem)
                        {
                            for (int index = 0; index < item1.Value48.Length; index++)
                            {
                                if (item1.Value48[index] != "")
                                {
                                    item.Value48[index] = item1.Value48[index];

                                }
                            }
                            item.Model45 = item.Model45 + (item1.Model45 == null ? null : ("," + item1.Model45));
                            item.Merchandise46 = item.Merchandise46 + (item1.Merchandise46 == null ? null : ("," + item1.Merchandise46));
                            item.MerCode47 = item.MerCode47 + (item1.MerCode47 == null ? null : ("," + item1.MerCode47));
                            item.EcnNo2 = item.EcnNo2 + "," + item1.EcnNo2;

                            //var noAdjm = database.StringGet("euc445_noadjm_" + item.PartNo8 + "_" + item.Bc1 + "_" + item.Bc12 + "_" + item1.MerCode47);
                            //if (!string.IsNullOrEmpty(noAdjm))
                            //{
                            try
                            {
                                if (dict300.TryGetValue((item.PartNo8, item.Bc12, item.Dim9), out var i300))
                                {
                                    item.Storelt40 = i300.Item1;
                                    item.Process41 = i300.Item2;
                                }
                                //////var i300 = euch300.FirstOrDefault(x => x.NoParts == item.PartNo8 && x.CdBlock == item.Bc12 && x.NoAdjDim == item.Dim9);

                                //////// var i300 = GetDeserializedObject<LinkageEucIjH300>("euc300", $"{item.PartNo8}_{item.Bc12}_{item.Dim9.ToString()}");
                                //////if (i300 != null)
                                //////{
                                //////    item.Storelt40 = i300.TmStoreLead;
                                //////    item.Process41 = i300.PdProcess;
                                //////}
                            }
                            catch
                            {
                                continue;
                            }
                            //}
                        }
                        var imCopyClone = mapper.Map<TodStructureOutputContentIj, TodStructureOutputContentIj>(item);
                        //////var iDelC = masterdelivery.FirstOrDefault(x => x.VendorCode == imCopyClone.Bc12);
                        //////var iJobC = masterjob.FirstOrDefault(x => x.PartNo == imCopyClone.PartNo8 && x.Vendor == imCopyClone.Bc12);
                        //////var iPackingC = masterpacking.FirstOrDefault(x => x.PartNo == imCopyClone.PartNo8 && x.Vendor == imCopyClone.Bc12);
                        //////var i1001C = eucj1001.FirstOrDefault(x => x.PartsNo == imCopyClone.PartNo8 && x.Vendor == imCopyClone.Bc12);
                        //GetDeserializedObject<LinkageEucIjJ1001>("euc1001", $"{imCopyClone.PartNo8}_{imCopyClone.Bc12}");
                        //var i300C = GetDeserializedObject<LinkageEucIjH300>("euc300", $"{imCopyClone.PartNo8}_{imCopyClone.Bc12}");

                        if (dictDelivery.TryGetValue(imCopyClone.Bc12, out var iDelC))
                        {
                            string[] iDelVal = iDelC.Split('_');
                            imCopyClone.MethodDelivery24 = iDelVal[0];
                            imCopyClone.Location125 = iDelVal[1];
                            imCopyClone.Location226 = iDelVal[2];
                            imCopyClone.Location327 = iDelVal[3];
                            imCopyClone.RouteDelivery28 = iDelVal[4];
                            imCopyClone.PartDelMoving29 = iDelVal[5];
                            imCopyClone.Day30 = Convert.ToInt32(iDelVal[6]);
                            imCopyClone.Night31 = Convert.ToInt32(iDelVal[7]);
                            imCopyClone.Week32 = Convert.ToInt32(iDelVal[8]);
                            imCopyClone.Name20 = iDelVal[9];
                        }
                        if (dict1001.TryGetValue((imCopyClone.PartNo8, imCopyClone.Bc12), out var i1001C))
                        {
                            imCopyClone.Type19 = i1001C.Item1;
                            imCopyClone.DelLot33 = i1001C.Item2;
                            imCopyClone.StdPacking34 = i1001C.Item3;
                            imCopyClone.Polt39 = i1001C.Item4;
                        }
                        if (dictPacking.TryGetValue((imCopyClone.PartNo8, imCopyClone.Bc12), out var iPackingC))
                        {
                            imCopyClone.Moq35 = iPackingC.Item1;
                            imCopyClone.Pcsbox36 = iPackingC.Item2;
                            imCopyClone.Boxpl37 = iPackingC.Item3;
                            imCopyClone.Pcspl38 = iPackingC.Item4;
                        }

                        //if (i300C != null)
                        //{
                        //    imCopyClone.Storelt40 = i300C.TmStoreLead;
                        //    imCopyClone.Process41 = i300C.PdProcess;
                        //}

                        if (dictAssignJob.TryGetValue((imCopyClone.PartNo8, imCopyClone.Bc12), out var iJobC))
                        {
                            imCopyClone.DoPic43 = iJobC.Item1;
                            imCopyClone.PoPic44 = iJobC.Item2;
                        }

                        var count_mer_from_model = ijMerchandise.Where(x => imCopyClone.Model45 != null && imCopyClone.Model45.Split(",").Distinct().ToList().Contains(x.Model) && x.Bc == imCopyClone.Bc1).Count();
                        var count_value = imCopyClone.Value48.Where(x => x != "" && x != "0").Count();
                        if (count_value >= count_mer_from_model)
                        {
                            imCopyClone.Des21 = "Com";
                        }
                        else
                        {
                            imCopyClone.Des21 = "Des";
                        }


                        batchRecords.Add(imCopyClone);


                    }

                    //update với 2 cặp khác nhau cùng 1 part mà chỉ có số
                    var lstUpdateSameCoMain = batchRecords
                        .Where(record => record.Comain22 != null && record.Comain22.All(char.IsDigit)) // Lọc các bản ghi có part_no chỉ chứa chữ số
                        .GroupBy(record => new { record.PartNo8, record.Bc1 }) // Nhóm các bản ghi theo part_no
                        .Where(group => group.Select(record => record.Comain22).Distinct().Count() >= 2) // Lọc các nhóm có ít nhất 2 giá trị comain22 khác nhau
                        .Select(group => group.Key);

                    foreach (var itemUpdate in lstUpdateSameCoMain)
                    {

                        //var check = batchRecords.FirstOrDefault(x => x.PartNo8 == itemUpdate.PartNo8 && (x.Comain22 != null && x.Comain22 != ""));
                        //if (check != null)
                        //{
                        //    itemUpdate.Comain22 = check.Comain22;
                        //}
                        var check = batchRecords.Where(x => x.Comain22 != null && x.PartNo8 == itemUpdate.PartNo8 && x.Bc1 == itemUpdate.Bc1 && x.Comain22.All(char.IsDigit)).Select(y => y.Comain22).ToList();
                        var commonCo = check.FirstOrDefault();
                        var lstUpdateCo = batchRecords.Where(x => x.Comain22 != null && check.Any(y => y == x.Comain22.Split("_").Last())).ToList();
                        foreach (var item in lstUpdateCo)
                        {
                            item.Comain22 = commonCo;
                        }
                    }


                    //đánh lại cặp với những con part ratio = 100
                    var lstUpdate = batchRecords.Where(x => x.Comain22 == null || x.Comain22 == "").ToList();
                    foreach (var itemUpdate in lstUpdate)
                    {
                        var check = batchRecords.FirstOrDefault(x => x.PartNo8 == itemUpdate.PartNo8 && x.Bc1 == itemUpdate.Bc1 && (x.Comain22 != null && x.Comain22 != ""));
                        if (check != null)
                        {
                            itemUpdate.Comain22 = check.Comain22;
                        }
                    }

                    //check đánh cặp special 
                    //lấy ra tất cả các cặp chỉ là các số
                    var lstUpdateS = batchRecords.Where(x => x.Comain22 != null && x.Comain22 != ""
                    && int.TryParse(x.Comain22, out _)).ToList().GroupBy(x => new { x.Comain22, x.Bc1 }).Select(g => g.First()).ToList();
                    foreach (var itemUpdateS in lstUpdateS)
                    {
                        var check = batchRecords.Where(x => x.Bc1 == itemUpdateS.Bc1 && x.Comain22 != null && x.Comain22.Replace("_S", "").Split("_").Last() == itemUpdateS.Comain22.Replace("_S", "") && x.Model45 != null).ToList();
                        //nếu lớn hơn 1 mới phải check xem có special không
                        List<string> lstString = new List<string>();
                        if (check.Count > 1)
                        {
                            foreach (var itemCheck in check)
                            {
                                string?[] merCode = itemCheck.MerCode47?.Split(',')?.Distinct().ToArray();
                                string? resultMerCode = merCode == null ? null : string.Join(",", merCode);
                                lstString.Add(resultMerCode);
                            }

                        }
                        if (lstString.Count > 0)
                        {
                            bool result = CheckStrings(lstString);
                            if (result == false)
                            {
                                var update = batchRecords.Where(x => x.Comain22 != null && x.Comain22.Replace("_S", "").Split("_").Last() == itemUpdateS.Comain22.Replace("_S", "")).ToList();
                                foreach (var itemUpdate in update)
                                {
                                    itemUpdate.Comain22 = itemUpdate.Comain22.Replace("_S", "") + "_" + "S";
                                }

                            }
                        }

                    }


                    //đánh lại cặp với các cặp có CO hoặc là Co - Parallel lấy theo kí tự dài nhất
                    var lstUpdateLenght = batchRecords.Where(x => x.Comain22 != null && (x.Comain22.Contains("CO") || x.Comain22.Contains("Parallel"))).GroupBy(x => new { x.PartNo8, x.Bc1 }).Select(g => g.First()).ToList().ToList();
                    foreach (var itemUpdate in lstUpdateLenght)
                    {
                        //lấy ra các part giống nhau và cặp giống nhau
                        var lstSame = batchRecords.Where(x => (x.PartNo8 == itemUpdate.PartNo8 && x.Bc1 == itemUpdate.Bc1)
                        || (x.Comain22 != null && int.TryParse(x.Comain22.Replace("_S", "").Split("_").Last(), out _) && x.Comain22.Replace("_S", "").Split("_").Last() == itemUpdate.Comain22.Replace("_S", "").Split("_").Last())).ToList();
                        //lấy ra coMain có kí tự dài nhất
                        var checkMax = lstSame.MaxBy(x => x.Comain22.Length);
                        foreach (var update in lstSame)
                        {
                            update.Comain22 = checkMax.Comain22;
                        }

                    }

                    // Tắt tự động phát hiện thay đổi để tăng hiệu suất
                    context.ChangeTracker.AutoDetectChangesEnabled = false;

                    // Chia danh sách thành các phần nhỏ (ví dụ: 1000 bản ghi mỗi phần)
                    var batchS = 10000;
                    var batches = batchRecords.Select((item, index) => new { Item = item, Index = index })
                                        .GroupBy(x => x.Index / batchS)
                                        .Select(g => g.Select(x => x.Item).ToList());


                    foreach (var batch in batches)
                    {
                        using (var transaction = context.Database.BeginTransaction())
                        {
                            try
                            {
                                context.TodStructureOutputContentIjs.AddRange(batch);
                                context.SaveChanges();

                                transaction.Commit();
                            }
                            catch
                            {
                                transaction.Rollback();
                                throw;
                            }
                        }


                        // Xóa bộ đệm để tránh tràn bộ nhớ
                        context.ChangeTracker.Clear();
                    }


                    content += "<p>" + ("Finished calculate & saved ouput " + batchRecords.Count + " record at: ") + DateTime.Now + "</p>";

                    new EmailService().Initial(lstITMail, " Completed structure output IJ", content);
                    //}
                    //else
                    //{
                    //    new EmailService().Initial(lstPDCMail, " Warning get euc445", "List merchandise from euch445 less than master merchandise, not get data!");
                    //}
                }
                catch (Exception e)
                {
                    new EmailService().Initial(lstITMail, " exception calculation output IJ", e.Message);
                }
            }


        }
        public async Task GetOutputIJALLExcel()
        {
            try
            {
                using (var context = new PdcsystemContext())
                {
                    string product = "IJ";
                    await SendMessageToClients($"Structure{product}_{date}", "Export output");
                    database.StringSet($"RecMess{Factory}Structure{product}_" + date, "Export output");
                    var config = new MapperConfiguration(cfg => cfg.CreateMap<TodStructureOutputContentIj, TodStructureOutputContentView>());
                    var mapper = config.CreateMapper();
                    try
                    {

                        Console.WriteLine(DateTime.Now.ToLongTimeString() + " start export");
                        var header = await context.TodStructureOutputHeaders.AsNoTracking().Where(x => x.Active == true && x.Product == "IJ").FirstOrDefaultAsync();
                        ExcelPackage.LicenseContext = LicenseContext.NonCommercial;


                        string filePath = Path.Combine(pathServer, "FileOutPut\\OutputStructure.xlsx");
                        FileInfo file = new FileInfo(filePath);
                        using (ExcelPackage excelPackage = new ExcelPackage(file))
                        {

                            ExcelWorksheet excelWorksheet = excelPackage.Workbook.Worksheets.First();
                            excelWorksheet.Cells["G1"].Value = DateTime.Now.ToString("yyyy-MM-dd");
                            excelWorksheet.Cells["F1"].Value = "DT_ENTRY";
                            excelWorksheet.Cells["G2"].Value = "IJ";
                            excelWorksheet.Cells["F2"].Value = "Product";
                            int i = 0;
                            int len = 0;
                            var content_start = "start insert time " + DateTime.Now.ToLongTimeString();

                            len = header.Model == null ? 0 : header.Model.Length;
                            if (len > 0)
                            {
                                var cellsMer = excelWorksheet.Cells[7, 47, 9, len + 46].Style;
                                cellsMer.Fill.PatternType = ExcelFillStyle.Solid; ;
                                cellsMer.Fill.BackgroundColor.SetColor(Color.FromArgb(169, 208, 142));
                                cellsMer.WrapText = true;
                                for (int j = 1; j <= len; j++)
                                {
                                    excelWorksheet.Cells[7, 46 + j].Value = header.Model[j - 1].Split(":")[1];
                                    excelWorksheet.Cells[8, 46 + j].Value = header.Merchandise[j - 1].Split(":")[1];
                                    excelWorksheet.Cells[9, 46 + j].Value = header.MerCode[j - 1].Split(":")[1];
                                }
                                excelWorksheet.Cells[9, 46, 9, len + 46].Style.TextRotation = 90;
                            }
                            var hashEntries = context.TodStructureOutputContentIjs.Where(x => x.Active == true).ToList();
                            var lstModel = mapper.Map<List<TodStructureOutputContentIj>, List<TodStructureOutputContentView>>(hashEntries);
                            foreach (var item1 in lstModel)
                            {
                                int currentRow = 10 + i;
                                var item = item1;
                                string?[] model = item.Model45?.Split(',');
                                string?[] hashModel = model?.Distinct().ToArray();
                                string? resultModel = hashModel == null ? null : string.Join("+", hashModel);

                                string?[] merdise = item.Merchandise46?.Split(',');
                                string?[] hashMer = merdise?.Distinct().ToArray();
                                string? resultMerDise = hashMer == null ? null : string.Join("+", hashMer);

                                string?[] merCode = item.MerCode47?.Split(',');
                                string?[] hashMerCode = merCode?.Distinct().ToArray();
                                string? resultMerCode = hashMerCode == null ? null : string.Join("+", hashMerCode);

                                excelWorksheet.Cells[currentRow, 1].Value = i + 1;
                                excelWorksheet.Cells[currentRow, 2].Value = item.Bc1;
                                excelWorksheet.Cells[currentRow, 3].Value = item.EcnNo2;
                                excelWorksheet.Cells[currentRow, 4].Value = item.EffectiveDate3;
                                excelWorksheet.Cells[currentRow, 5].Value = item.EcnLevel4;
                                excelWorksheet.Cells[currentRow, 6].Value = item.EffectiveDate5;
                                excelWorksheet.Cells[currentRow, 7].Value = item.Ratio6;
                                excelWorksheet.Cells[currentRow, 8].Value = item.PartnoBc7;
                                excelWorksheet.Cells[currentRow, 9].Value = item.PartNo8;
                                excelWorksheet.Cells[currentRow, 10].Value = item.Dim9;
                                excelWorksheet.Cells[currentRow, 11].Value = item.Pr10;
                                excelWorksheet.Cells[currentRow, 12].Value = item.PartName11;
                                excelWorksheet.Cells[currentRow, 13].Value = item.Bc12;
                                excelWorksheet.Cells[currentRow, 14].Value = item.Unit13;
                                excelWorksheet.Cells[currentRow, 15].Value = resultModel;
                                excelWorksheet.Cells[currentRow, 16].Value = resultMerDise;
                                excelWorksheet.Cells[currentRow, 17].Value = resultMerCode;
                                excelWorksheet.Cells[currentRow, 18].Value = item.Factory17;
                                excelWorksheet.Cells[currentRow, 19].Value = item.Ratio18.StringAbleToDouble();
                                excelWorksheet.Cells[currentRow, 20].Value = item.Type19;
                                excelWorksheet.Cells[currentRow, 21].Value = item.Name20;
                                excelWorksheet.Cells[currentRow, 22].Value = item.Des21;
                                excelWorksheet.Cells[currentRow, 23].Value = item.Comain22;
                                excelWorksheet.Cells[currentRow, 24].Value = item.Com23;
                                excelWorksheet.Cells[currentRow, 25].Value = item.MethodDelivery24;
                                excelWorksheet.Cells[currentRow, 26].Value = item.Location125;
                                excelWorksheet.Cells[currentRow, 27].Value = item.Location226;
                                excelWorksheet.Cells[currentRow, 28].Value = item.Location327;
                                excelWorksheet.Cells[currentRow, 29].Value = item.RouteDelivery28;
                                excelWorksheet.Cells[currentRow, 30].Value = item.PartDelMoving29;
                                excelWorksheet.Cells[currentRow, 31].Value = item.Day30;
                                excelWorksheet.Cells[currentRow, 32].Value = item.Night31;
                                excelWorksheet.Cells[currentRow, 33].Value = item.Week32;
                                excelWorksheet.Cells[currentRow, 34].Value = item.DelLot33;
                                excelWorksheet.Cells[currentRow, 35].Value = item.StdPacking34;
                                excelWorksheet.Cells[currentRow, 36].Value = item.Moq35;
                                excelWorksheet.Cells[currentRow, 37].Value = item.Pcsbox36;
                                excelWorksheet.Cells[currentRow, 38].Value = item.Boxpl37;
                                excelWorksheet.Cells[currentRow, 39].Value = item.Pcspl38;
                                excelWorksheet.Cells[currentRow, 40].Value = item.Polt39;
                                excelWorksheet.Cells[currentRow, 41].Value = item.Storelt40;
                                excelWorksheet.Cells[currentRow, 42].Value = item.Process41;
                                excelWorksheet.Cells[currentRow, 43].Value = item.DelAdjust42;
                                excelWorksheet.Cells[currentRow, 44].Value = item.DoPic43;
                                excelWorksheet.Cells[currentRow, 45].Value = item.PoPic44;

                                if (item.Value48 != null && item.Value48.Length > 0)
                                {
                                    int len1 = item.Value48 == null ? 0 : item.Value48.Length;
                                    if (len1 > 0)
                                    {
                                        for (int j = 1; j <= len1; j++)
                                        {
                                            excelWorksheet.Cells[currentRow, 46 + j].Value = item.Value48[j - 1] == "" ? "" : item.Value48[j - 1].StringAbleToDouble();
                                            //excelWorksheet.Cells[currentRow, 46 + j].Style.Numberformat.Format = "0";

                                        }
                                    }
                                }
                                i++;
                            }
                            var cells1 = excelWorksheet.Cells[7, 47, 9, len + 46].Style;
                            cells1.Font.Size = 11;
                            cells1.Font.Name = "Calibri";
                            cells1.Border.Top.Style = ExcelBorderStyle.Thin;
                            cells1.Border.Bottom.Style = ExcelBorderStyle.Thin;
                            cells1.Border.Left.Style = ExcelBorderStyle.Thin;
                            cells1.Border.Right.Style = ExcelBorderStyle.Thin;

                            var cells2 = excelWorksheet.Cells[10, 1, hashEntries.Count + 10, len + 46].Style;
                            cells2.Font.Size = 11;
                            cells2.Font.Name = "Calibri";
                            cells2.Border.Top.Style = ExcelBorderStyle.Thin;
                            cells2.Border.Bottom.Style = ExcelBorderStyle.Thin;
                            cells2.Border.Left.Style = ExcelBorderStyle.Thin;
                            cells2.Border.Right.Style = ExcelBorderStyle.Thin;
                            cells2.HorizontalAlignment = ExcelHorizontalAlignment.Left;
                            Console.WriteLine(content_start);
                            Console.WriteLine(DateTime.Now.ToLongTimeString() + " ended export");

                            string outputPath = Path.Combine(pathServer, "FileOutput\\OutPutStructureIJ", "Output_ALL_IJ_" + DateTime.Now.ToString("yyyy-MM-dd") + ".xlsx");
                            FileInfo excelFile = new FileInfo(outputPath);
                            excelPackage.SaveAs(excelFile);
                            await SendMessageToClients($"Structure{product}_{date}", "Finished");
                            database.StringSet($"RecMess{Factory}Structure{product}_" + date, "Finished");
                        }

                    }
                    catch (Exception e)
                    {
                        Console.WriteLine("Except " + e);
                        await SendMessageToClients($"Structure{product}_{date}", "Except export");
                        database.StringSet($"RecMess{Factory}Structure{product}_" + date, "Except export");
                    }
                }
            }
            catch (Exception)
            {

            }


        }
        public async Task UpdateMasterDeliveryIJ()
        {

            using (var ctx = new PdcsystemContext())
            {

                try
                {
                    var delivery = await ctx.TodStructureMasterDeliveries.Where(x => x.Active == true && x.ApprovedBy != null && x.Product != null && x.Product.ToUpper().Contains("IJ")).ToListAsync();
                    var outputIJ = ctx.TodStructureOutputContentIjs.AsNoTracking().Where(x => x.Active == true).ToList();
                    List<TodStructureMasterDelivery> lstUpdate = new List<TodStructureMasterDelivery>();
                    foreach (var item in delivery)
                    {
                        var totalPart = outputIJ.Where(x => x.Bc12 == item.VendorCode && x.Ratio18.StringToIntAble() > 0).Count();
                        item.TotalPartOrder = totalPart;
                        lstUpdate.Add(item);
                    }
                    ctx.UpdateRange(lstUpdate);
                    ctx.SaveChanges();
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                }

            }

        }
        public async Task CalcChangingPointIJ()
        {

            using (var ctx = new PdcsystemContext())
            {

                ExcelPackage.LicenseContext = LicenseContext.NonCommercial;

                try
                {
                    string filePath = Path.Combine(pathServer, "FileOutPut\\OutputChangingPoint.xlsx");
                    FileInfo file = new FileInfo(filePath);
                    using (ExcelPackage excelPackage = new ExcelPackage(file))
                    {
                        ExcelWorksheet excelWorksheet = excelPackage.Workbook.Worksheets.First();
                        excelWorksheet.Cells["G1"].Value = DateTime.Now.ToString("yyyy-MM-dd");
                        excelWorksheet.Cells["F1"].Value = "DT_ENTRY";
                        excelWorksheet.Cells["G2"].Value = "IJ";
                        excelWorksheet.Cells["F2"].Value = "Product";
                        var j = 0;

                        var output = await ctx.TodStructureOutputContentIjs.Where(x => x.Active == true).ToListAsync();
                        var latestDateOutPut = ctx.HistoryTodStructureOutputContentIjs.Where(x => x.Active == true).Max(x => x.DtEntry0);
                        var latestDateHistory = ctx.HistoryTodStructureOutputContentIjs.Where(x => x.Active == true).Max(x => x.HistoryDate.Value.Date);
                        var outputHistory = ctx.HistoryTodStructureOutputContentIjs.Where(x => x.HistoryDate.Value.Date == latestDateHistory).ToList();

                        var checkDt_entry = ctx.TodStructureOutputHeaders.Where(x => x.Active == false && x.Product == "IJ" && x.DateEntry == DateOnly.FromDateTime((DateTime)latestDateOutPut));
                        var lastesHeader = checkDt_entry.Count() != 0 ? checkDt_entry.Max(x => x.DateEntry) : DateOnly.FromDateTime((DateTime)output.Max(x => x.DtEntry0));
                        var header = ctx.TodStructureOutputHeaders.Where(x => x.Active == false && x.Product == "IJ" && x.DateEntry == lastesHeader).OrderByDescending(x => x.CreatedDate).FirstOrDefault();
                        var headerActual = ctx.TodStructureOutputHeaders.Where(x => x.Active == true && x.Product == "IJ").FirstOrDefault();
                        string[] lismerH = new string[header.MerCode.Length];
                        int len = headerActual.Merchandise.Length;
                        for (int i = 0; i < header.MerCode.Length; i++)
                        {
                            int index = header.MerCode[i].IndexOf(":");
                            lismerH[i] = header.MerCode[i].Substring(index + 1);
                        }
                        var dicIndexMerAct = headerActual.MerCode.ToList().Select(x => new { Key = x.Split(":")[1], Index = x.Split(":")[0] }).ToDictionary(x => x.Key, x => x.Index);


                        //change usage
                        output.AsParallel().ForAll(item =>
                        {

                            lock (lockObj) // Sử dụng lock để đồng bộ hoá việc thay đổi dữ liệu
                            {
                                int currentRow = 10 + j;
                                var arr48 = new List<string>();
                                arr48 = item.Value48.Select(x => "").ToList();
                                var checkHistory = outputHistory.FirstOrDefault(x => x.Bc1 == item.Bc1 && x.EcnLevel4 == item.EcnLevel4 &&
                                x.PartNo8 == item.PartNo8 && x.Bc12 == item.Bc12 && x.Ratio18 == item.Ratio18
                                && (!x.EcnNo2.Contains("Temp") ? (x.EcnNo2 == item.EcnNo2) : (x.EcnNo2.Split(",").Any(y => item.EcnNo2.Contains(y))
                                || x.EcnNo2.Split("+").Any(y => item.EcnNo2.Contains(y)))));

                                if (checkHistory != null)
                                {

                                    if (item.MerCode47 != null && checkHistory.MerCode47 != null)
                                    {
                                        foreach (var mer in item.MerCode47.Split(","))
                                        {
                                            int indexHistory = Array.IndexOf(lismerH, mer);
                                            if (indexHistory >= 0)
                                            {
                                                var indexActual = int.Parse(dicIndexMerAct[mer]);
                                                var valueActual = item.Value48[(int)indexActual] == "" ? "0" : item.Value48[(int)indexActual];

                                                try
                                                {
                                                    var valueH = checkHistory.Value48[indexHistory];
                                                    if (valueH != valueActual)
                                                    {
                                                        arr48[(int)indexActual] = valueActual;
                                                    }
                                                }
                                                catch
                                                {

                                                    arr48[(int)indexActual] = valueActual;
                                                }
                                            }
                                        }
                                    }
                                    if (item.MerCode47 == null && checkHistory.MerCode47 != null)
                                    {
                                        arr48 = item.Value48.ToList();
                                    }
                                }
                                var checkArr48 = arr48.Any(x => !x.Equals(""));

                                if (checkArr48 == true)
                                {
                                    string?[] model = item.Model45?.Split(',');
                                    string?[] hashModel = model?.Distinct().ToArray();
                                    //HashSet<string> hashModel = new HashSet<string>(model ?? Enumerable.Empty<string>());
                                    string? resultModel = hashModel == null ? null : string.Join("+", hashModel);
                                    string?[] merCode = item.MerCode47?.Split(',');
                                    string?[] hashMerCode = merCode?.Distinct().ToArray();
                                    //HashSet<string> hashMerCode = new HashSet<string>(merCode ?? Enumerable.Empty<string>());
                                    string? resultMerCode = hashMerCode == null ? null : string.Join("+", hashMerCode);
                                    excelWorksheet.Cells[currentRow, 1].Value = j + 1;
                                    excelWorksheet.Cells[currentRow, 2].Value = item.Bc1;
                                    excelWorksheet.Cells[currentRow, 3].Value = item.PartNo8;
                                    excelWorksheet.Cells[currentRow, 4].Value = item.Bc12;
                                    excelWorksheet.Cells[currentRow, 5].Value = item.Ratio18;
                                    excelWorksheet.Cells[currentRow, 6].Value = resultModel;
                                    excelWorksheet.Cells[currentRow, 7].Value = resultMerCode;
                                    excelWorksheet.Cells[currentRow, 9].Value = item.Name20 == null ? "" : item.Name20;
                                    excelWorksheet.Cells[currentRow, 8].Value = item.EcnLevel4;
                                    int len1 = item.Value48.Length;

                                    for (int b = 1; b <= len1; b++)
                                    {
                                        excelWorksheet.Cells[currentRow, 10 + b].Value = arr48[b - 1];
                                        excelWorksheet.Cells[currentRow, 10 + b].Style.Numberformat.Format = "0";
                                        excelWorksheet.Cells[currentRow, 10 + b].Style.Font.Color.SetColor(System.Drawing.Color.Red);
                                    }
                                    j++;
                                }
                                if (checkHistory == null)
                                {
                                    string?[] model = item.Model45?.Split(',');
                                    string?[] hashModel = model?.Distinct().ToArray();
                                    //HashSet<string> hashModel = new HashSet<string>(model ?? Enumerable.Empty<string>());
                                    string? resultModel = hashModel == null ? null : string.Join("+", hashModel);
                                    string?[] merCode = item.MerCode47?.Split(',');
                                    string?[] hashMerCode = merCode?.Distinct().ToArray();
                                    //HashSet<string> hashMerCode = new HashSet<string>(merCode ?? Enumerable.Empty<string>());
                                    string? resultMerCode = hashMerCode == null ? null : string.Join("+", hashMerCode);
                                    excelWorksheet.Cells[currentRow, 1].Value = j + 1;
                                    excelWorksheet.Cells[currentRow, 2].Value = item.Bc1;
                                    excelWorksheet.Cells[currentRow, 3].Value = item.PartNo8;
                                    excelWorksheet.Cells[currentRow, 3].Style.Font.Color.SetColor(System.Drawing.Color.Purple);
                                    excelWorksheet.Cells[currentRow, 4].Value = item.Bc12;
                                    excelWorksheet.Cells[currentRow, 5].Value = item.Ratio18;
                                    //excelWorksheet.Cells[(10 + j), 5].Style.Font.Color.SetColor(System.Drawing.Color.Red);
                                    excelWorksheet.Cells[currentRow, 6].Value = resultModel;
                                    excelWorksheet.Cells[currentRow, 7].Value = resultMerCode;
                                    excelWorksheet.Cells[currentRow, 9].Value = item.Name20 == null ? "" : item.Name20;
                                    excelWorksheet.Cells[currentRow, 8].Value = item.EcnLevel4;
                                    int len1 = item.Value48.Length;
                                    for (int b = 1; b <= len1; b++)
                                    {
                                        excelWorksheet.Cells[currentRow, 10 + b].Value = item.Value48[b - 1];
                                    }
                                    j++;
                                }

                            }
                        });
                        //change ratio
                        output.GroupBy(x => new { x.PartNo8, x.Bc1, x.Bc12, x.EcnLevel4 }).Select(g => g.First()).ToList().ToList().AsParallel().ForAll(item =>
                        {

                            lock (lockObj) // Sử dụng lock để đồng bộ hoá việc thay đổi dữ liệu
                            {

                                var lstRatio = output.Where(x => x.PartNo8 == item.PartNo8 && x.Bc1 == item.Bc1 && x.Bc12 == item.Bc12 && x.EcnLevel4 == item.EcnLevel4).Select(y => y.Ratio18).ToList();
                                var lstRatioH = outputHistory.Where(x => x.PartNo8 == item.PartNo8 && x.Bc1 == item.Bc1 && x.Bc12 == item.Bc12 && x.EcnLevel4 == item.EcnLevel4).Select(y => y.Ratio18).ToList();

                                var differentElements = lstRatio.Except(lstRatioH);
                                foreach (var difference in differentElements)
                                {
                                    string?[] model = item.Model45?.Split(',');
                                    string?[] hashModel = model?.Distinct().ToArray();
                                    //HashSet<string> hashModel = new HashSet<string>(model ?? Enumerable.Empty<string>());
                                    string? resultModel = hashModel == null ? null : string.Join("+", hashModel);
                                    string?[] merCode = item.MerCode47?.Split(',');
                                    string?[] hashMerCode = merCode?.Distinct().ToArray();
                                    //HashSet<string> hashMerCode = new HashSet<string>(merCode ?? Enumerable.Empty<string>());
                                    string? resultMerCode = hashMerCode == null ? null : string.Join("+", hashMerCode);
                                    excelWorksheet.Cells[(10 + j), 1].Value = j + 1;
                                    excelWorksheet.Cells[(10 + j), 2].Value = item.Bc1;
                                    excelWorksheet.Cells[(10 + j), 3].Value = item.PartNo8;
                                    excelWorksheet.Cells[(10 + j), 4].Value = item.Bc12;
                                    excelWorksheet.Cells[(10 + j), 5].Value = difference;
                                    excelWorksheet.Cells[(10 + j), 5].Style.Font.Color.SetColor(System.Drawing.Color.Red);
                                    excelWorksheet.Cells[(10 + j), 6].Value = resultModel;
                                    excelWorksheet.Cells[(10 + j), 7].Value = resultMerCode;
                                    excelWorksheet.Cells[(10 + j), 9].Value = item.Name20 == null ? "" : item.Name20;
                                    excelWorksheet.Cells[(10 + j), 8].Value = item.EcnLevel4;
                                    int len1 = item.Value48.Length;
                                    for (int b = 1; b <= len1; b++)
                                    {
                                        excelWorksheet.Cells[(10 + j), 10 + b].Value = item.Value48[b - 1];
                                        excelWorksheet.Cells[(10 + j), 10 + b].Style.Numberformat.Format = "0";
                                    }
                                    j = j + 1;
                                }

                            }

                        });

                        //today have, yesterday not have
                        var outputToday = output.Where(x => !outputHistory.Any(y => y.PartNo8 == x.PartNo8 && y.Bc1 == x.Bc1 && y.Bc12 == x.Bc12 && x.EcnLevel4 == y.EcnLevel4)).ToList();
                        outputToday.AsParallel().ForAll(item =>
                        {
                            lock (lockObj) // Sử dụng lock để đồng bộ hoá việc thay đổi dữ liệu
                            {
                                string?[] model = item.Model45?.Split(',');
                                string?[] hashModel = model?.Distinct().ToArray();
                                //HashSet<string> hashModel = new HashSet<string>(model ?? Enumerable.Empty<string>());
                                string? resultModel = hashModel == null ? null : string.Join("+", hashModel);
                                string?[] merCode = item.MerCode47?.Split(',');
                                string?[] hashMerCode = merCode?.Distinct().ToArray();
                                //HashSet<string> hashMerCode = new HashSet<string>(merCode ?? Enumerable.Empty<string>());
                                string? resultMerCode = hashMerCode == null ? null : string.Join("+", hashMerCode);
                                excelWorksheet.Cells[(10 + j), 1].Value = j + 1;
                                excelWorksheet.Cells[(10 + j), 2].Value = item.Bc1;
                                excelWorksheet.Cells[(10 + j), 3].Value = item.PartNo8;
                                excelWorksheet.Cells[(10 + j), 3].Style.Font.Color.SetColor(System.Drawing.Color.Green);
                                excelWorksheet.Cells[(10 + j), 4].Value = item.Bc12;
                                excelWorksheet.Cells[(10 + j), 5].Value = item.Ratio18;
                                excelWorksheet.Cells[(10 + j), 6].Value = resultModel;
                                excelWorksheet.Cells[(10 + j), 7].Value = resultMerCode;
                                excelWorksheet.Cells[(10 + j), 9].Value = item.Name20 == null ? "" : item.Name20;
                                excelWorksheet.Cells[(10 + j), 8].Value = item.EcnLevel4;
                                int len1 = item.Value48.Length;
                                for (int b = 1; b <= len1; b++)
                                {
                                    excelWorksheet.Cells[(10 + j), 10 + b].Value = item.Value48[b - 1];
                                    excelWorksheet.Cells[(10 + j), 10 + b].Style.Numberformat.Format = "0";
                                }
                                j = j + 1;
                            }

                        });


                        //yesterday have, today not have
                        var outputYesterday = outputHistory.Where(x => !output.Any(y => y.PartNo8 == x.PartNo8 && y.Bc1 == x.Bc1 && y.Bc12 == x.Bc12 && x.EcnLevel4 == y.EcnLevel4)).ToList();
                        outputYesterday.AsParallel().ForAll(item =>
                        {
                            lock (lockObj) // Sử dụng lock để đồng bộ hoá việc thay đổi dữ liệu
                            {

                                string?[] model = item.Model45?.Split(',');
                                string?[] hashModel = model?.Distinct().ToArray();
                                //HashSet<string> hashModel = new HashSet<string>(model ?? Enumerable.Empty<string>());
                                string? resultModel = hashModel == null ? null : string.Join("+", hashModel);
                                string?[] merCode = item.MerCode47?.Split(',');
                                string?[] hashMerCode = merCode?.Distinct().ToArray();
                                //HashSet<string> hashMerCode = new HashSet<string>(merCode ?? Enumerable.Empty<string>());
                                string? resultMerCode = hashMerCode == null ? null : string.Join("+", hashMerCode);
                                excelWorksheet.Cells[(10 + j), 1].Value = j + 1;
                                excelWorksheet.Cells[(10 + j), 2].Value = item.Bc1;
                                excelWorksheet.Cells[(10 + j), 3].Value = item.PartNo8;
                                excelWorksheet.Cells[(10 + j), 3].Style.Font.Color.SetColor(System.Drawing.Color.Gray);
                                excelWorksheet.Cells[(10 + j), 4].Value = item.Bc12;
                                excelWorksheet.Cells[(10 + j), 5].Value = item.Ratio18;
                                excelWorksheet.Cells[(10 + j), 6].Value = resultModel;
                                excelWorksheet.Cells[(10 + j), 7].Value = resultMerCode;
                                excelWorksheet.Cells[(10 + j), 9].Value = item.Name20 == null ? "" : item.Name20;
                                excelWorksheet.Cells[(10 + j), 8].Value = item.EcnLevel4;
                                int len1 = item.Value48.Length;
                                for (int b = 1; b <= len1; b++)
                                {
                                    excelWorksheet.Cells[(10 + j), 10 + b].Value = item.Value48[b - 1];
                                    excelWorksheet.Cells[(10 + j), 10 + b].Style.Numberformat.Format = "0";
                                }
                                j = j + 1;
                            }

                        });
                        if (len > 0)
                        {
                            var cellsMer = excelWorksheet.Cells[7, 11, 9, len + 10].Style;
                            cellsMer.Fill.PatternType = ExcelFillStyle.Solid; ;
                            cellsMer.Fill.BackgroundColor.SetColor(Color.FromArgb(169, 208, 142));
                            cellsMer.WrapText = true;
                            for (int a = 1; a <= len; a++)
                            {
                                excelWorksheet.Cells[7, 10 + a].Value = headerActual.Model[a - 1] == null || headerActual.Model[a - 1] == "" ? null : headerActual.Model[a - 1].Split(":")[1];
                                excelWorksheet.Cells[8, 10 + a].Value = headerActual.Merchandise[a - 1] == null || headerActual.Merchandise[a - 1] == "" ? null : headerActual.Merchandise[a - 1].Split(":")[1];
                                excelWorksheet.Cells[9, 10 + a].Value = headerActual.MerCode[a - 1] == null || headerActual.MerCode[a - 1] == "" ? null : headerActual.MerCode[a - 1].Split(":")[1];
                            }
                            excelWorksheet.Cells[9, 9, 9, len + 10].Style.TextRotation = 90;
                        }
                        var cells1 = excelWorksheet.Cells[7, 10, 9, len + 10].Style;
                        cells1.Font.Size = 11;
                        cells1.Font.Name = "Calibri";
                        cells1.Border.Top.Style = ExcelBorderStyle.Thin;
                        cells1.Border.Bottom.Style = ExcelBorderStyle.Thin;
                        cells1.Border.Left.Style = ExcelBorderStyle.Thin;
                        cells1.Border.Right.Style = ExcelBorderStyle.Thin;

                        var cells2 = excelWorksheet.Cells[10, 1, j + 10, len + 10].Style;
                        cells2.Font.Size = 11;
                        cells2.Font.Name = "Calibri";
                        cells2.Border.Top.Style = ExcelBorderStyle.Thin;
                        cells2.Border.Bottom.Style = ExcelBorderStyle.Thin;
                        cells2.Border.Left.Style = ExcelBorderStyle.Thin;
                        cells2.Border.Right.Style = ExcelBorderStyle.Thin;
                        cells2.HorizontalAlignment = ExcelHorizontalAlignment.Left;

                        string outputPath = Path.Combine(pathServer, "FileOutPut\\OutPutChangingPointIJ", "Output_Changing_Point_IJ_" + DateTime.Now.ToString("yyyy-MM-dd-HHmmss") + ".xlsx");
                        FileInfo excelFile = new FileInfo(outputPath);
                        excelPackage.SaveAs(excelFile);
                        var lstMail = new List<string>();
                        lstMail = ctx.AdmUserInformations.Where(x => x.Active == true
                            && x.AdmDetailUserGroups.Any(y => y.Active == true
                            && y.GroupId == Guid.Parse("99f66340-7ab7-4dac-ac55-fa37bab404d7")))
                                .Include(x => x.AdmDetailUserGroups)
                                .Select(x => x.Email ?? "")
                                .ToList();
                        var link = "http://cvn-vpsi/#/turnoverday/structure/output-structure";
                        string content = "<p style='font-weight: bold;'>Dear [Mrs/Mr]. All,</p>";
                        content += "<p>The job of  calculation changing point  IJ is done.</p>";
                        content += "<p>Now you can check it at: " + link + "</p>";
                        new EmailService().Initial(lstMail, " Completed structure changing point IJ", content);
                    }


                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                }

            }

        }
        public async Task CalcUniquePartIJ()
        {
            //var redis = RedisConnectionManager.GetRedisConnection();
            //var database = redis.GetDatabase();

            using (var ctx = new PdcsystemContext())
            {
                var outputUnique = await ctx.TodStructureOutputUniqueIjs.Where(x => x.Active == true).ToListAsync();
                outputUnique.ForEach(x => x.Active = false);
                ctx.UpdateRange(outputUnique);
                ctx.SaveChanges();
                var headerActual = ctx.TodStructureOutputHeaders.Where(x => x.Active == true && x.Product == "IJ").FirstOrDefault();
                var dicIndexMerAct = headerActual.MerCode.ToList().Select(x => new { Key = x.Split(":")[1], Index = x.Split(":")[0] }).ToDictionary(x => x.Key, x => x.Index);

                try
                {
                    var model = ctx.TodStructureMasterUniqueParts.Where(x => x.Active == true && x.Product.ToUpper().Contains("IJ")).ToList().OrderBy(x => x.Kind).ToList();
                    var group1 = model.Where(x => x.Kind == model.DistinctBy(y => y.Kind).ToList().FirstOrDefault().Kind).ToList();
                    var group2 = model.Where(x => x.Kind != model.DistinctBy(y => y.Kind).ToList().FirstOrDefault().Kind).ToList();
                    var output = ctx.TodStructureOutputContentIjs.Where(x => x.Active == true).ToList();
                    List<TodStructureOutputUniqueIj> lstAdd = new List<TodStructureOutputUniqueIj>();
                    foreach (var mer1 in group1)
                    {
                        var listCheck = output.Where(x => x.MerCode47 != null && !x.MerCode47.Contains(mer1.Merchandise)).ToList();
                        if (!dicIndexMerAct.TryGetValue(mer1.Merchandise, out var indexMer1))
                        {
                            indexMer1 = null; // Giá trị mặc định nếu không tìm thấy 
                        }
                        if (indexMer1 != null)
                        {
                            foreach (var item in listCheck)
                            {
                                var usageMer1 = item.Value48[int.Parse(indexMer1)];
                                if (usageMer1 == "")
                                {

                                    foreach (var gr2 in group2)
                                    {

                                        if (item.MerCode47.Contains(gr2.Merchandise))
                                        {
                                            //var indexMer2 = dicIndexMerAct[gr2.Merchandise]; 
                                            if (!dicIndexMerAct.TryGetValue(gr2.Merchandise, out var indexMer2))
                                            {
                                                indexMer2 = null; // Giá trị mặc định nếu không tìm thấy 
                                            }
                                            if (indexMer2 != null)
                                            {
                                                var usageMer2 = item.Value48[int.Parse(indexMer2)];
                                                if (usageMer2 != "" && usageMer2 != "0")
                                                {
                                                    lstAdd.Add(new TodStructureOutputUniqueIj
                                                    {
                                                        Kind = gr2.Kind,
                                                        Merchandise = gr2.Merchandise,
                                                        Bc1 = item.Bc1,
                                                        PartNo8 = item.PartNo8,
                                                        PartName9 = item.PartName11,
                                                        Bc12 = item.Bc12,
                                                        Name20 = item.Name20,
                                                        LdDo = item.DoPic43,
                                                        LdPo = item.PoPic44
                                                    });

                                                }
                                            }

                                        }
                                    }
                                }

                            }
                        }
                    }

                    foreach (var mer2 in group2)
                    {
                        var listCheck2 = output.Where(x => x.MerCode47 != null && !x.MerCode47.Contains(mer2.Merchandise)).ToList();
                        // var indexMer2 = dicIndexMerAct[mer2.Merchandise];
                        if (!dicIndexMerAct.TryGetValue(mer2.Merchandise, out var indexMer2))
                        {
                            indexMer2 = null; // Giá trị mặc định nếu không tìm thấy 
                        }
                        if (indexMer2 != null)
                        {
                            foreach (var item in listCheck2)
                            {
                                var usageMer2 = item.Value48[int.Parse(indexMer2)];
                                if (usageMer2 == "")
                                {

                                    foreach (var gr1 in group1)
                                    {

                                        if (item.MerCode47.Contains(gr1.Merchandise))
                                        {
                                            //var indexMer1 = dicIndexMerAct[gr1.Merchandise];
                                            if (!dicIndexMerAct.TryGetValue(gr1.Merchandise, out var indexMer1))
                                            {
                                                indexMer1 = null; // Giá trị mặc định nếu không tìm thấy 
                                            }
                                            if (indexMer1 != null)
                                            {
                                                var usageMer1 = item.Value48[int.Parse(indexMer1)];
                                                if (usageMer1 != "" && usageMer1 != "0")
                                                {
                                                    lstAdd.Add(new TodStructureOutputUniqueIj
                                                    {
                                                        Kind = gr1.Kind,
                                                        Merchandise = gr1.Merchandise,
                                                        Bc1 = item.Bc1,
                                                        PartNo8 = item.PartNo8,
                                                        PartName9 = item.PartName11,
                                                        Bc12 = item.Bc12,
                                                        Name20 = item.Name20,
                                                        LdDo = item.DoPic43,
                                                        LdPo = item.PoPic44
                                                    });

                                                }
                                            }

                                        }
                                    }
                                }

                            }
                        }
                    }
                    lstAdd = lstAdd.DistinctBy(x => new { x.PartNo8, x.Merchandise }).ToList();
                    ctx.AddRange(lstAdd);
                    ctx.SaveChanges();
                    var lstMail = new List<string>();
                    lstMail = ctx.AdmUserInformations.Where(x => x.Active == true
                        && x.AdmDetailUserGroups.Any(y => y.Active == true
                        && y.GroupId == Guid.Parse("99f66340-7ab7-4dac-ac55-fa37bab404d7")))
                            .Include(x => x.AdmDetailUserGroups)
                            .Select(x => x.Email ?? "")
                            .ToList();
                    var link = "http://cvn-vpsi/#/turnoverday/structure/output-structure";
                    string content = "<p style='font-weight: bold;'>Dear [Mrs/Mr]. All,</p>";
                    content += "<p>The job of  calculation unique part IJ is done.</p>";
                    content += "<p>Now you can check it at: " + link + "</p>";
                    new EmailService().Initial(lstMail, " Completed structure unique part IJ", content);
                }
                catch (Exception ex)
                {
                    new EmailService().Initial(lstITMail, " Exception calculation unique part ij", ex.Message);
                }

            }

        }

        #endregion

        #region LBP
        public async Task AutoCheckAllLBP()
        {
            try
            {
                Task task1 = RefreshMvH1701();
                Task task2 = AutoCheckLBP_H1202();
                Task task3 = AutoCheckLBP_H3001();
                Task task4 = AutoCheckLBP_H501();
                Task task5 = AutoCheckLBP_H300();
                Task task6 = AutoCheckLBP_J1001();
                Task task7 = RefreshMvEcnLv2LBP();
                await Task.WhenAll(task1, task2, task3, task4, task5, task6, task7);
            }
            catch (Exception e)
            {
                new EmailService().Initial(lstITMail, " Faile get all view", e.Message);
            }
        }
        public async Task RefreshMvH1701()
        {

            try
            {
                string job0 = _jobClient.Enqueue(() => ADO.RefreshMaterializeViewWithContext("mv_euc_h1701"));
                _jobClient.ContinueJobWith(job0, () => ADO.RefreshMaterializeViewWithContext("mv_euc_h1701_co_main"));
                _jobClient.ContinueJobWith(job0, () => ADO.RefreshMaterializeViewWithContext("mv_euc_h1701_mer_usage"));
                _jobClient.ContinueJobWith(job0, () => ADO.RefreshMaterializeViewWithContext("mv_euc_h1701_merchandise"));
                _jobClient.ContinueJobWith(job0, () => ADO.RefreshMaterializeViewWithContext("mv_euc_h1701_mother"));
                _jobClient.ContinueJobWith(job0, () => ADO.RefreshMaterializeViewWithContext("mv_euc_h1701_part_legular"));
                _jobClient.ContinueJobWith(job0, () => ADO.RefreshMaterializeViewWithContext("mv_euc_h1701_total_mother"));
                await Task.Run(() => Console.WriteLine("Done H1701"));
            }
            catch (Exception e)
            {
                new EmailService().Initial(lstITMail, "Faile refresh mv euc1701 co main", e.Message);
            }
        }

        public async Task AutoCheckLBP_H1202()
        {

            try
            {
                _jobClient.Enqueue(() => ADO.RefreshMaterializeViewWithContext("mv_euc_h1202_lbp"));
                await Task.Run(() => Console.WriteLine("Done H1202"));

            }
            catch (Exception e)
            {
                new EmailService().Initial(lstITMail, " Faile get euch1202_lbp", e.Message);

            }
        }
        public async Task AutoCheckLBP_H3001()
        {

            try
            {
                _jobClient.Enqueue(() => ADO.RefreshMaterializeViewWithContext("mv_euc_h3001_lbp"));
                await Task.Run(() => Console.WriteLine("Done mv_euc_h3001_lbp"));

            }
            catch (Exception e)
            {
                new EmailService().Initial(lstITMail, " Faile get euch3001_lbp", e.Message);

            }
        }
        public async Task AutoCheckLBP_H501()
        {

            try
            {
                _jobClient.Enqueue(() => ADO.RefreshMaterializeViewWithContext("mv_euc_h501_lbp"));
                await Task.Run(() => Console.WriteLine("Done mv_euc_h501_lbp"));
            }
            catch (Exception e)
            {
                new EmailService().Initial(lstITMail, " Faile get euch501_lbp", e.Message);
            }
        }
        public async Task AutoCheckLBP_H300()
        {

            try
            {
                _jobClient.Enqueue(() => ADO.RefreshMaterializeViewWithContext("mv_euc_h300_lbp"));
                await Task.Run(() => Console.WriteLine("Done mv_euc_h300_lbp"));

            }
            catch (Exception e)
            {
                new EmailService().Initial(lstITMail, " Faile get euch300_lbp", e.Message);

            }
        }
        public async Task AutoCheckLBP_J1001()
        {

            try
            {
                _jobClient.Enqueue(() => ADO.RefreshMaterializeViewWithContext("mv_euc_j1001_lbp"));
                await Task.Run(() => Console.WriteLine("Done mv_euc_j1001_lbp"));

            }
            catch (Exception e)
            {
                new EmailService().Initial(lstITMail, " Faile get eucj1001_lbp", e.Message);

            }
        }
        public async Task RefreshMvEcnLv2LBP()
        {

            try
            {
                string job6 = _jobClient.Enqueue(() => ADO.RefreshMaterializeViewWithContext("mv_euc_ecn_lv2_lbp"));
                _jobClient.ContinueJobWith(job6, () => ADO.RefreshMaterializeViewWithContext("mv_euc_ecn_lv2_lbp_usage"));
                _jobClient.ContinueJobWith(job6, () => ADO.RefreshMaterializeViewWithContext("mv_euc_ecn_lv2_lbp_merchandise"));
                await Task.Run(() => Console.WriteLine("Done EcnLv2"));

            }
            catch (Exception e)
            {
                new EmailService().Initial(lstITMail, " Faile get ecn lv2 lbp", e.Message);

            }
        }   
        public async Task HeadersLBP()
        {
            //var redis = RedisConnectionManager.GetRedisConnection();
            //var database = redis.GetDatabase();
            using (var ctx = new PdcsystemContext())
            {

                var lstDtEntry = await ctx.MvEucH1701s.Select(x => x.DtEntry).Distinct().ToListAsync();
                try
                {
                    var ijMerchandise = ctx.TodStructureMasterMerchandises.Where(x => x.Active == true
                     && x.Model != null && x.DestName != null && x.Merchandise != null
                     && x.Product != null && x.Product.Equals("LBP") && x.ApprovedBy != null && x.ApprovedDate != null && x.Status == "Run").ToList()
                     .OrderBy(x => x.Bc).ThenBy(x => x.Model).ThenBy(x => x.Merchandise).GroupBy(x => new { x.Model, x.DestName, x.Merchandise }).Select(g => g.First());
                    if (ijMerchandise.Count() > 0)
                    {
                        var activeHeader = ctx.TodStructureOutputHeaders.Where(x => x.Active == true && x.Product.Equals("LBP")).ToList();
                        activeHeader.ForEach(x => x.Active = false);
                        ctx.TodStructureOutputHeaders.UpdateRange(activeHeader);
                        var arrModel45 = ijMerchandise.ToList().Select((x, index) => $"{index}:{x.Model ?? ""}").ToArray(); ;
                        var arrMerchandise46 = ijMerchandise.ToList().Select((x, index) => $"{index}:{x.DestName ?? ""}").ToArray();
                        var arrMercode47 = ijMerchandise.ToList().Select((x, index) => $"{index}:{x.Merchandise ?? ""}").ToArray();
                        var arrValue48 = ijMerchandise.Select(x => "").ToList();

                        lstDtEntry.ForEach(x =>
                        {
                            ctx.TodStructureOutputHeaders.Add(new TodStructureOutputHeader()
                            {
                                Active = true,
                                DateEntry = DateOnly.FromDateTime(DateTime.Parse(x)),
                                Merchandise = arrMerchandise46,
                                MerCode = arrMercode47,
                                Model = arrModel45,
                                Product = "LBP"
                            });
                            ctx.SaveChanges();
                        });

                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                }

            }

        }
        public async Task GetOutputLBP(bool saveDel)
        {
            var lstOut = new List<TodStructureOutputContentLbp>();
            using (var context = new PdcsystemContext())
            {
                try
                {
                    var mveucH1701 = context.MvEucH1701s.AsQueryable();
                    var lbpMerchandise = new List<TodStructureMasterMerchandise>();
                    lbpMerchandise = await context.TodStructureMasterMerchandises.Where(x => x.Active == true
                   && x.Model != null && x.DestName != null && x.Merchandise != null
                   && x.Product != null && x.Product.Equals("LBP") && x.ApprovedBy != null && x.ApprovedDate != null && x.Status == "Run")
                       .OrderBy(x => x.Model).ThenBy(x => x.Merchandise)
                       .ToListAsync();

                    //var lstMer = lbpMerchandise.Select(y => y.Merchandise + "_" + y.Bc).Distinct().ToList();
                    //var checkMerH1701 = await mveucH1701.Select(x => x.NoInParts + "_" + x.CdBlock).Distinct().ToListAsync();
                    //if (checkMerH1701.Count >= lstMer.Count)
                    //{
                    Console.WriteLine("Start: " + DateTime.Now);
                    string content = "<p style='font-weight: bold;'>Dear [Mrs/Mr]. All,</p>";
                    content += "<p>" + "Start calc at : " + DateTime.Now + "</p>";
                    var config = new MapperConfiguration(cfg =>
                    {
                        cfg.CreateMap<TodStructureOutputContentLbp, TodStructureOutputContentLbp>().ForMember(x => x.Id, opt => opt.Ignore());
                    });
                    var mapper = new Mapper(config);
                    var masterpacking = await context.TodStructureMasterPackings.Where(x => x.Active == true && x.ApprovedDate != null && x.ApprovedBy != null).AsNoTracking().ToListAsync();
                    var masterjob = await context.PcPaPartJobAssignments.Where(x => x.Active == true && x.ApprovalDate != null && x.ApprovalBy != null && x.Product.ToUpper() == "LBP").AsNoTracking().ToListAsync();
                    var masterdelivery = await context.TodStructureMasterDeliveries.Where(x => x.Active == true && x.ApprovedDate != null && x.ApprovedBy != null && x.Product.ToUpper() == "LBP").AsNoTracking().ToListAsync();
                    var lstBc = global.ReturnBlockCode();

                    var dictPacking = new ConcurrentDictionary<(string, string), (int, int, int, int)>();
                    foreach (var ip in masterpacking)
                    {
                        dictPacking.TryAdd((ip.PartNo, ip.Vendor), (ip.Moq ?? 0, ip.PcsBox ?? 0, ip.BoxPallet ?? 0, ip.PcsPallet ?? 0));
                    }
                    var dictAssignJob = new ConcurrentDictionary<(string, string), (string, string)>();
                    foreach (var ip in masterjob)
                    {
                        dictAssignJob.TryAdd((ip.PartNo, ip.Vendor), (ip.DoPic ?? "", ip.PicPo ?? ""));
                    }
                    var dictDelivery = new ConcurrentDictionary<string, string>();
                    foreach (var ip in masterdelivery)
                    {
                        dictDelivery.TryAdd(ip.VendorCode, $"{ip.MethodDelivery ?? ""}_{ip.Location1 ?? ""}_{ip.Location2 ?? ""}_{ip.Location3 ?? ""}_{ip.RouteDelivery ?? ""}_{ip.PartDelivMoving ?? ""}_{ip.DelivFreqDay ?? 0}_{ip.DelivFreqNight ?? 0}_{ip.DelivFreqWeek ?? 0}_{ip.Name ?? ""}");
                    }

                    var arrValue48 = new List<string>();


                    var header = await context.TodStructureOutputHeaders.Where(x => x.Active == true && x.Product.ToUpper().Contains("LBP")).AsNoTracking().FirstAsync();
                    arrValue48 = header.Merchandise.Select(x => "").ToList();
                    // var dicDateIndex = calendarActual.Select((item, index) => new { Key = item.DateOfDate, Value = index }).ToDictionary(x => x.Key, x => x.Value);
                    var dicIndexMer = header.MerCode.ToList().Select(x => new { Key = x.Split(":")[1], Index = x.Split(":")[0] }).ToDictionary(x => x.Key, x => x.Index);
                    var dicIndexModel = header.Model.ToList().Select(x => new { Key = x.Split(":")[0], Index = x.Split(":")[1] }).ToDictionary(x => x.Key, x => x.Index);
                    var dicIndexDes = header.Merchandise.ToList().Select(x => new { Key = x.Split(":")[0], Index = x.Split(":")[1] }).ToDictionary(x => x.Key, x => x.Index);


                    var euch1701 = await mveucH1701.GroupBy(x => new { x.CdBlock, x.NoChldParts, x.CdBlockH001, x.Ratio, x.CfChgStatClssH001, x.NoChldAdjDim }).Select(g => g.First()).ToListAsync();

                    if (saveDel == true)
                    {
                        context.Database.ExecuteSqlRaw("DELETE FROM public.tod_structure_output_content_lbp where active = true;");
                    }
                    else
                    {
                        ////tắt trigger
                        context.Database.ExecuteSqlRaw("ALTER TABLE public.tod_structure_output_content_lbp DISABLE TRIGGER ALL");
                        //xóa output
                        context.Database.ExecuteSqlRaw("DELETE FROM public.tod_structure_output_content_lbp where active = true;");
                        ////bật trigger
                        context.Database.ExecuteSqlRaw("ALTER TABLE public.tod_structure_output_content_lbp Enable TRIGGER ALL");

                    }
                    var euch1701CoMain = context.MvEucH1701CoMains.ToDictionary(x => x.CoKey, x => x.OrderNo);
                    var euch1701MerUsage = context.MvEucH1701MerUsages.ToDictionary(x => x.MerKey, x => x.Usage);
                    var euch1701Merchandise = context.MvEucH1701Merchandises.ToDictionary(x => x.MerKey, x => x.Merchandise);
                    var euch1701PartLegular = context.MvEucH1701PartLegulars.ToDictionary(x => x.PartsKey, x => x.NoLegular);
                    var euch1202 = await context.MvEucH1202Lbps.ToListAsync();
                    var dict1202 = new ConcurrentDictionary<(string, string), (string, string)>();
                    foreach (var ip in euch1202)
                    {
                        dict1202.TryAdd((ip.NoParts, ip.NoSubstitParts), (ip.DtBValid, ip.PtSubstit));
                    }
                    var euch3001 = await context.MvEucH3001Lbps.ToListAsync();
                    var dict3001 = new ConcurrentDictionary<string, string>();
                    foreach (var ip in euch3001)
                    {
                        dict3001.TryAdd(ip.NoParts, ip.PdDecimalLead);
                    }
                    var euch5001 = await context.MvEucH501Lbps.ToListAsync();
                    var dict5001 = new ConcurrentDictionary<(string, string), (string, string)>();
                    foreach (var ip in euch5001)
                    {
                        dict5001.TryAdd((ip.NoParts, ip.CdBlock), (ip.DtBValid, ip.PtRatio));
                    }
                    var euch300 = await context.MvEucH300Lbps.ToListAsync();
                    var dict300 = new ConcurrentDictionary<(string, string, string), (string, string)>();
                    foreach (var ip in euch300)
                    {
                        dict300.TryAdd((ip.NoParts, ip.CdBlock, ip.NoAdjDim), (ip.TmStoreLead, ip.PdProcess));
                    }
                    var eucj1001 = await context.MvEucJ1001Lbps.ToListAsync();
                    var dict1001 = new ConcurrentDictionary<(string, string), (string, string, string, string)>();
                    foreach (var ip in eucj1001)
                    {
                        dict1001.TryAdd((ip.NoParts, ip.CdSply), (ip.CdOrdClass, ip.QtDelvLot, ip.QtSnp, ip.PdPoIssue));
                    }

                    content += "<p>" + " Master Delivery: " + masterdelivery.Count + "</p>";
                    content += "<p>" + " Master Job Assign: " + masterjob.Count + "</p>";
                    content += "<p>" + " Master Merchandise: " + lbpMerchandise.Count + "</p>";
                    content += "<p>" + " Master Packing: " + masterpacking.Count + "</p>";
                    content += "<p>" + " EUCH1701: " + euch1701.Count + "</p>";
                    content += "<p>" + " EUC1202: " + euch1202.Count + "</p>";
                    content += "<p>" + " EUC501: " + euch5001.Count + "</p>";
                    content += "<p>" + " EUC1001: " + eucj1001.Count + "</p>";
                    content += "<p>" + " EUC300: " + euch300.Count + "</p>";
                    content += "<p>" + " EUC3001: " + euch3001.Count + "</p>";
                    List<TodStructureOutputContentLbp> batchRecords = new List<TodStructureOutputContentLbp>();
                    List<TodStructureOutputContentLbp> lstTemporary = new List<TodStructureOutputContentLbp>();
                    var i = 0;
                    batchRecords = euch1701.AsParallel().Select(item =>
                    {
                        var im = new TodStructureOutputContentLbp();

                            //////var iDel = masterdelivery.FirstOrDefault(x => x.VendorCode == item.CdBlockH001);
                            //////var iJob = masterjob.FirstOrDefault(x => x.PartNo == item.NoChldParts && x.Vendor == item.CdBlockH001);
                            //////var iPacking = masterpacking.FirstOrDefault(x => x.PartNo == item.NoChldParts && x.Vendor == item.CdBlockH001);
                            //////var i1202 = euch1202.FirstOrDefault(x => x.NoParts == item.NoMotherParts && x.NoSubstitParts == item.NoChldParts);
                            //////var i500 = euch5001.FirstOrDefault(x => x.NoParts == item.NoChldParts && x.CdBlock == item.CdBlockH001);
                            //////var i1001 = eucj1001.FirstOrDefault(x => x.NoParts == item.NoChldParts && x.CdSply == item.CdBlockH001);
                            //////var i3001 = euch3001.FirstOrDefault(x => x.NoParts == item.NoChldParts);
                            //////var i300 = euch300.FirstOrDefault(x => x.NoParts == item.NoChldParts && x.CdBlock == item.CdBlockH001 && x.NoAdjDim == item.NoChldAdjDim);
                        var dt_entry_only = item.DtEntry;


                        im.DtEntry0 = DateTime.Parse(item.DtEntry);
                        im.Bc1 = item.CdBlock;
                        im.CreatedDate = DateTime.Now;
                        im.EcnNo2 = item.NoChgNotificationH001;
                        im.OldEcnNo2 = item.NoChgNotificationH001;
                        im.EffectiveDate3 = item.DtBValidH001;
                        im.EcnLevel4 = item.CfChgStatClssH001;
                        if (dict5001.TryGetValue((item.NoChldParts, item.CdBlockH001), out var i500))
                        {
                            im.EffectiveDate5 = i500.Item1;
                            im.Ratio6 = i500.Item2;
                        }
                        else
                        {
                            if (dict1202.TryGetValue((item.NoMotherParts, item.NoChldParts), out var i1202))
                            {
                                im.EffectiveDate5 = i1202.Item1;
                                im.Ratio6 = i1202.Item2;
                            }
                        }
                        im.PartNo8 = item.NoChldParts;
                        im.Dim9 = item.NoChldAdjDim;
                        im.Pr10 = item.CdProcessH001;
                        im.PartName11 = item.NmPartsEng;
                        im.Bc12 = item.CdBlockH001;
                        im.Unit13 = item.CdPiece;
                        im.Factory17 = "";
                        im.Ratio18 = item.Ratio.ToString();
                        im.Comain22 = "";
                        im.Com23 = "";
                        if (dict3001.TryGetValue(item.NoChldParts, out var i3001))
                        {
                            im.DelAdjust42 = i3001;
                        }
                        im.Value48 = arrValue48.ToArray();

                        if (dictDelivery.TryGetValue(item.CdBlockH001, out var iDel))
                        {
                            string[] iDelVal = iDel.Split('_');
                            im.MethodDelivery24 = iDelVal[0];
                            im.Location125 = iDelVal[1];
                            im.Location226 = iDelVal[2];
                            im.Location327 = iDelVal[3];
                            im.RouteDelivery28 = iDelVal[4];
                            im.PartDelMoving29 = iDelVal[5];
                            im.Day30 = Convert.ToInt32(iDelVal[6]);
                            im.Night31 = Convert.ToInt32(iDelVal[7]);
                            im.Week32 = Convert.ToInt32(iDelVal[8]);
                            im.Name20 = iDelVal[9];
                        }
                        if (dict1001.TryGetValue((item.NoChldParts, item.CdBlockH001), out var i1001))
                        {
                            im.Type19 = i1001.Item1;
                            im.DelLot33 = i1001.Item2;
                            im.StdPacking34 = i1001.Item3;
                            im.Polt39 = i1001.Item4;
                        }
                        if (dictPacking.TryGetValue((item.NoChldParts, item.CdBlockH001), out var iPackVal))
                        {
                            im.Moq35 = iPackVal.Item1;
                            im.Pcsbox36 = iPackVal.Item2;
                            im.Boxpl37 = iPackVal.Item3;
                            im.Pcspl38 = iPackVal.Item4;
                        }
                        if (dict300.TryGetValue((item.NoChldParts, item.CdBlockH001, item.NoChldAdjDim), out var i300))
                        {
                            im.Storelt40 = i300.Item1;
                            im.Process41 = i300.Item2;
                        }
                        if (dictAssignJob.TryGetValue((item.NoChldParts, item.CdBlockH001), out var valJob))
                        {
                            im.DoPic43 = valJob.Item1;
                            im.PoPic44 = valJob.Item2;
                        }
                        im.Comain22 = null;
                        if (item.PtRatioH005.StringAbleToDouble() > 0 && item.PtRatioH005.StringAbleToDouble() < 100)
                        {
                            im.Comain22 = lstBc.Contains(item.CdBlockH001) ? "CO - Parallel" : "CO";
                        }
                        if (item.PtSubstitH003.StringAbleToDouble() <= 100)
                        {
                                // im.Comain22 = bodem++.ToString();
                            if (!string.IsNullOrEmpty(item.NoLegularPartsH003.Trim()))
                            {
                                if (euch1701PartLegular.TryGetValue(item.NoChldParts + "_" + item.CdBlock, out var nolegularpart))
                                {
                                    if (euch1701CoMain.TryGetValue(nolegularpart + "_" + item.CdBlock, out var key_comain))
                                    {
                                        string? coMain = key_comain == null ? null : key_comain.ToString();
                                        im.Comain22 = im.Comain22 == null ? coMain : im.Comain22 + "_" + coMain;
                                    }
                                }

                            }
                        }

                        string model45 = null, des46 = null, mer47 = null;
                            //đếm các mer để so sánh tìm ra des21
                        var count_mer = 0;
                        List<string> merchandiseList = new List<string>();
                        var ratio = item.Ratio;
                        if (euch1701Merchandise.TryGetValue(item.CdBlock + "_" + item.NoChldParts + "_" + item.CdBlockH001 + "_" + im.Ratio18 + "_" + item.CfChgStatClssH001 + "_" + im.Dim9, out var value))
                        {
                            if (!string.IsNullOrEmpty(value))
                            {
                                string[] merchandiseArray = value?.Split(new[] { ',' }, StringSplitOptions.RemoveEmptyEntries);
                                foreach (var mer in merchandiseArray)
                                {
                                    if (euch1701MerUsage.TryGetValue(item.CdBlock + "_" + item.NoChldParts + "_" + item.CdBlockH001 + "_" + mer + "_" + ratio + "_" + item.CfChgStatClssH001 + "_" + im.Dim9, out var key_usage))
                                    {
                                        if (key_usage != null)
                                        {
                                            var usage = key_usage;
                                            try
                                            {
                                                    // var eucValue = JsonConvert.DeserializeObject<LinkageEucIjH445>(euc445);
                                                    //////var index = dicIndexMer[mer];
                                                dicIndexMer.TryGetValue(mer, out var index);
                                                    // database.StringGet("ij_" +mer);
                                                var susage = usage == 0 ? "0" : usage.ToString();
                                                im.Value48[int.Parse(index)] = susage;
                                                if (usage > 0)
                                                {
                                                        //////var model = dicIndexModel[index];
                                                    dicIndexModel.TryGetValue(index, out var model);
                                                        //database.StringGet("model_" + index.ToString());
                                                        //////var desname = dicIndexDes[index];
                                                    dicIndexDes.TryGetValue(index, out var desname);
                                                        //database.StringGet("desname_" + index.ToString());
                                                    model45 = model45 == null || model45 == "" ? model : model45 + "," + model;
                                                    des46 = des46 == null || des46 == "" ? desname : des46 + "," + desname;
                                                    mer47 = mer47 == null || mer47 == "" ? mer : mer47 + "," + mer;
                                                    count_mer++;
                                                }
                                            }
                                            catch
                                            {
                                                    //return im;
                                            }
                                        }
                                    }


                                }
                            }

                        }

                        im.Model45 = model45;
                        im.Merchandise46 = des46;
                        im.MerCode47 = mer47;

                            //check mer để tìm ra des21
                        var count_mer_from_model = lbpMerchandise.Where(x => model45 != null && model45.Split(",").Distinct().ToList().Contains(x.Model) && x.Bc == im.Bc1).Count();
                        if (count_mer >= count_mer_from_model)
                        {
                            im.Des21 = "Com";
                        }
                        else
                        {
                            im.Des21 = "Des";
                        }
                        i++;
                            //////Console.WriteLine(i);
                        return im;

                    }).ToList();



                    var masterTemp = context.TodStructureTemporaryConnects.Where(x => x.Active == true &&
                    lbpMerchandise.Select(y => y.Merchandise).ToList().Contains(x.Merchandise)
                    && x.EfffectiveFrom <= DateOnly.FromDateTime(DateTime.Now)
                    && x.EffectiveTo >= DateOnly.FromDateTime(DateTime.Now) && x.ApprovedBy != null).ToList();

                    foreach (var temp in masterTemp)
                    {
                        dicIndexMer.TryGetValue(temp.Merchandise, out var index);
                        dicIndexModel.TryGetValue(index, out var model);
                        dicIndexDes.TryGetValue(index, out var desname);
                        var checkPart = batchRecords.Any(x => x.PartNo8 == temp.PartNo && x.EcnLevel4 == temp.EcnLevel);
                        if (checkPart == true)
                        {
                            var checkexist = batchRecords.FirstOrDefault(x => x.PartNo8 == temp.PartNo && x.Bc12 == temp.Vendor && x.Bc1 == temp.Bc && x.Value48[int.Parse(index)] != "" && x.EcnLevel4 == temp.EcnLevel);
                            if (checkexist != null)
                            {
                                try
                                {

                                    var usage = temp.Usage;
                                    checkexist.Ratio18 = temp.Ratio.ToString();
                                    checkexist.EcnNo2 = temp.TempNo + (checkexist.EcnNo2.Contains("Temp") ? "+" + checkexist.EcnNo2 : null);
                                    var susage = usage == 0 ? "0" : usage.ToString();
                                    checkexist.Value48[int.Parse(index)] = susage;

                                    if (usage == 0)
                                    {
                                        int indexModel45 = checkexist.Model45.LastIndexOf(model.ToString());
                                        if (indexModel45 >= 0)
                                        {
                                            checkexist.Model45 = checkexist.Model45.Remove(indexModel45, model.ToString().Length);
                                        }
                                        int indexMer46 = checkexist.Merchandise46.LastIndexOf(desname.ToString());
                                        if (indexMer46 >= 0)
                                        {
                                            checkexist.Merchandise46 = checkexist.Merchandise46.Remove(indexMer46, desname.ToString().Length);
                                        }

                                        int indexMer47 = checkexist.MerCode47.LastIndexOf(temp.Merchandise);
                                        if (indexMer47 >= 0)
                                        {
                                            checkexist.MerCode47 = checkexist.MerCode47.Remove(indexMer47, temp.Merchandise.Length);
                                        }

                                    }
                                    else
                                    {
                                        checkexist.Model45 = checkexist.Model45 == null || checkexist.Model45 == "" ? model : checkexist.Model45 + "," + model;
                                        checkexist.Merchandise46 = checkexist.Merchandise46 == null || checkexist.Merchandise46 == "" ? desname : checkexist.Merchandise46 + "," + desname;
                                        checkexist.MerCode47 = checkexist.MerCode47 == null || checkexist.MerCode47 == "" ? temp.Merchandise : checkexist.MerCode47 + "," + temp.Merchandise;
                                    }
                                    var count_mer_from_model = lbpMerchandise.Where(x => checkexist.Model45 != null && checkexist.Model45.Split(",").Distinct().ToList().Contains(x.Model) && x.Bc == temp.Bc).Count();
                                    var count_value = checkexist.Value48.Where(x => x != "" && x != "0").Count();
                                    if (count_value >= count_mer_from_model)
                                    {
                                        checkexist.Des21 = "Com";
                                    }
                                    else
                                    {
                                        checkexist.Des21 = "Des";
                                    }

                                }
                                catch
                                {

                                    continue;
                                }
                            }
                            else
                            {
                                var im = batchRecords.FirstOrDefault(x => x.PartNo8 == temp.PartNo);
                                try
                                {
                                    var imCopy = mapper.Map<TodStructureOutputContentLbp, TodStructureOutputContentLbp>(im);

                                    var usage = temp.Usage;
                                    imCopy.Ratio18 = temp.Ratio.ToString();
                                    imCopy.EcnNo2 = temp.TempNo;
                                    imCopy.Bc12 = temp.Vendor;
                                    imCopy.Bc1 = temp.Bc;
                                    imCopy.EcnLevel4 = temp.EcnLevel;
                                    var susage = usage == 0 ? "0" : usage.ToString();
                                    imCopy.Value48 = arrValue48.ToArray();
                                    imCopy.Value48[int.Parse(index)] = susage;
                                    im.Comain22 = null;
                                    if (usage > 0)
                                    {
                                        imCopy.Model45 = model;
                                        imCopy.Merchandise46 = desname;
                                        imCopy.MerCode47 = temp.Merchandise;

                                    }
                                    else
                                    {
                                        imCopy.Model45 = null;
                                        imCopy.Merchandise46 = null;
                                        imCopy.MerCode47 = null;
                                    }

                                    imCopy.Des21 = "Des";
                                    var imCopyClone = mapper.Map<TodStructureOutputContentLbp, TodStructureOutputContentLbp>(imCopy);
                                    lstTemporary.Add(imCopyClone);
                                }
                                catch
                                {
                                }
                            }
                        }
                        else
                        {
                            var dt_entry = batchRecords.FirstOrDefault().DtEntry0;
                            //var iDel = masterdelivery.FirstOrDefault(x => x.VendorCode == temp.Vendor);
                            //var iJob = masterjob.FirstOrDefault(x => x.PartNo == temp.PartNo && x.Vendor == temp.Vendor);
                            //var iPacking = masterpacking.FirstOrDefault(x => x.PartNo == temp.PartNo && x.Vendor == temp.Vendor);
                            //var i1001 = GetDeserializedObject<LinkageEucIjJ1001>("euc1001", $"{temp.PartNo}_{temp.Vendor}");
                            //// var i300 = GetDeserializedObject<LinkageEucIjH300>("euc300", $"{temp.PartNo}_{temp.Vendor}");
                            //var i3001 = GetDeserializedObject<LinkageEucIjH3001>("euc3001", temp.PartNo);

                            //////var i1001 = eucj1001.FirstOrDefault(x => x.NoParts == temp.PartNo && x.CdSply == temp.Vendor);
                            ////var i3001 = euch3001.FirstOrDefault(x => x.NoParts == temp.PartNo);


                            var im = new TodStructureOutputContentLbp()
                            {
                                DtEntry0 = dt_entry,
                                Bc1 = temp.Bc,
                                CreatedDate = DateTime.Now,
                                EcnNo2 = temp.TempNo,
                                OldEcnNo2 = temp.TempNo,
                                EffectiveDate3 = temp.EfffectiveFrom.ToString(),
                                EcnLevel4 = temp.EcnLevel,
                                PartNo8 = temp.PartNo,
                                PartName11 = temp.PartName,
                                Bc12 = temp.Vendor,
                                Ratio18 = temp.Ratio.ToString(),
                                ////DelAdjust42 = i3001?.PdDecimalLead.StringAbleToDouble().ToString() ?? "",
                                Value48 = arrValue48.ToArray()
                            };
                            if (dictDelivery.TryGetValue(temp.Vendor, out var iDel))
                            {
                                string[] iDelVal = iDel.Split('_');
                                im.MethodDelivery24 = iDelVal[0];
                                im.Location125 = iDelVal[1];
                                im.Location226 = iDelVal[2];
                                im.Location327 = iDelVal[3];
                                im.RouteDelivery28 = iDelVal[4];
                                im.PartDelMoving29 = iDelVal[5];
                                im.Day30 = Convert.ToInt32(iDelVal[6]);
                                im.Night31 = Convert.ToInt32(iDelVal[7]);
                                im.Week32 = Convert.ToInt32(iDelVal[8]);
                                im.Name20 = iDelVal[9];
                            }
                            if (dictPacking.TryGetValue((temp.PartNo, temp.Vendor), out var iPackVal))
                            {
                                im.Moq35 = iPackVal.Item1;
                                im.Pcsbox36 = iPackVal.Item2;
                                im.Boxpl37 = iPackVal.Item3;
                                im.Pcspl38 = iPackVal.Item4;
                            }
                            if (dictAssignJob.TryGetValue((temp.PartNo, temp.Vendor), out var valJob))
                            {
                                im.DoPic43 = valJob.Item1;
                                im.PoPic44 = valJob.Item2;
                            }

                            if (dict1001.TryGetValue((temp.PartNo, temp.Vendor), out var i1001))
                            {
                                im.Type19 = i1001.Item1;
                                im.DelLot33 = i1001.Item2;
                                im.StdPacking34 = i1001.Item3;
                                im.Polt39 = i1001.Item4;
                            }
                            if (dict3001.TryGetValue(temp.PartNo, out var i3001))
                            {
                                im.DelAdjust42 = i3001;
                            }


                            var usage = temp.Usage;
                            var susage = usage == 0 ? "0" : usage.ToString();
                            im.Value48[int.Parse(index)] = susage;

                            if (usage > 0)
                            {
                                im.Model45 = model;
                                im.Merchandise46 = desname;
                                im.MerCode47 = temp.Merchandise;

                            }
                            else
                            {
                                im.Model45 = null;
                                im.Merchandise46 = null;
                                im.MerCode47 = null;
                            }
                            lstTemporary.Add(im);
                        }
                    }

                    var lstTemp = lstTemporary.Where(x => x.Merchandise46 != null && x.MerCode47 != null && x.Model45 != null).GroupBy(x => new { x.Bc12, x.PartNo8, x.Ratio18 }).Select(g => g.First()).ToList();

                    foreach (var item in lstTemp)
                    {

                        var existingItem = lstTemporary.DistinctBy(x => x.EcnNo2).Where(x => x.Bc12 == item.Bc12 && x.PartNo8 == item.PartNo8 && x.EcnNo2 != item.EcnNo2 && x.Ratio18 == item.Ratio18).ToList();
                        foreach (var item1 in existingItem)
                        {
                            for (int index = 0; index < item1.Value48.Length; index++)
                            {
                                if (item1.Value48[index] != "")
                                {
                                    item.Value48[index] = item1.Value48[index];

                                }
                            }
                            item.Model45 = item.Model45 + (item1.Model45 == null ? null : ("," + item1.Model45));
                            item.Merchandise46 = item.Merchandise46 + (item1.Merchandise46 == null ? null : ("," + item1.Merchandise46));
                            item.MerCode47 = item.MerCode47 + (item1.MerCode47 == null ? null : ("," + item1.MerCode47));
                            item.EcnNo2 = item.EcnNo2 + "," + item1.EcnNo2;

                            //var noAdjm = database.StringGet("euc445_noadjm_" + item.PartNo8 + "_" + item.Bc1 + "_" + item.Bc12 + "_" + item1.MerCode47);
                            //if (!string.IsNullOrEmpty(noAdjm))
                            //{
                            try
                            {
                                if (dict300.TryGetValue((item.PartNo8, item.Bc12, item.Dim9), out var i300))
                                {
                                    item.Storelt40 = i300.Item1;
                                    item.Process41 = i300.Item2;
                                }
                                //////var i300 = euch300.FirstOrDefault(x => x.NoParts == item.PartNo8 && x.CdBlock == item.Bc12 && x.NoAdjDim == item.Dim9);

                                //////// var i300 = GetDeserializedObject<LinkageEucIjH300>("euc300", $"{item.PartNo8}_{item.Bc12}_{item.Dim9.ToString()}");
                                //////if (i300 != null)
                                //////{
                                //////    item.Storelt40 = i300.TmStoreLead;
                                //////    item.Process41 = i300.PdProcess;
                                //////}
                            }
                            catch
                            {
                                continue;
                            }
                            //}
                        }
                        var imCopyClone = mapper.Map<TodStructureOutputContentLbp, TodStructureOutputContentLbp>(item);
                        ////var iDelC = masterdelivery.FirstOrDefault(x => x.VendorCode == imCopyClone.Bc12);
                        ////var iJobC = masterjob.FirstOrDefault(x => x.PartNo == imCopyClone.PartNo8 && x.Vendor == imCopyClone.Bc12);
                        ////var iPackingC = masterpacking.FirstOrDefault(x => x.PartNo == imCopyClone.PartNo8 && x.Vendor == imCopyClone.Bc12);
                        ////var i1001C = eucj1001.FirstOrDefault(x => x.NoParts == imCopyClone.PartNo8 && x.CdSply == imCopyClone.Bc12);
                        //GetDeserializedObject<LinkageEucIjJ1001>("euc1001", $"{imCopyClone.PartNo8}_{imCopyClone.Bc12}");
                        //var i300C = GetDeserializedObject<LinkageEucIjH300>("euc300", $"{imCopyClone.PartNo8}_{imCopyClone.Bc12}");
                        if (dictDelivery.TryGetValue(imCopyClone.Bc12, out var iDelC))
                        {
                            string[] iDelVal = iDelC.Split('_');
                            imCopyClone.MethodDelivery24 = iDelVal[0];
                            imCopyClone.Location125 = iDelVal[1];
                            imCopyClone.Location226 = iDelVal[2];
                            imCopyClone.Location327 = iDelVal[3];
                            imCopyClone.RouteDelivery28 = iDelVal[4];
                            imCopyClone.PartDelMoving29 = iDelVal[5];
                            imCopyClone.Day30 = Convert.ToInt32(iDelVal[6]);
                            imCopyClone.Night31 = Convert.ToInt32(iDelVal[7]);
                            imCopyClone.Week32 = Convert.ToInt32(iDelVal[8]);
                            imCopyClone.Name20 = iDelVal[9];
                        }
                        if (dict1001.TryGetValue((imCopyClone.PartNo8, imCopyClone.Bc12), out var i1001C))
                        {
                            imCopyClone.Type19 = i1001C.Item1;
                            imCopyClone.DelLot33 = i1001C.Item2;
                            imCopyClone.StdPacking34 = i1001C.Item3;
                            imCopyClone.Polt39 = i1001C.Item4;
                        }
                        if (dictPacking.TryGetValue((imCopyClone.PartNo8, imCopyClone.Bc12), out var iPackingC))
                        {
                            imCopyClone.Moq35 = iPackingC.Item1;
                            imCopyClone.Pcsbox36 = iPackingC.Item2;
                            imCopyClone.Boxpl37 = iPackingC.Item3;
                            imCopyClone.Pcspl38 = iPackingC.Item4;
                        }

                        //if (i300C != null)
                        //{
                        //    imCopyClone.Storelt40 = i300C.TmStoreLead;
                        //    imCopyClone.Process41 = i300C.PdProcess;
                        //}
                        if (dictAssignJob.TryGetValue((imCopyClone.PartNo8, imCopyClone.Bc12), out var iJobC))
                        {
                            imCopyClone.DoPic43 = iJobC.Item1;
                            imCopyClone.PoPic44 = iJobC.Item2;
                        }

                        var count_mer_from_model = lbpMerchandise.Where(x => imCopyClone.Model45 != null && imCopyClone.Model45.Split(",").Distinct().ToList().Contains(x.Model) && x.Bc == imCopyClone.Bc1).Count();
                        var count_value = imCopyClone.Value48.Where(x => x != "" && x != "0").Count();
                        if (count_value >= count_mer_from_model)
                        {
                            imCopyClone.Des21 = "Com";
                        }
                        else
                        {
                            imCopyClone.Des21 = "Des";
                        }


                        batchRecords.Add(imCopyClone);


                    }

                    //update với 2 cặp khác nhau cùng 1 part mà chỉ có số
                    var lstUpdateSameCoMain = batchRecords
                        .Where(record => record.Comain22 != null && record.Comain22.All(char.IsDigit)) // Lọc các bản ghi có part_no chỉ chứa chữ số
                        .GroupBy(record => new { record.PartNo8, record.Bc1 }) // Nhóm các bản ghi theo part_no
                        .Where(group => group.Select(record => record.Comain22).Distinct().Count() >= 2) // Lọc các nhóm có ít nhất 2 giá trị comain22 khác nhau
                        .Select(group => group.Key);

                    foreach (var itemUpdate in lstUpdateSameCoMain)
                    {

                        //var check = batchRecords.FirstOrDefault(x => x.PartNo8 == itemUpdate.PartNo8 && (x.Comain22 != null && x.Comain22 != ""));
                        //if (check != null)
                        //{
                        //    itemUpdate.Comain22 = check.Comain22;
                        //}
                        var check = batchRecords.Where(x => x.Comain22 != null && x.PartNo8 == itemUpdate.PartNo8 && x.Bc1 == itemUpdate.Bc1 && x.Comain22.All(char.IsDigit)).Select(y => y.Comain22).ToList();
                        var commonCo = check.FirstOrDefault();
                        var lstUpdateCo = batchRecords.Where(x => x.Comain22 != null && check.Any(y => y == x.Comain22.Split("_").Last())).ToList();
                        foreach (var item in lstUpdateCo)
                        {
                            item.Comain22 = commonCo;
                        }
                    }


                    //đánh lại cặp với những con part ratio = 100
                    var lstUpdate = batchRecords.Where(x => x.Comain22 == null || x.Comain22 == "").ToList();
                    foreach (var itemUpdate in lstUpdate)
                    {
                        var check = batchRecords.FirstOrDefault(x => x.PartNo8 == itemUpdate.PartNo8 && x.Bc1 == itemUpdate.Bc1 && (x.Comain22 != null && x.Comain22 != ""));
                        if (check != null)
                        {
                            itemUpdate.Comain22 = check.Comain22;
                        }
                    }

                    //check đánh cặp special 
                    //lấy ra tất cả các cặp chỉ là các số
                    var lstUpdateS = batchRecords.Where(x => x.Comain22 != null && x.Comain22 != ""
                    && int.TryParse(x.Comain22, out _)).ToList().GroupBy(x => new { x.Comain22, x.Bc1 }).Select(g => g.First()).ToList();
                    foreach (var itemUpdateS in lstUpdateS)
                    {
                        var check = batchRecords.Where(x => x.Bc1 == itemUpdateS.Bc1 && x.Comain22 != null && x.Comain22.Replace("_S", "").Split("_").Last() == itemUpdateS.Comain22.Replace("_S", "") && x.Model45 != null).ToList();
                        //nếu lớn hơn 1 mới phải check xem có special không
                        List<string> lstString = new List<string>();
                        if (check.Count > 1)
                        {
                            foreach (var itemCheck in check)
                            {
                                string?[] merCode = itemCheck.MerCode47?.Split(',')?.Distinct().ToArray();
                                string? resultMerCode = merCode == null ? null : string.Join(",", merCode);
                                lstString.Add(resultMerCode);
                            }

                        }
                        if (lstString.Count > 0)
                        {
                            bool result = CheckStrings(lstString);
                            if (result == false)
                            {
                                var update = batchRecords.Where(x => x.Comain22 != null && x.Comain22.Replace("_S", "").Split("_").Last() == itemUpdateS.Comain22.Replace("_S", "")).ToList();
                                foreach (var itemUpdate in update)
                                {
                                    itemUpdate.Comain22 = itemUpdate.Comain22.Replace("_S", "") + "_" + "S";
                                }

                            }
                        }

                    }


                    //đánh lại cặp với các cặp có CO hoặc là Co - Parallel lấy theo kí tự dài nhất
                    var lstUpdateLenght = batchRecords.Where(x => x.Comain22 != null && (x.Comain22.Contains("CO") || x.Comain22.Contains("Parallel"))).GroupBy(x => new { x.PartNo8, x.Bc1 }).Select(g => g.First()).ToList().ToList();
                    foreach (var itemUpdate in lstUpdateLenght)
                    {
                        //lấy ra các part giống nhau và cặp giống nhau
                        var lstSame = batchRecords.Where(x => (x.PartNo8 == itemUpdate.PartNo8 && x.Bc1 == itemUpdate.Bc1)
                        || (x.Comain22 != null && int.TryParse(x.Comain22.Replace("_S", "").Split("_").Last(), out _) && x.Comain22.Replace("_S", "").Split("_").Last() == itemUpdate.Comain22.Replace("_S", "").Split("_").Last())).ToList();
                        //lấy ra coMain có kí tự dài nhất
                        var checkMax = lstSame.MaxBy(x => x.Comain22.Length);
                        foreach (var update in lstSame)
                        {
                            update.Comain22 = checkMax.Comain22;
                        }

                    }

                    // Tắt tự động phát hiện thay đổi để tăng hiệu suất
                    context.ChangeTracker.AutoDetectChangesEnabled = false;

                    // Chia danh sách thành các phần nhỏ (ví dụ: 1000 bản ghi mỗi phần)
                    var batchS = 10000;
                    var batches = batchRecords.Select((item, index) => new { Item = item, Index = index })
                                        .GroupBy(x => x.Index / batchS)
                                        .Select(g => g.Select(x => x.Item).ToList());


                    foreach (var batch in batches)
                    {
                        using (var transaction = context.Database.BeginTransaction())
                        {
                            try
                            {
                                context.TodStructureOutputContentLbps.AddRange(batch);
                                context.SaveChanges();

                                transaction.Commit();
                            }
                            catch
                            {
                                transaction.Rollback();
                                throw;
                            }
                        }


                        // Xóa bộ đệm để tránh tràn bộ nhớ
                        context.ChangeTracker.Clear();
                    }


                    content += "<p>" + ("Finished calculate & saved ouput " + batchRecords.Count + " record at: ") + DateTime.Now + "</p>";

                    new EmailService().Initial(lstITMail, " Completed structure output LBP", content);
                    //}
                    //else
                    //{
                    //    new EmailService().Initial(lstPDCMail, " Warning get euch1701", "List merchandise from euch1701 less than master merchandise, not get data!");
                    //}
                }
                catch (Exception e)
                {
                    new EmailService().Initial(lstITMail, " exception calculation output LBP", e.Message);
                }
            }
        }
        public async Task GetOutputLBPALLExcel()
        {
            //var redis = RedisConnectionManager.GetRedisConnection();
            //var database = redis.GetDatabase();
            string product = "LBP";
            try
            {

                await SendMessageToClients($"Structure{product}_{date}", "Export output");
                database.StringSet($"RecMess{Factory}Structure{product}_" + date, "Export output");
                using (var context = new PdcsystemContext())
                {
                    var config = new MapperConfiguration(cfg =>
                    {
                        cfg.CreateMap<TodStructureOutputContentLbp, TodStructureOutputContentView>();
                    });

                    // Tạo mapper từ cấu hình
                    var mapper = new Mapper(config);
                    try
                    {
                        Console.WriteLine(DateTime.Now.ToLongTimeString() + " start export");
                        var header = await context.TodStructureOutputHeaders.AsNoTracking().Where(x => x.Active == true && x.Product == "LBP").FirstOrDefaultAsync();
                        ExcelPackage.LicenseContext = LicenseContext.NonCommercial;


                        string filePath = Path.Combine(pathServer, "FileOutPut\\OutputStructure.xlsx");
                        FileInfo file = new FileInfo(filePath);
                        using (ExcelPackage excelPackage = new ExcelPackage(file))
                        {

                            ExcelWorksheet excelWorksheet = excelPackage.Workbook.Worksheets.First();
                            excelWorksheet.Cells["G1"].Value = DateTime.Now.ToString("yyyy-MM-dd");
                            excelWorksheet.Cells["F1"].Value = "DT_ENTRY";
                            excelWorksheet.Cells["G2"].Value = "LBP";
                            excelWorksheet.Cells["F2"].Value = "Product";
                            var i = 0;
                            int len = 0;
                            var content_start = "start insert time " + DateTime.Now.ToLongTimeString();
                            len = header.Model == null ? 0 : header.Model.Length;
                            if (len > 0)
                            {
                                var cellsMer = excelWorksheet.Cells[7, 47, 9, len + 46].Style;
                                cellsMer.Fill.PatternType = ExcelFillStyle.Solid; ;
                                cellsMer.Fill.BackgroundColor.SetColor(Color.FromArgb(169, 208, 142));
                                cellsMer.WrapText = true;
                                for (int j = 1; j <= len; j++)
                                {
                                    excelWorksheet.Cells[7, 46 + j].Value = header.Model[j - 1].Split(":")[1];
                                    excelWorksheet.Cells[8, 46 + j].Value = header.Merchandise[j - 1].Split(":")[1];
                                    excelWorksheet.Cells[9, 46 + j].Value = header.MerCode[j - 1].Split(":")[1];
                                }
                                excelWorksheet.Cells[9, 46, 9, len + 46].Style.TextRotation = 90;
                            }
                            var hashEntries = context.TodStructureOutputContentLbps.Where(x => x.Active == true).ToList();
                            var lstModel = mapper.Map<List<TodStructureOutputContentLbp>, List<TodStructureOutputContentView>>(hashEntries);

                            foreach (var item1 in lstModel)
                            {
                                int currentRow = 10 + i;
                                var item = item1;
                                string?[] model = item.Model45?.Split(',');
                                string?[] hashModel = model?.Distinct().ToArray();
                                string? resultModel = hashModel == null ? null : string.Join("+", hashModel);

                                string?[] merdise = item.Merchandise46?.Split(',');
                                string?[] hashMer = merdise?.Distinct().ToArray();
                                string? resultMerDise = hashMer == null ? null : string.Join("+", hashMer);

                                string?[] merCode = item.MerCode47?.Split(',');
                                string?[] hashMerCode = merCode?.Distinct().ToArray();
                                string? resultMerCode = hashMerCode == null ? null : string.Join("+", hashMerCode);

                                excelWorksheet.Cells[currentRow, 1].Value = i + 1;
                                excelWorksheet.Cells[currentRow, 2].Value = item.Bc1;
                                excelWorksheet.Cells[currentRow, 3].Value = item.EcnNo2;
                                excelWorksheet.Cells[currentRow, 4].Value = item.EffectiveDate3;
                                excelWorksheet.Cells[currentRow, 5].Value = item.EcnLevel4;
                                excelWorksheet.Cells[currentRow, 6].Value = item.EffectiveDate5;
                                excelWorksheet.Cells[currentRow, 7].Value = item.Ratio6;
                                excelWorksheet.Cells[currentRow, 8].Value = item.PartnoBc7;
                                excelWorksheet.Cells[currentRow, 9].Value = item.PartNo8;
                                excelWorksheet.Cells[currentRow, 10].Value = item.Dim9;
                                excelWorksheet.Cells[currentRow, 11].Value = item.Pr10;
                                excelWorksheet.Cells[currentRow, 12].Value = item.PartName11;
                                excelWorksheet.Cells[currentRow, 13].Value = item.Bc12;
                                excelWorksheet.Cells[currentRow, 14].Value = item.Unit13;
                                excelWorksheet.Cells[currentRow, 15].Value = resultModel;
                                excelWorksheet.Cells[currentRow, 16].Value = resultMerDise;
                                excelWorksheet.Cells[currentRow, 17].Value = resultMerCode;
                                excelWorksheet.Cells[currentRow, 18].Value = item.Factory17;
                                excelWorksheet.Cells[currentRow, 19].Value = item.Ratio18.StringAbleToDouble();
                                excelWorksheet.Cells[currentRow, 20].Value = item.Type19;
                                excelWorksheet.Cells[currentRow, 21].Value = item.Name20;
                                excelWorksheet.Cells[currentRow, 22].Value = item.Des21;
                                excelWorksheet.Cells[currentRow, 23].Value = item.Comain22;
                                excelWorksheet.Cells[currentRow, 24].Value = item.Com23;
                                excelWorksheet.Cells[currentRow, 25].Value = item.MethodDelivery24;
                                excelWorksheet.Cells[currentRow, 26].Value = item.Location125;
                                excelWorksheet.Cells[currentRow, 27].Value = item.Location226;
                                excelWorksheet.Cells[currentRow, 28].Value = item.Location327;
                                excelWorksheet.Cells[currentRow, 29].Value = item.RouteDelivery28;
                                excelWorksheet.Cells[currentRow, 30].Value = item.PartDelMoving29;
                                excelWorksheet.Cells[currentRow, 31].Value = item.Day30;
                                excelWorksheet.Cells[currentRow, 32].Value = item.Night31;
                                excelWorksheet.Cells[currentRow, 33].Value = item.Week32;
                                excelWorksheet.Cells[currentRow, 34].Value = item.DelLot33;
                                excelWorksheet.Cells[currentRow, 35].Value = item.StdPacking34;
                                excelWorksheet.Cells[currentRow, 36].Value = item.Moq35;
                                excelWorksheet.Cells[currentRow, 37].Value = item.Pcsbox36;
                                excelWorksheet.Cells[currentRow, 38].Value = item.Boxpl37;
                                excelWorksheet.Cells[currentRow, 39].Value = item.Pcspl38;
                                excelWorksheet.Cells[currentRow, 40].Value = item.Polt39;
                                excelWorksheet.Cells[currentRow, 41].Value = item.Storelt40;
                                excelWorksheet.Cells[currentRow, 42].Value = item.Process41;
                                excelWorksheet.Cells[currentRow, 43].Value = item.DelAdjust42;
                                excelWorksheet.Cells[currentRow, 44].Value = item.DoPic43;
                                excelWorksheet.Cells[currentRow, 45].Value = item.PoPic44;

                                if (item.Value48 != null && item.Value48.Length > 0)
                                {
                                    int len1 = item.Value48 == null ? 0 : item.Value48.Length;
                                    if (len1 > 0)
                                    {
                                        for (int j = 1; j <= len1; j++)
                                        {

                                            excelWorksheet.Cells[currentRow, 46 + j].Value = item.Value48[j - 1] == "" ? "" : item.Value48[j - 1].StringAbleToDouble();
                                            //excelWorksheet.Cells[currentRow, 46 + j].Style.Numberformat.Format = "0";
                                        }
                                    }
                                }
                                i++;
                            }
                            var cells1 = excelWorksheet.Cells[7, 47, 9, len + 46].Style;
                            cells1.Font.Size = 11;
                            cells1.Font.Name = "Calibri";
                            cells1.Border.Top.Style = ExcelBorderStyle.Thin;
                            cells1.Border.Bottom.Style = ExcelBorderStyle.Thin;
                            cells1.Border.Left.Style = ExcelBorderStyle.Thin;
                            cells1.Border.Right.Style = ExcelBorderStyle.Thin;

                            var cells2 = excelWorksheet.Cells[10, 1, hashEntries.Count + 10, len + 46].Style;
                            cells2.Font.Size = 11;
                            cells2.Font.Name = "Calibri";
                            cells2.Border.Top.Style = ExcelBorderStyle.Thin;
                            cells2.Border.Bottom.Style = ExcelBorderStyle.Thin;
                            cells2.Border.Left.Style = ExcelBorderStyle.Thin;
                            cells2.Border.Right.Style = ExcelBorderStyle.Thin;
                            cells2.HorizontalAlignment = ExcelHorizontalAlignment.Left;

                            Console.WriteLine(content_start);
                            Console.WriteLine(DateTime.Now.ToLongTimeString() + " ended export");

                            string outputPath = Path.Combine(pathServer, "FileOutput\\OutPutStructureLBP", "Output_ALL_LBP_" + DateTime.Now.ToString("yyyy-MM-dd") + ".xlsx");
                            FileInfo excelFile = new FileInfo(outputPath);
                            excelPackage.SaveAs(excelFile);
                            await SendMessageToClients($"Structure{product}_{date}", "Finished");
                            database.StringSet($"RecMess{Factory}Structure{product}_" + date, "Finished");
                        }

                    }
                    catch (Exception e)
                    {
                        await SendMessageToClients($"Structure{product}_{date}", "Except export");
                        database.StringSet($"RecMess{Factory}Structure{product}_" + date, "Except export");
                        Console.WriteLine("Except " + e);
                    }
                }
            }
            catch (Exception)
            {

            }

        }
        public async Task UpdateMasterDeliveryLBP()
        {

            using (var ctx = new PdcsystemContext())
            {

                try
                {
                    var delivery = await ctx.TodStructureMasterDeliveries.Where(x => x.Active == true && x.ApprovedBy != null && x.Product != null && x.Product.ToUpper().Contains("LBP")).ToListAsync();
                    var outputLBP = ctx.TodStructureOutputContentLbps.AsNoTracking().Where(x => x.Active == true).ToList();
                    List<TodStructureMasterDelivery> lstUpdate = new List<TodStructureMasterDelivery>();
                    foreach (var item in delivery)
                    {
                        var totalPart = outputLBP.Where(x => x.Bc12 == item.VendorCode && x.Ratio18.StringToIntAble() > 0).Count();
                        item.TotalPartOrder = totalPart;
                        lstUpdate.Add(item);
                    }
                    ctx.UpdateRange(lstUpdate);
                    ctx.SaveChanges();
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                }

            }

        }
        public async Task CalcChangingPointLBP()
        {

            using (var ctx = new PdcsystemContext())
            {

                ExcelPackage.LicenseContext = LicenseContext.NonCommercial;

                try
                {
                    string filePath = Path.Combine(pathServer, "FileOutPut\\OutputChangingPoint.xlsx");
                    FileInfo file = new FileInfo(filePath);
                    using (ExcelPackage excelPackage = new ExcelPackage(file))
                    {

                        ExcelWorksheet excelWorksheet = excelPackage.Workbook.Worksheets.First();
                        excelWorksheet.Cells["G1"].Value = DateTime.Now.ToString("yyyy-MM-dd");
                        excelWorksheet.Cells["F1"].Value = "DT_ENTRY";
                        excelWorksheet.Cells["G2"].Value = "LBP";
                        excelWorksheet.Cells["F2"].Value = "Product";
                        var j = 0;


                        var output = await ctx.TodStructureOutputContentLbps.Where(x => x.Active == true).ToListAsync();
                        var latestDateOutPut = ctx.HistoryTodStructureOutputContentLbps.Where(x => x.Active == true).Max(x => x.DtEntry0);
                        var latestDateHistory = ctx.HistoryTodStructureOutputContentLbps.Where(x => x.Active == true).Max(x => x.HistoryDate.Value.Date);
                        var outputHistory = ctx.HistoryTodStructureOutputContentLbps.Where(x => x.HistoryDate.Value.Date == latestDateHistory).OrderByDescending(x => x.HistoryDate).ToList();


                        var checkDt_entry = ctx.TodStructureOutputHeaders.Where(x => x.Active == false && x.Product == "LBP" && x.DateEntry == DateOnly.FromDateTime((DateTime)latestDateOutPut)).ToList();
                        var lastesHeader = checkDt_entry.Count() != 0 ? checkDt_entry.Max(x => x.DateEntry) : DateOnly.FromDateTime((DateTime)output.Max(x => x.DtEntry0));
                        var header = ctx.TodStructureOutputHeaders.Where(x => x.Active == false && x.Product == "LBP" && x.DateEntry == lastesHeader).OrderByDescending(x => x.CreatedDate).FirstOrDefault();
                        var headerActual = ctx.TodStructureOutputHeaders.Where(x => x.Active == true && x.Product == "LBP").FirstOrDefault();
                        string[] lismerH = new string[header.MerCode.Length];
                        int len = headerActual.Merchandise.Length;

                        for (int i = 0; i < header.MerCode.Length; i++)
                        {
                            int index = header.MerCode[i].IndexOf(":");
                            lismerH[i] = header.MerCode[i].Substring(index + 1);
                        }
                        var dicIndexMerAct = headerActual.MerCode.ToList().Select(x => new { Key = x.Split(":")[1], Index = x.Split(":")[0] }).ToDictionary(x => x.Key, x => x.Index);


                        //change usage
                        output.AsParallel().ForAll(item =>
                        {

                            lock (lockObj) // Sử dụng lock để đồng bộ hoá việc thay đổi dữ liệu
                            {
                                int currentRow = 10 + j;
                                var arr48 = new List<string>();
                                arr48 = item.Value48.Select(x => "").ToList();
                                var checkHistory = outputHistory.FirstOrDefault(x => x.Bc1 == item.Bc1 && x.EcnLevel4 == item.EcnLevel4 &&
                                x.PartNo8 == item.PartNo8 && x.Bc12 == item.Bc12 && x.Ratio18 == item.Ratio18
                                && (!x.EcnNo2.Contains("Temp") ? (x.EcnNo2 == item.EcnNo2) : (x.EcnNo2.Split(",").Any(y => item.EcnNo2.Contains(y))
                                || x.EcnNo2.Split("+").Any(y => item.EcnNo2.Contains(y)))));

                                if (checkHistory != null)
                                {

                                    if (item.MerCode47 != null && checkHistory.MerCode47 != null)
                                    {
                                        foreach (var mer in item.MerCode47.Split(","))
                                        {
                                            int indexHistory = Array.IndexOf(lismerH, mer);
                                            if (indexHistory >= 0)
                                            {
                                                var indexActual = int.Parse(dicIndexMerAct[mer]);
                                                var valueActual = item.Value48[(int)indexActual] == "" ? "0" : item.Value48[(int)indexActual];

                                                try
                                                {
                                                    var valueH = checkHistory.Value48[indexHistory];
                                                    if (valueH != valueActual)
                                                    {
                                                        arr48[(int)indexActual] = valueActual;
                                                    }
                                                }
                                                catch
                                                {

                                                    arr48[(int)indexActual] = valueActual;
                                                }
                                            }
                                        }
                                    }
                                    if (item.MerCode47 == null && checkHistory.MerCode47 != null)
                                    {
                                        arr48 = item.Value48.ToList();
                                    }
                                }
                                var checkArr48 = arr48.Any(x => !x.Equals(""));

                                if (checkArr48 == true)
                                {
                                    string?[] model = item.Model45?.Split(',');
                                    string?[] hashModel = model?.Distinct().ToArray();
                                    //HashSet<string> hashModel = new HashSet<string>(model ?? Enumerable.Empty<string>());
                                    string? resultModel = hashModel == null ? null : string.Join("+", hashModel);
                                    string?[] merCode = item.MerCode47?.Split(',');
                                    string?[] hashMerCode = merCode?.Distinct().ToArray();
                                    //HashSet<string> hashMerCode = new HashSet<string>(merCode ?? Enumerable.Empty<string>());
                                    string? resultMerCode = hashMerCode == null ? null : string.Join("+", hashMerCode);
                                    excelWorksheet.Cells[currentRow, 1].Value = j + 1;
                                    excelWorksheet.Cells[currentRow, 2].Value = item.Bc1;
                                    excelWorksheet.Cells[currentRow, 3].Value = item.PartNo8;
                                    excelWorksheet.Cells[currentRow, 4].Value = item.Bc12;
                                    excelWorksheet.Cells[currentRow, 5].Value = item.Ratio18;
                                    excelWorksheet.Cells[currentRow, 6].Value = resultModel;
                                    excelWorksheet.Cells[currentRow, 7].Value = resultMerCode;
                                    excelWorksheet.Cells[currentRow, 9].Value = item.Name20 == null ? "" : item.Name20;
                                    excelWorksheet.Cells[currentRow, 8].Value = item.EcnLevel4;
                                    int len1 = item.Value48.Length;

                                    for (int b = 1; b <= len1; b++)
                                    {
                                        excelWorksheet.Cells[currentRow, 10 + b].Value = arr48[b - 1];
                                        excelWorksheet.Cells[currentRow, 10 + b].Style.Numberformat.Format = "0";
                                        excelWorksheet.Cells[currentRow, 10 + b].Style.Font.Color.SetColor(System.Drawing.Color.Red);
                                    }
                                    j++;
                                }
                                if (checkHistory == null)
                                {
                                    string?[] model = item.Model45?.Split(',');
                                    string?[] hashModel = model?.Distinct().ToArray();
                                    //HashSet<string> hashModel = new HashSet<string>(model ?? Enumerable.Empty<string>());
                                    string? resultModel = hashModel == null ? null : string.Join("+", hashModel);
                                    string?[] merCode = item.MerCode47?.Split(',');
                                    string?[] hashMerCode = merCode?.Distinct().ToArray();
                                    //HashSet<string> hashMerCode = new HashSet<string>(merCode ?? Enumerable.Empty<string>());
                                    string? resultMerCode = hashMerCode == null ? null : string.Join("+", hashMerCode);
                                    excelWorksheet.Cells[currentRow, 1].Value = j + 1;
                                    excelWorksheet.Cells[currentRow, 2].Value = item.Bc1;
                                    excelWorksheet.Cells[currentRow, 3].Value = item.PartNo8;
                                    excelWorksheet.Cells[currentRow, 3].Style.Font.Color.SetColor(System.Drawing.Color.Purple);
                                    excelWorksheet.Cells[currentRow, 4].Value = item.Bc12;
                                    excelWorksheet.Cells[currentRow, 5].Value = item.Ratio18;
                                    //excelWorksheet.Cells[(10 + j), 5].Style.Font.Color.SetColor(System.Drawing.Color.Red);
                                    excelWorksheet.Cells[currentRow, 6].Value = resultModel;
                                    excelWorksheet.Cells[currentRow, 7].Value = resultMerCode;
                                    excelWorksheet.Cells[currentRow, 9].Value = item.Name20 == null ? "" : item.Name20;
                                    excelWorksheet.Cells[currentRow, 8].Value = item.EcnLevel4;
                                    int len1 = item.Value48.Length;
                                    for (int b = 1; b <= len1; b++)
                                    {
                                        excelWorksheet.Cells[currentRow, 10 + b].Value = item.Value48[b - 1];
                                    }
                                    j++;
                                }

                            }
                        });

                        //change ratio
                        output.GroupBy(x => new { x.PartNo8, x.Bc1, x.Bc12, x.EcnLevel4 }).Select(g => g.First()).ToList().ToList().AsParallel().ForAll(item =>
                        {

                            lock (lockObj) // Sử dụng lock để đồng bộ hoá việc thay đổi dữ liệu
                            {

                                var lstRatio = output.Where(x => x.PartNo8 == item.PartNo8 && x.Bc1 == item.Bc1 && x.Bc12 == item.Bc12 && x.EcnLevel4 == item.EcnLevel4).Select(y => y.Ratio18).ToList();
                                var lstRatioH = outputHistory.Where(x => x.PartNo8 == item.PartNo8 && x.Bc1 == item.Bc1 && x.Bc12 == item.Bc12 && x.EcnLevel4 == item.EcnLevel4).Select(y => y.Ratio18).ToList();

                                var differentElements = lstRatio.Except(lstRatioH);
                                foreach (var difference in differentElements)
                                {
                                    string?[] model = item.Model45?.Split(',');
                                    string?[] hashModel = model?.Distinct().ToArray();
                                    //HashSet<string> hashModel = new HashSet<string>(model ?? Enumerable.Empty<string>());
                                    string? resultModel = hashModel == null ? null : string.Join("+", hashModel);
                                    string?[] merCode = item.MerCode47?.Split(',');
                                    string?[] hashMerCode = merCode?.Distinct().ToArray();
                                    //HashSet<string> hashMerCode = new HashSet<string>(merCode ?? Enumerable.Empty<string>());
                                    string? resultMerCode = hashMerCode == null ? null : string.Join("+", hashMerCode);
                                    excelWorksheet.Cells[(10 + j), 1].Value = j + 1;
                                    excelWorksheet.Cells[(10 + j), 2].Value = item.Bc1;
                                    excelWorksheet.Cells[(10 + j), 3].Value = item.PartNo8;
                                    excelWorksheet.Cells[(10 + j), 4].Value = item.Bc12;
                                    excelWorksheet.Cells[(10 + j), 5].Value = difference;
                                    excelWorksheet.Cells[(10 + j), 5].Style.Font.Color.SetColor(System.Drawing.Color.Red);
                                    excelWorksheet.Cells[(10 + j), 6].Value = resultModel;
                                    excelWorksheet.Cells[(10 + j), 7].Value = resultMerCode;
                                    excelWorksheet.Cells[(10 + j), 9].Value = item.Name20 == null ? "" : item.Name20;
                                    excelWorksheet.Cells[(10 + j), 8].Value = item.EcnLevel4;
                                    int len1 = item.Value48.Length;
                                    for (int b = 1; b <= len1; b++)
                                    {
                                        excelWorksheet.Cells[(10 + j), 10 + b].Value = item.Value48[b - 1];
                                        excelWorksheet.Cells[(10 + j), 10 + b].Style.Numberformat.Format = "0";
                                    }
                                    j = j + 1;
                                }

                            }

                        });

                        //today have, yesterday not have
                        var outputToday = output.Where(x => !outputHistory.Any(y => y.PartNo8 == x.PartNo8 && y.Bc1 == x.Bc1 && y.Bc12 == x.Bc12 && x.EcnLevel4 == y.EcnLevel4)).ToList();
                        outputToday.AsParallel().ForAll(item =>
                        {
                            lock (lockObj) // Sử dụng lock để đồng bộ hoá việc thay đổi dữ liệu
                            {
                                string?[] model = item.Model45?.Split(',');
                                string?[] hashModel = model?.Distinct().ToArray();
                                //HashSet<string> hashModel = new HashSet<string>(model ?? Enumerable.Empty<string>());
                                string? resultModel = hashModel == null ? null : string.Join("+", hashModel);
                                string?[] merCode = item.MerCode47?.Split(',');
                                string?[] hashMerCode = merCode?.Distinct().ToArray();
                                //HashSet<string> hashMerCode = new HashSet<string>(merCode ?? Enumerable.Empty<string>());
                                string? resultMerCode = hashMerCode == null ? null : string.Join("+", hashMerCode);
                                excelWorksheet.Cells[(10 + j), 1].Value = j + 1;
                                excelWorksheet.Cells[(10 + j), 2].Value = item.Bc1;
                                excelWorksheet.Cells[(10 + j), 3].Value = item.PartNo8;
                                excelWorksheet.Cells[(10 + j), 3].Style.Font.Color.SetColor(System.Drawing.Color.Green);
                                excelWorksheet.Cells[(10 + j), 4].Value = item.Bc12;
                                excelWorksheet.Cells[(10 + j), 5].Value = item.Ratio18;
                                excelWorksheet.Cells[(10 + j), 6].Value = resultModel;
                                excelWorksheet.Cells[(10 + j), 7].Value = resultMerCode;
                                excelWorksheet.Cells[(10 + j), 9].Value = item.Name20 == null ? "" : item.Name20;
                                excelWorksheet.Cells[(10 + j), 8].Value = item.EcnLevel4;
                                int len1 = item.Value48.Length;
                                for (int b = 1; b <= len1; b++)
                                {
                                    excelWorksheet.Cells[(10 + j), 10 + b].Value = item.Value48[b - 1];
                                    excelWorksheet.Cells[(10 + j), 10 + b].Style.Numberformat.Format = "0";
                                }
                                j = j + 1;
                            }

                        });


                        //yesterday have, today not have
                        var outputYesterday = outputHistory.Where(x => !output.Any(y => y.PartNo8 == x.PartNo8 && y.Bc1 == x.Bc1 && y.Bc12 == x.Bc12 && x.EcnLevel4 == y.EcnLevel4)).ToList();
                        outputYesterday.AsParallel().ForAll(item =>
                        {
                            lock (lockObj) // Sử dụng lock để đồng bộ hoá việc thay đổi dữ liệu
                            {

                                string?[] model = item.Model45?.Split(',');
                                string?[] hashModel = model?.Distinct().ToArray();
                                //HashSet<string> hashModel = new HashSet<string>(model ?? Enumerable.Empty<string>());
                                string? resultModel = hashModel == null ? null : string.Join("+", hashModel);
                                string?[] merCode = item.MerCode47?.Split(',');
                                string?[] hashMerCode = merCode?.Distinct().ToArray();
                                //HashSet<string> hashMerCode = new HashSet<string>(merCode ?? Enumerable.Empty<string>());
                                string? resultMerCode = hashMerCode == null ? null : string.Join("+", hashMerCode);
                                excelWorksheet.Cells[(10 + j), 1].Value = j + 1;
                                excelWorksheet.Cells[(10 + j), 2].Value = item.Bc1;
                                excelWorksheet.Cells[(10 + j), 3].Value = item.PartNo8;
                                excelWorksheet.Cells[(10 + j), 3].Style.Font.Color.SetColor(System.Drawing.Color.Gray);
                                excelWorksheet.Cells[(10 + j), 4].Value = item.Bc12;
                                excelWorksheet.Cells[(10 + j), 5].Value = item.Ratio18;
                                excelWorksheet.Cells[(10 + j), 6].Value = resultModel;
                                excelWorksheet.Cells[(10 + j), 7].Value = resultMerCode;
                                excelWorksheet.Cells[(10 + j), 9].Value = item.Name20 == null ? "" : item.Name20;
                                excelWorksheet.Cells[(10 + j), 8].Value = item.EcnLevel4;
                                int len1 = item.Value48.Length;
                                for (int b = 1; b <= len1; b++)
                                {
                                    excelWorksheet.Cells[(10 + j), 10 + b].Value = item.Value48[b - 1];
                                    excelWorksheet.Cells[(10 + j), 10 + b].Style.Numberformat.Format = "0";
                                }
                                j = j + 1;
                            }

                        });
                        if (len > 0)
                        {
                            var cellsMer = excelWorksheet.Cells[7, 11, 9, len + 10].Style;
                            cellsMer.Fill.PatternType = ExcelFillStyle.Solid; ;
                            cellsMer.Fill.BackgroundColor.SetColor(Color.FromArgb(169, 208, 142));
                            cellsMer.WrapText = true;
                            for (int a = 1; a <= len; a++)
                            {
                                excelWorksheet.Cells[7, 10 + a].Value = headerActual.Model[a - 1] == null || headerActual.Model[a - 1] == "" ? null : headerActual.Model[a - 1].Split(":")[1];
                                excelWorksheet.Cells[8, 10 + a].Value = headerActual.Merchandise[a - 1] == null || headerActual.Merchandise[a - 1] == "" ? null : headerActual.Merchandise[a - 1].Split(":")[1];
                                excelWorksheet.Cells[9, 10 + a].Value = headerActual.MerCode[a - 1] == null || headerActual.MerCode[a - 1] == "" ? null : headerActual.MerCode[a - 1].Split(":")[1];
                            }
                            excelWorksheet.Cells[9, 9, 9, len + 10].Style.TextRotation = 90;
                        }
                        var cells1 = excelWorksheet.Cells[7, 10, 9, len + 10].Style;
                        cells1.Font.Size = 11;
                        cells1.Font.Name = "Calibri";
                        cells1.Border.Top.Style = ExcelBorderStyle.Thin;
                        cells1.Border.Bottom.Style = ExcelBorderStyle.Thin;
                        cells1.Border.Left.Style = ExcelBorderStyle.Thin;
                        cells1.Border.Right.Style = ExcelBorderStyle.Thin;

                        var cells2 = excelWorksheet.Cells[10, 1, j + 10, len + 10].Style;
                        cells2.Font.Size = 11;
                        cells2.Font.Name = "Calibri";
                        cells2.Border.Top.Style = ExcelBorderStyle.Thin;
                        cells2.Border.Bottom.Style = ExcelBorderStyle.Thin;
                        cells2.Border.Left.Style = ExcelBorderStyle.Thin;
                        cells2.Border.Right.Style = ExcelBorderStyle.Thin;
                        cells2.HorizontalAlignment = ExcelHorizontalAlignment.Left;

                        string outputPath = Path.Combine(pathServer, "FileOutPut\\OutPutChangingPointLBP", "Output_Changing_Point_LBP_" + DateTime.Now.ToString("yyyy-MM-dd-HHmmss") + ".xlsx");
                        FileInfo excelFile = new FileInfo(outputPath);
                        excelPackage.SaveAs(excelFile);
                        var lstMail = new List<string>();
                        lstMail = ctx.AdmUserInformations.Where(x => x.Active == true
                            && x.AdmDetailUserGroups.Any(y => y.Active == true
                            && y.GroupId == Guid.Parse("99f66340-7ab7-4dac-ac55-fa37bab404d7")))
                                .Include(x => x.AdmDetailUserGroups)
                                .Select(x => x.Email ?? "")
                                .ToList();
                        var link = "http://cvn-vpsi/#/turnoverday/structure/output-structure";
                        string content = "<p style='font-weight: bold;'>Dear [Mrs/Mr]. All,</p>";
                        content += "<p>The job of  calculation changing point  LBP is done.</p>";
                        content += "<p>Now you can check it at: " + link + "</p>";
                        new EmailService().Initial(lstMail, " Completed structure changing point LBP", content);
                    }


                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                }

            }

        }
        public async Task CalcUniquePartLBP()
        {
            //var redis = RedisConnectionManager.GetRedisConnection();
            //var database = redis.GetDatabase();

            using (var ctx = new PdcsystemContext())
            {
                var outputUnique = ctx.TodStructureOutputUniqueLbps.Where(x => x.Active == true).ToList();
                outputUnique.ForEach(x => x.Active = false);
                ctx.UpdateRange(outputUnique);
                ctx.SaveChanges();
                var headerActual = ctx.TodStructureOutputHeaders.Where(x => x.Active == true && x.Product == "LBP").FirstOrDefault();
                var dicIndexMerAct = headerActual.MerCode.ToList().Select(x => new { Key = x.Split(":")[1], Index = x.Split(":")[0] }).ToDictionary(x => x.Key, x => x.Index);

                try
                {
                    var model = ctx.TodStructureMasterUniqueParts.Where(x => x.Active == true && x.Product.ToUpper().Contains("LBP")).ToList().OrderBy(x => x.Kind).ToList();
                    var group1 = model.Where(x => x.Kind == model.DistinctBy(y => y.Kind).ToList().FirstOrDefault().Kind).ToList();
                    var group2 = model.Where(x => x.Kind != model.DistinctBy(y => y.Kind).ToList().FirstOrDefault().Kind).ToList();
                    var output = await ctx.TodStructureOutputContentLbps.Where(x => x.Active == true).ToListAsync();
                    List<TodStructureOutputUniqueLbp> lstAdd = new List<TodStructureOutputUniqueLbp>();
                    foreach (var mer1 in group1)
                    {
                        var listCheck = output.Where(x => x.MerCode47 != null && !x.MerCode47.Contains(mer1.Merchandise)).ToList();
                        if (!dicIndexMerAct.TryGetValue(mer1.Merchandise, out var indexMer1))
                        {
                            indexMer1 = null; // Giá trị mặc định nếu không tìm thấy 
                        }
                        if (indexMer1 != null)
                        {
                            foreach (var item in listCheck)
                            {
                                var usageMer1 = item.Value48[int.Parse(indexMer1)];
                                if (usageMer1 == "")
                                {

                                    foreach (var gr2 in group2)
                                    {

                                        if (item.MerCode47.Contains(gr2.Merchandise))
                                        {
                                            //var indexMer2 = dicIndexMerAct[gr2.Merchandise]; 
                                            if (!dicIndexMerAct.TryGetValue(gr2.Merchandise, out var indexMer2))
                                            {
                                                indexMer2 = null; // Giá trị mặc định nếu không tìm thấy 
                                            }
                                            if (indexMer2 != null)
                                            {
                                                var usageMer2 = item.Value48[int.Parse(indexMer2)];
                                                if (usageMer2 != "" && usageMer2 != "0")
                                                {
                                                    lstAdd.Add(new TodStructureOutputUniqueLbp
                                                    {
                                                        Kind = gr2.Kind,
                                                        Merchandise = gr2.Merchandise,
                                                        Bc1 = item.Bc1,
                                                        PartNo8 = item.PartNo8,
                                                        PartName9 = item.PartName11,
                                                        Bc12 = item.Bc12,
                                                        Name20 = item.Name20,
                                                        LdDo = item.DoPic43,
                                                        LdPo = item.PoPic44
                                                    });

                                                }
                                            }

                                        }
                                    }
                                }

                            }
                        }
                    }

                    foreach (var mer2 in group2)
                    {
                        var listCheck2 = output.Where(x => x.MerCode47 != null && !x.MerCode47.Contains(mer2.Merchandise)).ToList();
                        // var indexMer2 = dicIndexMerAct[mer2.Merchandise];
                        if (!dicIndexMerAct.TryGetValue(mer2.Merchandise, out var indexMer2))
                        {
                            indexMer2 = null; // Giá trị mặc định nếu không tìm thấy 
                        }
                        if (indexMer2 != null)
                        {
                            foreach (var item in listCheck2)
                            {
                                var usageMer2 = item.Value48[int.Parse(indexMer2)];
                                if (usageMer2 == "")
                                {

                                    foreach (var gr1 in group1)
                                    {

                                        if (item.MerCode47.Contains(gr1.Merchandise))
                                        {
                                            //var indexMer1 = dicIndexMerAct[gr1.Merchandise];
                                            if (!dicIndexMerAct.TryGetValue(gr1.Merchandise, out var indexMer1))
                                            {
                                                indexMer1 = null; // Giá trị mặc định nếu không tìm thấy 
                                            }
                                            if (indexMer1 != null)
                                            {
                                                var usageMer1 = item.Value48[int.Parse(indexMer1)];
                                                if (usageMer1 != "" && usageMer1 != "0")
                                                {
                                                    lstAdd.Add(new TodStructureOutputUniqueLbp
                                                    {
                                                        Kind = gr1.Kind,
                                                        Merchandise = gr1.Merchandise,
                                                        Bc1 = item.Bc1,
                                                        PartNo8 = item.PartNo8,
                                                        PartName9 = item.PartName11,
                                                        Bc12 = item.Bc12,
                                                        Name20 = item.Name20,
                                                        LdDo = item.DoPic43,
                                                        LdPo = item.PoPic44
                                                    });

                                                }
                                            }

                                        }
                                    }
                                }

                            }
                        }
                    }
                    lstAdd = lstAdd.DistinctBy(x => new { x.PartNo8, x.Merchandise }).ToList();
                    ctx.AddRange(lstAdd);
                    ctx.SaveChanges();
                    var lstMail = new List<string>();
                    lstMail = ctx.AdmUserInformations.Where(x => x.Active == true
                        && x.AdmDetailUserGroups.Any(y => y.Active == true
                        && y.GroupId == Guid.Parse("99f66340-7ab7-4dac-ac55-fa37bab404d7")))
                            .Include(x => x.AdmDetailUserGroups)
                            .Select(x => x.Email ?? "")
                            .ToList();
                    var link = "http://cvn-vpsi/#/turnoverday/structure/output-structure";
                    string content = "<p style='font-weight: bold;'>Dear [Mrs/Mr]. All,</p>";
                    content += "<p>The job of  calculation unique part LBP is done.</p>";
                    content += "<p>Now you can check it at: " + link + "</p>";
                    new EmailService().Initial(lstMail, " Completed structure unique part LBP", content);
                }
                catch (Exception ex)
                {
                    new EmailService().Initial(lstITMail, " Exception calculation unique part lbp", ex.Message);
                }

            }

        }

        #endregion

        //////private T GetDeserializedObject<T>(string hashKey, string hashField)
        //////{
        //////    //var redis = RedisConnectionManager.GetRedisConnection();
        //////    //var database = redis.GetDatabase();
        //////    var json = database.HashGet(hashKey, hashField);
        //////    if (json.IsNull)
        //////    {
        //////        return default(T);
        //////    }
        //////    else
        //////    {
        //////        return JsonConvert.DeserializeObject<T>(json);
        //////    }
        //////}

        private bool CheckStrings(List<string> strings)
        {
            // Kiểm tra nếu không có chuỗi nào truyền vào
            if (strings.Count == 0)
            {
                return false;
            }

            // Lấy độ dài của chuỗi đầu tiên
            int length = strings[0].Split(",").Length;

            // Kiểm tra độ dài của các chuỗi còn lại
            foreach (var str in strings)
            {
                if (str.Split(",").Length != length)
                {
                    return false;
                }
            }
            var str1 = strings[0].Split(",");

            // Kiểm tra từng phần tử của các chuỗi
            foreach (var item in str1)
            {
                // Lấy phần tử thứ i của chuỗi đầu tiên
                var element = item;

                // Kiểm tra phần tử thứ i của các chuỗi còn lại
                foreach (var str in strings)
                {
                    if (!str.Contains(element))
                    {
                        return false;
                    }
                }
            }

            // Các điều kiện đề bài đều đúng
            return true;
        }


        public async Task SaveD101IJRedis()
        {
            //var redis = RedisConnectionManager.GetRedisConnection();
            //var database = redis.GetDatabase();

            try
            {

                //RedisResult[] keys = (RedisResult[])database.Execute("KEYS", "eucd101ij_*");
                //keys.AsParallel().ForAll(x =>
                //{
                //    var keyToDelete = (string)x;
                //    database.KeyDelete(keyToDelete);
                //});
                //using (var ctx = new PdcsystemContext())
                //{
                //    var dateNow = DateTime.Now.ToString("yyyyMMdd");
                //    List<VlinkageEucIjD101> dataView = new List<VlinkageEucIjD101>();
                //    try
                //    {
                //        dataView = await ctx.VlinkageEucIjD101s
                //            .ToListAsync();
                //    }
                //    catch
                //    {
                //        dataView = await ctx.VlinkageEucIjD101s
                //             .ToListAsync();
                //    }
                //    var i = 0;
                //    Console.WriteLine("Start " + DateTime.Now);
                //    var dv1 = Partitioner.Create(dataView);
                //    dv1.AsParallel().ForAll(e =>
                //    {
                //        var key = "eucd101ij_sum_" + e.NoParts + "_" + e.CdBlock;
                //        double incrementValue = e.CtAll.StringAbleToDouble();
                //        database.StringIncrement(key, incrementValue);
                //    });
                //}
                //Console.WriteLine("Stop " + DateTime.Now);

            }
            catch (Exception e)
            {
                //new EmailService().Initial(lstITMail, " Faile get eucd101 ij", e.Message);
            }
        }
        public async Task SaveD101LBPRedis()
        {
            //var redis = RedisConnectionManager.GetRedisConnection();
            //var database = redis.GetDatabase();

            try
            {

                //RedisResult[] keys = (RedisResult[])database.Execute("KEYS", "eucd101lbp_*");
                //keys.AsParallel().ForAll(x =>
                //{
                //    var keyToDelete = (string)x;
                //    database.KeyDelete(keyToDelete);
                //});
                //using (var ctx = new PdcsystemContext())
                //{
                //    var dateNow = DateTime.Now.ToString("yyyyMMdd");
                //    List<VlinkageEucLbpD101> dataView = new List<VlinkageEucLbpD101>();
                //    try
                //    {
                //        dataView = await ctx.VlinkageEucLbpD101s
                //            .ToListAsync();
                //    }
                //    catch
                //    {
                //        dataView = await ctx.VlinkageEucLbpD101s
                //             .ToListAsync();
                //    }
                //    var i = 0;
                //    Console.WriteLine("Start " + DateTime.Now);
                //    var dv1 = Partitioner.Create(dataView);
                //    dv1.AsParallel().ForAll(e =>
                //    {
                //        var key = "eucd101lbp_sum_" + e.NoParts + "_" + e.CdBlock;
                //        double incrementValue = e.CtAll.StringAbleToDouble();
                //        database.StringIncrement(key, incrementValue);
                //    });
                //}
                //Console.WriteLine("Stop " + DateTime.Now);

            }
            catch (Exception e)
            {
                //new EmailService().Initial(lstITMail, " Faile get eucd101 ij", e.Message);
            }
        }

        public async Task SaveJ4500IJRedis()
        {
            //var redis = RedisConnectionManager.GetRedisConnection();
            //var database = redis.GetDatabase();

            try
            {
                //var listPoStatus = new List<string>() { "AO", "PO", "MG", "FC", "PG", "LI" };
                //var listCdUse = global.ReturnBlockCode();
                //RedisResult[] keys = (RedisResult[])database.Execute("KEYS", "eucj4500ij_*");
                //keys.AsParallel().ForAll(x =>
                //{
                //    var keyToDelete = (string)x;
                //    database.KeyDelete(keyToDelete);
                //});
                //string sToday = DateTime.Now.ToString("yyyyMMdd");
                //using (var ctx = new PdcsystemContext())
                //{
                //List<MvLinkageIjJ4500> dataView = new List<MvLinkageIjJ4500>();
                //try
                //{
                //    dataView = await ctx.MvLinkageIjJ4500s.Where(x => listPoStatus.Contains(x.PoStatus)/* && listCdUse.Contains(x.CdUseBlock)*/).ToListAsync();
                //}
                //catch
                //{
                //    dataView = await ctx.MvLinkageIjJ4500s.Where(x => listPoStatus.Contains(x.PoStatus)/* && listCdUse.Contains(x.CdUseBlock)*/).ToListAsync();
                //}
                //var i = 0;
                //Console.WriteLine("Start " + DateTime.Now);
                //dataView.AsParallel().ForAll(e =>
                //{
                //    var key = "eucj4500ij_sum_" + e.NoParts + "_" + e.CdUseBlock + "_" + e.CdSply +"_"+e.DtDelv;
                //    double incrementValue = e.QtOrd.StringAbleToDouble();
                //    database.StringIncrement(key, incrementValue);
                //});
                //chỗ này đã chuyển vào materialized view
                //foreach (var e in dataView)
                //{
                //    var key = "eucj4500ij_sum_" + e.NoParts + "_" + (e.CdUseBlock ?? "") + "_" + e.CdSply + "_" + e.DtDelv;
                //    double incrementValue = e.QtOrd.StringAbleToDouble();
                //    if (e.DtDelv == sToday)
                //    {
                //        incrementValue = e.QtDelvBal.StringAbleToDouble();
                //    }
                //    database.StringIncrement(key, incrementValue);
                //}
                //}
                //Console.WriteLine("Stop " + DateTime.Now);
                //new EmailService().Initial(lstITMail, " Finish get j4500 ij", "Finish job get j4500 ij to redis");
            }
            catch (Exception e)
            {
                //new EmailService().Initial(lstITMail, " Faile get j4500 ij", e.Message);
            }
        }
        public async Task SaveJ4500LBPRedis()
        {
            //var redis = RedisConnectionManager.GetRedisConnection();
            //var database = redis.GetDatabase();

            try
            {
                //var listPoStatus = new List<string>() { "AO", "PO", "MG", "FC", "PG", "LI" };
                //var listCdUse = global.ReturnBlockCode();
                //RedisResult[] keys = (RedisResult[])database.Execute("KEYS", "eucj4500lbp_*");
                //keys.AsParallel().ForAll(x =>
                //{
                //    var keyToDelete = (string)x;
                //    database.KeyDelete(keyToDelete);
                //});
                //string sToday = DateTime.Now.ToString("yyyyMMdd");
                //using (var ctx = new PdcsystemContext())
                //{
                //    List<MvLinkageLbpJ4500> dataView = new List<MvLinkageLbpJ4500>();
                //    try
                //    {
                //        dataView = await ctx.MvLinkageLbpJ4500s.Where(x => listPoStatus.Contains(x.PoStatus)/* && listCdUse.Contains(x.CdUseBlock)*/).ToListAsync();
                //    }
                //    catch
                //    {
                //        dataView = await ctx.MvLinkageLbpJ4500s.Where(x => listPoStatus.Contains(x.PoStatus)/* && listCdUse.Contains(x.CdUseBlock)*/).ToListAsync();
                //    }
                //    var i = 0;
                //    //Console.WriteLine("Start " + DateTime.Now);
                //    //dataView.AsParallel().ForAll(e =>
                //    //{
                //    //    var key = "eucj4500ij_sum_" + e.NoParts + "_" + e.CdUseBlock + "_" + e.CdSply +"_"+e.DtDelv;
                //    //    double incrementValue = e.QtOrd.StringAbleToDouble();
                //    //    database.StringIncrement(key, incrementValue);
                //    //});
                //    foreach (var e in dataView)
                //    {
                //        var key = "eucj4500lbp_sum_" + e.NoParts + "_" + e.CdUseBlock + "_" + e.CdSply + "_" + e.DtDelv;
                //        double incrementValue = e.QtOrd.StringAbleToDouble();
                //        if (e.DtDelv == sToday)
                //        {
                //            incrementValue = e.QtDelvBal.StringAbleToDouble();
                //        }
                //        database.StringIncrement(key, incrementValue);
                //    }
                //}
                ////Console.WriteLine("Stop " + DateTime.Now);
                //new EmailService().Initial(lstITMail, " Finish get j4500_1 lbp", "Finish job get j4500_1 lbp to redis");
            }
            catch (Exception e)
            {
                //new EmailService().Initial(lstITMail, " Faile get eucb101 lbp", e.Message);
            }
        }


        #region lưu dữ liệu cũ live production vào history
        public async Task SaveHistoryLivePP()
        {
            try
            {
                var model = new List<HistoryVlinkageDailyLivePp>();
                using (var ctx = new PdcsystemContext())
                {
                    var md1 = await ctx.VlinkageHksLivePpIjs.Select(x => new HistoryVlinkageDailyLivePp()
                    {
                        Actual = x.Actual,
                        FromTime = x.FromTime,
                        Model = x.ProductCode,
                        PalletDate = x.PalletDate,
                        Plan = x.PlanQty,
                        Product = "IJ",
                        Shift = x.Shift
                    }).ToListAsync();
                    var md2 = await ctx.VlinkageHksLivePpLbps.Select(x => new HistoryVlinkageDailyLivePp()
                    {
                        Actual = x.Actual,
                        FromTime = x.FromTime,
                        Model = x.ProductCode,
                        PalletDate = x.PalletDate,
                        Plan = x.PlanQty,
                        Product = "LBP",
                        Shift = x.Shift
                    }).ToListAsync();
                    model.AddRange(md1);
                    model.AddRange(md2);
                    await ctx.HistoryVlinkageDailyLivePps.AddRangeAsync(model);
                    await ctx.SaveChangesAsync().ConfigureAwait(false);
                }
            }
            catch (Exception)
            {

            }
        }

        public async Task GetOutputECNLV2IJ()
        {
            try
            {
                using (var context = new PdcsystemContext())
                {
                    try
                    {
                        var masterpacking = context.TodStructureMasterPackings.Where(x => x.Active == true && x.ApprovedDate != null && x.ApprovedBy != null).ToList();
                        var masterjob = context.PcPaPartJobAssignments.Where(x => x.Active == true && x.ApprovalDate != null && x.ApprovalBy != null && x.Product.ToUpper() == "IJ").ToList();
                        var masterdelivery = context.TodStructureMasterDeliveries.Where(x => x.Active == true && x.ApprovedDate != null && x.ApprovedBy != null && x.Product.ToUpper() == "IJ").ToList();
                        var lstBc = global.ReturnBlockCode();
                        var dictPacking = new ConcurrentDictionary<(string, string), (int, int, int, int)>();
                        foreach (var ip in masterpacking)
                        {
                            dictPacking.TryAdd((ip.PartNo, ip.Vendor), (ip.Moq ?? 0, ip.PcsBox ?? 0, ip.BoxPallet ?? 0, ip.PcsPallet ?? 0));
                        }
                        var dictAssignJob = new ConcurrentDictionary<(string, string), (string, string)>();
                        foreach (var ip in masterjob)
                        {
                            dictAssignJob.TryAdd((ip.PartNo, ip.Vendor), (ip.DoPic ?? "", ip.PicPo ?? ""));
                        }
                        var dictDelivery = new ConcurrentDictionary<string, string>();
                        foreach (var ip in masterdelivery)
                        {
                            dictDelivery.TryAdd(ip.VendorCode, $"{ip.MethodDelivery ?? ""}_{ip.Location1 ?? ""}_{ip.Location2 ?? ""}_{ip.Location3 ?? ""}_{ip.RouteDelivery ?? ""}_{ip.PartDelivMoving ?? ""}_{ip.DelivFreqDay ?? 0}_{ip.DelivFreqNight ?? 0}_{ip.DelivFreqWeek ?? 0}_{ip.Name ?? ""}");
                        }
                        var ijMerchandise = new List<TodStructureMasterMerchandise>();
                        var arrValue48 = new List<string>();

                        ijMerchandise = await context.TodStructureMasterMerchandises.Where(x => x.Active == true
                        && x.Model != null && x.DestName != null && x.Merchandise != null
                        && x.Product != null && x.Product.Equals("IJ") && x.ApprovedBy != null && x.ApprovedDate != null && x.Status == "Run")
                            .OrderBy(x => x.Model).ThenBy(x => x.Merchandise)
                            .ToListAsync();
                        var header = context.TodStructureOutputHeaders.Where(x => x.Active == true && x.Product.ToUpper().Contains("IJ")).FirstOrDefault();
                        var dicIndexMer = header.MerCode.ToList().Select(x => new { Key = x.Split(":")[1], Index = x.Split(":")[0] }).ToDictionary(x => x.Key, x => x.Index);
                        var dicIndexModel = header.Model.ToList().Select(x => new { Key = x.Split(":")[0], Index = x.Split(":")[1] }).ToDictionary(x => x.Key, x => x.Index);
                        var dicIndexDes = header.Merchandise.ToList().Select(x => new { Key = x.Split(":")[0], Index = x.Split(":")[1] }).ToDictionary(x => x.Key, x => x.Index);
                        arrValue48 = header.Merchandise.Select(x => "").ToList();
                        var ecnlv2Usage = context.MvEucEcnLv2IjUsages.ToDictionary(x => x.MerKey, x => x.Usage);
                        var ecnlv2Mer = context.MvEucEcnLv2IjMerchandises.ToDictionary(x => x.MerKey, x => x.Merchandise);
                        //var euch1202 = context.MvEucH1202Ijs.ToList();
                        var euch3001 = await context.MvEucH3001Ijs.ToListAsync();
                        var dict3001 = new ConcurrentDictionary<string, string>();
                        foreach (var ip in euch3001)
                        {
                            dict3001.TryAdd(ip.NoParts, ip.PdDecimalLead);
                        }
                        //var euch5001 = context.MvEucH501Ijs.ToList();
                        //var euch300 = context.MvEucH300Ijs.ToList();
                        var eucj1001 = await context.MvEucJ1001Ijs.ToListAsync();
                        var dict1001 = new ConcurrentDictionary<(string, string), (string, string, string, string)>();
                        foreach (var ip in eucj1001)
                        {
                            dict1001.TryAdd((ip.PartsNo, ip.Vendor), (ip.OrderMethod, ip.DeliveryLot, ip.StandardPack, ip.PoLeadTime));
                        }

                        var hashEntries = context.MvEucEcnLv2Ijs.GroupBy(x => new { x.CdBlock, x.NoChldParts, x.CdChldSply }).Select(g => g.First()).ToList();

                        List<TodStructureOutputContentIj> batchRecords = new List<TodStructureOutputContentIj>();

                        batchRecords = hashEntries.AsParallel().Select(item =>
                        {

                            //////var iDel = masterdelivery.FirstOrDefault(x => x.VendorCode == item.CdChldSply);
                            //////var iJob = masterjob.FirstOrDefault(x => x.Bc == item.CdBlock && x.VendorCode == item.CdChldSply);
                            //////var iPacking = masterpacking.FirstOrDefault(x => x.PartNo == item.NoChldParts && x.Vendor == item.CdChldSply);
                            ////////var i1202 = euch1202.FirstOrDefault(x => x.NoParts == item.NoChldParts && x.NoSubstitParts == item.NoParts);
                            ////////var i500 = euch5001.FirstOrDefault(x => x.NoParts == item.NoChldParts && x.CdBlock == item.CdChldSply);
                            //////var i1001 = eucj1001.FirstOrDefault(x => x.PartsNo == item.NoChldParts && x.Vendor == item.CdChldSply);
                            //////var i3001 = euch3001.FirstOrDefault(x => x.NoParts == item.NoChldParts);
                            //////// var i300 = euch300.FirstOrDefault(x => x.NoParts == item.NoChldParts && x.CdBlock == item.CdBlockH001 && x.NoAdjDim == item.NoChldAdjDim);




                            var im = new TodStructureOutputContentIj()
                            {

                                Bc1 = item.CdBlock,
                                CreatedDate = DateTime.Now,
                                EcnNo2 = item.NoHistChange,
                                OldEcnNo2 = item.NoHistChange,
                                EffectiveDate3 = item.DtBValid,
                                EcnLevel4 = item.CfChgStatClss,
                                //EffectiveDate5 = !valuei501.IsNullOrEmpty ? i501.DtBValid : !valuei1202.IsNullOrEmpty ? i1202.DtBValid : null,
                                //Ratio6 = !valuei501.IsNullOrEmpty ? i501.PtRatio : !valuei1202.IsNullOrEmpty ? i1202.PtSubstit : null,
                                PartNo8 = item.NoChldParts,
                                Dim9 = item.NoChldAdjDim,
                                Pr10 = item.CdProcess,
                                //PartName11 = item.NmPartsEng,
                                Bc12 = item.CdChldSply,
                                Unit13 = item.CdPiece,
                                Factory17 = "",
                                Ratio18 = "100",
                                Comain22 = "",
                                Com23 = "",
                                //DelAdjust42 = i3001?.PdDecimalLead.StringAbleToDouble().ToString() ?? "",
                                Value48 = arrValue48.ToArray(),
                                Active = true
                            };
                            if (dict3001.TryGetValue(item.NoChldParts, out var i3001))
                            {
                                im.DelAdjust42 = i3001;
                            }
                            if (dictDelivery.TryGetValue(item.CdChldSply, out var iDel))
                            {
                                string[] iDelVal = iDel.Split('_');
                                im.MethodDelivery24 = iDelVal[0];
                                im.Location125 = iDelVal[1];
                                im.Location226 = iDelVal[2];
                                im.Location327 = iDelVal[3];
                                im.RouteDelivery28 = iDelVal[4];
                                im.PartDelMoving29 = iDelVal[5];
                                im.Day30 = Convert.ToInt32(iDelVal[6]);
                                im.Night31 = Convert.ToInt32(iDelVal[7]);
                                im.Week32 = Convert.ToInt32(iDelVal[8]);
                                im.Name20 = iDelVal[9];
                            }

                            if (dict1001.TryGetValue((item.NoChldParts, item.CdChldSply), out var i1001))
                            {
                                im.Type19 = i1001.Item1;
                                im.DelLot33 = i1001.Item2;
                                im.StdPacking34 = i1001.Item3;
                                im.Polt39 = i1001.Item4;
                            }

                            //if (i300 != null)
                            //{
                            //    im.Storelt40 = i300.TmStoreLead;
                            //    im.Process41 = i300.PdProcess;
                            //}
                            if (dictPacking.TryGetValue((item.NoChldParts, item.CdChldSply), out var iPackVal))
                            {
                                im.Moq35 = iPackVal.Item1;
                                im.Pcsbox36 = iPackVal.Item2;
                                im.Boxpl37 = iPackVal.Item3;
                                im.Pcspl38 = iPackVal.Item4;
                            }
                            if (dictAssignJob.TryGetValue((item.NoChldParts, item.CdChldSply), out var valJob))
                            {
                                im.DoPic43 = valJob.Item1;
                                im.PoPic44 = valJob.Item2;
                            }


                            //var key_euc = "ecnlv2ij_" + item.CdBlock + "_" + item.NoChldParts + "_" + item.CdChldSply;
                            //string value = database.StringGet(key_euc);
                            ecnlv2Mer.TryGetValue(item.CdBlock + "_" + item.NoChldParts + "_" + item.CdChldSply, out var key_euc);
                            string model45 = null, des46 = null, mer47 = null;
                            //đếm các mer để so sánh tìm ra des21
                            var count_mer = 0;
                            List<string> merchandiseList = new List<string>();
                            if (key_euc != null)
                            {
                                string value = key_euc;
                                string[] merchandiseArray = value?.Split(new[] { ',' }, StringSplitOptions.RemoveEmptyEntries);
                                foreach (var mer in merchandiseArray)
                                {
                                    if (ecnlv2Usage.TryGetValue(item.CdBlock + "_" + item.NoChldParts + "_" + item.CdChldSply + "_" + mer, out var key_usage))
                                    {
                                        var valueMer = key_usage;
                                        try
                                        {
                                            dicIndexMer.TryGetValue(mer, out var index);
                                            var usage = valueMer;
                                            var susage = usage == 0 ? "0" : usage.ToString();
                                            im.Value48[int.Parse(index)] = susage;
                                            if (usage > 0)
                                            {
                                                dicIndexModel.TryGetValue(index, out var model);
                                                dicIndexDes.TryGetValue(index, out var desname);
                                                model45 = model45 == null || model45 == "" ? model : model45 + "," + model;
                                                des46 = des46 == null || des46 == "" ? desname : des46 + "," + desname;
                                                mer47 = mer47 == null || mer47 == "" ? mer : mer47 + "," + mer;
                                                count_mer++;
                                            }
                                        }

                                        catch
                                        {
                                            //return im;
                                        }
                                    }

                                }


                            }
                            im.Model45 = model45;
                            im.Merchandise46 = des46;
                            im.MerCode47 = mer47;

                            //check mer để tìm ra des21
                            var count_mer_from_model = ijMerchandise.Where(x => model45 != null && model45.Split(",").Distinct().ToList().Contains(x.Model) && x.Bc == im.Bc1).Count();
                            if (count_mer >= count_mer_from_model)
                            {
                                im.Des21 = "Com";
                            }
                            else
                            {
                                im.Des21 = "Des";
                            }

                            return im;
                        }).ToList();


                        // Tắt tự động phát hiện thay đổi để tăng hiệu suất
                        context.ChangeTracker.AutoDetectChangesEnabled = false;

                        // Chia danh sách thành các phần nhỏ (ví dụ: 1000 bản ghi mỗi phần)
                        var batchS = 10000;
                        var batches = batchRecords.Select((item, index) => new { Item = item, Index = index })
                                            .GroupBy(x => x.Index / batchS)
                                            .Select(g => g.Select(x => x.Item).ToList());


                        foreach (var batch in batches)
                        {
                            using (var transaction = context.Database.BeginTransaction())
                            {
                                try
                                {
                                    context.TodStructureOutputContentIjs.AddRange(batch);
                                    context.SaveChanges();

                                    transaction.Commit();
                                }
                                catch
                                {
                                    transaction.Rollback();
                                    throw;
                                }
                            }


                            // Xóa bộ đệm để tránh tràn bộ nhớ
                            context.ChangeTracker.Clear();
                        }


                    }
                    catch (Exception e)
                    {

                        new EmailService().Initial(lstITMail, " exception calculation output with ecn lv2 ij", e.Message);
                    }
                }
            }
            catch (Exception)
            {

            }



        }

        public async Task GetOutputECNLV2LBP()
        {

            try
            {
                using (var context = new PdcsystemContext())
                {
                    try
                    {
                        var masterpacking = await context.TodStructureMasterPackings.Where(x => x.Active == true && x.ApprovedDate != null && x.ApprovedBy != null).ToListAsync();
                        var masterjob = await context.PcPaPartJobAssignments.Where(x => x.Active == true && x.ApprovalDate != null && x.ApprovalBy != null && x.Product == "LBP").ToListAsync();
                        var masterdelivery = await context.TodStructureMasterDeliveries.Where(x => x.Active == true && x.ApprovedDate != null && x.ApprovedBy != null && x.Product == "LBP").ToListAsync();
                        var lstBc = global.ReturnBlockCode();
                        var dictPacking = new ConcurrentDictionary<(string, string), (int, int, int, int)>();
                        foreach (var ip in masterpacking)
                        {
                            dictPacking.TryAdd((ip.PartNo, ip.Vendor), (ip.Moq ?? 0, ip.PcsBox ?? 0, ip.BoxPallet ?? 0, ip.PcsPallet ?? 0));
                        }
                        var dictAssignJob = new ConcurrentDictionary<(string, string), (string, string)>();
                        foreach (var ip in masterjob)
                        {
                            dictAssignJob.TryAdd((ip.PartNo, ip.Vendor), (ip.DoPic ?? "", ip.PicPo ?? ""));
                        }
                        var dictDelivery = new ConcurrentDictionary<string, string>();
                        foreach (var ip in masterdelivery)
                        {
                            dictDelivery.TryAdd(ip.VendorCode, $"{ip.MethodDelivery ?? ""}_{ip.Location1 ?? ""}_{ip.Location2 ?? ""}_{ip.Location3 ?? ""}_{ip.RouteDelivery ?? ""}_{ip.PartDelivMoving ?? ""}_{ip.DelivFreqDay ?? 0}_{ip.DelivFreqNight ?? 0}_{ip.DelivFreqWeek ?? 0}_{ip.Name ?? ""}");
                        }
                        var lbpMerchandise = new List<TodStructureMasterMerchandise>();
                        var arrValue48 = new List<string>();

                        lbpMerchandise = await context.TodStructureMasterMerchandises.Where(x => x.Active == true
                        && x.Model != null && x.DestName != null && x.Merchandise != null
                        && x.Product != null && x.Product.Equals("LBP") && x.ApprovedBy != null && x.ApprovedDate != null && x.Status == "Run")
                            .OrderBy(x => x.Model).ThenBy(x => x.Merchandise)
                            .ToListAsync();
                        var header = context.TodStructureOutputHeaders.Where(x => x.Active == true && x.Product.ToUpper().Contains("LBP")).FirstOrDefault();
                        var dicIndexMer = header.MerCode.ToList().Select(x => new { Key = x.Split(":")[1], Index = x.Split(":")[0] }).ToDictionary(x => x.Key, x => x.Index);
                        var dicIndexModel = header.Model.ToList().Select(x => new { Key = x.Split(":")[0], Index = x.Split(":")[1] }).ToDictionary(x => x.Key, x => x.Index);
                        var dicIndexDes = header.Merchandise.ToList().Select(x => new { Key = x.Split(":")[0], Index = x.Split(":")[1] }).ToDictionary(x => x.Key, x => x.Index);
                        arrValue48 = header.Merchandise.Select(x => "").ToList();
                        var ecnlv2Usage = context.MvEucEcnLv2LbpUsages.ToDictionary(x => x.MerKey, x => x.Usage);
                        var ecnlv2Mer = context.MvEucEcnLv2LbpMerchandises.ToDictionary(x => x.MerKey, x => x.Merchandise);
                        var euch3001 = await context.MvEucH3001Lbps.ToListAsync();
                        var dict3001 = new ConcurrentDictionary<string, string>();
                        foreach (var ip in euch3001)
                        {
                            dict3001.TryAdd(ip.NoParts, ip.PdDecimalLead);
                        }
                        var eucj1001 = await context.MvEucJ1001Lbps.ToListAsync();
                        var dict1001 = new ConcurrentDictionary<(string, string), (string, string, string, string)>();
                        foreach (var ip in eucj1001)
                        {
                            dict1001.TryAdd((ip.NoParts, ip.CdSply), (ip.CdOrdClass, ip.QtDelvLot, ip.QtSnp, ip.PdPoIssue));
                        }

                        var hashEntries = context.MvEucEcnLv2Lbps.GroupBy(x => new { x.CdBlock, x.NoChldParts, x.CdChldSply }).Select(g => g.First()).ToList();

                        List<TodStructureOutputContentLbp> batchRecords = new List<TodStructureOutputContentLbp>();

                        batchRecords = hashEntries.AsParallel().Select(item =>
                        {
                            var im = new TodStructureOutputContentLbp()
                            {

                                Bc1 = item.CdBlock,
                                CreatedDate = DateTime.Now,
                                EcnNo2 = item.NoHistChange,
                                OldEcnNo2 = item.NoHistChange,
                                EffectiveDate3 = item.DtBValid,
                                EcnLevel4 = item.CfChgStatClss,
                                //EffectiveDate5 = !valuei501.IsNullOrEmpty ? i501.DtBValid : !valuei1202.IsNullOrEmpty ? i1202.DtBValid : null,
                                //Ratio6 = !valuei501.IsNullOrEmpty ? i501.PtRatio : !valuei1202.IsNullOrEmpty ? i1202.PtSubstit : null,
                                PartNo8 = item.NoChldParts,
                                Dim9 = item.NoChldAdjDim,
                                Pr10 = item.CdProcess,
                                //PartName11 = item.NmPartsEng,
                                Bc12 = item.CdChldSply,
                                Unit13 = item.CdPiece,
                                Factory17 = "",
                                Ratio18 = "100",
                                Comain22 = "",
                                Com23 = "",
                                //DelAdjust42 = i3001?.PdDecimalLead.StringAbleToDouble().ToString() ?? "",
                                Value48 = arrValue48.ToArray(),
                                Active = true
                            };
                            if (dict3001.TryGetValue(item.NoChldParts, out var i3001))
                            {
                                im.DelAdjust42 = i3001;
                            }
                            if (dictDelivery.TryGetValue(item.CdChldSply, out var iDel))
                            {
                                string[] iDelVal = iDel.Split('_');
                                im.MethodDelivery24 = iDelVal[0];
                                im.Location125 = iDelVal[1];
                                im.Location226 = iDelVal[2];
                                im.Location327 = iDelVal[3];
                                im.RouteDelivery28 = iDelVal[4];
                                im.PartDelMoving29 = iDelVal[5];
                                im.Day30 = Convert.ToInt32(iDelVal[6]);
                                im.Night31 = Convert.ToInt32(iDelVal[7]);
                                im.Week32 = Convert.ToInt32(iDelVal[8]);
                                im.Name20 = iDelVal[9];
                            }

                            if (dict1001.TryGetValue((item.NoChldParts, item.CdChldSply), out var i1001))
                            {
                                im.Type19 = i1001.Item1;
                                im.DelLot33 = i1001.Item2;
                                im.StdPacking34 = i1001.Item3;
                                im.Polt39 = i1001.Item4;
                            }

                            if (dictPacking.TryGetValue((item.NoChldParts, item.CdChldSply), out var iPackVal))
                            {
                                im.Moq35 = iPackVal.Item1;
                                im.Pcsbox36 = iPackVal.Item2;
                                im.Boxpl37 = iPackVal.Item3;
                                im.Pcspl38 = iPackVal.Item4;
                            }

                            //if (i300 != null)
                            //{
                            //    im.Storelt40 = i300.TmStoreLead;
                            //    im.Process41 = i300.PdProcess;
                            //}

                            if (dictAssignJob.TryGetValue((item.NoChldParts, item.CdChldSply), out var valJob))
                            {
                                im.DoPic43 = valJob.Item1;
                                im.PoPic44 = valJob.Item2;
                            }

                            ecnlv2Mer.TryGetValue(item.CdBlock + "_" + item.NoChldParts + "_" + item.CdChldSply, out var key_euc);

                            string model45 = null, des46 = null, mer47 = null;
                            //đếm các mer để so sánh tìm ra des21
                            var count_mer = 0;
                            List<string> merchandiseList = new List<string>();
                            if (key_euc != null)
                            {
                                string value = key_euc;
                                string[] merchandiseArray = value?.Split(new[] { ',' }, StringSplitOptions.RemoveEmptyEntries);
                                foreach (var mer in merchandiseArray)
                                {
                                    if (ecnlv2Usage.TryGetValue(item.CdBlock + "_" + item.NoChldParts + "_" + item.CdChldSply + "_" + mer, out var key_usage))
                                    {
                                        var valueMer = key_usage;
                                        try
                                        {
                                            dicIndexMer.TryGetValue(mer, out var index);
                                            var usage = valueMer;
                                            var susage = usage == 0 ? "0" : usage.ToString();
                                            im.Value48[int.Parse(index)] = susage;
                                            if (usage > 0)
                                            {
                                                dicIndexModel.TryGetValue(index, out var model);
                                                dicIndexDes.TryGetValue(index, out var desname);
                                                model45 = model45 == null || model45 == "" ? model : model45 + "," + model;
                                                des46 = des46 == null || des46 == "" ? desname : des46 + "," + desname;
                                                mer47 = mer47 == null || mer47 == "" ? mer : mer47 + "," + mer;
                                                count_mer++;
                                            }
                                        }

                                        catch
                                        {
                                            //return im;
                                        }
                                    }

                                }


                            }
                            im.Model45 = model45;
                            im.Merchandise46 = des46;
                            im.MerCode47 = mer47;

                            //check mer để tìm ra des21
                            var count_mer_from_model = lbpMerchandise.Where(x => model45 != null && model45.Split(",").Distinct().ToList().Contains(x.Model) && x.Bc == im.Bc1).Count();
                            if (count_mer >= count_mer_from_model)
                            {
                                im.Des21 = "Com";
                            }
                            else
                            {
                                im.Des21 = "Des";
                            }

                            return im;
                        }).ToList();


                        // Tắt tự động phát hiện thay đổi để tăng hiệu suất
                        context.ChangeTracker.AutoDetectChangesEnabled = false;

                        // Chia danh sách thành các phần nhỏ (ví dụ: 1000 bản ghi mỗi phần)
                        var batchS = 10000;
                        var batches = batchRecords.Select((item, index) => new { Item = item, Index = index })
                                            .GroupBy(x => x.Index / batchS)
                                            .Select(g => g.Select(x => x.Item).ToList());


                        foreach (var batch in batches)
                        {
                            using (var transaction = context.Database.BeginTransaction())
                            {
                                try
                                {
                                    context.TodStructureOutputContentLbps.AddRange(batch);
                                    context.SaveChanges();

                                    transaction.Commit();
                                }
                                catch
                                {
                                    transaction.Rollback();
                                    throw;
                                }
                            }


                            // Xóa bộ đệm để tránh tràn bộ nhớ
                            context.ChangeTracker.Clear();
                        }


                    }
                    catch (Exception e)
                    {

                        new EmailService().Initial(lstITMail, " exception calculation output with ecn lv2 lbp", e.Message);
                    }
                }
            }
            catch (Exception)
            {

            }



        }

        public async Task RunStructureIJ()
        {
            string product = "IJ";
            try
            {
                await SendMessageToClients($"Structure{product}_{date}", "Processing");
                database.StringSet($"RecMess{Factory}Structure{product}_" + date, "Processing");
                using (var ctx = new PdcsystemContext())
                {
                    var lstMail = ctx.AdmUserInformations.Where(x => x.Active == true
                      && x.AdmDetailUserGroups.Any(y => y.Active == true
                      && y.GroupId == Guid.Parse("99f66340-7ab7-4dac-ac55-fa37bab404d7")))
                          .Include(x => x.AdmDetailUserGroups)
                          .Select(x => x.Email ?? "")
                          .ToList();
                    var ijMerchandise = await ctx.TodStructureMasterMerchandises.Where(x => x.Active == true
                    && x.Model != null && x.DestName != null && x.Merchandise != null
                    && x.Product != null && x.Product.Equals("IJ") && x.ApprovedBy != null && x.ApprovedDate != null && x.Status == "Run")
                        .OrderBy(x => x.Model).ThenBy(x => x.Merchandise)
                        .ToListAsync();

                    var lstMer = ijMerchandise.Select(y => y.Merchandise + "_" + y.Bc).Distinct().ToList();


                    var dtOnly = DateOnly.FromDateTime(DateTime.Now);
                    var checkOff = ctx.AdmMasterCalendars.FirstOrDefault(x => x.DateOfDate == dtOnly);
                    if (checkOff == null || (checkOff != null && checkOff.IjOff == false))
                    {
                        new EmailService().InitialDev(" Start job", "Start job get linkage and output ij");
                        var start = DateTime.Now;
                        await AutoCheckAllIJ();
                        var merh445 = await ctx.MvEucH445s.Select(x => x.NoInParts + "_" + x.CdBlock).Distinct().ToListAsync();
                        if ((merh445.Count >= lstMer.Count && Factory == "TS") || Factory != "TS")
                        {
                            await HeadersIJ();
                            await CheckSourceBeforeRunStructure(product);
                            start = DateTime.Now;
                            await GetOutputIJ(true);
                            await GetOutputECNLV2IJ();
                            _jobClient.Enqueue(() => GetOutputIJALLExcel());
                            _jobClient.Enqueue(() => SendMailWarnJob(product));
                            _jobClient.Enqueue(() => UpdateMasterDeliveryIJ());
                            //await SendMessageToClients($"Structure{product}_{date}", "Finished");
                            //database.StringSet($"RecMess{Factory}Structure{product}_{date}", "Finished");
                            var end = DateTime.Now;

                            try
                            {
                                //////TimeSpan timeSpan = end - start;
                                //////int minutes = Math.Abs(timeSpan.Minutes);
                                var spanTime = (int)DateTime.Now.Subtract(start).TotalSeconds;
                                var link = "http://cvn-vpsi/#/turnoverday/structure/output-structure";
                                string content = "<p style='font-weight: bold;'>Dear [Mrs/Mr]. All,</p>";
                                content += $"<p>The job of get the linkage from npis and the calculation output {product} is done. Completion time is {spanTime} seconds</p>";
                                content += $"<p>Now you can check it at: <a href='{link}'>Click Here</a></p>";
                                new EmailService().Initial(lstMail, " Completed job", content);

                            }
                            catch (Exception)
                            {

                            }
                            _jobClient.Enqueue(() => CalcChangingPointIJ());
                            _jobClient.Enqueue(() => CalcUniquePartIJ());
                            await Task.WhenAll(ManualFunc.GatewayAsync($"CalculateAction/Lt/{product}"));
                        }
                        else
                        {
                            await SendMessageToClients($"Structure{product}_{date}", "Finished");
                            database.StringSet($"RecMess{Factory}Structure{product}_{date}", "Finished");
                            new EmailService().Initial(lstMail, "Warning get euch445", "List merchandise from euch445 less than master merchandise, not get data!");

                        }



                    }
                    else
                    {
                        await SendMessageToClients($"Structure{product}_{date}", "Day off not run!");
                        database.StringSet($"RecMess{Factory}Structure{product}_{date}", "Day off not run!");
                        new EmailService().Initial(lstMail, " Warning job", $"Today is off, not run job calc structure {product}");
                    }
                    DateTime now = DateTime.Now;
                    DateTime targetTime = new DateTime(now.Year, now.Month, now.Day, 9, 0, 0);

                    if (now < targetTime)
                    {
                        HangfireJobList.DelayMinute("PartControl", product, 5);
                        HangfireJobList.DelayMinute("Simulation", product, 10);
                    }
                    else
                    {

                    }
                }
            }
            catch (Exception e)
            {
                await SendMessageToClients($"Structure{product}_{date}", "Error Exception!");
                database.StringSet($"RecMess{Factory}Structure{product}_{date}", "Error Exception!");
                new EmailService().InitialDev($" Error run job structure {product}", e.Message);
            }

        }
        public async Task RunStructureLBP()
        {
            string product = "LBP";
            try
            {

                await SendMessageToClients($"Structure{product}_{date}", "Processing");
                database.StringSet($"RecMess{Factory}Structure{product}_" + date, "Processing");
                using (var ctx = new PdcsystemContext())
                {
                    var lstMail = ctx.AdmUserInformations.Where(x => x.Active == true
                              && x.AdmDetailUserGroups.Any(y => y.Active == true
                              && y.GroupId == Guid.Parse("99f66340-7ab7-4dac-ac55-fa37bab404d7")))
                                  .Include(x => x.AdmDetailUserGroups)
                                  .Select(x => x.Email ?? "")
                                  .ToList();
                    var lbpMerchandise = await ctx.TodStructureMasterMerchandises.Where(x => x.Active == true
                      && x.Model != null && x.DestName != null && x.Merchandise != null
                      && x.Product != null && x.Product.Equals("LBP") && x.ApprovedBy != null && x.ApprovedDate != null && x.Status == "Run")
                          .OrderBy(x => x.Model).ThenBy(x => x.Merchandise)
                          .ToListAsync();

                    var lstMer = lbpMerchandise.Select(y => y.Merchandise + "_" + y.Bc).Distinct().ToList();

                    var dtOnly = DateOnly.FromDateTime(DateTime.Now);
                    var checkOff = ctx.AdmMasterCalendars.FirstOrDefault(x => x.DateOfDate == dtOnly);
                    if (checkOff == null || (checkOff != null && checkOff.LbpOff == false))
                    {
                        //new EmailService().InitialDev(" Start job", "Start job get linkage and output lbp");
                        var start = DateTime.Now;
                        await AutoCheckAllLBP();
                        var merh1701 = await ctx.MvEucH1701s.Select(x => x.NoInParts + "_" + x.CdBlock).Distinct().ToListAsync();

                        if ((merh1701.Count >= lstMer.Count && Factory == "TS") || Factory != "TS")
                        {
                            await HeadersLBP();
                            await CheckSourceBeforeRunStructure(product);
                            start = DateTime.Now;
                            await GetOutputLBP(true);
                            await GetOutputECNLV2LBP();
                            _jobClient.Enqueue(() => SendMailWarnJob(product));
                            _jobClient.Enqueue(() => GetOutputLBPALLExcel());
                            _jobClient.Enqueue(() => UpdateMasterDeliveryLBP());
                            await SendMessageToClients($"Structure{product}_{date}", "Finished");
                            database.StringSet($"RecMess{Factory}Structure{product}_{date}", "Finished");
                            var end = DateTime.Now;

                            try
                            {
                                //////TimeSpan timeSpan = end - start;
                                //////int minutes = Math.Abs(timeSpan.Minutes);
                                var spanTime = (int)DateTime.Now.Subtract(start).TotalSeconds;
                                var link = "http://cvn-vpsi/#/turnoverday/structure/output-structure";
                                string content = "<p style='font-weight: bold;'>Dear [Mrs/Mr]. All,</p>";
                                content += $"<p>The job of get the linkage from npis and the calculation output {product} is done. Completion time is {spanTime} seconds</p>";
                                content += $"<p>Now you can check it at: <a href='{link}'>Click Here</a></p>";
                                new EmailService().Initial(lstMail, " Completed job", content);

                            }
                            catch (Exception)
                            {

                            }
                            _jobClient.Enqueue(() => CalcChangingPointLBP());
                            _jobClient.Enqueue(() => CalcUniquePartLBP());

                            await Task.WhenAll(ManualFunc.GatewayAsync($"CalculateAction/Lt/{product}"));
                        }
                        else
                        {
                            await SendMessageToClients($"Structure{product}_{date}", "Finished");
                            database.StringSet($"RecMess{Factory}Structure{product}_{date}", "Finished");
                            new EmailService().Initial(lstMail, " Warning get euch1701", "List merchandise from euch1701 less than master merchandise, not get data!");

                        }


                    }
                    else
                    {
                        await SendMessageToClients($"Structure{product}_{date}", "Day off not run!");
                        database.StringSet($"RecMess{Factory}Structure{product}_{date}", "Day off not run!");

                        new EmailService().Initial(lstMail, " Warning job", $"Today is off, not run job calc structure {product}");
                    }
                    DateTime now = DateTime.Now;
                    DateTime targetTime = new DateTime(now.Year, now.Month, now.Day, 9, 0, 0);

                    if (now < targetTime)
                    {
                        HangfireJobList.DelayMinute("PartControl", product, 5);
                        HangfireJobList.DelayMinute("Simulation", product, 10);
                    }
                    else
                    {

                    }
                }
            }
            catch (Exception e)
            {
                await SendMessageToClients($"Structure{product}_{date}", "Error Exception!");
                database.StringSet($"RecMess{Factory}Structure{product}_{date}", "Error Exception!");
                new EmailService().InitialDev($" Error run job structure {product}", e.Message);
            }

        }

        public async Task GetOutputMerExcel(string product)
        {
            try
            {
                await SendMessageToClients($"ExportMer{product}_{date}", "Processing");
                database.StringSet($"RecMess{Factory}ExportMer{product}_" + date, "Processing");
                using (var context = new PdcsystemContext())
                {
                    string filePath = Path.Combine(pathServer, "Sample\\OriginalMer.xlsx");
                    FileInfo file = new FileInfo(filePath);
                    ExcelPackage.LicenseContext = LicenseContext.NonCommercial;
                    using (ExcelPackage excelPackage = new ExcelPackage(file))
                    {

                        ExcelWorksheet excelWorksheet;
                        excelWorksheet = excelPackage.Workbook.Worksheets.Add("OriginalMer");
                        var model = new List<string>();
                        if (product.ToUpper() == "IJ")
                        {
                            model = context.VlinkageEucIjH445s
                                .Select(x => x.CdBlock + "_" + x.NoInParts)
                                .Distinct()
                                .ToList();

                        }
                        else
                        {
                            model = context.VlinkageEucLbpH1701s
                                .Select(x => x.CdBlock + "_" + x.NoInParts)
                                .Distinct()
                                .ToList();
                        }
                        excelWorksheet.Cells["A1"].Value = "No";
                        excelWorksheet.Cells["B1"].Value = "BC";
                        excelWorksheet.Cells["C1"].Value = "Merchandise";
                        var row = 2;
                        foreach (var item in model)
                        {
                            var bcMer = item.Split("_");
                            excelWorksheet.Cells["A" + row].Value = row - 1;
                            excelWorksheet.Cells["B" + row].Value = bcMer[0];
                            excelWorksheet.Cells["C" + row].Value = bcMer[1];
                            row++;
                        }
                        excelWorksheet.Cells["A1:C" + row].Style.Font.Size = 11;
                        excelWorksheet.Cells["A1:C1"].Style.Font.Bold = true;
                        excelWorksheet.Cells["A1:C" + row].Style.Border.Top.Style = ExcelBorderStyle.Thin;
                        excelWorksheet.Cells["A1:C" + row].Style.Border.Bottom.Style = ExcelBorderStyle.Thin;
                        excelWorksheet.Cells["A1:C" + row].Style.Border.Left.Style = ExcelBorderStyle.Thin;
                        excelWorksheet.Cells["A1:C" + row].Style.Border.Right.Style = ExcelBorderStyle.Thin;

                        string outputPath = Path.Combine(pathServer, "FileOutput\\OutPutMer"+product, "OutPutMer_"+product+"_" + DateTime.Now.ToString("yyyy-MM-dd") + ".xlsx");
                        FileInfo excelFile = new FileInfo(outputPath);
                        excelPackage.SaveAs(excelFile);
                        await SendMessageToClients($"ExportMer{product}_{date}", "Finished");
                        database.StringSet($"RecMess{Factory}ExportMer{product}_" + date, "Finished");
                    }
                }
            }
            catch (Exception e)
            {
                await SendMessageToClients($"ExportMer{product}_{date}", "Except export");
                database.StringSet($"RecMess{Factory}ExportMer{product}_" + date, "Except export");
                Console.WriteLine("Except " + e);
            }

        }
        #endregion


        public async Task CheckSourceBeforeRunStructure(string product)
        {
            var lst = await ADO.CheckBeforeCalculateStructure2(product);
            var stringTable = @"<table><tr><th>STT</th><th>Data Source</th><th>Created Date</th><th>Rows Total</th></tr>";
            for (var i = 0; i < lst.Count; i++)
            {
                var item = lst[i];
                stringTable += @"<tr>
                <td style='text-align: center;'>" + (i + 1) + @"</td>
                <td style='text-align: left;'>" + item.data_source + @"</td>
                <td style='text-align: center;'>" + item.created_date + @"</td>
                <td style='text-align: center;'>" + item.rows_total + @"</td>
              </tr>";

            }
            stringTable += "</table>";

            new EmailService().InitialDev($"Check source before Run Structure {product.ToUpper()}", $@"<p style='font-weight: bold;'>Dear [Mrs/Mr]. Developer,</p>
                <p>You have received a notification about <span style='font-weight: bold; color: red; font-style: italic;'>Report check data source before Run Structure {product.ToUpper()}</span> from PSI System. Please check: </p><p>{stringTable}</p>");



        }
        public async Task UpdatePicOPStructureAferApproved(string product)
        {
            string uproduct = product.ToUpper();
            DateTime start = DateTime.Now;
            if (uproduct == "IJ")
            {
                await SendMessageToClients($"Structure{uproduct}_{date}", "Updating new job assignment");
                database.StringSet($"RecMess{Factory}Structure{uproduct}_{date}", "Updating new job assignment");
                using (var context = new PdcsystemContext())
                {
                    var masterjob = await context.PcPaPartJobAssignments.Where(x => x.Active == true && x.ApprovalDate != null && x.ApprovalBy != null && x.Product != null && x.Product.ToUpper() == uproduct).ToListAsync();
                    var check = masterjob.Any(x => x.Active == true);
                    if (check == true)
                    {
                        var lstOutput = await context.TodStructureOutputContentIjs.Where(x => x.Active == true).ToListAsync();
                        var batchRecords = lstOutput.AsParallel().Select(im =>
                        {
                            var lJob = masterjob.FirstOrDefault(x => x.PartNo == im.PartNo8 && x.Vendor == im.Bc12);

                            if (lJob != null)
                            {
                                im.DoPic43 = lJob.DoPic;
                                im.PoPic44 = lJob.PicPo;
                            }

                            return im;
                        }).ToList();
                        // Tắt tự động phát hiện thay đổi để tăng hiệu suất
                        context.ChangeTracker.AutoDetectChangesEnabled = false;

                        // Chia danh sách thành các phần nhỏ (ví dụ: 1000 bản ghi mỗi phần)
                        var batchS = 10000;
                        var batches = batchRecords.Select((item, index) => new { Item = item, Index = index })
                                            .GroupBy(x => x.Index / batchS)
                                            .Select(g => g.Select(x => x.Item).ToList());


                        foreach (var batch in batches)
                        {
                            context.TodStructureOutputContentIjs.UpdateRange(batch);
                            context.SaveChanges();
                            // Xóa bộ đệm để tránh tràn bộ nhớ
                            context.ChangeTracker.Clear();
                        }
                        await GetOutputIJALLExcel();
                        await SendMessageToClients($"Structure{uproduct}_{date}", "Finished");
                        database.StringSet($"RecMess{Factory}Structure{uproduct}_{date}", "Finished");
                        NoticeFinishJob("part job assignment", uproduct, start);
                        var amtLackPic = batchRecords.Where(x => x.PoPic44 == null || x.PoPic44 == "" || x.DoPic43 == null || x.DoPic43 == "").ToList();
                        var conectModel = amtLackPic.Where(x => x.Model45 != null && x.Model45 != "").ToList();
                        var notConectModel = amtLackPic.Where(x => x.Model45 == null || x.Model45 == "").ToList();
                        var groupWaring = context.AdmDetailUserGroups.Include(x => x.User).Where(x => x.Active == true && x.GroupId == new Guid("c3578880-22bf-4020-8215-469afae1e4a1")).ToList();
                        var lstReceiver = groupWaring.Where(x => x.User != null && x.User.Email != null && x.User.Email != "").Select(x => x.User.Email).ToList();
                        ExcelPackage.LicenseContext = LicenseContext.NonCommercial;
                        using (ExcelPackage excelPackage = new ExcelPackage())
                        {
                            ExcelWorksheet excelWorksheet;
                            excelWorksheet = excelPackage.Workbook.Worksheets.Add("Sheet1");
                            excelWorksheet.Cells["A1"].Value = "No";
                            excelWorksheet.Cells["B1"].Value = "Part no";
                            excelWorksheet.Cells["C1"].Value = "Do PIC";
                            excelWorksheet.Cells["D1"].Value = "Po PIC";
                            excelWorksheet.Cells["E1"].Value = "Model";
                            int i = 2;
                            foreach (var item in amtLackPic)
                            {
                                string?[] model = item.Model45?.Split(',');
                                string?[] hashModel = model?.Distinct().ToArray();
                                string? resultModel = hashModel == null ? null : string.Join("+", hashModel);

                                excelWorksheet.Cells["A" + i].Value = i - 1;
                                excelWorksheet.Cells["B" + i].Value = item.PartNo8;
                                excelWorksheet.Cells["C" + i].Value = item.DoPic43;
                                excelWorksheet.Cells["D" + i].Value = item.PoPic44;
                                excelWorksheet.Cells["E" + i].Value = resultModel;
                                i++;
                            }

                            excelWorksheet.Cells["A2:E" + i].Style.Font.Size = 11;
                            excelWorksheet.Cells["A2:E" + i].Style.Font.Name = "Calibri";
                            excelWorksheet.Cells["A2:E" + i].Style.Border.Top.Style = ExcelBorderStyle.Thin;
                            excelWorksheet.Cells["A2:E" + i].Style.Border.Bottom.Style = ExcelBorderStyle.Thin;
                            excelWorksheet.Cells["A2:E" + i].Style.Border.Left.Style = ExcelBorderStyle.Thin;
                            excelWorksheet.Cells["A2:E" + i].Style.Border.Right.Style = ExcelBorderStyle.Thin;

                            NoticeWarningJob(amtLackPic.Count, conectModel.Count, notConectModel.Count, lstReceiver,
                                excelPackage.GetAsByteArray(), "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", $"Warning Lack PIC{uproduct}_{DateTime.Now.ToString("dd-MM-yyyy")}.xlsx");


                        }

                    }
                }

            }
            else
            {
                await SendMessageToClients($"Structure{uproduct}_{date}", "Updating new job assignment");
                database.StringSet($"RecMess{Factory}Structure{uproduct}_{date}", "Updating new job assignment");
                using (var context = new PdcsystemContext())
                {
                    var masterjob = await context.PcPaPartJobAssignments.Where(x => x.Active == true && x.ApprovalDate != null && x.ApprovalBy != null && x.Product != null && x.Product.ToUpper() == "LBP").ToListAsync();
                    var check = masterjob.Any(x => x.Active == true);
                    if (check == true)
                    {
                        var lstOutput = await context.TodStructureOutputContentLbps.Where(x => x.Active == true).ToListAsync();
                        var batchRecords = lstOutput.AsParallel().Select(im =>
                        {
                            var lJob = masterjob.FirstOrDefault(x => x.PartNo == im.PartNo8 && x.Vendor == im.Bc12);

                            if (lJob != null)
                            {
                                im.DoPic43 = lJob.DoPic;
                                im.PoPic44 = lJob.PicPo;
                            }

                            return im;
                        }).ToList();
                        // Tắt tự động phát hiện thay đổi để tăng hiệu suất
                        context.ChangeTracker.AutoDetectChangesEnabled = false;

                        // Chia danh sách thành các phần nhỏ (ví dụ: 1000 bản ghi mỗi phần)
                        var batchS = 10000;
                        var batches = batchRecords.Select((item, index) => new { Item = item, Index = index })
                                            .GroupBy(x => x.Index / batchS)
                                            .Select(g => g.Select(x => x.Item).ToList());


                        foreach (var batch in batches)
                        {
                            context.TodStructureOutputContentLbps.UpdateRange(batch);
                            context.SaveChanges();
                            // Xóa bộ đệm để tránh tràn bộ nhớ
                            context.ChangeTracker.Clear();
                        }
                        await GetOutputLBPALLExcel();
                        await SendMessageToClients($"Structure{uproduct}_{date}", "Finished");
                        database.StringSet($"RecMess{Factory}Structure{uproduct}_{date}", "Finished");
                        NoticeFinishJob("part job assignment", uproduct, start);
                        var amtLackPic = batchRecords.Where(x => x.PoPic44 == null || x.PoPic44 == "" || x.DoPic43 == null || x.DoPic43 == "").ToList();
                        var conectModel = amtLackPic.Where(x => x.Model45 != null && x.Model45 != "").ToList();
                        var notConectModel = amtLackPic.Where(x => x.Model45 == null || x.Model45 == "").ToList();
                        var groupWaring = context.AdmDetailUserGroups.Include(x => x.User).Where(x => x.Active == true && x.GroupId == new Guid("c3578880-22bf-4020-8215-469afae1e4a1")).ToList();
                        var lstReceiver = groupWaring.Where(x => x.User != null && x.User.Email != null && x.User.Email != "").Select(x => x.User.Email).ToList();
                        ExcelPackage.LicenseContext = LicenseContext.NonCommercial;
                        using (ExcelPackage excelPackage = new ExcelPackage())
                        {
                            ExcelWorksheet excelWorksheet;
                            excelWorksheet = excelPackage.Workbook.Worksheets.Add("Sheet1");
                            excelWorksheet.Cells["A1"].Value = "No";
                            excelWorksheet.Cells["B1"].Value = "Part no";
                            excelWorksheet.Cells["C1"].Value = "Do PIC";
                            excelWorksheet.Cells["D1"].Value = "Po PIC";
                            excelWorksheet.Cells["E1"].Value = "Model";
                            int i = 2;
                            foreach (var item in amtLackPic)
                            {
                                string?[] model = item.Model45?.Split(',');
                                string?[] hashModel = model?.Distinct().ToArray();
                                string? resultModel = hashModel == null ? null : string.Join("+", hashModel);

                                excelWorksheet.Cells["A" + i].Value = i - 1;
                                excelWorksheet.Cells["B" + i].Value = item.PartNo8;
                                excelWorksheet.Cells["C" + i].Value = item.DoPic43;
                                excelWorksheet.Cells["D" + i].Value = item.PoPic44;
                                excelWorksheet.Cells["E" + i].Value = resultModel;
                                i++;
                            }

                            excelWorksheet.Cells["A2:E" + i].Style.Font.Size = 11;
                            excelWorksheet.Cells["A2:E" + i].Style.Font.Name = "Calibri";
                            excelWorksheet.Cells["A2:E" + i].Style.Border.Top.Style = ExcelBorderStyle.Thin;
                            excelWorksheet.Cells["A2:E" + i].Style.Border.Bottom.Style = ExcelBorderStyle.Thin;
                            excelWorksheet.Cells["A2:E" + i].Style.Border.Left.Style = ExcelBorderStyle.Thin;
                            excelWorksheet.Cells["A2:E" + i].Style.Border.Right.Style = ExcelBorderStyle.Thin;

                            NoticeWarningJob(amtLackPic.Count, conectModel.Count, notConectModel.Count, lstReceiver,
                                excelPackage.GetAsByteArray(), "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", $"Warning Lack PIC{uproduct}_{DateTime.Now.ToString("dd-MM-yyyy")}.xlsx");


                        }

                    }
                }

            }
        }
        public async Task UpdateStructureAfterApproved(string masterType, string product)
        {
            string uproduct = product.ToUpper();
            DateTime start = DateTime.Now;
            if (uproduct == "IJ")
            {
                using (var context = new PdcsystemContext())
                {
                    var lstOutput = await context.TodStructureOutputContentIjs.Where(x => x.Active == true).ToListAsync();
                    if (masterType.Equals("delivery"))
                    {
                        await SendMessageToClients($"Structure{uproduct}_{date}", "Updating new delivery");
                        database.StringSet($"RecMess{Factory}Structure{uproduct}_{date}", "Updating new delivery");

                        var masterdelivery = await context.TodStructureMasterDeliveries.Where(x => x.Active == true && x.ApprovedDate != null && x.ApprovedBy != null && x.Product != null && x.Product.ToUpper() == "IJ").ToListAsync();
                        var check = masterdelivery.Any(x => x.Active == true);
                        if (check == true)
                        {
                            var batchRecords = lstOutput.AsParallel().Select(im =>
                            {
                                var iDel = masterdelivery.FirstOrDefault(x => x.VendorCode == im.Bc12);
                                if (iDel != null)
                                {
                                    im.MethodDelivery24 = iDel.MethodDelivery;
                                    im.Location125 = iDel.Location1;
                                    im.Location226 = iDel.Location2;
                                    im.Location327 = iDel.Location3;
                                    im.RouteDelivery28 = iDel.RouteDelivery;
                                    im.PartDelMoving29 = iDel.PartDelivMoving;
                                    im.Day30 = iDel.DelivFreqDay;
                                    im.Night31 = iDel.DelivFreqNight;
                                    im.Week32 = iDel.DelivFreqWeek;
                                    im.Name20 = iDel.Name;
                                }


                                return im;
                            }).ToList();




                            // Tắt tự động phát hiện thay đổi để tăng hiệu suất
                            context.ChangeTracker.AutoDetectChangesEnabled = false;

                            // Chia danh sách thành các phần nhỏ (ví dụ: 1000 bản ghi mỗi phần)
                            var batchS = 10000;
                            var batches = batchRecords.Select((item, index) => new { Item = item, Index = index })
                                                .GroupBy(x => x.Index / batchS)
                                                .Select(g => g.Select(x => x.Item).ToList());


                            foreach (var batch in batches)
                            {
                                context.TodStructureOutputContentIjs.UpdateRange(batch);
                                context.SaveChanges();
                                // Xóa bộ đệm để tránh tràn bộ nhớ
                                context.ChangeTracker.Clear();
                            }
                            await GetOutputIJALLExcel();
                            await SendMessageToClients($"Structure{uproduct}_{date}", "Finished");
                            database.StringSet($"RecMess{Factory}Structure{uproduct}_{date}", "Finished");
                            NoticeFinishJob("delivery", uproduct, start);
                        }

                    }
                    else if (masterType.Equals("packing"))
                    {
                        await SendMessageToClients($"Structure{uproduct}_{date}", "Updating new packing");
                        database.StringSet($"RecMess{Factory}Structure{uproduct}_{date}", "Updating new packing");
                        var masterpacking = await context.TodStructureMasterPackings.Where(x => x.Active == true && x.ApprovedDate != null && x.ApprovedBy != null).ToListAsync();
                        var batchRecords = lstOutput.AsParallel().Select(im =>
                        {
                            var iPacking = masterpacking.FirstOrDefault(x => x.PartNo == im.PartNo8 && x.Vendor == im.Bc12);

                            if (iPacking != null)
                            {
                                im.Moq35 = iPacking.Moq;
                                im.Pcsbox36 = iPacking.PcsBox;
                                im.Boxpl37 = iPacking.BoxPallet;
                                im.Pcspl38 = iPacking.PcsPallet;
                            }

                            //var key = "mvoutputall";
                            //var field = im.Id.ToString();
                            //database.HashSet(key, field, JsonConvert.SerializeObject(im));
                            return im;
                        }).ToList();




                        // Tắt tự động phát hiện thay đổi để tăng hiệu suất
                        context.ChangeTracker.AutoDetectChangesEnabled = false;

                        // Chia danh sách thành các phần nhỏ (ví dụ: 1000 bản ghi mỗi phần)
                        var batchS = 10000;
                        var batches = batchRecords.Select((item, index) => new { Item = item, Index = index })
                                            .GroupBy(x => x.Index / batchS)
                                            .Select(g => g.Select(x => x.Item).ToList());


                        foreach (var batch in batches)
                        {
                            context.TodStructureOutputContentIjs.UpdateRange(batch);
                            context.SaveChanges();
                            // Xóa bộ đệm để tránh tràn bộ nhớ
                            context.ChangeTracker.Clear();
                        }
                        await GetOutputIJALLExcel();
                        await SendMessageToClients($"Structure{uproduct}_{date}", "Finished");
                        database.StringSet($"RecMess{Factory}Structure{uproduct}_{date}", "Finished");
                        NoticeFinishJob("packing", uproduct, start);

                    }
                    else if (masterType.Equals("temporaryconnect"))
                    {
                        await SendMessageToClients($"Structure{uproduct}_{date}", "Updating new temporary connect");
                        database.StringSet($"RecMess{Factory}Structure{uproduct}_{date}", "Updating new temporary connect");

                        //////var outputij = await context.TodStructureOutputContentIjs.Where(x => x.Active == true).ToListAsync();
                        //////context.TodStructureOutputContentIjs.RemoveRange(outputij);
                        //////context.SaveChanges();
                        var ijMerchandise = await context.TodStructureMasterMerchandises.Where(x => x.Active == true
                         && x.Model != null && x.DestName != null && x.Merchandise != null
                         && x.Product != null && x.Product.Equals("IJ") && x.ApprovedBy != null && x.ApprovedDate != null && x.Status == "Run")
                             .OrderBy(x => x.Model).ThenBy(x => x.Merchandise)
                             .ToListAsync();

                        var lstMer = ijMerchandise.Select(y => y.Merchandise + "_" + y.Bc).Distinct().ToList();
                        var merh445 = await context.MvEucH445s.Select(x => x.NoInParts + "_" + x.CdBlock).Distinct().ToListAsync();
                        if ((merh445.Count >= lstMer.Count && Factory == "TS") || Factory != "TS")
                        {
                            await ADO.doChangeAsync($"delete from public.tod_structure_output_content_{product.ToLower()};");

                            // await _manual.HeadersIJ();
                            await GetOutputIJ(true);
                            await GetOutputECNLV2IJ();
                            await GetOutputIJALLExcel();
                            NoticeFinishJob("temporary connect", uproduct, start);
                            await CalcChangingPointIJ();
                            await CalcUniquePartIJ();
                        }
                        else
                        {
                            var lstMail = context.AdmUserInformations.Where(x => x.Active == true
                              && x.AdmDetailUserGroups.Any(y => y.Active == true
                              && y.GroupId == Guid.Parse("99f66340-7ab7-4dac-ac55-fa37bab404d7")))
                                  .Include(x => x.AdmDetailUserGroups)
                                  .Select(x => x.Email ?? "")
                                  .ToList();
                            new EmailService().Initial(lstMail, "Warning update Temporary connect IJ", "List merchandise from euch445 less than master merchandise, not get data!");
                        }
                        await SendMessageToClients($"Structure{uproduct}_{date}", "Finished");
                        database.StringSet($"RecMess{Factory}Structure{uproduct}_{date}", "Finished");

                    }
                    else if (masterType.Equals("merchandise"))
                    {
                        await SendMessageToClients($"Structure{uproduct}_{date}", "Updating new merchandise");
                        database.StringSet($"RecMess{Factory}Structure{uproduct}_{date}", "Updating new merchandise");

                        await RunStructureIJ();
                        NoticeFinishJob("master merchandise", uproduct, start);

                    }
                    await SendMessageToClients($"Structure{uproduct}_{date}", "Finished");
                    database.StringSet($"RecMess{Factory}Structure{uproduct}_{date}", "Finished");
                }
            }
            else
            {
                using (var context = new PdcsystemContext())
                {
                    var lstOutput = await context.TodStructureOutputContentLbps.Where(x => x.Active == true).ToListAsync();
                    if (masterType.Equals("delivery"))
                    {
                        await SendMessageToClients($"Structure{uproduct}_{date}", "Updating new delivery");
                        database.StringSet($"RecMess{Factory}Structure{uproduct}_{date}", "Updating new delivery");
                        var masterdelivery = await context.TodStructureMasterDeliveries.Where(x => x.Active == true && x.ApprovedDate != null && x.ApprovedBy != null && x.Product != null && x.Product.ToUpper() == "LBP").ToListAsync();
                        var check = masterdelivery.Any(x => x.Active == true);
                        if (check == true)
                        {
                            var batchRecords = lstOutput.AsParallel().Select(im =>
                            {

                                var lDel = masterdelivery.FirstOrDefault(x => x.VendorCode == im.Bc12);

                                if (lDel != null)
                                {
                                    im.MethodDelivery24 = lDel.MethodDelivery;
                                    im.Location125 = lDel.Location1;
                                    im.Location226 = lDel.Location2;
                                    im.Location327 = lDel.Location3;
                                    im.RouteDelivery28 = lDel.RouteDelivery;
                                    im.PartDelMoving29 = lDel.PartDelivMoving;
                                    im.Day30 = lDel.DelivFreqDay;
                                    im.Night31 = lDel.DelivFreqNight;
                                    im.Week32 = lDel.DelivFreqWeek;
                                    im.Name20 = lDel.Name;
                                }


                                return im;
                            }).ToList();




                            // Tắt tự động phát hiện thay đổi để tăng hiệu suất
                            context.ChangeTracker.AutoDetectChangesEnabled = false;

                            // Chia danh sách thành các phần nhỏ (ví dụ: 1000 bản ghi mỗi phần)
                            var batchS = 10000;
                            var batches = batchRecords.Select((item, index) => new { Item = item, Index = index })
                                                .GroupBy(x => x.Index / batchS)
                                                .Select(g => g.Select(x => x.Item).ToList());


                            foreach (var batch in batches)
                            {
                                context.TodStructureOutputContentLbps.UpdateRange(batch);
                                context.SaveChanges();
                                // Xóa bộ đệm để tránh tràn bộ nhớ
                                context.ChangeTracker.Clear();
                            }
                            await GetOutputLBPALLExcel();
                            await SendMessageToClients($"Structure{uproduct}_{date}", "Finished");
                            database.StringSet($"RecMess{Factory}Structure{uproduct}_{date}", "Finished");
                            NoticeFinishJob("delivery", uproduct, start);
                        }

                    }
                    else if (masterType.Equals("packing"))
                    {
                        await SendMessageToClients($"Structure{uproduct}_{date}", "Updating new packing");
                        database.StringSet($"RecMess{Factory}Structure{uproduct}_{date}", "Updating new packing");
                        var masterpacking = await context.TodStructureMasterPackings.Where(x => x.Active == true && x.ApprovedDate != null && x.ApprovedBy != null).ToListAsync();
                        var batchRecords = lstOutput.AsParallel().Select(im =>
                        {
                            var iPacking = masterpacking.FirstOrDefault(x => x.PartNo == im.PartNo8 && x.Vendor == im.Bc12);

                            if (iPacking != null)
                            {
                                im.Moq35 = iPacking.Moq;
                                im.Pcsbox36 = iPacking.PcsBox;
                                im.Boxpl37 = iPacking.BoxPallet;
                                im.Pcspl38 = iPacking.PcsPallet;
                            }


                            return im;
                        }).ToList();



                        // Tắt tự động phát hiện thay đổi để tăng hiệu suất
                        context.ChangeTracker.AutoDetectChangesEnabled = false;

                        // Chia danh sách thành các phần nhỏ (ví dụ: 1000 bản ghi mỗi phần)
                        var batchS = 10000;
                        var batches = batchRecords.Select((item, index) => new { Item = item, Index = index })
                                            .GroupBy(x => x.Index / batchS)
                                            .Select(g => g.Select(x => x.Item).ToList());


                        foreach (var batch in batches)
                        {
                            context.TodStructureOutputContentLbps.UpdateRange(batch);
                            context.SaveChanges();
                            // Xóa bộ đệm để tránh tràn bộ nhớ
                            context.ChangeTracker.Clear();
                        }
                        await GetOutputLBPALLExcel();
                        await SendMessageToClients($"Structure{uproduct}_{date}", "Finished");
                        database.StringSet($"RecMess{Factory}Structure{uproduct}_{date}", "Finished");
                        NoticeFinishJob("packing", uproduct, start);
                    }
                    else if (masterType.Equals("temporaryconnect"))
                    {
                        await SendMessageToClients($"Structure{uproduct}_{date}", "Updating new temporary connect");
                        database.StringSet($"RecMess{Factory}Structure{uproduct}_{date}", "Updating new temporary connect");

                        //////var outputlbp = context.TodStructureOutputContentLbps.Where(x => x.Active == true).ToList();
                        //////context.TodStructureOutputContentLbps.RemoveRange(outputlbp);
                        //////context.SaveChanges();
                        var lbpMerchandise = await context.TodStructureMasterMerchandises.Where(x => x.Active == true
                         && x.Model != null && x.DestName != null && x.Merchandise != null
                         && x.Product != null && x.Product.Equals("LBP") && x.ApprovedBy != null && x.ApprovedDate != null && x.Status == "Run")
                             .OrderBy(x => x.Model).ThenBy(x => x.Merchandise)
                             .ToListAsync();

                        var lstMer = lbpMerchandise.Select(y => y.Merchandise + "_" + y.Bc).Distinct().ToList();
                        var merh17101 = await context.MvEucH1701s.Select(x => x.NoInParts + "_" + x.CdBlock).Distinct().ToListAsync();
                        if ((merh17101.Count >= lstMer.Count && Factory == "TS") || Factory != "TS")
                        {
                            await ADO.doChangeAsync($"delete from public.tod_structure_output_content_{product.ToLower()};");

                            // await HeadersLBP();
                            await GetOutputLBP(true);
                            await GetOutputECNLV2LBP();
                            await GetOutputLBPALLExcel();
                            await CalcChangingPointLBP();
                            await CalcUniquePartLBP();
                            NoticeFinishJob("temporary connect", uproduct, start);
                        }
                        else
                        {
                            var lstMail = context.AdmUserInformations.Where(x => x.Active == true
                              && x.AdmDetailUserGroups.Any(y => y.Active == true
                              && y.GroupId == Guid.Parse("99f66340-7ab7-4dac-ac55-fa37bab404d7")))
                                  .Include(x => x.AdmDetailUserGroups)
                                  .Select(x => x.Email ?? "")
                                  .ToList();

                            new EmailService().Initial(lstMail, "Warning update Temporary connect LBP", "List merchandise from euch1701 less than master merchandise, not get data!");
                        }
                        await SendMessageToClients($"Structure{uproduct}_{date}", "Finished");
                        database.StringSet($"RecMess{Factory}Structure{uproduct}_{date}", "Finished");

                    }
                    else if (masterType.Equals("merchandise"))
                    {
                        await SendMessageToClients($"Structure{uproduct}_{date}", "Updating new merchandise");
                        database.StringSet($"RecMess{Factory}Structure{uproduct}_{date}", "Updating new merchandise");


                        await RunStructureLBP();
                        NoticeFinishJob("master merchandise", uproduct, start);

                        await SendMessageToClients($"Structure{uproduct}_{date}", "Finished");
                        database.StringSet($"RecMess{Factory}Structure{uproduct}_{date}", "Finished");
                    }
                }
            }
        }
        public async Task SendMailWarnJob(string product)
        {
            if (product.ToUpper() == "IJ")
            {
                using (var context = new PdcsystemContext())
                {
                    var batchRecords = await context.TodStructureOutputContentIjs.Where(x => x.Active == true).ToListAsync();
                    var amtLackPic = batchRecords.Where(x => x.PoPic44 == null || x.PoPic44 == "" || x.DoPic43 == null || x.DoPic43 == "").ToList();
                    var conectModel = amtLackPic.Where(x => x.Model45 != null && x.Model45 != "").ToList();
                    var notConectModel = amtLackPic.Where(x => x.Model45 == null || x.Model45 == "").ToList();
                    var groupWaring = context.AdmDetailUserGroups.Include(x => x.User).Where(x => x.Active == true && x.GroupId == new Guid("c3578880-22bf-4020-8215-469afae1e4a1")).ToList();
                    var lstReceiver = groupWaring.Where(x => x.User.Email != null && x.User.Email != "").Select(x => x.User.Email).ToList();
                    ExcelPackage.LicenseContext = LicenseContext.NonCommercial;
                    using (ExcelPackage excelPackage = new ExcelPackage())
                    {
                        ExcelWorksheet excelWorksheet;
                        excelWorksheet = excelPackage.Workbook.Worksheets.Add("Sheet1");
                        excelWorksheet.Cells["A1"].Value = "No";
                        excelWorksheet.Cells["B1"].Value = "Part no";
                        excelWorksheet.Cells["C1"].Value = "Do PIC";
                        excelWorksheet.Cells["D1"].Value = "Po PIC";
                        excelWorksheet.Cells["E1"].Value = "Model";
                        int i = 2;
                        foreach (var item in amtLackPic)
                        {
                            string?[] model = item.Model45?.Split(',');
                            string?[] hashModel = model?.Distinct().ToArray();
                            string? resultModel = hashModel == null ? null : string.Join("+", hashModel);

                            excelWorksheet.Cells["A" + i].Value = i - 1;
                            excelWorksheet.Cells["B" + i].Value = item.PartNo8;
                            excelWorksheet.Cells["C" + i].Value = item.DoPic43;
                            excelWorksheet.Cells["D" + i].Value = item.PoPic44;
                            excelWorksheet.Cells["E" + i].Value = resultModel;
                            i++;
                        }

                        excelWorksheet.Cells["A2:E" + i].Style.Font.Size = 11;
                        excelWorksheet.Cells["A2:E" + i].Style.Font.Name = "Calibri";
                        excelWorksheet.Cells["A2:E" + i].Style.Border.Top.Style = ExcelBorderStyle.Thin;
                        excelWorksheet.Cells["A2:E" + i].Style.Border.Bottom.Style = ExcelBorderStyle.Thin;
                        excelWorksheet.Cells["A2:E" + i].Style.Border.Left.Style = ExcelBorderStyle.Thin;
                        excelWorksheet.Cells["A2:E" + i].Style.Border.Right.Style = ExcelBorderStyle.Thin;

                        NoticeWarningJob(amtLackPic.Count, conectModel.Count, notConectModel.Count, lstReceiver,
                            excelPackage.GetAsByteArray(), "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", "Warning Lack PICIJ_" + DateTime.Now.ToString("dd-MM-yyyy") + ".xlsx");
                    }
                }

            }
            else
            {
                using (var context = new PdcsystemContext())
                {
                    var batchRecords = await context.TodStructureOutputContentLbps.Where(x => x.Active == true).ToListAsync();
                    var amtLackPic = batchRecords.Where(x => x.PoPic44 == null || x.PoPic44 == "" || x.DoPic43 == null || x.DoPic43 == "").ToList();
                    var conectModel = amtLackPic.Where(x => x.Model45 != null && x.Model45 != "").ToList();
                    var notConectModel = amtLackPic.Where(x => x.Model45 == null || x.Model45 == "").ToList();
                    var groupWaring = context.AdmDetailUserGroups.Include(x => x.User).Where(x => x.Active == true && x.GroupId == new Guid("c3578880-22bf-4020-8215-469afae1e4a1")).ToList();
                    var lstReceiver = groupWaring.Where(x => x.User.Email != null && x.User.Email != "").Select(x => x.User.Email).ToList();
                    ExcelPackage.LicenseContext = LicenseContext.NonCommercial;
                    using (ExcelPackage excelPackage = new ExcelPackage())
                    {
                        ExcelWorksheet excelWorksheet;
                        excelWorksheet = excelPackage.Workbook.Worksheets.Add("Sheet1");
                        excelWorksheet.Cells["A1"].Value = "No";
                        excelWorksheet.Cells["B1"].Value = "Part no";
                        excelWorksheet.Cells["C1"].Value = "Do PIC";
                        excelWorksheet.Cells["D1"].Value = "Po PIC";
                        excelWorksheet.Cells["E1"].Value = "Model";
                        int i = 2;
                        foreach (var item in amtLackPic)
                        {
                            string?[] model = item.Model45?.Split(',');
                            string?[] hashModel = model?.Distinct().ToArray();
                            string? resultModel = hashModel == null ? null : string.Join("+", hashModel);

                            excelWorksheet.Cells["A" + i].Value = i - 1;
                            excelWorksheet.Cells["B" + i].Value = item.PartNo8;
                            excelWorksheet.Cells["C" + i].Value = item.DoPic43;
                            excelWorksheet.Cells["D" + i].Value = item.PoPic44;
                            excelWorksheet.Cells["E" + i].Value = resultModel;
                            i++;
                        }

                        excelWorksheet.Cells["A2:E" + i].Style.Font.Size = 11;
                        excelWorksheet.Cells["A2:E" + i].Style.Font.Name = "Calibri";
                        excelWorksheet.Cells["A2:E" + i].Style.Border.Top.Style = ExcelBorderStyle.Thin;
                        excelWorksheet.Cells["A2:E" + i].Style.Border.Bottom.Style = ExcelBorderStyle.Thin;
                        excelWorksheet.Cells["A2:E" + i].Style.Border.Left.Style = ExcelBorderStyle.Thin;
                        excelWorksheet.Cells["A2:E" + i].Style.Border.Right.Style = ExcelBorderStyle.Thin;

                        NoticeWarningJob(amtLackPic.Count, conectModel.Count, notConectModel.Count, lstReceiver,
                            excelPackage.GetAsByteArray(), "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", "Warning Lack PICLBP_" + DateTime.Now.ToString("dd-MM-yyyy") + ".xlsx");
                    }
                }
            }

        }

        public void NoticeFinishJob(string? type, string? product, DateTime start)
        {
            //var listMail = new List<string>() {
            //        "pdc-ie2@canon-vn.com.vn",
            //        "tpdc-adm35@canon-vn.com.vn",
            //        "tspdc-mm01@canon-vn.com.vn",
            //        "tpdc-adm47@canon-vn.com.vn",
            //        "ts-pdc1303@local.canon-vn.com.vn"};
            try
            {
                var spanTime = (int)DateTime.Now.Subtract(start).TotalSeconds;
                var link = "http://cvn-vpsi/#/turnoverday/structure/output-structure";
                string content = "<p>Hey Sirs,</p>\n";
                content += $"<p>Output {product} was complete update with new {type} data in {spanTime} seconds </p>\n";
                content += $"<p>Now you can check it at: <a href='{link}'>Click Here</a></p>\n";
                new EmailService().Initial(lstPDCMail, "[PSI-System] Completed update output " + product, content);

            }
            catch (Exception)
            {

            }
        }

        public void NoticeWarningJob(int? total, int? connect, int? notconnect, List<string> lstReceiver, byte[] attachmentData, string attachmentContentType, string attachmentFileName)
        {

            try
            {

                string content = "<p  style = 'font-weight: bold;'>Dear [Mrs/Mr]. All,</p>\n";
                content += "<p>Affter update job assignment have some part lack PO/DO PIC: </p>\n";
                content += "<p>  -Amount part lack PO/DO PIC: " + total + "</p>\n";
                content += "<p>  -Amount part lack PO/DO PIC connect model: " + connect + "</p>\n";
                content += "<p>  -Amount part lack PO/DO PIC not connect model: " + notconnect + "</p>\n";
                new EmailService().InitialAttach(lstReceiver, "[PSI-System] Warning update Job Assignment", content, attachmentData, attachmentContentType, attachmentFileName);

            }
            catch (Exception)
            {

            }
        }
        public async Task SendMessageToClients(string param, string message)
        {
            await _hubContext.Clients.All.SendAsync("RecMess" + Factory + param, message);
        }

    }

}





