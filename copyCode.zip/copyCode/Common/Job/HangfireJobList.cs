﻿using Hangfire;
using Hangfire.Storage;
using PDCProjectApi.Data;
using PDCProjectApi.Services;
using Quartz;
using Quartz.Impl.Calendar;

namespace PDCProjectApi.Common.Job
{
    public static class HangfireJobList
    {
        private static readonly IGlobalVariable global = new GlobalVariable();
        private static readonly List<string> lstProduct = global.ReturnProduct();
        private static readonly List<string> lstFuncDebut = global.ReturnFuncDebut();
        private static readonly string factory = global.ReturnFactory();
        public static void ServerScheduleJobs()
        {
            var recurringJobOptions = new RecurringJobOptions
            {
                TimeZone = TimeZoneInfo.Local
            };
            var lstDto = new List<RecurringJobDto>();
            foreach(var p in lstProduct)
            {
                if (lstFuncDebut.Contains("partcontrol"))
                {
                    RecurringJob.AddOrUpdate($"UserExportTodPartControl{p}", () => ManualFunc.GatewayAsync($"UserExportAction/Tod/{p}/1"), Cron.Never(), recurringJobOptions);
                    RecurringJob.AddOrUpdate($"UserExportTodDeadline{p}", () => ManualFunc.GatewayAsync($"UserExportAction/Tod/{p}/2"), Cron.Never(), recurringJobOptions);
                    RecurringJob.AddOrUpdate($"UserExportTodCommon{p}", () => ManualFunc.GatewayAsync($"UserExportAction/Tod/{p}/4"), Cron.Never(), recurringJobOptions);
                    RecurringJob.AddOrUpdate($"UserExportTodFcDo{p}", () => ManualFunc.GatewayAsync($"UserExportAction/Tod/{p}/7"), Cron.Never(), recurringJobOptions);
                    RecurringJob.AddOrUpdate($"SaveHistoryPartcontrol{p}", () => ManualFunc.GatewayAsync($"PushHistory/Tod/summary/{p}"), Cron.Daily(3, 0), recurringJobOptions);
                    RecurringJob.AddOrUpdate($"CalculatePartcontrol{p}_PreventUpload", () => ManualFunc.GatewayAsync($"CalculateAction/Tod/{p}"), Cron.Never(), recurringJobOptions);
                    RecurringJob.AddOrUpdate($"CalculatePartcontrol{p}_FCDO", () => ManualFunc.GatewayAsync($"CalculateAction/TodFcDo/{p}"), Cron.Never(), recurringJobOptions);
                    RecurringJob.AddOrUpdate($"RefreshAllMvPartcontrol", () => ManualFunc.GatewayAsync($"CheckSourceBeforeRunPartcontrol"), "*/5 7-8 * * *", recurringJobOptions);
                    RecurringJob.AddOrUpdate($"PushRedis{p}_B101", () => ManualFunc.GatewayAsync($"PushRedis/B101/{p}"), Cron.Daily(6, 15), recurringJobOptions);
                    RecurringJob.AddOrUpdate($"RefreshMvHksStockInvent", () => ManualFunc.GatewayAsync($"RefreshMv/InventStock/all"), "30-55/5 8 * * *", recurringJobOptions);
                }
                if (lstFuncDebut.Contains("digital"))
                {
                    if (factory.Contains("QV"))
                    {
                        RecurringJob.AddOrUpdate($"GetDataQV", () => ManualFunc.GatewayAsync($"GetQVData"), "0 8-18 * * *", recurringJobOptions);
                        RecurringJob.AddOrUpdate($"ReportDatabaseLog", () => ManualFunc.GatewayAsync($"CheckLogLastHour"), "59 8-17 * * *", recurringJobOptions);
                    }
                    RecurringJob.AddOrUpdate($"UserExportSimulation{p}", () => ManualFunc.GatewayAsync($"UserExportAction/Simulation/{p}/0"), "30 10 * * *", recurringJobOptions);
                    RecurringJob.AddOrUpdate($"SaveHistorySimulation{p}", () => ManualFunc.GatewayAsync($"PushHistory/Simulation/daily/{p}"), "3 3,8 * * *", recurringJobOptions);
                    RecurringJob.AddOrUpdate($"PushPOKey{p}", () => ManualFunc.GatewayAsync($"PushPOKey/{p}"), "5 9-21 * * *", recurringJobOptions);
                    RecurringJob.AddOrUpdate($"PushAgainPOKeyToOP7{p}", () => ManualFunc.GatewayAsync($"UserCalculateAction/SimulationPushPOKey/{p}"), Cron.Never(), recurringJobOptions);
                    RecurringJob.AddOrUpdate($"CalculateSimulation{p}", () => ManualFunc.GatewayAsync($"CalculateAction/Simulation/{p}"), Cron.Never(), recurringJobOptions);
                    RecurringJob.AddOrUpdate($"RefreshLiveProductionBlock10Minutes", () => ManualFunc.GatewayAsync($"RefreshMv/LivePPBlock10/all"), "37 8,14,17 * * *", recurringJobOptions);
                }
                //if (lstFuncDebut.Contains("partadjust"))
                //{
                //    RecurringJob.AddOrUpdate($"CalculatePartAdjustment{p}_NPIS", () => ManualFunc.GatewayAsync($"CalculateAction/PaNPIS/{p}"), "5 14,15,16,17 * * *", recurringJobOptions);
                //    RecurringJob.AddOrUpdate($"CalculatePartAdjustment{p}_ERI", () => ManualFunc.GatewayAsync($"CalculateAction/PaERI/{p}"), "15 13 * * *", recurringJobOptions);
                //}
                if (lstFuncDebut.Contains("manpower"))
                {

                }
                if (lstFuncDebut.Contains("leadtime"))
                {
                    RecurringJob.AddOrUpdate($"CalcPartList{p}_PreventUpload", () => ManualFunc.GatewayAsync($"CalculateAction/Lt/{p}"), Cron.Never(), recurringJobOptions);
                }
                if (lstFuncDebut.Contains("forecast"))
                {
                    RecurringJob.AddOrUpdate($"UserExportFcAll{p}", () => ManualFunc.GatewayAsync($"UserExportAction/Fc/{p}/0"), Cron.Weekly(DayOfWeek.Thursday, 17, 40), recurringJobOptions);
                    RecurringJob.AddOrUpdate($"CalculateForecast{p}_PreventUpload", () => ManualFunc.GatewayAsync($"CalculateAction/Fc/{p}"), Cron.Weekly(DayOfWeek.Thursday, 17, 10), recurringJobOptions);
                }
                if (lstFuncDebut.Contains("structure"))
                {
                    RecurringJob.AddOrUpdate($"CalculateStructure{p}", () => ManualFunc.GatewayAsync($"CalculateAction/Structure/{p}"), Cron.Daily(8, 20), recurringJobOptions);
                }
                if (lstFuncDebut.Contains("inventory"))
                {
                    RecurringJob.AddOrUpdate($"RefreshMvInvE700", () => ManualFunc.GatewayAsync($"RefreshMvE700"), "0 10 * * *", recurringJobOptions);
                    RecurringJob.AddOrUpdate($"PushRedis{p}_B101", () => ManualFunc.GatewayAsync($"PushRedis/B101/{p}"), Cron.Daily(6, 15), recurringJobOptions);
                    RecurringJob.AddOrUpdate($"JobSaveDataVisualizationSp", () => ManualFunc.GatewayAsync($"SaveDataVisualizationSp"), Cron.Daily(8, 57), recurringJobOptions);
                    RecurringJob.AddOrUpdate($"JobSaveDataVisualizationSpOp2", () => ManualFunc.GatewayAsync($"SaveDataVisualizationSpOp2"), Cron.Daily(8, 57), recurringJobOptions);
                    RecurringJob.AddOrUpdate($"JobSaveDataD800AndLending", () => ManualFunc.GatewayAsync($"SaveDataD800AndLending"), Cron.Daily(8, 00), recurringJobOptions);
                }
               
            }
            
        }
        public static void LocalScheduleJobs()
        {
            
        }

        public static string ContinuousJob(string recurringJobId)
        {
            string jobId = "";
            string state = "";
            using (var connection = JobStorage.Current.GetConnection())
            {
                var recurringJobs = connection.GetRecurringJobs();
                var matchingJob = recurringJobs.FirstOrDefault(j => j.Id == recurringJobId);
                if (matchingJob != null)
                {
                    jobId = matchingJob.LastJobId;
                    state = matchingJob.LastJobState;
                }
            }

            if (jobId != null && state != "Processing")
            {
                var backgroundJobClient = new BackgroundJobClient();
                backgroundJobClient.Requeue(jobId);

                //BackgroundJob.Requeue(jobId);
            }
            return "Da bat dau chay part control !";
        }
        public static bool PreventUpload()
        {
            try
            {
                return ADO.GetInt("SELECT count(*) FROM hangfire.job where invocationdata::text like '%Calc%' and statename = 'Processing'") > 0;
            }
            catch (Exception)
            {
                return false;
            }
        }
        public static bool PreventProcessing(string methodName)
        {
            try
            {
                return ADO.GetInt("SELECT count(*) FROM hangfire.job where invocationdata::text like '%" + methodName+ "%' and statename = 'Processing'") > 0;
            }
            catch (Exception)
            {
                return false;
            }
        }
        public static bool PreventProcessing2Param(string methodName, string product)
        {
            try
            {
                return ADO.GetInt($"SELECT count(*) FROM hangfire.job where invocationdata::text like '%{methodName}%{product}%' and statename = 'Processing'") > 0;
            }
            catch (Exception)
            {
                return false;
            }
        }
        public static bool PreventUpload(string recurringId)
        {
            try
            {
                using (var connection = JobStorage.Current.GetConnection())
                {
                    var recurringJobs = connection.GetRecurringJobs();
                    var matchingJob = recurringJobs.Where(x => x.Id == recurringId).Any(x => x.LastJobState == "Processing");
                    return matchingJob;
                }
            }
            catch (Exception)
            {
                return false;
            }
        }
        public static bool DelayMinute(string func, string product, int minute)
        {
            try
            {
                var recurringJobOptions = new RecurringJobOptions
                {
                    TimeZone = TimeZoneInfo.Local
                };
                var dt = DateTime.Now.AddMinutes(minute);
                var cronExpression = dt.Minute + " " + dt.Hour + " " + dt.Day + " " + dt.Month + " *";
                var cronExpressionDefault = 0 + " " + 9 + " " + dt.Day + " " + dt.Month + " *";
                if (func == "PartControl" && lstFuncDebut.Contains("partcontrol"))
                {
                    var valid = ADO.CheckValidBeforeRunPartContrl(product);
                    if(valid == 0)
                    {
                        RecurringJob.AddOrUpdate("CalculatePartcontrol" + product + "_PreventUpload", () => ManualFunc.GatewayAsync("CalculateAction/Tod/" + product), cronExpression, recurringJobOptions);
                    }
                    else
                    {
                        var dtCheck = new DateTime(dt.Year, dt.Month, dt.Day, 8, 30, 0);
                        if(DateTime.Now < dtCheck)
                        {
                            cronExpressionDefault = 40 + " " + 8 + " " + dt.Day + " " + dt.Month + " *";
                        }
                        RecurringJob.AddOrUpdate("CalculatePartcontrol" + product + "_PreventUpload", () => ManualFunc.GatewayAsync("CalculateAction/Tod/" + product), cronExpressionDefault, recurringJobOptions);
                    }
                }
                else if (func == "ExportPartControl" && lstFuncDebut.Contains("partcontrol"))
                {
                    RecurringJob.AddOrUpdate("UserExportTodPartControl" + product, () => ManualFunc.GatewayAsync("UserExportAction/Tod/" + product + "/1"), cronExpression, recurringJobOptions);
                    RecurringJob.AddOrUpdate("UserExportTodDeadline" + product, () => ManualFunc.GatewayAsync("UserExportAction/Tod/" + product + "/2"), cronExpression, recurringJobOptions);
                    RecurringJob.AddOrUpdate("UserExportTodCommon" + product, () => ManualFunc.GatewayAsync("UserExportAction/Tod/" + product + "/4"), cronExpression, recurringJobOptions);
                    //RecurringJob.AddOrUpdate("UserExportTodPartControlPic" + product, () => ManualFunc.GatewayAsync("UserExportAction/Tod/" + product + "/3"), cronExpression, recurringJobOptions);
                }
                else if (func == "ExportPartControlFcDo" && lstFuncDebut.Contains("partcontrol"))
                {
                    RecurringJob.AddOrUpdate("UserExportTodFcDo" + product, () => ManualFunc.GatewayAsync("UserExportAction/Tod/" + product + "/7"), cronExpression, recurringJobOptions);
                }
                else if (func == "ExportPartControlNoneInv" && lstFuncDebut.Contains("partcontrol"))
                {
                    RecurringJob.AddOrUpdate("UserExportTodPartControl" + product, () => ManualFunc.GatewayAsync("UserExportAction/Tod/" + product + "/1"), cronExpression, recurringJobOptions);
                }
                else if (func == "Simulation" && lstFuncDebut.Contains("digital"))
                {
                    RecurringJob.AddOrUpdate($"CalculateSimulation{product}", () => ManualFunc.GatewayAsync($"CalculateAction/Simulation/{product}"), cronExpression, recurringJobOptions);
                }
                else if (func == "ExportSimulation" && lstFuncDebut.Contains("digital"))
                {
                    RecurringJob.AddOrUpdate($"UserExportSimulation{product}", () => ManualFunc.GatewayAsync($"UserExportAction/Simulation/{product}/0"), cronExpression, recurringJobOptions);
                }
                return true;
            }
            catch (Exception)
            {
                return false;
            }
        }
    }
}
