﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;
using Newtonsoft.Json;
using PDCProjectApi.Model.Response;
using System.Collections;
using System.IdentityModel.Tokens.Jwt;
using System.Net;
using System.Net.Http.Headers;
using System.Reflection;
using System.Security.Claims;
using System.Text;
using static PDCProjectApi.Common.Job.LoggingDataLake;

namespace PDCProjectApi.Common.Job
{
    
    public static class LoggingDataLake
    {
        //Call API FOR ASP.NET CORE
        public static async Task SendLog(HttpContext context,string elapsed)
        {
            try
            {
                string userName = Environment.UserName;
                var ip = context.Connection.RemoteIpAddress;
                var machinename = await GetHostName(ip);
                var endpoint = context.Request.Path.Value;
                var hostname = context.Request.Host.ToString();
                var queryString = context.Request.QueryString;
                var authorizationHeader = context.Request.Headers["Authorization"].ToString();
                var handler = new JwtSecurityTokenHandler();
                var token = handler.ReadToken(authorizationHeader.Replace("Bearer ", "")) as JwtSecurityToken;
                var username = "";
                var fullname = "";
                if (token != null)
                {
                    username = token.Claims.FirstOrDefault(c => c.Type == "user_name")?.Value;
                    fullname = token.Claims.FirstOrDefault(c => c.Type == "full_name")?.Value;
                }
                using (HttpClient client = new HttpClient())
                {
                    string apiUrl = "http://cvn-vsmartdbs:89/api/Message";

                    var parameters = new Dictionary<string, string>
                    {
                        { "level", "info" },
                        { "machine",machinename},
                        { "window_user",username ?? "User" },
                        { "application","PSI"},
                        { "controller",hostname},
                        { "action_name",endpoint ?? "Action"},
                        { "time_action",DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") },
                        { "msg", (fullname ?? "") + (!string.IsNullOrEmpty(queryString.ToString()) ? " query: " + queryString: "") },
                        {"processing_time",elapsed }
                    };

                    var content = new FormUrlEncodedContent(parameters);

                    HttpResponseMessage res = await client.PostAsync(apiUrl, content).WaitAsync(TimeSpan.FromMilliseconds(100));
                }
            }
            catch (Exception)
            {

            }

        }
        
        public static async Task SendError(ExceptionContext context)
        {
            try
            {
                string userName = Environment.UserName;
                var ip = context.HttpContext.Connection.RemoteIpAddress;
                var machinename = await GetHostName(ip);
                var endpoint = context.HttpContext.Request.Path.Value;
                var hostname = context.HttpContext.Request.Host.ToString();
                var username = "Exception";

                var endpoint1 = context.HttpContext.GetEndpoint();
                var endpointName1 = endpoint1?.DisplayName;
                var endpointRoutePattern1 = (endpoint1 as RouteEndpoint)?.RoutePattern.RawText;
                var mess = context.Exception.Message.ToString();
                var mass1 = $"Message:{mess}, Endpoint: {endpointName1}, RoutePattern: {endpointRoutePattern1}, Detail Error: {context.Exception.ReturnDetailException() ?? ""}";
                using (HttpClient client = new HttpClient())
                {
                    string apiUrl = "http://cvn-vsmartdbs:89/api/Message";
                    var parameters = new Dictionary<string, string>
                    {
                        { "level", log_level.Error.ToString() },
                        { "machine",machinename},
                        { "window_user",username ?? "" },
                        { "application","PSI"},
                        { "controller",hostname},
                        { "action_name",endpoint ?? ""},
                        { "time_action",DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") },
                        { "msg", mass1 }
                    };
                    var content = new FormUrlEncodedContent(parameters);

                    HttpResponseMessage res = await client.PostAsync(apiUrl, content).WaitAsync(TimeSpan.FromMilliseconds(100));
                }
            }
            catch (Exception)
            {

            }

        }
        public static async Task<string> GetHostName(IPAddress ip)
        {
            try
            {
                var hostEntry = await Dns.GetHostEntryAsync(ip);
                return hostEntry.HostName;
            }
            catch (Exception)
            {
                return ip.ToString();
            }
        }
        public enum log_level
        {
            Error,
            Info
        }
    }
    public class LogData
    {
        public string level { get; set; } = null!;
        public string machine { get; set; } = null!;
        public string window_user { get; set; } = null!;
        public string application { get; set; } = null!;
        public string controller { get; set; } = null!;
        public string action_name { get; set; } = null!;
        public string time_action { get; set; } = null!;
        public string msg { get; set; } = null!;
    }
}
