﻿using Hangfire.Dashboard;
using Newtonsoft.Json;
using PDCProjectApi.Data;
using PDCProjectApi.Model.Chart;
using PDCProjectApi.Model.View;
using PDCProjectApi.Services;
using StackExchange.Redis;
using System.Security.Policy;
using System.Text;
using System.Text.Json;

namespace PDCProjectApi.Common.Job
{
    public static class ManualFunc
    {
        private static readonly IGlobalVariable global = new GlobalVariable();
        private static readonly string hangfireUrl = global.ReturnHangfireUrl();
        private static readonly string gatewayUrl = global.ReturnGatewayUrl();
        private static Dictionary<Tuple<DateOnly, int, string>, string> cache = new Dictionary<Tuple<DateOnly, int, string>, string>();
        public static List<DateOnly> GetWorkingDayValid(DateOnly dateFrom, DateOnly dateTo)
        {
            //try
            //{
            //    using (var ctx = new PdcsystemContext())
            //    {
            //        return ctx.AdmMasterCalendars
            //                    .Where(x => x.IjOff == false
            //                    && x.DateOfDate >= dateFrom && x.DateOfDate <= dateTo)
            //                    .OrderBy(x => x.DateOfDate)
            //                    .Select(x => x.DateOfDate)
            //                    .ToList();
            //    }
            //}
            //catch (Exception)
            //{
                return new List<DateOnly>();
            //}
        }
        public static DateOnly GetDateByDateAndStep(List<DateOnly> lstDate, DateOnly don, int step)
        {
            try
            {
                return lstDate[lstDate.IndexOf(don) + step];
            }
            catch (Exception)
            {
                return don;
            }
        }

        //public static string GetDateSubtractStl(List<AdmMasterCalendar> lst, DateOnly don, int step)
        //{
        //    try
        //    {
        //        if(step < 1)
        //        {
        //            return don.ToString("yyyyMMdd");
        //        }
        //        else
        //        {
        //            var dateSubtract = don.AddDays(-1 * step);
        //            var totalSub = lst.Where(x => x.DateOfDate >= dateSubtract && x.DateOfDate <= don).Count(y => y.IsOff);
        //            var result = don.AddDays(-1 * (step + totalSub));
        //            return result.ToString("yyyyMMdd");
        //        }
        //        //var result = don.AddDays(-1 * step);
        //        //if (lst.Where(x => x.DateOfDate == result).First().IsOff)
        //        //{
        //        //    return GetDateSubtractStl(lst, result, 1);
        //        //}
        //        //else
        //        //{
        //        //    return result.ToString("yyyyMMdd");
        //        //}
        //    }
        //    catch (Exception)
        //    {
        //        return don.ToString("yyyyMMdd");
        //    }
        //}
        public static string GetDateSubtractStl(List<AdmMasterCalendar> lst, DateOnly don, int step, string product)
        {
            try
            {
                // Kiểm tra trong cache trước khi tính toán
                var cacheKey = Tuple.Create(don, step, product);
                if (cache.ContainsKey(cacheKey))
                {
                    return cache[cacheKey];
                }

                if (step < 1)
                {
                    cache[cacheKey] = don.ToString("yyyyMMdd");
                    return cache[cacheKey];
                }
                else
                {
                    var dateSubtract = don.AddDays(-1 * step);
                    var offProperty = product == "IJ" ? "IjOff" : product == "LBP" ? "LbpOff" : "";

                    if (string.IsNullOrEmpty(offProperty))
                    {
                        cache[cacheKey] = DateTime.Now.ToString("yyyyMMdd");
                        return cache[cacheKey];
                    }

                    var totalSub = lst.Count(x => x.DateOfDate >= dateSubtract && x.DateOfDate < don && (bool)x.GetType().GetProperty(offProperty)?.GetValue(x) == true);
                    var result = don.AddDays(-1 * (step + totalSub));

                    if (lst.Any(x => x.DateOfDate == result && (bool)x.GetType().GetProperty(offProperty)?.GetValue(x) == true))
                    {
                        cache[cacheKey] = GetDateSubtractStl(lst, result, 1, product);
                        return cache[cacheKey];
                    }
                    else
                    {
                        cache[cacheKey] = result.ToString("yyyyMMdd");
                        return cache[cacheKey];
                    }
                }
            }
            catch (Exception)
            {
                return don.ToString("yyyyMMdd");
            }
        }
        public static string GetDateSubtractStlOld(List<AdmMasterCalendar> lst, DateOnly don, int step, string product)
        {
            try
            {
                if (step < 1)
                {
                    return don.ToString("yyyyMMdd");
                }
                else
                {
                    // trừ đi tổng số ngày stl
                    var dateSubtract = don.AddDays(-1 * step);
                    var totalSub = 0;
                    var offProperty = "";

                    if (product == "IJ")
                    {
                        totalSub = lst.Where(x => x.DateOfDate >= dateSubtract && x.DateOfDate < don).Count(y => y.IjOff ?? false);
                        offProperty = "IjOff";
                    }
                    else if (product == "LBP")
                    {
                        totalSub = lst.Where(x => x.DateOfDate >= dateSubtract && x.DateOfDate < don).Count(y => y.LbpOff ?? false);
                        offProperty = "LbpOff";
                    }
                    else
                    {
                        return DateTime.Now.ToString("yyyyMMdd");
                    }

                    var result = don.AddDays(-1 * (step + totalSub));

                    if (lst.Where(x => x.DateOfDate == result).Any(y => (bool)(y.GetType().GetProperty(offProperty)?.GetValue(y) ?? false)))
                    {
                        return GetDateSubtractStl(lst, result, 1, product);
                    }
                    else
                    {
                        return result.ToString("yyyyMMdd");
                    }

                }
            }
            catch (Exception)
            {
                return don.ToString("yyyyMMdd");
            }
        }
        public static string GetDateSubtractStlIJ(List<AdmMasterCalendar> lst, DateOnly don, int step)
        {
            try
            {
                if (step < 1)
                {
                    return don.ToString("yyyyMMdd");
                }
                else
                {
                    // trừ đi tổng số ngày stl
                    var dateSubtract = don.AddDays(-1 * step);
                    // đếm xem từ ngày đã trừ đến ngày truyền vào có bao nhiêu ngày off
                    var totalSub = lst.Where(x => x.DateOfDate >= dateSubtract && x.DateOfDate < don).Count(y => y.IjOff ?? false);
                    // trừ đi stl+ tổng ngày off
                    var result = don.AddDays(-1 * (step + totalSub));

                    // Kiểm tra ngày kết quả (result) có được đánh dấu là IsOff hay không
                    if (lst.Where(x => x.DateOfDate == result).Any(y => y.IjOff ?? false))
                    {
                        return GetDateSubtractStlIJ(lst, result, 1); // Gọi đệ quy với step = 1 để trừ thêm 1 ngày
                    }
                    else
                    {
                        return result.ToString("yyyyMMdd");
                    }

                }
            }
            catch (Exception)
            {
                return don.ToString("yyyyMMdd");
            }
        }
        public static string GetDateSubtractStlLBP(List<AdmMasterCalendar> lst, DateOnly don, int step)
        {
            try
            {
                if (step < 1)
                {
                    return don.ToString("yyyyMMdd");
                }
                else
                {
                    // trừ đi tổng số ngày stl
                    var dateSubtract = don.AddDays(-1 * step);
                    // đếm xem từ ngày đã trừ đến ngày truyền vào có bao nhiêu ngày off
                    var totalSub = lst.Where(x => x.DateOfDate >= dateSubtract && x.DateOfDate < don).Count(y => y.LbpOff ?? false);
                    // trừ đi stl+ tổng ngày off
                    var result = don.AddDays(-1 * (step + totalSub));

                    // Kiểm tra ngày kết quả (result) có được đánh dấu là IsOff hay không
                    if (lst.Where(x => x.DateOfDate == result).Any(y => y.LbpOff ?? false))
                    {
                        return GetDateSubtractStlLBP(lst, result, 1); // Gọi đệ quy với step = 1 để trừ thêm 1 ngày
                    }
                    else
                    {
                        return result.ToString("yyyyMMdd");
                    }

                }
            }
            catch (Exception)
            {
                return don.ToString("yyyyMMdd");
            }
        }
        public static List<ChartFcdelByTypeByGroupBy> GetChartSumupDataMonth(List<ChartFcdelByTypeByGroupBy> model1)
        {
            var lstModel = model1;
            if (lstModel?.Count < 1)
            {
                return new List<ChartFcdelByTypeByGroupBy>();
            }
            var total = new ChartFcdelByTypeByGroupBy
            {
                Label = "Total",
                Stack = "true",
                Days = lstModel?[0].Days,
                Value = lstModel?.Aggregate(new double[lstModel[0].Days.Length], (acc, item) =>
                {
                    for (int i = 0; i < item.Value?.Length; i++)
                    {
                        acc[i] += item.Value[i];
                    }
                    return acc;
                })
            };
            var distinctMonth = total.StrMonths.Distinct().ToList();
            Dictionary<string, (DateOnly, double)> dicMonth = new Dictionary<string, (DateOnly, double)>();
            for (int i = 0; i < total.Value.Length; i++)
            {
                var month = total.StrMonths[i];
                var day = total.Days[i];
                var val = total.Value[i];
                if (!dicMonth.ContainsKey(month))
                {
                    dicMonth.Add(month, (day, val));
                }
                else
                {
                    if (dicMonth[month].Item2 < val)
                    {
                        dicMonth[month] = (day, val);
                    }
                }
            }
            var arrDo = dicMonth.Select(x => x.Value.Item1).ToArray();
            var lstResult = new List<ChartFcdelByTypeByGroupBy>();
            foreach (var item in lstModel)
            {

                var newVal = new List<double>();
                Dictionary<DateOnly, double> dicValByDate = new Dictionary<DateOnly, double>();
                for (int i = 0; i < item.Value.Length; i++)
                {
                    try
                    {
                        dicValByDate.Add(item.Days[i], item.Value[i]);
                    }
                    catch (Exception)
                    {

                    }
                }

                for (int i = 0; i < arrDo.Length; i++)
                {
                    newVal.Add(dicValByDate[arrDo[i]]);
                }
                var newitem = item;
                newitem.Days = arrDo;
                newitem.Value = newVal.ToArray();
                lstResult.Add(newitem);
            }
            return lstResult;
        }
        public static List<string> GetNoMotherPartEuch445(Dictionary<string?,string?>? dicMother, Dictionary<string?, string?>? dicTotalMother, string upper, string bc, string noPart, string dim)//ConnectionMultiplexer redis, string upper, string bc, string noPart, string dim
        {
            if (dicMother.TryGetValue($"{noPart}_{bc}_{dim}", out var listMother))
            {
                if (listMother.Contains(upper) || string.IsNullOrEmpty(listMother))
                {
                    return new List<string> { $"{upper}_{dim}" };
                }
                dicTotalMother.TryGetValue($"{noPart}_{bc}_{upper}_{dim}", out var checkLstMother);
                if (checkLstMother != null)
                {
                    int startIndex = checkLstMother.IndexOf(upper);

                    if (startIndex != -1)
                    {
                        string result = checkLstMother.Substring(startIndex);
                        return new List<string> { result };
                    }
                }
            }
            return new List<string> { $"{upper}_{dim}" };
        }
        public static List<string> GetNoMotherPartEuch1701(Dictionary<string?, string?>? dicMother, Dictionary<string?, string?>? dicTotalMother, string upper, string bc, string noPart, string dim)
        {
            if (dicMother.TryGetValue($"{noPart}_{bc}_{dim}", out var listMother))
            {
                if (listMother.Contains(upper) || string.IsNullOrEmpty(listMother))
                {
                    return new List<string> { upper };
                }
                if (dicTotalMother.TryGetValue($"{noPart}_{bc}_{upper.Split("_")[0]}_{dim}", out var checkLstMother))
                {
                    if (checkLstMother != null)
                    {
                        int startIndex = checkLstMother.IndexOf(upper.Split("_")[0]);

                        if (startIndex != -1)
                        {
                            string result = checkLstMother.Substring(startIndex);
                            return new List<string> { result };
                        }
                    }
                }
            }

            return new List<string> { upper };
        }
        public static DateOnly ReturnPalletDate(this DateTime dt) => dt.Hour > 7 ? DateOnly.FromDateTime(dt) : DateOnly.FromDateTime(dt.AddDays(-1));
        public static string ConvertStreamToBase64(Stream reader)
        {
            byte[] buffer = new byte[reader.Length];
            reader.Read(buffer, 0, (int)reader.Length);
            return Convert.ToBase64String(buffer);
        }
        public static string ConvertBytesToBase64(byte[] bytes)
        {
            return Convert.ToBase64String(bytes);
        }
        //////public static async Task CallApi58Async(string path)
        //////{
        //////    //////string apiUrl = "http://" + hangfireUrl + "/api/hangfire/" + path;
        //////    ////////HttpClient client = new HttpClient();
        //////    //////try
        //////    //////{
                
        //////    //////    using (var client = new HttpClient())
        //////    //////    {
        //////    //////        HttpRequestMessage request = new HttpRequestMessage(HttpMethod.Get, apiUrl);
        //////    //////        client.Timeout = TimeSpan.FromSeconds(3);
        //////    //////        await client.SendAsync(request);
        //////    //////    }
        //////    //////}
        //////    //////catch (Exception ex)
        //////    //////{
        //////    //////    Console.WriteLine($"An error occurred: {ex.Message}");
        //////    //////}
        //////}
        public static async Task CallApiCurrentAsync(string path)
        {
            string url = $"http://localhost:5217/{path}";
            //HttpClient client = new HttpClient();
            try
            {
                
                using (var client = new HttpClient())
                {
                    HttpRequestMessage rq = new HttpRequestMessage(HttpMethod.Get, url);
                    client.Timeout = TimeSpan.FromSeconds(3);
                    await client.SendAsync(rq);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"An error occurred: {ex.Message}");
            }
        }
        public static async Task GatewayAsync(string path)
        {
            string apiUrl = "http://" + gatewayUrl + "/api/hangfire/" + path;
            try
            {
                using(var client = new HttpClient())
                {
                    HttpRequestMessage request = new HttpRequestMessage(HttpMethod.Get, apiUrl);
                    //client.Timeout = TimeSpan.FromSeconds(3);
                    _ = await client.SendAsync(request, HttpCompletionOption.ResponseHeadersRead);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"An error occurred: {ex.Message}");
                new EmailService().InitialDev("Error", $"Call Gateway Async {path} \n {ex.Message} \n {ex.StackTrace}");
            }
        }
        public static async Task GatewayAsyncPost(string path, string? jsonParams)
        {
           
            string apiUrl = "http://" + gatewayUrl + "/api/hangfire/" + path;
            try
            {
                using (var client = new HttpClient())
                {
                    var content = new StringContent(jsonParams, Encoding.UTF8, "application/json");
                    HttpRequestMessage request = new HttpRequestMessage(HttpMethod.Post, apiUrl);
                    request.Content = content;
                    client.Timeout = TimeSpan.FromSeconds(40);
                    var response = await client.SendAsync(request);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"An error occurred: {ex.Message}");
                new EmailService().InitialDev("Error", $"Call Gateway Async Post {path} \n {ex.Message} \n {ex.StackTrace}");
            }
        }
        public static async Task GetQVData(string type)
        {
            string apiUrl = "http://prodqv:9500/public-apis/v_live_pp_priority";
            if (type == "_LivePP_Priority")
            {
                apiUrl = "http://prodqv:9500/public-apis/v_live_pp_priority";
            }
            else if (type == "_working_time")
            {
                apiUrl = "http://prodqv:9500/public-apis/v_working_time";
            }
            else if (type == "_pdc_receiving_export")
            {
                apiUrl = "http://prodqv:9500/public-apis/v_pdc_receiving_export_qv";
            }
            try
            {
                using (var client = new HttpClient())
                {
                    HttpRequestMessage request = new HttpRequestMessage(HttpMethod.Get, apiUrl);
                    request.Headers.Add("x-api-key", "651dc4c6-1166-4049-81b4-918dd79964c1-da67966c-4104-4b62-a28c-a96a21a8fc70-8a7761f2-edbf-4510-b7ec-4b87ded962f7-7e861e30-3afa-4edd-9942-c7529c1d02b4-544793d4-5d14-4253-8045-675b332a359e");
                    //client.Timeout = TimeSpan.FromSeconds(3);
                    var response = await client.SendAsync(request, HttpCompletionOption.ResponseHeadersRead);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"An error occurred: {ex.Message}");
                new EmailService().InitialDev("Error", $"Call get QV Data {type} \n {ex.Message} \n {ex.StackTrace}");
            }
        }
    }
}

