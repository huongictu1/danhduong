﻿using Microsoft.EntityFrameworkCore;
using OfficeOpenXml;
using OfficeOpenXml.Style;
using PDCProjectApi.Common.Function;
using PDCProjectApi.Data;
using PDCProjectApi.Model.Response;
using PDCProjectApi.Services;
using System.Net;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Authorization;
using PDCProjectApi.Model.View;
using AutoMapper;
using Microsoft.IdentityModel.Tokens;
using DocumentFormat.OpenXml.InkML;
using System;

namespace PDCProjectApi.Common.Job
{

    public interface IInventorylJob
    {
        Task<CommonResponse> SaveOutput1Inventory(string product);
        Task<CommonResponse> SaveOutput1InventoryHistory(string product);
        Task GetOutputOp1Excel(string product);
        Task SaveDataVisualizationSpJob();
        Task SaveDataVisualizationSpOp2Job();
        Task SaveDataD800AndLending();

    }
    public class InventoryJob : IInventorylJob
    {
        private readonly PdcsystemContext ctx;
        private List<string> lstITMail;
        private readonly IGlobalVariable global = new GlobalVariable();
        private readonly string outputPathOri = "";
        private string pathServer;

        public InventoryJob(PdcsystemContext ctx)
        {
            this.ctx = ctx;
            this.lstITMail = global.ReturnITMail();
            this.outputPathOri = this.global.ReturnPathOutput();
            this.pathServer = global.ReturnPathServer();

        }
        public async Task<CommonResponse> SaveOutput1Inventory(string product)
        {
            var result = new CommonResponse()
            {
                Error = false,
                Message = "",
                Status = (int)HttpStatusCode.BadRequest
            };
            try
            {
                var structure = new List<TodStructureOutputContentIj>();
                var eucD800 = new List<VlinkageEucIjD800>();
                var ip1 = new List<InvSnp>();
                var ip2 = new List<InvIp2Packing>();
                var leadTime = new List<LtOp2Inquiry>();
                var lstCheckHis = await ctx.InvOutputPartHis.Where(x => x.Active == true && x.Product.ToUpper() == product.ToUpper()).ToListAsync();
                var lstAdd = new List<InvOutputPartHi>();
                var lstUpdate = new List<InvOutputPartHi>();
                var dateNow = DateOnly.FromDateTime(DateTime.Now);
                var calendarTerm = ctx.InvCalendarTerms.FirstOrDefault(x => x.Active == true && x.TimeFrom <= dateNow && x.TimeTo >= dateNow);
                //còn e900 nữa
                var eucE900 = new List<MvEucE900Ij>();
                if (calendarTerm != null)
                {

                    if (product == "IJ")
                    {
                        structure = await ctx.TodStructureOutputContentIjs.Where(x => x.Active == true).AsNoTracking().ToListAsync().ConfigureAwait(false);
                        try
                        {
                            eucD800 = await ctx.VlinkageEucIjD800s.AsNoTracking().ToListAsync().ConfigureAwait(false);
                        }
                        catch
                        {
                            eucD800 = await ctx.VlinkageEucIjD800s.AsNoTracking().ToListAsync().ConfigureAwait(false);
                        }
                        ip1 = await ctx.InvSnps.Include(x => x.InvSnpDetails).Where(x => x.Active == true && x.Product.ToUpper().Contains("IJ")).ToListAsync();
                        ip2 = await ctx.InvIp2Packings.Where(x => x.Active == true && x.Product.ToUpper().Contains("IJ")).ToListAsync();
                        leadTime = await ctx.LtOp2Inquiries.Where(x => x.Active == true && x.Product.ToUpper().Contains("IJ")).ToListAsync();
                        eucE900 = await ctx.MvEucE900Ijs.ToListAsync();
                    }
                    else
                    {
                        var outputLbp = await ctx.TodStructureOutputContentLbps.Where(x => x.Active == true).AsNoTracking().ToListAsync().ConfigureAwait(false);
                        structure = outputLbp.MapStructureOutput();
                        var eucD800Lbp = new List<VlinkageEucLbpD800>();
                        try
                        {
                            eucD800Lbp = await ctx.VlinkageEucLbpD800s.AsNoTracking().ToListAsync().ConfigureAwait(false);
                        }
                        catch
                        {
                            eucD800Lbp = await ctx.VlinkageEucLbpD800s.AsNoTracking().ToListAsync().ConfigureAwait(false);
                        }
                        eucD800 = eucD800Lbp.MapEucD800();
                        ip1 = await ctx.InvSnps.Include(x => x.InvSnpDetails).Where(x => x.Active == true && x.Product.ToUpper().Contains("LBP")).ToListAsync();
                        ip2 = await ctx.InvIp2Packings.Where(x => x.Active == true && x.Product.ToUpper().Contains("LBP")).ToListAsync();
                        leadTime = await ctx.LtOp2Inquiries.Where(x => x.Active == true && x.Product.ToUpper().Contains("LBP")).ToListAsync();
                        var eucE900Lbp = await ctx.MvEucE900Lbps.ToListAsync();
                        eucE900 = eucE900Lbp.MapEucE900();
                    }

                    structure = structure.GroupBy(x => new { x.PartNo8, x.Bc1, x.Bc12 }).Select(x => x.First()).ToList();
                    foreach (var item in structure)
                    {
                        var checkExists = lstCheckHis.FirstOrDefault(x => x.PartNo == item.PartNo8 && x.Vendor == item.Bc12 && x.Term == calendarTerm.Term);
                        var checkD800 = eucD800.FirstOrDefault(x => x.NoParts == item.PartNo8);
                        var checkIp1 = ip1.FirstOrDefault(x => x.PartNo == item.PartNo8 && x.Vendor == item.Bc12 && x.PeriodId == calendarTerm.Id);
                        var checkIp2 = ip2.Where(x => x.PartNo == item.PartNo8).ToList();
                        var checkLt = leadTime.FirstOrDefault(x => x.PartNo == item.PartNo8 && x.Vendor == item.Bc12);
                        var checkE900 = eucE900.FirstOrDefault(x => x.NoParts == item.PartNo8);
                        if (checkExists != null)
                        {
                            checkExists.Active = false;
                            lstUpdate.Add(checkExists);
                        }

                        string?[] model = item.Model45?.Split(',');
                        string?[] hashModel = model?.Distinct().ToArray();
                        string? resultModel = hashModel == null ? null : string.Join("+", hashModel);
                        var add = new InvOutputPartHi()
                        {
                            PartNo = item.PartNo8,
                            Dim = item.Dim9,
                            PartName = item.PartName11,
                            Vendor = item.Bc12,
                            CoMain = item.Comain22,
                            Model = resultModel,
                            DesCom = item.Des21,
                            OrderMethod = item.Name20,
                            SnpBox = item.Moq35.ToString(),
                            TypeOfPart = item.Pr10,
                            Term = calendarTerm.Term,
                            Product = product
                        };

                        if (checkD800 != null)
                        {
                            add.Cp = checkD800.NoInventCntlPoi;
                            add.UnitPrice = checkD800.CtAll.ToString();
                            add.Sp = checkD800.NoStockPoi;
                        }
                        if (checkIp2.Count > 0)
                        {
                            add.PackingMethod = checkIp2.FirstOrDefault().PackingMethod;
                            add.InvControlMethod = checkIp2.FirstOrDefault(x => x.InvDate >= calendarTerm.TimeFrom && calendarTerm.TimeTo >= x.InvDate)?.InvMethod;
                            add.PiResultHis = checkIp2.FirstOrDefault(x => x.PiDate >= calendarTerm.TimeFrom && calendarTerm.TimeTo >= x.PiDate)?.PiQty.ToString();
                            add.OmmitedHis = checkIp2.FirstOrDefault(x => x.OmittedDate >= calendarTerm.TimeFrom && calendarTerm.TimeTo >= x.OmittedDate)?.OmittedQty.ToString();
                            var urgent_date = new List<string?>();
                            foreach (var urgent in checkIp2.Where(x => x.UrgentDate >= calendarTerm.TimeFrom && calendarTerm.TimeTo >= x.UrgentDate).ToList())
                            {
                                if (urgent != null)
                                {
                                    urgent_date.Add(urgent.UrgentDate.ToString());
                                }
                            }
                            add.UrgentCase = urgent_date.ToArray();
                        }
                        if (checkIp1 != null)
                        {
                            int timeOk = checkIp1.InvSnpDetails.Where(x => x.Differ == 0).ToList().Count();
                            int timePlus = checkIp1.InvSnpDetails.Where(x => x.Differ > 0).ToList().Count();
                            int timeMinus = checkIp1.InvSnpDetails.Where(x => x.Differ < 0).ToList().Count();
                            string? status = null;
                            if (timePlus == 0 && timeOk == 0 && timeMinus == 0)
                            {
                                status = "NY";
                            }
                            else if (timeOk > 0 && timePlus == 0 && timeMinus == 0)
                            {
                                status = "OK";
                            }
                            else if (timeMinus == 0 && timeOk == 0 && timePlus > 0)
                            {
                                status = "Plus";
                            }
                            else if (timePlus == 0 && timeOk == 0 && timeMinus > 0)
                            {
                                status = "Minus";
                            }
                            else
                            {
                                status = "Unstable";
                            }
                            add.SpCheckHis = status;

                        }
                        if (checkLt != null)
                        {
                            add.KindOfPart = checkLt.KindOfPart;
                            add.ProcessUsing = checkLt.MovingRoute;
                            add.QtyKeepLine = checkLt.DoQty.ToString();
                            add.TotalLt = checkLt.TotalLtTotal.ToString();
                        }
                        add.DefectHis = checkE900 == null ? null : Math.Round((double)checkE900.Sum, 2).ToString();
                        lstAdd.Add(add);
                    }

                }
                else
                {
                    result.Status = (int)HttpStatusCode.BadRequest;
                    result.Message = "This time is not belong to of the calendar term!";
                    result.Error = true;
                    return result;
                }
                ctx.UpdateRange(lstUpdate);
                ctx.AddRange(lstAdd);
                ctx.SaveChanges();
                await GetOutputOp1Excel(product);
                var groupUser = ctx.AdmDetailUserGroups.Include(x => x.User).Where(x => x.Active == true && x.GroupId == new Guid("200989fe-1fe2-4da5-bd6f-576f185452a7")).ToList();
                var lstMail = groupUser.Where(x => x.User.Email != null && x.User.Email != "").Select(x => x.User.Email).ToList();
                var link = "http://cvn-vpsi/#/inventory/output/part-inv-his";
                string content = "<p style='font-weight: bold;'>Dear [Mrs/Mr]. All,</p>";
                content += "<p>The processing calculation output part inventory history of product " + product.ToUpper() + " is done.</p>";
                content += "<p>Now you can check it at: " + link + "</p>";

                new EmailService().Initial(lstMail, " Completed calc output part inventory history " + product.ToUpper(), content);

                return result;
            }
            catch (Exception e)
            {
                new EmailService().Initial(lstITMail, " Faile calc inventory op1", e.Message);
                result.Status = (int)HttpStatusCode.BadRequest;
                result.Message = e.Message;
                result.Error = true;
                return result;
            }
        }

        public async Task<CommonResponse> SaveOutput1InventoryHistory(string product)
        {
            var result = new CommonResponse()
            {
                Error = false,
                Message = "",
                Status = (int)HttpStatusCode.BadRequest
            };
            try
            {
                var structure = new List<TodStructureOutputContentIj>();
                var eucD800 = new List<VlinkageEucIjD800>();
                var ip1 = new List<InvSnp>();
                var ip2 = new List<InvIp2Packing>();
                var leadTime = new List<LtOp2Inquiry>();
                var lstCheckHis = await ctx.InvOutputPartHis.Where(x => x.Active == true && x.Product.ToUpper() == product.ToUpper()).ToListAsync();
                var lstAdd = new List<InvOutputPartHi>();
                var lstUpdate = new List<InvOutputPartHi>();
                var dateNow = DateOnly.FromDateTime(DateTime.Now);
                var calendarTerm = ctx.InvCalendarTerms.Where(x => x.Active == true).ToList()/*.FirstOrDefault(x => x.Active == true && x.TimeFrom <= dateNow && x.TimeTo >= dateNow)*/;
                //còn e900 nữa
                var eucE900 = new List<MvEucE900Ij>();
                if (calendarTerm != null)
                {

                    if (product == "IJ")
                    {
                        structure = await ctx.TodStructureOutputContentIjs.Where(x => x.Active == true).AsNoTracking().ToListAsync().ConfigureAwait(false);
                        try
                        {
                            eucD800 = await ctx.VlinkageEucIjD800s.AsNoTracking().ToListAsync().ConfigureAwait(false);
                        }
                        catch
                        {
                            eucD800 = await ctx.VlinkageEucIjD800s.AsNoTracking().ToListAsync().ConfigureAwait(false);
                        }
                        ip1 = await ctx.InvSnps.Include(x => x.InvSnpDetails).Where(x => x.Active == true && x.Product.ToUpper().Contains("IJ")).ToListAsync();
                        ip2 = await ctx.InvIp2Packings.Where(x => x.Active == true && x.Product.ToUpper().Contains("IJ")).ToListAsync();
                        leadTime = await ctx.LtOp2Inquiries.Where(x => x.Active == true && x.Product.ToUpper().Contains("IJ")).ToListAsync();
                        eucE900 = await ctx.MvEucE900Ijs.ToListAsync();
                    }
                    else
                    {
                        var outputLbp = await ctx.TodStructureOutputContentLbps.Where(x => x.Active == true).AsNoTracking().ToListAsync().ConfigureAwait(false);
                        structure = outputLbp.MapStructureOutput();
                        var eucD800Lbp = new List<VlinkageEucLbpD800>();
                        try
                        {
                            eucD800Lbp = await ctx.VlinkageEucLbpD800s.AsNoTracking().ToListAsync().ConfigureAwait(false);
                        }
                        catch
                        {
                            eucD800Lbp = await ctx.VlinkageEucLbpD800s.AsNoTracking().ToListAsync().ConfigureAwait(false);
                        }
                        eucD800 = eucD800Lbp.MapEucD800();
                        ip1 = await ctx.InvSnps.Include(x => x.InvSnpDetails).Where(x => x.Active == true && x.Product.ToUpper().Contains("LBP")).ToListAsync();
                        ip2 = await ctx.InvIp2Packings.Where(x => x.Active == true && x.Product.ToUpper().Contains("LBP")).ToListAsync();
                        leadTime = await ctx.LtOp2Inquiries.Where(x => x.Active == true && x.Product.ToUpper().Contains("LBP")).ToListAsync();
                        var eucE900Lbp = await ctx.MvEucE900Lbps.ToListAsync();
                        eucE900 = eucE900Lbp.MapEucE900();
                    }

                    structure = structure.GroupBy(x => new { x.PartNo8, x.Bc1, x.Bc12 }).Select(x => x.First()).ToList();

                    foreach (var item in structure)
                    {
                        
                        var checkIp2 = ip2.Where(x => x.PartNo == item.PartNo8 && x.Vendor == item.Bc12).ToList();
                        var checkD800 = eucD800.FirstOrDefault(x => x.NoParts == item.PartNo8);
                        var checkLt = leadTime.FirstOrDefault(x => x.PartNo == item.PartNo8 && x.Vendor == item.Bc12);
                        foreach (var term in calendarTerm)
                        {
                            var checkExists = lstCheckHis.Where(x =>x.Active == true && x.PartNo == item.PartNo8 && x.Vendor == item.Bc12 && x.Term == term.Term).FirstOrDefault();
                            //checkExists.ForEach(x => x.Active = false);
                            //checkExists.ForEach(x => lstUpdate.Add(x));
                            if(checkExists == null)
                            {
                                var checkIp1 = ip1.FirstOrDefault(x => x.PartNo == item.PartNo8 && x.Vendor == item.Bc12 && x.PeriodId == term.Id);
                                var checkE900 = eucE900.FirstOrDefault(x => x.NoParts == item.PartNo8 && x.Term == term.Term);

                                string?[] model = item.Model45?.Split(',');
                                string?[] hashModel = model?.Distinct().ToArray();
                                string? resultModel = hashModel == null ? null : string.Join("+", hashModel);
                                var add = new InvOutputPartHi()
                                {
                                    PartNo = item.PartNo8,
                                    Dim = item.Dim9,
                                    PartName = item.PartName11,
                                    Vendor = item.Bc12,
                                    CoMain = item.Comain22,
                                    Model = resultModel,
                                    DesCom = item.Des21,
                                    OrderMethod = item.Name20,
                                    SnpBox = item.Moq35.ToString(),
                                    TypeOfPart = item.Pr10,
                                    Term = term.Term,
                                    Product = product
                                };

                                if (checkD800 != null)
                                {
                                    add.Cp = checkD800.NoInventCntlPoi;
                                    add.UnitPrice = checkD800.CtAll.ToString();
                                    add.Sp = checkD800.NoStockPoi;
                                }
                                if (checkIp2.Count > 0)
                                {
                                    add.PackingMethod = checkIp2.FirstOrDefault().PackingMethod;
                                    add.InvControlMethod = checkIp2.FirstOrDefault(x => x.InvDate >= term.TimeFrom && term.TimeTo >= x.InvDate)?.InvMethod;
                                    add.PiResultHis = checkIp2.FirstOrDefault(x => x.PiDate >= term.TimeFrom && term.TimeTo >= x.PiDate)?.PiQty.ToString();
                                    var ommitedHis = checkIp2.Where(x => x.OmittedDate >= term.TimeFrom && term.TimeTo >= x.OmittedDate).ToList();
                                    add.OmmitedHis = ommitedHis.Count != 0 ? ommitedHis.Count.ToString() : null;
                                    var urgent_date = new List<string?>();
                                    foreach (var urgent in checkIp2.Where(x => x.UrgentDate >= term.TimeFrom && term.TimeTo >= x.UrgentDate).OrderBy(x => x.UrgentDate).ToList())
                                    {
                                        if (urgent != null)
                                        {
                                            urgent_date.Add(urgent.UrgentQt.ToString());
                                        }
                                    }
                                    add.UrgentCase = urgent_date.Count > 0 ? urgent_date.ToArray() : null;
                                }
                                if (checkIp1 != null)
                                {
                                    int timeOk = checkIp1.InvSnpDetails.Where(x => x.Differ == 0).ToList().Count();
                                    int timePlus = checkIp1.InvSnpDetails.Where(x => x.Differ > 0).ToList().Count();
                                    int timeMinus = checkIp1.InvSnpDetails.Where(x => x.Differ < 0).ToList().Count();
                                    string? status = null;
                                    if (timePlus == 0 && timeOk == 0 && timeMinus == 0)
                                    {
                                        status = "NY";
                                    }
                                    else if (timeOk > 0 && timePlus == 0 && timeMinus == 0)
                                    {
                                        status = "OK";
                                    }
                                    else if (timeMinus == 0 && timeOk == 0 && timePlus > 0)
                                    {
                                        status = "Plus";
                                    }
                                    else if (timePlus == 0 && timeOk == 0 && timeMinus > 0)
                                    {
                                        status = "Minus";
                                    }
                                    else
                                    {
                                        status = "Unstable";
                                    }
                                    add.SpCheckHis = status;

                                }
                                if (checkLt != null)
                                {
                                    add.KindOfPart = checkLt.KindOfPart;
                                    add.ProcessUsing = checkLt.MovingRoute;
                                    add.QtyKeepLine = checkLt.DoQty.ToString();
                                    add.TotalLt = checkLt.TotalLtTotal.ToString();
                                }
                                add.DefectHis = checkE900 == null ? null : Math.Round((double)checkE900.Sum, 2).ToString();
                                lstAdd.Add(add);
                            }
                            else
                            {
                                var checkIp1 = ip1.FirstOrDefault(x => x.PartNo == item.PartNo8 && x.Vendor == item.Bc12 && x.PeriodId == term.Id);
                                var checkE900 = eucE900.FirstOrDefault(x => x.NoParts == item.PartNo8 && x.Term == term.Term);
                                if (checkD800 != null)
                                {
                                    checkExists.Cp = checkD800.NoInventCntlPoi;
                                    checkExists.UnitPrice = checkD800.CtAll.ToString();
                                    checkExists.Sp = checkD800.NoStockPoi;
                                }
                                if (checkIp2.Count > 0)
                                {
                                    checkExists.PackingMethod = checkIp2.FirstOrDefault().PackingMethod;
                                    var checkInvMethod = checkIp2.FirstOrDefault(x => x.InvDate >= term.TimeFrom && term.TimeTo >= x.InvDate);
                                    if(checkInvMethod != null)
                                    {
                                        checkExists.InvControlMethod = checkInvMethod.InvMethod;
                                    }
                                   
                                    var checkPiResultHis = checkIp2.FirstOrDefault(x => x.PiDate >= term.TimeFrom && term.TimeTo >= x.PiDate);
                                    if (checkPiResultHis != null)
                                    {
                                        checkExists.PiResultHis = checkPiResultHis.PiQty.ToString();
                                    }
                                    var ommitedHis = checkIp2.Where(x => x.OmittedDate >= term.TimeFrom && term.TimeTo >= x.OmittedDate).ToList();
                                    if (ommitedHis.Count >0)
                                    {
                                        checkExists.OmmitedHis = ommitedHis.Count.ToString();
                                    }
                                    var checkUrgentCase = checkIp2.Where(x => x.UrgentDate >= term.TimeFrom && term.TimeTo >= x.UrgentDate).OrderBy(x => x.UrgentDate).ToList();
                                    if(checkUrgentCase.Count > 0)
                                    {
                                        var urgent_date = new List<string?>();
                                        foreach (var urgent in checkUrgentCase)
                                        {
                                            if (urgent != null)
                                            {
                                                urgent_date.Add(urgent.UrgentQt.ToString());
                                            }
                                        }
                                        checkExists.UrgentCase = urgent_date.ToArray() ;
                                    }
                                   
                                }
                                if (checkIp1 != null)
                                {
                                    int timeOk = checkIp1.InvSnpDetails.Where(x => x.Differ == 0).ToList().Count();
                                    int timePlus = checkIp1.InvSnpDetails.Where(x => x.Differ > 0).ToList().Count();
                                    int timeMinus = checkIp1.InvSnpDetails.Where(x => x.Differ < 0).ToList().Count();
                                    string? status = null;
                                    if (timePlus == 0 && timeOk == 0 && timeMinus == 0)
                                    {
                                        status = "NY";
                                    }
                                    else if (timeOk > 0 && timePlus == 0 && timeMinus == 0)
                                    {
                                        status = "OK";
                                    }
                                    else if (timeMinus == 0 && timeOk == 0 && timePlus > 0)
                                    {
                                        status = "Plus";
                                    }
                                    else if (timePlus == 0 && timeOk == 0 && timeMinus > 0)
                                    {
                                        status = "Minus";
                                    }
                                    else
                                    {
                                        status = "Unstable";
                                    }
                                    checkExists.SpCheckHis = status;

                                }
                                if (checkLt != null)
                                {
                                    checkExists.KindOfPart = checkLt.KindOfPart;
                                    checkExists.ProcessUsing = checkLt.MovingRoute;
                                    checkExists.QtyKeepLine = checkLt.DoQty.ToString();
                                    checkExists.TotalLt = checkLt.TotalLtTotal.ToString();
                                }
                                checkExists.DefectHis = checkE900 == null ? null : Math.Round((double)checkE900.Sum, 2).ToString();
                                lstUpdate.Add(checkExists);
                            }

                        }
                    }


                }
                else
                {
                    result.Status = (int)HttpStatusCode.BadRequest;
                    result.Message = "This time is not belong to of the calendar term!";
                    result.Error = true;
                    return result;
                }
                ctx.UpdateRange(lstUpdate);
                ctx.AddRange(lstAdd);
                await ctx.SaveChangesAsync();
                await GetOutputOp1Excel(product);
                var groupUser = ctx.AdmDetailUserGroups.Include(x => x.User).Where(x => x.Active == true && x.GroupId == new Guid("200989fe-1fe2-4da5-bd6f-576f185452a7")).ToList();
                var lstMail = groupUser.Where(x => x.User.Email != null && x.User.Email != "").Select(x => x.User.Email).ToList();
                var link = "http://cvn-vpsi/#/inventory/output/part-inv-his";
                string content = "<p style='font-weight: bold;'>Dear [Mrs/Mr]. All,</p>";
                content += "<p>The processing calculation output part inventory history of product " + product.ToUpper() + " is done.</p>";
                content += "<p>Now you can check it at: " + link + "</p>";

                new EmailService().Initial(lstMail, " Completed calc output part inventory history " + product.ToUpper(), content);

                return result;
            }
            catch (Exception e)
            {
                new EmailService().Initial(lstITMail, " Faile calc inventory op1", e.Message);
                result.Status = (int)HttpStatusCode.BadRequest;
                result.Message = e.Message;
                result.Error = true;
                return result;
            }
        }
        public async Task GetOutputOp1Excel(string product)
        {
            try
            {
                string filePath = Path.Combine(pathServer, "Sample\\PartInvHis.xlsx");
                FileInfo file = new FileInfo(filePath);
                ExcelPackage.LicenseContext = LicenseContext.NonCommercial;

                var today = DateOnly.FromDateTime(DateTime.Now);
                var termNow = ctx.InvCalendarTerms.FirstOrDefault(x => x.Active == true && x.TimeFrom <= today && today <= x.TimeTo);
                var lstTerm = await ctx.InvCalendarTerms.Where(x => x.Term == termNow.Term || x.TimeTo < today).OrderByDescending(x => x.TimeFrom).Take(3).OrderBy(x => x.TimeFrom).ToListAsync();

                var lstOutput = ctx.InvOutputPartHis.Where(x => x.Active == true && x.Product.ToUpper() == product.ToUpper() && lstTerm.Select(y => y.Term).ToList().Contains(x.Term)).ToList();
                var query = lstOutput.Where(x => x.Term == termNow.Term).GroupBy(x =>new { x.PartNo ,x.Vendor}).Select(g => g.First()).ToList();
                var model = query;


                using (ExcelPackage excelPackage = new ExcelPackage(file))
                {
                    ExcelWorksheet excelWorksheet = excelPackage.Workbook.Worksheets.First();
                    excelWorksheet.Cells["B2"].Value = product.ToUpper() + " PART INVENTORY HISTORY";
                    for (int i = 0; i < lstTerm.Count; i++)
                    {
                        if (i == 0)
                        {
                            excelWorksheet.Cells["U5"].Value = lstTerm[i].Term;
                            excelWorksheet.Cells["X5"].Value = lstTerm[i].Term;
                            excelWorksheet.Cells["AA5"].Value = lstTerm[i].Term;
                            excelWorksheet.Cells["AD5"].Value = lstTerm[i].Term;
                        }
                        if (i == 1)
                        {
                            excelWorksheet.Cells["V5"].Value = lstTerm[i].Term;
                            excelWorksheet.Cells["Y5"].Value = lstTerm[i].Term;
                            excelWorksheet.Cells["AB5"].Value = lstTerm[i].Term;
                            excelWorksheet.Cells["AE5"].Value = lstTerm[i].Term;
                        }
                        if (i == 2)
                        {
                            excelWorksheet.Cells["W5"].Value = lstTerm[i].Term;
                            excelWorksheet.Cells["Z5"].Value = lstTerm[i].Term;
                            excelWorksheet.Cells["AC5"].Value = lstTerm[i].Term;
                            excelWorksheet.Cells["AF5"].Value = lstTerm[i].Term;
                        }
                    }
                    //var lenghtUrgent = lstOutput.Max(x => x.UrgentCase?.Length ?? 0);

                    //for (int i = 0; i < lenghtUrgent; i++)
                    //{
                    //    var col = GetCellAddress((33 + i));
                    //    excelWorksheet.Cells[col + 5].Value = "Date happened" + i;
                    //    //result.LstUrgentDate.Add("Date happened " + (i + 1));
                    //}
                    //if (lenghtUrgent > 0)
                    //{
                    //    var col = GetCellAddress((33 + (lenghtUrgent - 1)));
                    //    excelWorksheet.Cells["AG4"].Value = "Urgent case";
                    //    excelWorksheet.Cells["AG4:" + col + 4].Merge = true;

                    //}
                    var lenghtUrgent = new List<int>();
                    int j = 6;
                    foreach (var item in model)
                    {


                        excelWorksheet.Cells["A" + j].Value = j - 5;
                        excelWorksheet.Cells["B" + j].Value = item.PartNo;
                        excelWorksheet.Cells["C" + j].Value = item.Dim;
                        excelWorksheet.Cells["D" + j].Value = item.Cp;
                        excelWorksheet.Cells["E" + j].Value = item.PartName;
                        excelWorksheet.Cells["F" + j].Value = item.Vendor;
                        excelWorksheet.Cells["G" + j].Value = item.CoMain;
                        excelWorksheet.Cells["H" + j].Value = item.Model;
                        excelWorksheet.Cells["I" + j].Value = item.DesCom;
                        excelWorksheet.Cells["J" + j].Value = item.OrderMethod;
                        excelWorksheet.Cells["K" + j].Value = item.UnitPrice;
                        excelWorksheet.Cells["L" + j].Value = item.SnpBox;
                        excelWorksheet.Cells["M" + j].Value = item.PackingMethod;
                        excelWorksheet.Cells["N" + j].Value = item.KindOfPart;
                        excelWorksheet.Cells["O" + j].Value = item.TypeOfPart;
                        excelWorksheet.Cells["P" + j].Value = item.ProcessUsing;
                        excelWorksheet.Cells["Q" + j].Value = item.QtyKeepLine;
                        excelWorksheet.Cells["R" + j].Value = item.TotalLt;
                        excelWorksheet.Cells["S" + j].Value = item.Sp;
                        excelWorksheet.Cells["T" + j].Value = item.InvControlMethod;


                        for (int i = 0; i < lstTerm.Count; i++)
                        {

                            var itemTerm = lstOutput.FirstOrDefault(x => x.Term == lstTerm[i].Term && x.PartNo == item.PartNo && x.Vendor == item.Vendor);
                            if (i == 0)
                            {
                                excelWorksheet.Cells["U" + j].Value = itemTerm == null ? null : itemTerm.SpCheckHis;
                                excelWorksheet.Cells["X" + j].Value = itemTerm == null ? null : itemTerm.PiResultHis;
                                excelWorksheet.Cells["AA" + j].Value = itemTerm == null ? null : itemTerm.DefectHis;
                                excelWorksheet.Cells["AD" + j].Value = itemTerm == null ? null : itemTerm.OmmitedHis;
                            }
                            if (i == 1)
                            {
                                excelWorksheet.Cells["V" + j].Value = itemTerm == null ? null : itemTerm.SpCheckHis;
                                excelWorksheet.Cells["Y" + j].Value = itemTerm == null ? null : itemTerm.PiResultHis;
                                excelWorksheet.Cells["AB" + j].Value = itemTerm == null ? null : itemTerm.DefectHis;
                                excelWorksheet.Cells["AE" + j].Value = itemTerm == null ? null : itemTerm.OmmitedHis;
                            }
                            if (i == 2)
                            {
                                excelWorksheet.Cells["W" + j].Value = itemTerm == null ? null : itemTerm.SpCheckHis;
                                excelWorksheet.Cells["Z" + j].Value = itemTerm == null ? null : itemTerm.PiResultHis;
                                excelWorksheet.Cells["AC" + j].Value = itemTerm == null ? null : itemTerm.DefectHis;
                                excelWorksheet.Cells["AF" + j].Value = itemTerm == null ? null : itemTerm.OmmitedHis;
                            }
                        }
                       
                        var urgentDate = item.UrgentCase == null?new List<string>(): item.UrgentCase.ToList();
                        for (int i = 0; i < urgentDate.Count; i++)
                        {
                            var col = GetCellAddress((33 + i));
                            excelWorksheet.Cells[col + j].Value = urgentDate[i];
                        }
                        lenghtUrgent.Add(urgentDate.Count);
                        j++;

                    }

                    var colEnd = GetCellAddress((33 + (lenghtUrgent.Max() - 1)));

                    for (int i = 0; i < lenghtUrgent.Max(); i++)
                    {
                        var col = GetCellAddress((33 + i));
                        excelWorksheet.Cells[col + 5].Value = "Time" + (i+1);
                        //result.LstUrgentDate.Add("Date happened " + (i + 1));
                    }
                    if (lenghtUrgent.Max() > 0)
                    {
                        var col = GetCellAddress((33 + (lenghtUrgent.Max() - 1)));
                        excelWorksheet.Cells["AG4"].Value = "Urgent case";
                        excelWorksheet.Cells["AG4:" + col + 4].Merge = true;

                    }

                    excelWorksheet.Cells["A4:" + colEnd + (j - 1)].Style.Font.Size = 11;
                    excelWorksheet.Cells["A4:" + colEnd + (j - 1)].Style.Font.Name = "Calibri";
                    excelWorksheet.Cells["A4:" + colEnd + (j - 1)].Style.Border.Top.Style = ExcelBorderStyle.Thin;
                    excelWorksheet.Cells["A4:" + colEnd + (j - 1)].Style.Border.Bottom.Style = ExcelBorderStyle.Thin;
                    excelWorksheet.Cells["A4:" + colEnd + (j - 1)].Style.Border.Left.Style = ExcelBorderStyle.Thin;
                    excelWorksheet.Cells["A4:" + colEnd + (j - 1)].Style.Border.Right.Style = ExcelBorderStyle.Thin;

                    string outputPath = Path.Combine(outputPathOri, "8. Inventory\\InvOp1" + product.ToUpper(), "Output_Part_Inv_His_" + product.ToUpper() + "_" + DateTime.Now.ToString("yyyy-MM-dd-hh-mm-ss") + ".xlsx");
                    FileInfo excelFile = new FileInfo(outputPath);
                    excelPackage.SaveAs(excelFile);

                }


            }
            catch (Exception e)
            {
                Console.WriteLine("Except " + e);

            }
        }
        private string GetCellAddress(int columnIndex)
        {
            string columnLetter = "";
            while (columnIndex > 0)
            {
                int remainder = (columnIndex - 1) % 26;
                columnLetter = Convert.ToChar('A' + remainder) + columnLetter;
                columnIndex = (columnIndex - 1) / 26;
            }
            return columnLetter;
        }
        public async Task SaveDataVisualizationSpJob()
        {
            try
            {
                var result = new InvVisualizationOp1Model();
                var lstResult = new List<InvVisualizationOp1>();
                string[] listBc1 = { "3100", "3500", "3600" };
                var config = new MapperConfiguration(cfg => cfg.CreateMap<TodStructureOutputContentLbp, TodStructureOutputContentIj>());
                var mapper = config.CreateMapper();

                int count = 0;
                List<TodStructureOutputContentIj> listPart = new List<TodStructureOutputContentIj>();
                List<TodStructureOutputContentIj> listPart1 = new List<TodStructureOutputContentIj>();
                var dateNowUtc = DateTime.Now;
                DateTime? dateCheck = null;
                DateTime? dateCheck1 = null;

                var dateNext = dateNowUtc.AddDays(-1);
                dateCheck = new DateTime(dateNext.Year, dateNext.Month, dateNext.Day, 8, 0, 0);
                dateCheck1 = new DateTime(dateNowUtc.Year, dateNowUtc.Month, dateNowUtc.Day, 7, 59, 59);


                List<VisualizationView> lstModel1 = new List<VisualizationView>();

                listPart = ctx.TodStructureOutputContentIjs.Where(x => x.Active == true && listBc1.Contains(x.Bc1) && !x.Bc12.Equals("3100")).ToList();
                lstModel1.AddRange(listPart.GroupBy(x => new { x.PartNo8 }).Select(g => new VisualizationView { tod = g.First(), Product = "IJP" }).ToList());
                var partLbp = await ctx.TodStructureOutputContentLbps.Where(x => x.Active == true && listBc1.Contains(x.Bc1) && !x.Bc12.Equals("3100")).ToListAsync();
                listPart1 = mapper.Map<List<TodStructureOutputContentLbp>, List<TodStructureOutputContentIj>>(partLbp);
                lstModel1.AddRange(listPart1.GroupBy(x => new { x.PartNo8 }).Select(g => new VisualizationView { tod = g.First(), Product = "LBP" }).ToList());

                //var listPartNo = lstModel1.Select(x => x.tod.PartNo8).ToList();
                var listStoreIn = ctx.VlinkageHksStoreInOuts.Where(x => x.IOut == 1 && x.PartNo != null).ToList().GroupBy(x => x.PartNo).ToDictionary(g => g.Key, g => g.ToList());
                var listStoreOut = ctx.VlinkageHksStoreInOuts.Where(x => x.IOut == 2 && x.PartNo != null).ToList().GroupBy(x => x.PartNo).ToDictionary(g => g.Key, g => g.ToList());
                var listVisual = ctx.InvVisualizationOp1s.Where(x => x.Active == true).ToList().GroupBy(x => x.PartNo).ToDictionary(g => g.Key, g => g.OrderByDescending(x => x.CreatedDate).ToList());
                var listReceive = ctx.VlinkageHksReceiveParts.ToList().GroupBy(x => x.PartNo).ToDictionary(g => g.Key, g => g.ToList());
                var listShipping = ctx.VlinkageHksShippingParts.ToList().GroupBy(x => x.PartNo).ToDictionary(g => g.Key, g => g.ToList());
                var listLending = ctx.VlinkageLendingPartPdcIjs.ToList().GroupBy(x => x.PartNumber).ToDictionary(g => g.Key, g => g.ToList());
                var listLendingAssy = ctx.VlinkageLendingPartAssyPcbIjs.ToList().GroupBy(x => x.PartNumber).ToDictionary(g => g.Key, g => g.ToList());
                string[] pdc2Lbp = { "TS01", "TS06", "TSB5", "TS18", "TS15", "TSB4" };
                string[] pdc2Ijp = { "TS07", "TS12", "TS04", "TS19", "TS16", "TS20", "TSA" };
                string[] logLbp = { "TSB5" };
                string[] logIjp = { "TSB" };

                int dem = 1;
                count = lstModel1.Count();
                DateOnly dateNow = DateOnly.FromDateTime(DateTime.Now);
                foreach (var item1 in lstModel1)
                {
                    var item = item1.tod;
                    var lstSamePart = item1.Product.Equals("IJP") ? listPart.Where(x => x.PartNo8.Equals(item.PartNo8)) : listPart1.Where(x => x.PartNo8.Equals(item.PartNo8));
                    var model = string.Join(",", lstSamePart.Where(x => !x.Model45.IsNullOrEmpty()).Select(x => x.Model45).ToList());
                    var merCode = string.Join(",", lstSamePart.Where(x => !x.MerCode47.IsNullOrEmpty()).Select(x => x.MerCode47).ToList());

                    //var listLast = listVisual.Where(x => x.PartNo.Equals(item.PartNo8)).OrderByDescending(x => x.CreatedDate).ToList();
                    listVisual.TryGetValue(item.PartNo8, out var listLast);
                    listLast = listLast ?? new List<InvVisualizationOp1>();
                    var last = listLast.Count() > 0 ? listLast.First() : null;

                    listStoreIn.TryGetValue(item.PartNo8, out var listPartIn);
                    listPartIn = listPartIn != null ? listPartIn.Where(x => dateCheck <= x.DateEntry && x.DateEntry <= dateCheck1).ToList() : new List<VlinkageHksStoreInOut>();

                    listStoreOut.TryGetValue(item.PartNo8, out var listPartOut);
                    listPartOut = listPartOut != null ? listPartOut.Where(x => dateCheck <= x.DateEntry && x.DateEntry <= dateCheck1).ToList() : new List<VlinkageHksStoreInOut>();

                    var MoLastRemain = last != null ? last.MoRemain.Value.FormatDouble() : 0;
                    var MsdLastRemain = last != null ? last.MsdRemain.Value.FormatDouble() : 0;

                    double? MoStoreIn = 0;
                    double? MoStoreOut = 0;
                    double? MoStoreOutS = 0;
                    double? MsdStoreIn = 0;
                    double? MsdStoreOut = 0;
                    double? MsdStoreOutS = 0;
                    if (listPartIn.Any(x => x.DeptName != null && x.DeptName.Contains("MO")))
                    {
                        MoStoreIn = listPartIn.Sum(x => x.Qty);
                        MoStoreOut = listPartOut.Where(x => x.Remark == null || (x.Remark != null && !x.Remark.Contains("Shikyu") && !x.Remark.Contains("Thăng Long"))).Sum(x => x.Qty);
                        MoStoreOutS = listPartOut.Where(x => x.Remark != null).ToList().Where(x => x.Remark.Contains("Shikyu") || x.Remark.Contains("Thăng Long")).Sum(x => x.Qty);

                    }
                    else if (listPartIn.Any(x => x.DeptName != null && x.DeptName.Contains("MSD")))
                    {
                        MsdStoreIn = listPartIn.Sum(x => x.Qty);
                        MsdStoreOut = listPartOut.Where(x => x.Remark == null || (x.Remark != null && !x.Remark.Contains("Shikyu") && !x.Remark.Contains("Thăng Long"))).Sum(x => x.Qty);
                        MsdStoreOutS = listPartOut.Where(x => x.Remark != null).ToList().Where(x => x.Remark.Contains("Shikyu") || x.Remark.Contains("Thăng Long")).Sum(x => x.Qty);

                    }
                    ///pdc2
                    listReceive.TryGetValue(item.PartNo8, out var listPartReceive);
                    listPartReceive = listPartReceive != null ? (item1.Product.Equals("IJP") ? listPartReceive.Where(x => dateCheck <= x.TimeReceive && x.TimeReceive <= dateCheck1 && pdc2Ijp.Contains(x.Location)).ToList() : listPartReceive.Where(x => dateCheck <= x.TimeReceive && x.TimeReceive <= dateCheck1 && pdc2Lbp.Contains(x.Location)).ToList()) : new List<VlinkageHksReceivePart>();

                    var Pdc2PoReceive = listPartReceive.Sum(x => x.ActQty);

                    listShipping.TryGetValue(item.PartNo8, out var listPartShipping);
                    listPartShipping = listPartShipping != null ? (item1.Product.Equals("IJP") ? listPartShipping.Where(x => x.DeliveryKey != null).ToList().Where(x => !x.DeliveryKey.Substring(0, 4).Equals("NGRT") && dateCheck <= x.TimeReceive && x.TimeReceive <= dateCheck1 && pdc2Ijp.Contains(x.Location)).ToList() : listPartShipping.Where(x => x.DeliveryKey != null).ToList().Where(x => !x.DeliveryKey.Substring(0, 4).Equals("NGRT") && dateCheck <= x.TimeReceive && x.TimeReceive <= dateCheck1 && pdc2Lbp.Contains(x.Location)).ToList()) : new List<VlinkageHksShippingPart>();

                    var Pdc2Shikyu = listPartShipping.Sum(x => x.ActQty);

                    listLending.TryGetValue(item.PartNo8, out var listPartLending);
                    var dateNowCheck = DateOnly.FromDateTime(DateTime.Now);
                    var listPartLendingBorrow = listPartLending != null ? listPartLending.Where(x => dateNowCheck == x.BorrowDate && (x.BorrowLoc[0].Equals("Z") || x.BorrowLoc[0].Equals("R") || x.BorrowLoc[0].Equals("K"))).ToList() : new List<VlinkageLendingPartPdcIj>();
                    var listPartLendingReturn = listPartLending != null ? listPartLending.Where(x => dateNowCheck == x.ReturnDate && (x.BorrowLoc[0].Equals("Z") || x.BorrowLoc[0].Equals("R") || x.BorrowLoc[0].Equals("K"))).ToList() : new List<VlinkageLendingPartPdcIj>();

                    var Pdc2LendingBorrow = listPartLendingBorrow.Sum(x => x.QtyBorrow);
                    var Pdc2LendingReturn = listPartLendingReturn.Sum(x => x.QtyReturn);
                    //log
                    listReceive.TryGetValue(item.PartNo8, out var listPartReceive1);
                    listPartReceive1 = listPartReceive1 != null ? (item1.Product.Equals("IJP") ? listPartReceive1.Where(x => dateCheck <= x.TimeReceive && x.TimeReceive <= dateCheck1 && logIjp.Contains(x.Location)).ToList() : listPartReceive1.Where(x => dateCheck <= x.TimeReceive && x.TimeReceive <= dateCheck1 && logLbp.Contains(x.Location)).ToList()) : new List<VlinkageHksReceivePart>();

                    var LogPoReceive = listPartReceive1.Sum(x => x.ActQty);

                    //assy
                    listLendingAssy.TryGetValue(item.PartNo8, out var listPartLendingAssy);
                    var listPartLendingAssyBorrow = listPartLendingAssy != null ? listPartLendingAssy.Where(x => dateNowCheck == x.BorrowDate).ToList() : new List<VlinkageLendingPartAssyPcbIj>();
                    var listPartLendingAssyReturn = listPartLendingAssy != null ? listPartLendingAssy.Where(x => dateNowCheck == x.ReturnDate).ToList() : new List<VlinkageLendingPartAssyPcbIj>();

                    var AssyLendingBorrow = listPartLendingAssyBorrow.Sum(x => x.QtyBorrow);
                    var AssyLendingReturn = listPartLendingAssyReturn.Sum(x => x.QtyReturn);

                    lstResult.Add(new InvVisualizationOp1()
                    {
                        PartNo = item.PartNo8,
                        PartName = item.PartName11,
                        Model = string.Join(",", model.Split(",").Distinct().ToList()),
                        Dest = string.Join(",", merCode.Split(",").Distinct().ToList()),
                        Date = dateNow,
                        MoLastRemain = MoLastRemain,
                        MoStoreIn = MoStoreIn,
                        MoStoreOut = MoStoreOut,
                        MoStoreOutS = MoStoreOutS,
                        MoRemain = MoLastRemain + MoStoreIn - MoStoreOut - MoStoreOutS,
                        MsdLastRemain = MsdLastRemain,
                        MsdStoreIn = MsdStoreIn,
                        MsdStoreOut = MsdStoreOut,
                        MsdStoreOutS = MsdStoreOutS,
                        MsdRemain = MsdLastRemain + MsdStoreIn - MsdStoreOut - MsdStoreOutS,
                        PcbLastRemain = last != null ? last.PcbRemain.Value.FormatDouble() : 0,
                        PcbStoreIn = 0,
                        PcbStoreOut = 0,
                        PcbStoreOutS = 0,
                        PcbRemain = 0,
                        Pdc2LastRemain = last != null ? last.Pdc2Remain.Value.FormatDouble() : 0,
                        Pdc2LastRemainStore = last != null ? last.Pdc2LastRemainStore.Value.FormatDouble() : 0,
                        Pdc2PoReceive = Pdc2PoReceive,
                        Pdc2InhouseTransfer = 0,
                        Pdc2Shikyu = Pdc2Shikyu,
                        Pdc2LendingBorrow = Pdc2LendingBorrow,
                        Pdc2LendingReturn = Pdc2LendingReturn,
                        Pdc2SupplyAssy = 0,
                        Pdc2Remain = 0,
                        Pdc2RemainStore = 0,
                        LogLastRemain = last != null ? last.LogRemain.Value.FormatDouble() : 0,
                        LogPoReceive = LogPoReceive,
                        LogLendingBorrow = 0,
                        LogLendingReturn = 0,
                        LogSupplyAssy = 0,
                        LogRemain = 0,
                        AssyLastRemain = last != null ? last.AssyRemain.Value.FormatDouble() : 0,
                        AssyPdc2Supply = 0,
                        AssyLendingBorrow = AssyLendingBorrow,
                        AssyLendingReturn = AssyLendingReturn,
                        AssyRpMachine = 0,
                        AssyRemain = 0,
                        TotalRemainMo = 0,
                        TotalRemainMsd = 0,
                        TotalRemainPcb = 0,
                        TotalRemainPdc2Rec = 0,
                        TotalRemainPdc2Store = 0,
                        TotalRemainLog = 0,
                        TotalRemainAssy = 0,
                        TotalRemainLending = 0,
                        TotalRemainTtl = 0,
                        Product = item1.Product,
                        Vendor = item.Bc12,

                    });
                    dem++;
                }

                ctx.InvVisualizationOp1s.AddRange(lstResult);
                ctx.SaveChanges();

            }
            catch (Exception e)
            {
                Console.WriteLine("Except " + e);

            }
        }
        public async Task SaveDataVisualizationSpOp2Job()
        {
            try
            {
                var result = new InvVisualizationOp1Model();
                var lstResult = new List<InvVisualizationOp2>();
                string[] listBc1 = { "3200" };
                var config = new MapperConfiguration(cfg => cfg.CreateMap<TodStructureOutputContentLbp, TodStructureOutputContentIj>());
                var mapper = config.CreateMapper();

                int count = 0;
                List<TodStructureOutputContentIj> listPart = new List<TodStructureOutputContentIj>();
                List<TodStructureOutputContentIj> listPart1 = new List<TodStructureOutputContentIj>();
                var dateNowUtc = DateTime.Now;
                DateTime? dateCheck = null;
                DateTime? dateCheck1 = null;

                var dateNext = dateNowUtc.AddDays(-1);
                dateCheck = new DateTime(dateNext.Year, dateNext.Month, dateNext.Day, 8, 0, 0);
                dateCheck1 = new DateTime(dateNowUtc.Year, dateNowUtc.Month, dateNowUtc.Day, 7, 59, 59);


                List<VisualizationView> lstModel1 = new List<VisualizationView>();

                listPart = ctx.TodStructureOutputContentIjs.Where(x => x.Active == true && listBc1.Contains(x.Bc1) && !x.Bc12.Equals("3100")).ToList();
                lstModel1.AddRange(listPart.GroupBy(x => new { x.PartNo8 }).Select(g => new VisualizationView { tod = g.First(), Product = "IJP" }).ToList());
                var partLbp = await ctx.TodStructureOutputContentLbps.Where(x => x.Active == true && listBc1.Contains(x.Bc1) && !x.Bc12.Equals("3100")).ToListAsync();
                listPart1 = mapper.Map<List<TodStructureOutputContentLbp>, List<TodStructureOutputContentIj>>(partLbp);
                lstModel1.AddRange(listPart1.GroupBy(x => new { x.PartNo8 }).Select(g => new VisualizationView { tod = g.First(), Product = "LBP" }).ToList());

                //var listPartNo = lstModel1.Select(x => x.tod.PartNo8).ToList();
                var listStoreIn = ctx.VlinkageHksStoreInOuts.Where(x => x.IOut == 1 && x.PartNo != null).ToList().GroupBy(x => x.PartNo).ToDictionary(g => g.Key, g => g.ToList());
                var listStoreOut = ctx.VlinkageHksStoreInOuts.Where(x => x.IOut == 2 && x.PartNo != null).ToList().GroupBy(x => x.PartNo).ToDictionary(g => g.Key, g => g.ToList());
                var listVisual = ctx.InvVisualizationOp2s.Where(x => x.Active == true).ToList().GroupBy(x => x.PartNo).ToDictionary(g => g.Key, g => g.OrderByDescending(x => x.CreatedDate).ToList());
                var listReceive = ctx.VlinkageHksReceiveParts.ToList().GroupBy(x => x.PartNo).ToDictionary(g => g.Key, g => g.ToList());
                var listShipping = ctx.VlinkageHksShippingParts.ToList().GroupBy(x => x.PartNo).ToDictionary(g => g.Key, g => g.ToList());
                var listLending = ctx.VlinkageLendingPartPdcIjs.ToList().GroupBy(x => x.PartNumber).ToDictionary(g => g.Key, g => g.ToList());
                var listLendingAssy = ctx.VlinkageLendingPartAssyPcbIjs.ToList().GroupBy(x => x.PartNumber).ToDictionary(g => g.Key, g => g.ToList());
                string[] pdc2Lbp = { "TS01", "TS06", "TSB5", "TS18", "TS15", "TSB4" };
                string[] pdc2Ijp = { "TS07", "TS12", "TS04", "TS19", "TS16", "TS20", "TSA" };
                string[] logLbp = { "TSB5" };
                string[] logIjp = { "TSB" };

                int dem = 1;
                count = lstModel1.Count();
                DateOnly dateNow = DateOnly.FromDateTime(DateTime.Now);
                foreach (var item1 in lstModel1)
                {
                    var item = item1.tod;
                    var lstSamePart = item1.Product.Equals("IJP") ? listPart.Where(x => x.PartNo8.Equals(item.PartNo8)) : listPart1.Where(x => x.PartNo8.Equals(item.PartNo8));
                    var model = string.Join(",", lstSamePart.Where(x => !x.Model45.IsNullOrEmpty()).Select(x => x.Model45).ToList());
                    //var merCode = string.Join(",", lstSamePart.Where(x => !x.MerCode47.IsNullOrEmpty()).Select(x => x.MerCode47).ToList());

                    //var listLast = listVisual.Where(x => x.PartNo.Equals(item.PartNo8)).OrderByDescending(x => x.CreatedDate).ToList();
                    listVisual.TryGetValue(item.PartNo8, out var listLast);
                    listLast = listLast ?? new List<InvVisualizationOp2>();
                    var last = listLast.Count() > 0 ? listLast.First() : null;

                    listStoreIn.TryGetValue(item.PartNo8, out var listPartIn);
                    listPartIn = listPartIn != null ? listPartIn.Where(x => dateCheck <= x.DateEntry && x.DateEntry <= dateCheck1).ToList() : new List<VlinkageHksStoreInOut>();

                    listStoreOut.TryGetValue(item.PartNo8, out var listPartOut);
                    listPartOut = listPartOut != null ? listPartOut.Where(x => dateCheck <= x.DateEntry && x.DateEntry <= dateCheck1).ToList() : new List<VlinkageHksStoreInOut>();
                    var MoLastRemain = last != null ? last.MoRemain.Value.FormatDouble() : 0;
                    double? MoStoreIn = 0;
                    double? MoStoreOut = 0;

                    if (listPartIn.Any(x => x.DeptName != null && x.DeptName.Contains("MO")))
                    {
                        MoStoreIn = listPartIn.Sum(x => x.Qty);
                        MoStoreOut = listPartOut.Where(x => x.Remark == null || (x.Remark != null && !x.Remark.Contains("Shikyu") && !x.Remark.Contains("Thăng Long"))).Sum(x => x.Qty);
                    }
                    //pcb
                    var dateNowCheck = DateOnly.FromDateTime(DateTime.Now);
                    listLendingAssy.TryGetValue(item.PartNo8, out var listPartLendingAssy);
                    var listPartLendingAssyBorrow = listPartLendingAssy != null ? listPartLendingAssy.Where(x => dateNowCheck == x.BorrowDate).ToList() : new List<VlinkageLendingPartAssyPcbIj>();
                    var listPartLendingAssyReturn = listPartLendingAssy != null ? listPartLendingAssy.Where(x => dateNowCheck == x.ReturnDate).ToList() : new List<VlinkageLendingPartAssyPcbIj>();

                    var AssyLendingBorrow = listPartLendingAssyBorrow.Sum(x => x.QtyBorrow);
                    var AssyLendingReturn = listPartLendingAssyReturn.Sum(x => x.QtyReturn);
                    //pdc
                    listReceive.TryGetValue(item.PartNo8, out var listPartReceive);
                    var listPartReceive1 = listPartReceive != null ? listPartReceive.Where(x => dateCheck <= x.TimeReceive && x.TimeReceive <= dateCheck1).ToList() : new List<VlinkageHksReceivePart>();
                    var listPartReceive2 = listPartReceive != null ? listPartReceive.Where(x => dateCheck <= x.TimeReceive && x.TimeReceive <= dateCheck1 && x.DeliveryKey.Substring(0, 2).Equals("BR")).ToList() : new List<VlinkageHksReceivePart>();

                    var Pdc2PoReceive1 = listPartReceive1.Sum(x => x.ActQty);
                    var Pdc2PoReceive2 = listPartReceive2.Sum(x => x.ActQty);

                    listShipping.TryGetValue(item.PartNo8, out var listPartShipping);
                    listPartShipping = listPartShipping != null ? listPartShipping.Where(x => x.DeliveryKey != null).ToList().Where(x =>  x.DeliveryKey.Substring(0, 2).Equals("BR") && dateCheck <= x.TimeReceive && x.TimeReceive <= dateCheck1).ToList() : new List<VlinkageHksShippingPart>();

                    var Pdc2Shikyu = listPartShipping.Sum(x => x.ActQty);

                    listLending.TryGetValue(item.PartNo8, out var listPartLending);
                    var listPartLendingBorrow = listPartLending != null ? listPartLending.Where(x => dateNowCheck == x.BorrowDate && x.BorrowLoc.Contains("PDC2")).ToList() : new List<VlinkageLendingPartPdcIj>();
                    var listPartLendingReturn = listPartLending != null ? listPartLending.Where(x => dateNowCheck == x.ReturnDate && x.BorrowLoc.Contains("PDC2")).ToList() : new List<VlinkageLendingPartPdcIj>();

                    var Pdc2LendingBorrow = listPartLendingBorrow.Sum(x => x.QtyBorrow);
                    var Pdc2LendingReturn = listPartLendingReturn.Sum(x => x.QtyReturn);

                    lstResult.Add(new InvVisualizationOp2()
                    {
                        PartNo = item.PartNo8,
                        PartName = item.PartName11,
                        Model = string.Join(",", model.Split(",").Distinct().ToList()),
                        Unit = item.Unit13,
                        Date = dateNow,
                        MoLastRemain = MoLastRemain,
                        MoStoreIn = MoStoreIn,
                        MoStoreOut = MoStoreOut,
                        MoRemain = (MoLastRemain + MoStoreIn - MoStoreOut),
                        PcbLastRemain = last != null ? last.PcbRemain.Value.FormatDouble() : 0,
                        PcbPdc2Supply = 0,
                        PcbLendingBorrow = AssyLendingBorrow,
                        PcbLendingReturn = AssyLendingReturn,
                        PcbRpUnit = 0,
                        PcbRemain = 0,
                        Pdc2LastRemain = last != null ? last.Pdc2Remain.Value.FormatDouble() : 0,
                        Pdc2PoReceive = Pdc2PoReceive1,
                        Pdc2InhouseSupply = 0,
                        Pdc2TlTransfer = Pdc2PoReceive2,
                        Pdc2TsTransfer = Pdc2Shikyu,
                        Pdc2LendingBorrow = Pdc2LendingBorrow,
                        Pdc2LendingReturn = Pdc2LendingReturn,
                        Pdc2SupplyPcb = 0,
                        Pdc2Remain = 0,
                        TotalMoStock = 0,
                        TotalPdc2Stock = 0,
                        TotalPcbStock = 0,
                        TotalLending = 0,
                        TotalTtlRemain = 0,
                        Product = item1.Product,
                        Vendor = item.Bc12,

                    });
                    dem++;
                }

                ctx.InvVisualizationOp2s.AddRange(lstResult);
                ctx.SaveChanges();

            }
            catch (Exception e)
            {
                Console.WriteLine("Except " + e);

            }
        }
        public async Task SaveDataD800AndLending()
        {
            try
            {
                var d800Ij = ctx.VlinkageEucIjD800s.ToList();
                var d800Lbp = ctx.VlinkageEucLbpD800s.ToList();
                List<InvD800> listD800 = new List<InvD800>();
                foreach (var item in d800Ij)
                {
                    listD800.Add(new InvD800()
                    {
                        NoParts = item.NoParts,
                        CtAll = item.CtAll,
                        NoStockPoi = item.NoStockPoi,
                        QtStock = item.QtStock,
                        Product = "IJP",
                        DtEntry = item.DtEntry
                    });
                }
                foreach (var item in d800Lbp)
                {
                    listD800.Add(new InvD800()
                    {
                        NoParts = item.NoParts,
                        CtAll = item.CtAll,
                        NoStockPoi = item.NoStockPoi,
                        QtStock = item.QtStock,
                        Product = "LBP",
                        DtEntry = item.DtEntry
                    });
                }
                var dateRemove = DateOnly.FromDateTime(DateTime.Now.AddDays(-15));
                var listRemove = ctx.InvD800s.Where(x => x.DtEntry == dateRemove).ToList();
                ctx.InvD800s.RemoveRange(listRemove);
                ctx.InvD800s.AddRange(listD800);
                //lending
                var lendingAssy = ctx.VlinkageLendingPartAssyPcbIjs.ToList();
                var lendingPdc = ctx.VlinkageLendingPartPdcIjs.ToList();
                List<InvLendingPartAssyPcbIj> listLendingAssy = new List<InvLendingPartAssyPcbIj>();
                foreach (var item in lendingAssy)
                {
                    listLendingAssy.Add(new InvLendingPartAssyPcbIj()
                    {
                        PartNumber = item.PartNumber,
                        QtyBorrow = item.QtyBorrow,
                        QtyReturn = item.QtyReturn,
                        QtyDefect = item.QtyDefect,
                        BorrowDate = item.BorrowDate,
                    });
                }
                List<InvLendingPartPdcIj> listLendingPdc = new List<InvLendingPartPdcIj>();
                foreach (var item in lendingPdc)
                {
                    listLendingPdc.Add(new InvLendingPartPdcIj()
                    {
                        PartNumber = item.PartNumber,
                        QtyBorrow = item.QtyBorrow,
                        QtyReturn = item.QtyReturn,
                        BorrowDate = item.BorrowDate,
                    });
                }
                ctx.InvLendingPartAssyPcbIjs.AddRange(listLendingAssy);
                ctx.InvLendingPartPdcIjs.AddRange(listLendingPdc);
                var listRemoveAssy = ctx.InvLendingPartAssyPcbIjs.Where(x => x.CreatedDate == dateRemove).ToList();
                ctx.InvLendingPartAssyPcbIjs.RemoveRange(listRemoveAssy);
                var listRemovePdc = ctx.InvLendingPartPdcIjs.Where(x => x.CreatedDate == dateRemove).ToList();
                ctx.InvLendingPartPdcIjs.RemoveRange(listRemovePdc);
                ctx.SaveChanges();

            }
            catch (Exception e)
            {
                Console.WriteLine("Except " + e);

            }
        }
    }
}
