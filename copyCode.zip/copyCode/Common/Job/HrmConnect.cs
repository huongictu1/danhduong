﻿using PDCProjectApi.Common;
using Microsoft.Data.SqlClient;
using System.Data;

namespace PDCProjectApi.Common.Job
{
    public static class HrmConnect
    {
        private static string Host = "";
        private static string User = "sa";
        private static string DBname = "";
        private static string Password = "";
        private static string connString =
                String.Format(
                    "Data Source={0};Initial Catalog={1};User ID={2};Password={3};TrustServerCertificate=True;",
                    Host,
                    DBname,
                    User,
                    Password);
        public static DataTable? getDataTable(string sql)
        {
            try
            {
                DataTable dt = new DataTable();
                using (var conn = new SqlConnection(connString))
                {
                    conn.Open();
                    using (var command = new SqlCommand(sql, conn))
                    {
                        SqlDataReader dtr = command.ExecuteReader();
                        dt.Load(dtr);
                    }
                    conn.Close();
                }
                return dt;
            }
            catch
            {
                return null;
            }
        }

        public static void UpdateListCommandSQL(List<string> lstUpdate)
        {
            try
            {
                using (SqlConnection conn = new SqlConnection(connString))
                {
                    conn.Open();
                    int result = 0;
                    foreach (string item in lstUpdate)
                    {
                        SqlCommand command = new SqlCommand(item, conn);
                        result += command.ExecuteNonQuery();
                    }
                    conn.Close();
                }
            }
            catch
            {

            }
            finally
            {

            }
        }

        public static List<DeptHRM>? GetListDepartmentHRM()
        {
            try
            {
                DataTable dt = new DataTable();
                using (var conn = new SqlConnection(connString))
                {
                    conn.Open();
                    using (var command = new SqlCommand(@"", conn))
                    {
                        SqlDataReader dtr = command.ExecuteReader();
                        dt.Load(dtr);
                    }
                    conn.Close();
                }
                return ExtensionMethod.ConvertDatatableToList<DeptHRM>(dt);
            }
            catch
            {
                return null;
            }
        }

        public static List<VInfor>? GetListVinforByDate()
        {
            try
            {
                DataTable dt = new DataTable();
                using (var conn = new SqlConnection(connString))
                {
                    conn.Open();
                    using (var command = new SqlCommand(@"select  e.EmpCo
    ", conn))
                    {
                        SqlDataReader dtr = command.ExecuteReader();
                        dt.Load(dtr);
                    }
                    conn.Close();
                }
                return ExtensionMethod.ConvertDatatableToList<VInfor>(dt);
            }
            catch
            {
                return null;
            }
        }

        public static List<VInforAll>? GetListVinforAll()
        {
            try
            {
                DataTable dt = new DataTable();
                using (var conn = new SqlConnection(connString))
                {
                    conn.Open();
                    using (var command = new SqlCommand(@"select EmpCo'')", conn))
                    {
                        SqlDataReader dtr = command.ExecuteReader();
                        dt.Load(dtr);
                    }
                    conn.Close();
                }
                return ExtensionMethod.ConvertDatatableToList<VInforAll>(dt);
            }
            catch
            {
                return null;
            }
        }
    }
    public class DeptHRM
    {
        public int DepartmentID { get; set; }
        public string? Department { get; set; }
        public string? DeptName { get; set; }
        public int FactID { get; set; }
        public string Factory { get; set; }
        public string AccCode { get; set; }
        public string Division { get; set; }
    }
    public class VInfor
    {
        public string EmployeeId { get; set; } = null!;
        public DateTime RecruitmentDate { get; set; }
        public string SEX { get; set; } = null!;
        public string LastName { get; set; } = null!;
        public int DepartmentID { get; set; }
        public string Grade { get; set; } = null!;
        //public string CardId { get; set; } = null!;
        //public DateTime BirthDate { get; set; }
    }

    public class VInforAll
    {
        public string EmpCode { get; set; } = null!;
        public string EmpNameEN { get; set; } = null!;
        public string SEX { get; set; } = null!;
        public string Grade { get; set; } = null!;
        public int DepartmentID { get; set; }
        public string MaTheChamCong { get; set; } = null!;
    }
}
