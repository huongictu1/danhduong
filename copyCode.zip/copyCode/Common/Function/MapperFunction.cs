﻿using DocumentFormat.OpenXml.Office2016.Drawing.ChartDrawing;
using Mapster;
using Microsoft.CodeAnalysis.CSharp.Syntax;
using PDCProjectApi.Data;
using PDCProjectApi.Model.View;

namespace PDCProjectApi.Common.Function
{
    public static class MapperFunction
    {
        public static TodStructureOutputContentIj MapStructureOutput(this TodStructureOutputContentLbp item) => item.Adapt<TodStructureOutputContentIj>();
        public static List<TodStructureOutputContentIj> MapStructureOutput(this List<TodStructureOutputContentLbp> item) => item.Adapt<List<TodStructureOutputContentIj>>();
        public static List<VlinkageEucIjD800> MapEucD800(this List<VlinkageEucLbpD800> item) => item.Adapt<List<VlinkageEucIjD800>>();
        public static List<MvEucE900Ij> MapEucE900(this List<MvEucE900Lbp> item) => item.Adapt<List<MvEucE900Ij>>();
        public static List<MvInvE700Ij1> MapEucE700(this List<MvInvE700Lbp1> item) => item.Adapt<List<MvInvE700Ij1>>();

        public static TodFcdelOutputPartDemandLbp MapForecastOutput(this TodFcdelOutputPartDemandIj item) => item.Adapt<TodFcdelOutputPartDemandLbp>();
        public static List<TodFcdelOutputPartDemandLbp> MapForecastOutput(this List<TodFcdelOutputPartDemandIj> item) => item.Adapt<List<TodFcdelOutputPartDemandLbp>>();
        public static List<TodFcdelOutputPartDemandIj> MapForecastOutput(this List<TodFcdelOutputPartDemandLbp> item) => item.Adapt<List<TodFcdelOutputPartDemandIj>>();
        public static List<TodFcdelOutputShiftDeliveryVolumeLbp> MapForecastOutput(this List<TodFcdelOutputShiftDeliveryVolumeIj> item) => item.Adapt<List<TodFcdelOutputShiftDeliveryVolumeLbp>>();
        public static List<TodFcdelOutputShiftDeliveryVolumeIj> MapForecastOutput(this List<TodFcdelOutputShiftDeliveryVolumeLbp> item) => item.Adapt<List<TodFcdelOutputShiftDeliveryVolumeIj>>();
        public static TodFcdelOutputShiftDeliveryVolumeIj MapForecastOutput(this TodFcdelOutputShiftDeliveryVolumeLbp item) => item.Adapt<TodFcdelOutputShiftDeliveryVolumeIj>();
        public static List<TodFcdelOutputLotDeliveryVolumeLbp> MapForecastOutput(this List<TodFcdelOutputLotDeliveryVolumeIj> item) => item.Adapt<List<TodFcdelOutputLotDeliveryVolumeLbp>>();
        public static List<TodFcdelOutputLotDeliveryVolumeIj> MapForecastOutput(this List<TodFcdelOutputLotDeliveryVolumeLbp> item) => item.Adapt<List<TodFcdelOutputLotDeliveryVolumeIj>>();
        public static List<TodFcdelOutputStockStdLbp> MapForecastOutput(this List<TodFcdelOutputStockStdIj> item) => item.Adapt<List<TodFcdelOutputStockStdLbp>>();
        public static List<TodFcdelOutputStockStdIj> MapForecastOutput(this List<TodFcdelOutputStockStdLbp> item) => item.Adapt<List<TodFcdelOutputStockStdIj>>();
        public static List<TodFcdelOutputDemandDeliveryVolumeIj> MapForecastOutput(this List<TodFcdelOutputDemandDeliveryVolumeLbp> item) => item.Adapt<List<TodFcdelOutputDemandDeliveryVolumeIj>>();
        public static List<TodFcdelOutputDemandDeliveryVolumeLbp> MapForecastOutput(this List<TodFcdelOutputDemandDeliveryVolumeIj> item) => item.Adapt<List<TodFcdelOutputDemandDeliveryVolumeLbp>>();
        public static List<TodFcdelOutputSumupVendorLbp> MapForecastOutput(this List<TodFcdelOutputSumupVendorIj> item) => item.Adapt<List<TodFcdelOutputSumupVendorLbp>>();
        public static List<TodFcdelOutputSumupRouteLbp> MapForecastOutput(this List<TodFcdelOutputSumupRouteIj> item) => item.Adapt<List<TodFcdelOutputSumupRouteLbp>>();
        public static List<TodFcdelOutputSumupVendorIj> MapForecastOutput(this List<TodFcdelOutputSumupVendorLbp> item) => item.Adapt<List<TodFcdelOutputSumupVendorIj>>();
        public static List<TodFcdelOutputSumupRouteIj> MapForecastOutput(this List<TodFcdelOutputSumupRouteLbp> item) => item.Adapt<List<TodFcdelOutputSumupRouteIj>>();
        public static List<TodFcdelOutputSumupLocationLbp> MapForecastOutput(this List<TodFcdelOutputSumupLocationIj> item) => item.Adapt<List<TodFcdelOutputSumupLocationLbp>>();

        public static TodTodOutput1AbnormalPalletIj MapTodOutput(this TodTodOutput1AbnormalPalletLbp item) => item.Adapt<TodTodOutput1AbnormalPalletIj>();
        public static TodTodOutput1AbnormalPalletLbp MapTodOutput(this TodTodOutput1AbnormalPalletIj item) => item.Adapt<TodTodOutput1AbnormalPalletLbp>();
        public static List<TodTodOutput1AbnormalPalletIj> MapTodOutput(this List<TodTodOutput1AbnormalPalletLbp> item) => item.Adapt<List<TodTodOutput1AbnormalPalletIj>>();
        public static TodTodOutput1AbnormalPcsIj MapTodOutput(this TodTodOutput1AbnormalPcsLbp item) => item.Adapt<TodTodOutput1AbnormalPcsIj>();
        public static TodTodOutput1AbnormalPcsLbp MapTodOutput(this TodTodOutput1AbnormalPcsIj item) => item.Adapt<TodTodOutput1AbnormalPcsLbp>();
        public static List<TodTodOutput1AbnormalPcsIj> MapTodOutput(this List<TodTodOutput1AbnormalPcsLbp> item) => item.Adapt<List<TodTodOutput1AbnormalPcsIj>>();

        public static TodTodOutput1AdjustPoIj MapTodOutput(this TodTodOutput1AdjustPoLbp item) => item.Adapt<TodTodOutput1AdjustPoIj>();
        public static TodTodOutput1AdjustPoLbp MapTodOutput(this TodTodOutput1AdjustPoIj item) => item.Adapt<TodTodOutput1AdjustPoLbp>();
        public static List<TodTodOutput1AdjustPoIj> MapTodOutput(this List<TodTodOutput1AdjustPoLbp> item) => item.Adapt<List<TodTodOutput1AdjustPoIj>>();

        public static TodTodOutput1DemandIj MapTodOutput(this TodTodOutput1DemandLbp item) => item.Adapt<TodTodOutput1DemandIj>();
        public static TodTodOutput1DemandLbp MapTodOutput(this TodTodOutput1DemandIj item) => item.Adapt<TodTodOutput1DemandLbp>();
        public static List<TodTodOutput1DemandIj> MapTodOutput(this List<TodTodOutput1DemandLbp> item) => item.Adapt<List<TodTodOutput1DemandIj>>();
        public static TodTodOutput1DemandCpIj MapTodOutput(this TodTodOutput1DemandCpLbp item) => item.Adapt<TodTodOutput1DemandCpIj>();
        public static TodTodOutput1DemandCpLbp MapTodOutput(this TodTodOutput1DemandCpIj item) => item.Adapt<TodTodOutput1DemandCpLbp>();
        public static List<TodTodOutput1DemandCpIj> MapTodOutput(this List<TodTodOutput1DemandCpLbp> item) => item.Adapt<List<TodTodOutput1DemandCpIj>>();
        public static List<TodTodOutputPartDemandCpIj> MapTodOutput(this List<TodTodOutputPartDemandCpLbp> item) => item.Adapt<List<TodTodOutputPartDemandCpIj>>();
        public static List<VPartcontrolFcdoIj> MapTodOutput(this List<VPartcontrolFcdoLbp> item) => item.Adapt<List<VPartcontrolFcdoIj>>();

        public static TodTodOutput1DoIj MapTodOutput(this TodTodOutput1DoLbp item) => item.Adapt<TodTodOutput1DoIj>();
        public static TodTodOutput1DoLbp MapTodOutput(this TodTodOutput1DoIj item) => item.Adapt<TodTodOutput1DoLbp>();
        public static List<TodTodOutput1DoIj> MapTodOutput(this List<TodTodOutput1DoLbp> item) => item.Adapt<List<TodTodOutput1DoIj>>();
        public static TodTodOutput1NgIj MapTodOutput(this TodTodOutput1NgLbp item) => item.Adapt<TodTodOutput1NgIj>();
        public static TodTodOutput1NgLbp MapTodOutput(this TodTodOutput1NgIj item) => item.Adapt<TodTodOutput1NgLbp>();
        public static List<TodTodOutput1NgIj> MapTodOutput(this List<TodTodOutput1NgLbp> item) => item.Adapt<List<TodTodOutput1NgIj>>();
        public static TodTodOutput1PendingIj MapTodOutput(this TodTodOutput1PendingLbp item) => item.Adapt<TodTodOutput1PendingIj>();
        public static TodTodOutput1PendingLbp MapTodOutput(this TodTodOutput1PendingIj item) => item.Adapt<TodTodOutput1PendingLbp>();
        public static List<TodTodOutput1PendingIj> MapTodOutput(this List<TodTodOutput1PendingLbp> item) => item.Adapt<List<TodTodOutput1PendingIj>>();
        public static TodTodOutput1PoIj MapTodOutput(this TodTodOutput1PoLbp item) => item.Adapt<TodTodOutput1PoIj>();
        public static TodTodOutput1PoLbp MapTodOutput(this TodTodOutput1PoIj item) => item.Adapt<TodTodOutput1PoLbp>();
        public static List<TodTodOutput1PoIj> MapTodOutput(this List<TodTodOutput1PoLbp> item) => item.Adapt<List<TodTodOutput1PoIj>>();

        public static TodTodOutput1StockActualIj MapTodOutput(this TodTodOutput1StockActualLbp item) => item.Adapt<TodTodOutput1StockActualIj>();
        public static TodTodOutput1StockActualLbp MapTodOutput(this TodTodOutput1StockActualIj item) => item.Adapt<TodTodOutput1StockActualLbp>();
        public static List<TodTodOutput1StockActualIj> MapTodOutput(this List<TodTodOutput1StockActualLbp> item) => item.Adapt<List<TodTodOutput1StockActualIj>>();
        public static TodTodOutput1StockPlanIj MapTodOutput(this TodTodOutput1StockPlanLbp item) => item.Adapt<TodTodOutput1StockPlanIj>();
        public static TodTodOutput1StockPlanLbp MapTodOutput(this TodTodOutput1StockPlanIj item) => item.Adapt<TodTodOutput1StockPlanLbp>();
        public static List<TodTodOutput1StockPlanIj> MapTodOutput(this List<TodTodOutput1StockPlanLbp> item) => item.Adapt<List<TodTodOutput1StockPlanIj>>();
        public static TodTodOutput1StockInclIj MapTodOutput(this TodTodOutput1StockInclLbp item) => item.Adapt<TodTodOutput1StockInclIj>();
        public static TodTodOutput1StockInclLbp MapTodOutput(this TodTodOutput1StockInclIj item) => item.Adapt<TodTodOutput1StockInclLbp>();
        public static List<TodTodOutput1StockInclIj> MapTodOutput(this List<TodTodOutput1StockInclLbp> item) => item.Adapt<List<TodTodOutput1StockInclIj>>();

        public static TodTodOutput1SummaryIj MapTodOutput(this TodTodOutput1SummaryLbp item) => item.Adapt<TodTodOutput1SummaryIj>();
        public static List<TodTodOutput1SummaryIj> MapTodOutput(this List<TodTodOutput1SummaryLbp> item) => item.Adapt<List<TodTodOutput1SummaryIj>>();
        public static TodTodOutput1ToActualIj MapTodOutput(this TodTodOutput1ToActualLbp item) => item.Adapt<TodTodOutput1ToActualIj>();
        public static TodTodOutput1ToActualLbp MapTodOutput(this TodTodOutput1ToActualIj item) => item.Adapt<TodTodOutput1ToActualLbp>();
        public static List<TodTodOutput1ToActualIj> MapTodOutput(this List<TodTodOutput1ToActualLbp> item) => item.Adapt<List<TodTodOutput1ToActualIj>>();
        public static TodTodOutput1ToPlanIj MapTodOutput(this TodTodOutput1ToPlanLbp item) => item.Adapt<TodTodOutput1ToPlanIj>();
        public static TodTodOutput1ToPlanLbp MapTodOutput(this TodTodOutput1ToPlanIj item) => item.Adapt<TodTodOutput1ToPlanLbp>();
        public static List<TodTodOutput1ToPlanIj> MapTodOutput(this List<TodTodOutput1ToPlanLbp> item) => item.Adapt<List<TodTodOutput1ToPlanIj>>();
        public static TodTodOutput1TotalIj MapTodOutput(this TodTodOutput1TotalLbp item) => item.Adapt<TodTodOutput1TotalIj>();
        public static List<TodTodOutput1TotalIj> MapTodOutput(this List<TodTodOutput1TotalLbp> item) => item.Adapt<List<TodTodOutput1TotalIj>>();
        public static List<TodTodOutput1TotalIjNoneInv> MapTodOutputNone(this List<TodTodOutput1TotalIj> item) => item.Adapt<List<TodTodOutput1TotalIjNoneInv>>();
        public static List<TodTodOutput1TotalLbpNoneInv> MapTodOutputNone2(this List<TodTodOutput1TotalIj> item) => item.Adapt<List<TodTodOutput1TotalLbpNoneInv>>();
        public static List<TodTodOutput1TotalIj> MapTodOutputNone2(this List<TodTodOutput1TotalLbpNoneInv> item) => item.Adapt<List<TodTodOutput1TotalIj>>();
        public static List<TodTodOutput1TotalIj> MapTodOutputNone2(this List<TodTodOutput1TotalIjNoneInv> item) => item.Adapt<List<TodTodOutput1TotalIj>>();
        public static List<TodTodOutput1TotalIjOld> MapTodOutput(this List<TodTodOutput1TotalLbpOld> item) => item.Adapt<List<TodTodOutput1TotalIjOld>>();
        public static List<TodTodOutput1TotalLbp> MapTodOutput(this List<TodTodOutput1TotalIj> item) => item.Adapt<List<TodTodOutput1TotalLbp>>();
        public static List<TodTodOutput2DeadlineLbp> MapTodOutput(this List<TodTodOutput2DeadlineIj> item) => item.Adapt<List<TodTodOutput2DeadlineLbp>>();
        public static List<TodTodOutput4CommonLbp> MapTodOutput(this List<TodTodOutput4CommonIj> item) => item.Adapt<List<TodTodOutput4CommonLbp>>();
        public static List<TodTodOutput1SummaryIj> MapTodItemToSummary(this List<TodTodOutput1DemandIj> item) => item.Adapt<List<TodTodOutput1SummaryIj>>();
        public static List<TodTodOutput1SummaryIj> MapTodItemToSummary(this List<TodTodOutput1DemandCpIj> item) => item.Adapt<List<TodTodOutput1SummaryIj>>();
        public static List<TodTodOutput1SummaryIj> MapTodItemToSummary(this List<TodTodOutput1NgIj> item) => item.Adapt<List<TodTodOutput1SummaryIj>>();
        public static List<TodTodOutput1SummaryIj> MapTodItemToSummary(this List<TodTodOutput1PoIj> item) => item.Adapt<List<TodTodOutput1SummaryIj>>();
        public static List<TodTodOutput1SummaryIj> MapTodItemToSummary(this List<TodTodOutput1DoIj> item) => item.Adapt<List<TodTodOutput1SummaryIj>>();
        public static List<TodTodOutput1SummaryIj> MapTodItemToSummary(this List<TodTodOutput1StockPlanIj> item) => item.Adapt<List<TodTodOutput1SummaryIj>>();
        public static List<TodTodOutput1SummaryIj> MapTodItemToSummary(this List<TodTodOutput1StockActualIj> item) => item.Adapt<List<TodTodOutput1SummaryIj>>();
        public static List<TodTodOutput1SummaryIj> MapTodItemToSummary(this List<TodTodOutput1PendingIj> item) => item.Adapt<List<TodTodOutput1SummaryIj>>();
        public static List<TodTodOutput1SummaryIj> MapTodItemToSummary(this List<TodTodOutput1StockInclIj> item) => item.Adapt<List<TodTodOutput1SummaryIj>>();
        public static List<TodTodOutput1SummaryIj> MapTodItemToSummary(this List<TodTodOutput1AbnormalPcsIj> item) => item.Adapt<List<TodTodOutput1SummaryIj>>();
        public static List<TodTodOutput1SummaryIj> MapTodItemToSummary(this List<TodTodOutput1AbnormalPalletIj> item) => item.Adapt<List<TodTodOutput1SummaryIj>>();
        public static List<TodTodOutput1SummaryIj> MapTodItemToSummary(this List<TodTodOutput1ToPlanIj> item) => item.Adapt<List<TodTodOutput1SummaryIj>>();
        public static List<TodTodOutput1SummaryIj> MapTodItemToSummary(this List<TodTodOutput1ToActualIj> item) => item.Adapt<List<TodTodOutput1SummaryIj>>();
        public static List<TodTodOutput1SummaryIj> MapTodItemToSummary(this List<TodTodOutput1AdjustPoIj> item) => item.Adapt<List<TodTodOutput1SummaryIj>>();
        public static List<MvLinkageIjE700> MapTodOutput(this List<MvLinkageLbpE700> item) => item.Adapt<List<MvLinkageIjE700>>();



        public static List<HistoryTodTodOutput1SummaryIj> MapTodHistory(this List<TodTodOutput1SummaryIj> item) => item.Adapt<List<HistoryTodTodOutput1SummaryIj>>();
        public static HistoryTodTodOutput1SummaryIj MapTodHistory(this TodTodOutput1SummaryIj item) => item.Adapt<HistoryTodTodOutput1SummaryIj>();
        public static List<HistoryTodTodOutput1SummaryLbp> MapTodHistory(this List<TodTodOutput1SummaryLbp> item) => item.Adapt<List<HistoryTodTodOutput1SummaryLbp>>();
        public static HistoryTodTodOutput1SummaryLbp MapTodHistory(this TodTodOutput1SummaryLbp item) => item.Adapt<HistoryTodTodOutput1SummaryLbp>();
        public static List<TodTodOutput1SummaryLbp> MapTodOutput(this List<TodTodOutput1SummaryIj> item) => item.Adapt<List<TodTodOutput1SummaryLbp>>();

        public static List<HistoryTodTodOutput1TotalIj> MapTodHistory(this List<TodTodOutput1TotalIj> item) => item.Adapt<List<HistoryTodTodOutput1TotalIj>>();
        public static HistoryTodTodOutput1TotalIj MapTodHistory(this TodTodOutput1TotalIj item) => item.Adapt<HistoryTodTodOutput1TotalIj>();
        public static List<HistoryTodTodOutput1TotalLbp> MapTodHistory(this List<TodTodOutput1TotalLbp> item) => item.Adapt<List<HistoryTodTodOutput1TotalLbp>>();
        public static HistoryTodTodOutput1TotalLbp MapTodHistory(this TodTodOutput1TotalLbp item) => item.Adapt<HistoryTodTodOutput1TotalLbp>();

        public static List<LtOutput0PartListIj> MapLtOutput0PartList(this List<LtOutput0PartListLbp> item) => item.Adapt<List<LtOutput0PartListIj>>();



        public static List<PcPaIp11AutoEriIssueView> MapPartAdjustment(this List<PcPaIp11AutoEriIssue> item) => item.Adapt<List<PcPaIp11AutoEriIssueView>>();
        public static List<PcPaIp121ManualHandPoHandView> MapPartAdjustment(this List<PcPaIp121ManualHandPoHand> item) => item.Adapt<List<PcPaIp121ManualHandPoHandView>>();
        public static List<PcPaIp11AutoEriIssueView> MapPartAdjustment1(this List<PcPaIp121ManualHandPoHand> item) => item.Adapt<List<PcPaIp11AutoEriIssueView>>();
        public static List<PcPaIp11AutoEriIssueView> MapPartAdjustment2(this List<PcPaIp13cAutoIssueFormRevise> item) => item.Adapt<List<PcPaIp11AutoEriIssueView>>();
        public static List<PcPaIp122ManualHandPoReviseView> MapPartAdjustment3(this List<PcPaIp13bAutoIssueFormRevise> item) => item.Adapt<List<PcPaIp122ManualHandPoReviseView>>();
        public static List<PcPaIp122ManualHandPoReviseView> MapPartAdjustment4(this List<PcPaIp13dAutoIssueFormRevise> item) => item.Adapt<List<PcPaIp122ManualHandPoReviseView>>();
        public static List<PcPaIp122ManualHandPoReviseView> MapPartAdjustment(this List<PcPaIp122ManualHandPoRevise> item) => item.Adapt<List<PcPaIp122ManualHandPoReviseView>>();
        public static List<PcPaIp13aAutoPoPendingNpiView> MapPartAdjustment(this List<PcPaIp13aAutoPoPendingNpi> item) => item.Adapt<List<PcPaIp13aAutoPoPendingNpiView>>();
        public static List<PcPaIp13bAutoIssueFormReviseView> MapPartAdjustment(this List<PcPaIp13bAutoIssueFormRevise> item) => item.Adapt<List<PcPaIp13bAutoIssueFormReviseView>>();
        public static List<PcPaIp13cAutoIssueFormReviseView> MapPartAdjustment(this List<PcPaIp13cAutoIssueFormRevise> item) => item.Adapt<List<PcPaIp13cAutoIssueFormReviseView>>();
        public static List<PcPaIp13bAutoIssueFormReviseView> MapPartAdjustment(this List<PcPaIp13dAutoIssueFormRevise> item) => item.Adapt<List<PcPaIp13bAutoIssueFormReviseView>>();
        public static PcPaRequestRevisePoView MapPartAdjustment(this PcPaRequestRevisePo item) => item.Adapt<PcPaRequestRevisePoView>();
        public static List<PcPaRequestRevisePoProcessView> MapPartAdjustment(this List<PcPaRequestRevisePoProcess> item) => item.Adapt<List<PcPaRequestRevisePoProcessView>>();
        public static List<PcPaOp23ReviseView> MapPartAdjustment(this List<PcPaOp23Revise> item) => item.Adapt<List<PcPaOp23ReviseView>>();
        public static List<PcPaOp22HandView> MapPartAdjustment(this List<PcPaOp22Hand> item) => item.Adapt<List<PcPaOp22HandView>>();
        public static List<PcPaOp21HandView> MapPartAdjustment(this List<PcPaOp21Hand> item) => item.Adapt<List<PcPaOp21HandView>>();


        public static MpRecMasterPeriodView MapRecruitment(this MpRecMasterPeriod item) => item.Adapt<MpRecMasterPeriodView>();
        public static List<MpRecMasterPeriodView> MapRecruitment(this List<MpRecMasterPeriod> item) => item.Adapt<List<MpRecMasterPeriodView>>();



        public static List<VStructureIjSimulation> MapSimulation(this List<VStructureLbpSimulation> item) => item.Adapt<List<VStructureIjSimulation>>();
        public static List<MvLivePpIjBlock10PartMaster> MapSimulation(this List<MvLivePpLbpBlock10PartMaster> item) => item.Adapt<List<MvLivePpIjBlock10PartMaster>>();
        public static List<VGroupMvLivePpIjBlock10CountLine> MapSimulation(this List<VGroupMvLivePpLbpBlock10CountLine> item) => item.Adapt<List<VGroupMvLivePpIjBlock10CountLine>>();
        public static List<PcSimulationPpLineLbp> MapSimulation(this List<PcSimulationPpLineIj> item) => item.Adapt<List<PcSimulationPpLineLbp>>();
        public static List<PcSimulationCountlineLbp> MapSimulation(this List<PcSimulationCountlineIj> item) => item.Adapt<List<PcSimulationCountlineLbp>>();
        public static List<PcSimulationPartMasterLbp> MapSimulation(this List<PcSimulationPartMasterIj> item) => item.Adapt<List<PcSimulationPartMasterLbp>>();
        public static List<PcSimulationPartMasterIj> MapSimulation(this List<PcSimulationPartMasterLbp> item) => item.Adapt<List<PcSimulationPartMasterIj>>();
        public static List<PcSimulationLeadtimeLbp> MapSimulation(this List<PcSimulationLeadtimeIj> item) => item.Adapt<List<PcSimulationLeadtimeLbp>>();
        public static List<VStructureIjSimulationParallel> MapSimulation(this List<VStructureLbpSimulationParallel> item) => item.Adapt<List<VStructureIjSimulationParallel>>();
        public static List<VSimulationLeadtimeIj> MapSimulation(this List<VSimulationLeadtimeLbp> item) => item.Adapt<List<VSimulationLeadtimeIj>>();
        public static List<PcSimulationPpLineChangeppIj> MapSimulationP(this List<PcSimulationPpLineIj> item) => item.Adapt<List<PcSimulationPpLineChangeppIj>>();
        public static List<PcSimulationPpLineChangeppIj> MapSimulationP(this List<PcSimulationPpLineLbp> item) => item.Adapt<List<PcSimulationPpLineChangeppIj>>();
        public static List<PcSimulationPpLineChangeppIj> MapSimulationP(this List<PcSimulationPpLineChangeppLbp> item) => item.Adapt<List<PcSimulationPpLineChangeppIj>>();
        public static List<PcSimulationPpLineChangeppLbp> MapSimulationP(this List<PcSimulationPpLineChangeppIj> item) => item.Adapt<List<PcSimulationPpLineChangeppLbp>>();
        public static List<PcSimulationPartMasterChangeppLbp> MapSimulationP(this List<PcSimulationPartMasterChangeppIj> item) => item.Adapt<List<PcSimulationPartMasterChangeppLbp>>();
        public static List<PcSimulationPartMasterLbp> MapSimulationP(this List<PcSimulationPartMasterChangeppLbp> item) => item.Adapt<List<PcSimulationPartMasterLbp>>();
        public static List<PcSimulationPartMasterLbp> MapSimulation(this List<PcSimulationPartMasterChangeppIj> item) => item.Adapt<List<PcSimulationPartMasterLbp>>();
        public static PcSimulationPpLineChangeppLbp MapSimulationP(this VSimulationChangeppJoinLbp item) => item.Adapt<PcSimulationPpLineChangeppLbp>();
        public static PcSimulationPpLineChangeppLbp MapSimulationP(this VSimulationChangeppJoin2Lbp item) => item.Adapt<PcSimulationPpLineChangeppLbp>();
        public static List<VSimulationChangeppJoinLbp> MapSimulationP(this List<VSimulationChangeppJoinIj> item) => item.Adapt<List<VSimulationChangeppJoinLbp>>();
        public static List<VSimulationChangeppJoin2Lbp> MapSimulationP(this List<VSimulationChangeppJoin2Ij> item) => item.Adapt<List<VSimulationChangeppJoin2Lbp>>();
        public static List<VStructureLbpSimulationChangepp> MapSimulationP(this List<VStructureIjSimulationChangepp> item) => item.Adapt<List<VStructureLbpSimulationChangepp>>();
        public static List<VPartMasterChangeppLbp> MapSimulationP(this List<VPartMasterChangeppIj> item) => item.Adapt<List<VPartMasterChangeppLbp>>();
        public static List<VSimulationLeadtimeLbpS1Findmer> MapSimulationP(this List<VSimulationLeadtimeIjS1Findmer> item) => item.Adapt<List<VSimulationLeadtimeLbpS1Findmer>>();
        public static List<VSimulationLeadtimeLbpS1Findmer> MapSimulationP(this List<VSimulationLeadtimeIjS1FindmerAll> item) => item.Adapt<List<VSimulationLeadtimeLbpS1Findmer>>();
        public static List<VSimulationLeadtimeLbpS1Findmer> MapSimulationP(this List<VSimulationLeadtimeLbpS1FindmerAll> item) => item.Adapt<List<VSimulationLeadtimeLbpS1Findmer>>();
        public static List<VSimulationLeadtimeLbpS1Findmer> MapSimulationP(this List<VSimulationLeadtimeIjS1FindmerChangepp> item) => item.Adapt<List<VSimulationLeadtimeLbpS1Findmer>>();
        public static List<VSimulationLeadtimeLbpS1Findmer> MapSimulationP(this List<VSimulationLeadtimeLbpS1FindmerChangepp> item) => item.Adapt<List<VSimulationLeadtimeLbpS1Findmer>>();
        public static List<VSimulationPartDemandByCellLbp> MapSimulationP(this List<VSimulationPartDemandByCellIj> item) => item.Adapt<List<VSimulationPartDemandByCellLbp>>();
        public static List<VSimulationPartDemandByCellLbp> MapSimulationP(this List<VSimulationPartDemandByCellIj2> item) => item.Adapt<List<VSimulationPartDemandByCellLbp>>();
        public static List<VSimulationPartDemandByCellLbp> MapSimulationP(this List<VSimulationPartDemandByCellLbp2> item) => item.Adapt<List<VSimulationPartDemandByCellLbp>>();
        public static List<VSimulationCountCellByShiftLbp> MapSimulationP(this List<VSimulationCountCellByShiftIj> item) => item.Adapt<List<VSimulationCountCellByShiftLbp>>();
        public static List<VSimulationLeadtimeTableLbp> MapSimulationP(this List<VSimulationLeadtimeTableIj> item) => item.Adapt<List<VSimulationLeadtimeTableLbp>>();
        public static List<VHksAiRestTimeLbp> MapSimulationP(this List<VHksAiRestTimeIj> item) => item.Adapt<List<VHksAiRestTimeLbp>>();
        public static List<VHksAiRestTimeLbp> MapSimulationP(this List<VHksAiRestTimeIj2> item) => item.Adapt<List<VHksAiRestTimeLbp>>();
        public static List<VHksAiRestTimeLbp> MapSimulationP(this List<VHksAiRestTimeLbp2> item) => item.Adapt<List<VHksAiRestTimeLbp>>();

        public static List<PcSimulationLeadtimeIj> MapSimulationP(this List<PcSimulationLeadtimeLbp> item) => item.Adapt<List<PcSimulationLeadtimeIj>>();
        public static List<VSimulationPrecalcOp6Lbp> MapSimulationP(this List<VSimulationPrecalcOp6Ij> item) => item.Adapt<List<VSimulationPrecalcOp6Lbp>>();
        public static List<PcSimulationSmTimeOp6Ij> MapSimulationP(this List<PcSimulationSmTimeOp6Lbp> item) => item.Adapt<List<PcSimulationSmTimeOp6Ij>>();
        public static List<PcSimulationFcdoIj> MapSimulationP(this List<PcSimulationFcdoLbp> item) => item.Adapt<List<PcSimulationFcdoIj>>();
        public static List<PcSimulationFcdoLbp> MapSimulationP_Reverse(this List<PcSimulationFcdoIj> item) => item.Adapt<List<PcSimulationFcdoLbp>>();
        public static List<PcSimulationAdjustDoOp11Ij> MapSimulationP(this List<PcSimulationAdjustDoOp11Lbp> item) => item.Adapt<List<PcSimulationAdjustDoOp11Ij>>();
        public static List<PcSimulationSmTimeOp8Ij> MapSimulationP(this List<PcSimulationSmTimeOp8Lbp> item) => item.Adapt<List<PcSimulationSmTimeOp8Ij>>();
        public static List<PcSimulationNpisPdoLbp> MapSimulationP(this List<PcSimulationNpisPdoIj> item) => item.Adapt<List<PcSimulationNpisPdoLbp>>();
        public static List<PcSimulationWarningListOp9Ij> MapSimulationP(this List<PcSimulationWarningListOp9Lbp> item) => item.Adapt<List<PcSimulationWarningListOp9Ij>>();
        public static List<PcSimulationWarningOverOp10Ij> MapSimulationP(this List<PcSimulationWarningOverOp10Lbp> item) => item.Adapt<List<PcSimulationWarningOverOp10Ij>>();
        public static List<VLivePpLbpBlock10PartMasterChangepp> MapSimulationP(this List<VLivePpIjBlock10PartMasterChangepp> item) => item.Adapt<List<VLivePpLbpBlock10PartMasterChangepp>>();
        public static List<VlinkageHksLivePpIj> MapLivePP(this List<VlinkageHksLivePpLbp> item) => item.Adapt<List<VlinkageHksLivePpIj>>();
    }
    public class SummaryComparer : IEqualityComparer<TodTodOutput1SummaryIj>
    {
        public bool Equals(TodTodOutput1SummaryIj x, TodTodOutput1SummaryIj y)
        {
            return x.PartNo == y.PartNo
                && x.Bc == y.Bc
                && x.Vendor == y.Vendor
                && x.CalcOrder == y.CalcOrder;
        }

        public int GetHashCode(TodTodOutput1SummaryIj obj)
        {
            return obj.PartNo.GetHashCode()
                ^ obj.Bc.GetHashCode()
                ^ obj.Vendor.GetHashCode()
                ^ obj.CalcOrder.GetHashCode();
        }
    }
}
