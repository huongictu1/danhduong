﻿using Microsoft.AspNetCore.Mvc;
using OfficeOpenXml;
using System.Data;
using System.IO;
using System.IO.Pipes;
using System.Security.AccessControl;

namespace PDCProjectApi.Common.Function
{
    public static class ExcelFunction
    {
        public static byte[] ExportEmptyExcelFromDatatable(List<ExcelExportObject> lstObj)
        {
            ExcelPackage.LicenseContext = LicenseContext.NonCommercial;
            using (ExcelPackage excelPackage = new ExcelPackage())
            {
                foreach (var obj in lstObj)
                {
                    ExcelWorksheet excelWorksheet1;
                    excelWorksheet1 = excelPackage.Workbook.Worksheets.Add(obj.sheetName);
                    excelWorksheet1.Cells[1, 1].LoadFromDataTable(obj.dataTable, true, OfficeOpenXml.Table.TableStyles.Light2);
                }
                return excelPackage.GetAsByteArray();
            }
        }
        public static void SaveByteArrayToExcel(byte[] arr, string filePath)
        {
            using(MemoryStream ms = new MemoryStream(arr))
            {
                using (ExcelPackage excel = new ExcelPackage(ms))
                {
                    FileInfo f = new FileInfo(filePath);
                    excel.SaveAs(f);
                }
            }
        }
        public static void SetFileSecutiry(string filePath)
        {
            try
            {
                FileInfo fileInfo = new FileInfo(filePath);
                FileSecurity security = fileInfo.GetAccessControl();
                FileSystemAccessRule rule = new FileSystemAccessRule("everyone", FileSystemRights.Write, AccessControlType.Deny);
                //security.AddAccessRule(rule);
                fileInfo.SetAccessControl(security);
            }
            catch (Exception)
            {

            }
        }
    }
    public class ExcelExportObject
    {
        public DataTable? dataTable { get; set; }
        public string? sheetName { get; set; }
    }
}
