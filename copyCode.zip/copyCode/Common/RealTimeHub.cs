﻿using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.SignalR;
using PDCProjectApi.Services;
using StackExchange.Redis;
using System.Threading.Tasks;

namespace PDCProjectApi.Common
{

    public class RealTimeHub : Hub
    {
        
        private static ConnectionMultiplexer redis = RedisConnectionManager.GetRedisConnection();
        private static IDatabase redisDb = redis.GetDatabase();
        private readonly IGlobalVariable global = new GlobalVariable();
        private string Fact = "";
        public RealTimeHub()
        {
            this.Fact = global.ReturnFactory();
        }
        public async Task SendMessage(string param,string message)
        {
          
            await Clients.All.SendAsync("RecMess"+ Fact + param, message);
        }
        public async Task OnConnectedAsync(string param)
        {
            var message = redisDb.StringGet("RecMess"+ Fact + param);
            if (!string.IsNullOrEmpty(message))
            {
                await SendMessageCaller(param, message);
            }
            else
            {
                await SendMessageCaller(param, "Not yet run");
            }
        }
        public async Task SendMessageCaller(string param, string message)
        {

            await Clients.Caller.SendAsync("RecMess"+ Fact + param, message);
        }
    }
}

