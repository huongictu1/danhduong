﻿using Microsoft.EntityFrameworkCore;
using Npgsql;
using PDCProjectApi.Data;
using PDCProjectApi.Model.Response;
using PDCProjectApi.Services;
using System.Data;
using System.Reflection;
using System.Runtime.CompilerServices;

namespace PDCProjectApi.Common
{
    public class ADO
    {
        static IConfigurationRoot configuration = new ConfigurationBuilder()
                .SetBasePath(AppDomain.CurrentDomain.BaseDirectory)
                .AddJsonFile("appsettings.json")
                .Build();
        
        static string connectionString = configuration.GetConnectionString("PDCConnection").StringAbleToString();


        static NpgsqlTransaction transaction = null;
        static NpgsqlConnection conn = null;
        public static void doChange(string sql)
        {
            try
            {

                using (var conn = new NpgsqlConnection(connectionString))
                {
                    conn.Open();
                    using (var command = new NpgsqlCommand(sql, conn))
                    {
                        command.ExecuteNonQuery();
                    }
                    conn.Close();
                }
            }
            catch (Exception)
            {

            }
            finally
            {

            }

        }
        public static async Task doChangeAsync(string sql)
        {
            try
            {

                using (var conn = new NpgsqlConnection(connectionString))
                {
                    try
                    {
                        await conn.OpenAsync();

                        using (var command = new NpgsqlCommand(sql, conn))
                        {
                            try
                            {
                                await command.ExecuteNonQueryAsync();
                            }
                            catch (Exception e)
                            {
                                await command.ExecuteNonQueryAsync();
                                //new EmailService().Initial(new List<string>() { "it-app28@local.canon-vn.com.vn"}, "Exception command.ExecuteNonQueryAsync()", "Exception :"+ e.Message.ToString());
                            }
                           
                        }
                    }
                    catch (Exception ex)
                    {
                        // Xử lý exception ở đây
                        new EmailService().Initial(new List<string>() { "it-app28@local.canon-vn.com.vn" }, "Exception command.ExecuteNonQueryAsync()", "Exception :" + ex.Message.ToString());

                    }
                    finally
                    {
                        if (conn.State == ConnectionState.Open)
                        {
                            conn.Close();
                        }
                    }
                }
            }
            catch (Exception)
            {

            }
            finally
            {

            }

        }
        public static Task doChangeAsync2(string sql)
        {
            try
            {

                _ = Task.Run(async () =>
                {
                    using (var conn = new NpgsqlConnection(connectionString))
                    {
                        await conn.OpenAsync();

                        using (var command = new NpgsqlCommand(sql, conn))
                        {
                            await command.ExecuteNonQueryAsync();
                        }

                        conn.Close();
                    }
                });
            }
            catch (Exception)
            {

            }
            finally
            {

            }

            return Task.CompletedTask;
        }

        public static void doChange1(List<string> sql)
        {
            try
            {

                using (conn = new NpgsqlConnection(connectionString))
                {
                    conn.Open();
                    transaction = conn.BeginTransaction();
                    foreach (var item in sql)
                    {

                        using (var command = new NpgsqlCommand(item, conn))
                        {
                            command.ExecuteNonQuery();

                        }
                    }
                    transaction.Commit();
                    conn.Close();
                }
            }

            catch (Exception e)
            {
                transaction.Rollback();
                throw;
            }
            finally
            {
                conn.Close();
            }

        }
        public static void doChange2(List<string> sql)
        {
            try
            {

                using (conn = new NpgsqlConnection(connectionString))
                {
                    conn.Open();
                    foreach (var item in sql)
                    {

                        using (var command = new NpgsqlCommand(item, conn))
                        {
                            command.ExecuteNonQuery();

                        }
                    }
                    conn.Close();
                }
            }

            catch (Exception e)
            {
                
            }
            finally
            {
                conn.Close();
            }

        }
        public static DataTable getDataTable(string sql)
        {
            try
            {
                DataTable dt = new DataTable();
                using (conn = new NpgsqlConnection(connectionString))
                {
                    conn.Open();

                    using (var command = new NpgsqlCommand(sql, conn))
                    {
                        NpgsqlDataReader dtr = command.ExecuteReader();
                        dt.Load(dtr);
                    }
                    conn.Close();
                }
                return dt;
            }
            catch (Exception ex)
            {
                return null;
            }
            finally
            {

            }
        }
        public static int CheckSSO(string uname, string sysid)
        {
            try
            {
                string cmd = @"SELECT count(*)
    FROM public.v_ssopdc
    where username = '" + uname + "' and sysid = '" + sysid + "'";
                int kqua = 0;
                using (conn = new NpgsqlConnection(connectionString))
                {
                    conn.Open();

                    using (var command = new NpgsqlCommand(cmd, conn))
                    {
                        var result = command.ExecuteScalar();
                        kqua = result == null ? 0 : Convert.ToInt32(result.ToString());
                    }
                    conn.Close();
                }
                return kqua;
            }
            catch (Exception ex)
            {
                return 0;
            }
            finally
            {

            }
        }
        public static int GetInt(string sql)
        {
            try
            {
                int kqua = 0;
                using (conn = new NpgsqlConnection(connectionString))
                {
                    conn.Open();

                    using (var command = new NpgsqlCommand(sql, conn))
                    {
                        var result = command.ExecuteScalar();
                        kqua = result == null ? 0 : Convert.ToInt32(result.ToString());
                    }
                    conn.Close();
                }
                return kqua;
            }
            catch
            {
                return 0;
            }
            finally
            {

            }
        }
        public static string GetLogLastHour()
        {
            try
            {
                String result = "";
                string sql = "SELECT substring FROM public.v_pg_read_log_last_hour;";
                using (conn = new NpgsqlConnection(connectionString))
                {
                    conn.Open();

                    using (var command = new NpgsqlCommand(sql, conn))
                    {
                        var res = command.ExecuteScalar();
                        result = res.ObjToStringAble();
                    }
                    conn.Close();
                }
                return result;
            }
            catch
            {
                return "";
            }
            finally
            {

            }
        }
        public static async Task<string> GetString(string sql)
        {
            try
            {
                string kqua = "";
                using (conn = new NpgsqlConnection(connectionString))
                {
                    conn.Open();

                    using (var command = new NpgsqlCommand(sql, conn))
                    {
                        var result = await command.ExecuteScalarAsync();
                        kqua = result == null ? "" : result.ObjToStringAble();
                    }
                    conn.Close();
                }
                return kqua;
            }
            catch
            {
                return "";
            }
            finally
            {

            }
        }
        public static DataTable getDataTable2(string sql)
        {
            using (NpgsqlConnection conn = new NpgsqlConnection(connectionString))
            {
                NpgsqlCommand command = new NpgsqlCommand(sql, conn);
                conn.Open();
                using (var result = command.ExecuteReader())
                {
                    var dt = new DataTable();
                    dt.Load(result);
                    return dt;
                }
            }
        }
        public static async Task<DataTable> getDataTableAsync(string sql)
        {
            using (NpgsqlConnection conn = new NpgsqlConnection(connectionString))
            {
                NpgsqlCommand command = new NpgsqlCommand(sql, conn);
                conn.Open();
                using (var result = command.ExecuteReaderAsync())
                {
                    var dt = new DataTable();
                    dt.Load(await result);
                    return dt;
                }
            }
        }
        public static async Task RefreshMaterializeView(string viewName)
        {
            try
            {
                await doChangeAsync("REFRESH MATERIALIZED VIEW public." + viewName + ";");

            }
            catch (Exception e)
            {
                new EmailService().Initial(new List<string>() { "it-app28@local.canon-vn.com.vn" }, "Exception refresh mv "+viewName, "Exception :" + e.Message.ToString());
            }
        }
        //thử sử dụng vì so sánh nó bảo cái này hơn về hiệu suất
        public static async Task RefreshMaterializeViewWithContext(string viewName)
        {
            try
            {
                //await doChangeAsync("REFRESH MATERIALIZED VIEW public." + viewName + ";");
                using (var ctx = new PdcsystemContext())
                {
                    try
                    {
                        FormattableString query = FormattableStringFactory.Create($"REFRESH MATERIALIZED VIEW public.{viewName};", viewName);
                        await ctx.Database.ExecuteSqlInterpolatedAsync(query);
                    }
                    catch
                    {
                        FormattableString query = FormattableStringFactory.Create($"REFRESH MATERIALIZED VIEW public.{viewName};", viewName);
                        await ctx.Database.ExecuteSqlInterpolatedAsync(query);
                    }
                }
            }
            catch (Exception e)
            {
                new EmailService().Initial(new List<string>() { "it-app28@local.canon-vn.com.vn" }, "Exception refresh mv " + viewName, "Exception :" + e.Message.ToString());
            }
        }

        public static List<MvRefreshCheckModel1> CheckBeforeCalculatePartControl()
        {
            try
            {
                var dt = getDataTable(@"select * from v_check_mv_part_control vcmpc");
                var lst = ConvertDatatableToList<MvRefreshCheckModel1>(dt);
                return lst;
            }
            catch (Exception)
            {
                return new List<MvRefreshCheckModel1>();
            }
        }
        public static List<string> CheckAllMaterializedViewReady()
        {
            try
            {
                var dt = getDataTable(@"select 'refresh materialized view ' || schemaname || '.' || matviewname || ';' as matviewname from pg_catalog.pg_matviews");
                var lst = ConvertDatatableToList<string>(dt);
                return lst;
            }
            catch (Exception)
            {
                return new List<string>();
            }
        }
        public static List<MvRefreshCheckModel1> CheckBeforeCalculateStructure(string product)
        {
            try
            {
                var dt = getDataTable($"select * from public.v_check_mv_structure where product = '{product.ToUpper()}';");
                var lst = ConvertDatatableToList<MvRefreshCheckModel1>(dt);
                return lst;
            }
            catch (Exception)
            {
                return new List<MvRefreshCheckModel1>();
            }
        }
        public static async Task<List<MvRefreshCheckModel1>> CheckBeforeCalculateStructure2(string product)
        {
            try
            {
                var dt = await getDataTableAsync($"select * from public.v_check_mv_structure where product = '{product.ToUpper()}';");
                var lst = ConvertDatatableToList<MvRefreshCheckModel1>(dt);
                return lst;
            }
            catch (Exception)
            {
                return new List<MvRefreshCheckModel1>();
            }
        }
        public static List<VMonitoringLockSession> CheckLockSessions()
        {
            try
            {
                var dt = getDataTable(@"SELECT * FROM public.v_monitoring_lock_session");
                var lst = ConvertDatatableToList<VMonitoringLockSession>(dt);
                return lst;
            }
            catch (Exception)
            {
                return new List<VMonitoringLockSession>();
            }
        }
        public static List<VMonitoringLockInfo> CheckLockInfo()
        {
            try
            {
                var dt = getDataTable(@"SELECT * FROM public.v_monitoring_lock_info;");
                var lst = ConvertDatatableToList<VMonitoringLockInfo>(dt);
                return lst;
            }
            catch (Exception)
            {
                return new List<VMonitoringLockInfo>();
            }
        }
        public static List<MvRefreshCheckModel2> CheckBeforeCalculatePartControlForInventory()
        {
            try
            {
                var strDt = DateTime.Today.ToString("yyyy-MM-dd");
                var dt = getDataTable(@"SELECT distinct date_entry, 'LBP' as product 
FROM public.mv_linkage_hks_stock_invent_lbp
where date_entry not like '" + strDt + @"%'
union all 
SELECT distinct date_entry, 'IJ' as product 
FROM public.mv_linkage_hks_stock_invent_ij
where date_entry not like '" + strDt + "%'");
                var lst = ConvertDatatableToList<MvRefreshCheckModel2>(dt);
                return lst;
            }
            catch (Exception)
            {
                return new List<MvRefreshCheckModel2>();
            }
        }
        public static async Task<DateOnly> GetDateWorkingAfterNumberOfDay(string product, int days)
        {
            var kqua = DateOnly.FromDateTime(DateTime.Today.AddDays(days));
            try
            {
                string sql = $@"SELECT date_of_date
 FROM public.adm_master_calendar
 where {product.ToLower()}_off ='false' and date_of_date >= current_date 
 order by date_of_date 
 offset {days}
 limit 1";

                using (conn = new NpgsqlConnection(connectionString))
                {
                    conn.Open();

                    using (var command = new NpgsqlCommand(sql, conn))
                    {
                        var result = await command.ExecuteScalarAsync();
                        kqua = result.ObjToDateonly();
                    }
                    conn.Close();
                }
            }
            catch (Exception)
            {
                 
            }
            return kqua;
        }
        public static int CheckValidBeforeRunPartContrl(string product)
        {
            return GetInt("select sum(d) from(SELECT d FROM public.v_valid_mv_"+product.ToLower()+"_part_control) as tbl;");
        }
        public static int GetRecurringJobId(string methodName)
        {
            try
            {
                return GetInt("select id from hangfire.job WHERE InvocationData::json->>'Method' = '" + methodName + "' order by id desc limit 1");
            }
            catch (Exception)
            {
                return 0;
            }
        }
        public static void VacuumTableLinkage()
        {
            var newLst = new List<string>();
            newLst.Add("VACUUM (FULL, FREEZE, VERBOSE, ANALYZE, SKIP_LOCKED, INDEX_CLEANUP, TRUNCATE) public.linkage_euc_ij_h1202;");
            newLst.Add("VACUUM (FULL, FREEZE, VERBOSE, ANALYZE, SKIP_LOCKED, INDEX_CLEANUP, TRUNCATE) public.linkage_euc_ij_h300;");
            newLst.Add("VACUUM (FULL, FREEZE, VERBOSE, ANALYZE, SKIP_LOCKED, INDEX_CLEANUP, TRUNCATE) public.linkage_euc_ij_h300_1;");
            newLst.Add("VACUUM (FULL, FREEZE, VERBOSE, ANALYZE, SKIP_LOCKED, INDEX_CLEANUP, TRUNCATE) public.linkage_euc_ij_h445;");
            newLst.Add("VACUUM (FULL, FREEZE, VERBOSE, ANALYZE, SKIP_LOCKED, INDEX_CLEANUP, TRUNCATE) public.linkage_euc_ij_h501;");
            newLst.Add("VACUUM (FULL, FREEZE, VERBOSE, ANALYZE, SKIP_LOCKED, INDEX_CLEANUP, TRUNCATE) public.linkage_euc_ij_j100_1;");
            newLst.Add("VACUUM (FULL, FREEZE, VERBOSE, ANALYZE, SKIP_LOCKED, INDEX_CLEANUP, TRUNCATE) public.linkage_euc_lbp_h1701;");
            newLst.Add("VACUUM (FULL, FREEZE, VERBOSE, ANALYZE, SKIP_LOCKED, INDEX_CLEANUP, TRUNCATE) public.linkage_euc_lbp_h300;");
            newLst.Add("VACUUM (FULL, FREEZE, VERBOSE, ANALYZE, SKIP_LOCKED, INDEX_CLEANUP, TRUNCATE) public.linkage_euc_lbp_h501;");
            newLst.Add("VACUUM (FULL, FREEZE, VERBOSE, ANALYZE, SKIP_LOCKED, INDEX_CLEANUP, TRUNCATE) public.linkage_euc_lbp_j100_1;");
            newLst.Add("VACUUM (FULL, FREEZE, VERBOSE, ANALYZE, SKIP_LOCKED, INDEX_CLEANUP, TRUNCATE) public.linkage_euc_lbp_j101;");
            newLst.Add("VACUUM (FULL, FREEZE, VERBOSE, ANALYZE, SKIP_LOCKED, INDEX_CLEANUP, TRUNCATE) public.tod_structure_output_content_ij;");
            newLst.Add("VACUUM (FULL, FREEZE, VERBOSE, ANALYZE, SKIP_LOCKED, INDEX_CLEANUP, TRUNCATE) public.tod_structure_output_content_lbp;");
            doChange2(newLst);
        }
        public static List<T> ConvertDatatableToList<T>(DataTable dt)
        {
            List<T> data = new List<T>();
            foreach (DataRow row in dt.Rows)
            {
                T item = GetItem<T>(row);
                data.Add(item);
            }
            return data;
        }
        private static T GetItem<T>(DataRow dr)
        {
            Type temp = typeof(T);
            T obj = Activator.CreateInstance<T>();
            foreach (DataColumn column in dr.Table.Columns)
            {
                foreach (PropertyInfo pro in temp.GetProperties())
                {
                    if (pro.Name == column.ColumnName)
                    {
                        pro.SetValue(obj, dr[column.ColumnName], null);
                    }
                    else
                    {
                        continue;
                    }
                }
            }
            return obj;
        }

    }
}
