﻿using System.Drawing;

namespace PDCProjectApi.Common.Interface
{
    public interface IFileStorageService
    {
        Task DeleteFile(string fileRoute, string containerName);
        Task<string> SaveFile(string containerName, IFormFile file);
        Task<string> SaveFile1(string containerName, IFormFile file);
        Task<string> SaveFileManual(string containerName, IFormFile file);
        Task<string> SaveFileRequestNo(string containerName, IFormFile file, string requestNo);
        Task<string> SaveImage(string containerName, Image img);
        Task<string> EditFile(string containerName, IFormFile file, string fileRoute);
    }
}
