﻿using DocumentFormat.OpenXml.Drawing;
using DocumentFormat.OpenXml.Spreadsheet;
using Hangfire.Common;
using Hangfire.Dashboard;
using Hangfire.PostgreSql;
using Hangfire.States;
using Microsoft.AspNetCore.Mvc.Filters;
using Microsoft.Extensions.FileProviders;
using PDCProjectApi.Common.Job;
using PDCProjectApi.Services;
using System.Net;

namespace PDCProjectApi.Common
{

    public class MyExceptionFilter : ExceptionFilterAttribute
    {
        private readonly IEmailService _email;
        private readonly ILogger _log;
        public MyExceptionFilter(ILogger<MyExceptionFilter> logger, IEmailService email)
        {
            this._email = email;
            this._log = logger;
        }

        public override void OnException(ExceptionContext context)
        {
            // Lấy thông tin route template của endpoint hiện tại
            var endpoint = context.HttpContext.GetEndpoint();
            var endpointName = endpoint?.DisplayName;
            var endpointRoutePattern = (endpoint as RouteEndpoint)?.RoutePattern.RawText;
            //var pcName = Dns.GetHostEntryAsync(context.HttpContext.Connection.RemoteIpAddress);
            //var queryString = context.HttpContext.Request.QueryString;

            Task.Run(() => LoggingDataLake.SendError(context));

            // Gửi email báo lỗi tới developer
            // Code gửi email ở đây
            _log.LogError("Exception: \nMessage:{0} \nEndpoint:{1} \nRoute Pattern:{2}", new object[] { context.Exception.Message, endpointName ?? "blank endpoint name", endpointRoutePattern ?? "blank endpoint route pattern" });
            _email.InitialDev("Exception throw", @$"<p style='font-weight: bold;'>Dear [Mrs/Mr]. Developer,</p>
                <p>You have received a notification about <span style='font-weight: bold; color: red; font-style: italic;'>Exception </span>from PSI System. Please check on system: </p>
                <p style='font-weight: bold;'>1. Message: " + context.Exception.Message + @" </p>
                <p style='font-weight: bold;'>2. Source:" + context.Exception.Source + @"</p>
                <p style='font-weight: bold;'>3. Endpoint:" + endpointName + @"</p>
                <p style='font-weight: bold;'>4. StackTrace:" + (context.Exception.StackTrace ?? "Undefined") + @"</p>
                <p style='font-weight: bold;'>5. EndpointRoutePattern:" + endpointRoutePattern + @"<br />" + context.Exception.ReturnDetailException());
            base.OnException(context);
        }
    }
    public class RequestLoggingMiddleware
    {
        private readonly RequestDelegate _next;
        public RequestLoggingMiddleware(RequestDelegate next)
        {
            _next = next;
        }

        public async Task Invoke(HttpContext context)
        {
            if (context.Request.Method == "OPTIONS" || (context.Request.Path.Value != null && !context.Request.Path.Value.Contains("api")))
            {

                await _next(context);
            }
            else
            {

                var startTime = DateTime.Now;
                await _next(context);
                var elapsed = DateTime.Now.Subtract(startTime).TotalMilliseconds.ToString();
                await LoggingDataLake.SendLog(context, elapsed);


            }

        }
    }
    public static class RequestLoggingMiddlewareExtensions
    {
        public static IApplicationBuilder UseRequestLogging(this IApplicationBuilder builder)
        {
            return builder.UseMiddleware<RequestLoggingMiddleware>();
        }
    }
    public static class CustomDirectoryBrowserMiddlewareExtensions
    {
        public static IApplicationBuilder UseDirectoryBrowser(this IApplicationBuilder builder, List<IFileProvider> fileProvider, List<string> requestPath)
        {
            return builder.UseMiddleware<CustomDirectoryBrowserMiddleware>(fileProvider, requestPath);
        }
    }
    public class CustomDirectoryBrowserMiddleware
    {
        private readonly RequestDelegate _next;
        private readonly List<IFileProvider> _fileProvider;
        private readonly List<string> _requestPath;

        public CustomDirectoryBrowserMiddleware(RequestDelegate next, List<IFileProvider> fileProvider, List<string> requestPath)
        {
            _next = next;
            _fileProvider = fileProvider;
            _requestPath = requestPath;
        }

        public async Task InvokeAsync(HttpContext context)
        {
            try
            {
                for (int i = 0; i < _fileProvider.Count; i++)
                {
                    try
                    {
                        var path = _requestPath[i];
                        var file = _fileProvider[i];
                        if (context.Request.Path.StartsWithSegments(path, out var remainingPath))
                        {
                            var contents = file.GetDirectoryContents(remainingPath);
                            if (contents.Exists)
                            {
                                var sortedContents = contents.OrderByDescending(f => f.LastModified).ToList(); // Sắp xếp theo tên
                                var bread = CreateBreadcrumb(context.Request.Path.Value, out string lastPath);
                                context.Response.ContentType = "text/html";
                                await context.Response.WriteAsync(@"
<!DOCTYPE html>
<html lang='en'>
<head>
    <meta charset='UTF-8'>
    <meta name='viewport' content='width=device-width, initial-scale=1.0'>
    <title>Directory Browser</title>
    <style>
        body {
            font-family: Arial, sans-serif;
        }
        header {
            margin-bottom: 20px;
        }
        #breadcrumb {
            margin-bottom: 20px;
        }
        #index {
            width: 100%;
            border-collapse: collapse;
        }
        #index th, #index td {
            padding: 8px 12px;
            border: 1px solid #ddd;
        }
        #index th {
            background-color: #f4f4f4;
        }
        .name a {
            color: #007bff;
            text-decoration: none;
        }
        .name a:hover {
            text-decoration: underline;
        }
        .length { text-align: right; }
        .modified { text-align: center; }
    </style>
</head>
<body>
    <header>
        <h1>Index of <span id='current-path'>" + remainingPath + @"</span></h1>
    </header>
    <nav id='breadcrumb'>" + bread + @"</nav>
    <section id='main'>
        <table id='index' summary='The list of files in the given directory. Column headers are listed in the first row.'>
            <thead>
                <tr>
                    <th abbr='Name'>Name</th>
                    <th abbr='Size'>Size</th>
                    <th abbr='Modified'>Last Modified</th>
                </tr>
            </thead>
            <tbody id='file-list'>
                " + CreateFileList(sortedContents, lastPath) + @"
            </tbody>
        </table>
    </section>
</body>
</html>
");
                                return;
                            }
                        }
                    }
                    catch (Exception)
                    {
                        continue;
                    }
                    

                }
            }
            catch (Exception)
            {

            }
            await _next(context);
        }
        private string CreateBreadcrumb(string path, out string lastPath)
        {
            var parts = path.Split('/').Where(part => !string.IsNullOrEmpty(part)).ToArray();
            string temp = "";
            var breadcrumb = string.Join(" / ", parts.Select((part, index) =>
            {
                var href = "/" + string.Join("/", parts.Take(index + 1));
                temp = $"{href}";
                return $"<a href='{href}'>{part}</a>";
            }));
            lastPath = temp;
            return breadcrumb;
        }

        private string CreateFileList(IEnumerable<IFileInfo> contents, string remainingPath)
        {
            Console.WriteLine(remainingPath);
            var rows = contents.Select(file => $@"
<tr class='file'>
    <td class='name'><a href='{(file.IsDirectory ? file.Name : remainingPath + "/" + file.Name)}'>{file.Name}</a></td>
    <td class='length'>{(file.IsDirectory ? "-" : file.Length.ToString("N0"))}</td>
    <td class='modified'>{file.LastModified.AddHours(7).ToString("yyyy-MM-dd HH:mm:ss")}</td>
</tr>").ToArray();
            return string.Join(Environment.NewLine, rows);
        }
    }

    public class MyAuthorizationFilter : IDashboardAuthorizationFilter
    {
        public bool Authorize(DashboardContext context)
        {
            return true;
        }
    }

    public class DelayedRetryAttribute : JobFilterAttribute, IElectStateFilter
    {
        public void OnStateElection(ElectStateContext context)
        {
            // Kiểm tra nếu job bị failed
            if (context.CandidateState is FailedState)
            {
                // Thêm một delay 2 phút trước khi requeue lại job
                context.SetJobParameter("Delay", TimeSpan.FromMinutes(2));

                // Đặt trạng thái của job thành EnqueuedState để requeue lại job
                context.CandidateState = new EnqueuedState();
                new EmailService().InitialDev(" Success Re-running job failed", "Re-Enqueue job");
            }
        }
    }
}
