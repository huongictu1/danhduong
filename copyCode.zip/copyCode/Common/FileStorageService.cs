﻿using PDCProjectApi.Common.Interface;
using System.Drawing;
using PDCProjectApi.Common;
using System.Drawing.Imaging;

namespace PDCProjectApi.Common
{
    public class FileStorageService : IFileStorageService
    {
        private readonly IWebHostEnvironment env;
        private readonly IHttpContextAccessor httpContextAccessor;

        public FileStorageService(IWebHostEnvironment env, IHttpContextAccessor httpContextAccessor)
        {
            this.env = env;
            this.httpContextAccessor = httpContextAccessor;
        }
        public Task DeleteFile(string fileRoute, string containerName)
        {
            if (string.IsNullOrEmpty(fileRoute))
            {
                return Task.CompletedTask;
            }

            var fileName = Path.GetFileName(fileRoute);
            var fileDirectory = Path.Combine(env.WebRootPath, containerName, fileName);

            if (File.Exists(fileDirectory))
            {
                File.Delete(fileDirectory);
            }

            return Task.CompletedTask;
        }

        public async Task<string> EditFile(string containerName, IFormFile file, string fileRoute)
        {
            await DeleteFile(fileRoute, containerName);
            return await SaveFile(containerName, file);
        }

        public async Task<string> SaveFile(string containerName, IFormFile file)
        {
            var extension = Path.GetExtension(file.FileName);
            var fileName = $"{Guid.NewGuid() + "_" + Path.GetFileName(file.FileName).Split('.')[0].ReplaceSpecialChar()}{extension}";
            string folder = Path.Combine(env.WebRootPath, containerName);

            if (!Directory.Exists(folder))
            {
                Directory.CreateDirectory(folder);
            }

            string route = Path.Combine(folder, fileName);
            using (var ms = new MemoryStream())
            {
                await file.CopyToAsync(ms);
                var content = ms.ToArray();
                await File.WriteAllBytesAsync(route, content);
            }

#pragma warning disable CS8602 // Dereference of a possibly null reference.
            var url = $"{httpContextAccessor.HttpContext.Request.Scheme}://{httpContextAccessor.HttpContext.Request.Host}";
#pragma warning restore CS8602 // Dereference of a possibly null reference.
            var routeForDB = Path.Combine(url, containerName, fileName).Replace("\\", "/");
            return routeForDB + ";";
        }
        public async Task<string> SaveFile1(string containerName, IFormFile file)
        {
            var extension = Path.GetExtension(file.FileName);
            var fileName = $"{Guid.NewGuid() + "#" + Path.GetFileName(file.FileName).Split('.')[0].ReplaceSpecialChar()}{extension}";
            string folder = Path.Combine(env.WebRootPath, containerName);

            if (!Directory.Exists(folder))
            {
                Directory.CreateDirectory(folder);
            }

            string route = Path.Combine(folder, fileName);
            using (var ms = new MemoryStream())
            {
                await file.CopyToAsync(ms);
                var content = ms.ToArray();
                await File.WriteAllBytesAsync(route, content);
            }

#pragma warning disable CS8602 // Dereference of a possibly null reference.
            var url = $"{httpContextAccessor.HttpContext.Request.Scheme}://{httpContextAccessor.HttpContext.Request.Host}";
#pragma warning restore CS8602 // Dereference of a possibly null reference.
            var routeForDB = Path.Combine(url, containerName, fileName).Replace("\\", "/");
            return routeForDB + ";";
        }
        public async Task<string> SaveFileRequestNo(string containerName, IFormFile file, string requestNo)
        {
            var extension = Path.GetExtension(file.FileName);
            var fileName = $"{requestNo + "_" + Path.GetFileName(file.FileName).Split('.')[0].ReplaceSpecialChar()}{extension}";
            string folder = Path.Combine(env.WebRootPath, containerName);

            if (!Directory.Exists(folder))
            {
                Directory.CreateDirectory(folder);
            }

            string route = Path.Combine(folder, fileName);
            using (var ms = new MemoryStream())
            {
                await file.CopyToAsync(ms);
                var content = ms.ToArray();
                await File.WriteAllBytesAsync(route, content);
            }

#pragma warning disable CS8602 // Dereference of a possibly null reference.
            var url = $"{httpContextAccessor.HttpContext.Request.Scheme}://{httpContextAccessor.HttpContext.Request.Host}";
#pragma warning restore CS8602 // Dereference of a possibly null reference.
            var routeForDB = Path.Combine(url, containerName, fileName).Replace("\\", "/");
            return routeForDB + ";";
        }

        public async Task<string> SaveImage(string containerName, Image img)
        {
            var extension = Path.GetExtension("image.jpg");
            var fileName = Guid.NewGuid() + "." + extension;
            string folder = Path.Combine(env.WebRootPath, containerName);

            if (!Directory.Exists(folder))
            {
                Directory.CreateDirectory(folder);
            }

            string route = Path.Combine(folder, fileName);

            using (var ms = new MemoryStream())
            {
                img.Save(ms, img.RawFormat);
                var content = ms.ToArray();
                await File.WriteAllBytesAsync(route, content);
            }

#pragma warning disable CS8602 // Dereference of a possibly null reference.
            var url = $"{httpContextAccessor.HttpContext.Request.Scheme}://{httpContextAccessor.HttpContext.Request.Host}";
#pragma warning restore CS8602 // Dereference of a possibly null reference.
            var routeForDB = Path.Combine(url, containerName, fileName).Replace("\\", "/");
            return routeForDB + ";";
        }

        public async Task<string> SaveFileManual(string containerName, IFormFile file)
        {
            var extension = Path.GetExtension(file.FileName);
            var fileName = $"{Path.GetFileName(file.FileName).Split('.')[0].ReplaceSpecialChar()}{extension}";
            string folder = Path.Combine(env.WebRootPath, containerName);

            if (!Directory.Exists(folder))
            {
                Directory.CreateDirectory(folder);
            }

            string route = Path.Combine(folder, fileName);
            using (var ms = new MemoryStream())
            {
                await file.CopyToAsync(ms);
                var content = ms.ToArray();
                await File.WriteAllBytesAsync(route, content);
            }

#pragma warning disable CS8602 // Dereference of a possibly null reference.
            var url = $"{httpContextAccessor.HttpContext.Request.Scheme}://{httpContextAccessor.HttpContext.Request.Host}";
#pragma warning restore CS8602 // Dereference of a possibly null reference.
            var routeForDB = Path.Combine(fileName).Replace("\\", "/");
            return routeForDB;
        }

    }
}
