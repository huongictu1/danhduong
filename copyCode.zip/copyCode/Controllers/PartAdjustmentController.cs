﻿using DocumentFormat.OpenXml.InkML;
using DocumentFormat.OpenXml.Spreadsheet;
using Hangfire;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using OfficeOpenXml;
using PDCProjectApi.Common;
using PDCProjectApi.Common.Function;
using PDCProjectApi.Common.Job;
using PDCProjectApi.Data;
using PDCProjectApi.Helper;
using PDCProjectApi.Model.Request;
using PDCProjectApi.Model.Response;
using PDCProjectApi.Model.View;
using PDCProjectApi.Services;
using System;
using System.Net;
using System.Security.Claims;

namespace PDCProjectApi.Controllers
{
    [Route("api/partAdjustment")]
    [ApiController]
    public class PartAdjustmentController : ControllerBase, IDisposable
    {
        private readonly IEmailService _email;
        private readonly PdcsystemContext _ctx;
        private readonly IPartAdjustmentJob _pa;
        public PartAdjustmentController( IEmailService email, PdcsystemContext ctx, IPartAdjustmentJob pa)
        {
            _email = email;
            _ctx = ctx;
            _pa = pa;
        }

        private bool disposed = false;
        protected virtual void Dispose(bool disposing)
        {
            if (!disposed)
            {
                if (disposing)
                {
                    if (_ctx != null)
                    {
                        _ctx.DisposeAsync();
                    }
                    if (_pa != null)
                    {
                        _pa.DisposeAsync();
                    }
                }
                disposed = true;
            }
        }
        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }
        ~PartAdjustmentController() { Dispose(false); }

        [HttpPost("add-master-individual")]
        public CommonResponse AddMasterIndividual([FromBody] PcPaMasterIndividualRequest rq)

        {
            CommonResponse res = new CommonResponse()
            {
                Error = false,
                Message = "",
                Status = (int)HttpStatusCode.BadRequest
            };
            try
            {
                
                var u = GetCurrentUser();
                var model = new PcPaMasterIndividual()
                {
                    Active = true,
                    CreatedBy = u.UserName,
                    Dept = rq.Dept,
                    Description = rq.Description,
                    Factory = rq.Factory,
                    Individual = rq.Individual,
                    Model = rq.Model,
                    Note = rq.Note,
                    Phase = rq.Phase,
                    Product = rq.Product,
                    Remark = rq.Remark
                };
                _ctx.Add(model);
                _ctx.SaveChanges();
                res.Error = false;
                res.Status = 200;
                res.Message = "Add successful !";
            }
            catch (Exception e)
            {
                res.Error = true;
                res.Message = e.Message;
                res.Status = (int)HttpStatusCode.BadRequest;
            }
            return res;
        }
        [HttpPost("fillter-partadjust-master-individual")]
        public PcPaMasterIndividualModel FillterMasterIndividual(PcPaMasterIndividualParam param)
        {
            try
            {
                var result = new PcPaMasterIndividualModel();
                var lstResult = new List<PcPaMasterIndividualView>();
                var u = GetCurrentUser();

                var model = _ctx.PcPaMasterIndividuals.Where(x => x.Active == true 
                && (x.Phase.ToUpper().Contains(param.Phase.ToUpper())
                && x.Description.ToUpper().Contains(param.Description.ToUpper()) 
                && x.Dept.ToUpper().Contains(param.Dept.ToUpper())));

                var model2 = model.OrderByDescending(x => x.CreatedDate).Paginate(param).ToList();
                int i = 0;
                
                var c = model.Count();
                result.lstModel = model2;
                result.toRecord = (int)Math.Min(result.totalRecords, result.currentPage * result.recordPerPage);
                result.totalPage = (int)Math.Ceiling((decimal)c / param.RecordsPerPage);
                result.totalRecords = c;
                result.recordPerPage = param.RecordsPerPage;
                result.currentPage = param.Page;
                result.fromRecord = c == 0 ? 0 : (result.currentPage - 1) * result.recordPerPage + 1;
                return result;
            }
            catch (Exception)
            {
                return new PcPaMasterIndividualModel();
            }
        }
        [HttpGet("approve-master-individual")]
        public async Task<CommonResponse> ApproveMasterIndividual()
        {
            CommonResponse res = new CommonResponse()
            {
                Error = false,
                Message = "",
                Status = (int)HttpStatusCode.BadRequest
            };
            try
            {
               
                var u = GetCurrentUser();
                //tìm những con cũ dựa vào key những con mới
                var lstOld = await _ctx.PcPaMasterIndividuals
                    .Where(x => x.Active == true && x.ApprovalDate != null)
                    .ToListAsync();
                var lstNew = await _ctx.PcPaMasterIndividuals
                    .Where(x => x.Active == true && x.ApprovalDate == null)
                    .ToListAsync();
                if (lstNew != null && lstNew.Count > 0)
                {
                    lstOld.ForEach(x =>
                    {
                        x.Active = false;
                    });
                    _ctx.UpdateRange(lstOld);
                    lstNew.ForEach(x =>
                    {
                        x.ApprovalBy = u.UserName;
                        x.ApprovalDate = DateTime.Now.SetKindUtc();
                    });
                    _ctx.UpdateRange(lstNew);
                    await _ctx.SaveChangesAsync();
                }

                res.Error = false;
                res.Message = "Successfully !";
                res.Status = (int)HttpStatusCode.OK;
                return res;
            }
            catch (Exception e)
            {
                res.Error = true;
                res.Message = e.Message;
                res.Status = (int)HttpStatusCode.BadRequest;
                return res;
            }
        }
        [HttpGet("reject-master-individual")]
        public async Task<CommonResponse> RejectMasterIndividual()
        {
            CommonResponse res = new CommonResponse()
            {
                Error = false,
                Message = "",
                Status = (int)HttpStatusCode.BadRequest
            };
            try
            {

                var u = GetCurrentUser();
                //tìm những con cũ dựa vào key những con mới
              
                var model = await _ctx.PcPaMasterIndividuals
                    .Where(x => x.Active == true && x.ApprovalDate == null)
                    .ToListAsync();
               
                    model.ForEach(x =>
                    {
                        x.Active = false;
                        x.ApprovalBy = u.UserName;
                        x.ApprovalDate = DateTime.Now.SetKindUtc();
                    });
                    _ctx.UpdateRange(model);
                    await _ctx.SaveChangesAsync();
                

                res.Error = false;
                res.Message = "Successfully !";
                res.Status = (int)HttpStatusCode.OK;
                return res;
            }
            catch (Exception e)
            {
                res.Error = true;
                res.Message = e.Message;
                res.Status = (int)HttpStatusCode.BadRequest;
                return res;
            }
        }
        [HttpPut("edit-master-individual/{id}")]
        public async Task<CommonResponse> EditMasterIndividual(Guid id, [FromBody] PcPaMasterIndividualRequest rq)
        {
            CommonResponse res = new CommonResponse()
            {
                Error = false,
                Message = "Can't update the master",
                Status = 200
            };
            try
            {

                var u = GetCurrentUser();
                var model = await _ctx.PcPaMasterIndividuals.FirstAsync(x => x.Id == id);
                _ctx.Remove(model);
                var model1 = new PcPaMasterIndividual()
                {
                    Active = true,
                    CreatedBy = u.UserName,
                    Dept = rq.Dept,
                    Description = rq.Description,
                    Factory = rq.Factory,
                    Individual = rq.Individual,
                    Model = rq.Model,
                    Note = rq.Note,
                    Phase = rq.Phase,
                    Product = rq.Product,
                    Remark = rq.Remark
                };
                _ctx.Add(model1);
                int r = await _ctx.SaveChangesAsync();
                res.Message = r > 0 ? "Successful !" : "Can't update";
            }
            catch (Exception e)
            {
                //SendMailError(e);
                res.Message = e.Message;
                res.Error = true;
                res.Status = 400;
            }
            return res;
        }
     
        [HttpPost("add-part-job-assignment")]
        public CommonResponse AddPartJobAssignment([FromBody] PcPaPartJobAssignmentRequest rq)

        {
            CommonResponse res = new CommonResponse()
            {
                Error = false,
                Message = "",
                Status = (int)HttpStatusCode.BadRequest
            };
            try
            {
                var u = GetCurrentUser();
                var model = new PcPaPartJobAssignment()
                {
                    Active = true,
                    CreatedBy = u.UserName,
                    Buyer = rq.Buyer,
                    Note = rq.Note,
                    PartNo = rq.PartNo,
                    PicPo = rq.PicPo,
                    Vendor = rq.Vendor,
                    Product = rq.Product
                };
                _ctx.Add(model);
                _ctx.SaveChanges();
                res.Error = false;
                res.Status = 200;
                res.Message = "Add successful !";
            }
            catch (Exception e)
            {
                res.Error = true;
                res.Message = e.Message;
                res.Status = (int)HttpStatusCode.BadRequest;
            }
            return res;
        }
        [HttpPost("fillter-partadjust-part-job-assignment")]
        public PcPaPartJobAssignmentModel FillterPartJobAssignment(PcPaPartJobAssignmentParam param)
        {
            try
            {
                var result = new PcPaPartJobAssignmentModel();
                var lstResult = new List<PcPaPartJobAssignmentView>();
                var u = GetCurrentUser();

                var model = _ctx.PcPaPartJobAssignments.Where(x => x.Active == true
                && (x.PartNo.ToUpper().Contains(param.PartNo.ToUpper()) 
                && x.Vendor.ToUpper().Contains(param.Vendor.ToUpper())
                && x.Product.ToUpper().Contains(param.Product.ToUpper())
                && x.Buyer.ToUpper().Contains(param.Buyer.ToUpper())));


                var model2 = model.OrderByDescending(x => x.CreatedDate).Paginate(param).ToList();
                int i = 0;
                foreach (var item in model2)
                {
                    lstResult.Add(new PcPaPartJobAssignmentView()
                    {
                        Id = item.Id,
                        Vendor = item.Vendor,
                        Buyer = item.Buyer,
                        PicPo = item.PicPo,
                        PartNo = item.PartNo,
                        Note = item.Note,
                        ApprovalBy = item.ApprovalBy,
                        ApprovalDate = item.ApprovalDate,
                        DoPic = item.DoPic,
                        Product = item.Product
                    }); i++;
                }
                var c = model.Count();
                result.lstModel = lstResult;
                result.toRecord = (int)Math.Min(result.totalRecords, result.currentPage * result.recordPerPage);
                result.totalPage = (int)Math.Ceiling((decimal)c / param.RecordsPerPage);
                result.totalRecords = c;
                result.recordPerPage = param.RecordsPerPage;
                result.currentPage = param.Page;
                result.fromRecord = c == 0 ? 0 : (result.currentPage - 1) * result.recordPerPage + 1;
                return result;
            }
            catch (Exception)
            {
                return new PcPaPartJobAssignmentModel();
            }
        }
        [HttpGet("approve-part-job-assignment")]
        public async Task<CommonResponse> ApprovePartJobAssignment()
        {
            CommonResponse res = new CommonResponse()
            {
                Error = false,
                Message = "",
                Status = (int)HttpStatusCode.BadRequest
            };
            try
            {

                var u = GetCurrentUser();
                var lstUpdate = new List<PcPaPartJobAssignment>();
                var lstOld = _ctx.PcPaPartJobAssignments
                         .Where(x => x.Active == true && x.ApprovalDate != null).ToList();
                var lstNew = _ctx.PcPaPartJobAssignments
                         .Where(x => x.Active == true && x.ApprovalDate == null).ToList();
                if(lstNew != null && lstNew.Count > 0)
                { 
                    lstNew.ForEach(x =>
                    {
                        var exists = lstOld.Where(y => y.Vendor == x.Vendor && y.PartNo == x.PartNo && x.Product == y.Product).ToList();
                        lstUpdate.AddRange(exists);
                        x.ApprovalBy = u.UserName;
                        x.ApprovalDate = DateTime.Now.SetKindUtc();

                    });
                    lstUpdate.ForEach(x => x.Active = false);
                    _ctx.UpdateRange(lstNew);
                    _ctx.UpdateRange(lstUpdate);
                    await _ctx.SaveChangesAsync();
                    await ManualFunc.GatewayAsync("UpdatePicOPStructureAferApproved/IJ");
                    await ManualFunc.GatewayAsync("UpdatePicOPStructureAferApproved/LBP");
                }
                
                res.Error = false;
                res.Message = "Successfully !";
                res.Status = (int)HttpStatusCode.OK;
                return res;
            }
            catch (Exception e)
            {
                res.Error = true;
                res.Message = e.Message;
                res.Status = (int)HttpStatusCode.BadRequest;
                return res;
            }
        }
        [HttpGet("reject-part-job-assignment")]
        public async Task<CommonResponse> RejectPartJobAssignment()
        {
            CommonResponse res = new CommonResponse()
            {
                Error = false,
                Message = "",
                Status = (int)HttpStatusCode.BadRequest
            };
            try
            {

                var u = GetCurrentUser();
                //tìm những con cũ dựa vào key những con mới

                var model = await _ctx.PcPaPartJobAssignments
                    .Where(x => x.Active == true && x.ApprovalDate == null)
                    .ToListAsync();

                model.ForEach(x =>
                {
                    x.Active = false;
                    x.ApprovalBy = u.UserName;
                    x.ApprovalDate = DateTime.Now.SetKindUtc();
                });
                _ctx.UpdateRange(model);
                await _ctx.SaveChangesAsync();


                res.Error = false;
                res.Message = "Successfully !";
                res.Status = (int)HttpStatusCode.OK;
                return res;
            }
            catch (Exception e)
            {
                res.Error = true;
                res.Message = e.Message;
                res.Status = (int)HttpStatusCode.BadRequest;
                return res;
            }
        }
        [HttpPut("edit-part-job-assignment/{id}")]
        public async Task<CommonResponse> EditPartJobAssignment(Guid id, [FromBody] PcPaPartJobAssignmentRequest rq)
        {
            CommonResponse res = new CommonResponse()
            {
                Error = false,
                Message = "Can't update the master",
                Status = 200
            };
            try
            {

                var u = GetCurrentUser();
                var model = await _ctx.PcPaPartJobAssignments.FirstAsync(x => x.Id == id);
                _ctx.Remove(model);
                var model1 = new PcPaPartJobAssignment()
                {
                    Active = true,
                    CreatedBy = u.UserName,
                    Note = rq.Note,
                    Buyer = rq.Buyer,
                    ApprovalBy = null,
                    ApprovalDate = null,
                    PartNo = rq.PartNo,
                    PicPo = rq.PicPo,
                    Vendor = rq.Vendor,
                    Product = rq.Product
                };
                _ctx.Add(model1);
                int r = await _ctx.SaveChangesAsync();
                res.Message = r > 0 ? "Successful !" : "Can't update";
            }
            catch (Exception e)
            {
                //SendMailError(e);
                res.Message = e.Message;
                res.Error = true;
                res.Status = 400;
            }
            return res;
        }

        [HttpPost("import-ManualHandPoHand")]
        public async Task<CommonResponse> ImportManualHandPoHand2Async(string product, string phase, [FromForm] IFormFile file)
        {
            var result = new CommonResponse()
            {
                Error = false,
                Message = "",
                Status = (int)HttpStatusCode.BadRequest
            };
            try
            {
                var u = GetCurrentUser();
                var lstModel = new List<PcPaIp121ManualHandPoHand>();
                using (var memoStream = new MemoryStream())
                {
                    file.CopyTo(memoStream);
                //    using (FileStream fileStream = new FileStream(@"\\cts-app-test\DataShare\PDC\5.Pard Adjustment\OP1.2.1  Manual hand PO - Hand (1A2A6A).xlsx", FileMode.Open))
                //{
                //    MemoryStream memoryStream = new MemoryStream();
                //    fileStream.CopyTo(memoryStream);
                    ExcelPackage.LicenseContext = LicenseContext.NonCommercial;
                    using (var package = new ExcelPackage(memoStream))
                    {
                        var worksheet = package.Workbook.Worksheets[0];
                        if(worksheet.Name != "Form New issue (Hand)")
                        {
                            return result;
                        }
                        var rowCount = worksheet.Dimension?.Rows;
                        if (rowCount.HasValue && rowCount.Value > 6)
                        {
                            for (int row = 7; row <= rowCount.Value; row++)
                            {
                                if (worksheet.Cells["B" + row].ObjToStringAble() == "" || worksheet.Cells["C" + row].ObjToStringAble() == "")
                                {
                                    break;
                                }
                                try
                                {
                                    var no = worksheet.Cells["A" + row].Value.ObjToStringAble().Trim();
                                    var vendor = worksheet.Cells["B" + row].Value.ObjToStringAble();
                                    var part_no = worksheet.Cells["C" + row].Value.ObjToStringAble();
                                    var dim = worksheet.Cells["D" + row].Value.ObjToStringAble();
                                    var used_by = worksheet.Cells["E" + row].Value.ObjToStringAble();
                                    var individual_order = worksheet.Cells["F" + row].Value.ObjToStringAble();
                                    var delivery_date = worksheet.Cells["G" + row].Value.ObjToDatetimeAble();
                                    var order_quantity = worksheet.Cells["H" + row].Value.ObjToStringAble();
                                    var um = worksheet.Cells["I" + row].Value.ObjToStringAble();
                                    var drawing = worksheet.Cells["J" + row].Value.ObjToStringAble();
                                    var shipping_method = worksheet.Cells["K" + row].Value.ObjToStringAble();
                                    var main_body = worksheet.Cells["L" + row].Value.ObjToStringAble();
                                    var transport_method = worksheet.Cells["M" + row].Value.ObjToStringAble();
                                    var reason = worksheet.Cells["N" + row].Value.ObjToStringAble();
                                    var remark = worksheet.Cells["O" + row].Value.ObjToStringAble();
                                    lstModel.Add(new PcPaIp121ManualHandPoHand
                                    {
                                        CreatedBy = u.UserName,
                                        No = no,
                                        Active = true,
                                        PartNo = part_no ?? "",
                                        Vendor = vendor,
                                        Remark = remark,
                                        Reason = reason,
                                        TransportMethod = transport_method,
                                        ShippingMethod = shipping_method,
                                        Um = um,
                                        DeliveryDate = delivery_date.Value.ToString("yyyyMMdd"),
                                        Dim = dim,
                                        Drawing = drawing,
                                        MainBody = main_body,
                                        OrderQuantity = Convert.ToInt32(order_quantity),
                                        Product = "",
                                        UsedBy = used_by,
                                        IndividualOrder = individual_order
                                    });
                                }
                                catch (Exception)
                                {

                                }

                            }
                            if (lstModel.Count == 0)
                            {
                                result.Status = (int)HttpStatusCode.BadRequest;
                                result.Message = "No data";
                                result.Error = true;
                                return result;
                            }

                            _ctx.AddRange(lstModel);
                            _ctx.SaveChanges();

                        }

                    }
                }
                var groupModel = lstModel.GroupBy(x => x.Vendor).ToList();
                foreach(var g in groupModel)
                {
                    await _pa.IssueRequestRevisePOByInput(g.Select(x => x.Id).ToList(), "Hand", phase, product, u.UserName, g.First().Vendor, "ManualHand");
                }
                if (lstModel != null && lstModel.Count > 0)
                {
                    await NoticeNewRequest();
                }
                result.Status = (int)HttpStatusCode.OK;
                result.Message = "Done";
                result.Error = false;
                return result;
            }
            catch (Exception e)
            {
                result.Status = (int)HttpStatusCode.BadRequest;
                result.Message = e.Message;
                result.Error = true;
                return result;
            }
        }
        private async Task NoticeNewRequest()
        {
            try
            {
                var groupId = (await _ctx.AdmMasterApprovalProcesses.Where(x => x.FuncName == "PartAdj" && x.ApprOrder == 1).FirstAsync()).GroupId;
                var lstEmail = _ctx.AdmDetailUserGroups.Where(x => x.Active == true && x.GroupId == groupId).Include(x => x.User).Select(x => x.User.Email ?? "").ToList();
                _email.Initial(lstEmail, "New request Part Adjustment", @"<p style='font-weight: bold;'>Dear [Mrs/Mr]. All,</p>
                <p>You have received a notification about <span style='font-weight: bold; color: red; font-style: italic;'>New Issue Revise PO from Part Adjustment </span>from PSI System. Please check at link <a href='http://cvn-psi/#/turnoverday/part-adjustment/request-revise-po'>Request Revise Po</a> .</p>
                
                ");
            }
            catch (Exception)
            {

            }
        }
        [HttpPost("import-ManualHandPoRevise")]
        public async Task<CommonResponse> ImportManualHandPoRevise2Async(string product, string phase, [FromForm] IFormFile file)
        {
            var result = new CommonResponse()
            {
                Error = false,
                Message = "",
                Status = (int)HttpStatusCode.BadRequest
            };
            try
            {
                var u = GetCurrentUser();
                var lstModel = new List<PcPaIp122ManualHandPoRevise>();
                using (var memoStream = new MemoryStream())
                {
                    file.CopyTo(memoStream);
                //    using (FileStream fileStream = new FileStream(@"\\cts-app-test\DataShare\PDC\5.Pard Adjustment\OP1.2.2  Manual hand PO - Revise (1A2A6A).xlsx", FileMode.Open))
                //{
                //    MemoryStream memoryStream = new MemoryStream();
                //    fileStream.CopyTo(memoryStream);
                    ExcelPackage.LicenseContext = LicenseContext.NonCommercial;
                    using (var package = new ExcelPackage(memoStream))
                    {
                        var worksheet = package.Workbook.Worksheets[0];
                        if(worksheet.Name != "Form pull in-Pull out-cancel")
                        {
                            return result;
                        }
                        var rowCount = worksheet.Dimension?.Rows;
                        if (rowCount.HasValue && rowCount.Value > 6)
                        {
                            for (int row = 7; row <= rowCount.Value; row++)
                            {
                                try
                                {
                                    if (worksheet.Cells["B" + row].ObjToStringAble() == "" || worksheet.Cells["C" + row].ObjToStringAble() == "")
                                    {
                                        break;
                                    }
                                    var no = worksheet.Cells["A" + row].Value.ObjToStringAble().Trim();
                                    var vendor = worksheet.Cells["B" + row].Value.ObjToStringAble();
                                    var part_no = worksheet.Cells["C" + row].Value.ObjToStringAble();
                                    var dim = worksheet.Cells["D" + row].Value.ObjToStringAble();
                                    var delivery_key_no = worksheet.Cells["E" + row].Value.ObjToStringAble();
                                    var used_by = worksheet.Cells["F" + row].Value.ObjToStringAble();
                                    var used_by2 = worksheet.Cells["G" + row].Value.ObjToStringAble();
                                    var delivery_location = worksheet.Cells["H" + row].Value.ObjToStringAble();
                                    var delivery_location2 = worksheet.Cells["I" + row].Value.ObjToStringAble();
                                    var delivery_date = worksheet.Cells["J" + row].Value.ObjToStringAble();
                                    var delivery_date2 = worksheet.Cells["K" + row].Value.ObjToStringAble();
                                    var order_quantity = worksheet.Cells["L" + row].Value.ObjToStringAble();
                                    var order_quantity2 = worksheet.Cells["M" + row].Value.ObjToStringAble();
                                    var drawing = worksheet.Cells["N" + row].Value.ObjToStringAble();
                                    var drawing2 = worksheet.Cells["O" + row].Value.ObjToStringAble();
                                    var main_body = worksheet.Cells["P" + row].Value.ObjToStringAble();
                                    var main_body2 = worksheet.Cells["Q" + row].Value.ObjToStringAble();
                                    var transport_method = worksheet.Cells["R" + row].Value.ObjToStringAble();
                                    var transport_method2 = worksheet.Cells["S" + row].Value.ObjToStringAble();
                                    var reason = worksheet.Cells["T" + row].Value.ObjToStringAble();
                                    var remark = worksheet.Cells["U" + row].Value.ObjToStringAble();
                                    lstModel.Add(new PcPaIp122ManualHandPoRevise
                                    {
                                        CreatedBy = u.UserName,
                                        Active = true,
                                        PartNo = part_no ?? "",
                                        Vendor = vendor,
                                        Remark = remark,
                                        Reason = reason,
                                        DeliveryDate = delivery_date,
                                        Dim = dim,
                                        Drawing = drawing,
                                        MainBody = main_body,
                                        OrderQuantity = Convert.ToInt32(order_quantity),
                                        Product = product,
                                        UsedBy = used_by,
                                        DeliveryDate2 = delivery_date2,
                                        DeliveryKeyNo = delivery_key_no,
                                        DeliveryLocation = delivery_location,
                                        DeliveryLocation2 = delivery_location2,
                                        Drawing2 = drawing2,
                                        MainBody2 = main_body2,
                                        OrderQuantity2 = order_quantity2.StringToIntAble(),
                                        ShippingMethod = "",
                                        TransportMethod = transport_method,
                                        TransportMethod2 = transport_method2,
                                        UsedBy2 = used_by2,
                                        No = no
                                    });
                                }
                                catch (Exception)
                                {

                                }
                                
                            }
                            if (lstModel.Count == 0)
                            {
                                result.Status = (int)HttpStatusCode.BadRequest;
                                result.Message = "No data";
                                result.Error = true;
                                return result;
                            }

                            _ctx.AddRange(lstModel);
                            _ctx.SaveChanges();

                        }

                    }
                }

                var groupModel = lstModel.GroupBy(x => x.Vendor).ToList();
                foreach (var g in groupModel)
                {
                    await _pa.IssueRequestRevisePOByInput(g.Select(x => x.Id).ToList(), "Revise", phase, product, u.UserName, g.First().Vendor, "ManualRevise");
                }
                if (lstModel != null && lstModel.Count > 0)
                {
                    await NoticeNewRequest();
                }
                result.Status = (int)HttpStatusCode.OK;
                result.Message = "Success";
                result.Error = false;
                return result;
            }
            catch (Exception e)
            {
                result.Status = (int)HttpStatusCode.BadRequest;
                result.Message = e.Message;
                result.Error = true;
                return result;
            }
        }
        [HttpGet("import-AutoERI")]
        public async Task<CommonResponse> ImportEri2Async(string product, string phase)
        {
            var result = new CommonResponse()
            {
                Error = false,
                Message = "",
                Status = (int)HttpStatusCode.BadRequest
            };
            try
            {
                var u = GetCurrentUser();
                var lstModel = _ctx.PcPaIp11AutoEriIssues.Where(x => x.Active == true && x.RqId == null && x.CreatedDate > DateTime.Today).ToList();
                var groupModel = lstModel.GroupBy(x => x.Vendor).ToList();
                foreach (var g in groupModel)
                {
                    await _pa.IssueRequestRevisePOByInput(g.Select(x => x.Id).ToList(), "ERI", phase, product, u.UserName, g.First().Vendor, "AutoERI");
                }

                result.Status = (int)HttpStatusCode.OK;
                result.Message = "Success";
                result.Error = false;
                return result;
            }
            catch (Exception e)
            {
                result.Status = (int)HttpStatusCode.BadRequest;
                result.Message = e.Message;
                result.Error = true;
                return result;
            }
        }
        [HttpGet("import-AutoNPIS")]
        public async Task<CommonResponse> ImportNPIS2Async(string product, string phase)
        {
            var result = new CommonResponse()
            {
                Error = false,
                Message = "",
                Status = (int)HttpStatusCode.BadRequest
            };
            try
            {
                var u = GetCurrentUser();
                var lstModel = _ctx.PcPaIp13aAutoPoPendingNpis.Where(x => x.Active == true && x.RqId == null && x.CreatedDate > DateTime.Today).ToList();
                var groupModel = lstModel.GroupBy(x => x.Vendor).ToList();
                foreach (var g in groupModel)
                {
                    await _pa.IssueRequestRevisePOByInput(g.Select(x => x.Id).ToList(), "NPIS", phase, product, u.UserName, g.First().Vendor, "AutoNPIS");
                }

                result.Status = (int)HttpStatusCode.OK;
                result.Message = "Success";
                result.Error = false;
                return result;
            }
            catch (Exception e)
            {
                result.Status = (int)HttpStatusCode.BadRequest;
                result.Message = e.Message;
                result.Error = true;
                return result;
            }
        }




        [HttpGet("get-detail-request-revise-po/{id}")]
        public async Task<PcPaRequestRevisePoDetailModel> DetailPcPaRequestRevisePO(Guid id)
        {
            try
            {
                var result = new PcPaRequestRevisePoDetailModel();
                var requestInfo = new PcPaRequestRevisePo();
                var lstProcess = new List<PcPaRequestRevisePoProcess>();
                var lstDetail = new List<object>();
                var u = GetCurrentUser();

                var model = await _ctx.PcPaRequestRevisePos.Where(x => x.Id == id).FirstAsync();
                requestInfo = model;
                lstProcess = await _ctx.PcPaRequestRevisePoProcesses.Where(x => x.Active == true && x.RequestId == id).OrderBy(x => x.AprOrder).ToListAsync();

                result.RequestInfo = requestInfo.MapPartAdjustment();
                result.LstProcess = lstProcess.MapPartAdjustment();
                result.LstEri = (await _ctx.PcPaIp11AutoEriIssues.Where(x => x.Active == true && x.RqId == id).OrderBy(x => x.No).ToListAsync()).MapPartAdjustment();
                result.LstHand = (await _ctx.PcPaIp121ManualHandPoHands.Where(x => x.Active == true && x.RqId == id).OrderBy(x => x.No).ToListAsync()).MapPartAdjustment();
                result.LstRevise = (await _ctx.PcPaIp122ManualHandPoRevises.Where(x => x.Active == true && x.RqId == id).OrderBy(x => x.No).ToListAsync()).MapPartAdjustment();
                result.Lst13a = (await _ctx.PcPaIp13aAutoPoPendingNpis.Where(x => x.Active == true && x.RqId == id).OrderBy(x => x.PartNo).ToListAsync()).MapPartAdjustment();
                result.Lst13b = (await _ctx.PcPaIp13bAutoIssueFormRevises.Where(x => x.Active == true && x.RqId == id).OrderBy(x => x.No).ToListAsync()).MapPartAdjustment();
                result.Lst13c = (await _ctx.PcPaIp13cAutoIssueFormRevises.Where(x => x.Active == true && x.RqId == id).OrderBy(x => x.No).ToListAsync()).MapPartAdjustment();
                var tem13d = await _ctx.PcPaIp13dAutoIssueFormRevises.Where(x => x.Active == true && x.RqId == id).OrderBy(x => x.No).ToListAsync();
                if(tem13d != null && tem13d.Count > 0)
                {
                    result.Lst13b = tem13d.MapPartAdjustment();
                }
                
                return result;
            }
            catch (Exception)
            {
                return new PcPaRequestRevisePoDetailModel();
            }
        }


        [HttpPost("filter-pcpa-request-revise-po")]
        public async Task<PcPaRequestRevisePoModel> FilterPcPaRequestRevisePO(PcPaRequestRevisePOParam param)
        {
            try
            {
                var result = new PcPaRequestRevisePoModel();
                var lstResult = new List<PcPaRequestRevisePo>();
                var u = GetCurrentUser();

                var model = _ctx.PcPaRequestRevisePos.Where(x => x.Active == true
                && x.CreatedDate > DateTime.Today
                && x.RequestNo.ToUpper().Contains(param.Pic.ToUpper()));
                if (!string.IsNullOrEmpty(param.Product))
                {
                    model = model.Where(x => x.Product == param.Product);
                }

                var model2 = await model.OrderByDescending(x => x.RequestNo).Paginate(param).ToListAsync();
                int i = 0;

                var c = await model.CountAsync();
                result.lstModel = model2;
                result.toRecord = (int)Math.Min(result.totalRecords, result.currentPage * result.recordPerPage);
                result.totalPage = (int)Math.Ceiling((decimal)c / param.RecordsPerPage);
                result.totalRecords = c;
                result.recordPerPage = param.RecordsPerPage;
                result.currentPage = param.Page;
                result.fromRecord = c == 0 ? 0 : (result.currentPage - 1) * result.recordPerPage + 1;
                return result;
            }
            catch (Exception)
            {
                return new PcPaRequestRevisePoModel();
            }
        }

        [HttpPost("inquiry-pcpa-request-revise-po")]
        public PcPaRequestRevisePoModel InquiryPcPaRequestRevisePO(PcPaRequestRevisePOParam param)
        {
            try
            {
                var result = new PcPaRequestRevisePoModel();
                var lstResult = new List<PcPaRequestRevisePo>();
                var u = GetCurrentUser();

                var model = _ctx.PcPaRequestRevisePos.Where(x => x.Active == true
                && x.CreatedDate < DateTime.Today 
                && (x.RequestNo.ToUpper().Contains(param.search.ToUpper().Trim())));

                var model2 = model.OrderByDescending(x => x.CreatedDate).Paginate(param).ToList();
                int i = 0;

                var c = model.Count();
                result.lstModel = model2;
                result.toRecord = (int)Math.Min(result.totalRecords, result.currentPage * result.recordPerPage);
                result.totalPage = (int)Math.Ceiling((decimal)c / param.RecordsPerPage);
                result.totalRecords = c;
                result.recordPerPage = param.RecordsPerPage;
                result.currentPage = param.Page;
                result.fromRecord = c == 0 ? 0 : (result.currentPage - 1) * result.recordPerPage + 1;
                return result;
            }
            catch (Exception)
            {
                return new PcPaRequestRevisePoModel();
            }
        }
        [HttpPost("output-upload-npis")]
        public PcPaOutputUploadNPISModel OutputUploadNPIS(OutputUploadNPISParam param)
        {
            try
            {
                var result = new PcPaOutputUploadNPISModel();
                var lstResult = new List<PcPaOutputUploadNPIS>();
                var u = GetCurrentUser();

                var modelOp21 = _ctx.PcPaOp21Hands.Where(x => x.Active == true);
                var modelOp22 = _ctx.PcPaOp22Hands.Where(x => x.Active == true);
                var modelOp23 = _ctx.PcPaOp23Revises.Where(x => x.Active == true);
                if(param.Vendor != "")
                {
                    modelOp21 = modelOp21.Where(x => x.Vendor.Contains(param.Vendor)).DistinctBy(x => x.RequestId);
                    modelOp22 = modelOp22.Where(x => x.Vendor.Contains(param.Vendor)).DistinctBy(x => x.RequestId);
                    modelOp23 = modelOp23.Where(x => x.Vendor.Contains(param.Vendor)).DistinctBy(x => x.RequestId);
                }
                var lmodelOp21 = modelOp21.OrderByDescending(x => x.CreatedDate).Paginate(param).ToList();
                var lmodelOp22 = modelOp22.OrderByDescending(x => x.CreatedDate).Paginate(param).ToList();
                var lmodelOp23 = modelOp23.OrderByDescending(x => x.CreatedDate).Paginate(param).ToList();
                int i = 0;

                if(lmodelOp21.Count > 0)
                {
                    foreach(var item in lmodelOp21)
                    {
                        try
                        {
                            var rq = _ctx.PcPaRequestRevisePos.Where(x => x.Id == item.RequestId.Value).First();
                            lstResult.Add(new PcPaOutputUploadNPIS()
                            {
                                OutputType = "Hand for ERI/MT part",
                                RequestId = item.RequestId.Value,
                                Vendor = item.Vendor,
                                RequestNo = rq.RequestNo,
                                PartNo = item.PartNo
                            });
                        }
                        catch (Exception)
                        {
                            continue;
                        }
                        
                    }
                }
                if (lmodelOp22.Count > 0)
                {
                    foreach (var item in lmodelOp22)
                    {
                        try
                        {
                            var rq = _ctx.PcPaRequestRevisePos.Where(x => x.Id == item.RequestId.Value).First();
                            lstResult.Add(new PcPaOutputUploadNPIS()
                            {
                                OutputType = "Hand for MP part",
                                RequestId = item.RequestId.Value,
                                Vendor = item.Vendor,
                                RequestNo = rq.RequestNo,
                                PartNo = item.PartNo
                            });
                        }
                        catch (Exception)
                        {
                            continue;
                        }
                    }
                }
                if (lmodelOp23.Count > 0)
                {
                    foreach (var item in lmodelOp23)
                    {
                        try
                        {
                            var rq = _ctx.PcPaRequestRevisePos.Where(x => x.Id == item.RequestId.Value).First();
                            lstResult.Add(new PcPaOutputUploadNPIS()
                            {
                                OutputType = "Revise for MP part",
                                RequestId = item.RequestId.Value,
                                Vendor = item.Vendor,
                                RequestNo = rq.RequestNo,
                                PartNo = item.PartsNo
                            });
                        }
                        catch (Exception)
                        {
                            continue;
                        }
                    }
                }
                var c = lmodelOp21.Count + lmodelOp22.Count + lmodelOp23.Count;
                result.lstModel = lstResult;
                result.toRecord = (int)Math.Min(result.totalRecords, result.currentPage * result.recordPerPage);
                result.totalPage = (int)Math.Ceiling((decimal)c / param.RecordsPerPage);
                result.totalRecords = c;
                result.recordPerPage = param.RecordsPerPage;
                result.currentPage = param.Page;
                result.fromRecord = c == 0 ? 0 : (result.currentPage - 1) * result.recordPerPage + 1;
                return result;
            }
            catch (Exception)
            {
                return new PcPaOutputUploadNPISModel();
            }
        }

        [HttpGet("is-next-approval/{id}")]
        public async Task<CommonResponse> CheckIsNextApproval(Guid id)
        {
            var res = new CommonResponse()
            {
                Error = false,
                Message = "No content",
                Status = 200
            };
            try
            {
                var md = await _ctx.PcPaRequestRevisePos.Where(x => x.Active == true && x.Id == id).FirstAsync();
                if(md.NextApproval == null || md.Status != "Waiting")
                {
                    res.Error = true;
                    res.Message = "Finished process !";
                    return res;
                }
                var nextProcess = await _ctx.PcPaRequestRevisePoProcesses.Where(x => x.Active == true && x.AprNext == true).FirstOrDefaultAsync();
                if(nextProcess == null)
                {
                    res.Error = true;
                    res.Message = "Finished process !";
                    return res;
                }
                else
                {
                    var groupId = nextProcess.GroupId;
                    var u = GetCurrentUser();
                    var uId = Guid.Parse(u.Id);
                    var check = _ctx.AdmDetailUserGroups.Any(x => x.Active == true && x.GroupId == groupId && x.UserId == uId);
                    if(check)
                    {
                        res.Error = false;
                        res.Message = "Is next approver !";
                        return res;
                    }
                    else
                    {
                        res.Error = true;
                        res.Message = "Permission denied !";
                        return res;
                    }
                }
            }
            catch (Exception ex)
            {
                res.Error = true;
                res.Message = ex.Message;
                res.Status = 400;
            }
            return res;
        }
        [HttpGet("approve-issue-revise-po/{id}")]
        public async Task<CommonResponse> ApproveRequestRevisePO(Guid id, bool action, string comment)//action nhận true là approve, còn false là reject
        {
            var res = new CommonResponse()
            {
                Error = false,
                Message = "No content",
                Status = 200
            };
            try
            {
                var u = GetCurrentUser();
                var currentProcess = await _ctx.PcPaRequestRevisePoProcesses.Where(x => x.Active == true && x.Id == id).FirstOrDefaultAsync();
                if (currentProcess == null)
                {
                    res.Error = true;
                    res.Message = "Finished process !";
                    return res;
                }
                else
                {
                    currentProcess.AprNext = false;
                    currentProcess.AprStatus = action;
                    currentProcess.ModifiedBy = u.UserName;
                    currentProcess.ModifiedDate = DateTime.Now.SetKindUtc();
                    currentProcess.AprComment = comment;
                    _ctx.PcPaRequestRevisePoProcesses.Update(currentProcess);
                    _ctx.SaveChanges();

                    var nextProcess = await _ctx.PcPaRequestRevisePoProcesses.Where(x => x.Active == true
                    && x.RequestId == currentProcess.RequestId && x.AprOrder == (currentProcess.AprOrder + 1)).FirstOrDefaultAsync();
                    if(nextProcess == null)
                    {
                        var rq = await _ctx.PcPaRequestRevisePos.Where(x => x.Id == currentProcess.RequestId).FirstAsync();
                        if(action == true)
                        {
                            rq.ConfirmSendRq = "Yes";
                            rq.NextApproval = null;
                            rq.Status = "Completed";
                            rq.ConfirmUpdateNpis = "Yes";

                            //nếu approve đến cuối cùng thì tính output 
                            if (rq.RequestNo.Contains("ERI") || rq.RequestNo.Contains("Hand_MT_") || rq.RequestNo.Contains("Revise_MT_"))
                            {
                                await _pa.Op21_HandForEriMtPart(rq.Id);
                            }
                            else if ((rq.RequestNo.Contains("NPIS") && rq.RequestNo.Contains("RH")) || rq.RequestNo.Contains("Hand_MP_"))
                            {
                                await _pa.Op22_HandFor13cMpPart(rq.Id);
                            }
                            else if((rq.RequestNo.Contains("NPIS") && (rq.RequestNo.Contains("RHR") || rq.RequestNo.Contains("D"))) || rq.RequestNo.Contains("Revise_MP_"))
                            {
                                await _pa.Op23_ReviseFor13bMpPart(rq.Id);
                            }
                        }
                        else
                        {
                            rq.ConfirmSendRq = "No";
                            rq.NextApproval = null;
                            rq.Status = "Rejected";
                            rq.ConfirmUpdateNpis = "No";
                        }
                        rq.ModifiedBy = u.UserName;
                        rq.ModifiedDate = DateTime.Now.SetKindUtc();
                        _ctx.PcPaRequestRevisePos.Update(rq);
                        _ctx.SaveChanges();

                        res.Error = false;
                        res.Message = "Finished process !";
                        return res;
                    }
                    else
                    {
                        if(action == true)
                        {
                            nextProcess.AprNext = true;
                            _ctx.PcPaRequestRevisePoProcesses.Update(nextProcess);
                            _ctx.SaveChanges();

                            var rq = await _ctx.PcPaRequestRevisePos.Where(x => x.Id == currentProcess.RequestId).FirstAsync();
                            rq.NextApproval = nextProcess.AprGrade;
                            rq.Status = "Waiting";
                            rq.ModifiedBy = u.UserName;
                            rq.ModifiedDate = DateTime.Now.SetKindUtc();
                            _ctx.PcPaRequestRevisePos.Update(rq);
                            _ctx.SaveChanges();

                            var lstEmail = _ctx.AdmDetailUserGroups.Where(x => x.Active == true && x.GroupId == nextProcess.GroupId).Include(x => x.User).Select(x => x.User.Email ?? "").ToList();
                            _email.Initial(lstEmail, "New request Part Adjustment", @"<p style='font-weight: bold;'>Dear [Mrs/Mr]. All,</p>
                <p>You have received a notification about <span style='font-weight: bold; color: red; font-style: italic;'>New Issue Revise PO from Part Adjustment </span>from PSI System. Please check at link <a href='http://cvn-vpsi/#/turnoverday/part-adjustment/request-revise-po-detail-all/" + rq.Id + @"'>" + rq.RequestNo + @"</a> .</p>
                
                ");
                        }
                        else
                        {
                            var rq = await _ctx.PcPaRequestRevisePos.Where(x => x.Id == currentProcess.RequestId).FirstAsync();
                            rq.NextApproval = "Rejected";
                            rq.Status = "Rejected";
                            rq.ModifiedBy = u.UserName;
                            rq.ModifiedDate = DateTime.Now.SetKindUtc();
                            _ctx.PcPaRequestRevisePos.Update(rq);
                            _ctx.SaveChanges();
                        }

                        res.Error = false;
                        res.Message = "Successful !";
                        return res;
                    }
                }
            }
            catch (Exception ex)
            {
                res.Error = true;
                res.Message = ex.Message;
                res.Status = 400;
            }
            return res;
        }
        [HttpGet("force-execute-output-npis/{id}")]
        public async Task<CommonResponse> ForceExecuteNPIS(Guid id)
        {
            var res = new CommonResponse()
            {
                Error = false,
                Message = "No content",
                Status = 200
            };
            try
            {
                var rq = await _ctx.PcPaRequestRevisePos.Where(x => x.Id == id).FirstAsync();
                //nếu approve đến cuối cùng thì tính output 
                if (rq.RequestNo.Contains("ERI") || rq.RequestNo.Contains("Hand_MT_") || rq.RequestNo.Contains("Revise_MT_"))
                {
                    await _pa.Op21_HandForEriMtPart(rq.Id);
                }
                else if ((rq.RequestNo.Contains("NPIS") && rq.RequestNo.Contains("RH")) || rq.RequestNo.Contains("Hand_MP_"))
                {
                    await _pa.Op22_HandFor13cMpPart(rq.Id);
                }
                else if ((rq.RequestNo.Contains("NPIS") && (rq.RequestNo.Contains("RHR") || rq.RequestNo.Contains("D"))) || rq.RequestNo.Contains("Revise_MP_"))
                {
                    await _pa.Op23_ReviseFor13bMpPart(rq.Id);
                }

                res.Error = false;
                res.Message = "Successful !";
                res.Status = 200;
            }
            catch (Exception ex)
            {
                res.Error = true;
                res.Message = ex.Message;
                res.Status = 400;
            }
            return res;
        }

        [HttpGet("test-generate-requestno")]
        [AllowAnonymous]
        public async Task<string> TestGenerateRequestno(string request, string phase)
        {
            try
            {
                //var result = await ADO.GetString("select public.generate_request_no('" + request + "', '" + phase + "')");
                var result = await _pa.GenerateRequestNumberOfPartAdjustment(request, phase, "TEST");
                return result;
            }
            catch (Exception) { }
            return "";
        }
        [HttpGet("test-po-pending")]
        [AllowAnonymous]
        public async Task<string> TestGetPoPending()
        {
            try
            {
                //var result = await _pa.Ip13a_AutoIssueHandPoNpis("IJ");
                var result = await _pa.Ip13a_AutoIssueHandPoNpis("LBP");
                return "";
            }
            catch (Exception) { }
            return "";
        }
        [HttpGet]
        [Route("TestERI")]
        [AllowAnonymous]
        public async Task<string> TestERI()
        {
            await _pa.Ip11_AutoIssueFormHandPOERI();
            return "Da bat dau check !";
        }
        private UserClaims GetCurrentUser()
        {
            UserClaims userClaims = new UserClaims();
            var identity = HttpContext.User.Identity as ClaimsIdentity;
            if (identity != null)
            {
                userClaims.UserName = identity.FindFirst("user_name") == null ? "Undefined" : identity.FindFirst("user_name").Value;
                userClaims.Id = identity.FindFirst("id") == null ? "Undefined" : identity.FindFirst("id").Value;
                userClaims.Departments = identity.FindFirst("deptIds") == null ? "" : identity.FindFirst("deptIds").Value;
                userClaims.Factories = identity.FindFirst("factIds") == null ? "" : identity.FindFirst("factIds").Value;
                userClaims.CostCenter = identity.FindFirst("cost_center") == null ? "" : identity.FindFirst("cost_center").Value;
                userClaims.FullName = identity.FindFirst("full_name") == null ? "" : identity.FindFirst("full_name").Value;
                userClaims.Departments = identity.FindFirst("dept") == null ? "" : identity.FindFirst("dept").Value;
                userClaims.Grade = identity.FindFirst("grade") == null ? "" : identity.FindFirst("grade").Value;
                userClaims.IsAdmin = identity.FindFirst("isAdmin") == null ? "false" : identity.FindFirst("isAdmin").Value;

            }
            return userClaims;
        }
    }
}
