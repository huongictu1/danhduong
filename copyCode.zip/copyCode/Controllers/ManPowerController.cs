﻿using AutoMapper;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Newtonsoft.Json;
using PDCProjectApi.Common;
using PDCProjectApi.Common.Interface;
using PDCProjectApi.Data;
using PDCProjectApi.Helper;
using PDCProjectApi.Model.Request;
using PDCProjectApi.Model.Response;
using PDCProjectApi.Model.View;
using System.Net;
using System.Security.Claims;
using PDCProjectApi.Common.Job;
using System.Diagnostics;
using AutoMapper.QueryableExtensions;
using PDCProjectApi.Services;
using OfficeOpenXml;
using DocumentFormat.OpenXml.Spreadsheet;
using System.Linq;
using PDCProjectApi.Common.Function;
using Microsoft.IdentityModel.Tokens;
using DocumentFormat.OpenXml.Drawing.Charts;
using DocumentFormat.OpenXml.Wordprocessing;
using DocumentFormat.OpenXml.Office2016.Drawing.ChartDrawing;
using Hangfire;

namespace PDCProjectApi.Controllers
{
    [Route("api/manpower")]
    [ApiController]
    [Authorize]
    public class ManPowerController : Controller
    {
        [Obsolete]
        private readonly Microsoft.AspNetCore.Hosting.IHostingEnvironment _hostingEnvironment;
        private readonly IHttpContextAccessor httpContextAccessor;
        private readonly IFileStorageService fileStorageService;
        private readonly PdcsystemContext context;
        private readonly IConfiguration configuration;
        private readonly IEmailService email;
        private readonly IManPower _mpw;
        [Obsolete]
        public ManPowerController(Microsoft.AspNetCore.Hosting.IHostingEnvironment hosting, PdcsystemContext ctx,
            IHttpContextAccessor httpContextAccessor, IFileStorageService fileService, IManPower mpw,
            IConfiguration configuration, IEmailService mail)
        {
            this._hostingEnvironment = hosting;
            this.httpContextAccessor = httpContextAccessor;
            this.context = ctx;
            this.fileStorageService = fileService;
            this.configuration = configuration;
            this.email = mail;
            this._mpw = mpw;
        }

        #region master 
        [HttpGet("check-pic-pdc1")]
        public bool CheckPicPdc1()
        {
            var u = GetCurrentUser();
            return context.AdmDetailUserGroups.Any(x => x.Active == true && x.UserId == new Guid(u.Id) && (x.GroupId == new Guid("9c418949-f339-428b-a351-9e5709318544")
            || x.GroupId == new Guid("1567cfeb-32fe-4745-bbdc-2ace703099d4")));

        }
        [HttpGet("check-admin")]
        public bool CheckAdmin()
        {
            var u = GetCurrentUser();
            return context.AdmDetailUserGroups.Any(x => x.Active == true && x.UserId == new Guid(u.Id) &&
            (x.GroupId == new Guid("e462d3a8-27fa-4ffa-bac4-512a2ab33bc3")
            || x.GroupId == new Guid("1567cfeb-32fe-4745-bbdc-2ace703099d4")
            ));

        }
        [HttpGet("filter-manpower-master-time")]
        public async Task<List<MPTimeView>> FilterMPMasterTime()
        {
            try
            {
                var lstResult = new List<MPTimeView>();
                var query = await context.MpManpowerTimes.Where(x => x.Active == true).OrderBy(x => x.CreatedDate).ToListAsync();
                foreach (var item in query)
                {
                    lstResult.Add(new MPTimeView
                    {
                        Id = item.Id,
                        Product = item.Product,
                        From = item.From == null ? null : item.From.Value.ToString("MMM-dd-yyyy"),
                        To = item.To == null ? null : item.To.Value.ToString("MMM-dd-yyyy"),
                        ModifyBy = item.ModifiedBy,
                        ModifyDate = item.ModifiedDate == null ? null : item.ModifiedDate.Value.ToString("MMM-dd-yyyy"),
                        Version = item.Version
                    });
                }

                return lstResult;
            }
            catch (Exception e)
            {
                //SendMailError(e);
                return new List<MPTimeView>();
            }
        }

        [HttpPut("edit-manpower-master-time")]
        public async Task<CommonResponse> EditMPMasterTime(ManPowerRequest rq)
        {
            CommonResponse res = new CommonResponse()
            {
                Error = false,
                Message = "",
                Status = (int)HttpStatusCode.BadRequest
            };
            try
            {
                DateOnly? from = rq.From.StringToDateAble();
                DateOnly? to = rq.To.StringToDateAble();
                var u = GetCurrentUser();
                var model = await context.MpManpowerTimes.Where(x => x.Active == true).ToListAsync();
                model.ForEach(x => x.From = from);
                model.ForEach(x => x.To = to);
                model.ForEach(x => x.Version = rq.Version);
                model.ForEach(x => x.ModifiedBy = u.UserName + "_" + u.FullName);
                model.ForEach(x => x.ModifiedDate = DateTime.Now.SetKindUtc());
                context.UpdateRange(model);
                context.SaveChanges();


                res.Error = false;
                res.Message = "Successfully !";
                res.Status = (int)HttpStatusCode.OK;
                return res;
            }
            catch (Exception e)
            {

                res.Error = true;
                res.Message = e.Message;
                res.Status = (int)HttpStatusCode.BadRequest;
                //SendMailError(e);
                return res;
            }
        }
        [HttpGet("check-month-op3")]
        public List<string> CheckMonth()
        {
            var lstMonth = context.MpManpowerOp3Monthlies.ToList().Select(x => x.Date.ToList().Select(y => y).ToList()).ToList();
            List<DateOnly> oneDimensionalList = new List<DateOnly>();

            // Duyệt qua từng danh sách con và thêm phần tử vào danh sách kết quả
            foreach (var sublist in lstMonth)
            {
                oneDimensionalList.AddRange(sublist);
            }

            return oneDimensionalList.Distinct().Select(x => x.ToString("MM-dd-yyyy")).ToList();

        }
        [HttpGet("check-version-in-output")]
        public List<string> CheckVersionInOutput()
        {
            var lstVersion = context.MpManpowerItems.Where(x => x.Version != null).Select(x => x.Version).Distinct().ToList();       
            return lstVersion;

        }
        [HttpGet("filter-manpower-current-status")]
        public List<MPCheckStatusView> CheckManpowerCurrentStatus()
        {
            List<MPCheckStatusView> lstResult = new List<MPCheckStatusView>();
            var model = context.MpManpowerItems.Where(x => x.Active == true).ToList();
            var lstDept = model.Select(x => new { x.Dept,x.TypePs }).Distinct().ToList();
            foreach(var item in lstDept)
            {
                var check = model.FirstOrDefault(x => x.Dept == item.Dept && x.TypePs == item.TypePs);
                lstResult.Add(new MPCheckStatusView
                {
                    Dept = item.Dept,
                    CreatedBy = check.CreatedBy,
                    CreatedDate = check.CreatedDate == null? null:check.CreatedDate.Value.ToString("dd-MMM-yyyy"),
                    Version = check.Version,
                    Type = check.TypePs,
                    Status = check.RejectedBy != null? "Rejected":(check.ApprovedBy != null ?"Approved":"Checking")
                });
            }
            return lstResult;

        }
        #endregion

        #region manpower
        [HttpGet("get-dept-manpower")]
        public List<string>? GetDeptManPower()
        {
            try
            {
                return context.MpManpowerItems.Where(x => x.Active == true).Select(x => x.Dept).Distinct().ToList();
            }
            catch
            {
                return new List<string>();
            }
        }
        [HttpGet("check-approver-manpower")]
        public bool CheckApproverManPower()
        {
            var u = GetCurrentUser();
            return context.AdmDetailUserGroups.Any(x => x.Active == true && x.UserId == new Guid(u.Id) && x.GroupId == new Guid("fd608f81-c0c3-4bf0-bc0c-585986c30fe8"));

        }
        [HttpPost("filter-manpower-item")]
        public async Task<MPItemView> FilterMPItem(ManPowerItemRequest param)
        {
            try
            {
                var lstResult = new MPItemView();
                var query = await context.MpManpowerItems.Where(x => x.Active == true && x.Dept.ToUpper() == param.Dept.ToUpper()
                && x.Product.ToUpper() == param.Product.ToUpper() && x.TypePs == param.Type/*&& x.Version.ToUpper() == param.Version.ToUpper()*/).OrderBy(x => x.OrderNo).ToListAsync();
                var masterCalendar = context.AdmMasterCalendars.ToList();
                var calc = query.FirstOrDefault();
                lstResult.Version = calc.Version;
                var mpCal = masterCalendar.Where(x => x.DateOfDate >= calc.From && x.DateOfDate <= calc.To).OrderBy(x => x.DateOfDate).Select(x => x.DateOfDate.ToString("yyyy-MM-dd")).ToList();
                lstResult.LstDate = mpCal;
                lstResult.LstValue = new List<List<string>?>();
                foreach (var item in query)
                {
                    lstResult.LstValue.Add(item.Value.ToList());
                }
                lstResult.ApprovedBy = query.FirstOrDefault().ApprovedBy == null && query.FirstOrDefault().RejectedBy == null ? "Checking" : (query.FirstOrDefault().RejectedBy != null ? "Rejected" : "Approved");
                return lstResult;
            }
            catch (Exception e)
            {
                //SendMailError(e);
                return new MPItemView();
            }
        }

        [HttpGet("approve-manpower-item/{dept}/{type}")]
        public async Task<CommonResponse> ApproveManPowerItem(string dept,string type)
        {
            CommonResponse res = new CommonResponse()
            {
                Error = false,
                Message = "",
                Status = (int)HttpStatusCode.BadRequest
            };
            try
            {
                var u = GetCurrentUser();
                //var version = context.MpManpowerTimes.FirstOrDefault(x => x.Active == true).Version;
                var model = await context.MpManpowerItems
                        .Where(x => x.TypePs == type && x.Active == true && x.ApprovedDate == null && x.ApprovedBy == null && x.RejectedBy == null && x.Dept.ToUpper() == dept.ToUpper())
                        .OrderBy(x => x.OrderNo)
                        .ToListAsync();
                if (model.Count == 0)
                {
                    res.Error = true;
                    res.Message = "Not have data wait approve of department!";
                    res.Status = (int)HttpStatusCode.BadRequest;
                    return res;
                }
                model.ForEach(x =>
                {
                    x.ApprovedBy = u.UserName;
                    x.ApprovedDate = DateTime.Now;

                });
                context.UpdateRange(model);
                context.SaveChanges();
                var user = context.AdmUserInformations.Where(x => x.Active == true && x.EmployeeCode == model.FirstOrDefault().CreatedBy).FirstOrDefault();
                var lstRecive = new List<string>() { user.Email };

                var link = "http://cvn-vpsi/#/manpower/plan/input-data/" + type;

                SendMailApproved(dept, u.FullName, lstRecive, user.FullName, link);
                res.Error = false;
                res.Message = "Successfully !";
                res.Status = (int)HttpStatusCode.OK;
                return res;
            }
            catch (Exception e)
            {
                res.Error = true;
                res.Message = e.Message;
                res.Status = (int)HttpStatusCode.BadRequest;
                //SendMailError(e);
                return res;
            }


        }
        [HttpPost("reject-manpower-item/{dept}/{type}")]
        public async Task<CommonResponse> RejectManPowerItem(string[]? reason, string dept, string type)
        {
            CommonResponse res = new CommonResponse()
            {
                Error = false,
                Message = "",
                Status = (int)HttpStatusCode.BadRequest
            };
            try
            {
                var u = GetCurrentUser();
                //var version = context.MpManpowerTimes.FirstOrDefault(x => x.Active == true).Version;
                var model = await context.MpManpowerItems
                        .Where(x => x.TypePs == type && x.Active == true && x.ApprovedDate == null && x.ApprovedBy == null && x.RejectedBy == null && x.Dept.ToUpper() == dept.ToUpper())
                        .OrderBy(x => x.OrderNo)
                        .ToListAsync();
                if (model.Count == 0)
                {
                    res.Error = true;
                    res.Message = "Not have data wait approve of department!";
                    res.Status = (int)HttpStatusCode.BadRequest;
                    return res;
                }

                model.ForEach(x =>
                {
                    x.RejectedBy = u.UserName;
                    x.RejectedDate = DateTime.Now;
                });
                context.UpdateRange(model);
                context.SaveChanges();

                var user = context.AdmUserInformations.Where(x => x.Active == true && x.EmployeeCode == model.FirstOrDefault().CreatedBy).FirstOrDefault();
                var lstRecive = new List<string>() { user.Email };
                var link = "http://cvn-vpsi/#/manpower/plan/input-data/" + type;
                SendMailRejectd(dept, reason[0], u.FullName, lstRecive, user.FullName, link);
                res.Error = false;
                res.Message = "Successfully !";
                res.Status = (int)HttpStatusCode.OK;
                return res;
            }
            catch (Exception e)
            {
                res.Error = true;
                res.Message = e.Message;
                res.Status = (int)HttpStatusCode.BadRequest;
                //SendMailError(e);
                return res;
            }


        }

        [HttpPost("update-op2-after-approve/{dept}/{type}")]
        public async Task<CommonResponse> UpdateOP2(string[] version, string dept,string type)
        {
            CommonResponse res = new CommonResponse()
            {
                Error = false,
                Message = "",
                Status = (int)HttpStatusCode.BadRequest
            };
            try
            {
                await UpdateOp2Task(version,dept,type);
                res.Error = false;
                res.Message = "Successfully !";
                res.Status = (int)HttpStatusCode.OK;
                return res;
            }
            catch (Exception e)
            {
                res.Error = true;
                res.Message = e.Message;
                res.Status = (int)HttpStatusCode.BadRequest;
                //SendMailError(e);
                return res;
            }


        }

        [HttpGet("update-op3-daily-after-approve/{dept}/{type}")]
        public async Task<CommonResponse> UpdateOP3Daily( string dept,string type)
        {
            CommonResponse res = new CommonResponse()
            {
                Error = false,
                Message = "",
                Status = (int)HttpStatusCode.BadRequest
            };
            try
            {
                await UpdateOp3DailyTask(dept, type);
                res.Error = false;
                res.Message = "Successfully !";
                res.Status = (int)HttpStatusCode.OK;
                return res;
            }
            catch (Exception e)
            {
                res.Error = true;
                res.Message = e.Message;
                res.Status = (int)HttpStatusCode.BadRequest;
                //SendMailError(e);
                return res;
            }
        }
        [HttpGet("update-op3-monthly-after-approve/{dept}/{type}")]
        public async Task<CommonResponse> UpdateOP3Monthly( string dept,string type)
        {
            CommonResponse res = new CommonResponse()
            {
                Error = false,
                Message = "",
                Status = (int)HttpStatusCode.BadRequest
            };
            try
            {
                await UpdateOp3MonthTask(dept, type);
                res.Error = false;
                res.Message = "Successfull!";
                res.Status = (int)HttpStatusCode.OK;
                return res;
            }
            catch (Exception e)
            {
                res.Error = true;
                res.Message = e.Message;
                res.Status = (int)HttpStatusCode.BadRequest;
                //SendMailError(e);
                return res;
            }
        }

        [HttpPost("update-op1-after-approve/{type}")]
        public async Task<CommonResponse> UpdateAllOPAfterApprove(string[] version,string type)
        {
            CommonResponse res = new CommonResponse()
            {
                Error = false,
                Message = "",
                Status = (int)HttpStatusCode.BadRequest
            };
            try
            {
                await UpdateOP1Task(version,type);
                res.Error = false;
                res.Message = "Successfull!";
                res.Status = (int)HttpStatusCode.OK;
                return res;

            }
            catch (Exception e)
            {
                res.Error = true;
                res.Message = e.Message;
                res.Status = (int)HttpStatusCode.BadRequest;
                //SendMailError(e);
                return res;
            }
        }
        //[HttpPost("excute-calc-output-1/{dept}/{type}")]
        //public async Task<CommonResponse> ExcuteCalcAllOuput(string[] version, string dept, string type)
        //{
        //    CommonResponse res = new CommonResponse()
        //    {
        //        Error = false,
        //        Message = "",
        //        Status = (int)HttpStatusCode.BadRequest
        //    };
        //    try
        //    {
        //        Task task1 = UpdateOP1Task(version, type);
        //        Task task2 = UpdateOp2Task(version, dept, type);
        //        Task task3 = UpdateOp3DailyTask(dept, type);
        //        Task task4 = UpdateOp3MonthTask(dept, type);
        //        await Task.WhenAll(task1, task2, task3, task4);
        //        var checkGroupReceive = context.AdmDetailUserGroups.Include(x => x.User).Where(x => x.Active == true && x.GroupId == new Guid("c33ffa8f-e9e9-4dd5-a73f-ab08d8f12819")).ToList();

        //        if (checkGroupReceive.Count > 0)
        //        {
        //            var link = "http://cvn-psi/#/manpower/output/op1";
        //            var lstReceiver = checkGroupReceive.Where(x => x.User.Active == true && x.User.Email != null && x.User.Email != "").Select(y => y.User.Email).ToList();
        //            SendMailDoneOutputMp(lstReceiver, link);
        //        }
        //        res.Error = false;
        //        res.Message = "Successfully !";
        //        res.Status = (int)HttpStatusCode.OK;
        //        return res;
        //    }
        //    catch (Exception e)
        //    {
        //        res.Error = true;
        //        res.Message = e.Message;
        //        res.Status = (int)HttpStatusCode.BadRequest;
        //        //SendMailError(e);
        //        return res;
        //    }


        //}
        
        [HttpPost("filter-manpower-op1-daily/{product}/{type}")]
        public async Task<MPItemView> FilterMPOP1Daily(string[] version, string type,string product)
        {
            try
            {
                var lstResult = new MPItemView();
                var query = await context.MpManpowerOp1Dailies.Where(x =>x.TypePs == type && x.Version == version[0] && x.Active == true && x.Product.ToUpper() == product.ToUpper()).OrderBy(x => x.OrderNo).ToListAsync();
                lstResult.LstDate = query.FirstOrDefault().Date.OrderBy(x => x).Select(x => x.ToString("yyyy-MM-dd")).ToList();
                lstResult.LstValue = new List<List<string>?>();
                foreach (var item in query)
                {
                    lstResult.LstValue.Add(item.Value.ToList());
                }
                return lstResult;
            }
            catch (Exception e)
            {
                //SendMailError(e);
                return new MPItemView();
            }
        }

        [HttpPost("filter-manpower-op1-weekly/{product}/{type}")]
        public async Task<MPItemView> FilterMPOP1Weekly(string[] version, string type,string product)
        {
            try
            {
                var lstResult = new MPItemView();
                var query = await context.MpManpowerOp1Weeklies.Where(x => x.TypePs == type && x.Version == version[0] && x.Active == true && x.Product.ToUpper() == product.ToUpper()).OrderBy(x => x.OrderNo).ToListAsync();


                lstResult.LstDate = query.FirstOrDefault().Date.OrderBy(x => x).Select(x => x.ToString("yyyy-MM-dd")).ToList();
                lstResult.LstValue = new List<List<string>?>();
                foreach (var item in query)
                {
                    lstResult.LstValue.Add(item.Value.ToList());
                }
                return lstResult;
            }
            catch (Exception e)
            {
                //SendMailError(e);
                return new MPItemView();
            }
        }

        [HttpPost("filter-manpower-op1-monthly/{product}/{type}")]
        public async Task<MPItemView> FilterMPOP1Monthly(string[] version, string type,string product)
        {
            try
            {
                var lstResult = new MPItemView();
                var query = await context.MpManpowerOp1Monthlies.Where(x => x.TypePs == type && x.Version == version[0] && x.Active == true && x.Product.ToUpper() == product.ToUpper()).OrderBy(x => x.OrderNo).ToListAsync();

                lstResult.LstDate = query.FirstOrDefault().Date.OrderBy(x => x).Select(x => x.ToString("yyyy-MM-dd")).ToList();
                lstResult.LstValue = new List<List<string>?>();
                foreach (var item in query)
                {
                    lstResult.LstValue.Add(item.Value.ToList());
                }
                return lstResult;
            }
            catch (Exception e)
            {
                //SendMailError(e);
                return new MPItemView();
            }
        }

        [HttpPost("filter-manpower-op2-daily/{product}/{type}")]
        public async Task<List<MPOp2View>> FilterMPOP2Daily(string[] version, string type,string product)
        {
            try
            {
                var lstResult = new List<MPOp2View>();

                var query = await context.MpManpowerOp2Dailies.Where(x => x.TypePs == type && x.Version == version[0] && x.Active == true && x.Product.ToUpper() == product.ToUpper()).OrderBy(x => x.Dept).ToListAsync();
                var maxDate = query.Max(x => x.Date.Length);
                var dateCommon = query.FirstOrDefault(x => x.Date.Length == maxDate).Date.ToList();
                // var valCommon = dateCommon.Select(x => "").ToList();
                foreach (var item in query)
                {
                    var dateCheck = item.Date.ToList();
                    var lstVal = dateCommon.Select(x => "").ToList();
                    foreach (var date in dateCommon)
                    {
                        var index = dateCheck.IndexOf(date);
                        if (index != -1)
                        {
                            lstVal[index] = item.Value[index];
                        }

                    }

                    lstResult.Add(new MPOp2View
                    {
                        Dept = item.Dept,
                        LstDate = dateCommon.OrderBy(x => x).Select(x => x.ToString("yyyy-MM-dd")).ToList(),
                        LstValue = lstVal
                    });
                }
                return lstResult;
            }
            catch (Exception e)
            {
                //SendMailError(e);
                return new List<MPOp2View>();
            }
        }
        [HttpPost("filter-manpower-op2-weekly/{product}/{type}")]
        public async Task<List<MPOp2View>> FilterMPOP2Weekly(string[] version, string type,string product)
        {
            try
            {
                var lstResult = new List<MPOp2View>();
                var query = await context.MpManpowerOp2Weeklies.Where(x => x.TypePs == type && x.Version == version[0] && x.Active == true && x.Product.ToUpper() == product.ToUpper()).OrderBy(x => x.Dept).ToListAsync();
                var maxDate = query.Max(x => x.Date.Length);
                var dateCommon = query.FirstOrDefault(x => x.Date.Length == maxDate).Date.ToList();
                // var valCommon = dateCommon.Select(x => "").ToList();
                foreach (var item in query)
                {
                    var dateCheck = item.Date.ToList();
                    var lstVal = dateCommon.Select(x => "").ToList();
                    foreach (var date in dateCommon)
                    {
                        var index = dateCheck.IndexOf(date);
                        if (index != -1)
                        {
                            lstVal[index] = item.Value[index];
                        }

                    }

                    lstResult.Add(new MPOp2View
                    {
                        Dept = item.Dept,
                        LstDate = dateCommon.OrderBy(x => x).Select(x => x.ToString("yyyy-MM-dd")).ToList(),
                        LstValue = lstVal
                    });
                }
                return lstResult;
            }
            catch (Exception e)
            {
                //SendMailError(e);
                return new List<MPOp2View>();
            }
        }
        [HttpPost("filter-manpower-op2-monthly/{product}/{type}")]
        public async Task<List<MPOp2View>> FilterMPOP2Monthly(string[] version, string type,string product)
        {
            try
            {
                var lstResult = new List<MPOp2View>();
                var query = await context.MpManpowerOp2Monthlies.Where(x => x.TypePs == type && x.Version == version[0] && x.Active == true && x.Product.ToUpper() == product.ToUpper()).OrderBy(x => x.Dept).ToListAsync();
                var maxDate = query.Max(x => x.Date.Length);
                var dateCommon = query.FirstOrDefault(x => x.Date.Length == maxDate).Date.ToList();
                // var valCommon = dateCommon.Select(x => "").ToList();
                foreach (var item in query)
                {
                    var dateCheck = item.Date.ToList();
                    var lstVal = dateCommon.Select(x => "").ToList();
                    foreach (var date in dateCommon)
                    {
                        var index = dateCheck.IndexOf(date);
                        if (index != -1)
                        {
                            lstVal[index] = item.Value[index];
                        }

                    }

                    lstResult.Add(new MPOp2View
                    {
                        Dept = item.Dept,
                        LstDate = dateCommon.OrderBy(x => x).Select(x => x.ToString("yyyy-MM-dd")).ToList(),
                        LstValue = lstVal
                    });
                }
                return lstResult;
            }
            catch (Exception e)
            {
                //SendMailError(e);
                return new List<MPOp2View>();
            }
        }

        [HttpGet("filter-manpower-op3-daily/{type}")]
        public async Task<List<MPOp3View>> FilterMPOP3Daily( string type)
        {
            try
            {
                var lstResult = new List<MPOp3View>();
                var query = await context.MpManpowerOp3Dailies.Where(x => x.TypePs == type && x.Active == true).OrderBy(x => x.Dept).ToListAsync();
                var maxDate = query.Max(x => x.Date.Length);
                var dateCommon = query.FirstOrDefault(x => x.Date.Length == maxDate).Date.ToList();
                //var valCommon = dateCommon.Select(x => "").ToList();
                foreach (var item in query)
                {
                    for (int i = 0; i <= 2; i++)
                    {
                        var dateCheck = item.Date.ToList();
                        var lstVal = dateCommon.Select(x => "").ToList();
                        foreach (var date in dateCommon)
                        {
                            var index = dateCheck.IndexOf(date);
                            if (index != -1)
                            {
                                lstVal[index] = i == 0 ? item.PlanValue[index] : (i == 1 ? item.ActualValue[index] : item.DifferValue[index]);
                            }

                        }
                        lstResult.Add(new MPOp3View
                        {
                            Dept = item.Dept,
                            LstDate = dateCommon.OrderBy(x => x).Select(x => x.ToString("yyyy-MM-dd")).ToList(),
                            LstValue = lstVal,
                            Order = i,
                            Type = i == 0 ? "Plan" : (i == 1 ? "Actual" : "Differ")
                        });
                    }

                }
                return lstResult;
            }
            catch (Exception e)
            {
                //SendMailError(e);
                return new List<MPOp3View>();
            }
        }

        [HttpGet("filter-manpower-op3-monthly/{dept}/{product}/{type}")]
        [AllowAnonymous]
        public async Task<List<MPOp3View>> FilterMPOP3Monthly(string type,string? dept, string? product)
        {
            try
            {
                var lstResult = new List<MPOp3View>();
                var query = await context.MpManpowerOp3Monthlies.Where(x => x.TypePs == type && x.Active == true).OrderBy(x => x.OrderNo).ToListAsync();
                int j = 0;
                if (product.ToUpper() != "ALL")
                {
                    if (dept.ToUpper() != "ALL")
                    {
                        query = query.Where(x => x.Dept.ToUpper() == dept.ToUpper() && x.Product.ToUpper() == product.ToUpper()).ToList();
                        var date = query.FirstOrDefault(x => x.Type == "Differ").Date;
                        foreach (var item in query.Where(x => x.Type == "New").ToList())
                        {
                            var lstValue = new List<string>();
                            foreach (var month in date)
                            {
                                var index = item.Date.ToList().IndexOf(month);
                                if (index == -1)
                                {
                                    lstValue.Add("");
                                }
                                else
                                {
                                    lstValue.Add(item.Value[index]);
                                }

                            }
                            lstResult.Add(new MPOp3View
                            {
                                Order = item.OrderNo,
                                Type = item.Type,
                                LstDate = date.OrderBy(x => x).Select(x => x.ToString()).ToList(),
                                LstValue = lstValue
                            });

                        }
                        if (query.Where(x => x.Type == "Old").ToList().Count > 0)
                        {
                            foreach (var item in query.Where(x => x.Type == "Old").ToList())
                            {
                                lstResult.Add(new MPOp3View
                                {
                                    Order = item.OrderNo,
                                    Type = item.Type,
                                    LstDate = date.OrderBy(x => x).Select(x => x.ToString()).ToList(),
                                    LstValue = item.Value.ToList()
                                });
                            }
                        }
                        else
                        {
                            foreach (var item in query.Where(x => x.Type == "New").ToList())
                            {
                                lstResult.Add(new MPOp3View
                                {
                                    Order = item.OrderNo,
                                    Type = "Old",
                                    LstDate = date.OrderBy(x => x).Select(x => x.ToString()).ToList(),
                                    LstValue = item.Value.Select(x => "").ToList()
                                });
                            }
                        }

                        foreach (var item in query.Where(x => x.Type == "Differ").ToList())
                        {
                            lstResult.Add(new MPOp3View
                            {
                                Order = item.OrderNo,
                                Type = item.Type,
                                LstDate = date.OrderBy(x => x).Select(x => x.ToString()).ToList(),
                                LstValue = item.Value.ToList()
                            });

                        }
                    }
                    else
                    {
                        query = query.Where(x => x.Product.ToUpper() == product.ToUpper()).ToList();
                        var maxDate = query.Max(x => x.Date.Length);
                        var date = query.FirstOrDefault(x => x.Type == "Differ" && x.Date.Length == maxDate).Date;
                        //add for new
                        for (int i = 0; i <= 14; i++)
                        {
                            var lstItem = query.Where(x => x.OrderNo == i && x.Type == "New").ToList();
                            var lstValue = new List<List<string>>();
                            foreach (var item in lstItem)
                            {
                                var values = new List<string>();
                                foreach (var month in date)
                                {
                                    var index = item.Date.ToList().IndexOf(month);
                                    if (index == -1)
                                    {
                                        values.Add("");
                                    }
                                    else
                                    {
                                        values.Add(item.Value[index]);
                                    }
                                }
                                lstValue.Add(values);
                            }
                            lstResult.Add(new MPOp3View
                            {
                                Order = i,
                                Type = lstItem.First().Type,
                                LstDate = date.OrderBy(x => x).Select(x => x.ToString()).ToList(),
                                LstValue = SumArrays(lstValue)
                            });

                        }

                        //add for Old
                        for (int i = 0; i <= 14; i++)
                        {
                            var lstItem = query.Where(x => x.OrderNo == i && x.Type == "Old").ToList();
                            var lstValue = new List<List<string>>();
                            if (lstItem.Count > 0)
                            {
                                foreach (var item in lstItem)
                                {
                                    var values = new List<string>();
                                    foreach (var month in date)
                                    {
                                        var index = item.Date.ToList().IndexOf(month);
                                        if (index == -1)
                                        {
                                            values.Add("");
                                        }
                                        else
                                        {
                                            values.Add(item.Value[index]);
                                        }
                                    }
                                    lstValue.Add(values);
                                }
                                lstResult.Add(new MPOp3View
                                {
                                    Order = i,
                                    Type = lstItem.First().Type,
                                    LstDate = date.OrderBy(x => x).Select(x => x.ToString()).ToList(),
                                    LstValue = SumArrays(lstValue)
                                });
                            }
                            else
                            {
                                var item = lstResult.FirstOrDefault(x => x.Order == i);
                                lstResult.Add(new MPOp3View
                                {
                                    Order = i,
                                    Type = item.Type,
                                    LstDate = date.OrderBy(x => x).Select(x => x.ToString()).ToList(),
                                    LstValue = date.Select(x => "").ToList()
                                });
                            }
                        }

                        //add for Differ
                        for (int i = 0; i <= 14; i++)
                        {
                            var lstItem = query.Where(x => x.OrderNo == i && x.Type == "Differ").ToList();
                            var lstValue = new List<List<string>>();
                            foreach (var item in lstItem)
                            {
                                var values = new List<string>();
                                foreach (var month in date)
                                {
                                    var index = item.Date.ToList().IndexOf(month);
                                    if (index == -1)
                                    {
                                        values.Add("");
                                    }
                                    else
                                    {
                                        values.Add(item.Value[index]);
                                    }
                                }
                                lstValue.Add(values);
                            }
                            lstResult.Add(new MPOp3View
                            {
                                Order = i,
                                Type = lstItem.First().Type,
                                LstDate = date.OrderBy(x => x).Select(x => x.ToString()).ToList(),
                                LstValue = SumArrays(lstValue)
                            });

                        }
                    }
                }
                else
                {
                    if (dept.ToUpper() != "ALL")
                    {
                        query = query.Where(x => x.Dept.ToUpper() == dept.ToUpper()).ToList();
                        var maxDate = query.Max(x => x.Date.Length);
                        var date = query.FirstOrDefault(x => x.Type == "Differ" && x.Date.Length == maxDate).Date;
                        //add for new
                        for (int i = 0; i <= 14; i++)
                        {
                            var lstItem = query.Where(x => x.OrderNo == i && x.Type == "New").ToList();
                            var lstValue = new List<List<string>>();
                            foreach (var item in lstItem)
                            {
                                var values = new List<string>();
                                foreach (var month in date)
                                {
                                    var index = item.Date.ToList().IndexOf(month);
                                    if (index == -1)
                                    {
                                        values.Add("");
                                    }
                                    else
                                    {
                                        values.Add(item.Value[index]);
                                    }
                                }
                                lstValue.Add(values);
                            }
                            lstResult.Add(new MPOp3View
                            {
                                Order = i,
                                Type = lstItem.First().Type,
                                LstDate = date.OrderBy(x => x).Select(x => x.ToString()).ToList(),
                                LstValue = SumArrays(lstValue)
                            });

                        }
                        //add for Old
                        for (int i = 0; i <= 14; i++)
                        {
                            var lstItem = query.Where(x => x.OrderNo == i && x.Type == "Old").ToList();
                            var lstValue = new List<List<string>>();
                            if (lstItem.Count > 0)
                            {
                                foreach (var item in lstItem)
                                {
                                    var values = new List<string>();
                                    foreach (var month in date)
                                    {
                                        var index = item.Date.ToList().IndexOf(month);
                                        if (index == -1)
                                        {
                                            values.Add("");
                                        }
                                        else
                                        {
                                            values.Add(item.Value[index]);
                                        }
                                    }
                                    lstValue.Add(values);
                                }
                                lstResult.Add(new MPOp3View
                                {
                                    Order = i,
                                    Type = lstItem.First().Type,
                                    LstDate = date.OrderBy(x => x).Select(x => x.ToString()).ToList(),
                                    LstValue = SumArrays(lstValue)
                                });
                            }
                            else
                            {
                                var item = lstResult.FirstOrDefault(x => x.Order == i);
                                lstResult.Add(new MPOp3View
                                {
                                    Order = i,
                                    Type = item.Type,
                                    LstDate = date.OrderBy(x => x).Select(x => x.ToString()).ToList(),
                                    LstValue = date.Select(x => "").ToList()
                                });
                            }
                        }

                        //add for Differ
                        for (int i = 0; i <= 14; i++)
                        {
                            var lstItem = query.Where(x => x.OrderNo == i && x.Type == "Differ").ToList();
                            var lstValue = new List<List<string>>();
                            foreach (var item in lstItem)
                            {
                                var values = new List<string>();
                                foreach (var month in date)
                                {
                                    var index = item.Date.ToList().IndexOf(month);
                                    if (index == -1)
                                    {
                                        values.Add("");
                                    }
                                    else
                                    {
                                        values.Add(item.Value[index]);
                                    }
                                }
                                lstValue.Add(values);
                            }
                            lstResult.Add(new MPOp3View
                            {
                                Order = i,
                                Type = lstItem.First().Type,
                                LstDate = date.OrderBy(x => x).Select(x => x.ToString()).ToList(),
                                LstValue = SumArrays(lstValue)
                            });

                        }
                    }
                    else
                    {
                        var maxDate = query.Max(x => x.Date.Length);
                        var date = query.FirstOrDefault(x => x.Type == "Differ" && x.Date.Length == maxDate).Date;
                        //add for new
                        for (int i = 0; i <= 14; i++)
                        {
                            var lstItem = query.Where(x => x.OrderNo == i && x.Type == "New").ToList();
                            var lstValue = new List<List<string>>();
                            foreach (var item in lstItem)
                            {
                                var values = new List<string>();
                                foreach (var month in date)
                                {
                                    var index = item.Date.ToList().IndexOf(month);
                                    if (index == -1)
                                    {
                                        values.Add("");
                                    }
                                    else
                                    {
                                        values.Add(item.Value[index]);
                                    }
                                }
                                lstValue.Add(values);
                            }
                            lstResult.Add(new MPOp3View
                            {
                                Order = i,
                                Type = lstItem.First().Type,
                                LstDate = date.OrderBy(x => x).Select(x => x.ToString()).ToList(),
                                LstValue = SumArrays(lstValue)
                            });

                        }

                        //add for Old
                        for (int i = 0; i <= 14; i++)
                        {
                            var lstItem = query.Where(x => x.OrderNo == i && x.Type == "Old").ToList();
                            var lstValue = new List<List<string>>();
                            if (lstItem.Count > 0)
                            {
                                foreach (var item in lstItem)
                                {
                                    var values = new List<string>();
                                    foreach (var month in date)
                                    {
                                        var index = item.Date.ToList().IndexOf(month);
                                        if (index == -1)
                                        {
                                            values.Add("");
                                        }
                                        else
                                        {
                                            values.Add(item.Value[index]);
                                        }
                                    }
                                    lstValue.Add(values);
                                }
                                lstResult.Add(new MPOp3View
                                {
                                    Order = i,
                                    Type = lstItem.First().Type,
                                    LstDate = date.OrderBy(x => x).Select(x => x.ToString()).ToList(),
                                    LstValue = SumArrays(lstValue)
                                });
                            }
                            else
                            {
                                var item = lstResult.FirstOrDefault(x => x.Order == i);
                                lstResult.Add(new MPOp3View
                                {
                                    Order = i,
                                    Type = item.Type,
                                    LstDate = date.OrderBy(x => x).Select(x => x.ToString()).ToList(),
                                    LstValue = date.Select(x => "").ToList()
                                });
                            }
                        }

                        //add for Differ
                        for (int i = 0; i <= 14; i++)
                        {
                            var lstItem = query.Where(x => x.OrderNo == i && x.Type == "Differ").ToList();
                            var lstValue = new List<List<string>>();
                            foreach (var item in lstItem)
                            {
                                var values = new List<string>();
                                foreach (var month in date)
                                {
                                    var index = item.Date.ToList().IndexOf(month);
                                    if (index == -1)
                                    {
                                        values.Add("");
                                    }
                                    else
                                    {
                                        values.Add(item.Value[index]);
                                    }
                                }
                                lstValue.Add(values);
                            }
                            lstResult.Add(new MPOp3View
                            {
                                Order = i,
                                Type = lstItem.First().Type,
                                LstDate = date.OrderBy(x => x).Select(x => x.ToString()).ToList(),
                                LstValue = SumArrays(lstValue)
                            });

                        }
                    }
                }


                return lstResult;
            }
            catch (Exception e)
            {
                //SendMailError(e);
                return new List<MPOp3View>();
            }
        }

        [HttpPost("filter-manpower-op4-weekly/{product}/{type}")]
        public async Task<MPOp4View> FilterMPOP4Weekly(string[] version, string type, string product)
        {
            try
            {
                var lstResult = new MPOp4View();
                var query = await context.MpManpowerOp1Weeklies.Where(x => x.Version == version[0] && x.TypePs == type && x.Active == true && x.Product == product.ToUpper()).ToListAsync();

                foreach (var item in query)
                {
                    if (item.OrderNo == 0)
                    {
                        lstResult.LstDate = item.Date.Select(x => x.ToString("yyyy-MM-dd")).ToList();
                    }
                    if (item.OrderNo == 4)
                    {
                        lstResult.WorkloadValue = item.Value.Select(x => x.StringAbleToDouble()).ToList();
                    }
                    if (item.OrderNo == 31)
                    {
                        lstResult.CvnValue = item.Value.Select(x => x.StringAbleToDouble()).ToList();
                    }
                    if (item.OrderNo == 48)
                    {
                        lstResult.VcValue = item.Value.Select(x => x.StringAbleToDouble()).ToList();
                    }
                    if (item.OrderNo == 66)
                    {
                        lstResult.StValue = item.Value.Select(x => x.StringAbleToDouble()).ToList();
                    }

                }
                return lstResult;
            }
            catch (Exception e)
            {
                //SendMailError(e);
                return new MPOp4View();
            }
        }

        [HttpPost("filter-manpower-op4-monthly/{product}/{type}")]
        public async Task<MPOp4View> FilterMPOP4Monthly(string[] version, string type, string product)
        {
            try
            {
                var lstResult = new MPOp4View();
                var query = await context.MpManpowerOp1Monthlies.Where(x => x.Version == version[0] && x.TypePs == type && x.Active == true && x.Product == product.ToUpper()).ToListAsync();

                foreach (var item in query)
                {
                    if (item.OrderNo == 0)
                    {
                        lstResult.LstDate = item.Date.Select(x => x.ToString("yyyy-MM-dd")).ToList();
                    }
                    if (item.OrderNo == 4)
                    {
                        lstResult.WorkloadValue = item.Value.Select(x => x.StringAbleToDouble()).ToList();
                    }
                    if (item.OrderNo == 31)
                    {
                        lstResult.CvnValue = item.Value.Select(x => x.StringAbleToDouble()).ToList();
                    }
                    if (item.OrderNo == 48)
                    {
                        lstResult.VcValue = item.Value.Select(x => x.StringAbleToDouble()).ToList();
                    }
                    if (item.OrderNo == 66)
                    {
                        lstResult.StValue = item.Value.Select(x => x.StringAbleToDouble()).ToList();
                    }

                }
                return lstResult;
            }
            catch (Exception e)
            {
                //SendMailError(e);
                return new MPOp4View();
            }
        }

        [HttpGet("filter-manpower-op5/{time}/{type}/{typeps}")]
        public async Task<MPOp5View> FilterMPOP5(string? time, string? type, string? typeps)
        {
            try
            {
                var lstResult = new MPOp5View();
                var query = await context.MpManpowerOp3Monthlies.Where(x => x.TypePs == typeps && x.Active == true && x.Type == "New").ToListAsync();
                var lstDept = query.Select(x => x.Dept).OrderBy(x => x).Distinct().ToList();
                var date = DateOnly.Parse(time);
                var resultDept = new List<string>();
                //value chart pie
                var resultValuePie = new List<double>();
                //value chart bar
                var resultValueBar = new List<double>();
                foreach (var item in lstDept)
                {
                    resultDept.Add(item);
                    var dataDept = query.Where(x => x.Dept.ToUpper() == item.ToUpper()).ToList();
                    var dataWKL = dataDept.FirstOrDefault(x => x.OrderNo == 0);
                    var indexWKL = dataWKL.Date.ToList().IndexOf(date);
                    if (type == "Resign")
                    {
                        double val = 0;
                        double valWKl = 0;
                        for (int i = 1; i <= 3; i++)
                        {
                            var data = dataDept.Where(x => x.OrderNo == i);
                            foreach (var product in data)
                            {
                                var index = product.Date.ToList().IndexOf(date);
                                if (index != -1)
                                {
                                    val = val + product.Value[index].StringAbleToDouble();
                                }
                            }
                        }
                        resultValuePie.Add(Math.Round(val, 1));
                        resultValueBar.Add(indexWKL == -1 ? 0 : (dataWKL.Value[indexWKL].StringAbleToDouble() == 0 ? 0 : Math.Round(((val / dataWKL.Value[indexWKL].StringAbleToDouble()) * 100), 1)));
                    }
                    else if (type == "Contract end")
                    {
                        double val = 0;
                        double valWKl = 0;
                        for (int i = 4; i <= 6; i++)
                        {
                            var data = dataDept.Where(x => x.OrderNo == i);
                            foreach (var product in data)
                            {
                                var index = product.Date.ToList().IndexOf(date);
                                if (index != -1)
                                {
                                    val = val + product.Value[index].StringAbleToDouble();
                                }
                            }
                        }
                        resultValuePie.Add(Math.Round(val, 1));
                        resultValueBar.Add(indexWKL == -1 ? 0 : (dataWKL.Value[indexWKL].StringAbleToDouble() == 0 ? 0 : Math.Round(((val / dataWKL.Value[indexWKL].StringAbleToDouble()) * 100), 1)));

                    }
                    else if (type == "Ratio")
                    {
                        double val = 0;
                        double valWKl = 0;

                        var data = dataDept.Where(x => x.OrderNo == 7);
                        foreach (var product in data)
                        {
                            var index = product.Date.ToList().IndexOf(date);
                            if (index != -1)
                            {
                                val = val + product.Value[index].StringAbleToDouble();
                            }
                        }

                        resultValuePie.Add(Math.Round(val, 1));
                        resultValueBar.Add(indexWKL == -1 ? 0 : (dataWKL.Value[indexWKL].StringAbleToDouble() == 0 ? 0 : Math.Round(((val / dataWKL.Value[indexWKL].StringAbleToDouble()) * 100), 1)));
                    }
                }
                lstResult.LstLabel = lstDept;
                lstResult.LstValuePie = resultValuePie;
                lstResult.LstValueBar = resultValueBar;

                return lstResult;
            }
            catch (Exception e)
            {
                //SendMailError(e);
                return new MPOp5View();
            }
        }

        [HttpPost("send-mail-registration-manpower")]
        public CommonResponse SendMailRegistrationManpower(string[] param)
        {
            CommonResponse res = new CommonResponse()
            {
                Error = false,
                Message = "",
                Status = (int)HttpStatusCode.BadRequest
            };
            try
            {

                //get deadline
                var deadline = context.MpManpowerTimes.FirstOrDefault(x => x.Active == true);
                //check all member group pic manpower
                var checkApprovalDept = context.AdmDetailUserGroups.Include(x => x.User).Where(x => x.Active == true && x.GroupId == new Guid("fc67970f-201f-4f67-905d-61533eb50c69")).ToList();

                if (checkApprovalDept.Count > 0)
                {
                    var link = "http://cvn-vpsi/#/manpower/plan/input-data";
                    var lstReceiver = checkApprovalDept.Where(x => x.User.Active == true && x.User.Email != null && x.User.Email != "").Select(y => y.User.Email).ToList();
                    SendMailRemind(deadline.From.Value.ToString("yyyy-MMM-dd"), deadline.To.Value.ToString("yyyy-MMM-dd"), lstReceiver, link, param[0], deadline.Version);
                }

                res.Error = false;
                res.Message = "Successfull!";
                res.Status = (int)HttpStatusCode.OK;

            }
            catch (Exception e)
            {
                res.Error = true;
                res.Message = e.Message;
                res.Status = (int)HttpStatusCode.BadRequest;
            }
            return res;
        }

        [HttpGet("filter-manpower-version/{type}")]
        public List<Version> FilterMPOP1Version(string? type)
        {
            var lstResult = new List<Version>();
            var model = context.MpManpowerItems
                        .Where(x => x.TypePs == type && x.ApprovedDate != null && x.ApprovedBy != null)
                        .OrderByDescending(x => x.CreatedDate)
                        .Select(x => x.Version).Distinct().ToList();
            foreach (var item in model)
            {
                lstResult.Add(new Version
                {
                    VersionPs = item
                });
            }
            return lstResult;        
        }
        #endregion


        //[HttpPost("import-RecruimentDeptPlan")]
        //public async Task<CommonResponse> ImportRecruimentDeptPlan(string model, string periodId, [FromForm] RecPlanParam data)
        //{
        //    var result = new CommonResponse()
        //    {
        //        Error = false,
        //        Message = "",
        //        Status = (int)HttpStatusCode.BadRequest
        //    };
        //    try
        //    {
        //        var u = GetCurrentUser();
        //        var lstDeptRec = await context.MpRecMasterDepts.Where(x => x.Active == true).Select(x => x.DeptName.ToUpper()).ToListAsync();
        //        if (!lstDeptRec.Contains(data.dept.ToUpper()))
        //        {
        //            result.Message = "Wrong dept name !";
        //            result.Error = true;
        //            result.Status = 400;
        //            return result;
        //        }
        //        var period = await context.MpRecMasterPeriods.Where(x => x.Id == Guid.Parse(periodId)).FirstAsync();
        //        var dateFrom = period.DateFrom;
        //        var dateTo = period.DateTo;
        //        using (var memoStream = new MemoryStream())
        //        {
        //            data.file.CopyTo(memoStream);
        //            ExcelPackage.LicenseContext = LicenseContext.NonCommercial;
        //            using (var package = new ExcelPackage(memoStream))
        //            {
        //                var worksheet = package.Workbook.Worksheets[0];
        //                if (worksheet.Name != "Input 2")
        //                {
        //                    result.Message = "Wrong sheet name !";
        //                    result.Error = true;
        //                    result.Status = 400;
        //                    return result;
        //                }
        //                var rowCount = worksheet.Dimension?.Rows;
        //                var colCount = worksheet.Dimension?.Columns;

        //                if (colCount != 6)
        //                {
        //                    result.Message = "Wrong format in columns number !";
        //                    result.Error = true;
        //                    result.Status = 400;
        //                    return result;
        //                }
        //                var modelInSheet = worksheet.Cells["C1"].Value.ObjToStringAble().Trim();
        //                if (modelInSheet.ToUpper() != model.ToUpper())
        //                {
        //                    result.Message = "Wrong model !";
        //                    result.Error = true;
        //                    result.Status = 400;
        //                    return result;
        //                }
        //                var lstDateOnly = new List<DateOnly>();
        //                var lstFemale = new List<int>();
        //                var lstMale = new List<int>();
        //                var lstVoca = new List<int>();
        //                var lstExplanation = new List<string>();
        //                if (rowCount.HasValue && rowCount.Value > 4 && rowCount.Value > 5)
        //                {
        //                    for (int row = 4; row <= rowCount.Value; row++)
        //                    {
        //                        try
        //                        {
        //                            var recDate = worksheet.Cells["A" + row].Value.ObjToDateonlyAble();
        //                            if (recDate == null)
        //                            {
        //                                continue;
        //                            }
        //                            else if (recDate < dateFrom || recDate > dateTo)
        //                            {
        //                                continue;
        //                            }
        //                            var femaleValue = worksheet.Cells["C" + row].Value.ObjToIntAble();
        //                            var maleValue = worksheet.Cells["D" + row].Value.ObjToIntAble();
        //                            var vocaValue = worksheet.Cells["E" + row].Value.ObjToIntAble();
        //                            var explanation = worksheet.Cells["F" + row].Value.ObjToStringAble();
        //                            lstDateOnly.Add(recDate.Value);
        //                            lstFemale.Add(femaleValue);
        //                            lstMale.Add(maleValue);
        //                            lstVoca.Add(vocaValue);
        //                            lstExplanation.Add(explanation);
        //                        }
        //                        catch (Exception)
        //                        {
        //                            continue;
        //                        }


        //                    }
        //                    if (lstDateOnly.Count == lstFemale.Count && lstMale.Count == lstExplanation.Count && lstFemale.Count == lstMale.Count)
        //                    {
        //                        var checkExist = context.MpRecDeptPlanIp2s.FirstOrDefault(x => x.Active == true && x.PeriodId == Guid.Parse(periodId) && x.DeptName.Equals(data.dept) && x.Model.Equals(model));
        //                        if (checkExist != null)
        //                        {
        //                            checkExist.ModifiedBy = u.UserName;
        //                            checkExist.ModifiedDate = DateTime.Now.SetKindUtc();
        //                            checkExist.RecDate = lstDateOnly.ToArray();
        //                            checkExist.RecExplain = lstExplanation.ToArray();
        //                            checkExist.RecPlanF = lstFemale.ToArray();
        //                            checkExist.RecPlanM = lstMale.ToArray();
        //                            checkExist.RecPlanVc = lstVoca.ToArray();
        //                            context.MpRecDeptPlanIp2s.Update(checkExist);
        //                        }
        //                        else
        //                        {
        //                            var md = new MpRecDeptPlanIp2()
        //                            {
        //                                Active = true,
        //                                CreatedBy = u.UserName,
        //                                DeptName = data.dept,
        //                                Model = model,
        //                                RecDate = lstDateOnly.ToArray(),
        //                                RecExplain = lstExplanation.ToArray(),
        //                                RecPlanF = lstFemale.ToArray(),
        //                                RecPlanM = lstMale.ToArray(),
        //                                RecPlanVc = lstVoca.ToArray(),
        //                                PeriodId = Guid.Parse(periodId)
        //                            };
        //                            context.MpRecDeptPlanIp2s.Add(md);
        //                        }
        //                        context.SaveChanges();
        //                    }
        //                }



        //            }
        //        }


        //        result.Status = (int)HttpStatusCode.OK;
        //        result.Message = "Success";
        //        result.Error = false;
        //        return result;
        //    }
        //    catch (Exception e)
        //    {
        //        result.Status = (int)HttpStatusCode.BadRequest;
        //        result.Message = e.Message;
        //        result.Error = true;
        //        return result;
        //    }
        //}
        [HttpPost("import-RecruimentDeptPlan")]
        public async Task<CommonResponse> ImportRecruimentDeptPlan(string model, string periodId, [FromForm] RecPlanParam data)
        {
            var result = new CommonResponse()
            {
                Error = false,
                Message = "",
                Status = (int)HttpStatusCode.BadRequest
            };
            try
            {
                var checkList = context.MpRecDeptPlanIp2s.Where(x => x.Status == 1 && x.Active == true && x.PeriodId == Guid.Parse(periodId) && x.DeptName.Equals(data.dept) && x.Model.Equals(model)).ToList();
                if(checkList.Count() > 0)
                {
                    result.Status = (int)HttpStatusCode.BadRequest;
                    result.Message = "There are pending data so you can't upload";
                    result.Error = true;
                    return result;
                }
                else
                {
                    var checkListFinish = context.MpRecDeptPlanIp2s.Where(x => x.Status == 2 && x.Active == true && x.PeriodId == Guid.Parse(periodId) && x.DeptName.Equals(data.dept) && x.Model.Equals(model)).ToList();
                    checkListFinish.ForEach(x => x.Status = 0);

                    var u = GetCurrentUser();
                    var lstDeptRec = await context.MpRecMasterDepts.Where(x => x.Active == true).Select(x => x.DeptName.ToUpper()).ToListAsync();
                    if (!lstDeptRec.Contains(data.dept.ToUpper()))
                    {
                        result.Message = "Wrong dept name !";
                        result.Error = true;
                        result.Status = 400;
                        return result;
                    }
                    var period = await context.MpRecMasterPeriods.Where(x => x.Id == Guid.Parse(periodId)).FirstAsync();
                    var dateFrom = period.DateFrom;
                    var dateTo = period.DateTo;
                    using (var memoStream = new MemoryStream())
                    {
                        data.file.CopyTo(memoStream);
                        ExcelPackage.LicenseContext = LicenseContext.NonCommercial;
                        using (var package = new ExcelPackage(memoStream))
                        {
                            var worksheet = package.Workbook.Worksheets[0];
                            if (worksheet.Name != "Input 2")
                            {
                                result.Message = "Wrong sheet name !";
                                result.Error = true;
                                result.Status = 400;
                                return result;
                            }
                            var rowCount = worksheet.Dimension?.Rows;
                            var colCount = worksheet.Dimension?.Columns;

                            if (colCount != 6)
                            {
                                result.Message = "Wrong format in columns number !";
                                result.Error = true;
                                result.Status = 400;
                                return result;
                            }
                            var modelInSheet = worksheet.Cells["C1"].Value.ObjToStringAble().Trim();
                            if (modelInSheet.ToUpper() != model.ToUpper())
                            {
                                result.Message = "Wrong model !";
                                result.Error = true;
                                result.Status = 400;
                                return result;
                            }
                            var lstDateOnly = new List<DateOnly>();
                            var lstFemale = new List<int>();
                            var lstMale = new List<int>();
                            var lstVoca = new List<int>();
                            var lstExplanation = new List<string>();
                            if (rowCount.HasValue && rowCount.Value > 4 && rowCount.Value > 5)
                            {
                                for (int row = 4; row <= rowCount.Value; row++)
                                {
                                    try
                                    {
                                        var recDate = worksheet.Cells["A" + row].Value.ObjToDateonlyAble();
                                        if (recDate == null)
                                        {
                                            continue;
                                        }
                                        else if (recDate < dateFrom || recDate > dateTo)
                                        {
                                            continue;
                                        }
                                        var femaleValue = worksheet.Cells["C" + row].Value.ObjToIntAble();
                                        var maleValue = worksheet.Cells["D" + row].Value.ObjToIntAble();
                                        //var vocaValue = worksheet.Cells["E" + row].Value.ObjToIntAble();
                                        var explanation = worksheet.Cells["E" + row].Value.ObjToStringAble();
                                        lstDateOnly.Add(recDate.Value);
                                        lstFemale.Add(femaleValue);
                                        lstMale.Add(maleValue);
                                        //lstVoca.Add(vocaValue);
                                        lstExplanation.Add(explanation);
                                    }
                                    catch (Exception e)
                                    {
                                        continue;
                                    }


                                }
                                if (lstDateOnly.Count == lstFemale.Count && lstMale.Count == lstExplanation.Count && lstFemale.Count == lstMale.Count)
                                {
                                    checkList.ForEach(x => x.Status = 0);
                                        var md = new MpRecDeptPlanIp2()
                                        {
                                            Active = true,
                                            CreatedBy = u.UserName,
                                            DeptName = data.dept,
                                            Model = model,
                                            RecDate = lstDateOnly.ToArray(),
                                            RecExplain = lstExplanation.ToArray(),
                                            RecPlanF = lstFemale.ToArray(),
                                            RecPlanM = lstMale.ToArray(),
                                            //RecPlanVc = lstVoca.ToArray(),
                                            PeriodId = Guid.Parse(periodId),
                                            Status = 1,
                                            AprroveBy = data.mgr
                                        };
                                        context.MpRecDeptPlanIp2s.Add(md);
                                    
                                    
                                }
                            }



                        }
                    }
                    context.SaveChanges();
                }
                var user = context.AdmUserInformations.Where(x => x.Active == true && x.EmployeeCode == data.mgr).FirstOrDefault();
                var lstRecive = new List<string>() { user.Email };
                var link = "http://cvn-vpsi/#/manpower/recruitment/rec-dept-plan/" + periodId + "/" + model + "/" + data.dept;
                SendMailBeforeApprovedRec(data.dept, lstRecive, user.FullName, link);

                result.Status = (int)HttpStatusCode.OK;
                result.Message = "Success";
                result.Error = false;
                return result;
            }
            catch (Exception e)
            {
                result.Status = (int)HttpStatusCode.BadRequest;
                result.Message = e.Message;
                result.Error = true;
                return result;
            }
        }
        [HttpPost("import-RecruimentAllActual")]
        public async Task<CommonResponse> ImportRecruimentAllActual(string model, string periodId, [FromForm] IFormFile file)
        {
            var result = new CommonResponse()
            {
                Error = false,
                Message = "",
                Status = (int)HttpStatusCode.BadRequest
            };
            try
            {
                var u = GetCurrentUser();
                var lstDeptRec = await context.MpRecMasterDepts.Where(x => x.Active == true).Select(x => x.DeptName.ToUpper()).ToListAsync();
                var period = await context.MpRecMasterPeriods.Where(x => x.Id == Guid.Parse(periodId)).FirstAsync();
                var dateFrom = period.DateFrom;
                var dateTo = period.DateTo;
                using (var memoStream = new MemoryStream())
                {
                    file.CopyTo(memoStream);
                    ExcelPackage.LicenseContext = LicenseContext.NonCommercial;
                    using (var package = new ExcelPackage(memoStream))
                    {
                        var worksheet = package.Workbook.Worksheets[0];
                        if (worksheet.Name != "Input 3")
                        {
                            result.Message = "Wrong sheet name !";
                            result.Error = true;
                            result.Status = 400;
                            return result;
                        }
                        var rowCount = worksheet.Dimension?.Rows;
                        var colCount = worksheet.Dimension?.Columns;

                        if ((colCount - 2) % 3 > 0)
                        {
                            result.Message = "Wrong format in columns number !";
                            result.Error = true;
                            result.Status = 400;
                            return result;
                        }
                        var modelInSheet = worksheet.Cells["C1"].Value.ObjToStringAble().Trim();
                        if (modelInSheet.ToUpper() != model.ToUpper())
                        {
                            result.Message = "Wrong model !";
                            result.Error = true;
                            result.Status = 400;
                            return result;
                        }

                        bool valid = false;
                        if (rowCount.HasValue && colCount.HasValue && rowCount.Value > 4 && rowCount.Value > 5)
                        {
                            for (int i = 3; i <= colCount.Value; i++)
                            {
                                if (i % 3 == 0 && worksheet.Cells[3, i].Value.ObjToStringAble() == "F")
                                {
                                    valid = true;
                                }
                                else if (i % 3 == 1 && worksheet.Cells[3, i].Value.ObjToStringAble() == "M")
                                {
                                    valid = true;
                                }
                                else if (i % 3 == 2 && worksheet.Cells[3, i].Value.ObjToStringAble() == "VC")
                                {
                                    valid = true;
                                }
                                else
                                {
                                    valid = false;
                                }
                            }
                            if (valid)
                            {
                                var lstDateOnly = new List<DateOnly>();
                                var indexPossible = new List<int>();
                                for (int j = 4; j <= (rowCount.Value); j++)
                                {
                                    try
                                    {
                                        var date = worksheet.Cells[j, 1].Value.ObjToDateonlyAble();
                                        if (date == null)
                                        {
                                            continue;
                                        }
                                        else if (date < dateFrom || date > dateTo)
                                        {
                                            continue;
                                        }
                                        else if (lstDateOnly.Contains(date.Value))
                                        {
                                            result.Message = "Wrong format ! Exists date: " + date;
                                            result.Error = true;
                                            result.Status = 400;
                                            return result;
                                        }
                                        lstDateOnly.Add(date.Value);
                                        indexPossible.Add(j);
                                    }
                                    catch (Exception er)
                                    {
                                        continue;
                                    }
                                }
                                for (int i = 1; i <= ((colCount - 2) / 3); i++)
                                {
                                    string dept = worksheet.Cells[2, 2 + (3 * i - 2)].Value.ObjToStringAble();
                                    if (!lstDeptRec.Contains(dept.ToUpper()))
                                    {
                                        continue;
                                    }
                                    var cFemale = 2 + (3 * i - 2);
                                    var cMale = 2 + (3 * i - 1);
                                    var cVoca = 2 + (3 * i);
                                    var lstFemale = new List<int>();
                                    var lstMale = new List<int>();
                                    var lstVoca = new List<int>();
                                    var lstExplanation = new List<string>();
                                    for (int j = 4; j <= (rowCount.Value); j++)
                                    {
                                        try
                                        {
                                            if (indexPossible.Contains(j))
                                            {
                                                lstFemale.Add(worksheet.Cells[j, cFemale].Value.ObjToIntAble());
                                                lstMale.Add(worksheet.Cells[j, cMale].Value.ObjToIntAble());
                                                lstVoca.Add(worksheet.Cells[j, cVoca].Value.ObjToIntAble());
                                            }

                                        }
                                        catch (Exception er)
                                        {
                                            continue;
                                        }
                                    }
                                    if (lstDateOnly.Count == lstFemale.Count && lstFemale.Count == lstMale.Count)
                                    {
                                        var checkExist = context.MpRecDeptActualIp3s.FirstOrDefault(x => x.Active == true && x.PeriodId == Guid.Parse(periodId) && x.DeptName.Equals(dept) && x.Model.Equals(modelInSheet));
                                        if (checkExist != null)
                                        {
                                            checkExist.ModifiedBy = u.UserName;
                                            checkExist.ModifiedDate = DateTime.Now.SetKindUtc();
                                            checkExist.RecActualF = lstFemale.ToArray();
                                            checkExist.RecActualM = lstMale.ToArray();
                                            checkExist.RecActualVc = lstVoca.ToArray();
                                            checkExist.RecDate = lstDateOnly.ToArray();
                                            context.MpRecDeptActualIp3s.Update(checkExist);
                                        }
                                        else
                                        {
                                            var item = new MpRecDeptActualIp3()
                                            {
                                                Active = true,
                                                CreatedBy = u.UserName,
                                                DeptName = dept,
                                                Model = modelInSheet,
                                                RecActualF = lstFemale.ToArray(),
                                                RecActualM = lstMale.ToArray(),
                                                RecActualVc = lstVoca.ToArray(),
                                                RecDate = lstDateOnly.ToArray(),
                                                PeriodId = Guid.Parse(periodId)
                                            };
                                            context.MpRecDeptActualIp3s.Add(item);
                                        }
                                        context.SaveChanges();
                                    }

                                }
                            }

                        }

                    }
                }

                result.Status = (int)HttpStatusCode.OK;
                result.Message = "Success";
                result.Error = false;
                return result;
            }
            catch (Exception e)
            {
                result.Status = (int)HttpStatusCode.BadRequest;
                result.Message = e.Message;
                result.Error = true;
                return result;
            }
        }
        [HttpPost("import-RecruimentAllMaintain")]
        public async Task<CommonResponse> ImportRecruimentAllMaintain(string model, string periodId, [FromForm] IFormFile file)
        {
            var result = new CommonResponse()
            {
                Error = false,
                Message = "",
                Status = (int)HttpStatusCode.BadRequest
            };
            try
            {
                var u = GetCurrentUser();
                var lstDeptRec = await context.MpRecMasterDepts.Where(x => x.Active == true).Select(x => x.DeptName.ToUpper()).ToListAsync();
                var period = await context.MpRecMasterPeriods.Where(x => x.Id == Guid.Parse(periodId)).FirstAsync();
                var dateFrom = period.DateFrom;
                var dateTo = period.DateTo;
                using (var memoStream = new MemoryStream())
                {
                    file.CopyTo(memoStream);
                    ExcelPackage.LicenseContext = LicenseContext.NonCommercial;
                    using (var package = new ExcelPackage(memoStream))
                    {
                        var worksheet = package.Workbook.Worksheets[0];
                        if (worksheet.Name != "Input 4")
                        {
                            result.Message = "Wrong sheet name !";
                            result.Error = true;
                            result.Status = 400;
                            return result;
                        }
                        var rowCount = worksheet.Dimension?.Rows;
                        var colCount = worksheet.Dimension?.Columns;

                        var modelInSheet = worksheet.Cells["C1"].Value.ObjToStringAble().Trim();
                        if (modelInSheet.ToUpper() != model.ToUpper())
                        {
                            result.Message = "Wrong model !";
                            result.Error = true;
                            result.Status = 400;
                            return result;
                        }
                        var isMaintain = worksheet.Cells["C2"].Value.ObjToStringAble().Trim();
                        if (isMaintain.ToUpper() != "MAINTAIN")
                        {
                            result.Message = "Wrong content type !";
                            result.Error = true;
                            result.Status = 400;
                            return result;
                        }
                        bool valid = false;
                        if (rowCount.HasValue && colCount.HasValue && rowCount.Value > 4 && rowCount.Value > 5)
                        {
                            for (int i = 3; i <= colCount; i++)
                            {
                                string dept = worksheet.Cells[3, i].Value.ObjToStringAble();
                                if (!lstDeptRec.Contains(dept.ToUpper()))
                                {
                                    continue;
                                }
                                var lstDateOnly = new List<DateOnly>();
                                var lstMaintain = new List<int>();
                                for (int j = 4; j <= (rowCount.Value); j++)
                                {
                                    try
                                    {
                                        var date = worksheet.Cells[j, 1].Value.ObjToDateonlyAble();
                                        if (date == null)
                                        {
                                            continue;
                                        }
                                        else if (date < dateFrom || date > dateTo)
                                        {
                                            continue;
                                        }
                                        lstDateOnly.Add(date.Value);
                                        lstMaintain.Add(worksheet.Cells[j, i].Value.ObjToIntAble());
                                    }
                                    catch (Exception)
                                    {
                                        continue;
                                    }
                                }
                                if (lstDateOnly.Count == lstMaintain.Count)
                                {
                                    var checkExist = context.MpRecAllMaintainIp4s.FirstOrDefault(x => x.Active == true && x.PeriodId == Guid.Parse(periodId) && x.DeptName.Equals(dept) && x.Model.Equals(modelInSheet));
                                    if (checkExist != null)
                                    {
                                        checkExist.ModifiedBy = u.UserName;
                                        checkExist.ModifiedDate = DateTime.Now.SetKindUtc();
                                        checkExist.RecMaintain = lstMaintain.ToArray();
                                        checkExist.RecDate = lstDateOnly.ToArray();
                                        checkExist.RecExplain = new string[] { };
                                        context.MpRecAllMaintainIp4s.Update(checkExist);
                                    }
                                    else
                                    {
                                        var item = new MpRecAllMaintainIp4()
                                        {
                                            Active = true,
                                            CreatedBy = u.UserName,
                                            DeptName = dept,
                                            Model = modelInSheet,
                                            RecMaintain = lstMaintain.ToArray(),
                                            RecDate = lstDateOnly.ToArray(),
                                            RecExplain = new string[] { },
                                            PeriodId = Guid.Parse(periodId)
                                        };
                                        context.MpRecAllMaintainIp4s.Add(item);
                                    }
                                    context.SaveChanges();
                                }

                            }

                        }

                    }
                }

                result.Status = (int)HttpStatusCode.OK;
                result.Message = "Success";
                result.Error = false;
                return result;
            }
            catch (Exception e)
            {
                result.Status = (int)HttpStatusCode.BadRequest;
                result.Message = e.Message;
                result.Error = true;
                return result;
            }
        }

        [HttpGet("get-list-recruitment-dept")]
        public async Task<List<string>> GetRecruitmentDeptList()
        {
            try
            {
                var u = GetCurrentUser();
                var lstDeptU = u.DeptId.Split(',');
                var lstDeptRec = await context.MpRecMasterDepts.Where(x => x.Active == true).OrderBy(x => x.DeptOrder).ToListAsync();
                if (u.IsPdc.ToLower().Equals("true"))
                {
                    return lstDeptRec.Select(x => x.DeptName).ToList();
                }
                else
                {
                    var result = new List<string>();
                    foreach (var item in lstDeptRec)
                    {
                        if (item.DeptId != null)
                        {
                            var lstDeptId = item.DeptId.Select(x => x.ToString()).ToList();
                            if (lstDeptId.Intersect(lstDeptU).Count() > 0)
                            {
                                result.Add(item.DeptName);
                                continue;
                            }
                        }
                    }
                    return result;
                }
            }
            catch (Exception e)
            {
                return new List<string>();
            }
        }

        [HttpGet("get-list-recruitment-period")]
        public async Task<List<MpRecMasterPeriodView>> GetAllRecruitmentPeriod()
        {
            try
            {
                var model = await context.MpRecMasterPeriods.Where(x => x.Active == true).OrderByDescending(x => x.CreatedDate.Value).ToListAsync();
                return model.MapRecruitment();
            }
            catch (Exception e)
            {
                //SendMailError(e);
                return new List<MpRecMasterPeriodView>();
            }
        }
        [HttpPost("add-recruitment-period")]
        public async Task<CommonResponse> AddRecruitmentPeriod(MpRecMasterPeriodRequest rq)
        {
            var res = new CommonResponse()
            {
                Error = false,
                Message = "Successful !",
                Status = 200
            };
            try
            {
                await context.MpRecMasterPeriods.AddAsync(new MpRecMasterPeriod()
                {
                    DateFrom = rq.DateFrom,
                    DateTo = rq.DateTo,
                    Note = rq.Note,
                    PeriodName = rq.PeriodName
                });
                context.SaveChanges();
                res.Error = false;
                res.Message = "Successful !";
                res.Status = 200;
            }
            catch (Exception e)
            {
                //SendMailError(e);
                res.Error = true;
                res.Message = e.Message;
                res.Status = 400;
            }
            return res;
        }
        [HttpPut("remove-recruitment-period")]
        public async Task<CommonResponse> RemoveRecruitmentPeriod(Guid id)
        {
            var res = new CommonResponse()
            {
                Error = false,
                Message = "Successful !",
                Status = 200
            };
            try
            {
                var u = GetCurrentUser();
                var md = context.MpRecMasterPeriods.Where(x => x.Id == id).First();
                md.Active = false;
                md.ModifiedDate = DateTime.Now.SetKindUtc();
                md.ModifiedBy = u.UserName;
                context.Update(md);
                await context.SaveChangesAsync();
                res.Error = false;
                res.Message = "Successful !";
                res.Status = 200;
            }
            catch (Exception e)
            {
                //SendMailError(e);
                res.Error = true;
                res.Message = e.Message;
                res.Status = 400;
            }
            return res;
        }
        [HttpPost("filter-recruitment-dept-plan")]
        public MpRecDeptPlanIp2Model FilterRecruitmentDeptPlan(MpRecDeptPlanParam param)
        {
            try
            {
                var result = new MpRecDeptPlanIp2Model();
                var lstResult = new List<MpRecDeptPlanIp2View>();
                var u = GetCurrentUser();
                int countTong = 0;
                var model1 = context.MpRecDeptPlanIp2s.Where(x => x.Active == true && x.Status != 0).AsQueryable();
                if (param.Product.Equals("ALL MODEL"))
                {
                    string[] listProduct = { "IJP MODEL", "LBP MODEL" };
                    foreach (var item1 in listProduct)
                    {
                        var model = model1.Where(x => x.Model.Equals(item1));
                        if (!param.Department.IsNullOrEmpty() && param.Department != "ALL") model = model.Where(x => x.DeptName == param.Department);
                        if (!param.PeriodId.IsNullOrEmpty()) model = model.Where(x => x.PeriodId == Guid.Parse(param.PeriodId));

                        var model2 = model.FirstOrDefault();

                        for (int i = 0; i < model2.RecDate.Length; i++)
                        {
                            lstResult.Add(new MpRecDeptPlanIp2View()
                            {
                                DateItem = model2.RecDate[i].ToString("yyyy-MM-dd"),
                                Explanation = model2.RecExplain[i],
                                FemalValue = model2.RecPlanF[i],
                                MaleValue = model2.RecPlanM[i],
                                //VocaValue = model2.RecPlanVc[i],
                                DateWeek = model2.RecDate[i].DayOfWeek.ToString().Substring(0, 3)
                            });
                        }
                        countTong += model2.RecDate.Length;
                
                    }
                }
                else
                {

                    if (!param.Product.IsNullOrEmpty()) {
                            model1 = model1.Where(x => x.Model == param.Product); 
                    }
                    if (!param.Department.IsNullOrEmpty() && param.Department != "ALL") model1 = model1.Where(x => x.DeptName == param.Department);
                    if (!param.PeriodId.IsNullOrEmpty()) model1 = model1.Where(x => x.PeriodId == Guid.Parse(param.PeriodId));

                    var model2 = model1.FirstOrDefault();

                    for (int i = 0; i < model2.RecDate.Length; i++)
                    {
                        lstResult.Add(new MpRecDeptPlanIp2View()
                        {
                            DateItem = model2.RecDate[i].ToString("yyyy-MM-dd"),
                            Explanation = model2.RecExplain[i],
                            FemalValue = model2.RecPlanF[i],
                            MaleValue = model2.RecPlanM[i],
                            //VocaValue = model2.RecPlanVc[i],
                            DateWeek = model2.RecDate[i].DayOfWeek.ToString().Substring(0, 3)
                        });
                    }
                    countTong += model2.RecDate.Length;
       
                }

                var c = countTong;
                result.lstModel = lstResult;
                result.toRecord = (int)Math.Min(result.totalRecords, result.currentPage * result.recordPerPage);
                result.totalPage = (int)Math.Ceiling((decimal)c / param.RecordsPerPage);
                result.totalRecords = c;
                result.recordPerPage = param.RecordsPerPage;
                result.currentPage = param.Page;
                result.fromRecord = c == 0 ? 0 : (result.currentPage - 1) * result.recordPerPage + 1;
                return result;
            }
            catch (Exception)
            {
                return new MpRecDeptPlanIp2Model();
            }
        }
        [HttpPost("filter-recruitment-dept-plan-table")]
        public MpRecDeptPlanIp2ModelTable FilterRecruitmentDeptPlanTable(MpRecDeptPlanParam param)
        {
            try
            {
                var result = new MpRecDeptPlanIp2ModelTable();
                var lstResult = new List<List<string>>();
                var u = GetCurrentUser();
                var model1 = context.MpRecDeptPlanIp2s.Where(x => x.Active == true && x.Status != 0).AsQueryable();
                int countTong = 0;
                string status = "";
                string approveBy = "";
                if (param.Product.Equals("ALL MODEL"))
                {
                    var modelIJP = model1.Where(x => x.Model.Equals("IJP MODEL"));
                    if (!param.Department.IsNullOrEmpty() && param.Department != "ALL") modelIJP = modelIJP.Where(x => x.DeptName == param.Department);
                    if (!param.PeriodId.IsNullOrEmpty()) modelIJP = modelIJP.Where(x => x.PeriodId == Guid.Parse(param.PeriodId));
                    var modelLBP = model1.Where(x => x.Model.Equals("LBP MODEL"));
                    if (!param.Department.IsNullOrEmpty() && param.Department != "ALL") modelLBP = modelLBP.Where(x => x.DeptName == param.Department);
                    if (!param.PeriodId.IsNullOrEmpty()) modelLBP = modelLBP.Where(x => x.PeriodId == Guid.Parse(param.PeriodId));

                    if(modelIJP.Count()>0 && modelLBP.Count() > 0)
                    {
                        var modelIJPF = modelIJP.First();
                        var modelLBPF = modelLBP.First();
                        status += "IJP - " + (modelIJPF.Status == 1 ? "Checking" : (modelIJPF.Status == 2 ? "Finished" : "Rejected"))+"|";
                        status += "LBP - " + (modelLBPF.Status == 1 ? "Checking" : (modelLBPF.Status == 2 ? "Finished" : "Rejected"));
                        var z = new DateOnly[modelIJPF.RecDate.Length + modelLBPF.RecDate.Length];
                        modelIJPF.RecDate.CopyTo(z, 0);
                        modelLBPF.RecDate.CopyTo(z, modelIJPF.RecDate.Length);
                        var RecPlanF = new int[modelIJPF.RecPlanF.Length + modelLBPF.RecPlanF.Length];
                        modelIJPF.RecPlanF.CopyTo(RecPlanF, 0);
                        modelLBPF.RecPlanF.CopyTo(RecPlanF, modelIJPF.RecPlanF.Length);
                        var RecPlanM = new int[modelIJPF.RecPlanM.Length + modelLBPF.RecPlanM.Length];
                        modelIJPF.RecPlanM.CopyTo(RecPlanM, 0);
                        modelLBPF.RecPlanM.CopyTo(RecPlanM, modelIJPF.RecPlanM.Length);
                        //var RecPlanVc = new int[modelIJPF.RecPlanVc.Length + modelLBPF.RecPlanVc.Length];
                        //modelIJPF.RecPlanVc.CopyTo(RecPlanVc, 0);
                        //modelLBPF.RecPlanVc.CopyTo(RecPlanVc, modelIJPF.RecPlanVc.Length);
                        var RecExplain = new string[modelIJPF.RecExplain.Length + modelLBPF.RecExplain.Length];
                        modelIJPF.RecExplain.CopyTo(RecExplain, 0);
                        modelLBPF.RecExplain.CopyTo(RecExplain, modelIJPF.RecExplain.Length);

                        var model2 = z.Skip((param.Page - 1) * param.RecordsPerPage).Take(param.RecordsPerPage).ToList();
                        foreach (var item in model2)
                        {
                            List<string> r = new List<string>();
                            r.Add(item.ToString("dd-MMM-yy"));
                            r.Add(item.DayOfWeek.ToString().Substring(0, 3));
                            var index = Array.IndexOf(z, item);
                            r.Add(RecPlanF[index] != 0 ? RecPlanF[index].ToString() : "");
                            r.Add(RecPlanM[index] != 0 ? RecPlanM[index].ToString() : "");
                            //r.Add(RecPlanVc[index] != 0 ? RecPlanVc[index].ToString() : "");
                            r.Add(RecExplain[index]);
                            lstResult.Add(r);
                        }
                        countTong += modelIJPF.RecDate.Length + modelLBPF.RecDate.Length;

                    }
                    else
                    {
                        var project = modelIJP.Count() > 0 ? modelIJP.First() : modelLBP.First();
                        if(modelIJP.Count() > 0)
                        {

                            status += "IJP - " + (project.Status == 1 ? "Checking" : (project.Status == 2 ? "Finished" : "Rejected")) + "| LBP - No data";
                        }
                        else
                        {

                            status += "IJP - No data | LBP - " + (project.Status == 1 ? "Checking" : (project.Status == 2 ? "Finished" : "Rejected"));
                        }
                        var model2 = project.RecDate.Skip((param.Page - 1) * param.RecordsPerPage).Take(param.RecordsPerPage).ToList();
                        foreach (var item in model2)
                        {
                            List<string> r = new List<string>();
                            r.Add(item.ToString("dd-MMM-yy"));
                            r.Add(item.DayOfWeek.ToString().Substring(0, 3));
                            var index = Array.IndexOf(project.RecDate, item);
                            r.Add(project.RecPlanF[index] != 0 ? project.RecPlanF[index].ToString() : "");
                            r.Add(project.RecPlanM[index] != 0 ? project.RecPlanM[index].ToString() : "");
                            //r.Add(project.RecPlanVc[index] != 0 ? project.RecPlanVc[index].ToString() : "");
                            r.Add(project.RecExplain[index]);
                            lstResult.Add(r);
                        }
                        countTong += project.RecDate.Length;
                    }
                   
                    

                }
                else
                {

                    if (!param.Product.IsNullOrEmpty())
                    {                 
                          model1 = model1.Where(x => x.Model == param.Product);                  
                    }
                    if (!param.Department.IsNullOrEmpty() && param.Department != "ALL") model1 = model1.Where(x => x.DeptName == param.Department);
                    if (!param.PeriodId.IsNullOrEmpty()) model1 = model1.Where(x => x.PeriodId == Guid.Parse(param.PeriodId));
                    var project = model1.FirstOrDefault();
                    var model2 = project.RecDate.Skip((param.Page - 1) * param.RecordsPerPage).Take(param.RecordsPerPage).ToList();
                    foreach (var item in model2)
                    {
                        List<string> r = new List<string>();
                        r.Add(item.ToString("dd-MMM-yy"));
                        r.Add(item.DayOfWeek.ToString().Substring(0, 3));
                        var index = Array.IndexOf(project.RecDate, item);
                        r.Add(project.RecPlanF[index] != 0 ? project.RecPlanF[index].ToString() : "");
                        r.Add(project.RecPlanM[index] != 0 ? project.RecPlanM[index].ToString() : "");
                        //r.Add(project.RecPlanVc[index] != 0 ? project.RecPlanVc[index].ToString() : "");
                        r.Add(project.RecExplain[index]);
                        lstResult.Add(r);
                    }
                    countTong += project.RecDate.Length;
                    status = project.Status == 1 ? "Checking" : (project.Status == 2 ? "Finished" : "Rejected") ;
                    approveBy = project.AprroveBy;

                }
                var c = countTong;
                result.Status = status;
                result.ApproveBy = approveBy;
                result.lstModel = lstResult;
                result.toRecord = (int)Math.Min(result.totalRecords, result.currentPage * result.recordPerPage);
                result.totalPage = (int)Math.Ceiling((decimal)c / param.RecordsPerPage);
                result.totalRecords = c;
                result.recordPerPage = param.RecordsPerPage;
                result.currentPage = param.Page;
                result.fromRecord = c == 0 ? 0 : (result.currentPage - 1) * result.recordPerPage + 1;
                return result;
            }
            catch (Exception e)
            {
                return new MpRecDeptPlanIp2ModelTable();
            }
        }
        [HttpPost("filter-recruitment-dept-actual")]
        public MpRecDeptActualIp3Model FilterRecruitmentDeptActual(MpRecDeptActualParam param)
        {
            try
            {
                var result = new MpRecDeptActualIp3Model();
                var lstResult = new List<MpRecDeptActualIp3View>();
                var u = GetCurrentUser();
                var listMaster = context.MpRecMasterDepts.ToList();
                var model = context.MpRecDeptActualIp3s.Where(x => x.Active == true).AsQueryable();

                //int countTong = 0;
                //if (param.Product.Equals("ALL MODEL"))
                //{
                //    var modelIJP = model.Where(x => x.Model.Equals("IJP MODEL"));
                //    if (!param.PeriodId.IsNullOrEmpty()) modelIJP = modelIJP.Where(x => x.PeriodId == Guid.Parse(param.PeriodId));
                //    var modelLBP = model.Where(x => x.Model.Equals("LBP MODEL"));
                //    if (!param.PeriodId.IsNullOrEmpty()) modelLBP = modelLBP.Where(x => x.PeriodId == Guid.Parse(param.PeriodId));
                //    if (modelIJP.Count() > 0 && modelLBP.Count() > 0)
                //    {
                //        var modelIJPF = modelIJP.First();
                //        var modelLBPF = modelLBP.First();
                //        var z = new DateOnly[modelIJPF.RecDate.Length + modelLBPF.RecDate.Length];
                //        modelIJPF.RecDate.CopyTo(z, 0);
                //        modelLBPF.RecDate.CopyTo(z, modelIJPF.RecDate.Length);
                //        var RecActualF = new int[modelIJPF.RecActualF.Length + modelLBPF.RecActualF.Length];
                //        modelIJPF.RecActualF.CopyTo(RecActualF, 0);
                //        modelLBPF.RecActualF.CopyTo(RecActualF, modelIJPF.RecActualF.Length);
                //        var RecActualM = new int[modelIJPF.RecActualM.Length + modelLBPF.RecActualM.Length];
                //        modelIJPF.RecActualM.CopyTo(RecActualM, 0);
                //        modelLBPF.RecActualM.CopyTo(RecActualM, modelIJPF.RecActualM.Length);
                //        var RecActualVc = new int[modelIJPF.RecActualVc.Length + modelLBPF.RecActualVc.Length];
                //        modelIJPF.RecActualVc.CopyTo(RecActualVc, 0);
                //        modelLBPF.RecActualVc.CopyTo(RecActualVc, modelIJPF.RecActualVc.Length);
                //        List<DateOnly> dateMinList = new List<DateOnly>();
                //        List<DateOnly> dateMaxList = new List<DateOnly>();
                //        List<string> listDept = new List<string>();
                //        List<MpRecDeptActualIp3Order> listOrder = new List<MpRecDeptActualIp3Order>();
                //        foreach (var d in model)
                //        {
                //            listOrder.Add(new MpRecDeptActualIp3Order()
                //            {
                //                Mp = d,
                //                Index = listMaster.FirstOrDefault(x => x.DeptName.ToUpper().Equals(d.DeptName.ToUpper())).DeptOrder
                //            });
                //            dateMinList.Add(d.RecDate.First());
                //            dateMaxList.Add(d.RecDate.Last());
                //        }
                //        listOrder = listOrder.OrderBy(x => x.Index).ToList();
                //        DateOnly dateMin = dateMinList.Min();
                //        DateOnly dateMax = dateMaxList.Max();

                //        List<DateOnly> dateList = new List<DateOnly>();

                //        // Thêm các ngày từ ngày đầu đến ngày cuối vào List
                //        for (DateOnly date = dateMin; date <= dateMax; date = date.AddDays(1))
                //        {
                //            dateList.Add(date);
                //        }
                //        List<List<string>> resultList = new List<List<string>>();

                //        var model2 = dateList.Skip((param.Page - 1) * param.RecordsPerPage).Take(param.RecordsPerPage).ToList();

                //    }
                //}
                if (!param.Product.Equals("ALL MODEL"))
                {
                    if (!param.Product.IsNullOrEmpty()) model = model.Where(x => x.Model == param.Product);
                }

                if (!param.PeriodId.IsNullOrEmpty()) model = model.Where(x => x.PeriodId == Guid.Parse(param.PeriodId));
                List<DateOnly> dateMinList = new List<DateOnly>();
                List<DateOnly> dateMaxList = new List<DateOnly>();
                List<string> listDept = new List<string>();
                List<MpRecDeptActualIp3Order> listOrder = new List<MpRecDeptActualIp3Order>();
                foreach (var d in model)
                {
                    listOrder.Add(new MpRecDeptActualIp3Order()
                    {
                        Mp = d,
                        Index = listMaster.FirstOrDefault(x => x.DeptName.ToUpper().Equals(d.DeptName.ToUpper())).DeptOrder
                    });
                    dateMinList.Add(d.RecDate.First());
                    dateMaxList.Add(d.RecDate.Last());
                }
                listOrder = listOrder.OrderBy(x => x.Index).ToList();
                DateOnly dateMin = dateMinList.Min();
                DateOnly dateMax = dateMaxList.Max();

                List<DateOnly> dateList = new List<DateOnly>();

                // Thêm các ngày từ ngày đầu đến ngày cuối vào List
                for (DateOnly date = dateMin; date <= dateMax; date = date.AddDays(1))
                {
                    dateList.Add(date);
                }
                List<List<string>> resultList = new List<List<string>>();

                var model2 = dateList.Skip((param.Page - 1) * param.RecordsPerPage).Take(param.RecordsPerPage).ToList();
                foreach (var item in model2)
                {
                    List<string> r = new List<string>();
                    r.Add(item.ToString("dd-MMM-yy"));
                    r.Add(item.DayOfWeek.ToString().Substring(0, 3));
                    for (int i = 0; i < listOrder.Count(); i++)
                    {
                        var index = Array.IndexOf(listOrder[i].Mp.RecDate, item);
                        r.Add(listOrder[i].Mp.RecActualF[index] != 0 ? listOrder[i].Mp.RecActualF[index].ToString() : "");
                        r.Add(listOrder[i].Mp.RecActualM[index] != 0 ? listOrder[i].Mp.RecActualM[index].ToString() : "");
                        r.Add(listOrder[i].Mp.RecActualVc[index] != 0 ? listOrder[i].Mp.RecActualVc[index].ToString() : "");

                    }
                    resultList.Add(r);
                }
                var c = dateList.Count();
                result.Product = param.Product;
                result.ListDept = listOrder.Select(x => x.Mp.DeptName).ToList();
                result.lstModel = resultList;
                result.toRecord = (int)Math.Min(result.totalRecords, result.currentPage * result.recordPerPage);
                result.totalPage = (int)Math.Ceiling((decimal)c / param.RecordsPerPage);
                result.totalRecords = c;
                result.recordPerPage = param.RecordsPerPage;
                result.currentPage = param.Page;
                result.fromRecord = c == 0 ? 0 : (result.currentPage - 1) * result.recordPerPage + 1;
                return result;
            }
            catch (Exception)
            {
                return new MpRecDeptActualIp3Model();
            }
        }
        [HttpPost("filter-recruitment-dept-maintain")]
        public MpRecDeptMaintainIp4Model FilterRecruitmentDeptMaintain(MpRecDeptActualParam param)
        {
            try
            {
                var result = new MpRecDeptMaintainIp4Model();
                var u = GetCurrentUser();
                var listMaster = context.MpRecMasterDepts.ToList();
                var model = context.MpRecAllMaintainIp4s.Where(x => x.Active == true).AsQueryable();
                if (!param.Product.Equals("ALL MODEL"))
                {
                    if (!param.Product.IsNullOrEmpty()) model = model.Where(x => x.Model == param.Product);
                }
                if (!param.PeriodId.IsNullOrEmpty()) model = model.Where(x => x.PeriodId == Guid.Parse(param.PeriodId));
                List<DateOnly> dateMinList = new List<DateOnly>();
                List<DateOnly> dateMaxList = new List<DateOnly>();
                List<string> listDept = new List<string>();
                List<MpRecAllMaintainIp4Order> listOrder = new List<MpRecAllMaintainIp4Order>();
                foreach (var d in model)
                {
                    listOrder.Add(new MpRecAllMaintainIp4Order()
                    {
                        Mp = d,
                        Index = listMaster.FirstOrDefault(x => x.DeptName.ToUpper().Equals(d.DeptName.ToUpper())).DeptOrder
                    });
                    dateMinList.Add(d.RecDate.First());
                    dateMaxList.Add(d.RecDate.Last());
                }
                listOrder = listOrder.OrderBy(x => x.Index).ToList();
                DateOnly dateMin = dateMinList.Min();
                DateOnly dateMax = dateMaxList.Max();

                List<DateOnly> dateList = new List<DateOnly>();

                // Thêm các ngày từ ngày đầu đến ngày cuối vào List
                for (DateOnly date = dateMin; date <= dateMax; date = date.AddDays(1))
                {
                    dateList.Add(date);
                }
                List<List<string>> resultList = new List<List<string>>();

                var model2 = dateList.Skip((param.Page - 1) * param.RecordsPerPage).Take(param.RecordsPerPage).ToList();
                foreach (var item in model2)
                {
                    List<string> r = new List<string>();
                    r.Add(item.ToString("dd-MMM-yy"));
                    r.Add(item.DayOfWeek.ToString().Substring(0, 3));
                    for (int i = 0; i < listOrder.Count(); i++)
                    {
                        var index = Array.IndexOf(listOrder[i].Mp.RecDate, item);
                        r.Add(listOrder[i].Mp.RecMaintain[index] != 0 ? listOrder[i].Mp.RecMaintain[index].ToString() : "");
                    }
                    resultList.Add(r);
                }
                var c = dateList.Count();
                result.Product = param.Product;
                result.ListDept = listOrder.Select(x => x.Mp.DeptName).ToList();
                result.lstModel = resultList;
                result.toRecord = (int)Math.Min(result.totalRecords, result.currentPage * result.recordPerPage);
                result.totalPage = (int)Math.Ceiling((decimal)c / param.RecordsPerPage);
                result.totalRecords = c;
                result.recordPerPage = param.RecordsPerPage;
                result.currentPage = param.Page;
                result.fromRecord = c == 0 ? 0 : (result.currentPage - 1) * result.recordPerPage + 1;
                return result;
            }
            catch (Exception)
            {
                return new MpRecDeptMaintainIp4Model();
            }
        }
        [HttpPost("filter-recruitment-output")]
        public MpRecDeptActualIp3Model FilterRecruitmentOutput(MpRecDeptActualParamArr param)
        {
            try
            {
                if (param.Product.Equals("ALL MODEL"))
                {
                    var result = new MpRecDeptActualIp3Model();
                    var lstResult = new List<MpRecDeptActualIp3View>();
                    var listMaster = context.MpRecMasterDepts.ToList();
                    var modelDept = context.MpRecDeptPlanIp2s.Where(x => x.Active == true && x.Status == 2).AsQueryable();
                    if (!param.Product.IsNullOrEmpty()) modelDept = modelDept.Where(x => x.Model.Equals("IJP MODEL") || x.Model.Equals("LBP MODEL"));
                    if (!param.PeriodId.IsNullOrEmpty()) modelDept = modelDept.Where(x => param.PeriodId.Contains(x.PeriodId.ToString()));
                    var modelActual = context.MpRecDeptActualIp3s.Where(x => x.Active == true).AsQueryable();
                    if (!param.Product.IsNullOrEmpty()) modelActual = modelActual.Where(x => x.Model.Equals("IJP MODEL") || x.Model.Equals("LBP MODEL"));
                    if (!param.PeriodId.IsNullOrEmpty()) modelActual = modelActual.Where(x => param.PeriodId.Contains(x.PeriodId.ToString()));
                    var modelMaintain = context.MpRecAllMaintainIp4s.Where(x => x.Active == true).AsQueryable();
                    if (!param.Product.IsNullOrEmpty()) modelMaintain = modelMaintain.Where(x => x.Model.Equals("IJP MODEL") || x.Model.Equals("LBP MODEL"));
                    if (!param.PeriodId.IsNullOrEmpty()) modelMaintain = modelMaintain.Where(x => param.PeriodId.Contains(x.PeriodId.ToString()));
                    List<string> listDept = new List<string>();
                    listDept.AddRange(modelDept.Select(x => x.DeptName.ToUpper()).ToList());
                    listDept.AddRange(modelActual.Select(x => x.DeptName.ToUpper()).ToList());
                    listDept.AddRange(modelMaintain.Select(x => x.DeptName.ToUpper()).ToList());
                    listDept = listDept.Distinct().ToList();
                    List<DeptNameViewTotal> listDeptOrder = new List<DeptNameViewTotal>();
                    List<DateOnly> dateMinList = new List<DateOnly>();
                    List<DateOnly> dateMaxList = new List<DateOnly>();
                    List<string> listOrder = new List<string>();
                    foreach (var item in listDept)
                    {
                        var dept = modelDept.Where(x => x.DeptName.ToUpper().Equals(item)).ToList();
                        var actual = modelActual.Where(x => x.DeptName.ToUpper().Equals(item)).ToList();
                        var maintain = modelMaintain.Where(x => x.DeptName.ToUpper().Equals(item)).ToList();
                        listDeptOrder.Add(new DeptNameViewTotal()
                        {
                            Name = item,
                            Dept = dept,
                            Actual = actual,
                            Maintain = maintain,
                            Index = listMaster.FirstOrDefault(x => x.DeptName.ToUpper().Equals(item.ToUpper())).DeptOrder
                        });
                        if (dept != null)
                        {
                            dateMinList.AddRange(dept.Select(x => x.RecDate.First()).ToList());
                            dateMaxList.AddRange(dept.Select(x => x.RecDate.Last()).ToList());
                        }
                        if (actual != null)
                        {
                            dateMinList.AddRange(actual.Select(x => x.RecDate.First()).ToList());
                            dateMaxList.AddRange(actual.Select(x => x.RecDate.Last()).ToList());
                        }
                        if (maintain != null)
                        {
                            dateMinList.AddRange(maintain.Select(x => x.RecDate.First()).ToList());
                            dateMaxList.AddRange(maintain.Select(x => x.RecDate.Last()).ToList());
                        }
                    }
                    listDeptOrder = listDeptOrder.OrderBy(x => x.Index).ToList();
                    listOrder = listDeptOrder.Select(x => x.Name).ToList();

                    DateOnly dateMin = dateMinList.Min();
                    DateOnly dateMax = dateMaxList.Max();

                    List<DateOnly> dateList = new List<DateOnly>();

                    // Thêm các ngày từ ngày đầu đến ngày cuối vào List
                    for (DateOnly date = dateMin; date <= dateMax; date = date.AddDays(1))
                    {
                        dateList.Add(date);
                    }
                    List<List<string>> resultList = new List<List<string>>();

                    //var model2 = dateList.Skip((param.Page - 1) * param.RecordsPerPage).Take(param.RecordsPerPage).ToList();
                    Dictionary<string, int> listAccumulation = new Dictionary<string, int>();
                    foreach (var item in dateList)
                    {
                        List<string> r = new List<string>();
                        r.Add(item.ToString("dd-MMM-yy"));
                        r.Add(item.DayOfWeek.ToString().Substring(0, 3));
                        List<string> listTemp = new List<string>();
                        var planF = 0;
                        var planM = 0;
                        var planVc = 0;
                        var actualF = 0;
                        var actualM = 0;
                        var actualVc = 0;
                        var difF = 0;
                        var difM = 0;
                        var difVc = 0;
                        var maintain = 0;
                        var accumulation = 0;
                        for (int i = 0; i < listDeptOrder.Count(); i++)
                        {
                            var deptIJ = listDeptOrder[i].Dept.FirstOrDefault(x => x.Model.Equals("IJP MODEL"));
                            var deptLBP = listDeptOrder[i].Dept.FirstOrDefault(x => x.Model.Equals("LBP MODEL"));
                            var deptIJActual = listDeptOrder[i].Actual.FirstOrDefault(x => x.Model.Equals("IJP MODEL"));
                            var deptLBPActual = listDeptOrder[i].Actual.FirstOrDefault(x => x.Model.Equals("LBP MODEL"));
                            var deptIJMaintain = listDeptOrder[i].Maintain.FirstOrDefault(x => x.Model.Equals("IJP MODEL"));
                            var deptLBPMaintain = listDeptOrder[i].Maintain.FirstOrDefault(x => x.Model.Equals("LBP MODEL"));

                            var indexDept = deptIJ != null ? Array.IndexOf(deptIJ.RecDate, item) : -1;
                            var indexActual = deptIJActual != null ? Array.IndexOf(deptIJActual.RecDate, item) : -1;
                            var indexMaintain = deptIJMaintain != null ? Array.IndexOf(deptIJMaintain.RecDate, item) : -1;

                            var indexDept1 = deptLBP != null ? Array.IndexOf(deptLBP.RecDate, item) : -1;
                            var indexActual1 = deptLBPActual != null ? Array.IndexOf(deptLBPActual.RecDate, item) : -1;
                            var indexMaintain1 = deptLBPMaintain != null ? Array.IndexOf(deptLBPMaintain.RecDate, item) : -1;



                            var tempPlanF = (indexDept != -1 ? deptIJ.RecPlanF[indexDept] : 0) + (indexDept1 != -1 ? deptLBP.RecPlanF[indexDept1] : 0);
                            planF += tempPlanF;
                            listTemp.Add(tempPlanF != 0 ? tempPlanF.ToString() : "");
                            var tempPlanM = (indexDept != -1 ? deptIJ.RecPlanM[indexDept] : 0) + (indexDept1 != -1 ? deptLBP.RecPlanM[indexDept1] : 0);
                            planM += tempPlanM;
                            listTemp.Add(tempPlanM != 0 ? tempPlanM.ToString() : "");
                            var tempPlanVc = (indexDept != -1 ? deptIJ.RecPlanVc[indexDept] : 0) + (indexDept1 != -1 ? deptLBP.RecPlanVc[indexDept1] : 0);
                            planVc += tempPlanVc;
                            listTemp.Add(tempPlanVc != 0 ? tempPlanVc.ToString() : "");

                            var tempActualF = (indexActual != -1 ? deptIJActual.RecActualF[indexActual] : 0) + (indexActual1 != -1 ? deptLBPActual.RecActualF[indexActual1] : 0);
                            actualF += tempActualF;
                            listTemp.Add(tempActualF != 0 ? tempActualF.ToString() : "");
                            var tempActualM = (indexActual != -1 ? deptIJActual.RecActualM[indexActual] : 0) + (indexActual1 != -1 ? deptLBPActual.RecActualM[indexActual1] : 0);
                            actualM += tempActualM;
                            listTemp.Add(tempActualM != 0 ? tempActualM.ToString() : "");
                            var tempActualVc = (indexActual != -1 ? deptIJActual.RecActualVc[indexActual] : 0) + (indexActual1 != -1 ? deptLBPActual.RecActualVc[indexActual1] : 0);
                            actualVc += tempActualVc;
                            listTemp.Add(tempActualVc != 0 ? tempActualVc.ToString() : "");



                            var difFT = tempActualF - tempPlanF;
                            listTemp.Add(difFT != 0 ? difFT.ToString() : "");
                            difF += difFT;
                            var difMT = tempActualM - tempPlanM;
                            listTemp.Add(difMT != 0 ? difMT.ToString() : "");
                            difM += difMT;
                            var difVcT = tempActualVc - tempPlanVc;
                            listTemp.Add(difVcT != 0 ? difVcT.ToString() : "");
                            difVc += difVcT;


                            var tempMaintain = (indexMaintain != -1 ? deptIJMaintain.RecMaintain[indexMaintain] : 0) + (indexMaintain1 != -1 ? deptLBPMaintain.RecMaintain[indexMaintain1] : 0);
                            maintain += tempMaintain;
                            listTemp.Add(tempMaintain != 0 ? tempMaintain.ToString() : "");


                            var accBefore = 0;
                            try
                            {
                                accBefore = listAccumulation[item.AddDays(-1).ToString("dd-MMM-yy") + "-" + listDeptOrder[i].Name];
                            }
                            catch
                            {
                                accBefore = 0;
                            }
                            var accT = accBefore + (difFT + difMT + difVcT) - tempMaintain;
                            accumulation += accT;
                            listAccumulation.Add(item.ToString("dd-MMM-yy") + "-" + listDeptOrder[i].Name, accT);
                            listTemp.Add(accT != 0 ? accT.ToString() : "");
                            listTemp.Add((indexDept != -1 ? deptIJ.RecExplain[indexDept] : "") + " - " + (indexDept1 != -1 ? deptLBP.RecExplain[indexDept1] : ""));

                        }
                        r.Add(planF != 0 ? planF.ToString() : "");
                        r.Add(planM != 0 ? planM.ToString() : "");
                        r.Add(planVc != 0 ? planVc.ToString() : "");
                        r.Add(actualF != 0 ? actualF.ToString() : "");
                        r.Add(actualM != 0 ? actualM.ToString() : "");
                        r.Add(actualVc != 0 ? actualVc.ToString() : "");
                        r.Add(difF != 0 ? difF.ToString() : "");
                        r.Add(difM != 0 ? difM.ToString() : "");
                        r.Add(difVc != 0 ? difVc.ToString() : "");
                        r.Add(maintain != 0 ? maintain.ToString() : "");
                        r.Add(accumulation != 0 ? accumulation.ToString() : "");
                        r.Add("");
                        r.AddRange(listTemp);
                        resultList.Add(r);
                    }
                    var c = dateList.Count();
                    result.Product = param.Product;
                    result.ListDept = listOrder;
                    result.lstModel = resultList.Skip((param.Page - 1) * param.RecordsPerPage).Take(param.RecordsPerPage).ToList();
                    result.toRecord = (int)Math.Min(result.totalRecords, result.currentPage * result.recordPerPage);
                    result.totalPage = (int)Math.Ceiling((decimal)c / param.RecordsPerPage);
                    result.totalRecords = c;
                    result.recordPerPage = param.RecordsPerPage;
                    result.currentPage = param.Page;
                    result.fromRecord = c == 0 ? 0 : (result.currentPage - 1) * result.recordPerPage + 1;
                    return result;
                }
                else
                {
                    var result = new MpRecDeptActualIp3Model();
                    var lstResult = new List<MpRecDeptActualIp3View>();
                    var listMaster = context.MpRecMasterDepts.ToList();
                    var modelDept = context.MpRecDeptPlanIp2s.Where(x => x.Active == true && x.Status == 2).AsQueryable();
                    if (!param.Product.IsNullOrEmpty()) modelDept = modelDept.Where(x => x.Model == param.Product);
                    if (!param.PeriodId.IsNullOrEmpty()) modelDept = modelDept.Where(x => param.PeriodId.Contains(x.PeriodId.ToString()));
                    var modelActual = context.MpRecDeptActualIp3s.Where(x => x.Active == true).AsQueryable();
                    if (!param.Product.IsNullOrEmpty()) modelActual = modelActual.Where(x => x.Model == param.Product);
                    if (!param.PeriodId.IsNullOrEmpty()) modelActual = modelActual.Where(x => param.PeriodId.Contains(x.PeriodId.ToString()));
                    var modelMaintain = context.MpRecAllMaintainIp4s.Where(x => x.Active == true).AsQueryable();
                    if (!param.Product.IsNullOrEmpty()) modelMaintain = modelMaintain.Where(x => x.Model == param.Product);
                    if (!param.PeriodId.IsNullOrEmpty()) modelMaintain = modelMaintain.Where(x => param.PeriodId.Contains(x.PeriodId.ToString()));
                    List<string> listDept = new List<string>();
                    listDept.AddRange(modelDept.Select(x => x.DeptName.ToUpper()).ToList());
                    listDept.AddRange(modelActual.Select(x => x.DeptName.ToUpper()).ToList());
                    listDept.AddRange(modelMaintain.Select(x => x.DeptName.ToUpper()).ToList());
                    listDept = listDept.Distinct().ToList();
                    List<DeptNameView> listDeptOrder = new List<DeptNameView>();
                    List<DateOnly> dateMinList = new List<DateOnly>();
                    List<DateOnly> dateMaxList = new List<DateOnly>();
                    List<string> listOrder = new List<string>();
                    foreach (var item in listDept)
                    {
                        var dept = modelDept.FirstOrDefault(x => x.DeptName.ToUpper().Equals(item));
                        var actual = modelActual.FirstOrDefault(x => x.DeptName.ToUpper().Equals(item));
                        var maintain = modelMaintain.FirstOrDefault(x => x.DeptName.ToUpper().Equals(item));
                        listDeptOrder.Add(new DeptNameView()
                        {
                            Name = item,
                            Dept = dept,
                            Actual = actual,
                            Maintain = maintain,
                            Index = listMaster.FirstOrDefault(x => x.DeptName.ToUpper().Equals(item.ToUpper())).DeptOrder
                        });
                        if (dept != null)
                        {
                            dateMinList.Add(dept.RecDate.First());
                            dateMaxList.Add(dept.RecDate.Last());
                        }
                        if (actual != null)
                        {
                            dateMinList.Add(actual.RecDate.First());
                            dateMaxList.Add(actual.RecDate.Last());
                        }
                        if (maintain != null)
                        {
                            dateMinList.Add(maintain.RecDate.First());
                            dateMaxList.Add(maintain.RecDate.Last());
                        }
                    }
                    listDeptOrder = listDeptOrder.OrderBy(x => x.Index).ToList();
                    listOrder = listDeptOrder.Select(x => x.Name).ToList();

                    DateOnly dateMin = dateMinList.Min();
                    DateOnly dateMax = dateMaxList.Max();

                    List<DateOnly> dateList = new List<DateOnly>();

                    // Thêm các ngày từ ngày đầu đến ngày cuối vào List
                    for (DateOnly date = dateMin; date <= dateMax; date = date.AddDays(1))
                    {
                        dateList.Add(date);
                    }
                    List<List<string>> resultList = new List<List<string>>();

                    //var model2 = dateList.Skip((param.Page - 1) * param.RecordsPerPage).Take(param.RecordsPerPage).ToList();
                    Dictionary<string, int> listAccumulation = new Dictionary<string, int>();
                    foreach (var item in dateList)
                    {
                        List<string> r = new List<string>();
                        r.Add(item.ToString("dd-MMM-yy"));
                        r.Add(item.DayOfWeek.ToString().Substring(0, 3));
                        List<string> listTemp = new List<string>();
                        var planF = 0;
                        var planM = 0;
                        var planVc = 0;
                        var actualF = 0;
                        var actualM = 0;
                        var actualVc = 0;
                        var difF = 0;
                        var difM = 0;
                        var difVc = 0;
                        var maintain = 0;
                        var accumulation = 0;
                        for (int i = 0; i < listDeptOrder.Count(); i++)
                        {
                            var indexDept = listDeptOrder[i].Dept != null ? Array.IndexOf(listDeptOrder[i].Dept.RecDate, item) : -1;
                            var indexActual = listDeptOrder[i].Actual != null ? Array.IndexOf(listDeptOrder[i].Actual.RecDate, item) : -1;
                            var indexMaintain = listDeptOrder[i].Maintain != null ? Array.IndexOf(listDeptOrder[i].Maintain.RecDate, item) : -1;

                            if (indexDept != -1)
                            {
                                listTemp.Add(listDeptOrder[i].Dept.RecPlanF[indexDept] != 0 ? listDeptOrder[i].Dept.RecPlanF[indexDept].ToString() : "");
                                planF += listDeptOrder[i].Dept.RecPlanF[indexDept];
                                listTemp.Add(listDeptOrder[i].Dept.RecPlanM[indexDept] != 0 ? listDeptOrder[i].Dept.RecPlanM[indexDept].ToString() : "");
                                planM += listDeptOrder[i].Dept.RecPlanM[indexDept];
                                listTemp.Add(listDeptOrder[i].Dept.RecPlanVc[indexDept] != 0 ? listDeptOrder[i].Dept.RecPlanVc[indexDept].ToString() : "");
                                planVc += listDeptOrder[i].Dept.RecPlanVc[indexDept];
                            }
                            else
                            {
                                listTemp.Add("");
                                listTemp.Add("");
                                listTemp.Add("");
                            }
                            if (indexActual != -1)
                            {
                                listTemp.Add(listDeptOrder[i].Actual.RecActualF[indexActual] != 0 ? listDeptOrder[i].Actual.RecActualF[indexActual].ToString() : "");
                                actualF += listDeptOrder[i].Actual.RecActualF[indexActual];
                                listTemp.Add(listDeptOrder[i].Actual.RecActualM[indexActual] != 0 ? listDeptOrder[i].Actual.RecActualM[indexActual].ToString() : "");
                                actualM += listDeptOrder[i].Actual.RecActualM[indexActual];
                                listTemp.Add(listDeptOrder[i].Actual.RecActualVc[indexActual] != 0 ? listDeptOrder[i].Actual.RecActualVc[indexActual].ToString() : "");
                                actualVc += listDeptOrder[i].Actual.RecActualVc[indexActual];
                            }
                            else
                            {
                                listTemp.Add("");
                                listTemp.Add("");
                                listTemp.Add("");
                            }

                            var difFT = (indexActual != -1 ? listDeptOrder[i].Actual.RecActualF[indexActual] : 0) - (indexDept != -1 ? listDeptOrder[i].Dept.RecPlanF[indexDept] : 0);
                            listTemp.Add(difFT != 0 ? difFT.ToString() : "");
                            difF += difFT;
                            var difMT = (indexActual != -1 ? listDeptOrder[i].Actual.RecActualM[indexActual] : 0) - (indexDept != -1 ? listDeptOrder[i].Dept.RecPlanM[indexDept] : 0);
                            listTemp.Add(difMT != 0 ? difMT.ToString() : "");
                            difM += difMT;
                            var difVcT = (indexActual != -1 ? listDeptOrder[i].Actual.RecActualVc[indexActual] : 0) - (indexDept != -1 ? listDeptOrder[i].Dept.RecPlanVc[indexDept] : 0);
                            listTemp.Add(difVcT != 0 ? difVcT.ToString() : "");
                            difVc += difVcT;

                            var main = indexMaintain != -1 ? listDeptOrder[i].Maintain.RecMaintain[indexMaintain] : 0;
                            if (indexMaintain != -1)
                            {
                                listTemp.Add(main != 0 ? main.ToString() : "");
                                maintain += main;
                            }
                            else
                            {
                                listTemp.Add("");
                            }

                            var accBefore = 0;
                            try
                            {
                                accBefore = listAccumulation[item.AddDays(-1).ToString("dd-MMM-yy") + "-" + listDeptOrder[i].Name];
                            }
                            catch
                            {
                                accBefore = 0;
                            }
                            var accT = accBefore + (difFT + difMT + difVcT) - main;
                            accumulation += accT;
                            listAccumulation.Add(item.ToString("dd-MMM-yy") + "-" + listDeptOrder[i].Name, accT);
                            listTemp.Add(accT != 0 ? accT.ToString() : "");
                            listTemp.Add(indexDept != -1 ? listDeptOrder[i].Dept.RecExplain[indexDept] : "");

                        }
                        r.Add(planF != 0 ? planF.ToString() : "");
                        r.Add(planM != 0 ? planM.ToString() : "");
                        r.Add(planVc != 0 ? planVc.ToString() : "");
                        r.Add(actualF != 0 ? actualF.ToString() : "");
                        r.Add(actualM != 0 ? actualM.ToString() : "");
                        r.Add(actualVc != 0 ? actualVc.ToString() : "");
                        r.Add(difF != 0 ? difF.ToString() : "");
                        r.Add(difM != 0 ? difM.ToString() : "");
                        r.Add(difVc != 0 ? difVc.ToString() : "");
                        r.Add(maintain != 0 ? maintain.ToString() : "");
                        r.Add(accumulation != 0 ? accumulation.ToString() : "");
                        r.Add("");
                        r.AddRange(listTemp);
                        resultList.Add(r);
                    }
                    var c = dateList.Count();
                    result.Product = param.Product;
                    result.ListDept = listOrder;
                    result.lstModel = resultList.Skip((param.Page - 1) * param.RecordsPerPage).Take(param.RecordsPerPage).ToList();
                    result.toRecord = (int)Math.Min(result.totalRecords, result.currentPage * result.recordPerPage);
                    result.totalPage = (int)Math.Ceiling((decimal)c / param.RecordsPerPage);
                    result.totalRecords = c;
                    result.recordPerPage = param.RecordsPerPage;
                    result.currentPage = param.Page;
                    result.fromRecord = c == 0 ? 0 : (result.currentPage - 1) * result.recordPerPage + 1;
                    return result;
                }



            }
            catch (Exception)
            {
                return new MpRecDeptActualIp3Model();
            }
        }
        private UserClaims GetCurrentUser()
        {
            UserClaims userClaims = new UserClaims();
            var identity = HttpContext.User.Identity as ClaimsIdentity;
            if (identity != null)
            {
                userClaims.UserName = identity.FindFirst("user_name") == null ? "Undefined" : identity.FindFirst("user_name").Value;
                userClaims.Id = identity.FindFirst("id") == null ? "Undefined" : identity.FindFirst("id").Value;
                userClaims.DeptId = identity.FindFirst("dept_id") == null ? "" : identity.FindFirst("dept_id").Value;
                userClaims.Factories = identity.FindFirst("factIds") == null ? "" : identity.FindFirst("factIds").Value;
                userClaims.CostCenter = identity.FindFirst("cost_center") == null ? "" : identity.FindFirst("cost_center").Value;
                userClaims.FullName = identity.FindFirst("full_name") == null ? "" : identity.FindFirst("full_name").Value;
                userClaims.Departments = identity.FindFirst("dept") == null ? "" : identity.FindFirst("dept").Value;
                userClaims.Grade = identity.FindFirst("grade") == null ? "" : identity.FindFirst("grade").Value;
                userClaims.IsAdmin = identity.FindFirst("isAdmin") == null ? "false" : identity.FindFirst("isAdmin").Value;
                userClaims.Email = identity.FindFirst("email") == null ? "" : identity.FindFirst("email").Value;
                userClaims.IsPdc = identity.FindFirst("isPdc") == null ? "false" : identity.FindFirst("isPdc").Value;
            }
            return userClaims;
        }
        [HttpPost("get-recruitment-output-weekly")]
        public MpRecDeptActualIp3Model GetRecruitmentOutputWeekly([FromBody] OutputWeeklyParam param)
        {
            try
            {


                //var result = new MpRecDeptActualIp3Model();
                //var lstResult = new List<MpRecDeptActualIp3View>();
                //var listMaster = context.MpRecMasterDepts.ToList();
                //var modelDept = context.MpRecDeptPlanIp2s.Where(x => x.Active == true).AsQueryable();
                //if (!param.Product.IsNullOrEmpty()) modelDept = modelDept.Where(x => x.Model == param.Product);
                //if (!param.Period.IsNullOrEmpty()) modelDept = modelDept.Where(x => x.PeriodId == Guid.Parse(param.Period));
                //var modelActual = context.MpRecDeptActualIp3s.Where(x => x.Active == true).AsQueryable();
                //if (!param.Product.IsNullOrEmpty()) modelActual = modelActual.Where(x => x.Model == param.Product);
                //if (!param.Period.IsNullOrEmpty()) modelActual = modelActual.Where(x => x.PeriodId == Guid.Parse(param.Period));
                //var modelMaintain = context.MpRecAllMaintainIp4s.Where(x => x.Active == true).AsQueryable();
                //if (!param.Product.IsNullOrEmpty()) modelMaintain = modelMaintain.Where(x => x.Model == param.Product);
                //if (!param.Period.IsNullOrEmpty()) modelMaintain = modelMaintain.Where(x => x.PeriodId == Guid.Parse(param.Period));
                //List<string> listDept = new List<string>();
                //listDept.AddRange(modelDept.Select(x => x.DeptName.ToUpper()).ToList());
                //listDept.AddRange(modelActual.Select(x => x.DeptName.ToUpper()).ToList());
                //listDept.AddRange(modelMaintain.Select(x => x.DeptName.ToUpper()).ToList());
                //listDept = listDept.Distinct().ToList();
                //List<DeptNameView> listDeptOrder = new List<DeptNameView>();
                //List<DateOnly> dateMinList = new List<DateOnly>();
                //List<DateOnly> dateMaxList = new List<DateOnly>();
                //List<string> listOrder = new List<string>();
                //foreach (var item in listDept)
                //{
                //    var dept = modelDept.FirstOrDefault(x => x.DeptName.ToUpper().Equals(item));
                //    var actual = modelActual.FirstOrDefault(x => x.DeptName.ToUpper().Equals(item));
                //    var maintain = modelMaintain.FirstOrDefault(x => x.DeptName.ToUpper().Equals(item));
                //    listDeptOrder.Add(new DeptNameView()
                //    {
                //        Name = item,
                //        Dept = dept,
                //        Actual = actual,
                //        Maintain = maintain,
                //        Index = listMaster.FirstOrDefault(x => x.DeptName.ToUpper().Equals(item.ToUpper())).DeptOrder
                //    });
                //    if (dept != null)
                //    {
                //        dateMinList.Add(dept.RecDate.First());
                //        dateMaxList.Add(dept.RecDate.Last());
                //    }
                //    if (actual != null)
                //    {
                //        dateMinList.Add(actual.RecDate.First());
                //        dateMaxList.Add(actual.RecDate.Last());
                //    }
                //    if (maintain != null)
                //    {
                //        dateMinList.Add(maintain.RecDate.First());
                //        dateMaxList.Add(maintain.RecDate.Last());
                //    }
                //}
                //listDeptOrder = listDeptOrder.OrderBy(x => x.Index).ToList();
                //listOrder = listDeptOrder.Select(x => x.Name).ToList();

                //DateOnly dateMin = dateMinList.Min();
                //DateOnly dateMax = dateMaxList.Max();

                //List<DateOnly> dateList = new List<DateOnly>();

                //// Thêm các ngày từ ngày đầu đến ngày cuối vào List
                //for (DateOnly date = dateMin; date <= dateMax; date = date.AddDays(1))
                //{
                //    dateList.Add(date);
                //}
                //List<List<string>> resultList = new List<List<string>>();

                ////var model2 = dateList.Skip((param.Page - 1) * param.RecordsPerPage).Take(param.RecordsPerPage).ToList();
                //Dictionary<string, int> listAccumulation = new Dictionary<string, int>();
                //foreach (var item in dateList)
                //{
                //    List<string> r = new List<string>();
                //    r.Add(item.ToString("dd-MMM-yy"));
                //    r.Add(item.DayOfWeek.ToString().Substring(0, 3));
                //    List<string> listTemp = new List<string>();
                //    var planF = 0;
                //    var planM = 0;
                //    var planVc = 0;
                //    var actualF = 0;
                //    var actualM = 0;
                //    var actualVc = 0;
                //    var difF = 0;
                //    var difM = 0;
                //    var difVc = 0;
                //    var maintain = 0;
                //    var accumulation = 0;
                //    for (int i = 0; i < listDeptOrder.Count(); i++)
                //    {
                //        var indexDept = listDeptOrder[i].Dept != null ? Array.IndexOf(listDeptOrder[i].Dept.RecDate, item) : -1;
                //        var indexActual = listDeptOrder[i].Actual != null ? Array.IndexOf(listDeptOrder[i].Actual.RecDate, item) : -1;
                //        var indexMaintain = listDeptOrder[i].Maintain != null ? Array.IndexOf(listDeptOrder[i].Maintain.RecDate, item) : -1;

                //        if (indexDept != -1)
                //        {
                //            listTemp.Add(listDeptOrder[i].Dept.RecPlanF[indexDept] != 0 ? listDeptOrder[i].Dept.RecPlanF[indexDept].ToString() : "");
                //            planF += listDeptOrder[i].Dept.RecPlanF[indexDept];
                //            listTemp.Add(listDeptOrder[i].Dept.RecPlanM[indexDept] != 0 ? listDeptOrder[i].Dept.RecPlanM[indexDept].ToString() : "");
                //            planM += listDeptOrder[i].Dept.RecPlanM[indexDept];
                //            listTemp.Add(listDeptOrder[i].Dept.RecPlanVc[indexDept] != 0 ? listDeptOrder[i].Dept.RecPlanVc[indexDept].ToString() : "");
                //            planVc += listDeptOrder[i].Dept.RecPlanVc[indexDept];
                //        }
                //        else
                //        {
                //            listTemp.Add("");
                //            listTemp.Add("");
                //            listTemp.Add("");
                //        }
                //        if (indexActual != -1)
                //        {
                //            listTemp.Add(listDeptOrder[i].Actual.RecActualF[indexActual] != 0 ? listDeptOrder[i].Actual.RecActualF[indexActual].ToString() : "");
                //            actualF += listDeptOrder[i].Actual.RecActualF[indexActual];
                //            listTemp.Add(listDeptOrder[i].Actual.RecActualM[indexActual] != 0 ? listDeptOrder[i].Actual.RecActualM[indexActual].ToString() : "");
                //            actualM += listDeptOrder[i].Actual.RecActualM[indexActual];
                //            listTemp.Add(listDeptOrder[i].Actual.RecActualVc[indexActual] != 0 ? listDeptOrder[i].Actual.RecActualVc[indexActual].ToString() : "");
                //            actualVc += listDeptOrder[i].Actual.RecActualVc[indexActual];
                //        }
                //        else
                //        {
                //            listTemp.Add("");
                //            listTemp.Add("");
                //            listTemp.Add("");
                //        }

                //        var difFT = (indexActual != -1 ? listDeptOrder[i].Actual.RecActualF[indexActual] : 0) - (indexDept != -1 ? listDeptOrder[i].Dept.RecPlanF[indexDept] : 0);
                //        listTemp.Add(difFT != 0 ? difFT.ToString() : "");
                //        difF += difFT;
                //        var difMT = (indexActual != -1 ? listDeptOrder[i].Actual.RecActualM[indexActual] : 0) - (indexDept != -1 ? listDeptOrder[i].Dept.RecPlanM[indexDept] : 0);
                //        listTemp.Add(difMT != 0 ? difMT.ToString() : "");
                //        difM += difMT;
                //        var difVcT = (indexActual != -1 ? listDeptOrder[i].Actual.RecActualVc[indexActual] : 0) - (indexDept != -1 ? listDeptOrder[i].Dept.RecPlanVc[indexDept] : 0);
                //        listTemp.Add(difVcT != 0 ? difVcT.ToString() : "");
                //        difVc += difVcT;

                //        var main = indexMaintain != -1 ? listDeptOrder[i].Maintain.RecMaintain[indexMaintain] : 0;
                //        if (indexMaintain != -1)
                //        {
                //            listTemp.Add(main != 0 ? main.ToString() : "");
                //            maintain += main;
                //        }
                //        else
                //        {
                //            listTemp.Add("");
                //        }

                //        var accBefore = 0;
                //        try
                //        {
                //            accBefore = listAccumulation[item.AddDays(-1).ToString("dd-MMM-yy") + "-" + listDeptOrder[i].Name];
                //        }
                //        catch
                //        {
                //            accBefore = 0;
                //        }
                //        var accT = accBefore + (difFT + difMT + difVcT) - main;
                //        accumulation += accT;
                //        listAccumulation.Add(item.ToString("dd-MMM-yy") + "-" + listDeptOrder[i].Name, accT);
                //        listTemp.Add(accT != 0 ? accT.ToString() : "");
                //        listTemp.Add(indexDept != -1 ? listDeptOrder[i].Dept.RecExplain[indexDept] : "");

                //    }
                //    r.Add(planF != 0 ? planF.ToString() : "");
                //    r.Add(planM != 0 ? planM.ToString() : "");
                //    r.Add(planVc != 0 ? planVc.ToString() : "");
                //    r.Add(actualF != 0 ? actualF.ToString() : "");
                //    r.Add(actualM != 0 ? actualM.ToString() : "");
                //    r.Add(actualVc != 0 ? actualVc.ToString() : "");
                //    r.Add(difF != 0 ? difF.ToString() : "");
                //    r.Add(difM != 0 ? difM.ToString() : "");
                //    r.Add(difVc != 0 ? difVc.ToString() : "");
                //    r.Add(maintain != 0 ? maintain.ToString() : "");
                //    r.Add(accumulation != 0 ? accumulation.ToString() : "");
                //    r.Add("");
                //    r.AddRange(listTemp);
                //    resultList.Add(r);
                //}
                var result = new MpRecDeptActualIp3Model();
                var lstResult = new List<MpRecDeptActualIp3View>();
                var listMaster = context.MpRecMasterDepts.ToList();
                var modelDept = context.MpRecDeptPlanIp2s.Where(x => x.Active == true && x.Status == 2).AsQueryable();
                if (!param.Product.IsNullOrEmpty()) modelDept = modelDept.Where(x => x.Model.Equals("IJP MODEL") || x.Model.Equals("LBP MODEL"));
                if (!param.Period.IsNullOrEmpty()) modelDept = modelDept.Where(x => param.Period.Contains(x.PeriodId.ToString()));
                var modelActual = context.MpRecDeptActualIp3s.Where(x => x.Active == true).AsQueryable();
                if (!param.Product.IsNullOrEmpty()) modelActual = modelActual.Where(x => x.Model.Equals("IJP MODEL") || x.Model.Equals("LBP MODEL"));
                if (!param.Period.IsNullOrEmpty()) modelActual = modelActual.Where(x => param.Period.Contains(x.PeriodId.ToString()));
                var modelMaintain = context.MpRecAllMaintainIp4s.Where(x => x.Active == true).AsQueryable();
                if (!param.Product.IsNullOrEmpty()) modelMaintain = modelMaintain.Where(x => x.Model.Equals("IJP MODEL") || x.Model.Equals("LBP MODEL"));
                if (!param.Period.IsNullOrEmpty()) modelMaintain = modelMaintain.Where(x => param.Period.Contains(x.PeriodId.ToString()));
                List<string> listDept = new List<string>();
                listDept.AddRange(modelDept.Select(x => x.DeptName.ToUpper()).ToList());
                listDept.AddRange(modelActual.Select(x => x.DeptName.ToUpper()).ToList());
                listDept.AddRange(modelMaintain.Select(x => x.DeptName.ToUpper()).ToList());
                listDept = listDept.Distinct().ToList();
                List<DeptNameViewTotal> listDeptOrder = new List<DeptNameViewTotal>();
                List<DateOnly> dateMinList = new List<DateOnly>();
                List<DateOnly> dateMaxList = new List<DateOnly>();
                List<string> listOrder = new List<string>();
                foreach (var item in listDept)
                {
                    var dept = modelDept.Where(x => x.DeptName.ToUpper().Equals(item)).ToList();
                    var actual = modelActual.Where(x => x.DeptName.ToUpper().Equals(item)).ToList();
                    var maintain = modelMaintain.Where(x => x.DeptName.ToUpper().Equals(item)).ToList();
                    listDeptOrder.Add(new DeptNameViewTotal()
                    {
                        Name = item,
                        Dept = dept,
                        Actual = actual,
                        Maintain = maintain,
                        Index = listMaster.FirstOrDefault(x => x.DeptName.ToUpper().Equals(item.ToUpper())).DeptOrder
                    });
                    if (dept != null)
                    {
                        dateMinList.AddRange(dept.Select(x => x.RecDate.First()).ToList());
                        dateMaxList.AddRange(dept.Select(x => x.RecDate.Last()).ToList());
                    }
                    if (actual != null)
                    {
                        dateMinList.AddRange(actual.Select(x => x.RecDate.First()).ToList());
                        dateMaxList.AddRange(actual.Select(x => x.RecDate.Last()).ToList());
                    }
                    if (maintain != null)
                    {
                        dateMinList.AddRange(maintain.Select(x => x.RecDate.First()).ToList());
                        dateMaxList.AddRange(maintain.Select(x => x.RecDate.Last()).ToList());
                    }
                }
                listDeptOrder = listDeptOrder.OrderBy(x => x.Index).ToList();
                listOrder = listDeptOrder.Select(x => x.Name).ToList();

                DateOnly dateMin = dateMinList.Min();
                DateOnly dateMax = dateMaxList.Max();

                List<DateOnly> dateList = new List<DateOnly>();

                // Thêm các ngày từ ngày đầu đến ngày cuối vào List
                for (DateOnly date = dateMin; date <= dateMax; date = date.AddDays(1))
                {
                    dateList.Add(date);
                }
                List<List<string>> resultList = new List<List<string>>();

                //var model2 = dateList.Skip((param.Page - 1) * param.RecordsPerPage).Take(param.RecordsPerPage).ToList();
                Dictionary<string, int> listAccumulation = new Dictionary<string, int>();
                foreach (var item in dateList)
                {
                    List<string> r = new List<string>();
                    r.Add(item.ToString("dd-MMM-yy"));
                    r.Add(item.DayOfWeek.ToString().Substring(0, 3));
                    List<string> listTemp = new List<string>();
                    var planF = 0;
                    var planM = 0;
                    var planVc = 0;
                    var actualF = 0;
                    var actualM = 0;
                    var actualVc = 0;
                    var difF = 0;
                    var difM = 0;
                    var difVc = 0;
                    var maintain = 0;
                    var accumulation = 0;
                    for (int i = 0; i < listDeptOrder.Count(); i++)
                    {
                        var deptIJ = listDeptOrder[i].Dept.FirstOrDefault(x => x.Model.Equals("IJP MODEL"));
                        var deptLBP = listDeptOrder[i].Dept.FirstOrDefault(x => x.Model.Equals("LBP MODEL"));
                        var deptIJActual = listDeptOrder[i].Actual.FirstOrDefault(x => x.Model.Equals("IJP MODEL"));
                        var deptLBPActual = listDeptOrder[i].Actual.FirstOrDefault(x => x.Model.Equals("LBP MODEL"));
                        var deptIJMaintain = listDeptOrder[i].Maintain.FirstOrDefault(x => x.Model.Equals("IJP MODEL"));
                        var deptLBPMaintain = listDeptOrder[i].Maintain.FirstOrDefault(x => x.Model.Equals("LBP MODEL"));

                        var indexDept = deptIJ != null ? Array.IndexOf(deptIJ.RecDate, item) : -1;
                        var indexActual = deptIJActual != null ? Array.IndexOf(deptIJActual.RecDate, item) : -1;
                        var indexMaintain = deptIJMaintain != null ? Array.IndexOf(deptIJMaintain.RecDate, item) : -1;

                        var indexDept1 = deptLBP != null ? Array.IndexOf(deptLBP.RecDate, item) : -1;
                        var indexActual1 = deptLBPActual != null ? Array.IndexOf(deptLBPActual.RecDate, item) : -1;
                        var indexMaintain1 = deptLBPMaintain != null ? Array.IndexOf(deptLBPMaintain.RecDate, item) : -1;



                        var tempPlanF = (indexDept != -1 ? deptIJ.RecPlanF[indexDept] : 0) + (indexDept1 != -1 ? deptLBP.RecPlanF[indexDept1] : 0);
                        planF += tempPlanF;
                        listTemp.Add(tempPlanF != 0 ? tempPlanF.ToString() : "");
                        var tempPlanM = (indexDept != -1 ? deptIJ.RecPlanM[indexDept] : 0) + (indexDept1 != -1 ? deptLBP.RecPlanM[indexDept1] : 0);
                        planM += tempPlanM;
                        listTemp.Add(tempPlanM != 0 ? tempPlanM.ToString() : "");
                        var tempPlanVc = (indexDept != -1 ? deptIJ.RecPlanVc[indexDept] : 0) + (indexDept1 != -1 ? deptLBP.RecPlanVc[indexDept1] : 0);
                        planVc += tempPlanVc;
                        listTemp.Add(tempPlanVc != 0 ? tempPlanVc.ToString() : "");

                        var tempActualF = (indexActual != -1 ? deptIJActual.RecActualF[indexActual] : 0) + (indexActual1 != -1 ? deptLBPActual.RecActualF[indexActual1] : 0);
                        actualF += tempActualF;
                        listTemp.Add(tempActualF != 0 ? tempActualF.ToString() : "");
                        var tempActualM = (indexActual != -1 ? deptIJActual.RecActualM[indexActual] : 0) + (indexActual1 != -1 ? deptLBPActual.RecActualM[indexActual1] : 0);
                        actualM += tempActualM;
                        listTemp.Add(tempActualM != 0 ? tempActualM.ToString() : "");
                        var tempActualVc = (indexActual != -1 ? deptIJActual.RecActualVc[indexActual] : 0) + (indexActual1 != -1 ? deptLBPActual.RecActualVc[indexActual1] : 0);
                        actualVc += tempActualVc;
                        listTemp.Add(tempActualVc != 0 ? tempActualVc.ToString() : "");



                        var difFT = tempActualF - tempPlanF;
                        listTemp.Add(difFT != 0 ? difFT.ToString() : "");
                        difF += difFT;
                        var difMT = tempActualM - tempPlanM;
                        listTemp.Add(difMT != 0 ? difMT.ToString() : "");
                        difM += difMT;
                        var difVcT = tempActualVc - tempPlanVc;
                        listTemp.Add(difVcT != 0 ? difVcT.ToString() : "");
                        difVc += difVcT;


                        var tempMaintain = (indexMaintain != -1 ? deptIJMaintain.RecMaintain[indexMaintain] : 0) + (indexMaintain1 != -1 ? deptLBPMaintain.RecMaintain[indexMaintain1] : 0);
                        maintain += tempMaintain;
                        listTemp.Add(tempMaintain != 0 ? tempMaintain.ToString() : "");


                        var accBefore = 0;
                        try
                        {
                            accBefore = listAccumulation[item.AddDays(-1).ToString("dd-MMM-yy") + "-" + listDeptOrder[i].Name];
                        }
                        catch
                        {
                            accBefore = 0;
                        }
                        var accT = accBefore + (difFT + difMT + difVcT) - tempMaintain;
                        accumulation += accT;
                        listAccumulation.Add(item.ToString("dd-MMM-yy") + "-" + listDeptOrder[i].Name, accT);
                        listTemp.Add(accT != 0 ? accT.ToString() : "");
                        listTemp.Add((indexDept != -1 ? deptIJ.RecExplain[indexDept] : "") + " - " + (indexDept1 != -1 ? deptLBP.RecExplain[indexDept1] : ""));

                    }
                    r.Add(planF != 0 ? planF.ToString() : "");
                    r.Add(planM != 0 ? planM.ToString() : "");
                    r.Add(planVc != 0 ? planVc.ToString() : "");
                    r.Add(actualF != 0 ? actualF.ToString() : "");
                    r.Add(actualM != 0 ? actualM.ToString() : "");
                    r.Add(actualVc != 0 ? actualVc.ToString() : "");
                    r.Add(difF != 0 ? difF.ToString() : "");
                    r.Add(difM != 0 ? difM.ToString() : "");
                    r.Add(difVc != 0 ? difVc.ToString() : "");
                    r.Add(maintain != 0 ? maintain.ToString() : "");
                    r.Add(accumulation != 0 ? accumulation.ToString() : "");
                    r.Add("");
                    r.AddRange(listTemp);
                    resultList.Add(r);
                }
                if (param.Type.Equals("Weekly"))
                {
                    DateTime startDate = DateTime.ParseExact(param.FromDate, "dd-MM-yyyy", null);
                    DateTime endDate = DateTime.ParseExact(param.ToDate, "dd-MM-yyyy", null);
                    bool first = true;
                    List<int> listPlan = new List<int>();
                    List<List<string>> listResult = new List<List<string>>();
                    for (DateTime date = startDate; date <= endDate; date = date.AddDays(1))
                    {
                        List<string> listTemp = new List<string>();
                        if (first)
                        {
                            for (int i = 1; i < 7; i++)
                            {
                                if (date.AddDays(i).DayOfWeek == DayOfWeek.Sunday)
                                {
                                    var data = resultList.FirstOrDefault(x => x.Contains(date.AddDays(i).ToString("dd-MMM-yy")));
                                    listPlan.Add(Math.Abs(int.Parse(data[12])));
                                    first = false;
                                    break;
                                }

                            }
                            listTemp.Add(date.ToString("dd-MMM"));
                            listTemp.Add(listPlan.Last().ToString());
                            listTemp.Add(listPlan.Sum().ToString());
                            listResult.Add(listTemp);
                        }
                        else
                        {
                            if (date.DayOfWeek == DayOfWeek.Monday || date.Day == 1)
                            {
                                int sum = 0;
                                bool checkAdd = true;
                                for (int i = 0; i < 7; i++)
                                {
                                    if (date.AddDays(i).DayOfWeek != DayOfWeek.Sunday)
                                    {
                                        var data = resultList.FirstOrDefault(x => x.Contains(date.AddDays(i).ToString("dd-MMM-yy")));
                                        if (data != null)
                                        {
                                            sum += (!data[2].Equals("") ? int.Parse(data[2]) : 0) + (!data[3].Equals("") ? int.Parse(data[3]) : 0) + (!data[4].Equals("") ? int.Parse(data[4]) : 0);

                                        }
                                        else
                                        {
                                            listPlan.Add(sum);
                                            checkAdd = false;
                                            break;
                                        }

                                    }
                                    else
                                    {
                                        listPlan.Add(sum);
                                        checkAdd = false;
                                        break;
                                    }

                                }
                                if (checkAdd) { listPlan.Add(sum); };
                                listTemp.Add(date.ToString("dd-MMM"));
                                listTemp.Add(listPlan.Last().ToString());
                                listTemp.Add(listPlan.Sum().ToString());
                                listResult.Add(listTemp);
                            }
                        }

                    }



                    return new MpRecDeptActualIp3Model()
                    {
                        lstModel = listResult
                    };
                }
                else
                {
                    DateTime startDate = DateTime.ParseExact(param.FromDate, "MM-yyyy", null);
                    DateTime endDate = DateTime.ParseExact(param.ToDate, "MM-yyyy", null);
                    bool first = true;
                    List<int> listPlan = new List<int>();
                    List<List<string>> listResult = new List<List<string>>();
                    for (DateTime date = startDate; date <= endDate; date = date.AddMonths(1))
                    {
                        List<string> listTemp = new List<string>();
                        var nextMonth = date.AddMonths(1);
                        var lastDateMonth = nextMonth.AddDays(-1);
                        if (first)
                        {
                            var data = resultList.FirstOrDefault(x => x.Contains(lastDateMonth.ToString("dd-MMM-yy")));
                            listPlan.Add(Math.Abs(int.Parse(data[12])));
                            first = false;
                            listTemp.Add(date.ToString("MMM-yy"));
                            listTemp.Add(listPlan.Last().ToString());
                            listTemp.Add(listPlan.Sum().ToString());
                            listResult.Add(listTemp);
                        }
                        else
                        {

                            int sum = 0;
                            bool checkAdd = true;
                            for (int i = 0; i < 31; i++)
                            {
                                if (date.AddDays(i).Date <= lastDateMonth.Date)
                                {
                                    var data = resultList.FirstOrDefault(x => x.Contains(date.AddDays(i).ToString("dd-MMM-yy")));
                                    if (data != null)
                                    {
                                        sum += (!data[2].Equals("") ? int.Parse(data[2]) : 0) + (!data[3].Equals("") ? int.Parse(data[3]) : 0) + (!data[4].Equals("") ? int.Parse(data[4]) : 0);

                                    }
                                    else
                                    {
                                        listPlan.Add(sum);
                                        checkAdd = false;
                                        break;
                                    }

                                }
                                else
                                {
                                    listPlan.Add(sum);
                                    checkAdd = false;
                                    break;
                                }

                            }
                            if (checkAdd) { listPlan.Add(sum); };
                            listTemp.Add(date.ToString("MMM-yy"));
                            listTemp.Add(listPlan.Last().ToString());
                            listTemp.Add(listPlan.Sum().ToString());
                            listResult.Add(listTemp);
                        }

                    }



                    return new MpRecDeptActualIp3Model()
                    {
                        lstModel = listResult
                    };
                }


            }
            catch (Exception)
            {

                return new MpRecDeptActualIp3Model();
            }
        }
        private List<string> SumArrays(List<List<string>> arr)
        {
            if (arr.Count == 0)
            {
                return new List<string>();
            }

            List<string> result = new List<string>(arr[0]);

            for (int i = 1; i < arr.Count; i++)
            {
                for (int j = 0; j < arr[i].Count; j++)
                {
                    result[j] = (result[j].StringAbleToDouble() + (arr[i][j]).StringAbleToDouble()).ToString();
                }
            }

            return result;
        }

        //gửi mail khi reject
        private bool SendMailRejectd(string dept, string reason, string rejectBy, List<string> lstReceive, string receiver, string link)
        {
            try
            {
                string txtContent = "<span style = 'font-weight: bold;'> Dear Mrs/Mr." + receiver + "</span><br><br>" +
                "<span>Your request approve/confirm manpower of </span>: <span style = 'font-weight: bold;'>" + dept + " was returned </span><br>" +
                "<span>Reason</span>: <span style = 'font-weight: bold;'>" + reason + "</span><br>" +
                "<span>Returned by</span>: <span style = 'font-weight: bold;'>" + rejectBy + "</span><br>" +
                "<span>Returned date</span>: <span style = 'font-weight: bold;'>" + DateTime.Now.ToString("dd-MMM-yyyy") + "</span><br>" +
                "<span>You can check it at: " + link + "</span><br><br>" +
                "";

                email.Initial(lstReceive,
                    "[PSI-System] Returned request manpower",
                    txtContent);
                return false;
            }
            catch
            {
                return false;
            }
        }
        private bool SendMailRejectRec(string dept, string reason, string rejectBy, List<string> lstReceive, string receiver, string link)
        {
            try
            {
                string txtContent = "<span style = 'font-weight: bold;'> Dear Mrs/Mr." + receiver + "</span><br><br>" +
                "<span>Your request for plan recruitment of </span>: <span style = 'font-weight: bold;'>" + dept + " was returned </span><br>" +
                "<span>Reason</span>: <span style = 'font-weight: bold;'>" + reason + "</span><br>" +
                "<span>Returned by</span>: <span style = 'font-weight: bold;'>" + rejectBy + "</span><br>" +
                "<span>Returned date</span>: <span style = 'font-weight: bold;'>" + DateTime.Now.ToString("dd-MMM-yyyy") + "</span><br>" +
                "<span>You can check it at: <a href=\"" + link + "\">Click here</a></span><br><br>" +
                "";

                email.Initial(lstReceive,
                    "[PSI-System] Rejected recruitment plan request",
                    txtContent);
                return false;
            }
            catch
            {
                return false;
            }
        }
        //gửi mail báo hoàn thành approve
        private bool SendMailApproved(string dept, string approveBy, List<string> lstReceive, string receiver, string link)
        {
            try
            {
                string txtContent = "<span style = 'font-weight: bold;'> Dear Mrs/Mr." + receiver + "</span><br><br>" +
                "<span>Your request approve for manpower of </span>: <span style = 'font-weight: bold;'>" + dept + " was confirmed </span><br>" +
                "<span>Confirm by</span>: <span style = 'font-weight: bold;'>" + approveBy + "</span><br>" +
                "<span>Confirm date</span>: <span style = 'font-weight: bold;'>" + DateTime.Now.ToString("dd-MMM-yyyy") + "</span><br>" +
                "<span>You can check it at: " + link + "</span><br><br>" +
                "";


                email.Initial(lstReceive,
                    "[PSI-System] Check approve request manpower",
                    txtContent);
                return false;
            }
            catch
            {
                return false;
            }
        }
        private bool SendMailApprovedRec(string dept, string approveBy, List<string> lstReceive, string receiver, string link)
        {
            try
            {
                string txtContent = "<span style = 'font-weight: bold;'> Dear Mrs/Mr." + receiver + "</span><br><br>" +
                "<span>Your request for plan recruitment of </span>: <span style = 'font-weight: bold;'>" + dept + " was confirmed </span><br>" +
                "<span>Confirm by</span>: <span style = 'font-weight: bold;'>" + approveBy + "</span><br>" +
                "<span>Confirm date</span>: <span style = 'font-weight: bold;'>" + DateTime.Now.ToString("dd-MMM-yyyy") + "</span><br>" +
                "<span>You can check it at: <a href=\"" + link + "\">Click here</a></span><br><br>" +
                "";


                email.Initial(lstReceive,
                    "[PSI-System] Approved recruitment plan request",
                    txtContent);
                return false;
            }
            catch
            {
                return false;
            }
        }
        private bool SendMailBeforeApprovedRec(string dept, List<string> lstReceive, string receiver, string link)
        {
            try
            {
                string txtContent = "<span style = 'font-weight: bold;'> Dear Mrs/Mr." + receiver + "</span><br><br>" +
                "<span>You have a request to confirm plan recruitment of </span>: <span style = 'font-weight: bold;'>" + dept + " </span><br>" +
                "<span>You can check it at: <a href=\"" + link + "\">Click here</a></span><br><br>" +
                "";


                email.Initial(lstReceive,
                    "[PSI-System] Approve recruitment plan request",
                    txtContent);
                return false;
            }
            catch
            {
                return false;
            }
        }
        private bool SendMailRemind(string from, string to, List<string> lstReceive, string link, string dueDate, string regarding)
        {
            try
            {
                string txtContent = "<span style = 'font-weight: bold;'> To Whom it may concern,</span><br><br>" +
                "<span> Regarding</span>: <span style = 'font-weight: bold;'>" + regarding + ",</span><br>" +
                "<span> Please update your Department</span>: <span style = 'font-weight: bold;'>Manpower & Recruitment demand.</span><br>" +
                "<span>The time range is</span>: <span style = 'font-weight: bold;'> from " + from + "~to " + to + "</span><br>" +
                "<span>Due date of upload: </span> <span style = 'font-weight: bold;'>" + dueDate + "</span><br><br>" +
                "<span>You can check it at: " + link + "</span><br><br>" +
                "";


                email.Initial(lstReceive,
                    "[PSI-System] Input data manpower",
                    txtContent);
                return false;
            }
            catch
            {
                return false;
            }
        }

        private async Task UpdateOP1Task(string[] version, string type)
        {
            //CommonResponse res = new CommonResponse()
            //{
            //    Error = false,
            //    Message = "",
            //    Status = (int)HttpStatusCode.BadRequest
            //};
            try
            {

                var lstUpdate = new List<MpManpowerOp1Daily>();
                var lstAdd = new List<MpManpowerOp1Daily>();
                var calendar = context.AdmMasterCalendars.ToList();
                var modelIJ = await context.MpManpowerItems
                        .Where(x => x.TypePs == type && x.Version == version[0] && x.ApprovedDate != null && x.ApprovedBy != null && x.Product == "IJ")
                        .OrderBy(x => x.OrderNo)
                        .ToListAsync();
                var fromIJ = modelIJ.Min(x => x.From);
                var toIJ = modelIJ.Max(x => x.To);
                var lstDataIJ = modelIJ.GroupBy(y => new { y.OrderNo }).Select(x => x.First()).ToList();
                var lstCalIJ = calendar.Where(x => x.DateOfDate >= fromIJ && x.DateOfDate <= toIJ).Select(x => x.DateOfDate).ToList();
                var lstSumaryIJ = context.MpManpowerOp1Dailies.Where(x => x.Active == true && x.Product == "IJ" && x.TypePs == type && x.Version == version[0]).ToList();
                var lstExplanation = new List<int?>() { 8, 9, 10, 11, 12 };
                foreach (var item in lstDataIJ)
                {
                    var lstValue = lstCalIJ.Select(x => "").ToList();
                    var lstGroup = modelIJ.Where(x => x.OrderNo == item.OrderNo).ToList();
                    foreach (var group in lstGroup)
                    {
                        var valueGroup = group.Value;
                        var calGroup = group.Date.ToList();
                        if (!lstExplanation.Contains(group.OrderNo))
                        {
                            foreach (var cal in lstCalIJ)
                            {
                                var indexModel = calGroup.IndexOf(cal);
                                var indexSum = lstCalIJ.IndexOf(cal);
                                if (indexModel == -1)
                                {
                                    lstValue[indexSum] = lstValue[indexSum];
                                }
                                else
                                {
                                    if (lstValue[indexSum] == "" && valueGroup[indexModel] == "")
                                    {
                                        lstValue[indexSum] = "";
                                    }
                                    else if (lstValue[indexSum] == "" && valueGroup[indexModel] != "")
                                    {
                                        lstValue[indexSum] = Math.Round(valueGroup[indexModel].StringAbleToDouble(), 0).ToString();
                                    }
                                    else if (lstValue[indexSum] != "" && valueGroup[indexModel] == "")
                                    {
                                        lstValue[indexSum] = Math.Round(lstValue[indexSum].StringAbleToDouble(), 0).ToString();
                                    }
                                    else if (lstValue[indexSum] != "" && valueGroup[indexModel] != "")
                                    {
                                        lstValue[indexSum] = (Math.Round(lstValue[indexSum].StringAbleToDouble() + valueGroup[indexModel].StringAbleToDouble(), 0)).ToString();
                                    }
                                }
                            }
                        }
                        else
                        {
                            foreach (var cal in lstCalIJ)
                            {
                                var indexModel = calGroup.IndexOf(cal);
                                var indexSum = lstCalIJ.IndexOf(cal);
                                if (indexModel == -1)
                                {
                                    lstValue[indexSum] = lstValue[indexSum];
                                }
                                else
                                {
                                    if (lstValue[indexSum] == "" && valueGroup[indexModel] == "")
                                    {
                                        lstValue[indexSum] = "";
                                    }
                                    else if (lstValue[indexSum] == "" && valueGroup[indexModel] != "")
                                    {
                                        lstValue[indexSum] = valueGroup[indexModel];
                                    }
                                    else if (lstValue[indexSum] != "" && valueGroup[indexModel] == "")
                                    {
                                        lstValue[indexSum] = lstValue[indexSum];
                                    }
                                    else if (lstValue[indexSum] != "" && valueGroup[indexModel] != "")
                                    {
                                        lstValue[indexSum] = lstValue[indexSum] + "," + valueGroup[indexModel];
                                    }
                                }
                            }
                        }
                    }
                    if (lstSumaryIJ.Count == 0)
                    {
                        lstAdd.Add(new MpManpowerOp1Daily
                        {
                            Item = item.Item,
                            Date = lstCalIJ.ToArray(),
                            Value = lstValue.ToArray(),
                            OrderNo = item.OrderNo,
                            Product = item.Product,
                            TypePs = type,
                            Version = version[0]
                        });
                    }
                    else
                    {
                        var itemSum = lstSumaryIJ.Where(x => x.OrderNo == item.OrderNo).FirstOrDefault();
                        //nếu from date của form up lên nhỏ hơn from date của thằng from sumary
                        if (fromIJ < itemSum.Date[0])
                        {
                            //lấy thêm thằng date của thằng up lên
                            var lstConcatStart = calendar.Where(x => x.DateOfDate >= fromIJ && x.DateOfDate < itemSum.Date[0]).Select(x => "").ToList();

                            //nếu to date của thằng up lên nhỏ hơn hoạc bằng to date của thằng sumary
                            if (toIJ <= itemSum.Date[itemSum.Date.Length - 1])
                            {
                                var newCal = calendar.Where(x => x.DateOfDate >= fromIJ && x.DateOfDate <= itemSum.Date[itemSum.Date.Length - 1]).Select(x => x.DateOfDate).ToList();

                                itemSum.Date = newCal.ToArray();
                                itemSum.Value = (lstConcatStart.Concat(itemSum.Value.ToList())).ToArray();
                                var i = 0;
                                foreach (var date in lstCalIJ)
                                {
                                    var index = newCal.IndexOf(date);

                                    itemSum.Value[index] = lstValue[i];
                                    i++;
                                }
                                lstUpdate.Add(itemSum);
                            }
                            else
                            {
                                var lstConcatEnd = calendar.Where(x => x.DateOfDate > itemSum.Date[itemSum.Date.Length - 1] && x.DateOfDate <= toIJ).Select(x => "").ToList();
                                var newCal = calendar.Where(x => x.DateOfDate >= fromIJ && x.DateOfDate <= toIJ).Select(x => x.DateOfDate).ToList();
                                itemSum.Date = newCal.ToArray();
                                itemSum.Value = (lstConcatStart.Concat(itemSum.Value.ToList()).Concat(lstConcatEnd)).ToArray();
                                var i = 0;
                                foreach (var date in lstCalIJ)
                                {
                                    var index = newCal.IndexOf(date);
                                    itemSum.Value[index] = lstValue[i];
                                    i++;
                                }
                                lstUpdate.Add(itemSum);
                            }

                        }
                        else
                        {
                            var lstConcatEnd = calendar.Where(x => x.DateOfDate > itemSum.Date[itemSum.Date.Length - 1] && x.DateOfDate <= toIJ).Select(x => "").ToList();
                            var newCal = calendar.Where(x => x.DateOfDate >= itemSum.Date[0] && x.DateOfDate <= toIJ).Select(x => x.DateOfDate).ToList();
                            itemSum.Date = newCal.ToArray();
                            itemSum.Value = (itemSum.Value.ToList().Concat(lstConcatEnd)).ToArray();
                            var i = 0;
                            foreach (var date in lstCalIJ)
                            {
                                var index = newCal.IndexOf(date);
                                itemSum.Value[index] = lstValue[i];
                                i++;
                            }
                            lstUpdate.Add(itemSum);
                        }

                    }

                }

                var modelLBP = context.MpManpowerItems
                        .Where(x =>  x.TypePs == type && x.Version == version[0] && x.ApprovedDate != null && x.ApprovedBy != null && x.Product == "LBP")
                        .OrderBy(x => x.OrderNo)
                        .ToList();
                var fromLBP = modelLBP.Min(x => x.From);
                var toLBP = modelLBP.Max(x => x.To);
                var lstDataLBP = modelLBP.GroupBy(y => new { y.OrderNo }).Select(x => x.First()).ToList();
                var lstCalLBP = calendar.Where(x => x.DateOfDate >= fromLBP && x.DateOfDate <= toLBP).Select(x => x.DateOfDate).ToList();
                var lstSumaryLBP = context.MpManpowerOp1Dailies.Where(x => x.Active == true && x.Product == "LBP" && x.TypePs == type && x.Version == version[0]).ToList();

                foreach (var item in lstDataLBP)
                {
                    var lstValue = lstCalLBP.Select(x => "").ToList();
                    var lstGroup = modelLBP.Where(x => x.OrderNo == item.OrderNo).ToList();
                    foreach (var group in lstGroup)
                    {
                        var valueGroup = group.Value;
                        var calGroup = group.Date.ToList();
                        if (!lstExplanation.Contains(group.OrderNo))
                        {
                            foreach (var cal in lstCalLBP)
                            {
                                var indexModel = calGroup.IndexOf(cal);
                                var indexSum = lstCalIJ.IndexOf(cal);
                                if (indexModel == -1)
                                {
                                    lstValue[indexSum] = lstValue[indexSum];
                                }
                                else
                                {
                                    if (lstValue[indexSum] == "" && valueGroup[indexModel] == "")
                                    {
                                        lstValue[indexSum] = "";
                                    }
                                    else if (lstValue[indexSum] == "" && valueGroup[indexModel] != "")
                                    {
                                        lstValue[indexSum] = Math.Round(valueGroup[indexModel].StringAbleToDouble(), 0).ToString();
                                    }
                                    else if (lstValue[indexSum] != "" && valueGroup[indexModel] == "")
                                    {
                                        lstValue[indexSum] = Math.Round(lstValue[indexSum].StringAbleToDouble(), 0).ToString();
                                    }
                                    else if (lstValue[indexSum] != "" && valueGroup[indexModel] != "")
                                    {
                                        lstValue[indexSum] = (Math.Round(lstValue[indexSum].StringAbleToDouble() + valueGroup[indexModel].StringAbleToDouble(), 0)).ToString();
                                    }
                                }
                            }
                        }
                        else
                        {
                            foreach (var cal in lstCalLBP)
                            {
                                var indexModel = calGroup.IndexOf(cal);
                                var indexSum = lstCalIJ.IndexOf(cal);
                                if (indexModel == -1)
                                {
                                    lstValue[indexSum] = lstValue[indexSum];
                                }
                                else
                                {
                                    if (lstValue[indexSum] == "" && valueGroup[indexModel] == "")
                                    {
                                        lstValue[indexSum] = "";
                                    }
                                    else if (lstValue[indexSum] == "" && valueGroup[indexModel] != "")
                                    {
                                        lstValue[indexSum] = valueGroup[indexModel];
                                    }
                                    else if (lstValue[indexSum] != "" && valueGroup[indexModel] == "")
                                    {
                                        lstValue[indexSum] = lstValue[indexSum];
                                    }
                                    else if (lstValue[indexSum] != "" && valueGroup[indexModel] != "")
                                    {
                                        lstValue[indexSum] = lstValue[indexSum] + "," + valueGroup[indexModel];
                                    }
                                }
                            }
                        }
                    }
                    if (lstSumaryLBP.Count == 0)
                    {
                        lstAdd.Add(new MpManpowerOp1Daily
                        {
                            Item = item.Item,
                            Date = lstCalLBP.ToArray(),
                            Value = lstValue.ToArray(),
                            OrderNo = item.OrderNo,
                            Product = item.Product,
                            TypePs = type,
                            Version = version[0]
                        });
                    }
                    else
                    {
                        var itemSum = lstSumaryLBP.Where(x => x.OrderNo == item.OrderNo).FirstOrDefault();
                        if (fromLBP < itemSum.Date[0])
                        {
                            var lstConcatStart = calendar.Where(x => x.DateOfDate >= fromLBP && x.DateOfDate < itemSum.Date[0]).Select(x => "").ToList();

                            if (toLBP <= itemSum.Date[itemSum.Date.Length - 1])
                            {
                                var newCal = calendar.Where(x => x.DateOfDate >= fromLBP && x.DateOfDate <= itemSum.Date[itemSum.Date.Length - 1]).Select(x => x.DateOfDate).ToList();

                                itemSum.Date = newCal.ToArray();
                                itemSum.Value = (lstConcatStart.Concat(itemSum.Value.ToList())).ToArray();
                                var i = 0;
                                foreach (var date in lstCalLBP)
                                {
                                    var index = newCal.IndexOf(date);
                                    itemSum.Value[index] = lstValue[i];
                                    i++;
                                }
                                lstUpdate.Add(itemSum);
                            }
                            else
                            {
                                var lstConcatEnd = calendar.Where(x => x.DateOfDate > itemSum.Date[itemSum.Date.Length - 1] && x.DateOfDate <= toLBP).Select(x => "").ToList();
                                var newCal = calendar.Where(x => x.DateOfDate >= fromLBP && x.DateOfDate <= toLBP).Select(x => x.DateOfDate).ToList();
                                itemSum.Date = newCal.ToArray();
                                itemSum.Value = (lstConcatStart.Concat(itemSum.Value.ToList()).Concat(lstConcatEnd)).ToArray();
                                var i = 0;
                                foreach (var date in lstCalLBP)
                                {
                                    var index = newCal.IndexOf(date);
                                    itemSum.Value[index] = lstValue[i];
                                    i++;
                                }
                                lstUpdate.Add(itemSum);
                            }

                        }
                        else
                        {
                            var lstConcatEnd = calendar.Where(x => x.DateOfDate > itemSum.Date[itemSum.Date.Length - 1] && x.DateOfDate <= toLBP).Select(x => "").ToList();
                            var newCal = calendar.Where(x => x.DateOfDate >= itemSum.Date[0] && x.DateOfDate <= toLBP).Select(x => x.DateOfDate).ToList();
                            itemSum.Date = newCal.ToArray();
                            itemSum.Value = (itemSum.Value.ToList().Concat(lstConcatEnd)).ToArray();
                            var a = (itemSum.Value.ToList().Concat(lstConcatEnd)).ToArray();
                            var i = 0;
                            foreach (var date in lstCalLBP)
                            {
                                var index = newCal.IndexOf(date);
                                itemSum.Value[index] = lstValue[i];
                                i++;
                            }
                            lstUpdate.Add(itemSum);
                        }

                    }

                }
                //xóa all đi vì mình tính lại mà
                var delAllModel = context.MpManpowerOp1Dailies.Where(x => x.TypePs == type && x.Version == version[0] && x.Product == "ALL").ToList();
                //concat vì 1 trong 2 thằng sẽ có thằng null nên không conflict được
                var lstAllModel = lstAdd.Concat(lstUpdate);
                foreach (var item in lstAllModel.GroupBy(x => x.OrderNo).Select(g => g.First()).ToList())
                {
                    var allOrder = lstAllModel.Where(x => x.OrderNo == item.OrderNo).ToList();
                    var minDate = allOrder.Min(x => x.Date[0]);
                    var maxDate = allOrder.Max(x => x.Date[x.Date.Length - 1]);
                    var newCal = calendar.Where(x => x.DateOfDate >= minDate && x.DateOfDate <= maxDate).Select(x => x.DateOfDate).ToList();
                    var lstValue = newCal.Select(x => "").ToList();
                    foreach (var i in allOrder)
                    {
                        var dateOrder = i.Date.ToList();
                        var valueOrder = i.Value.ToList();
                        if (lstExplanation.Contains(i.OrderNo))
                        {
                            foreach (var date in newCal)
                            {
                                var index = newCal.IndexOf(date);
                                var indexOrder = dateOrder.IndexOf(date);
                                if (indexOrder != -1)
                                {
                                    if (lstValue[index] == "" && valueOrder[indexOrder] == "")
                                    {
                                        lstValue[index] = "";
                                    }
                                    else if (lstValue[index] == "" && valueOrder[indexOrder] != "")
                                    {
                                        lstValue[index] = valueOrder[indexOrder];
                                    }
                                    else if (lstValue[index] != "" && valueOrder[indexOrder] == "")
                                    {
                                        lstValue[index] = lstValue[index];
                                    }
                                    else if (lstValue[index] != "" && valueOrder[indexOrder] != "")
                                    {
                                        lstValue[index] = lstValue[index] + "," + valueOrder[indexOrder];
                                    }
                                }
                            }
                        }
                        else
                        {
                            foreach (var date in newCal)
                            {
                                var index = newCal.IndexOf(date);
                                var indexOrder = dateOrder.IndexOf(date);
                                if (indexOrder != -1)
                                {
                                    if (lstValue[index] == "" && valueOrder[indexOrder] == "")
                                    {
                                        lstValue[index] = "";
                                    }
                                    else if (lstValue[index] == "" && valueOrder[indexOrder] != "")
                                    {
                                        lstValue[index] = Math.Round(valueOrder[indexOrder].StringAbleToDouble(), 0).ToString();
                                    }
                                    else if (lstValue[index] != "" && valueOrder[indexOrder] == "")
                                    {
                                        lstValue[index] = Math.Round(lstValue[index].StringAbleToDouble(), 0).ToString();
                                    }
                                    else if (lstValue[index] != "" && valueOrder[indexOrder] != "")
                                    {
                                        lstValue[index] = Math.Round(lstValue[index].StringAbleToDouble() + valueOrder[indexOrder].StringAbleToDouble(), 0).ToString();
                                    }
                                }
                            }
                        }
                    }
                    lstAdd.Add(new MpManpowerOp1Daily
                    {
                        Item = item.Item,
                        Date = newCal.ToArray(),
                        Value = lstValue.ToArray(),
                        OrderNo = item.OrderNo,
                        Product = "ALL",
                        TypePs = type,
                        Version = version[0]
                    });
                }
                context.RemoveRange(delAllModel);
                context.AddRange(lstAdd);
                context.UpdateRange(lstUpdate);
                context.SaveChanges();

                var lstDaily = context.MpManpowerOp1Dailies.Where(x => x.TypePs == type && x.Version == version[0] && x.Active == true).GroupBy(x => x.Product).ToList();
                //Insert cho weekly
                var lstFormular = new List<int?>() { 7, 31, 48, 66, 67, 68, 69, 71 };

                //những order không tính avg
                var lstOrderAVG = new List<int?>() {13,14,15,16,17,18,19,20,21,22,23,24,26,27,28,29,30,32,33,34,35,36,37,38,39,40,41,43,44,45,46,47,49,
                50,51,52,53,54,55,56,57,58,59,61,62,63,64,65};
                var lstAddW = new List<MpManpowerOp1Weekly>();
                var lstDelW = context.MpManpowerOp1Weeklies.Where(x => x.TypePs == type && x.Version == version[0] && x.Active == true ).ToList();
                var calOff = calendar.Where(x => x.IjOff == true && x.LbpOff == true).Select(y => y.DateOfDate).ToList();

                foreach (var product in lstDaily)
                {
                    foreach (var item in product)
                    {
                        if (!lstFormular.Contains(item.OrderNo))
                        {
                            var lstDate = new List<DateOnly>();
                            var lstValue = new List<string>();
                            var lstWeek = calendar.Where(x => (x.DateOfDate >= item.Date[0].AddDays(-6) && x.DateOfDate <= item.Date[item.Date.Length - 1].AddDays(6)) && x.DayOfWeek == "MON").Select(x => x.DateOfDate).ToList();
                            var itemDate = item.Date.ToList();
                            var itemValue = item.Value.ToList();

                            if (!lstExplanation.Contains(item.OrderNo))
                            {
                                foreach (var week in lstWeek)
                                {
                                    //var endDate = DateOnly.FromDateTime(new DateTime(month.Year, month.Month, DateTime.DaysInMonth(month.Year, month.Month)));
                                    lstDate.Add(week);

                                    var cal = itemDate.Where(x => !calOff.Contains(x) && x >= week && x < week.AddDays(7)).ToList();
                                    string val = "";
                                    foreach (var date in cal)
                                    {
                                        var index = itemDate.IndexOf(date);

                                        if (index != -1)
                                        {
                                            if (itemValue[index] == "" && val == "")
                                            {
                                                val = "";
                                            }
                                            else if (itemValue[index] == "" && val != "")
                                            {
                                                val = val;
                                            }
                                            else if (itemValue[index] != "" && val == "")
                                            {
                                                val = itemValue[index];
                                            }
                                            else if (item.Value[index] != "" && val != "")
                                            {
                                                val = (item.Value[index].StringAbleToDouble() + val.StringAbleToDouble()).ToString();
                                            }
                                        }

                                    }
                                    lstValue.Add(val == "" ? "" :(lstOrderAVG.Contains(item.OrderNo)? val : (Math.Round(val.StringAbleToDouble() / (cal.Count), 0)).ToString()));
                                }
                            }
                            else
                            {

                                foreach (var week in lstWeek)
                                {

                                    lstDate.Add(week);
                                    lstValue.Add("");
                                }
                            }
                            lstAddW.Add(new MpManpowerOp1Weekly
                            {
                                Item = item.Item,
                                Date = lstDate.ToArray(),
                                Value = lstValue.ToArray(),
                                OrderNo = item.OrderNo,
                                Product = item.Product,
                                TypePs = type,
                                Version = version[0]
                            });
                        }
                    }
                }
               

                var lstProduct = new List<string>() { "IJ", "LBP","ALL" };
                foreach (var formular in lstFormular)
                {

                    foreach (var product in lstProduct)
                    {
                        var lstDate = new List<DateOnly>();
                        var lstValue = new List<string>();
                        //lấy ra 1 thằng đại diện để lấy thông tin common
                        var itemCommon = lstAddW.FirstOrDefault(x => x.OrderNo == 0 && x.Product.ToUpper() == product);
                        lstDate = itemCommon.Date.ToList();
                        if (formular == 7)
                        {
                            var itemNo2 = lstAddW.FirstOrDefault(x => x.OrderNo == 2 && x.Product.ToUpper() == product);
                            var lstVal = itemNo2.Value;
                            for (int i = 0; i < lstDate.Count; i++)
                            {
                                lstValue.Add(i == 0 ? "" : ((lstVal[i].StringAbleToDouble() - lstVal[(i - 1)].StringAbleToDouble()).ToString()));
                            }
                        }
                        if (formular == 31)
                        {
                            var valNo13 = lstAddW.FirstOrDefault(x => x.OrderNo == 13 && x.Product.ToUpper() == product).Value.Select(y => y.StringAbleToDouble()).ToList();
                            var valNo14 = lstAddW.FirstOrDefault(x => x.OrderNo == 14 && x.Product.ToUpper() == product).Value.Select(y => y.StringAbleToDouble()).ToList();
                            var valNo15 = lstAddW.FirstOrDefault(x => x.OrderNo == 15 && x.Product.ToUpper() == product).Value.Select(y => y.StringAbleToDouble()).ToList();
                            var valNo16 = lstAddW.FirstOrDefault(x => x.OrderNo == 16 && x.Product.ToUpper() == product).Value.Select(y => y.StringAbleToDouble()).ToList();
                            var valNo17 = lstAddW.FirstOrDefault(x => x.OrderNo == 17 && x.Product.ToUpper() == product).Value.Select(y => y.StringAbleToDouble()).ToList();
                            var valNo18 = lstAddW.FirstOrDefault(x => x.OrderNo == 18 && x.Product.ToUpper() == product).Value.Select(y => y.StringAbleToDouble()).ToList();
                            var valNo19 = lstAddW.FirstOrDefault(x => x.OrderNo == 19 && x.Product.ToUpper() == product).Value.Select(y => y.StringAbleToDouble()).ToList();
                            var valNo20 = lstAddW.FirstOrDefault(x => x.OrderNo == 20 && x.Product.ToUpper() == product).Value.Select(y => y.StringAbleToDouble()).ToList();
                            var valNo21 = lstAddW.FirstOrDefault(x => x.OrderNo == 21 && x.Product.ToUpper() == product).Value.Select(y => y.StringAbleToDouble()).ToList();
                            var valNo22 = lstAddW.FirstOrDefault(x => x.OrderNo == 22 && x.Product.ToUpper() == product).Value.Select(y => y.StringAbleToDouble()).ToList();
                            var valNo23 = lstAddW.FirstOrDefault(x => x.OrderNo == 23 && x.Product.ToUpper() == product).Value.Select(y => y.StringAbleToDouble()).ToList();
                            var valNo24 = lstAddW.FirstOrDefault(x => x.OrderNo == 24 && x.Product.ToUpper() == product).Value.Select(y => y.StringAbleToDouble()).ToList();

                            var valNo26 = lstAddW.FirstOrDefault(x => x.OrderNo == 26 && x.Product.ToUpper() == product).Value.Select(y => y.StringAbleToDouble()).ToList();
                            var valNo27 = lstAddW.FirstOrDefault(x => x.OrderNo == 27 && x.Product.ToUpper() == product).Value.Select(y => y.StringAbleToDouble()).ToList();
                            var valNo28 = lstAddW.FirstOrDefault(x => x.OrderNo == 28 && x.Product.ToUpper() == product).Value.Select(y => y.StringAbleToDouble()).ToList();
                            var valNo29 = lstAddW.FirstOrDefault(x => x.OrderNo == 29 && x.Product.ToUpper() == product).Value.Select(y => y.StringAbleToDouble()).ToList();
                            var valNo30 = lstAddW.FirstOrDefault(x => x.OrderNo == 30 && x.Product.ToUpper() == product).Value.Select(y => y.StringAbleToDouble()).ToList();
                            //var valNo31 = lstAddW.FirstOrDefault(x => x.OrderNo == 31).Value;
                            for (int i = 0; i < lstDate.Count; i++)
                            {
                                var val = (valNo13[i] > 0 ? valNo13[i] : (i == 0?0:lstValue[i - 1].StringAbleToDouble())) + (valNo14[i] + valNo15[i] + valNo16[i] + valNo17[i] + valNo18[i] + valNo19[i] + valNo20
                                    [i]) - (valNo21[i] + valNo22[i] + valNo23[i] + valNo24[i]) - (valNo26[i] + valNo27[i] + valNo28[i] + valNo29[i] + valNo30[i]);
                                lstValue.Add(val.ToString());
                            }

                        }
                        if (formular == 48)
                        {
                            var valNo32 = lstAddW.FirstOrDefault(x => x.OrderNo == 32 && x.Product.ToUpper() == product).Value.Select(y => y.StringAbleToDouble()).ToList();
                            var valNo33 = lstAddW.FirstOrDefault(x => x.OrderNo == 33 && x.Product.ToUpper() == product).Value.Select(y => y.StringAbleToDouble()).ToList();
                            var valNo34 = lstAddW.FirstOrDefault(x => x.OrderNo == 34 && x.Product.ToUpper() == product).Value.Select(y => y.StringAbleToDouble()).ToList();
                            var valNo35 = lstAddW.FirstOrDefault(x => x.OrderNo == 35 && x.Product.ToUpper() == product).Value.Select(y => y.StringAbleToDouble()).ToList();
                            var valNo36 = lstAddW.FirstOrDefault(x => x.OrderNo == 36 && x.Product.ToUpper() == product).Value.Select(y => y.StringAbleToDouble()).ToList();
                            var valNo37 = lstAddW.FirstOrDefault(x => x.OrderNo == 37 && x.Product.ToUpper() == product).Value.Select(y => y.StringAbleToDouble()).ToList();
                            var valNo38 = lstAddW.FirstOrDefault(x => x.OrderNo == 38 && x.Product.ToUpper() == product).Value.Select(y => y.StringAbleToDouble()).ToList();
                            var valNo39 = lstAddW.FirstOrDefault(x => x.OrderNo == 39 && x.Product.ToUpper() == product).Value.Select(y => y.StringAbleToDouble()).ToList();
                            var valNo40 = lstAddW.FirstOrDefault(x => x.OrderNo == 40 && x.Product.ToUpper() == product).Value.Select(y => y.StringAbleToDouble()).ToList();
                            var valNo41 = lstAddW.FirstOrDefault(x => x.OrderNo == 41 && x.Product.ToUpper() == product).Value.Select(y => y.StringAbleToDouble()).ToList();

                            var valNo43 = lstAddW.FirstOrDefault(x => x.OrderNo == 43 && x.Product.ToUpper() == product).Value.Select(y => y.StringAbleToDouble()).ToList();
                            var valNo44 = lstAddW.FirstOrDefault(x => x.OrderNo == 44 && x.Product.ToUpper() == product).Value.Select(y => y.StringAbleToDouble()).ToList();
                            var valNo45 = lstAddW.FirstOrDefault(x => x.OrderNo == 45 && x.Product.ToUpper() == product).Value.Select(y => y.StringAbleToDouble()).ToList();
                            var valNo46 = lstAddW.FirstOrDefault(x => x.OrderNo == 46 && x.Product.ToUpper() == product).Value.Select(y => y.StringAbleToDouble()).ToList();
                            var valNo47 = lstAddW.FirstOrDefault(x => x.OrderNo == 47 && x.Product.ToUpper() == product).Value.Select(y => y.StringAbleToDouble()).ToList();
                            // var valNo48 = lstAddW.FirstOrDefault(x => x.OrderNo == 31).Value;
                            for (int i = 0; i < lstDate.Count; i++)
                            {
                                var val = (valNo32[i] > 0 ? valNo32[i] : (i == 0 ? 0 : lstValue[i - 1].StringAbleToDouble())) + (valNo33[i] + valNo34[i] + valNo35[i] + valNo36[i] + valNo37[i]) - (valNo38[i] + valNo39[i] + valNo40[i] + valNo41[i]) - (valNo47[i] + valNo43[i] + valNo44[i] + valNo45[i] + valNo46[i]);
                                lstValue.Add(val.ToString());
                            }
                        }
                        if (formular == 66)
                        {
                            var valNo49 = lstAddW.FirstOrDefault(x => x.OrderNo == 49 && x.Product.ToUpper() == product).Value.Select(y => y.StringAbleToDouble()).ToList();
                            var valNo50 = lstAddW.FirstOrDefault(x => x.OrderNo == 50 && x.Product.ToUpper() == product).Value.Select(y => y.StringAbleToDouble()).ToList();
                            var valNo51 = lstAddW.FirstOrDefault(x => x.OrderNo == 51 && x.Product.ToUpper() == product).Value.Select(y => y.StringAbleToDouble()).ToList();
                            var valNo52 = lstAddW.FirstOrDefault(x => x.OrderNo == 52 && x.Product.ToUpper() == product).Value.Select(y => y.StringAbleToDouble()).ToList();
                            var valNo53 = lstAddW.FirstOrDefault(x => x.OrderNo == 53 && x.Product.ToUpper() == product).Value.Select(y => y.StringAbleToDouble()).ToList();
                            var valNo54 = lstAddW.FirstOrDefault(x => x.OrderNo == 54 && x.Product.ToUpper() == product).Value.Select(y => y.StringAbleToDouble()).ToList();
                            var valNo55 = lstAddW.FirstOrDefault(x => x.OrderNo == 55 && x.Product.ToUpper() == product).Value.Select(y => y.StringAbleToDouble()).ToList();
                            var valNo56 = lstAddW.FirstOrDefault(x => x.OrderNo == 56 && x.Product.ToUpper() == product).Value.Select(y => y.StringAbleToDouble()).ToList();
                            var valNo57 = lstAddW.FirstOrDefault(x => x.OrderNo == 57 && x.Product.ToUpper() == product).Value.Select(y => y.StringAbleToDouble()).ToList();
                            var valNo58 = lstAddW.FirstOrDefault(x => x.OrderNo == 58 && x.Product.ToUpper() == product).Value.Select(y => y.StringAbleToDouble()).ToList();
                            var valNo59 = lstAddW.FirstOrDefault(x => x.OrderNo == 59 && x.Product.ToUpper() == product).Value.Select(y => y.StringAbleToDouble()).ToList();

                            var valNo61 = lstAddW.FirstOrDefault(x => x.OrderNo == 61 && x.Product.ToUpper() == product).Value.Select(y => y.StringAbleToDouble()).ToList();
                            var valNo62 = lstAddW.FirstOrDefault(x => x.OrderNo == 62 && x.Product.ToUpper() == product).Value.Select(y => y.StringAbleToDouble()).ToList();
                            var valNo63 = lstAddW.FirstOrDefault(x => x.OrderNo == 63 && x.Product.ToUpper() == product).Value.Select(y => y.StringAbleToDouble()).ToList();
                            var valNo64 = lstAddW.FirstOrDefault(x => x.OrderNo == 64 && x.Product.ToUpper() == product).Value.Select(y => y.StringAbleToDouble()).ToList();
                            var valNo65 = lstAddW.FirstOrDefault(x => x.OrderNo == 65 && x.Product.ToUpper() == product).Value.Select(y => y.StringAbleToDouble()).ToList();

                            for (int i = 0; i < lstDate.Count; i++)
                            {
                                var val = (valNo49[i] > 0 ? valNo49[i] : (i == 0 ? 0 : lstValue[i - 1].StringAbleToDouble())) + (valNo50[i] + valNo51[i] + valNo52[i] + valNo53[i] + valNo54[i]) - (valNo55[i] + valNo56[i] + valNo57[i] + valNo58[i] + valNo59[i]) - (valNo61[i] + valNo62[i] + valNo63[i] + valNo64[i] + valNo65[i]);
                                lstValue.Add(val.ToString());
                            }
                        }
                        if (formular == 67)
                        {
                            var valNo31 = lstAddW.FirstOrDefault(x => x.OrderNo == 31 && x.Product.ToUpper() == product).Value.Select(y => y.StringAbleToDouble()).ToList();
                            var valNo48 = lstAddW.FirstOrDefault(x => x.OrderNo == 48 && x.Product.ToUpper() == product).Value.Select(y => y.StringAbleToDouble()).ToList();
                            var valNo66 = lstAddW.FirstOrDefault(x => x.OrderNo == 66 && x.Product.ToUpper() == product).Value.Select(y => y.StringAbleToDouble()).ToList();
                            for (int i = 0; i < lstDate.Count; i++)
                            {
                                var val = valNo31[i] + valNo48[i] + valNo66[i];
                                lstValue.Add(val.ToString());
                            }
                        }
                        if (formular == 68)
                        {
                            var valNo2 = lstAddW.FirstOrDefault(x => x.OrderNo == 2 && x.Product.ToUpper() == product).Value.Select(y => y.StringAbleToDouble()).ToList();
                            var valNo67 = lstAddW.FirstOrDefault(x => x.OrderNo == 67 && x.Product.ToUpper() == product).Value.Select(y => y.StringAbleToDouble()).ToList();
                            for (int i = 0; i < lstDate.Count; i++)
                            {
                                var val = valNo67[i] - valNo2[i];
                                lstValue.Add(val.ToString());
                            }
                        }
                        if (formular == 69)
                        {
                            var valNo4 = lstAddW.FirstOrDefault(x => x.OrderNo == 4 && x.Product.ToUpper() == product).Value.Select(y => y.StringAbleToDouble()).ToList();
                            var valNo67 = lstAddW.FirstOrDefault(x => x.OrderNo == 67 && x.Product.ToUpper() == product).Value.Select(y => y.StringAbleToDouble()).ToList();
                            for (int i = 0; i < lstDate.Count; i++)
                            {
                                var val = valNo67[i] - valNo4[i];
                                lstValue.Add(val.ToString());
                            }
                        }
                        if (formular == 71)
                        {
                            var valNo70 = lstAddW.FirstOrDefault(x => x.OrderNo == 70 && x.Product.ToUpper() == product).Value.Select(y => y.StringAbleToDouble()).ToList();
                            var valNo67 = lstAddW.FirstOrDefault(x => x.OrderNo == 67 && x.Product.ToUpper() == product).Value.Select(y => y.StringAbleToDouble()).ToList();
                            for (int i = 0; i < lstDate.Count; i++)
                            {
                                var val = valNo67[i] - valNo70[i];
                                lstValue.Add(val.ToString());
                            }

                        }
                        lstAddW.Add(new MpManpowerOp1Weekly
                        {
                            // Item = item.Item,
                            Date = lstDate.ToArray(),
                            Value = lstValue.ToArray(),
                            OrderNo = formular,
                            Product = product,
                            TypePs = type,
                            Version = version[0]
                        });
                       
                    }
                    
                }
                //Insert cho monthly
                var lstAddM = new List<MpManpowerOp1Monthly>();
                var lstDelM = context.MpManpowerOp1Monthlies.Where(x => x.TypePs == type && x.Version == version[0] && x.Active == true).ToList();
                foreach (var product in lstDaily)
                {
                    foreach (var item in product)
                    {
                        if (!lstFormular.Contains(item.OrderNo))
                        {
                            var lstDate = new List<DateOnly>();
                            var lstValue = new List<string>();
                            var lstMonth = item.Date.Select(x => new { Month = x.Month, Year = x.Year }).Distinct().ToList();
                            var itemDate = item.Date.ToList();
                            var itemValue = item.Value.ToList();
                        
                            if (!lstExplanation.Contains(item.OrderNo))
                            {
                                foreach (var month in lstMonth)
                                {
                                    var startDate = DateOnly.FromDateTime(new DateTime(month.Year, month.Month, 1));
                                    var endDate = DateOnly.FromDateTime(new DateTime(month.Year, month.Month, DateTime.DaysInMonth(month.Year, month.Month)));
                                    lstDate.Add(endDate);
                                    var cal = itemDate.Where(x => !calOff.Contains(x) && x >= startDate && x <= endDate).ToList();
                                    string val = "";
                                    foreach (var date in cal)
                                    {
                                        var index = itemDate.IndexOf(date);

                                        if (itemValue[index] == "" && val == "")
                                        {
                                            val = "";
                                        }
                                        else if (itemValue[index] == "" && val != "")
                                        {
                                            val = val;
                                        }
                                        else if (itemValue[index] != "" && val == "")
                                        {
                                            val = itemValue[index];
                                        }
                                        else if (item.Value[index] != "" && val != "")
                                        {
                                            val = (item.Value[index].StringAbleToDouble() + val.StringAbleToDouble()).ToString();
                                        }
                                    }
                                    lstValue.Add(val == "" ? "" : (lstOrderAVG.Contains(item.OrderNo) ? val : (Math.Round(val.StringAbleToDouble() / (cal.Count), 0)).ToString()));
                                }
                            }
                            else
                            {

                                foreach (var month in lstMonth)
                                {

                                    var endDate = DateOnly.FromDateTime(new DateTime(month.Year, month.Month, DateTime.DaysInMonth(month.Year, month.Month)));
                                    lstDate.Add(endDate);
                                    lstValue.Add("");
                                }
                            }
                            lstAddM.Add(new MpManpowerOp1Monthly
                            {
                                Item = item.Item,
                                Date = lstDate.ToArray(),
                                Value = lstValue.ToArray(),
                                OrderNo = item.OrderNo,
                                Product = item.Product,
                                TypePs = type,
                                Version = version[0]
                            });
                        }
                       
                    }
                }
                foreach (var formular in lstFormular)
                {

                    foreach (var product in lstProduct)
                    {
                        var lstDate = new List<DateOnly>();
                        var lstValue = new List<string>();
                        //lấy ra 1 thằng đại diện để lấy thông tin common
                        var itemCommon = lstAddM.FirstOrDefault(x => x.OrderNo == 0 && x.Product.ToUpper() == product);
                        lstDate = itemCommon.Date.ToList();
                        if (formular == 7)
                        {
                            var itemNo2 = lstAddM.FirstOrDefault(x => x.OrderNo == 2 && x.Product.ToUpper() == product);
                            var lstVal = itemNo2.Value;
                            for (int i = 0; i < lstDate.Count; i++)
                            {
                                lstValue.Add(i == 0 ? "" : ((lstVal[i].StringAbleToDouble() - lstVal[(i - 1)].StringAbleToDouble()).ToString()));
                            }
                        }
                        if (formular == 31)
                        {
                            var valNo13 = lstAddM.FirstOrDefault(x => x.OrderNo == 13 && x.Product.ToUpper() == product).Value.Select(y => y.StringAbleToDouble()).ToList();
                            var valNo14 = lstAddM.FirstOrDefault(x => x.OrderNo == 14 && x.Product.ToUpper() == product).Value.Select(y => y.StringAbleToDouble()).ToList();
                            var valNo15 = lstAddM.FirstOrDefault(x => x.OrderNo == 15 && x.Product.ToUpper() == product).Value.Select(y => y.StringAbleToDouble()).ToList();
                            var valNo16 = lstAddM.FirstOrDefault(x => x.OrderNo == 16 && x.Product.ToUpper() == product).Value.Select(y => y.StringAbleToDouble()).ToList();
                            var valNo17 = lstAddM.FirstOrDefault(x => x.OrderNo == 17 && x.Product.ToUpper() == product).Value.Select(y => y.StringAbleToDouble()).ToList();
                            var valNo18 = lstAddM.FirstOrDefault(x => x.OrderNo == 18 && x.Product.ToUpper() == product).Value.Select(y => y.StringAbleToDouble()).ToList();
                            var valNo19 = lstAddM.FirstOrDefault(x => x.OrderNo == 19 && x.Product.ToUpper() == product).Value.Select(y => y.StringAbleToDouble()).ToList();
                            var valNo20 = lstAddM.FirstOrDefault(x => x.OrderNo == 20 && x.Product.ToUpper() == product).Value.Select(y => y.StringAbleToDouble()).ToList();
                            var valNo21 = lstAddM.FirstOrDefault(x => x.OrderNo == 21 && x.Product.ToUpper() == product).Value.Select(y => y.StringAbleToDouble()).ToList();
                            var valNo22 = lstAddM.FirstOrDefault(x => x.OrderNo == 22 && x.Product.ToUpper() == product).Value.Select(y => y.StringAbleToDouble()).ToList();
                            var valNo23 = lstAddM.FirstOrDefault(x => x.OrderNo == 23 && x.Product.ToUpper() == product).Value.Select(y => y.StringAbleToDouble()).ToList();
                            var valNo24 = lstAddM.FirstOrDefault(x => x.OrderNo == 24 && x.Product.ToUpper() == product).Value.Select(y => y.StringAbleToDouble()).ToList();

                            var valNo26 = lstAddM.FirstOrDefault(x => x.OrderNo == 26 && x.Product.ToUpper() == product).Value.Select(y => y.StringAbleToDouble()).ToList();
                            var valNo27 = lstAddM.FirstOrDefault(x => x.OrderNo == 27 && x.Product.ToUpper() == product).Value.Select(y => y.StringAbleToDouble()).ToList();
                            var valNo28 = lstAddM.FirstOrDefault(x => x.OrderNo == 28 && x.Product.ToUpper() == product).Value.Select(y => y.StringAbleToDouble()).ToList();
                            var valNo29 = lstAddM.FirstOrDefault(x => x.OrderNo == 29 && x.Product.ToUpper() == product).Value.Select(y => y.StringAbleToDouble()).ToList();
                            var valNo30 = lstAddM.FirstOrDefault(x => x.OrderNo == 30 && x.Product.ToUpper() == product).Value.Select(y => y.StringAbleToDouble()).ToList();
                            //var valNo31 = lstAddM.FirstOrDefault(x => x.OrderNo == 31).Value;
                            for (int i = 0; i < lstDate.Count; i++)
                            {
                                var val = (valNo13[i] > 0 ? valNo13[i] : (i == 0 ? 0 : lstValue[i - 1].StringAbleToDouble())) + (valNo14[i] + valNo15[i] + valNo16[i] + valNo17[i] + valNo18[i] + valNo19[i] + valNo20
                                    [i]) - (valNo21[i] + valNo22[i] + valNo23[i] + valNo24[i]) - (valNo26[i] + valNo27[i] + valNo28[i] + valNo29[i] + valNo30[i]);
                                lstValue.Add(val.ToString());
                            }

                        }
                        if (formular == 48)
                        {
                            var valNo32 = lstAddM.FirstOrDefault(x => x.OrderNo == 32 && x.Product.ToUpper() == product).Value.Select(y => y.StringAbleToDouble()).ToList();
                            var valNo33 = lstAddM.FirstOrDefault(x => x.OrderNo == 33 && x.Product.ToUpper() == product).Value.Select(y => y.StringAbleToDouble()).ToList();
                            var valNo34 = lstAddM.FirstOrDefault(x => x.OrderNo == 34 && x.Product.ToUpper() == product).Value.Select(y => y.StringAbleToDouble()).ToList();
                            var valNo35 = lstAddM.FirstOrDefault(x => x.OrderNo == 35 && x.Product.ToUpper() == product).Value.Select(y => y.StringAbleToDouble()).ToList();
                            var valNo36 = lstAddM.FirstOrDefault(x => x.OrderNo == 36 && x.Product.ToUpper() == product).Value.Select(y => y.StringAbleToDouble()).ToList();
                            var valNo37 = lstAddM.FirstOrDefault(x => x.OrderNo == 37 && x.Product.ToUpper() == product).Value.Select(y => y.StringAbleToDouble()).ToList();
                            var valNo38 = lstAddM.FirstOrDefault(x => x.OrderNo == 38 && x.Product.ToUpper() == product).Value.Select(y => y.StringAbleToDouble()).ToList();
                            var valNo39 = lstAddM.FirstOrDefault(x => x.OrderNo == 39 && x.Product.ToUpper() == product).Value.Select(y => y.StringAbleToDouble()).ToList();
                            var valNo40 = lstAddM.FirstOrDefault(x => x.OrderNo == 40 && x.Product.ToUpper() == product).Value.Select(y => y.StringAbleToDouble()).ToList();
                            var valNo41 = lstAddM.FirstOrDefault(x => x.OrderNo == 41 && x.Product.ToUpper() == product).Value.Select(y => y.StringAbleToDouble()).ToList();

                            var valNo43 = lstAddM.FirstOrDefault(x => x.OrderNo == 43 && x.Product.ToUpper() == product).Value.Select(y => y.StringAbleToDouble()).ToList();
                            var valNo44 = lstAddM.FirstOrDefault(x => x.OrderNo == 44 && x.Product.ToUpper() == product).Value.Select(y => y.StringAbleToDouble()).ToList();
                            var valNo45 = lstAddM.FirstOrDefault(x => x.OrderNo == 45 && x.Product.ToUpper() == product).Value.Select(y => y.StringAbleToDouble()).ToList();
                            var valNo46 = lstAddM.FirstOrDefault(x => x.OrderNo == 46 && x.Product.ToUpper() == product).Value.Select(y => y.StringAbleToDouble()).ToList();
                            var valNo47 = lstAddM.FirstOrDefault(x => x.OrderNo == 47 && x.Product.ToUpper() == product).Value.Select(y => y.StringAbleToDouble()).ToList();
                            // var valNo48 = lstAddM.FirstOrDefault(x => x.OrderNo == 31).Value;
                            for (int i = 0; i < lstDate.Count; i++)
                            {
                                var val = (valNo32[i] > 0 ? valNo32[i] : (i == 0 ? 0 : lstValue[i - 1].StringAbleToDouble())) + (valNo33[i] + valNo34[i] + valNo35[i] + valNo36[i] + valNo37[i]) - (valNo38[i] + valNo39[i] + valNo40[i] + valNo41[i]) - (valNo47[i] + valNo43[i] + valNo44[i] + valNo45[i] + valNo46[i]);
                                lstValue.Add(val.ToString());
                            }
                        }
                        if (formular == 66)
                        {
                            var valNo49 = lstAddM.FirstOrDefault(x => x.OrderNo == 49 && x.Product.ToUpper() == product).Value.Select(y => y.StringAbleToDouble()).ToList();
                            var valNo50 = lstAddM.FirstOrDefault(x => x.OrderNo == 50 && x.Product.ToUpper() == product).Value.Select(y => y.StringAbleToDouble()).ToList();
                            var valNo51 = lstAddM.FirstOrDefault(x => x.OrderNo == 51 && x.Product.ToUpper() == product).Value.Select(y => y.StringAbleToDouble()).ToList();
                            var valNo52 = lstAddM.FirstOrDefault(x => x.OrderNo == 52 && x.Product.ToUpper() == product).Value.Select(y => y.StringAbleToDouble()).ToList();
                            var valNo53 = lstAddM.FirstOrDefault(x => x.OrderNo == 53 && x.Product.ToUpper() == product).Value.Select(y => y.StringAbleToDouble()).ToList();
                            var valNo54 = lstAddM.FirstOrDefault(x => x.OrderNo == 54 && x.Product.ToUpper() == product).Value.Select(y => y.StringAbleToDouble()).ToList();
                            var valNo55 = lstAddM.FirstOrDefault(x => x.OrderNo == 55 && x.Product.ToUpper() == product).Value.Select(y => y.StringAbleToDouble()).ToList();
                            var valNo56 = lstAddM.FirstOrDefault(x => x.OrderNo == 56 && x.Product.ToUpper() == product).Value.Select(y => y.StringAbleToDouble()).ToList();
                            var valNo57 = lstAddM.FirstOrDefault(x => x.OrderNo == 57 && x.Product.ToUpper() == product).Value.Select(y => y.StringAbleToDouble()).ToList();
                            var valNo58 = lstAddM.FirstOrDefault(x => x.OrderNo == 58 && x.Product.ToUpper() == product).Value.Select(y => y.StringAbleToDouble()).ToList();
                            var valNo59 = lstAddM.FirstOrDefault(x => x.OrderNo == 59 && x.Product.ToUpper() == product).Value.Select(y => y.StringAbleToDouble()).ToList();

                            var valNo61 = lstAddM.FirstOrDefault(x => x.OrderNo == 61 && x.Product.ToUpper() == product).Value.Select(y => y.StringAbleToDouble()).ToList();
                            var valNo62 = lstAddM.FirstOrDefault(x => x.OrderNo == 62 && x.Product.ToUpper() == product).Value.Select(y => y.StringAbleToDouble()).ToList();
                            var valNo63 = lstAddM.FirstOrDefault(x => x.OrderNo == 63 && x.Product.ToUpper() == product).Value.Select(y => y.StringAbleToDouble()).ToList();
                            var valNo64 = lstAddM.FirstOrDefault(x => x.OrderNo == 64 && x.Product.ToUpper() == product).Value.Select(y => y.StringAbleToDouble()).ToList();
                            var valNo65 = lstAddM.FirstOrDefault(x => x.OrderNo == 65 && x.Product.ToUpper() == product).Value.Select(y => y.StringAbleToDouble()).ToList();

                            for (int i = 0; i < lstDate.Count; i++)
                            {
                                var val = (valNo49[i] > 0 ? valNo49[i] : (i == 0 ? 0 : lstValue[i - 1].StringAbleToDouble())) + (valNo50[i] + valNo51[i] + valNo52[i] + valNo53[i] + valNo54[i]) - (valNo55[i] + valNo56[i] + valNo57[i] + valNo58[i] + valNo59[i]) - (valNo61[i] + valNo62[i] + valNo63[i] + valNo64[i] + valNo65[i]);
                                lstValue.Add(val.ToString());
                            }
                        }
                        if (formular == 67)
                        {
                            var valNo31 = lstAddM.FirstOrDefault(x => x.OrderNo == 31 && x.Product.ToUpper() == product).Value.Select(y => y.StringAbleToDouble()).ToList();
                            var valNo48 = lstAddM.FirstOrDefault(x => x.OrderNo == 48 && x.Product.ToUpper() == product).Value.Select(y => y.StringAbleToDouble()).ToList();
                            var valNo66 = lstAddM.FirstOrDefault(x => x.OrderNo == 66 && x.Product.ToUpper() == product).Value.Select(y => y.StringAbleToDouble()).ToList();
                            for (int i = 0; i < lstDate.Count; i++)
                            {
                                var val = valNo31[i] + valNo48[i] + valNo66[i];
                                lstValue.Add(val.ToString());
                            }
                        }
                        if (formular == 68)
                        {
                            var valNo2 = lstAddM.FirstOrDefault(x => x.OrderNo == 2 && x.Product.ToUpper() == product).Value.Select(y => y.StringAbleToDouble()).ToList();
                            var valNo67 = lstAddM.FirstOrDefault(x => x.OrderNo == 67 && x.Product.ToUpper() == product).Value.Select(y => y.StringAbleToDouble()).ToList();
                            for (int i = 0; i < lstDate.Count; i++)
                            {
                                var val = valNo67[i] - valNo2[i];
                                lstValue.Add(val.ToString());
                            }
                        }
                        if (formular == 69)
                        {
                            var valNo4 = lstAddM.FirstOrDefault(x => x.OrderNo == 4 && x.Product.ToUpper() == product).Value.Select(y => y.StringAbleToDouble()).ToList();
                            var valNo67 = lstAddM.FirstOrDefault(x => x.OrderNo == 67 && x.Product.ToUpper() == product).Value.Select(y => y.StringAbleToDouble()).ToList();
                            for (int i = 0; i < lstDate.Count; i++)
                            {
                                var val = valNo67[i] - valNo4[i];
                                lstValue.Add(val.ToString());
                            }
                        }
                        if (formular == 71)
                        {
                            var valNo70 = lstAddM.FirstOrDefault(x => x.OrderNo == 70 && x.Product.ToUpper() == product).Value.Select(y => y.StringAbleToDouble()).ToList();
                            var valNo67 = lstAddM.FirstOrDefault(x => x.OrderNo == 67 && x.Product.ToUpper() == product).Value.Select(y => y.StringAbleToDouble()).ToList();
                            for (int i = 0; i < lstDate.Count; i++)
                            {
                                var val = valNo67[i] - valNo70[i];
                                lstValue.Add(val.ToString());
                            }

                        }
                        lstAddM.Add(new MpManpowerOp1Monthly
                        {
                            // Item = item.Item,
                            Date = lstDate.ToArray(),
                            Value = lstValue.ToArray(),
                            OrderNo = formular,
                            Product = product,
                            TypePs = type,
                            Version = version[0]
                        });
                        
                    }
                }
                context.RemoveRange(lstDelM);
                context.AddRange(lstAddM);
                context.RemoveRange(lstDelW);
                context.AddRange(lstAddW);
                context.SaveChanges();

                var checkGroupReceive = context.AdmDetailUserGroups.Include(x => x.User).Where(x => x.Active == true && x.GroupId == new Guid("c33ffa8f-e9e9-4dd5-a73f-ab08d8f12819")).ToList();

                if (checkGroupReceive.Count > 0)
                {
                    var link = "http://cvn-vpsi/#/manpower/output1/op1";
                    var lstReceiver = checkGroupReceive.Where(x => x.User.Active == true && x.User.Email != null && x.User.Email != "").Select(y => y.User.Email).ToList();
                    SendMailDoneOutputMp(lstReceiver, link);
                }
                //res.Error = false;
                //res.Message = "Successfully !";
                //res.Status = (int)HttpStatusCode.OK;
                //return res;
            }
            catch (Exception e)
            {
                //res.Error = true;
                //res.Message = e.Message;
                //res.Status = (int)HttpStatusCode.BadRequest;
                //SendMailError(e);
                //return res;
            }
        }
        private async Task UpdateOp2Task(string[] version, string dept, string type)
        {
            var lstUpdate = new List<MpManpowerOp2Daily>();
            var lstAdd = new List<MpManpowerOp2Daily>();
            var calendar = context.AdmMasterCalendars.ToList();
            //lấy order 69 vì đấy là index của row cần tính
            //var version = context.MpManpowerTimes.FirstOrDefault(x => x.Active == true).Version;
            var model = await context.MpManpowerItems
                    .Where(x => x.TypePs == type && x.Version == version[0] && x.ApprovedDate != null && x.ApprovedBy != null && x.Dept.ToUpper() == dept.ToUpper() && x.OrderNo == 69)
                    .OrderBy(x => x.OrderNo)
                    .ToListAsync();
            //var lstCal = context.MpManpowerOp1Dailies.GroupBy(x => x.Product).Select(x => x.First()).ToList();
            var lstOP2 = context.MpManpowerOp2Dailies.Where(x => x.TypePs == type && x.Version == version[0] && x.Dept.ToUpper() == dept.ToUpper()).ToList();
            foreach (var item in model)
            {
                if (lstOP2.Count == 0)
                {
                    lstAdd.Add(new MpManpowerOp2Daily
                    {
                        Dept = dept.ToUpper(),
                        Product = item.Product,
                        Date = item.Date,
                        Value = item.Value,
                        TypePs = type,
                        Version = version[0]
                    });
                }
                else
                {
                    var itemDept = lstOP2.Where(x => x.Product == item.Product).FirstOrDefault();
                    var fromModel = item.Date[0];
                    var toModel = item.Date[item.Date.Length - 1];
                    var fromDept = itemDept.Date[0];
                    var toDept = itemDept.Date[itemDept.Date.Length - 1];
                    var itemCal = item.Date.ToList();
                    if (fromModel < fromDept)
                    {
                        var lstConcatStart = calendar.Where(x => x.DateOfDate >= fromModel && x.DateOfDate < fromDept).Select(x => "").ToList();

                        if (toModel <= toDept)
                        {
                            var newCal = calendar.Where(x => x.DateOfDate >= fromModel && x.DateOfDate <= toDept).Select(x => x.DateOfDate).ToList();

                            itemDept.Date = newCal.ToArray();
                            itemDept.Value = (lstConcatStart.Concat(itemDept.Value.ToList())).ToArray();
                            var i = 0;
                            foreach (var date in itemCal)
                            {
                                var index = newCal.IndexOf(date);
                                itemDept.Value[index] = item.Value[i];
                                i++;
                            }
                            lstUpdate.Add(itemDept);
                        }
                        else
                        {
                            var lstConcatEnd = calendar.Where(x => x.DateOfDate > toDept && x.DateOfDate <= toModel).Select(x => "").ToList();
                            var newCal = calendar.Where(x => x.DateOfDate >= fromModel && x.DateOfDate <= toModel).Select(x => x.DateOfDate).ToList();
                            itemDept.Date = newCal.ToArray();
                            itemDept.Value = (lstConcatStart.Concat(itemDept.Value.ToList()).Concat(lstConcatEnd)).ToArray();
                            var i = 0;
                            foreach (var date in itemCal)
                            {
                                var index = newCal.IndexOf(date);
                                itemDept.Value[index] = item.Value[i];
                                i++;
                            }
                            lstUpdate.Add(itemDept);
                        }

                    }
                    else
                    {
                        var lstConcatEnd = calendar.Where(x => x.DateOfDate > toDept && x.DateOfDate <= toModel).Select(x => "").ToList();
                        var newCal = calendar.Where(x => x.DateOfDate >= fromDept && x.DateOfDate <= toModel).Select(x => x.DateOfDate).ToList();
                        itemDept.Date = newCal.ToArray();
                        itemDept.Value = (itemDept.Value.ToList().Concat(lstConcatEnd)).ToArray();
                        var i = 0;
                        foreach (var date in itemCal)
                        {
                            var index = newCal.IndexOf(date);
                            itemDept.Value[index] = item.Value[i];
                            i++;
                        }
                        lstUpdate.Add(itemDept);
                    }


                }
            }
            //xóa all đi vì mình tính lại mà
            var delAllModel = context.MpManpowerOp2Dailies.Where(x => x.TypePs == type && x.Version == version[0] && x.Product == "ALL" && x.Dept.ToUpper() == dept.ToUpper()).ToList();
            //concat vì 1 trong 2 thằng sẽ có thằng null nên không conflict được
            var lstAllModel = lstAdd.Concat(lstUpdate);


            var minDate = lstAllModel.Min(x => x.Date[0]);
            var maxDate = lstAllModel.Max(x => x.Date[x.Date.Length - 1]);
            var newCalItem = calendar.Where(x => x.DateOfDate >= minDate && x.DateOfDate <= maxDate).Select(x => x.DateOfDate).ToList();
            var lstValue = newCalItem.Select(x => "").ToList();
            foreach (var i in lstAllModel)
            {
                var itemDate = i.Date.ToList();
                var itemValue = i.Value.ToList();
                foreach (var date in newCalItem)
                {
                    var index = newCalItem.IndexOf(date);
                    var indexItem = itemDate.IndexOf(date);
                    if (indexItem != -1)
                    {
                        if (lstValue[index] == "" && itemValue[indexItem] == "")
                        {
                            lstValue[index] = "";
                        }
                        else if (lstValue[index] == "" && itemValue[indexItem] != "")
                        {
                            lstValue[index] = itemValue[indexItem];
                        }
                        else if (lstValue[index] != "" && itemValue[indexItem] == "")
                        {
                            lstValue[index] = lstValue[index];
                        }
                        else if (lstValue[index] != "" && itemValue[indexItem] != "")
                        {
                            lstValue[index] = (lstValue[index].StringAbleToDouble() + itemValue[indexItem].StringAbleToDouble()).ToString();
                        }
                    }
                }
            }
            lstAdd.Add(new MpManpowerOp2Daily
            {
                Date = newCalItem.ToArray(),
                Value = lstValue.ToArray(),
                Product = "ALL",
                Dept = dept.ToUpper(),
                TypePs = type,
                Version = version[0]
            });

            context.RemoveRange(delAllModel);
            context.AddRange(lstAdd);
            context.UpdateRange(lstUpdate);
            context.SaveChanges();

            var lstDaily = context.MpManpowerOp2Dailies.Where(x => x.TypePs == type && x.Version == version[0] && x.Dept.ToUpper() == dept.ToUpper()).ToList();
            //Insert cho weekly
            var lstAddW = new List<MpManpowerOp2Weekly>();
            var lstDelW = context.MpManpowerOp2Weeklies.Where(x => x.TypePs == type && x.Version == version[0] && x.Dept.ToUpper() == dept.ToUpper()).ToList();

            foreach (var item in lstDaily)
            {
                var lstDateW = new List<DateOnly>();
                var lstValueW = new List<string>();
                var lstWeek = calendar.Where(x => (x.DateOfDate >= item.Date[0].AddDays(-6) && x.DateOfDate <= item.Date[item.Date.Length - 1].AddDays(6)) && x.DayOfWeek == "MON").Select(x => x.DateOfDate).ToList();
                var itemDate = item.Date.ToList();
                var itemValue = item.Value.ToList();
                foreach (var week in lstWeek)
                {
                    //var endDate = DateOnly.FromDateTime(new DateTime(month.Year, month.Month, DateTime.DaysInMonth(month.Year, month.Month)));
                    lstDateW.Add(week);
                    var cal = itemDate.Where(x => x >= week && x < week.AddDays(7)).ToList();
                    string val = "";
                    foreach (var date in cal)
                    {
                        var index = itemDate.IndexOf(date);

                        if (index != -1)
                        {
                            if (itemValue[index] == "" && val == "")
                            {
                                val = "";
                            }
                            else if (itemValue[index] == "" && val != "")
                            {
                                val = val;
                            }
                            else if (itemValue[index] != "" && val == "")
                            {
                                val = itemValue[index];
                            }
                            else if (item.Value[index] != "" && val != "")
                            {
                                val = (Math.Round(item.Value[index].StringAbleToDouble() + val.StringAbleToDouble(), 0)).ToString();
                            }
                        }

                    }
                    lstValueW.Add(val);
                }
                lstAddW.Add(new MpManpowerOp2Weekly
                {
                    Date = lstDateW.ToArray(),
                    Value = lstValueW.ToArray(),
                    Product = item.Product,
                    Dept = dept,
                    TypePs = type,
                    Version = version[0]
                });
            }

            //Insert cho monthly
            var lstAddM = new List<MpManpowerOp2Monthly>();
            var lstDelM = context.MpManpowerOp2Monthlies.Where(x => x.TypePs == type && x.Version == version[0] && x.Dept.ToUpper() == dept.ToUpper()).ToList();

            foreach (var item in lstDaily)
            {
                var lstDateM = new List<DateOnly>();
                var lstValueM = new List<string>();
                var lstMonth = item.Date.Select(x => new { Month = x.Month, Year = x.Year }).Distinct().ToList();
                var itemDate = item.Date.ToList();
                var itemValue = item.Value.ToList();
                foreach (var month in lstMonth)
                {
                    var startDate = DateOnly.FromDateTime(new DateTime(month.Year, month.Month, 1));
                    var endDate = DateOnly.FromDateTime(new DateTime(month.Year, month.Month, DateTime.DaysInMonth(month.Year, month.Month)));
                    lstDateM.Add(endDate);
                    var cal = itemDate.Where(x => x >= startDate && x <= endDate).ToList();
                    string val = "";
                    foreach (var date in cal)
                    {
                        var index = itemDate.IndexOf(date);

                        if (itemValue[index] == "" && val == "")
                        {
                            val = "";
                        }
                        else if (itemValue[index] == "" && val != "")
                        {
                            val = val;
                        }
                        else if (itemValue[index] != "" && val == "")
                        {
                            val = itemValue[index];
                        }
                        else if (item.Value[index] != "" && val != "")
                        {
                            val = (Math.Round(item.Value[index].StringAbleToDouble() + val.StringAbleToDouble(), 0)).ToString();
                        }
                    }
                    lstValueM.Add(val);
                }
                lstAddM.Add(new MpManpowerOp2Monthly
                {
                    Date = lstDateM.ToArray(),
                    Value = lstValueM.ToArray(),
                    Product = item.Product,
                    Dept = dept,
                    TypePs = type,
                    Version = version[0]

                });
            }

            context.RemoveRange(lstDelM);
            context.AddRange(lstAddM);
            context.RemoveRange(lstDelW);
            context.AddRange(lstAddW);
            context.SaveChanges();

        }
        private async Task UpdateOp3DailyTask(string dept, string type)
        {
            var lstOrderNo = new List<int?>() { 21, 22, 25, 38, 39, 42, 56, 57, 60 };
            var lstUpdate = new List<MpManpowerOp3Daily>();
            var lstAdd = new List<MpManpowerOp3Daily>();
            var calendar = context.AdmMasterCalendars.ToList();
            //var version = context.MpManpowerTimes.FirstOrDefault(x => x.Active == true).Version;
            var model = await context.MpManpowerItems
                    .Where(x =>/*x.Version  == version &&*/x.TypePs == type && x.Active == true && x.ApprovedDate != null && x.ApprovedBy != null && x.Dept.ToUpper() == dept.ToUpper() && lstOrderNo.Contains(x.OrderNo))
                    .OrderBy(x => x.OrderNo)
                    .ToListAsync();
            var lstOP3 = context.MpManpowerOp3Dailies.Where(x => x.Dept.ToUpper() == dept.ToUpper() && x.TypePs == type).FirstOrDefault();

            var minDate = model.Min(x => x.Date[0]);
            var maxDate = model.Max(x => x.Date[x.Date.Length - 1]);
            var newCalItem = calendar.Where(x => x.DateOfDate >= minDate && x.DateOfDate <= maxDate).Select(x => x.DateOfDate).ToList();
            var planValue = new List<string>();
            var actualValue = new List<string>();
            var differValue = new List<string>();
            var lastest_date = DateOnly.FromDateTime(model.FirstOrDefault().CreatedDate.Value.UnsetKindUtc());

            foreach (var cal in newCalItem)
            {
                var value = "";
                foreach (var item in model)
                {
                    var index = item.Date.ToList().IndexOf(cal);
                    if (index != -1)
                    {
                        if (value == "" && item.Value[index] == "")
                        {
                            value = "";
                        }
                        else if (value == "" && item.Value[index] != "")
                        {
                            value = item.Value[index];
                        }
                        else if (value != "" && item.Value[index] == "")
                        {
                            value = value;
                        }
                        else if (value != "" && item.Value[index] != "")
                        {
                            value = (item.Value[index].StringAbleToDouble() + value.StringAbleToDouble()).ToString();
                        }
                    }
                }
                planValue.Add(value);
            }
            if (lstOP3 == null)
            {
                List<string> lstDiffer = planValue.Select(x => "").ToList();
                foreach (var calDiffer in newCalItem)
                {
                    var index = newCalItem.IndexOf(calDiffer);
                    if (index != -1)
                    {
                        lstDiffer[index] = (0 - planValue[index].StringAbleToDouble()).ToString();
                    }

                }

                lstAdd.Add(new MpManpowerOp3Daily
                {
                    Dept = dept,
                    Date = newCalItem.ToArray(),
                    PlanValue = planValue.ToArray(),
                    ActualValue = planValue.Select(x => "").ToArray(),
                    DifferValue = lstDiffer.ToArray(),
                    LatestUpdate = lastest_date,
                    TypePs = type
                    //Version = version
                });
            }
            else
            {
                var dateOp3 = lstOP3.Date.ToList();
                //update value cho plan
                var dateUdPlan = newCalItem.Where(x => x >= lastest_date).ToList();
                foreach (var calPlan in dateUdPlan)
                {
                    var index = dateOp3.IndexOf(calPlan);
                    var indexValue = newCalItem.IndexOf(calPlan);
                    if (index != -1)
                    {
                        lstOP3.PlanValue[index] = planValue[indexValue];
                    }
                }
                //update value cho actual
                var dateUdActual = newCalItem.Where(x => x >= lstOP3.LatestUpdate && x < lastest_date).ToList();
                foreach (var calActual in dateUdActual)
                {
                    var index = dateOp3.IndexOf(calActual);
                    var indexValue = newCalItem.IndexOf(calActual);
                    if (index != -1)
                    {
                        lstOP3.ActualValue[index] = planValue[indexValue];
                    }
                }

                //update differ
                foreach (var calDiffer in newCalItem)
                {
                    var index = dateOp3.IndexOf(calDiffer);
                    if (index != -1)
                    {
                        lstOP3.DifferValue[index] = (lstOP3.ActualValue[index].StringAbleToDouble() - lstOP3.PlanValue[index].StringAbleToDouble()).ToString();
                    }

                }
                lstOP3.LatestUpdate = lastest_date;
                lstUpdate.Add(lstOP3);

            }
            context.AddRange(lstAdd);
            context.UpdateRange(lstUpdate);
            context.SaveChanges();
        }
        private async Task UpdateOp3MonthTask(string dept, string type)
        {
            var lstOrderNo = new List<int?>() { 0, 21, 38, 56, 22, 39, 57, 25, 42, 62, 26, 43, 61 };

            var lstItem = new List<string?>() { "WKL", "Resign estimation", "Resign having form", "Resign of temporary transfer", "Contract end CVN", "Contract end VOC", "Contract end Shorterm" };

            var lstData = new List<MpManpowerOp3Monthly>();
            var lstAdd = new List<MpManpowerOp3Monthly>();
            var lstUpdate = new List<MpManpowerOp3Monthly>();
            var calendar = context.AdmMasterCalendars.ToList();
            var model = await context.MpManpowerItems
                    .Where(x => x.TypePs == type && x.Active == true && x.ApprovedDate != null && x.ApprovedBy != null && x.Dept.ToUpper() == dept.ToUpper() && lstOrderNo.Contains(x.OrderNo))
                    .OrderBy(x => x.OrderNo)
                    .ToListAsync();
            var lstOP3 =await context.MpManpowerOp3Monthlies.Where(x => x.TypePs == type && x.Dept.ToUpper() == dept.ToUpper()).ToListAsync();

            //Insert cho monthly

            var lstProduct = model.GroupBy(x => x.Product).ToList();
            var itemDate = model.FirstOrDefault().Date.ToList();
            var lstMonth = itemDate.Select(x => new { Month = x.Month, Year = x.Year }).Distinct().ToList();
            var lstDell = context.MpManpowerOp3Monthlies.Where(x => x.TypePs == type && x.Dept.ToUpper() == dept.ToUpper() && (x.Type == "New" || x.Type == "Differ")).ToList();

            foreach (var product in lstProduct)
            {
                int i = 0;
                var lstValTotal = new List<List<string>>();
                var lstValueWKL = new List<string>();
                var lstValTotalR = new List<List<string>>();
                foreach (var item in lstItem)
                {
                    var lstDateM = new List<DateOnly>();
                    var lstValueM = new List<string>();
                    foreach (var month in lstMonth)
                    {
                        var startDate = DateOnly.FromDateTime(new DateTime(month.Year, month.Month, 1));
                        var endDate = DateOnly.FromDateTime(new DateTime(month.Year, month.Month, DateTime.DaysInMonth(month.Year, month.Month)));
                        var cal = itemDate.Where(x => x >= startDate && x <= endDate).ToList();
                        lstDateM.Add(endDate);
                        string val = "";
                        if (i == 0)
                        {
                            var itemValue = product.FirstOrDefault(x => x.OrderNo == 0).Value;
                            foreach (var date in cal)
                            {
                                var index = itemDate.IndexOf(date);
                                val = (itemValue[index].StringAbleToDouble() + val.StringAbleToDouble()).ToString();

                            }
                            lstValueM.Add(val);
                            lstValueWKL.Add(val);
                        }
                        if (i == 1)
                        {
                            var itemValue1 = product.FirstOrDefault(x => x.OrderNo == 21).Value;
                            var itemValue2 = product.FirstOrDefault(x => x.OrderNo == 38).Value;
                            var itemValue3 = product.FirstOrDefault(x => x.OrderNo == 56).Value;
                            foreach (var date in cal)
                            {
                                var index = itemDate.IndexOf(date);
                                val = (itemValue1[index].StringAbleToDouble() + itemValue2[index].StringAbleToDouble() + itemValue3[index].StringAbleToDouble() + val.StringAbleToDouble()).ToString();

                            }
                            lstValueM.Add(val);
                        }
                        if (i == 2)
                        {
                            var itemValue1 = product.FirstOrDefault(x => x.OrderNo == 22).Value;
                            var itemValue2 = product.FirstOrDefault(x => x.OrderNo == 39).Value;
                            var itemValue3 = product.FirstOrDefault(x => x.OrderNo == 57).Value;
                            foreach (var date in cal)
                            {
                                var index = itemDate.IndexOf(date);
                                val = (itemValue1[index].StringAbleToDouble() + itemValue2[index].StringAbleToDouble() + itemValue3[index].StringAbleToDouble() + val.StringAbleToDouble()).ToString();

                            }
                            lstValueM.Add(val);
                        }
                        if (i == 3)
                        {
                            var itemValue1 = product.FirstOrDefault(x => x.OrderNo == 25).Value;
                            var itemValue2 = product.FirstOrDefault(x => x.OrderNo == 42).Value;
                            var itemValue3 = product.FirstOrDefault(x => x.OrderNo == 62).Value;
                            foreach (var date in cal)
                            {
                                var index = itemDate.IndexOf(date);
                                val = (itemValue1[index].StringAbleToDouble() + itemValue2[index].StringAbleToDouble() + itemValue3[index].StringAbleToDouble() + val.StringAbleToDouble()).ToString();

                            }
                            lstValueM.Add(val);
                        }
                        if (i == 4)
                        {
                            var itemValue = product.FirstOrDefault(x => x.OrderNo == 26).Value;
                            foreach (var date in cal)
                            {
                                var index = itemDate.IndexOf(date);
                                val = (itemValue[index].StringAbleToDouble() + val.StringAbleToDouble()).ToString();

                            }
                            lstValueM.Add(val);
                        }
                        if (i == 5)
                        {
                            var itemValue = product.FirstOrDefault(x => x.OrderNo == 43).Value;
                            foreach (var date in cal)
                            {
                                var index = itemDate.IndexOf(date);
                                val = (itemValue[index].StringAbleToDouble() + val.StringAbleToDouble()).ToString();

                            }
                            lstValueM.Add(val);
                        }
                        if (i == 6)
                        {
                            var itemValue = product.FirstOrDefault(x => x.OrderNo == 61).Value;
                            foreach (var date in cal)
                            {
                                var index = itemDate.IndexOf(date);
                                val = (itemValue[index].StringAbleToDouble() + val.StringAbleToDouble()).ToString();

                            }
                            lstValueM.Add(val);
                        }

                    }
                    if (i != 0)
                    {
                        lstValTotal.Add(lstValueM);
                    }

                    lstAdd.Add(new MpManpowerOp3Monthly
                    {
                        Dept = dept.ToUpper(),
                        Product = product.First().Product,
                        Date = lstDateM.ToArray(),
                        OrderNo = i,
                        Item = item,
                        Value = lstValueM.ToArray(),
                        Type = "New",
                        TypePs = type
                    });
                    if (i != 0)
                    {
                        var valRatio = new List<string>();
                        for (int j = 0; j < lstValueM.Count; j++)
                        {
                            if (lstValueWKL[j].StringAbleToDouble() != 0)
                            {
                                valRatio.Add((lstValueM[j].StringAbleToDouble() / lstValueWKL[j].StringAbleToDouble()).ToString());
                            }
                            else
                            {
                                valRatio.Add("");
                            }
                        }
                        lstValTotalR.Add(valRatio);
                        lstAdd.Add(new MpManpowerOp3Monthly
                        {
                            Dept = dept.ToUpper(),
                            Product = product.First().Product,
                            Date = lstDateM.ToArray(),
                            OrderNo = i + 7,
                            Item = item + "_ratio",
                            Value = valRatio.ToArray(),
                            Type = "New",
                            TypePs = type
                        });
                    }
                    i++;
                }
                var valTotal = SumArrays(lstValTotal);
                lstAdd.Add(new MpManpowerOp3Monthly
                {
                    Dept = dept.ToUpper(),
                    Product = product.First().Product,
                    Date = lstAdd.First().Date.ToArray(),
                    OrderNo = i,
                    Item = "TTL",
                    Value = valTotal.ToArray(),
                    Type = "New",
                    TypePs = type
                });
                var valTotalR = SumArrays(lstValTotalR);
                lstAdd.Add(new MpManpowerOp3Monthly
                {
                    Dept = dept.ToUpper(),
                    Product = product.First().Product,
                    Date = lstAdd.First().Date.ToArray(),
                    OrderNo = i + 7,
                    Item = "TTL_ratio",
                    Value = valTotalR.ToArray(),
                    Type = "New",
                    TypePs = type
                });
            }

            foreach (var item in lstAdd)
            {
                var checkOld = lstOP3.FirstOrDefault(x => x.Active == true && x.OrderNo == item.OrderNo && x.Product == item.Product && x.Type.Contains("Old"));
                var checkNew = lstOP3.FirstOrDefault(x => x.Active == true && x.OrderNo == item.OrderNo && x.Product == item.Product && x.Type.Contains("New"));
                if (checkOld == null && checkNew != null)
                {
                    checkNew.Type = "Old";
                    lstUpdate.Add(checkNew);

                }
                else if (checkOld != null && checkNew != null)
                {
                    var lstDateNew = item.Date.ToList();
                    checkOld.Date = checkOld.Date.ToList().Concat(lstDateNew.Where(x => !checkOld.Date.ToList().Contains(x)).ToList()).OrderBy(x => x).ToArray();

                    foreach (var cal in lstDateNew)
                    {
                        var indexOld = checkOld.Date.ToList().IndexOf(cal);
                        var indexNew = checkNew.Date.ToList().IndexOf(cal);
                        if (indexNew != -1)
                        {
                            checkOld.Value[indexOld] = checkNew.Value[indexNew];
                        }
                        else
                        {
                            if (indexOld >= checkOld.Value.Length)
                            {
                                checkOld.Value[indexOld] = "";
                            }

                        }
                    }
                    lstUpdate.Add(checkOld);
                }
            }

            context.RemoveRange(lstDell);
            context.AddRange(lstAdd);
            context.UpdateRange(lstUpdate);
            context.SaveChanges();

            //calc differ again
            var newLstOp3 = context.MpManpowerOp3Monthlies.Where(x => x.TypePs == type && x.Active == true && x.Dept.ToUpper() == dept.ToUpper()).ToList();
            var lstAddDiffer = new List<MpManpowerOp3Monthly>();

            //IJ
            var op3Ij = newLstOp3.Where(x => x.Type == "New" && x.Product == "IJ").OrderBy(x => x.OrderNo).ToList();

            foreach (var item in op3Ij)
            {
                //var lstDate = new List<DateOnly>();
                var lstValue = new List<string>();
                var oldOp3 = newLstOp3.FirstOrDefault(x => x.OrderNo == item.OrderNo && x.Type != item.Type && x.Product == item.Product);
                if (oldOp3 == null)
                {
                    lstAddDiffer.Add(new MpManpowerOp3Monthly
                    {
                        Dept = dept.ToUpper(),
                        Product = item.Product,
                        Date = item.Date,
                        OrderNo = item.OrderNo,
                        Item = item.Item,
                        Value = item.Value,
                        Type = "Differ",
                        TypePs = type
                    });
                }
                else
                {
                    var dateOld = oldOp3.Date.ToList();
                    var dateN = item.Date.ToList();
                    var valDiffer = new List<string>();
                    foreach (var cal in dateOld)
                    {
                        var indexN = dateN.IndexOf(cal);
                        var indexO = dateOld.IndexOf(cal);
                        if (indexN == -1)
                        {
                            valDiffer.Add(oldOp3.Value[indexO]);
                        }
                        else
                        {
                            valDiffer.Add((item.Value[indexN].StringAbleToDouble() - oldOp3.Value[indexO].StringAbleToDouble()).ToString());
                        }
                    }
                    lstAddDiffer.Add(new MpManpowerOp3Monthly
                    {
                        Dept = dept.ToUpper(),
                        Product = item.Product,
                        Date = dateOld.ToArray(),
                        OrderNo = item.OrderNo,
                        Item = item.Item,
                        Value = valDiffer.ToArray(),
                        Type = "Differ",
                        TypePs = type
                    });
                }

            }

            //LBP
            var op3Lbp = newLstOp3.Where(x => x.Type == "New" && x.Product == "LBP").OrderBy(x => x.OrderNo).ToList();

            foreach (var item in op3Lbp)
            {
                //var lstDate = new List<DateOnly>();
                var lstValue = new List<string>();
                var oldOp3 = newLstOp3.FirstOrDefault(x => x.OrderNo == item.OrderNo && x.Type != item.Type && x.Product == item.Product);
                if (oldOp3 == null)
                {
                    lstAddDiffer.Add(new MpManpowerOp3Monthly
                    {
                        Dept = dept.ToUpper(),
                        Product = item.Product,
                        Date = item.Date,
                        OrderNo = item.OrderNo,
                        Item = item.Item,
                        Value = item.Value,
                        Type = "Differ",
                        TypePs = type
                    });
                }
                else
                {
                    var dateOld = oldOp3.Date.ToList();
                    var dateN = item.Date.ToList();
                    var valDiffer = new List<string>();
                    foreach (var cal in dateOld)
                    {
                        var indexN = dateN.IndexOf(cal);
                        var indexO = dateOld.IndexOf(cal);
                        if (indexN == -1)
                        {
                            valDiffer.Add(oldOp3.Value[indexO]);
                        }
                        else
                        {
                            valDiffer.Add((item.Value[indexN].StringAbleToDouble() - oldOp3.Value[indexO].StringAbleToDouble()).ToString());
                        }
                    }
                    lstAddDiffer.Add(new MpManpowerOp3Monthly
                    {
                        Dept = dept.ToUpper(),
                        Product = item.Product,
                        Date = dateOld.ToArray(),
                        OrderNo = item.OrderNo,
                        Item = item.Item,
                        Value = valDiffer.ToArray(),
                        Type = "Differ",
                        TypePs = type
                    });
                }

            }

            context.AddRange(lstAddDiffer);
            context.SaveChanges();
        }
        private bool SendMailDoneOutputMp(List<string> lstReceive, string link)
        {
            try
            {
                string txtContent = "<span style = 'font-weight: bold;'>  Dear Mrs/Mr.ALL ,</span><br><br>" +
                "<span>Manpower have new data output</span><br><br>" +
                "<span>You can check it at: " + link + "</span><br><br>" +
                "";


                email.Initial(lstReceive,
                    "[PSI-System] New output manpower",
                    txtContent);
                return false;
            }
            catch
            {
                return false;
            }
        }
        private bool SendMailError(Exception e)
        {
            try
            {
                string txtContent = "<p>Message: " + e.Message + "</p><br>" +
                "<p>Data: " + e.Data.ToString() + "</p><br>" +
                "<p>StackTrace: " + e.StackTrace + "</p><br>" +
                "<p>HelpLink: " + e.HelpLink ?? "" + "</p><br>" +
                "<p>Source: " + e.Source ?? "" + "</p><br>";
                email.InitialDev(
                    "Error exception",
                    txtContent);
                return false;
            }
            catch
            {
                return false;
            }
        }
        [HttpGet("get-list-mgr")]
        public async Task<List<MgrView>> GetListMgr()
        {
            try
            {

                var model = await context.AdmDetailUserGroups.Where(x => x.Active == true && x.GroupId.ToString().Equals("59c15e2d-e6c0-4ec4-a7f2-47db2405f5ce")).Select(x=>x.UserId).ToListAsync();
                var list = context.AdmDetailUserDepts.Include(x => x.Dept).Include(x=>x.User).Where(x => x.Active == true && model.Contains(x.UserId)).Select(x => new MgrView() { Name= x.User.EmployeeCode + "-" + x.User.FullName + "-" + x.Dept.DeptShortName,Value=x.User.EmployeeCode }).ToList();
                return list;
            }
            catch (Exception e)
            {
                //SendMailError(e);
                return new List<MgrView>();
            }
        }
        [HttpPost("approve-plan-rec")]
        public CommonResponse ApprovePlanRec(MpRecDeptPlanParam param)
        {
            CommonResponse res = new CommonResponse()
            {
                Error = false,
                Message = "",
                Status = (int)HttpStatusCode.BadRequest
            };
            try
            {
                var u = GetCurrentUser();
                var model = context.MpRecDeptPlanIp2s.FirstOrDefault(x => x.Active == true && x.Status == 1 && x.DeptName.Equals(param.Department) && x.Model.Equals(param.Product) && x.PeriodId.ToString().Equals(param.PeriodId));
                if(model != null)
                {
                    model.ApproveDate = DateOnly.FromDateTime(DateTime.Now);
                    model.Status = 2;
                }
                var modelDel = context.MpRecDeptPlanIp2s.FirstOrDefault(x => x.Active == true && x.Status == 0 && x.DeptName.Equals(param.Department) && x.Model.Equals(param.Product) && x.PeriodId.ToString().Equals(param.PeriodId));
                if(modelDel != null)
                {
                    context.MpRecDeptPlanIp2s.Remove(modelDel);
                }
                var createdBy = model != null ? model.CreatedBy : modelDel.CreatedBy;
                var user = context.AdmUserInformations.Where(x => x.Active == true && x.EmployeeCode == createdBy).FirstOrDefault();
                var lstRecive = new List<string>() { user.Email };
                var link = "http://cvn-vpsi/#/manpower/recruitment/rec-dept-plan/"+param.PeriodId+"/"+param.Product+"/"+param.Department;
                SendMailApprovedRec(param.Department, u.FullName, lstRecive, user.FullName, link);
                res.Error = false;
                res.Message = "Successfully !";
                res.Status = (int)HttpStatusCode.OK;
                context.SaveChanges();
                return res;
            }
            catch (Exception e)
            {
                res.Error = true;
                res.Message = e.Message;
                res.Status = (int)HttpStatusCode.BadRequest;
                //SendMailError(e);
                return res;
            }


        }
        [HttpPost("reject-plan-rec")]
        public CommonResponse RejectPlanRec(MpRecDeptPlanParam param)
        {
            CommonResponse res = new CommonResponse()
            {
                Error = false,
                Message = "",
                Status = (int)HttpStatusCode.BadRequest
            };
            try
            {
                var u = GetCurrentUser();
                var model = context.MpRecDeptPlanIp2s.FirstOrDefault(x => x.Active == true && x.Status == 0 && x.DeptName.Equals(param.Department) && x.Model.Equals(param.Product) && x.PeriodId.ToString().Equals(param.PeriodId));
                if(model != null)
                {
                    model.ApproveDate = DateOnly.FromDateTime(DateTime.Now);
                    model.Status = 2;
                }
                var modelDel = context.MpRecDeptPlanIp2s.FirstOrDefault(x => x.Active == true && x.Status == 1 && x.DeptName.Equals(param.Department) && x.Model.Equals(param.Product) && x.PeriodId.ToString().Equals(param.PeriodId));
                if(modelDel != null)
                {
                    context.MpRecDeptPlanIp2s.Remove(modelDel);
                }
                var createdBy = modelDel != null ? modelDel.CreatedBy : model.CreatedBy;
                var user = context.AdmUserInformations.Where(x => x.Active == true && x.EmployeeCode == modelDel.CreatedBy).FirstOrDefault();
                var lstRecive = new List<string>() { user.Email };
                var link = "http://cvn-vpsi/#/manpower/recruitment/rec-dept-plan/" + param.PeriodId + "/" + param.Product + "/" + param.Department;
                SendMailRejectRec(param.Department,param.Reason, u.FullName, lstRecive, user.FullName, link);
                res.Error = false;
                res.Message = "Successfully !";
                res.Status = (int)HttpStatusCode.OK;
                context.SaveChanges();
                return res;
            }
            catch (Exception e)
            {
                res.Error = true;
                res.Message = e.Message;
                res.Status = (int)HttpStatusCode.BadRequest;
                //SendMailError(e);
                return res;
            }


        }

        #region Manpower step2.1


        [HttpPost("filter-mp21-ip-master-type-cell")]
        public async Task<Manpower21Ip2TypeCellModel> FilterMp21IpMasterTypeCell(Mp2Ip2MpwTypeCellParam parameters)
        {
            try
            {
                Manpower21Ip2TypeCellModel result = new Manpower21Ip2TypeCellModel()
                {
                    currentPage = parameters.Page,
                    recordPerPage = parameters.RecordsPerPage
                };

                var query = context.MpManpower2MasterTypeCells.Where(x => x.Active == true);


                query = !string.IsNullOrEmpty(parameters.Cell) ? query.Where(x => x.Cell != null && x.Cell.ToUpper().Contains(parameters.Cell.ToUpper())) : query;
                query = !string.IsNullOrEmpty(parameters.Model) ? query.Where(x => x.Model != null && x.Model.ToUpper().Contains(parameters.Model.ToUpper())) : query;
               
                result.totalRecords = await query.CountAsync();
                result.totalPage = (int)Math.Ceiling((decimal)result.totalRecords / parameters.RecordsPerPage);
                var model = await query.Paginate(parameters).ToListAsync();
                var lstResult = new List<Manpower21Ip2TypeCellView>();
                foreach(var item in model)
                {
                    lstResult.Add(new Manpower21Ip2TypeCellView
                    {
                        Cell = item.Cell,
                        Model = item.Model,
                        TypeCellA = item.TypeCellA,
                        TypeCellB = item.TypeCellB,
                        From = item.From == null?null: item.From.Value.ToString("yyyy-MM-dd"),
                        To = item.To == null ? null : item.To.Value.ToString("yyyy-MM-dd")
                    });
                }
                result.lstModel = lstResult;
                result.fromRecord = model.Count == 0 ? 0 : (result.currentPage - 1) * result.recordPerPage + 1;
                result.toRecord = (int)Math.Min(result.totalRecords, result.currentPage * result.recordPerPage);
                result.currentPage = result.totalPage < result.currentPage ? result.totalPage : result.currentPage;
                return result;
            }
            catch (Exception e)
            {
                //SendMailError(e);
                return new Manpower21Ip2TypeCellModel()
                {
                    currentPage = parameters.Page,
                    recordPerPage = parameters.RecordsPerPage
                };
            }
        }
        [HttpPost("filter-mp2-op1")]
        public async Task<Manpower2Op1Model> FilterMp2Op1(Mp2Op1Param parameters)
        {
            try
            {
                Manpower2Op1Model result = new Manpower2Op1Model()
                {
                    currentPage = parameters.Page,
                    recordPerPage = parameters.RecordsPerPage
                };
                DateOnly? fromDate = parameters.FromDate.StringToDateAble();
                DateOnly? toDate = parameters.ToDate.StringToDateAble();
              
                var query = await context.MpManpower2Op1s.Where(x => x.Active == true && x.Fact.ToUpper() == parameters.Fact.ToUpper() && x.Model.ToUpper().Contains(parameters.Model.ToUpper())).OrderBy(x => x.Model).ToListAsync();
                var model = query.Select(x => x.Model).OrderBy(x => x).ToList();
                var lstDate = query.FirstOrDefault().Date.OrderBy(x => x).ToList();
                var lstDateS = fromDate != null ? lstDate.Where(x => x >= fromDate).ToList() : lstDate;
                lstDateS = toDate != null ? lstDateS.Where(x => x <= toDate).ToList() : lstDateS;
                result.totalRecords =  lstDate.Count;
                result.totalPage = (int)Math.Ceiling((decimal)result.totalRecords / parameters.RecordsPerPage);
                var dateSearch =  lstDateS.Paginate(parameters).ToList();
                var lstResult = new List<MP2Op1View>();
                foreach(var date in dateSearch)
                {
                    var lstValue = new List<string>();
                    var index = lstDate.IndexOf(date);
                    foreach(var item in query)
                    {
                        lstValue.Add(item.ValueDay[index]);
                        lstValue.Add(item.ValueNight[index]);
                        lstValue.Add((item.ValueDay[index].StringAbleToDouble() + item.ValueNight[index].StringAbleToDouble()).ToString());
                    }
                    lstResult.Add(new MP2Op1View
                    {
                        Date = date.ToString(),
                        LstValue = lstValue
                    });
                }
                result.lstModel = lstResult;
                result.Model = model;
                result.fromRecord = lstDateS.Count == 0 ? 0 : (result.currentPage - 1) * result.recordPerPage + 1;
                result.toRecord = (int)Math.Min(result.totalRecords, result.currentPage * result.recordPerPage);
                result.currentPage = result.totalPage < result.currentPage ? result.totalPage : result.currentPage;
                return result;
            }
            catch (Exception e)
            {
                //SendMailError(e);
                return new Manpower2Op1Model()
                {
                    currentPage = parameters.Page,
                    recordPerPage = parameters.RecordsPerPage
                };
            }
        }

        [HttpPost("filter-mp2-op21")]
        public async Task<Manpower2Op21Model> FilterMp2Op21(Mp2Op21Param parameters)
        {
            try
            {
                Manpower2Op21Model result = new Manpower2Op21Model()
                {
                    currentPage = parameters.Page,
                    recordPerPage = parameters.RecordsPerPage
                };
                DateOnly? fromDate = parameters.FromDate.StringToDateAble();
                DateOnly? toDate = parameters.ToDate.StringToDateAble();


                var query = context.MpManpower2Op21s.Where(x => x.Active == true && x.Fact.ToUpper() == parameters.Fact.ToUpper());
                query = !string.IsNullOrEmpty(parameters.FromDate) ? query.Where(x => x.Date >= fromDate) : query;
                query = !string.IsNullOrEmpty(parameters.ToDate) ? query.Where(x => x.Date <= toDate) : query;
                var lstCell = query.FirstOrDefault().LstCell.ToList();
                List<int> indexList = new List<int>();
                var lstMasterCell = new List<string>();
                for (int i = 0; i < lstCell.Count; i++)
                {
                    if (lstCell[i].Contains(parameters.Group) && lstCell[i].Contains(parameters.Model) && lstCell[i].Contains(parameters.Cell))
                    {
                        indexList.Add(i);
                        lstMasterCell.Add(lstCell[i]);
                    }
                }
                var lstGroup = lstMasterCell.Select(item =>
                {
                    string[] parts = item.Split(':');
                    return parts[0];
                    
                }).GroupBy(x => x).Select(group => $"{group.Key}: {group.Count()}").ToList();

                var lstModel = lstMasterCell.Select(item =>
                {
                    string[] parts = item.Split(':');
                   
                     return parts[1]+":"+ parts[0];
                }).GroupBy(x => x).Select(group => $"{group.Key}: {group.Count()}").ToList();
                var listCell = lstMasterCell.Select(x => x.Split(":")[2]).ToList();

                var model = await query.OrderBy(x => x.Date).Paginate(parameters).ToListAsync();
                var lstResult = new List<MP2Op21View>();
                foreach(var item in model)
                {
                    var lstValue = new List<string>();
                    foreach (var index in indexList)
                    {
                        var color = item.LstColor[index];
                        lstValue.Add(item.LstValue[index] + "_" +(color != "Accent6" && color != "Background1" && color != ""?color:(color == "Accent6"? "F79646" : "")));
                    }
                    lstResult.Add(new MP2Op21View
                    {
                        Date = item.Date.ToString(),
                        LstValue = lstValue,
                    });
                    
                }


              

                result.totalRecords = await query.CountAsync();
                result.totalPage = (int)Math.Ceiling((decimal)result.totalRecords / parameters.RecordsPerPage);
                result.lstModel = lstResult;
                result.Group = lstGroup;
                result.Model = lstModel;
                result.Cell = listCell;
                result.fromRecord = lstResult.Count == 0 ? 0 : (result.currentPage - 1) * result.recordPerPage + 1;
                result.toRecord = (int)Math.Min(result.totalRecords, result.currentPage * result.recordPerPage);
                result.currentPage = result.totalPage < result.currentPage ? result.totalPage : result.currentPage;
                return result;
            }
            catch (Exception e)
            {
                //SendMailError(e);
                return new Manpower2Op21Model()
                {
                    currentPage = parameters.Page,
                    recordPerPage = parameters.RecordsPerPage
                };
            }
        }       
        [HttpPost("filter-mp2-op22")]
        public async Task<Manpower2Op22Model> FilterMp2Op22(Mp2Op22Param parameters)
        {
            try
            {
                Manpower2Op22Model result = new Manpower2Op22Model()
                {
                    currentPage = parameters.Page,
                    recordPerPage = parameters.RecordsPerPage
                };
                DateOnly? fromDate = parameters.FromDate.StringToDateAble();
                DateOnly? toDate = parameters.ToDate.StringToDateAble();


                var query = context.MpManpower2Op22s.Where(x => x.Active == true && x.Fact.ToUpper() == parameters.Fact.ToUpper());
                query = !string.IsNullOrEmpty(parameters.FromDate) ? query.Where(x => x.Date >= fromDate) : query;
                query = !string.IsNullOrEmpty(parameters.ToDate) ? query.Where(x => x.Date <= toDate) : query;
                var lstModel = query.FirstOrDefault().ModelType.ToList();
                List<int> indexList = new List<int>();
                var lstMasterModel = new List<string>();
              
                for (int i = 0; i < lstModel.Count; i++)
                {
                    if (lstModel[i].ToUpper().Contains(parameters.Model.ToUpper()) && lstModel[i].ToUpper().Contains(parameters.Type.ToUpper()))
                    {
                        indexList.Add(i);
                        lstMasterModel.Add(lstModel[i]);
                    }
                }
                var lstModelAct = lstMasterModel.Select(item =>
                {
                    string[] parts = item.Split(':');
                    return parts[0];

                }).GroupBy(x => x).Select(group => $"{group.Key}: {group.Count()*2}").ToList();
                var lstTypeAct = lstMasterModel.Select(item =>
                {
                    string[] parts = item.Split(':');
                    return parts[1];

                }).ToList();

                var model = await query.OrderBy(x => x.Date).Paginate(parameters).ToListAsync();
                var lstResult = new List<MP2Op22View>();
                foreach (var item in model)
                {
                    var lstValue = new List<string>();
                    foreach (var index in indexList)
                    {
                        var vlueD = item.ValueDay[index];
                        var vlueN = item.ValueNight[index];
                        lstValue.Add(vlueD);
                        lstValue.Add(vlueN);
                    }
                    lstResult.Add(new MP2Op22View
                    {
                        Date = item.Date.ToString(),
                        LstValue = lstValue,
                    });

                }
                result.totalRecords = await query.CountAsync();
                result.totalPage = (int)Math.Ceiling((decimal)result.totalRecords / parameters.RecordsPerPage);
                result.lstModel = lstResult;
                result.Model = lstModelAct;
                result.Type = lstTypeAct;
                result.fromRecord = lstResult.Count == 0 ? 0 : (result.currentPage - 1) * result.recordPerPage + 1;
                result.toRecord = (int)Math.Min(result.totalRecords, result.currentPage * result.recordPerPage);
                result.currentPage = result.totalPage < result.currentPage ? result.totalPage : result.currentPage;
                return result;
            }
            catch (Exception e)
            {
                //SendMailError(e);
                return new Manpower2Op22Model()
                {
                    currentPage = parameters.Page,
                    recordPerPage = parameters.RecordsPerPage
                };
            }
        }

        [HttpPost("filter-mp2-op3")]
        public async Task<Manpower2Op1Model> FilterMp2Op3(Mp2Op1Param parameters)
        {
            try
            {
                Manpower2Op1Model result = new Manpower2Op1Model()
                {
                    currentPage = parameters.Page,
                    recordPerPage = parameters.RecordsPerPage
                };
                DateOnly? fromDate = parameters.FromDate.StringToDateAble();
                DateOnly? toDate = parameters.ToDate.StringToDateAble();


                var query = context.MpManpower2Op3s.Where(x => x.Active == true && x.Fact.ToUpper() == parameters.Fact.ToUpper());
                query = !string.IsNullOrEmpty(parameters.FromDate) ? query.Where(x => x.Date >= fromDate) : query;
                query = !string.IsNullOrEmpty(parameters.ToDate) ? query.Where(x => x.Date <= toDate) : query;
                var lstModel = query.FirstOrDefault().Model.ToList();
                List<int> indexList = new List<int>();
                var lstMasterModel = new List<string>();

                for (int i = 0; i < lstModel.Count; i++)
                {
                    if (lstModel[i].ToUpper().Contains(parameters.Model.ToUpper()) )
                    {
                        indexList.Add(i);
                        lstMasterModel.Add(lstModel[i]);
                    }
                }
               
                var model = await query.OrderBy(x => x.Date).Paginate(parameters).ToListAsync();
                var lstResult = new List<MP2Op1View>();
                foreach (var item in model)
                {
                    var lstValue = new List<string>();
                    foreach (var index in indexList)
                    {
                        var vlueD = item.ValueDay[index];
                        var vlueN = item.ValueNight[index];
                        lstValue.Add(vlueD);
                        lstValue.Add(vlueN);
                    }
                    lstResult.Add(new MP2Op1View
                    {
                        Date = item.Date.ToString(),
                        LstValue = lstValue,
                    });

                }
                result.totalRecords = await query.CountAsync();
                result.totalPage = (int)Math.Ceiling((decimal)result.totalRecords / parameters.RecordsPerPage);
                result.lstModel = lstResult;
                result.Model = lstMasterModel;
               
                result.fromRecord = lstResult.Count == 0 ? 0 : (result.currentPage - 1) * result.recordPerPage + 1;
                result.toRecord = (int)Math.Min(result.totalRecords, result.currentPage * result.recordPerPage);
                result.currentPage = result.totalPage < result.currentPage ? result.totalPage : result.currentPage;
                return result;
            }
            catch (Exception e)
            {
                //SendMailError(e);
                return new Manpower2Op1Model()
                {
                    currentPage = parameters.Page,
                    recordPerPage = parameters.RecordsPerPage
                };
            }
        }

        [HttpPost("filter-mp2-op4")]
        public async Task<Manpower2Op4Model> FilterMp2Op4(Mp2Op4Param parameters)
        {
            try
            {
                Manpower2Op4Model result = new Manpower2Op4Model()
                {
                    currentPage = parameters.Page,
                    recordPerPage = parameters.RecordsPerPage
                };
                DateOnly? fromDate = parameters.FromDate.StringToDateAble();
                DateOnly? toDate = parameters.ToDate.StringToDateAble();


                var query = context.MpManpower2Op4s.Where(x => x.Active == true && x.Fact.ToUpper() == parameters.Fact.ToUpper());
                query = !string.IsNullOrEmpty(parameters.FromDate) ? query.Where(x => x.Date >= fromDate) : query;
                query = !string.IsNullOrEmpty(parameters.ToDate) ? query.Where(x => x.Date <= toDate) : query;
                query = !string.IsNullOrEmpty(parameters.Model) ? query.Where(x => x.Model != null &&  x.Model.ToUpper().Contains(parameters.Model.ToUpper())) : query;
                query = !string.IsNullOrEmpty(parameters.Cell) ? query.Where(x => x.Cell != null && x.Cell.ToUpper().Contains(parameters.Cell.ToUpper())) : query;
                query = !string.IsNullOrEmpty(parameters.Type) ? query.Where(x => x.Type != null && x.Type.ToUpper().Contains(parameters.Type.ToUpper())) : query;
                query = !string.IsNullOrEmpty(parameters.Group) ? query.Where(x => x.Group != null && x.Group.ToUpper().Contains(parameters.Group.ToUpper())) : query;
                query = !string.IsNullOrEmpty(parameters.Remark) ? query.Where(x => x.Remark != null && x.Remark.ToUpper().Contains(parameters.Remark.ToUpper())) : query;

                var model = await query.OrderBy(x => x.Date).Paginate(parameters).ToListAsync();
                var lstResult = new List<MP2Op4View>();
                foreach(var item in model)
                {
                    lstResult.Add(new MP2Op4View
                    {
                        Date = item.Date.ToString(),
                        Model = item.Model,
                        Cell = item.Cell,
                        Type = item.Type,
                        HireDate = item.HireDate.ToString(),
                        MpDate = item.MpDate.ToString(),
                        OpCellAssy = item.OpCellAssy,
                        OpCellPdc2 = item.OpCellPdc2,
                        Remark = item.Remark,
                        Group = item.Group,
                        Color = item.Color

                    });
                }
                
                result.totalRecords = await query.CountAsync();
                result.totalPage = (int)Math.Ceiling((decimal)result.totalRecords / parameters.RecordsPerPage);
                result.lstModel = lstResult;

                result.fromRecord = lstResult.Count == 0 ? 0 : (result.currentPage - 1) * result.recordPerPage + 1;
                result.toRecord = (int)Math.Min(result.totalRecords, result.currentPage * result.recordPerPage);
                result.currentPage = result.totalPage < result.currentPage ? result.totalPage : result.currentPage;
                return result;
            }
            catch (Exception e)
            {
                //SendMailError(e);
                return new Manpower2Op4Model()
                {
                    currentPage = parameters.Page,
                    recordPerPage = parameters.RecordsPerPage
                };
            }
        }
        #endregion
        #region ExcuteData
        [HttpGet("check-job-calc-mpw21-processing/{product}")]
        public async Task<CommonResponse> CheckJobProcessing(string product)
        {
            CommonResponse res = new CommonResponse()
            {
                Error = false,
                Message = "",
                Status = (int)HttpStatusCode.BadRequest
            };
            try
            {

                var monitoringApi = JobStorage.Current.GetMonitoringApi();
                var countSucess = monitoringApi.ProcessingCount();
                var enqueuedJobs = monitoringApi.ProcessingJobs(0, (int)countSucess);

                var jobExists = enqueuedJobs.FirstOrDefault(job => job.Value.Job.Method.Name == "ExcuteAllOutPut21" && job.Value.Job.Arguments[0].Contains(product));

                if (jobExists.Value != null)
                {
                    res.Error = true;
                    res.Message = "Job " + jobExists.Value.Job.Method.Name + product + " is processing, please wait complete!";
                    res.Status = (int)HttpStatusCode.BadRequest;
                }
                else
                {
                    res.Error = false;
                    res.Message = "Successfully !";
                    res.Status = (int)HttpStatusCode.OK;
                }
            }
            catch (Exception e)
            {
                res.Error = true;
                res.Message = e.Message;
                res.Status = (int)HttpStatusCode.BadRequest;
                //SendMailError(e);
            }
            return res;


        }

        [HttpPost("excute-calc-manpower/{product}")]
        public async Task<CommonResponse> ExcuteCalcManpower21(string product)
        {
            CommonResponse res = new CommonResponse()
            {
                Error = false,
                Message = "",
                Status = (int)HttpStatusCode.BadRequest
            };
            try
            {
                await ManualFunc.GatewayAsync("CalcManpowerStep21/" + product);
              // _mpw.ExcuteAllOutPut21(product);
                res.Error = false;
                res.Message = "Successfully !";
                res.Status = (int)HttpStatusCode.OK;
                return res;
            }
            catch (Exception e)
            {
                res.Error = true;
                res.Message = e.Message;
                res.Status = (int)HttpStatusCode.BadRequest;
                //SendMailError(e);
                return res;
            }


        }
        #endregion

        #region Manpower step2.2

        #endregion
    }
    public class Version
    {
        public string? VersionPs { get; set; }
    }
}
