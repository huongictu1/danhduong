﻿using PDCProjectApi.Common;
using PDCProjectApi.Common.Interface;
using PDCProjectApi.Data;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Tokens;
using Npgsql;
using System.IdentityModel.Tokens.Jwt;
using System.Net;
using System.Security.Claims;
using System.Text;
using PDCProjectApi.Model.Request;
using PDCProjectApi.Model.Response;
using PDCProjectApi.Common.Job;
using System.Collections.Concurrent;
using PDCProjectApi.Services;
using System.Diagnostics;
using AutoMapper;
using PDCProjectApi.Common.Function;
using Hangfire;
using Hangfire.Common;
using Newtonsoft.Json;
using DocumentFormat.OpenXml.Spreadsheet;
using StackExchange.Redis;
using PDCProjectApi.BaseClasses;
using DocumentFormat.OpenXml.Drawing;
using PDCProjectApi.Model.View;
using Microsoft.AspNetCore.SignalR;

namespace PDCProjectApi.Controllers
{
    [Route("api/account")]
    [ApiController]
    [Authorize]
    ////[ApiExplorerSettings(IgnoreApi = true)]
    public class AccountController : ControllerBase, IDisposable
    {
        private Guid idApproved = Guid.Parse("4abe4e89-b815-426b-b56a-7476924c1191");
        private Guid idChecked = Guid.Parse("96bc4ae5-6b85-48ba-8962-313001532358");
        //private Guid idRejected = Guid.Parse("564f7092-51e1-4855-8f56-6dff5062bbbc");
        //private Guid idIssued = Guid.Parse("564f7092-51e1-4855-8f56-6dff5062bbbc");
        //static IConfigurationRoot configuration1 = new ConfigurationBuilder()
        //   .SetBasePath(AppDomain.CurrentDomain.BaseDirectory)
        //   .AddJsonFile("appsettings.json")
        //   .Build();
        private readonly IConfiguration configuration;
        private readonly PdcsystemContext _ctx;
        private readonly IHttpContextAccessor httpContextAccessor;
        private readonly ITodJob tod;
        private readonly ILeadTimeJob ltJob;
        private readonly IInventorylJob invJob;
        private readonly IEmailService email;
        private readonly IManualJob _manual;
        private readonly IManPower manpwJob;
        private readonly ISimulation smlJob;
        private readonly IHubContext<RealTimeHub> _hubContext;
        private readonly IGlobalVariable global = new GlobalVariable();
        private string Factory = "";
        public AccountController(
         IConfiguration configuration, IHttpContextAccessor contextAccessor,
         PdcsystemContext context, /*IFileStorageService ifile, */ITodJob job, IEmailService email, IHubContext<RealTimeHub> hubContext,
         ILeadTimeJob _ltJob, IManualJob manual, IInventorylJob invJob, IManPower manpwJob, ISimulation smlJob)
        {
            this.configuration = configuration;
            this._ctx = context;
            this.httpContextAccessor = contextAccessor;
            //this.fileStorageService = ifile;
            this.tod = job;
            this.email = email;
            this.ltJob = _ltJob;
            this._manual = manual;
            this.invJob = invJob;
            this.manpwJob = manpwJob;
            this.smlJob = smlJob;
            this.Factory = global.ReturnFactory();
            this._hubContext = hubContext;
        }
        private bool disposed = false;
        protected virtual void Dispose(bool disposing)
        {
            if (!disposed)
            {
                if (disposing)
                {
                    if (tod != null)
                    {
                        tod.DisposeAsync();
                    }
                    if (_ctx != null)
                    {
                        _ctx.DisposeAsync();
                    }
                    if (manpwJob != null)
                    {
                        manpwJob.DisposeAsync();
                    }
                    if (_manual != null)
                    {
                        _manual.DisposeAsync();
                    }
                    if (ltJob != null)
                    {
                        ltJob.DisposeAsync();
                    }
                }
                disposed = true;
            }
        }
        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }
        ~AccountController() { Dispose(false); }
        [HttpPost("login")]
        [AllowAnonymous]
        //[ApiExplorerSettings(IgnoreApi = true)]
        public async Task<IActionResult> Login([FromBody] UserCredentials credentials)
        {

            if (credentials.username != null && credentials.password != null)
            {
                var user = await GetUser(credentials.username, credentials.password);
                if (user != null)
                {
                    if (!user.Active)
                    {
                        return BadRequest("Account not active");
                    }else if(user.CanLogin == false)
                    {
                        return BadRequest("Account not yet approve to login, please sign up or contact PIC!");
                    }
                    return Ok(GenerateToken(user));
                }
                else
                {
                    return BadRequest("Password wrong 😭😭😭");
                }
            }
            else
            {
                return BadRequest("Require username and password");
            }
        }
        /// <summary>
        /// lấy thông tin user đang truy cập api
        /// </summary>
        /// <param name="username"></param>
        /// <param name="password"></param>
        /// <returns></returns>
        private async Task<UserClaims?> GetUser(string username, string password)
        {
            try
            {
                var hash = password.ToSha256();
                var userModel = await _ctx.AdmUserInformations.Where(x => x.Active == true && x.EmployeeCode.Equals(username) && x.Password.Equals(hash)).OrderByDescending(x => x.CreatedDate).FirstOrDefaultAsync();


                if (userModel != null)
                {
                    var id = userModel.Id;
                    var dept = _ctx.AdmDetailUserDepts.Include(x => x.Dept).ThenInclude(x => x.Fact).Where(x => x.Active == true && x.UserId == id).ToList();
                    var isAdmin = _ctx.AdmDetailUserGroups.Any(x => x.Active == true && x.UserId == id && x.GroupId == new Guid("1567cfeb-32fe-4745-bbdc-2ace703099d4"));
                    var lstDeptName = dept.Select(x => x.Dept.DeptShortName).Distinct().ToList();
                    var lstDeptId = dept.Select(x => x.DeptId).Distinct().ToList();
                    var nameFact = dept.Select(x => x.Dept.Fact.FactShortName).Distinct().ToList();
                    var lstCostCenter = dept.Select(x => x.Dept.CostCenter).Distinct().ToList();
                    return new UserClaims()
                    {
                        FullName = userModel.FullName,
                        Id = userModel.Id.ToString(),
                        UserName = userModel.EmployeeCode,
                        Active = userModel.Active.Value,
                        PathImage = userModel.PathImage,
                        Departments = string.Join(',', lstDeptName),
                        DeptId = string.Join(',', lstDeptId),
                        Factories = string.Join(',', nameFact),
                        Email = userModel.Email,
                        Password = userModel.Password,
                        CostCenter = string.Join(',', lstCostCenter),
                        IsAdmin = isAdmin.ToString(),
                        CanLogin = userModel.StatusId == new Guid("4abe4e89-b815-426b-b56a-7476924c1191")
                    };
                }
                else { return null; }

            }
            catch (Exception)
            {
                return null;
            }

        }
        /// <summary>
        /// phương thức sinh ra token chứa các thông tin cá nhân
        /// </summary>
        /// <param name="user"></param>
        /// <returns></returns>
        private TokenResponse GenerateToken(UserClaims user)
        {
            var codeAdministrator = configuration.GetValue<string>("Administrator");
            //create claim detail base on the user information
            string rol = user.UserName.Equals(codeAdministrator) ? "administrator" : "user";
            string pages = "";
            var isAdmin = _ctx.AdmDetailUserGroups.Any(x => x.Active == true && x.UserId == new Guid(user.Id) && x.GroupId == new Guid("1567cfeb-32fe-4745-bbdc-2ace703099d4"));
            var isApprover = _ctx.AdmDetailUserGroups.Any(x => x.Active == true && x.UserId == new Guid(user.Id) && x.GroupId == new Guid("a7fabd6b-9a83-4959-bdaf-973e70a68b35"));
            var isAddStructure = _ctx.AdmDetailUserGroups.Any(x => x.Active == true && x.UserId == new Guid(user.Id) && x.GroupId == new Guid("926ced40-a5c7-4475-9f9c-5dee19f98c4b"));
            var isPdc = _ctx.AdmDetailUserDepts.Any(x => x.Active == true && x.UserId == new Guid(user.Id) && x.Dept.DeptShortName.Contains("PDC 1"));

           

            if (isAdmin == true)
            {
                var adminPage = _ctx.AdmMasterPages.Where(x => x.Active == true && (x.Link != null && x.Link != "")).Select(x => x.Link).ToList();

                pages = string.Join(';', adminPage);
            }
            else
            {
                var user_group = _ctx.AdmDetailUserGroups.Where(x => x.Active == true && x.UserId == new Guid(user.Id)).Select(x => x.GroupId).ToList();
                var page_group = _ctx.AdmDetailPageGroups.Include(x => x.Page).Where(x => x.Active == true && user_group.Contains(x.GroupId) && (x.Page.Link != null && x.Page.Link != "")).Select(y => y.Page.Link).ToList();

                pages = string.Join(';', page_group);
            }
            //string groups = string.Join(";", GetListGroupByUser(new Guid(user.Id)));

            var claims = new[]
            {
                        new Claim(JwtRegisteredClaimNames.Sub, configuration["Jwt:Subject"]),
                        new Claim(JwtRegisteredClaimNames.Jti, Guid.NewGuid().ToString()),
                        new Claim(JwtRegisteredClaimNames.Iat, DateTime.Now.ToString()),
                        new Claim("id", user.Id.ToString()),
                        new Claim("user_name", user.UserName.ToString()),
                        new Claim("full_name", user.FullName.ToString()),
                        new Claim("first_name", user.FullName.Split(' ').Last().ToString()),
                        new Claim("path_image", string.IsNullOrEmpty(user.PathImage) ? $"{httpContextAccessor.HttpContext.Request.Scheme}://{httpContextAccessor.HttpContext.Request.Host}" + "/images/avatar/avatar-default.jpg": user.PathImage.Split(";").First()),
                        new Claim(ClaimTypes.Role, rol),
                        new Claim("role", rol),
                        new Claim("dept",string.IsNullOrEmpty(user.Departments) ? "":  user.Departments),
                        new Claim("dept_id",string.IsNullOrEmpty(user.DeptId) ? "":  user.DeptId),
                        new Claim("fact", string.IsNullOrEmpty(user.Factories) ? "": user.Factories),
                        new Claim("path", pages),
                        new Claim("email",string.IsNullOrEmpty(user.Email)?"":user.Email),
                        new Claim("grade",string.IsNullOrEmpty(user.Grade)?"":user.Grade),
                        //new Claim("group",groups),
                        new Claim("cost_center",user.CostCenter),
                        new Claim("dept_cost",user.CostDept != null ? user.CostDept:""),
                        new Claim("isAdmin",isAdmin.ToString().ToLower()),
                        new Claim("isApprover",isApprover.ToString().ToLower()),
                        new Claim("isAddStructure",isAddStructure.ToString().ToLower()),
                        new Claim("isPdc",isPdc.ToString().ToLower())
            };

            var key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(configuration["Jwt:Key"]));
            var signIn = new SigningCredentials(key, SecurityAlgorithms.HmacSha256);
            var token = new JwtSecurityToken(configuration["Jwt:Issuer"], configuration["Jwt:Audience"], claims, DateTime.Now, DateTime.Now.AddHours(2), signIn);
            var expiration = DateTime.Now.AddHours(2);

            //try
            //{
            //    SendLogToDataLake.CallApi(this, SendLogToDataLake.log_level.Info, user.UserName + " - " + user.FullName + " login PSI");
            //}
            //catch (Exception)
            //{

            //}
            return new TokenResponse()
            {
                Token = new JwtSecurityTokenHandler().WriteToken(token),
                Expiration = expiration
            };
        }

        [HttpGet("forgot-password/{username}")]
        //[ApiExplorerSettings(IgnoreApi = true)]
        [AllowAnonymous]
        public CommonResponse ForgotPassword(string username)
        {
            CommonResponse res = new CommonResponse()
            {
                Error = false,
                Message = "",
                Status = (int)HttpStatusCode.BadRequest
            };
            try
            {
                string newpass = ExtensionMethod.NewPassword();
                string hash = newpass.ToSha256();

                TokenResponse token2 = GenerateToken2(username);

                var user = _ctx.AdmUserInformations.FirstOrDefault(x => x.EmployeeCode.Equals(username));
                if (user == null)
                {
                    res.Error = true;
                    res.Message = "Employee code does not exist in the system !";
                    res.Status = (int)HttpStatusCode.BadRequest;
                    return res;
                }
                if (user != null && user.StatusId == idChecked)
                {
                    res.Error = true;
                    res.Message = "Employee code is pending approval.Please wait or contact admin !";
                    res.Status = (int)HttpStatusCode.BadRequest;
                    return res;
                }
                if (user != null && user.StatusId != idChecked && user.StatusId != idApproved)
                {
                    res.Error = true;
                    res.Message = "The employee code is not registered on the system. Please register !";
                    res.Status = (int)HttpStatusCode.BadRequest;
                    return res;
                }
                if ((user.Email == null || !user.Email.Contains("@")) && user.StatusId == idApproved)
                {
                    res.Error = true;
                    res.Message = "Not have email";
                    res.Status = (int)HttpStatusCode.NotFound;
                    return res;
                }
                user.Token = token2.Token;
                _ctx.SaveChanges();
                string url_frontend = configuration.GetValue<string>("frontend_url");
                email.Initial(new List<string>() { user.Email ?? "" }, " Forgot password", GetContentMailNewpassword(user.FullName, url_frontend + "/#/reset-password/" + username + "/" + token2.Token, ""));
                //try
                //{
                //    SendLogToDataLake.CallApi(this, SendLogToDataLake.log_level.Info, username + " forgot password");
                //}
                //catch (Exception)
                //{

                //}
                res.Error = false;
                res.Message = "Please check link in your email !";
                res.Status = (int)HttpStatusCode.OK;
                return res;
            }
            catch (Exception e)
            {
                res.Error = true;
                res.Message = e.Message;
                res.Status = (int)HttpStatusCode.BadRequest;
                return res;
            }

        }


        [HttpGet("forgot-password-not-mail/{username}/{codemail}")]
        [AllowAnonymous]
        //[ApiExplorerSettings(IgnoreApi = true)]
        public CommonResponse ForgotPasswordNotMail(string username, string codemail)
        {
            CommonResponse res = new CommonResponse()
            {
                Error = false,
                Message = "",
                Status = (int)HttpStatusCode.BadRequest
            };
            try
            {
                string newpass = ExtensionMethod.NewPassword();
                string hash = newpass.ToSha256();

                TokenResponse token2 = GenerateToken2(username);
                var user = _ctx.AdmUserInformations.FirstOrDefault(x => x.EmployeeCode.Equals(username));
                var userMail = _ctx.AdmUserInformations.FirstOrDefault(x => x.EmployeeCode.Equals(codemail));
                if (userMail == null)
                {
                    res.Error = true;
                    res.Message = "Employee code to receive link does not exist in the system !";
                    res.Status = (int)HttpStatusCode.BadRequest;
                    return res;
                }
                if ((userMail.Email == null || !userMail.Email.Contains("@")))
                {
                    res.Error = true;
                    res.Message = "Employee code to receive link not have email.Please check again!";
                    res.Status = (int)HttpStatusCode.NotFound;
                    return res;
                }
                user.Token = token2.Token;
                _ctx.SaveChanges();
                string url_frontend = configuration.GetValue<string>("frontend_url");
                email.Initial(new List<string>() { userMail.Email ?? "" }, " Forgot password", GetContentMailNewpassword(user.FullName, url_frontend + "/#/reset-password/" + username + "/" + token2.Token, ""));

                res.Error = false;
                res.Message = "Please check link in your email of " + codemail;
                res.Status = (int)HttpStatusCode.OK;
                return res;
            }
            catch (Exception e)
            {
                res.Error = true;
                res.Message = e.Message;
                res.Status = (int)HttpStatusCode.BadRequest;
                return res;
            }

        }

        [HttpPost("reset-password")]
        //[ApiExplorerSettings(IgnoreApi = true)]
        [AllowAnonymous]
        public CommonResponse ResetPassword([FromBody] TokenRequest auth)
        {
            CommonResponse res = new CommonResponse()
            {
                Error = false,
                Message = "",
                Status = (int)HttpStatusCode.BadRequest
            };
            try
            {
                if (!auth.Password.IsPasswordValid())
                {
                    res.Error = true;
                    res.Message = "Requires at least one special character, lowercase, uppercase, minimum length 8 characters !";
                    res.Status = (int)HttpStatusCode.BadRequest;
                    return res;
                }
                string hash = auth.Password.ToSha256();

                var user = _ctx.AdmUserInformations.FirstOrDefault(x => x.Token.Equals(auth.Token));
                if (user == null)
                {
                    res.Error = true;
                    res.Message = "Wrong token !";
                    res.Status = (int)HttpStatusCode.BadRequest;
                    return res;
                }
                user.Password = hash;
                user.Token = null;
                _ctx.SaveChanges();

                res.Error = false;
                res.Message = "Changed password !";
                res.Status = (int)HttpStatusCode.OK;
            }
            catch (Exception e)
            {
                res.Error = true;
                res.Message = e.Message;
                res.Status = (int)HttpStatusCode.BadRequest;
            }
            return res;
        }

        //đổi mk
        [HttpPost("change-password")]
        //[ApiExplorerSettings(IgnoreApi = true)]
        public CommonResponse ChangePassword([FromBody] UserCredentials2 auth)
        {
            CommonResponse res = new CommonResponse()
            {
                Error = false,
                Message = "",
                Status = (int)HttpStatusCode.BadRequest
            };
            try
            {
                if (!auth.NewPassword.IsPasswordValid())
                {
                    res.Error = true;
                    res.Message = "Requires at least one special character, lowercase, uppercase, minimum length 8 characters !";
                    res.Status = (int)HttpStatusCode.BadRequest;
                    return res;
                }

                string hash1 = auth.OldPassword.ToSha256();
                string hash2 = auth.NewPassword.ToSha256();
                var user = _ctx.AdmUserInformations.FirstOrDefault(x => x.EmployeeCode.Equals(auth.Username) && x.Password.Equals(hash1));
                if (user == null)
                {
                    res.Error = true;
                    res.Message = "Old password not correct.Please check again!";
                    res.Status = (int)HttpStatusCode.BadRequest;
                }
                else
                {
                    user.Password = hash2;
                    user.Token = null;
                    _ctx.SaveChanges();
                    res.Error = false;
                    res.Message = "Changed password !";
                    res.Status = (int)HttpStatusCode.OK;
                }
            }
            catch (Exception e)
            {
                res.Error = true;
                res.Message = e.Message;
                res.Status = (int)HttpStatusCode.BadRequest;
            }
            return res;
        }

        [HttpGet("gen-token-service")]
        //[ApiExplorerSettings(IgnoreApi = true)]
        [AllowAnonymous]
        public TokenResponse GenerateTokenService(string username, string password)
        {
            if ((!username.Equals("web-service")) || (!password.Equals("psi-service")))
            {
                return new TokenResponse()
                {
                    Token = null,
                    Expiration = DateTime.Now
                };
            }
            var claims = new[]
            {
                        new Claim(JwtRegisteredClaimNames.Sub, configuration["Jwt:Subject"]),
                        new Claim(JwtRegisteredClaimNames.Jti, Guid.NewGuid().ToString()),
                        new Claim(JwtRegisteredClaimNames.Iat, DateTime.Now.ToString()),
                        new Claim("user_name", username),
                        new Claim("role", "service")
                    };
            var key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(configuration["Jwt:Key"]));
            var signIn = new SigningCredentials(key, SecurityAlgorithms.HmacSha256);
            var token = new JwtSecurityToken(configuration["Jwt:Issuer"], configuration["Jwt:Audience"], claims, DateTime.Now, DateTime.Now.AddYears(10), signIn);
            var expiration = DateTime.Now.AddYears(50);
            return new TokenResponse()
            {
                Token = new JwtSecurityTokenHandler().WriteToken(token),
                Expiration = expiration
            };
        }

        /// <summary>
        /// tạo nội dung mail với các tham số
        /// </summary>
        /// <param name="full_name"></param>
        /// <param name="link"></param>
        /// <param name="newpassword"></param>
        /// <returns></returns>
        private string GetContentMailNewpassword(string full_name, string link, string newpassword)
        {
            string result = String.Format("Dear " + "Ms/Mr " + "{0}! <br /><br />"
            + "☆ You required reset password: <span style=\"color: red; font-weight: bold;\">" + "</span>.<br /><br /> "
             + "Please Click here to reset: -- " + "<a href='" + link + "'>Click here</a><br />"
            + "-----------------------------------<br />"
            + "☆ [Submission Date]<b> " + DateTime.Now.ToString("dd/MM/yyyy") + "</b><br />"
            + " **************************************************************************************", full_name);

            return result;
        }
        private TokenResponse GenerateToken2(string username)
        {
            var claims = new[]
            {
                        new Claim(JwtRegisteredClaimNames.Sub, configuration["Jwt:Subject"]),
                        new Claim(JwtRegisteredClaimNames.Jti, Guid.NewGuid().ToString()),
                        new Claim(JwtRegisteredClaimNames.Iat, DateTime.Now.ToString()),
                        new Claim("user_name", username)
                    };
            var key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(configuration["Jwt:Key"]));
            var signIn = new SigningCredentials(key, SecurityAlgorithms.HmacSha256);
            var token = new JwtSecurityToken(configuration["Jwt:Issuer"], configuration["Jwt:Audience"], claims, DateTime.Now, DateTime.Now.AddDays(1), signIn);
            var expiration = DateTime.Now.AddHours(6);
            return new TokenResponse()
            {
                Token = new JwtSecurityTokenHandler().WriteToken(token),
                Expiration = expiration
            };
        }
        [HttpGet("keepAlive")]
        [AllowAnonymous]
        public IActionResult KeepAlive()
        {
            try
            {
                email.InitialDev(" Keep Alive", DateTime.Now.ToLongTimeString());
                return Ok();
            }
            catch (Exception)
            {
                return NoContent();
            }
        }
        private UserClaims GetCurrentUser()
        {
            UserClaims userClaims = new UserClaims();
            var identity = HttpContext.User.Identity as ClaimsIdentity;
            if (identity != null)
            {
                userClaims.UserName = identity.FindFirst("user_name") == null ? "Undefined" : identity.FindFirst("user_name").Value;
                userClaims.Id = identity.FindFirst("id") == null ? "Undefined" : identity.FindFirst("id").Value;
                //userClaims.IsIt = identity.FindFirst("isIt") == null ? "0" : identity.FindFirst("isIt").Value;
                userClaims.Departments = identity.FindFirst("deptIds") == null ? "" : identity.FindFirst("deptIds").Value;
                userClaims.Factories = identity.FindFirst("factIds") == null ? "" : identity.FindFirst("factIds").Value;
                userClaims.CostCenter = identity.FindFirst("cost_center") == null ? "" : identity.FindFirst("cost_center").Value;
                userClaims.FullName = identity.FindFirst("full_name") == null ? "" : identity.FindFirst("full_name").Value;
                userClaims.Departments = identity.FindFirst("dept") == null ? "" : identity.FindFirst("dept").Value;
                userClaims.Grade = identity.FindFirst("grade") == null ? "" : identity.FindFirst("grade").Value;
                userClaims.IsAdmin = identity.FindFirst("isAdmin") == null ? "false" : identity.FindFirst("isAdmin").Value;

            }
            return userClaims;
        }

        [HttpGet("test-euc-file-h445")]

        [AllowAnonymous]
        public async Task<IActionResult> TestEUCh445()
        {
            try
            {
                await _manual.RunStructureIJ();
                //ManualJob.AutoCheckLBP_H1701();
                return Ok();
            }
            catch (Exception)
            {
                return NoContent();
            }
        }
        [HttpGet("get-output-ij")]
        [AllowAnonymous]
        public async Task<IActionResult> GetEuc445()
        {
            try
            {
                await _manual.GetOutputIJ(false);
                return Ok();
            }
            catch (Exception)
            {
                return NoContent();
            }
        }
        [HttpGet("get-output-lbp")]
        [AllowAnonymous]
        public async Task<IActionResult> GetOutPutLBP()
        {
            try
            {
                await _manual.GetOutputLBP(true);
                return Ok();
            }
            catch (Exception)
            {
                return NoContent();
            }
        }

        [HttpGet("calc-chaging-ij")]
        [AllowAnonymous]
        public async Task<IActionResult> CalcChangingIj()
        {
            try
            {
                await _manual.CalcChangingPointIJ();
                //await _manual.CalcChangingPointLBP();
                return Ok();
            }
            catch (Exception)
            {
                return NoContent();
            }
        }

        [HttpGet("calc-chaging-lbp")]
        [AllowAnonymous]
        public async Task<IActionResult> CalcChangingLBP()
        {
            try
            {
                //await _manual.CalcChangingPointIJ();
                await _manual.CalcChangingPointLBP();
                return Ok();
            }
            catch (Exception)
            {
                return NoContent();
            }
        }

        [HttpGet("calc-unique-part-ij")]
        [AllowAnonymous]
        public async Task<IActionResult> CalcUniquePartIj()
        {
            try
            {

                await _manual.CalcUniquePartIJ();
                return Ok();
            }
            catch (Exception)
            {
                return NoContent();
            }
        }

        [HttpGet("calc-unique-part-lbp")]
        [AllowAnonymous]
        public async Task<IActionResult> CalcUniquePartLBP()
        {
            try
            {

                await _manual.CalcUniquePartLBP();

                //await _manual.RefreshTemporary();
                return Ok();
            }
            catch (Exception)
            {
                return NoContent();
            }
        }

        [HttpGet("insert-headers-to-redis")]
        [AllowAnonymous]
        public async Task<IActionResult> InsertHeadersToRedis()
        {
            try
            {
                await _manual.HeadersIJ();
                return Ok();
            }
            catch (Exception)
            {
                return NoContent();
            }
        }


        [HttpGet("insert-headers-ij")]
        [AllowAnonymous]
        public async Task<IActionResult> InsertHeaders()
        {
            try
            {
                await _manual.HeadersIJ();
                //await _manual.HeadersLBP();
                return Ok();
            }
            catch (Exception)
            {
                return NoContent();
            }
        }
        [HttpGet("insert-headers-lbp")]
        [AllowAnonymous]
        public async Task<IActionResult> InsertHeadersLBP()
        {
            try
            {
                // await _manual.HeadersIJ();
                await _manual.HeadersLBP();
                return Ok();
            }
            catch (Exception)
            {
                return NoContent();
            }
        }

      
        [HttpGet("export-excel-ij")]
        [AllowAnonymous]
        public async Task<IActionResult> ExportIJExcel()
        {
            try
            {
                await _manual.GetOutputIJALLExcel();
                //await _manual.GetOutputIJDateExcel();
                //await _manual.GetOutputLBPALLExcel();
                //await _manual.GetOutputLBPDateExcel();
                return Ok();
            }
            catch (Exception)
            {
                return NoContent();
            }
        }

        [HttpGet("export-excel-lbp")]
        [AllowAnonymous]
        public async Task<IActionResult> ExportLBPExcel()
        {
            try
            {
                await _manual.GetOutputLBPALLExcel();
                //await _manual.GetOutputIJDateExcel();
                //await _manual.GetOutputLBPALLExcel();
                //await _manual.GetOutputLBPDateExcel();
                return Ok();
            }
            catch (Exception)
            {
                return NoContent();
            }
        }

        [HttpGet("calc-fc-part-demand/{product}")]
        [AllowAnonymous]
        public async Task<IActionResult> CalcFCPartDemand(string product)
        {
            try
            {
                await tod.CalculateFC_Demand(product);
               
                return Ok();
            }
            catch (Exception)
            {
                return NoContent();
            }
        }




        [HttpGet("insert-d101-redis")]
        [AllowAnonymous]
        public async Task<IActionResult> InsertD101Redis()
        {
            try
            {
                await _manual.SaveD101IJRedis();
                await _manual.SaveD101LBPRedis();
                return Ok();
            }
            catch (Exception)
            {
                return NoContent();
            }
        }
        [HttpGet("insert-j4500-redis")]
        [AllowAnonymous]
        public async Task<IActionResult> InsertJ4500Redis()
        {
            try
            {
                await _manual.SaveJ4500IJRedis();

                return Ok();
            }
            catch (Exception)
            {
                return NoContent();
            }
        }
        [HttpGet("insert-j4500lbp-redis")]
        [AllowAnonymous]
        public async Task<IActionResult> InsertJ4500LBPRedis()
        {
            try
            {
                await _manual.SaveJ4500LBPRedis();

                return Ok();
            }
            catch (Exception)
            {
                return NoContent();
            }
        }


        [HttpGet("try-put-tod-op11/{product}")]
        [AllowAnonymous]
        ////[ApiExplorerSettings(IgnoreApi = true)]
        public async Task<IActionResult> AutoPutTodOp1(string product)
        {
            try
            {
                await tod.Number3_CalculateOP1_1(product.ToUpper(), true);
                //await tod.Number3_CalculateOP1_1("LBP", true);
                return Ok();
            }
            catch (Exception)
            {
                return NoContent();
            }
        }


        [HttpGet("try-calc-op1/{product}")]
        [AllowAnonymous]
        ////[ApiExplorerSettings(IgnoreApi = true)]
        public async Task<IActionResult> AutoCalcTodOp1(string product)
        {
            try
            {
                await tod.Number3_Partcontrol_Calculate_All_Item(product.ToUpper(), false, false, true, CancellationToken.None);
                //await tod.Number3_CalculateOP1_1(product, true);
                return Ok();
            }
            catch (Exception)
            {
                return NoContent();
            }
        }

       
        [HttpGet("try-get-ecnlv2-to-output/{product}")]
        [AllowAnonymous]
        public async Task<IActionResult> TryGetEcnLv2ToOutPut(string product)
        {
            try
            {

                //var listMail = new List<string>() { "it-app28@local.canon-vn.com.vn" };
                //email.Initial(listMail, " Start put ecn lv2 ij to redis", "Start job put ecn lv2 ij to redis");

                if (product.ToUpper() == "IJ")
                {
                    await _manual.GetOutputECNLV2IJ();
                }
                if (product.ToUpper() == "LBP")
                {
                    await _manual.GetOutputECNLV2LBP();
                }
                //email.Initial(listMail, " Finish put ecn lv2 ij to redis", "Finish job put ecn lv2 ij to redis");
                return Ok();
            }
            catch (Exception e)
            {
                email.InitialDev(" Except put ecn lv2 ij to redis", e.Message);
                return Ok();
            }
        }
        [HttpGet("export-output1-total/{product}")]
        [AllowAnonymous]
        public async Task<IActionResult> ExportOutput1Total(string product)
        {
            try
            {
                await tod.ExportOutputTodOutput1Total(product, CancellationToken.None);
                return Ok();
            }
            catch (Exception)
            {
                return NoContent();
            }
        }

      

        [HttpGet("calc-lead-time-op0-part-list/{product}")]
        [AllowAnonymous]
        public async Task<IActionResult> GetOP0LTPartList(string product)
        {
            try
            {
                await ltJob.RunCalcOutPut0PartList(product,true);
                return Ok();
            }
            catch (Exception)
            {
                return NoContent();
            }
        }

        [HttpGet("test-service-tod")]
        [AllowAnonymous]
        public async Task<IActionResult> TestService()
        {
            try
            {
                //await tod.CalculateTOD_LBP(true, false, false, true);
                await tod.ExportTOD_LBP(true, CancellationToken.None);
                return Ok();
            }
            catch (Exception)
            {
                return NoContent();
            }
        }

        [HttpGet("calc-lead-time-op2/{rq}/{dept}")]
        [AllowAnonymous]
        public async Task<IActionResult> GetOP2LT(string rq,string dept)
        {
            try
            {
                if(dept.ToUpper() == "ASSY")
                {
                    await ltJob.UpdateOp2WithFormASSY(rq);
                }
                if (dept.ToUpper() == "PDC2")
                {
                    await ltJob.UpdateOp2WithFormPDC2(rq);
                }
             
                return Ok();
            }
            catch (Exception)
            {
                return NoContent();
            }
        }

     
        [HttpGet("update-lead-time-op2")]
        [AllowAnonymous]
        public async Task<IActionResult> UpdateOP2LT()
        {
            //var context = new PdcsystemContext();
            var lstOp2 = _ctx.LtOp2Summaries.Where(x => x.Active == true).ToList();
            var lstUpdate = new List<LtOp2Summary>();
            foreach (var element in lstOp2)
            {
                element.Pdc2Rec = ((double?)(element.Pdc2Rec)).MathRound2();
                element.Pdc2Pickup = ((double?)(element.Pdc2Pickup)).MathRound2();
                element.Pdc2Moving = ((double?)(element.Pdc2Moving)).MathRound2();
                element.Pdc2Supply = ((double?)(element.Pdc2Supply)).MathRound2();
                element.Pdc2Safety = ((double?)(element.Pdc2Safety)).MathRound2();
                element.Pdc2Total = ((double?)(element.Pdc2Total)).MathRound2();

                element.AssyMainPickup = ((double?)(element.AssyMainPickup)).MathRound2();
                element.AssyMainMoving = ((double?)(element.AssyMainMoving)).MathRound2();
                element.AssyMainSupply = ((double?)(element.AssyMainSupply)).MathRound2();
                element.AssyMainProcess = ((double?)(element.AssyMainProcess)).MathRound2();
                element.AssyMainStock = ((double?)(element.AssyMainStock)).MathRound2();
                element.AssyMainTotal = ((double?)(element.AssyMainTotal)).MathRound2();

                element.AssyKittingPickup = ((double?)(element.AssyKittingPickup)).MathRound2();
                element.AssyKittingMoving = ((double?)(element.AssyKittingMoving)).MathRound2();
                element.AssyKittingSupply = ((double?)(element.AssyKittingSupply)).MathRound2();
                element.AssyKittingProcess = ((double?)(element.AssyKittingProcess)).MathRound2();
                element.AssyKittingStock = ((double?)(element.AssyKittingStock)).MathRound2();
                element.AssyKittingTotal = ((double?)(element.AssyKittingTotal)).MathRound2();

                element.AssySubcPickup = ((double?)(element.AssySubcPickup)).MathRound2();
                element.AssySubcMoving = ((double?)(element.AssySubcMoving)).MathRound2();
                element.AssySubcSupply = ((double?)(element.AssySubcSupply)).MathRound2();
                element.AssySubcProcess = ((double?)(element.AssySubcProcess)).MathRound2();
                element.AssySubcStock = ((double?)(element.AssySubcStock)).MathRound2();
                element.AssySubcTotal = ((double?)(element.AssySubcTotal)).MathRound2();

                element.AssySilkPickup = ((double?)(element.AssySilkPickup)).MathRound2();
                element.AssySilkMoving = ((double?)(element.AssySilkMoving)).MathRound2();
                element.AssySilkSupply = ((double?)(element.AssySilkSupply)).MathRound2();
                element.AssySilkProcess = ((double?)(element.AssySilkProcess)).MathRound2();
                element.AssySilkStock = ((double?)(element.AssySilkStock)).MathRound2();
                element.AssySilkTotal = ((double?)(element.AssySilkTotal)).MathRound2();

                element.AssyMainPickup = ((double?)(element.AssyMainPickup)).MathRound2();
                element.AssyMainMoving = ((double?)(element.AssyMainMoving)).MathRound2();
                element.AssyMainSupply = ((double?)(element.AssyMainSupply)).MathRound2();
                element.AssyMainProcess = ((double?)(element.AssyMainProcess)).MathRound2();
                element.AssyMainStock = ((double?)(element.AssyMainStock)).MathRound2();
                element.AssyMainTotal = ((double?)(element.AssyMainTotal)).MathRound2();

                element.AssyMediaPickup = ((double?)(element.AssyMediaPickup)).MathRound2();
                element.AssyMediaMoving = ((double?)(element.AssyMediaMoving)).MathRound2();
                element.AssyMediaSupply = ((double?)(element.AssyMediaSupply)).MathRound2();
                element.AssyMediaProcess = ((double?)(element.AssyMediaProcess)).MathRound2();
                element.AssyMediaStock = ((double?)(element.AssyMediaStock)).MathRound2();
                element.AssyMediaTotal = ((double?)(element.AssyMediaTotal)).MathRound2();

                element.AssyMipPickup = ((double?)(element.AssyMipPickup)).MathRound2();
                element.AssyMipMoving = ((double?)(element.AssyMipMoving)).MathRound2();
                element.AssyMipSupply = ((double?)(element.AssyMipSupply)).MathRound2();
                element.AssyMipProcess = ((double?)(element.AssyMipProcess)).MathRound2();
                element.AssyMipStock = ((double?)(element.AssyMipStock)).MathRound2();
                element.AssyMipTotal = ((double?)(element.AssyMipTotal)).MathRound2();

                element.AssySubpPickup = ((double?)(element.AssySubpPickup)).MathRound2();
                element.AssySubpMoving = ((double?)(element.AssySubpMoving)).MathRound2();
                element.AssySubpSupply = ((double?)(element.AssySubpSupply)).MathRound2();
                element.AssySubpProcess = ((double?)(element.AssySubpProcess)).MathRound2();
                element.AssySubpStock = ((double?)(element.AssySubpStock)).MathRound2();
                element.AssySubpTotal = ((double?)(element.AssySubpTotal)).MathRound2();

                element.AssyCounterPickup = ((double?)(element.AssyCounterPickup)).MathRound2();
                element.AssyCounterMoving = ((double?)(element.AssyCounterMoving)).MathRound2();
                element.AssyCounterSupply = ((double?)(element.AssyCounterSupply)).MathRound2();
                element.AssyCounterProcess = ((double?)(element.AssyCounterProcess)).MathRound2();
                element.AssyCounterStock = ((double?)(element.AssyCounterStock)).MathRound2();
                element.AssyCounterTotal = ((double?)(element.AssyCounterTotal)).MathRound2();

                element.DoQty = ((double?)(element.DoQty)).MathRound2();
                element.DoLt = ((double?)(element.DoLt)).MathRound2();

                element.IhProcess = ((double?)(element.IhProcess)).MathRound2();
                element.IhTransportation = ((double?)(element.IhTransportation)).MathRound2();
                element.IhSafety = ((double?)(element.IhSafety)).MathRound2();
                element.IhBuild = ((double?)(element.IhBuild)).MathRound2();
                element.IhTotal = ((double?)(element.IhTotal)).MathRound2();

                element.OtherProcess = ((double?)(element.OtherProcess)).MathRound2();
                element.OtherLt = ((double?)(element.OtherLt)).MathRound2();
                element.OtherTotal = ((double?)(element.OtherTotal)).MathRound2();

                element.TotalLtTotal = ((double?)(element.TotalLtTotal)).MathRound2();

                lstUpdate.Add(element);
            }
            _ctx.UpdateRange(lstUpdate);
            _ctx.SaveChanges();

            return Ok();
        }

        [HttpGet("calc-output-lbp")]
        [AllowAnonymous]
        public async Task<IActionResult> CalcOutputLbp()
        {
            try
            {
                await _manual.RunStructureLBP();
                return Ok();
            }
            catch (Exception)
            {
                return NoContent();
            }
        }

        [HttpGet("re-calc-lead-time-op2/{dept}/{approved}")]
        [AllowAnonymous]
        public async Task<IActionResult> ReCalcOP2LT(string? dept ,bool approved)
        {
            try
            {
                if(dept.ToUpper() == "PDC2" && approved == false)
                {
                    var rqInfor = _ctx.LtFormRegistrationPdc2Infors.Where(x => x.Active == true && x.Status == 0).Select(x => x.RequestNo).ToList();
                    var rqNo = _ctx.LtFormRegistrationPdc2Processes.Where(x => rqInfor.Contains(x.RequestNo) && x.Active == true && x.OrderNo == 3 && x.Next == true).OrderBy(x => x.CreatedDate).ToList();
                   // var rqNo = _ctx.LtFormRegistrationPdc2Infors.Where(x => x.Active == true && x.Status == 1).ToList();
                    foreach(var item in rqNo)
                    {
                        await ltJob.UpdateOp2WithFormPDC2(item.RequestNo);
                    }

                }
                if (dept.ToUpper() == "PDC2" && approved == true)
                {
                    //var rqInfor = _ctx.LtFormRegistrationPdc2Infors.Where(x => x.Active == true && x.Status == 0).Select(x => x.RequestNo).ToList();
                    //var rqNo = _ctx.LtFormRegistrationPdc2Processes.Where(x => rqInfor.Contains(x.RequestNo) && x.Active == true && x.OrderNo == 3 && x.Next == true).ToList();
                    var rqNo = _ctx.LtFormRegistrationPdc2Infors.Where(x => x.Active == true && x.Status == 1).OrderBy(x => x.CreatedDate).ToList();
                    foreach (var item in rqNo)
                    {
                        await ltJob.UpdateOp2WithFormPDC2(item.RequestNo);
                    }

                }
                if (dept.ToUpper() == "ASSY" && approved == false)
                {
                    var rqInfor = _ctx.LtFormRegistrationAssyInfors.Where(x => x.Active == true && x.Status == 0).Select(x => x.RequestNo).ToList();
                    var rqNo = _ctx.LtFormRegistrationAssyProcesses.Where(x => rqInfor.Contains(x.RequestNo) && x.Active == true && x.OrderNo == 3 && x.Next == true).OrderBy(x => x.CreatedDate).ToList();
                  //  var rqNo = _ctx.LtFormRegistrationAssyInfors.Where(x => x.Active == true && x.Status == 1).ToList();
                    foreach (var item in rqNo)
                    {
                        await ltJob.UpdateOp2WithFormASSY(item.RequestNo);
                    }
                  
                }
                if (dept.ToUpper() == "ASSY" && approved == true)
                {
                    //var rqInfor = _ctx.LtFormRegistrationAssyInfors.Where(x => x.Active == true && x.Status == 0).Select(x => x.RequestNo).ToList();
                    //var rqNo = _ctx.LtFormRegistrationAssyProcesses.Where(x => rqInfor.Contains(x.RequestNo) && x.Active == true && x.OrderNo == 3 && x.Next == true).ToList();
                      var rqNo = _ctx.LtFormRegistrationAssyInfors.Where(x => x.Active == true && x.Status == 1).OrderBy(x => x.CreatedDate).ToList();
                    foreach (var item in rqNo)
                    {
                        await ltJob.UpdateOp2WithFormASSY(item.RequestNo);
                    }

                }
                if (dept.ToUpper() == "LOG" && approved == false)
                {
                    var rqInfor = _ctx.LtFormRegistrationLogInfors.Where(x => x.Active == true && x.Status == 0).Select(x => x.RequestNo).ToList();
                    var rqNo = _ctx.LtFormRegistrationLogProcesses.Where(x => rqInfor.Contains(x.RequestNo) && x.Active == true && x.OrderNo == 3 && x.Next == true).OrderBy(x => x.CreatedDate).ToList();
                    //  var rqNo = _ctx.LtFormRegistrationAssyInfors.Where(x => x.Active == true && x.Status == 1).ToList();
                    foreach (var item in rqNo)
                    {
                        await ltJob.UpdateOp2WithFormLOG(item.RequestNo);
                    }

                }
                if (dept.ToUpper() == "LOG" && approved == true)
                {
                    //var rqInfor = _ctx.LtFormRegistrationAssyInfors.Where(x => x.Active == true && x.Status == 0).Select(x => x.RequestNo).ToList();
                    //var rqNo = _ctx.LtFormRegistrationAssyProcesses.Where(x => rqInfor.Contains(x.RequestNo) && x.Active == true && x.OrderNo == 3 && x.Next == true).ToList();
                    var rqNo = _ctx.LtFormRegistrationLogInfors.Where(x => x.Active == true && x.Status == 1).OrderBy(x => x.CreatedDate).ToList();
                    foreach (var item in rqNo)
                    {
                        await ltJob.UpdateOp2WithFormLOG(item.RequestNo);
                    }

                }
                if (dept.ToUpper() == "IH" && approved == false)
                {
                    var rqInfor = _ctx.LtFormRegistrationIhInfors.Where(x => x.Active == true && x.Status == 0).Select(x => x.RequestNo).ToList();
                    var rqNo = _ctx.LtFormRegistrationIhProcesses.Where(x => rqInfor.Contains(x.RequestNo) && x.Active == true && x.OrderNo == 3 && x.Next == true).OrderBy(x => x.CreatedDate).ToList();
                    //  var rqNo = _ctx.LtFormRegistrationAssyInfors.Where(x => x.Active == true && x.Status == 1).ToList();
                    foreach (var item in rqNo)
                    {
                        await ltJob.UpdateOp2WithFormInHouse(item.RequestNo);
                    }

                }
                if (dept.ToUpper() == "IH" && approved == true)
                {
                    //var rqInfor = _ctx.LtFormRegistrationAssyInfors.Where(x => x.Active == true && x.Status == 0).Select(x => x.RequestNo).ToList();
                    //var rqNo = _ctx.LtFormRegistrationAssyProcesses.Where(x => rqInfor.Contains(x.RequestNo) && x.Active == true && x.OrderNo == 3 && x.Next == true).ToList();
                    var rqNo = _ctx.LtFormRegistrationIhInfors.Where(x => x.Active == true && x.Status == 1).OrderBy(x => x.CreatedDate).ToList();
                    foreach (var item in rqNo)
                    {
                        await ltJob.UpdateOp2WithFormInHouse(item.RequestNo);
                    }

                }
               
                return Ok();
            }
            catch (Exception)
            {
                return NoContent();
            }
        }

        [HttpGet("update-lead-time-inquiry/{dept}")]
        [AllowAnonymous]
        public async Task<IActionResult>UpdateLTInquiry(string? dept)
        {
            try
            {
                if (dept.ToUpper() == "PDC2")
                {
                    var rqNo = _ctx.LtFormRegistrationPdc2Infors.Where(x => x.Active == true && x.Status == 1).OrderBy(x => x.CreatedDate).ToList();
                    foreach (var item in rqNo)
                    {
                        await ltJob.UpdateOp2InquiryWithApprove(item.RequestNo);
                    }

                }
                if (dept.ToUpper() == "ASSY")
                {
                    var rqNo = _ctx.LtFormRegistrationAssyInfors.Where(x => x.Active == true && x.Status == 1).OrderBy(x => x.CreatedDate).ToList();
                    foreach (var item in rqNo)
                    {
                        await ltJob.UpdateOp2InquiryWithApprove(item.RequestNo);
                    }
                }
                if (dept.ToUpper() == "LOG")
                {
                    var rqNo = _ctx.LtFormRegistrationLogInfors.Where(x => x.Active == true && x.Status == 1).OrderBy(x => x.CreatedDate).ToList();
                    foreach (var item in rqNo)
                    {
                        await ltJob.UpdateOp2InquiryWithApprove(item.RequestNo);
                    }
                }
                if (dept.ToUpper() == "IH")
                {
                    var rqNo = _ctx.LtFormRegistrationIhInfors.Where(x => x.Active == true && x.Status == 1).OrderBy(x => x.CreatedDate).ToList();
                    foreach (var item in rqNo)
                    {
                        await ltJob.UpdateOp2InquiryWithApprove(item.RequestNo);
                    }
                }

                return Ok();
            }
            catch (Exception)
            {
                return NoContent();
            }
        }
        [HttpGet("update-lead-time-inquiry-rq/{rq}")]
        [AllowAnonymous]
        public async Task<IActionResult> UpdateLTInquiryRq(string? rq)
        {
            try
            {
                
                        await ltJob.UpdateOp2InquiryWithApprove(rq);
                 

                return Ok();
            }
            catch (Exception)
            {
                return NoContent();
            }
        }

        [HttpGet("calc-inv-op1")]
        [AllowAnonymous]
        public async Task<IActionResult> CalcInvOp1(string product)
        {
            try
            {
                await invJob.SaveOutput1InventoryHistory(product);
                return Ok();
            }
            catch (Exception)
            {
                return NoContent();
            }
        }
        [HttpGet("export-inv-op1")]
        [AllowAnonymous]
        public async Task<IActionResult> ExportInvOp1(string product)
        {
            try
            {
                await invJob.GetOutputOp1Excel(product);
                return Ok();
            }
            catch (Exception)
            {
                return NoContent();
            }
        }
        [HttpGet("check-manpower/{product}")]
        [AllowAnonymous]
        public async Task<IActionResult> CheckManPower(string product)
        {
            try
            {
                await manpwJob.GetOp4(product);
                return Ok();
            }
            catch (Exception)
            {
                return NoContent();
            }
        }

       
        [HttpGet("export-tod-total/{product}")]
        [AllowAnonymous]
        public async Task<IActionResult> ExportTodTotal(string product)
        {
            try
            {
                await tod.ExportOutputTodOutput1Total(product, CancellationToken.None);
                return Ok();
            }
            catch (Exception)
            {
                return NoContent();
            }
        }
      
       
      
        [HttpGet("test-get-report-source")]
        [AllowAnonymous]
        public async Task<IActionResult> TestGetOutputIj(string product)
        {
            try
            {
                await _manual.CheckSourceBeforeRunStructure(product);
                return Ok();
            }
            catch (Exception)
            {
                return NoContent();
            }
        }

        [HttpGet("re-calc-lead-time-op2-other")]
        [AllowAnonymous]
        public async Task<IActionResult> ReCalcOP2Other()
        {
            try
            {
              
                        await ltJob.UpdateOp2WithFormOther();
               

                return Ok();
            }
            catch (Exception)
            {
                return NoContent();
            }
        }
        [HttpGet("re-calc-lead-time-op2-other-inquiry")]
        [AllowAnonymous]
        public async Task<IActionResult> ReCalcOP2OtherInquiry()
        {
            try
            {

                await ltJob.UpdateOp2InquiryWithApproveOther();


                return Ok();
            }
            catch (Exception)
            {
                return NoContent();
            }
        }

        [HttpGet("calc-op1-sml-special/{product}")]
        [AllowAnonymous]
        public async Task<IActionResult> CalcOp1SmlSpecial(string product)
        {
            try
            {

               var lstSpec = await smlJob.LivePp10MinuteSpecial(product);
                //await smlJob.PushPartMaster(lstSpec,product,CancellationToken.None);
                // await smlJob.ExportLivePp10MinuteSpecial(lstSpec,product,CancellationToken.None);
               // await smlJob.PushLeadtime("IJ", "",true, CancellationToken.None);
                return Ok();
            }
            catch (Exception)
            {
                return NoContent();
            }
        }
        [HttpPost("export-op6-urgent/{product}/{user}")]
        [AllowAnonymous]
        public async Task<IActionResult> ExportOp6Urgent([FromBody] string? param, string product,string user)
        {
            try
            {

                await smlJob.ExportOp6SimulationUrgent(product, CancellationToken.None,param,user);


                return Ok();
            }
            catch (Exception)
            {
                return NoContent();
            }
        }
        [HttpGet("calc-op2-sml-ppchange/{product}")]
        [AllowAnonymous]
        public async Task<IActionResult> CalcOp2SmlPPChange(string product)
        {
            try
            {

                await smlJob.PushOp7FCDO(product, CancellationToken.None);


                return Ok();
            }
            catch (Exception)
            {
                return NoContent();
            }
        }
        [HttpGet("push-op7-divide/{product}")]
        [AllowAnonymous]
        public async Task<IActionResult> PushOp7Divide(string product)
        {
            try
            {

                await smlJob.PushOp7FCDODivide(product, CancellationToken.None);


                return Ok();
            }
            catch (Exception)
            {
                return NoContent();
            }
        }

        [HttpGet("test-euc-file-h1202/{product}/{caseTest}")]

        [AllowAnonymous]
        public async Task<IActionResult> TestEUCH1202(string product,string caseTest)
        {
            try
            {
                var dt = DateTime.Now;
                //await smlJob.PushOp7FCDODivide("IJ", CancellationToken.None);
                //await ltJob.RunCalcOutPut0PartList("IJ",false);
                //ManualJob.AutoCheckLBP_H1701();
                //await smlJob.PushOp7FCDO("IJ", CancellationToken.None);
                //await smlJob.PushLeadtime("LBP","A",true, CancellationToken.None);
                await smlJob.PushOp6SimulationTime(product, true, false, true, true, true, true, true, caseTest, CancellationToken.None);
                //await tod.Number3_Partcontrol_Calculate_All_Item_TL("IJ", true, true, true, CancellationToken.None);
                //DateTime dt = DateTime.Now;
                //await smlJob.PushOp9WarningList("LBP", dt, "OK", CancellationToken.None);
                return Ok();
            }
            catch (Exception)
            {
                return NoContent();
            }
        }

        [HttpGet("test-calc-op6/{product}")]

        [AllowAnonymous]
        public async Task<IActionResult> TestCalcOp6(string product)
        {
            try
            {
                //await smlJob.PushOp7FCDODivide("IJ", CancellationToken.None);
                //await ltJob.RunCalcOutPut0PartList("IJ",false);
                //ManualJob.AutoCheckLBP_H1701();
                //await smlJob.PushOp7FCDO("IJ", CancellationToken.None);
                //await smlJob.PushLeadtime("LBP","A",true, CancellationToken.None);
                await smlJob.PushOp6SimulationTime(product, true, false, true, true, true, false, true, "RC6-4947-000_TABT_5100", CancellationToken.None);
                //await tod.Number3_Partcontrol_Calculate_All_Item_TL("IJ", true, true, true, CancellationToken.None);
                //DateTime dt = DateTime.Now;
                //await smlJob.PushOp9WarningList("LBP",dt,"OK", CancellationToken.None);
                return Ok();
            }
            catch (Exception)
            {
                return NoContent();
            }
        }
        [HttpGet("test-push-op7/{product}")]

        [AllowAnonymous]
        public async Task<IActionResult> TestPushOp7(string product)
        {
            try
            {
                var dt = DateTime.Now;
                
                await smlJob.PushOp7FCDO(product, CancellationToken.None);
                
                return Ok();
            }
            catch (Exception)
            {
                return NoContent();
            }
        }
        //[HttpGet("test-notification")]

        //[AllowAnonymous]
        //public async Task<IActionResult> TestNotification()
        //{
        //    await SendMessageToClients($"Notification", "This is notification test!");
        //    return Ok();
        //}

        //private async Task SendMessageToClients(string param, string message)
        //{
        //    await _hubContext.Clients.All.SendAsync("RecMess" + Factory + param, message);
        //}
    }
}
