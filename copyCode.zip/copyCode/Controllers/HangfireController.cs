﻿using DocumentFormat.OpenXml.Bibliography;
using DocumentFormat.OpenXml.Spreadsheet;
using Hangfire;
using Hangfire.Storage;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using PDCProjectApi.Common;
using PDCProjectApi.Common.Interface;
using PDCProjectApi.Common.Job;
using PDCProjectApi.Data;
using PDCProjectApi.Services;
using System.Text;

namespace PDCProjectApi.Controllers
{
    [Route("api/hangfire")]
    [ApiController]
    public class HangfireController : ControllerBase, IDisposable
    {
        private readonly ITodJob tod;
        private readonly ILeadTimeJob led;
        private readonly IPartAdjustmentJob _pad;
        private readonly ISimulation _sim;
        private readonly IBackgroundJobClient backgroundJobClient;
        private readonly IEmailService _email;
        private readonly IManualJob _man;
        private readonly IManPower _mpw;
        private readonly IInventorylJob _invent;
        private bool disposed = false;
        private readonly IGlobalVariable global;
        private string factory = "";
        protected virtual void Dispose(bool disposing)
        {
            if (!disposed)
            {
                if (disposing)
                {
                    if(tod != null)
                    {
                        tod.DisposeAsync();
                    }
                    if (_sim != null)
                    {
                        _sim.DisposeAsync();
                    }
                    if(_man != null)
                    {
                        _man.DisposeAsync();
                    }
                    if(_pad != null)
                    {
                        _pad.DisposeAsync();
                    }
                    if(led != null)
                    {
                        led.DisposeAsync();
                    }
                }
                disposed = true;
            }
        }
        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }
        ~HangfireController() { Dispose(false); }
        public HangfireController(ITodJob job, ILeadTimeJob l, IBackgroundJobClient _backgroundJobClient, IEmailService email, 
            IPartAdjustmentJob pad, ISimulation sim, IManualJob manual,IManPower mpw, IInventorylJob invent,
            IGlobalVariable gl)
        {
            tod = job;
            led = l;
            backgroundJobClient = _backgroundJobClient;
            _email = email;
            _pad = pad;
            _sim = sim;
            _man = manual;
            _mpw = mpw;
            _invent = invent;
            global = gl;
            factory = global.ReturnFactory();
        }
        [HttpGet]
        [Route("UserExportAction/{func}/{product}/{numberOutput}")]
        [AllowAnonymous]
        public string UserExportAction(string func, string product, string numberOutput)
        {
            
            if (func == "Tod")
            {
                //////if (HangfireJobList.PreventProcessing2Param("ExportOutputTodOutput1Total", product))
                //////{
                //////    return "Other jobs processing";
                //////}
                if (numberOutput == "1")
                {
                    backgroundJobClient.Enqueue( () => tod.ExportOutputTodOutput1Total(product, CancellationToken.None));
                }
                else if (numberOutput == "2")
                {
                    backgroundJobClient.Enqueue( () => tod.ExportOutputTodOutput2Deadline(product));
                }
                else if (numberOutput == "4")
                {
                    backgroundJobClient.Enqueue( () => tod.ExportOutputTodOutput4Common(product));
                }
                else if (numberOutput == "7")
                {
                    backgroundJobClient.Enqueue(() => tod.ExportOutputTodOutput7FcDo(product));
                }
            }
            else if(func == "Fc")
            {
                if (HangfireJobList.PreventProcessing("ExportFC_" + product))
                {
                    return "Other jobs processing";
                }
                if (product == "IJ")
                {
                    backgroundJobClient.Enqueue( () => tod.ExportFC_IJ(CancellationToken.None));
                }
                else if (product == "LBP")
                {
                    backgroundJobClient.Enqueue( () => tod.ExportFC_LBP(CancellationToken.None));
                }
            }
            else if (func == "Simulation")
            {
                //if (HangfireJobList.PreventProcessing2Param("ExportOp6SimulationTime", product))
                //{
                //    return "Other jobs processing";
                //}
                backgroundJobClient.Enqueue( () => _sim.ExportLivePp10Minute(product, CancellationToken.None));
                backgroundJobClient.Enqueue(() => _sim.ExportLivePp10MinuteWithChangepp(product, CancellationToken.None));
                string masterPp = backgroundJobClient.Enqueue( () => _sim.ExportPartMaster(product, false, CancellationToken.None));
                backgroundJobClient.Enqueue(() => _sim.ExportPartMaster(product, true, CancellationToken.None));
                //backgroundJobClient.Enqueue( () => _sim.ExportCountlineByStructure(product));
                backgroundJobClient.Enqueue( () => _sim.ExportOp5NpisDoPo(product, CancellationToken.None));
                //backgroundJobClient.Enqueue( () => _sim.ExportLeadtime(product, CancellationToken.None));
                backgroundJobClient.Enqueue( () => _sim.ExportOp6SimulationTime(product, CancellationToken.None));
                backgroundJobClient.ContinueJobWith(masterPp, () => _sim.ExportOp7FC_DO(product, CancellationToken.None));
                backgroundJobClient.Enqueue(() => _sim.ExportOp71_NPIS(product, CancellationToken.None));
                backgroundJobClient.Enqueue( () => _sim.ExportOp8SimulationDate(product, CancellationToken.None));
                backgroundJobClient.Enqueue( () => _sim.ExportOp9WarningList(product, CancellationToken.None));
                backgroundJobClient.Enqueue(() => _sim.ExportOp10WarningOver(product, CancellationToken.None));
                backgroundJobClient.Enqueue(() => _sim.ExportOp11AdjustDO(product));
                //backgroundJobClient.Enqueue(() => _sim.ExportLeadtime(product, CancellationToken.None));
            }
            return "Da bat dau chay part control !";
        }

        [HttpGet]
        [Route("UserExportSimulationLeadtime/{product}")]
        [AllowAnonymous]
        public string UserExportSimulationLeadtime(string product)
        {
            backgroundJobClient.Enqueue(() => _sim.ExportLeadtime(product, CancellationToken.None));
            return "Da bat dau chay part control !";
        }

        [HttpGet]
        [Route("CalculateAction/{func}/{product}")]
        [AllowAnonymous]
        public async Task<string> CalculateAction(string func, string product)
        {
            if(func == "Structure")
            {
                if (HangfireJobList.PreventProcessing("RunStructure" + product))
                {
                    return "Other jobs processing";
                }
                try
                {
                    if (product == "LBP")
                    {
                        backgroundJobClient.Enqueue( () => _man.RunStructureLBP());
                    }
                    else if (product == "IJ")
                    {
                        backgroundJobClient.Enqueue( () => _man.RunStructureIJ());
                    }
                }
                catch (Exception e)
                {
                    _email.InitialDev(" Error start job structure", e.Message);
                }
               
            }
            else if (func == "Tod" || func == "Fc" || func == "TodTest")
            {
                if (HangfireJobList.PreventProcessing("Calculate" + func.ToUpper() + "_" + product))
                {
                    return "Other jobs processing";
                }
                if (func == "Tod")
                {
                    if (product == "IJ")
                    {
                        backgroundJobClient.Enqueue( () => tod.CalculateTOD_IJ(true, false, false, true, CancellationToken.None));
                    }
                    else if (product == "LBP")
                    {
                        backgroundJobClient.Enqueue( () => tod.CalculateTOD_LBP(true, false, false, true, CancellationToken.None));
                    }
                }
                
                else if (func == "Fc")
                {
                    if (product == "IJ")
                    {
                        backgroundJobClient.Enqueue( () => tod.CalculateFC_IJ(CancellationToken.None));
                    }
                    else if (product == "LBP")
                    {
                        backgroundJobClient.Enqueue( () => tod.CalculateFC_LBP(CancellationToken.None));
                    }
                }
            }
            else if (func == "TodFcDo")
            {
                if (HangfireJobList.PreventProcessing("Calculate" + func.ToUpper() + "_" + product))
                {
                    return "Other jobs processing";
                }
                backgroundJobClient.Enqueue(() => tod.Number3_Partcontrol_Calculate_All_NoneP99(product, false, false, CancellationToken.None));              
            }
            else if (func == "Lt")
            {
                if (HangfireJobList.PreventProcessing2Param("RunCalcOutPut0PartList", product))
                {
                    return "Other jobs processing";
                }
                backgroundJobClient.Enqueue(() => led.RunCalcOutPut0PartList(product,true));

            }
            else if (func == "Simulation")
            {
                if (HangfireJobList.PreventProcessing2Param("PushOp6SimulationTime", product))
                {
                    return "Other jobs processing";
                }
                //string optionToRun = $"Product:{product} | IncludeDO:{true} | IncludeAutoDO:{false} | IncludePastMasterPPChange:{false} | OtherOrder:{true} | IncludeIP2:{false}";
                string optionToRun = $"Product:{product} <br /> RunOp1-Op5.Again:{true} <br /> IncludeDO:{true} <br /> IncludeAutoDO:{false} <br /> IncludePastMasterPPChange:{false} <br /> OtherOrder:{true} <br /> IncludeIP2:{false}<br /> FC DO:{false}";
                var stringhtml = ReturnHtmlTable(true, true, false, false, true, false, false);
                DateTime dt = DateTime.Now;
                if (factory.Contains("QV"))
                {
                    string job005 = backgroundJobClient.Enqueue(() => _sim.PushQV_PDC_ReceivingExport(CancellationToken.None));
                    string job001 = backgroundJobClient.Enqueue(() => _sim.PushQV_LivePP(CancellationToken.None));
                    string job01 = backgroundJobClient.ContinueJobWith(job001, () => ADO.doChangeAsync($"REFRESH MATERIALIZED VIEW public.mv_live_pp_{product.ToLower()}_block10;"));
                    string job02 = backgroundJobClient.ContinueJobWith(job001, () => ADO.doChangeAsync($"REFRESH MATERIALIZED VIEW public.mv_live_pp_{product.ToLower()}_block10_part_master;"));
                    string job5 = backgroundJobClient.ContinueJobWith(job005, () => _sim.PushOp5NpisDoPo(product, CancellationToken.None));
                    var lstSpec = await _sim.LivePp10MinuteSpecial(product);
                    string jobExport = backgroundJobClient.Enqueue(() => _sim.ExportLivePp10MinuteSpecial(lstSpec, product, CancellationToken.None));
                    string job1 = backgroundJobClient.ContinueJobWith(job01, () => _sim.PushLivePp10Minute(lstSpec, product, CancellationToken.None));
                    string job11 = backgroundJobClient.ContinueJobWith(job1, () => _sim.PushLivePp10MinuteWithChangepp(product, CancellationToken.None));
                    // string job12 = backgroundJobClient.ContinueJobWith(job1, () => _sim.LivePp10MinuteSpecial(product));
                    string job2 = backgroundJobClient.ContinueJobWith(job02, () => _sim.PushPartMaster(lstSpec, product, CancellationToken.None));
                    string job21 = backgroundJobClient.ContinueJobWith(job11, () => _sim.PushPartMasterChangePP(product, CancellationToken.None));
                    string job4 = backgroundJobClient.ContinueJobWith(job2, () => _sim.PushLeadtime(product, "", false, CancellationToken.None));

                    string job6 = backgroundJobClient.ContinueJobWith(job4, () => _sim.PushOp6SimulationTime(product, true, false, false, true, false, false, false, "", CancellationToken.None));

                    string job9 = backgroundJobClient.ContinueJobWith(job6, () => _sim.PushOp9WarningList(product, dt, stringhtml, CancellationToken.None));
                    string job8 = backgroundJobClient.ContinueJobWith(job9, () => _sim.PushOp8SimulationDate(product, CancellationToken.None));
                    string job7 = backgroundJobClient.ContinueJobWith(job6, () => _sim.PushOp7FCDO(product, CancellationToken.None));
                    string job10 = backgroundJobClient.ContinueJobWith(job7, () => _sim.PushOp7FCDODivide(product, CancellationToken.None));
                }
                else
                {
                    string job01 = backgroundJobClient.Enqueue(() => ADO.doChangeAsync($"REFRESH MATERIALIZED VIEW public.mv_live_pp_{product.ToLower()}_block10;"));
                    string job02 = backgroundJobClient.Enqueue(() => ADO.doChangeAsync($"REFRESH MATERIALIZED VIEW public.mv_live_pp_{product.ToLower()}_block10_part_master;"));
                    string job5 = backgroundJobClient.Enqueue(() => _sim.PushOp5NpisDoPo(product, CancellationToken.None));
                    var lstSpec = await _sim.LivePp10MinuteSpecial(product);
                    string jobExport = backgroundJobClient.Enqueue(() => _sim.ExportLivePp10MinuteSpecial(lstSpec, product, CancellationToken.None));
                    string job1 = backgroundJobClient.ContinueJobWith(job01, () => _sim.PushLivePp10Minute(lstSpec, product, CancellationToken.None));
                    string job11 = backgroundJobClient.ContinueJobWith(job1, () => _sim.PushLivePp10MinuteWithChangepp(product, CancellationToken.None));
                    // string job12 = backgroundJobClient.ContinueJobWith(job1, () => _sim.LivePp10MinuteSpecial(product));
                    string job2 = backgroundJobClient.ContinueJobWith(job02, () => _sim.PushPartMaster(lstSpec, product, CancellationToken.None));
                    string job21 = backgroundJobClient.ContinueJobWith(job11, () => _sim.PushPartMasterChangePP(product, CancellationToken.None));
                    string job4 = backgroundJobClient.ContinueJobWith(job2, () => _sim.PushLeadtime(product, "", false, CancellationToken.None));

                    string job6 = backgroundJobClient.ContinueJobWith(job4, () => _sim.PushOp6SimulationTime(product, true, false, false, true, false, false, false, "", CancellationToken.None));

                    string job9 = backgroundJobClient.ContinueJobWith(job6, () => _sim.PushOp9WarningList(product, dt, stringhtml, CancellationToken.None));
                    string job8 = backgroundJobClient.ContinueJobWith(job9, () => _sim.PushOp8SimulationDate(product, CancellationToken.None));
                    string job7 = backgroundJobClient.ContinueJobWith(job6, () => _sim.PushOp7FCDO(product, CancellationToken.None));
                    string job10 = backgroundJobClient.ContinueJobWith(job7, () => _sim.PushOp7FCDODivide(product, CancellationToken.None));
                }
                
            }
            else if (func == "PaNPIS")
            {
                if (HangfireJobList.PreventProcessing2Param("Ip13a_AutoIssueHandPoNpis", product))
                {
                    return "Other jobs processing";
                }
                backgroundJobClient.Enqueue( () => _pad.Ip13a_AutoIssueHandPoNpis(product));

            }
            else if (func == "PaERI")
            {
                backgroundJobClient.Enqueue( () => _pad.Ip11_AutoIssueFormHandPOERI());

            }
            return "Da bat dau chay part control !";
        }
        [HttpGet]
        [Route("UserCalculateAction/{func}/{product}")]
        [AllowAnonymous]
        public string UserCalculateAction(string func, string product)
        {
            if (func == "Tod")
            {
                if (HangfireJobList.PreventProcessing("CalculateTOD_" + product + "Manual"))
                {
                    return "Other jobs processing";
                }
                if (product == "IJ")
                {
                    backgroundJobClient.Enqueue( () => tod.CalculateTOD_IJManual(true, false, false, true, CancellationToken.None));
                }
                else if (product == "LBP")
                {
                    backgroundJobClient.Enqueue( () => tod.CalculateTOD_LBPManual(true, false, false, true, CancellationToken.None));
                }
            }
            else if (func == "SimulationPushPOKey")//phương thức này dùng để push PO key vào OP7 của Digital Simulation, chỉ chạy riêng push PO Key (lấy key mới nhất)
            {
                var jobRun = backgroundJobClient.Enqueue(() => _sim.PushOp7FCDO(product, CancellationToken.None));
                var jobExport = backgroundJobClient.ContinueJobWith(jobRun, () => _sim.ExportOp7FC_DO(product, CancellationToken.None));
                //chỗ này cần confirm lại xem có cần chạy cả Divide DO không
            }
            return "Da bat dau chay part control !";
        }
        [HttpGet]
        [Route("UserCalculateSimulation/{product}/{runAll}/{doNpis}/{autoDo}/{demandChange}/{otherOrder}/{doChange}/{fcDo}")]
        [AllowAnonymous]
        public async Task<string> UserCalculateSimulation(string product, bool runAll, bool doNpis, bool autoDo, bool demandChange, bool otherOrder, bool doChange, bool fcDo)
        {
            if (HangfireJobList.PreventProcessing2Param("PushOp6SimulationTime", product))
            {
                return "Other jobs processing";
            }
            DateTime dt = DateTime.Now;
            string optionToRun = $"Product:{product} <br /> RunOp1-Op5.Again:{runAll} <br /> IncludeDO:{doNpis} <br /> IncludeAutoDO:{autoDo} <br /> IncludePastMasterPPChange:{demandChange} <br /> OtherOrder:{otherOrder} <br /> IncludeIP2:{doChange} <br /> FC DO:{fcDo}";
            var stringhtml = ReturnHtmlTable(runAll, doNpis, autoDo, demandChange, otherOrder, doChange, fcDo);
            if (runAll)
            {
                if (factory.Contains("QV"))
                {
                    string job005 = backgroundJobClient.Enqueue(() => _sim.PushQV_PDC_ReceivingExport(CancellationToken.None));
                    string job001 = backgroundJobClient.Enqueue(() => _sim.PushQV_LivePP(CancellationToken.None));
                    string job01 = backgroundJobClient.ContinueJobWith(job001, () => ADO.doChangeAsync($"REFRESH MATERIALIZED VIEW public.mv_live_pp_{product.ToLower()}_block10;"));
                    string job02 = backgroundJobClient.ContinueJobWith(job001, () => ADO.doChangeAsync($"REFRESH MATERIALIZED VIEW public.mv_live_pp_{product.ToLower()}_block10_part_master;"));
                    string job5 = backgroundJobClient.ContinueJobWith(job005, () => _sim.PushOp5NpisDoPo(product, CancellationToken.None));
                    var lstSpec = await _sim.LivePp10MinuteSpecial(product);
                    string jobExport = backgroundJobClient.Enqueue(() => _sim.ExportLivePp10MinuteSpecial(lstSpec, product, CancellationToken.None));
                    string job1 = backgroundJobClient.ContinueJobWith(job01, () => _sim.PushLivePp10Minute(lstSpec, product, CancellationToken.None));
                    string job11 = backgroundJobClient.ContinueJobWith(job1, () => _sim.PushLivePp10MinuteWithChangepp(product, CancellationToken.None));
                    // string job12 = backgroundJobClient.ContinueJobWith(job1, () => _sim.LivePp10MinuteSpecial(product, CancellationToken.None));
                    string job2 = backgroundJobClient.ContinueJobWith(job02, () => _sim.PushPartMaster(lstSpec, product, CancellationToken.None));
                    string job21 = backgroundJobClient.ContinueJobWith(job11, () => _sim.PushPartMasterChangePP(product, CancellationToken.None));
                    string job4 = backgroundJobClient.ContinueJobWith(job2, () => _sim.PushLeadtime(product, "", false, CancellationToken.None));
                    string job6 = backgroundJobClient.ContinueJobWith(job4, () => _sim.PushOp6SimulationTime(product, doNpis, autoDo, demandChange, otherOrder, doChange, false, fcDo, "", CancellationToken.None));

                    string job9 = backgroundJobClient.ContinueJobWith(job6, () => _sim.PushOp9WarningList(product, dt, stringhtml, CancellationToken.None));
                    string job8 = backgroundJobClient.ContinueJobWith(job9, () => _sim.PushOp8SimulationDate(product, CancellationToken.None));
                    string job7 = backgroundJobClient.ContinueJobWith(job6, () => _sim.PushOp7FCDO(product, CancellationToken.None));
                    string job10 = backgroundJobClient.ContinueJobWith(job7, () => _sim.PushOp7FCDODivide(product, CancellationToken.None));
                }
                else
                {
                    string job01 = backgroundJobClient.Enqueue(() => ADO.doChangeAsync($"REFRESH MATERIALIZED VIEW public.mv_live_pp_{product.ToLower()}_block10;"));
                    string job02 = backgroundJobClient.Enqueue(() => ADO.doChangeAsync($"REFRESH MATERIALIZED VIEW public.mv_live_pp_{product.ToLower()}_block10_part_master;"));
                    string job5 = backgroundJobClient.Enqueue(() => _sim.PushOp5NpisDoPo(product, CancellationToken.None));
                    var lstSpec = await _sim.LivePp10MinuteSpecial(product);
                    string jobExport = backgroundJobClient.Enqueue(() => _sim.ExportLivePp10MinuteSpecial(lstSpec, product, CancellationToken.None));
                    string job1 = backgroundJobClient.ContinueJobWith(job01, () => _sim.PushLivePp10Minute(lstSpec, product, CancellationToken.None));
                    string job11 = backgroundJobClient.ContinueJobWith(job1, () => _sim.PushLivePp10MinuteWithChangepp(product, CancellationToken.None));
                    // string job12 = backgroundJobClient.ContinueJobWith(job1, () => _sim.LivePp10MinuteSpecial(product, CancellationToken.None));
                    string job2 = backgroundJobClient.ContinueJobWith(job02, () => _sim.PushPartMaster(lstSpec, product, CancellationToken.None));
                    string job21 = backgroundJobClient.ContinueJobWith(job11, () => _sim.PushPartMasterChangePP(product, CancellationToken.None));
                    string job4 = backgroundJobClient.ContinueJobWith(job2, () => _sim.PushLeadtime(product, "", false, CancellationToken.None));
                    string job6 = backgroundJobClient.ContinueJobWith(job4, () => _sim.PushOp6SimulationTime(product, doNpis, autoDo, demandChange, otherOrder, doChange, false, fcDo, "", CancellationToken.None));

                    string job9 = backgroundJobClient.ContinueJobWith(job6, () => _sim.PushOp9WarningList(product, dt, stringhtml, CancellationToken.None));
                    string job8 = backgroundJobClient.ContinueJobWith(job9, () => _sim.PushOp8SimulationDate(product, CancellationToken.None));
                    string job7 = backgroundJobClient.ContinueJobWith(job6, () => _sim.PushOp7FCDO(product, CancellationToken.None));
                    string job10 = backgroundJobClient.ContinueJobWith(job7, () => _sim.PushOp7FCDODivide(product, CancellationToken.None));
                }
            }
            else
            {
                string job5 = backgroundJobClient.Enqueue(() => _sim.PushOp5NpisDoPo(product, CancellationToken.None));
                string job6 = backgroundJobClient.ContinueJobWith(job5, () => _sim.PushOp6SimulationTime(product, doNpis, autoDo, demandChange, otherOrder, doChange, false, fcDo, "", CancellationToken.None));
                
                string job9 = backgroundJobClient.ContinueJobWith(job6, () => _sim.PushOp9WarningList(product, dt, stringhtml, CancellationToken.None));
                string job8 = backgroundJobClient.ContinueJobWith(job9, () => _sim.PushOp8SimulationDate(product, CancellationToken.None));
                string job7 = backgroundJobClient.ContinueJobWith(job6, () => _sim.PushOp7FCDO(product, CancellationToken.None));
                string job10 = backgroundJobClient.ContinueJobWith(job7, () => _sim.PushOp7FCDODivide(product, CancellationToken.None));
            }
            
            return "Da bat dau chay part control !";
        }
        [HttpGet]
        [Route("UserDebugSimulation/{product}/{runAll}/{doNpis}/{autoDo}/{demandChange}/{otherOrder}/{doChange}/{testCase}")]
        [AllowAnonymous]
        public string UserDebugSimulation(string product, bool runAll, bool doNpis, bool autoDo, bool demandChange, bool otherOrder, bool doChange, string testCase)
        {
            DateTime dt = DateTime.Now;
            string optionToRun = $"Product:{product} <br /> RunOp1-Op5.Again:{runAll} <br /> IncludeDO:{doNpis} <br /> IncludeAutoDO:{autoDo} <br /> IncludePastMasterPPChange:{demandChange} <br /> OtherOrder:{otherOrder} <br /> IncludeIP2:{doChange} <br /> Test Case:{testCase}";
            string job6 = backgroundJobClient.Enqueue(() => _sim.PushOp6SimulationTime(product, doNpis, autoDo, demandChange, otherOrder, doChange, true, false, testCase, CancellationToken.None));
            return "Da bat dau chay part control !";
        }
        [HttpGet]
        [Route("UserCalculateAction2/{func}/{product}/{ppChange}/{ppChangeDel}/{otherPlan}")]
        [AllowAnonymous]
        public string UserCalculateAction2(string func, string product, string ppChange, string ppChangeDel, string otherPlan)
        {
            if (func == "Tod")
            {
                if (HangfireJobList.PreventProcessing("CalculateTOD_" + product + "Manual"))
                {
                    return "Other jobs processing";
                }
                if (product == "IJ")
                {
                    backgroundJobClient.Enqueue(() => tod.CalculateTOD_IJ(true, ppChange == "1", ppChangeDel == "1", otherPlan == "1", CancellationToken.None));
                    //backgroundJobClient.Enqueue(() => tod.CalculateTOD_IJManual(true, ppChange == "1", ppChangeDel == "1", otherPlan == "1", CancellationToken.None));
                }
                else if (product == "LBP")
                {
                    backgroundJobClient.Enqueue(() => tod.CalculateTOD_LBP(true, ppChange == "1", ppChangeDel == "1", otherPlan == "1", CancellationToken.None));
                    //backgroundJobClient.Enqueue(() => tod.CalculateTOD_LBPManual(true, ppChange == "1", ppChangeDel == "1", otherPlan == "1", CancellationToken.None));
                }
            }
            else if (func == "TodFcDo")
            {
                if (HangfireJobList.PreventProcessing("CalculateTOD_" + product + "Manual"))
                {
                    return "Other jobs processing";
                }
                backgroundJobClient.Enqueue(() => tod.Number3_Partcontrol_Calculate_All_NoneP99(product, ppChange == "1", ppChangeDel == "1", CancellationToken.None));
            }
            return "Da bat dau chay part control !";
        }


        [HttpGet]
        [Route("PushHistory/{func}/{item}/{product}")]
        [AllowAnonymous]
        public string PushHistoryAction(string func, string item, string product)
        {
            if (func == "Tod")
            {
                if(item == "summary")
                {
                    backgroundJobClient.Enqueue( () => tod.Number3_PushHistoryTodSummary(product, true));
                }
                else if (item == "total")
                {
                    backgroundJobClient.Enqueue( () => tod.Number3_PushHistoryTodTotal(product));
                }
            }
            else if(func == "Simulation")//mỗi ngày push 1 bản ghi vào detail block time by date
            {
                backgroundJobClient.Enqueue( () => _sim.PushBlockTimeByDate(product));
            }
            return "Da bat dau chay part control !";
        }

        [HttpGet]
        [Route("PushPOKey/{product}")]
        [AllowAnonymous]
        public string PushPOKey(string product)
        {
            string job111 = backgroundJobClient.Enqueue(() => _sim.GetPoKey(product));
            return "Da bat dau chay part control !";
        }


        [HttpGet]
        [Route("RefreshMv/{source}/{product}")]
        [AllowAnonymous]
        public string RefreshMvAction(string source, string product)
        {
            if (source == "J4500")
            {
                backgroundJobClient.Enqueue( () => tod.RefreshMvJ4500(product));

            }
            else if (source == "InventStock")
            {
                backgroundJobClient.Enqueue( () => tod.RefreshMvHksStockInvent());
            }
            else if (source == "LivePPBlock10")
            {
                backgroundJobClient.Enqueue( () => tod.RefreshLivePPBlock10Minutes());
            }
            else
            {
                backgroundJobClient.Enqueue( () => ADO.RefreshMaterializeView(source));
            }
            return "Da bat dau chay part control !";
        }
        [HttpGet]
        [Route("RefreshMvE700")]
        [AllowAnonymous]
        public string RefreshMvE700()
        {

                backgroundJobClient.Enqueue( () => tod.RefreshMvE700());
                
            return "Da bat dau chay Mv Inv E700 !";
        }


        [HttpGet]
        [Route("CheckSourceBeforeRunPartcontrol")]
        [AllowAnonymous]
        public string CheckSourceBeforeRunPartcontrol()
        {
            string stringDate = DateTime.Now.ToString("yyyy-MM-dd");
            bool haveError = false;
            var lst = ADO.CheckBeforeCalculatePartControl();
            if(lst.Count < 16)
            {
                _email.InitialDev(" Report check data source before Run Part Control", @"<p style='font-weight: bold;'>Dear [Mrs/Mr]. Developer,</p>
                <p>You have received a notification about <span style='font-weight: bold; color: red; font-style: italic;'>Report check data source before Run Part Control </span>from PSI System. Please check: </p>
                <p>" + $"only {lst.Count} view < 16 expectation" + @"</p>
                ");
            }
            var stringTable = @"<table><tr><th>STT</th><th>Data Source</th><th>Created Date</th><th>Rows Total</th></tr>";
            for(var i = 0; i < lst.Count; i++)
            {
                var item = lst[i];
                stringTable += @"<tr>
    <td>" + (i + 1) + @"</td>
    <td>" + item.data_source + @"</td>
    <td>" + item.created_date + @"</td>
    <td>" + item.rows_total + @"</td>
  </tr>";
                if (!item.created_date.StartsWith(stringDate))
                {
                    haveError = true;
                    backgroundJobClient.Enqueue( () => ADO.RefreshMaterializeView(item.data_source));
                }
            }
            stringTable += "</table>";
            if (haveError)
            {
                _email.InitialDev(" Report check data source before Run Part Control", @"<p style='font-weight: bold;'>Dear [Mrs/Mr]. Developer,</p>
                <p>You have received a notification about <span style='font-weight: bold; color: red; font-style: italic;'>Report check data source before Run Part Control </span>from PSI System. Please check: </p>
                <p>" + stringTable + @"</p>
                ");
            }
            
            return "Da bat dau check !";
        }

        [HttpGet]
        [Route("CheckLockSession")]
        [AllowAnonymous]
        public string CheckLockSession()
        {
            //            var lst = ADO.CheckLockSessions();
            //            if(lst == null || lst.Count < 1)
            //            {
            //                return "OK";
            //            }
            //            var styleCssBorder = "border: 1px solid black";
            //            var stringTable = $@"<table style='{styleCssBorder}'>
            //<tr>
            //<th>STT</th>
            //<th>PID</th>
            //<th>ApplicationName</th>
            //<th>ClientAddr</th>
            //<th>WaitEvent</th>
            //<th>State</th>
            //<th>Query</th>
            //</tr>";
            //            for (var i = 0; i < lst.Count; i++)
            //            {
            //                var item = lst[i];
            //                stringTable += $@"<tr>
            //    <td>{(i + 1)}</td>
            //    <td>{item.Pid}</td>
            //    <td>{item.ApplicationName}</td>
            //    <td>{item.ClientAddr.Address}</td>
            //    <td>{item.WaitEvent}</td>
            //    <td>{item.State}</td>
            //    <td>{item.Query}</td>
            //  </tr>";
            //            }
            //            stringTable += "</table>";
            _email.InitialDev("Status of Server resource", $@"<p style='font-weight: bold;'>Dear [Mrs/Mr]. Developer,</p>
                <p>You have received a notification about warning <span style='font-weight: bold; color: red; font-style: italic;'>Total Memory only PSI: {GC.GetTotalMemory(false)} </span>. Please check: </p>
                <p></p>
                ");

            return "Da bat dau check !";
        }
        [HttpGet]
        [Route("CheckLockInfo")]
        [AllowAnonymous]
        public string CheckLockInfo()
        {
//            var lst = ADO.CheckLockInfo();
//            if (lst == null || lst.Count < 1)
//            {
//                return "OK";
//            }
//            var styleCssBorder = "border: 1px solid black";
//            var stringTable = $@"<table style='{styleCssBorder}'>
//<tr>
//<th>STT</th>
//<th>PID</th>
//<th>LockType</th>
//<th>Mode</th>
//<th>Granted</th>
//</tr>";
//            for (var i = 0; i < lst.Count; i++)
//            {
//                var item = lst[i];
//                stringTable += $@"<tr>
//    <td>{(i + 1)}</td>
//    <td>{item.Pid}</td>
//    <td>{item.Locktype}</td>
//    <td>{item.Mode}</td>
//    <td>{item.Granted}</td>
//  </tr>";
//            }
//            stringTable += "</table>";
//            _email.InitialDev(" Warning Lock Infor", @"<p style='font-weight: bold;'>Dear [Mrs/Mr]. Developer,</p>
//                <p>You have received a notification about warning <span style='font-weight: bold; color: red; font-style: italic;'>Detected Lock Infor </span>from PSI System. Please check: </p>
//                <p>" + stringTable + @"</p>
//                ");

            return "Da bat dau check !";
        }

        [HttpGet]
        [Route("CheckLogLastHour")]
        [AllowAnonymous]
        public string CheckLogLastHour()
        {
            var res = ADO.GetLogLastHour();
            if (res == "")
            {
                return "OK";
            }
            var byteArray = Encoding.UTF8.GetBytes(res);
            _email.InitialAttach(new List<string>() { "it-app26@local.canon-vn.com.vn", "it-app27@local.canon-vn.com.vn", "it-app28@local.canon-vn.com.vn" }, "Database Log", "Please check attachment database log in last hour", byteArray, "text/plain", $"log-{DateTime.Now.ToString("yyyy-MM-dd HH:mm")}.txt");
            return "Da bat dau check !";
        }

        [HttpGet]
        [Route("CheckSourceBeforeRunPartcontrolForInventory")]
        [AllowAnonymous]
        public string CheckSourceBeforeRunPartcontrolForInventory()
        {
            var lst = ADO.CheckBeforeCalculatePartControlForInventory();
            if(lst != null && lst.Count > 0)
            {
                var stringTable = @"<table><tr><th>STT</th><th>Date Entry</th><th>Product</th></tr>";
                for (var i = 0; i < lst.Count; i++)
                {
                    var item = lst[i];
                    stringTable += @"<tr>
    <td>" + (i + 1) + @"</td>
    <td>" + item.date_entry + @"</td>
    <td>" + item.product + @"</td>
  </tr>";
                    stringTable += "</table>";
                }
                _email.Initial(new List<string>() { "thu.nguyen696@mail.canon", "it-app33@local.canon-vn.com.vn" }, " Wrong HKS inventory stock - Part Control", @"<p style='font-weight: bold;'>Dear [Mrs/Mr]. PIC,</p>
                <p>You have received a notification about <span style='font-weight: bold; color: red; font-style: italic;'>Report check data source before Run Part Control </span>from PSI System. Please check: </p>
                <p>" + stringTable + @"</p>
                ");
            }
            

            return "Da bat dau check !";
        }

        [HttpGet]
        [Route("PushRedis/{source}/{product}")]
        [AllowAnonymous]
        public string PushRedisDataFromEuc(string source, string product)
        {
            if(product == "IJ")
            {
                if (source == "B101")//6h15
                {
                //backgroundJobClient.Enqueue( () => _man.SaveB101IJRedis());
                }
                else if (source == "D101")//8h15
                {
                    backgroundJobClient.Enqueue( () => _man.SaveD101IJRedis());
                }
                else if (source == "J4500")//8h15
                {
                    backgroundJobClient.Enqueue( () => _man.SaveJ4500IJRedis());
                }
            }
            else if(product == "LBP")
            {
                if (source == "B101")//6h15
                {
                    //backgroundJobClient.Enqueue( () => _man.SaveB101LBPRedis());
                }
                else if (source == "D101")//8h15
                {
                    backgroundJobClient.Enqueue( () => _man.SaveD101LBPRedis());
                }
                else if (source == "J4500")//8h15
                {
                    backgroundJobClient.Enqueue( () => _man.SaveJ4500LBPRedis());
                }
            }
            
            return "Da bat dau chay structure !";
        }

        [HttpGet]
        [Route("RefreshAllMaterializedView")]
        [AllowAnonymous]
        public string RefreshAllMaterializedView()
        {
            //var lst = ADO.CheckAllMaterializedViewReady();
            //string jobId = "";
            //for (var i = 0; i < lst.Count; i++)
            //{
            //    if(jobId == null)
            //    {
            //        jobId = backgroundJobClient.Enqueue(() => Task.Run(() => ADO.doChangeAsync(lst[i])));
            //    }
            //    else
            //    {
            //        jobId = backgroundJobClient.ContinueJobWith(jobId, () => Task.Run(() => ADO.doChangeAsync(lst[i])));
            //    }
            //}
            return "Da bat dau check !";
        }

        [HttpGet]
        [Route("GetQVData")]
        [AllowAnonymous]
        public string GetQVData()
        {
            if (factory.Contains("QV"))
            {
                backgroundJobClient.Enqueue(() => _sim.PushQV_AITime(CancellationToken.None));
                //backgroundJobClient.Enqueue(() => _sim.PushQV_LivePP(CancellationToken.None));
                backgroundJobClient.Enqueue(() => _sim.PushQV_LivePP_Priority(CancellationToken.None));
                //backgroundJobClient.Enqueue(() => _sim.PushQV_PDC_ReceivingExport(CancellationToken.None));
            }
            return "Da bat dau check !";
        }

        [HttpGet]
        [Route("CalcManpowerStep21/{product}")]
        [AllowAnonymous]
        public string CalcManpowerStep21(string product)
        {
            backgroundJobClient.Enqueue(() => _mpw.ExcuteAllOutPut21(product));
            return "Da bat dau chay !";
        }

        [HttpGet]
        [Route("UpdatePicOPStructureAferApproved/{product}")]
        [AllowAnonymous]
        public string UpdatePicOPStructureAferApproved(string product)
        {
            backgroundJobClient.Enqueue(() => _man.UpdatePicOPStructureAferApproved(product));
            return "Da bat dau chay !";
        }

        [HttpGet]
        [Route("UpdateStructureAfterApprove/{masterType}/{product}")]
        [AllowAnonymous]
        public string UpdateStructureAfterApprove(string masterType, string product)
        {
            backgroundJobClient.Enqueue(() => _man.UpdateStructureAfterApproved(masterType,product));
            return "Da bat dau chay !";
        }


        private string ReturnHtmlTable(bool runAll, bool doNpis, bool autoDo, bool demandChange, bool runOtherOrder, bool doChange, bool containsFcDo)
        {
            var stringTable = @"<table><tr><th style='border: 1px solid black;'>Condition</th><th style='border: 1px solid black;'>Rerun</th><th style='border: 1px solid black;'>Not rerun</th></tr>";
            stringTable += @$"<tr><td style='border: 1px solid black;'>RunOp1-Op5.Again:</td><td style='border: 1px solid black;'>{(runAll ? "TRUE" : "")}</td><td style='border: 1px solid black;'>{(runAll ? "" : "FALSE")}</td></tr>";
            stringTable += @$"<tr><td style='border: 1px solid black;'>IncludeDO:</td><td style='border: 1px solid black;'>{(doNpis ? "TRUE" : "")}</td><td style='border: 1px solid black;'>{(doNpis ? "" : "FALSE")}</td></tr>";
            stringTable += @$"<tr><td style='border: 1px solid black;'>IncludeAutoDO:</td><td style='border: 1px solid black;'>{(autoDo ? "TRUE" : "")}</td><td style='border: 1px solid black;'>{(autoDo ? "" : "FALSE")}</td></tr>";
            stringTable += @$"<tr><td style='border: 1px solid black;'>IncludePastMasterPPChange:</td><td style='border: 1px solid black;'>{(demandChange ? "TRUE" : "")}</td><td style='border: 1px solid black;'>{(demandChange ? "" : "FALSE")}</td></tr>";
            stringTable += @$"<tr><td style='border: 1px solid black;'>OtherOrder:</td><td style='border: 1px solid black;'>{(runOtherOrder ? "TRUE" : "")}</td><td style='border: 1px solid black;'>{(runOtherOrder ? "" : "FALSE")}</td></tr>";
            stringTable += @$"<tr><td style='border: 1px solid black;'>IncludeIP2:</td><td style='border: 1px solid black;'>{(doChange ? "TRUE" : "")}</td><td style='border: 1px solid black;'>{(doChange ? "" : "FALSE")}</td></tr>";
            stringTable += @$"<tr><td style='border: 1px solid black;'>FC DO:</td><td style='border: 1px solid black;'>{(containsFcDo ? "TRUE" : "")}</td><td style='border: 1px solid black;'>{(containsFcDo ? "" : "FALSE")}</td></tr>";
            stringTable += "</table>";

            return stringTable;
        }
        [HttpGet]
        [Route("SaveDataVisualizationSp")]
        [AllowAnonymous]
        public string SaveDataVisualizationSp()
        {
            backgroundJobClient.Enqueue(() => _invent.SaveDataVisualizationSpJob());
            return "Da bat dau chay !";
        }
        [HttpGet]
        [Route("SaveDataVisualizationSpOp2")]
        [AllowAnonymous]
        public string SaveDataVisualizationSpOp2()
        {
            backgroundJobClient.Enqueue(() => _invent.SaveDataVisualizationSpOp2Job());
            return "Da bat dau chay !";
        }
        [HttpGet]
        [Route("SaveDataD800AndLending")]
        [AllowAnonymous]
        public string SaveDataD800AndLending()
        {
            backgroundJobClient.Enqueue(() => _invent.SaveDataD800AndLending());
            return "Da bat dau chay !";
        }
        [HttpPost]
        [Route("ExportOp6Urgent/{product}/{user}")]
        [AllowAnonymous]
        public async Task<string> ExportOp6UrgentAsync(string product,string? user)
        {
            using (var reader = new StreamReader(Request.Body))
            {
                var jsonParams = await reader.ReadToEndAsync();
                backgroundJobClient.Enqueue(() => _sim.ExportOp6SimulationUrgent(product, CancellationToken.None, jsonParams,user));
            }

            return "Da bat dau chay !";

        }
        [HttpGet]
        [Route("ExportMerEuc/{product}")]
        [AllowAnonymous]
        public string ExportMerEuc(string product)
        {
            backgroundJobClient.Enqueue(() => _man.GetOutputMerExcel(product));
            return "Da bat dau chay !";
        }
    }

}
