﻿using AutoMapper;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Newtonsoft.Json;
using PDCProjectApi.Common;
using PDCProjectApi.Common.Interface;
using PDCProjectApi.Data;
using PDCProjectApi.Helper;
using PDCProjectApi.Model.Request;
using PDCProjectApi.Model.Response;
using PDCProjectApi.Model.View;
using System.Net;
using System.Security.Claims;
using PDCProjectApi.Common.Job;
using System.Diagnostics;
using PDCProjectApi.Model.Chart;
using DocumentFormat.OpenXml;
using Microsoft.CodeAnalysis.VisualBasic.Syntax;
using PDCProjectApi.Services;
using Quartz;
using PDCProjectApi.BaseClasses;
using System.Linq;
using PDCProjectApi.Common.Function;

namespace PDCProjectApi.Controllers
{
    [Route("api/todfcdel")]
    [ApiController]
    [Authorize]
    //[ApiExplorerSettings(IgnoreApi = true)]
    public class TodFcdelVolumeController : ControllerBaseAPI, IDisposable
    {
        [Obsolete]
        private readonly Microsoft.AspNetCore.Hosting.IHostingEnvironment _hostingEnvironment;
        private readonly IHttpContextAccessor httpContextAccessor;
        private readonly IFileStorageService fileStorageService;
        private readonly PdcsystemContext context;
        private readonly IConfiguration configuration;
        private readonly IEmailService email;
        private readonly ITodJob job;
        private string pathServer = "";
        private readonly IGlobalVariable global;
        private List<string> lstITMail = new List<string>();
        [Obsolete]
        public TodFcdelVolumeController(Microsoft.AspNetCore.Hosting.IHostingEnvironment hosting, 
            PdcsystemContext ctx, IHttpContextAccessor httpContextAccessor, 
            IFileStorageService fileService, IConfiguration configuration, 
            IEmailService mail, ITodJob jd, IGlobalVariable gl)
        {
            this._hostingEnvironment = hosting;
            this.httpContextAccessor = httpContextAccessor;
            this.context = ctx;
            this.fileStorageService = fileService;
            this.configuration = configuration;
            this.email = mail;
            this.job = jd;
            this.global = gl;
            this.pathServer = this.global.ReturnPathServer();
            this.lstITMail = this.global.ReturnITMail();
        }

        private bool disposed = false;
        protected virtual void Dispose(bool disposing)
        {
            if (!disposed)
            {
                if (disposing)
                {
                    if (context != null)
                    {
                        context.DisposeAsync();
                    }

                }
                disposed = true;
            }
        }
        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }
        ~TodFcdelVolumeController() { Dispose(false); }

        [HttpPost("filter-fcdel-master-max-gaplot")]
        public async Task<TodMasterFcdelMaxGapLotModel> FilterMasterMaxGapLot(TodMasterFcdelMaxGapLotParam parameters)
        {
            try
            {
                var config = new MapperConfiguration(cfg => cfg.CreateMap<TodFcdelMasterMaxGaplot, TodMasterFcdelMaxGapLotView>());
                var mapper = config.CreateMapper();
                TodMasterFcdelMaxGapLotModel result = new TodMasterFcdelMaxGapLotModel()
                {
                    currentPage = parameters.Page,
                    recordPerPage = parameters.RecordsPerPage
                };
                var query = context.TodFcdelMasterMaxGaplots.Where(x => x.Active == true);
                query = !string.IsNullOrEmpty(parameters.Vendor) ? query.Where(x => x.Vendor != null && x.Vendor.ToUpper().Contains(parameters.Vendor.ToUpper())) : query;
                query = !string.IsNullOrEmpty(parameters.Product) ? query.Where(x => x.Product != null && x.Product.ToUpper().Contains(parameters.Product.ToUpper())) : query;
                query = !string.IsNullOrEmpty(parameters.Month) ? query.Where(x => x.Month != null && x.Month.ToString().ToUpper().Contains(parameters.Month.ToUpper())) : query;
                query = !string.IsNullOrEmpty(parameters.Year) ? query.Where(x => x.Year != null && x.Year.ToString().ToUpper().Contains(parameters.Year.ToUpper())) : query;
                query = !string.IsNullOrEmpty(parameters.MaxGapDs) ? query.Where(x => x.MaxGapDs != null && x.MaxGapDs.ToString().ToUpper().Contains(parameters.MaxGapDs.ToUpper())) : query;
                query = !string.IsNullOrEmpty(parameters.MaxGapNs) ? query.Where(x => x.MaxGapNs != null && x.MaxGapNs.ToString().ToUpper().Contains(parameters.MaxGapNs.ToUpper())) : query;
                result.totalRecords = await query.CountAsync();
                result.totalPage = (int)Math.Ceiling((decimal)result.totalRecords / parameters.RecordsPerPage);
                var model = await query.OrderByDescending(x => x.CreatedDate).Paginate(parameters).ToListAsync();
                var modelView = mapper.Map<List<TodFcdelMasterMaxGaplot>, List<TodMasterFcdelMaxGapLotView>>(model);
                result.lstModel = modelView;
                result.fromRecord = model.Count == 0 ? 0 : (result.currentPage - 1) * result.recordPerPage + 1;
                result.toRecord = (int)Math.Min(result.totalRecords, result.currentPage * result.recordPerPage);
                result.currentPage = result.totalPage < result.currentPage ? result.totalPage : result.currentPage;
                return result;
            }
            catch (Exception e)
            {
                //SendMailError(e);
                return new TodMasterFcdelMaxGapLotModel()
                {
                    currentPage = parameters.Page,
                    recordPerPage = parameters.RecordsPerPage
                };
            }
        }
        [HttpPost("filter-fcdel-master-do-leadtime")]
        public async Task<TodMasterFcdelDoLeadtimeModel> FilterMasterDoLeadTime(TodMasterFcdelDoLeadTimeParam parameters)
        {
            try
            {
                var config = new MapperConfiguration(cfg => cfg.CreateMap<TodFcdelMasterDoLeadtime, TodMasterFcdelDoLeadtimeView>());
                var mapper = config.CreateMapper();
                TodMasterFcdelDoLeadtimeModel result = new TodMasterFcdelDoLeadtimeModel()
                {
                    currentPage = parameters.Page,
                    recordPerPage = parameters.RecordsPerPage
                };
                var query = context.TodFcdelMasterDoLeadtimes.Where(x => x.Active == true);
                query = !string.IsNullOrEmpty(parameters.Vendor) ? query.Where(x => x.Vendor != null && x.Vendor.ToUpper().Contains(parameters.Vendor.ToUpper())) : query;
                query = !string.IsNullOrEmpty(parameters.PartNo) ? query.Where(x => x.PartNo != null && x.PartNo.ToUpper().Contains(parameters.PartNo.ToUpper())) : query;
                query = !string.IsNullOrEmpty(parameters.Qty) ? query.Where(x => x.QtyKeepCell != null && x.QtyKeepCell.ToString().ToUpper().Contains(parameters.Qty.ToUpper())) : query;
                query = !string.IsNullOrEmpty(parameters.Model) ? query.Where(x => x.Model != null && x.Model.ToUpper().Contains(parameters.Model.ToUpper())) : query;
                query = !string.IsNullOrEmpty(parameters.DoLeadTime) ? query.Where(x => x.DoLeadTime != null && x.DoLeadTime.ToString().ToUpper().Contains(parameters.DoLeadTime.ToUpper())) : query;
                query = !string.IsNullOrEmpty(parameters.MovingRoute) ? query.Where(x => x.MovingRoute != null && x.MovingRoute.ToUpper().Contains(parameters.MovingRoute.ToUpper())) : query;
                result.totalRecords = await query.CountAsync();
                result.totalPage = (int)Math.Ceiling((decimal)result.totalRecords / parameters.RecordsPerPage);
                var model = await query.OrderByDescending(x => x.CreatedDate).Paginate(parameters).ToListAsync();
                var modelView = mapper.Map<List<TodFcdelMasterDoLeadtime>, List<TodMasterFcdelDoLeadtimeView>>(model);
                result.lstModel = modelView;
                result.fromRecord = model.Count == 0 ? 0 : (result.currentPage - 1) * result.recordPerPage + 1;
                result.toRecord = (int)Math.Min(result.totalRecords, result.currentPage * result.recordPerPage);
                result.currentPage = result.totalPage < result.currentPage ? result.totalPage : result.currentPage;
                return result;
            }
            catch (Exception e)
            {
                //SendMailError(e);
                return new TodMasterFcdelDoLeadtimeModel()
                {
                    currentPage = parameters.Page,
                    recordPerPage = parameters.RecordsPerPage
                };
            }
        }
        [HttpPost("filter-fcdel-ps-model")]
        public async Task<TodFcdelPsModelModel> FilterPsModel(TodFcdelPsModelParam parameters)
        {
            try
            {
                var config = new MapperConfiguration(cfg => cfg.CreateMap<TodFcdelPsModel, TodFcdelPsModelView>());
                var mapper = config.CreateMapper();
                TodFcdelPsModelModel result = new TodFcdelPsModelModel()
                {
                    currentPage = parameters.Page,
                    recordPerPage = parameters.RecordsPerPage
                };
                var query = context.TodFcdelPsModels.Where(x => x.Active == true);
                query = !string.IsNullOrEmpty(parameters.Model) ? query.Where(x => x.ModelName != null && x.ModelName.ToUpper().Contains(parameters.Model.ToUpper())) : query;
                query = parameters.Date != null ? query.Where(x => x.ModelDate == DateOnly.FromDateTime(parameters.Date.Value)) : query;
                result.totalRecords = await query.CountAsync();
                result.totalPage = (int)Math.Ceiling((decimal)result.totalRecords / parameters.RecordsPerPage);
                var model = await query.OrderByDescending(x => x.CreatedDate).Paginate(parameters).ToListAsync();
                var modelView = mapper.Map<List<TodFcdelPsModel>, List<TodFcdelPsModelView>>(model);
                result.lstModel = modelView;
                result.fromRecord = model.Count == 0 ? 0 : (result.currentPage - 1) * result.recordPerPage + 1;
                result.toRecord = (int)Math.Min(result.totalRecords, result.currentPage * result.recordPerPage);
                result.currentPage = result.totalPage < result.currentPage ? result.totalPage : result.currentPage;
                return result;
            }
            catch (Exception e)
            {
                //SendMailError(e);
                return new TodFcdelPsModelModel()
                {
                    currentPage = parameters.Page,
                    recordPerPage = parameters.RecordsPerPage
                };
            }
        }
        [HttpPost("filter-fcdel-abnormal-stock")]
        public async Task<TodFcdelMasterAbnormalStockModel> FilterAbnormal(TodFcdelMasterAbnormalStockParam parameters)
        {
            try
            {
                var config = new MapperConfiguration(cfg => cfg.CreateMap<TodFcdelMasterAbnormalStock, TodFcdelMasterAbnormalStockView>());
                var mapper = config.CreateMapper();
                TodFcdelMasterAbnormalStockModel result = new TodFcdelMasterAbnormalStockModel()
                {
                    currentPage = parameters.Page,
                    recordPerPage = parameters.RecordsPerPage
                };
                var query = context.TodFcdelMasterAbnormalStocks.Where(x => x.Active == true);
                query = !string.IsNullOrEmpty(parameters.Product) ? query.Where(x => x.Product != null && x.Product.ToUpper().Contains(parameters.Product.ToUpper())) : query;
                query = parameters.Date != null ? query.Where(x => x.StoreDate == DateOnly.FromDateTime(parameters.Date.Value)) : query;
                result.totalRecords = await query.CountAsync();
                result.totalPage = (int)Math.Ceiling((decimal)result.totalRecords / parameters.RecordsPerPage);
                var model = await query.OrderByDescending(x => x.CreatedDate).Paginate(parameters).ToListAsync();
                var modelView = mapper.Map<List<TodFcdelMasterAbnormalStock>, List<TodFcdelMasterAbnormalStockView>>(model);
                result.lstModel = modelView;
                result.fromRecord = model.Count == 0 ? 0 : (result.currentPage - 1) * result.recordPerPage + 1;
                result.toRecord = (int)Math.Min(result.totalRecords, result.currentPage * result.recordPerPage);
                result.currentPage = result.totalPage < result.currentPage ? result.totalPage : result.currentPage;
                return result;
            }
            catch (Exception e)
            {
                //SendMailError(e);
                return new TodFcdelMasterAbnormalStockModel()
                {
                    currentPage = parameters.Page,
                    recordPerPage = parameters.RecordsPerPage
                };
            }
        }

        [HttpPost("filter-fcdel-part-demand-{product}")]
        public async Task<TodFcdelPartDemandModel> FilterFcdelPartDemandIJ([FromRoute] string product, TodFcdelPartDemandParam parameters)
        {
            try
            {
                product = product.ToLower().Trim();
                TodFcdelPartDemandModel result = new TodFcdelPartDemandModel()
                {
                    currentPage = parameters.Page,
                    recordPerPage = parameters.RecordsPerPage
                };
                IQueryable<TodFcdelOutputPartDemandIj> query = context.Set<TodFcdelOutputPartDemandIj>();
                if (product == "ij")
                {
                    query = context.TodFcdelOutputPartDemandIjs.Where(x => x.Active == true);
                }
                else if (product == "lbp")
                {
                    query = context.TodFcdelOutputPartDemandLbps.Where(x => x.Active == true)
                        .Select(x => new TodFcdelOutputPartDemandIj()
                        {
                            Active = x.Active,
                            Bc = x.Bc,
                            BoxPallet = x.BoxPallet,
                            CreatedBy = x.CreatedBy,
                            CreatedDate = x.CreatedDate,
                            DeliveryFrequencyType = x.DeliveryFrequencyType,
                            DeliveryRoute = x.DeliveryRoute,
                            Destination = x.Destination,
                            Id = x.Id,
                            Location = x.Location,
                            Location2 = x.Location2,
                            Location3 = x.Location3,
                            MaxGap = x.MaxGap,
                            Model = x.Model,
                            ModifiedBy = x.ModifiedBy,
                            ModifiedDate = x.ModifiedDate,
                            MoqOrder = x.MoqOrder,
                            PartName = x.PartName,
                            PartNo = x.PartNo,
                            PcsBox = x.PcsBox,
                            PcsPallet = x.PcsPallet,
                            Ratio = x.Ratio,
                            PartDemandDate = x.PartDemandDate,
                            PartDemandDay = x.PartDemandDay,
                            PartDemandNight = x.PartDemandNight,
                            Vendor = x.Vendor,
                            VendorName = x.VendorName
                        });
                }
                if (LstBlockCode.Count > 0)
                {
                    query = query.Where(x => x.Bc != null && LstBlockCode.Contains(x.Bc));
                }
                query = !string.IsNullOrEmpty(parameters.Vendor) ? query.Where(x => x.Vendor != null && x.Vendor.ToUpper().Contains(parameters.Vendor.ToUpper())) : query;
                query = !string.IsNullOrEmpty(parameters.PartNo) ? query.Where(x => x.PartNo != null && x.PartNo.ToUpper().Contains(parameters.PartNo.ToUpper())) : query;
                //còn các ngày đã xử lý ở client
               

                result.totalRecords = await query.CountAsync();
                result.totalPage = (int)Math.Ceiling((decimal)result.totalRecords / parameters.RecordsPerPage);
                var model = await query.OrderBy(x => x.PartNo).Paginate(parameters).ToListAsync();
                result.lstModel = model;
                result.fromRecord = model.Count == 0 ? 0 : (result.currentPage - 1) * result.recordPerPage + 1;
                result.toRecord = (int)Math.Min(result.totalRecords, result.currentPage * result.recordPerPage);
                result.currentPage = result.totalPage < result.currentPage ? result.totalPage : result.currentPage;
                return result;
            }
            catch (Exception e)
            {
                return new TodFcdelPartDemandModel()
                {
                    currentPage = parameters.Page,
                    recordPerPage = parameters.RecordsPerPage
                };
            }
        }

        [HttpPost("filter-fcdel-shift-delivery-{product}")]
        public async Task<TodFcdelOutputShiftDeliveryVolumeModel> FilterFcdelShiftDeliverydIJ([FromRoute]string product, TodFcdelShiftDeliveryParam parameters)
        {
            try
            {
                product = product.ToLower().Trim();
                TodFcdelOutputShiftDeliveryVolumeModel result = new TodFcdelOutputShiftDeliveryVolumeModel()
                {
                    currentPage = parameters.Page,
                    recordPerPage = parameters.RecordsPerPage
                };
                IQueryable<TodFcdelOutputShiftDeliveryVolumeIj> query = context.Set<TodFcdelOutputShiftDeliveryVolumeIj>();
                if (product == "ij")
                {
                    query = context.TodFcdelOutputShiftDeliveryVolumeIjs.Where(x => x.Active == true);
                }
                else if (product == "lbp")
                {
                    query = context.TodFcdelOutputShiftDeliveryVolumeLbps.Where(x => x.Active == true)
                        .Select(x => new TodFcdelOutputShiftDeliveryVolumeIj()
                    {
                            Active = x.Active,
                            Bc = x.Bc,
                            BoxPallet = x.BoxPallet,
                            CreatedBy = x.CreatedBy,
                            CreatedDate = x.CreatedDate,
                            DeliveryFrequencyType = x.DeliveryFrequencyType,
                            DeliveryRoute = x.DeliveryRoute,
                            Destination = x.Destination,
                            Id = x.Id,
                            Location = x.Location,
                            Location2 = x.Location2,
                            Location3 = x.Location3,
                            MaxGap = x.MaxGap,
                            Model = x.Model,
                            ModifiedBy = x.ModifiedBy,
                            ModifiedDate = x.ModifiedDate,
                            MoqOrder = x.MoqOrder,
                            PartName = x.PartName,
                            PartNo = x.PartNo,
                            PcsBox = x.PcsBox,
                            PcsPallet = x.PcsPallet,
                            Ratio = x.Ratio,
                            ShiftDeliveryDate = x.ShiftDeliveryDate,
                            ShiftDeliveryVolumeDay = x.ShiftDeliveryVolumeDay,
                            ShiftDeliveryVolumeNight = x.ShiftDeliveryVolumeNight,
                            Vendor = x.Vendor,
                            VendorName = x.VendorName
                    });
                }
                if (LstBlockCode.Count > 0)
                {
                    query = query.Where(x => x.Bc != null && LstBlockCode.Contains(x.Bc));
                }
                query = !string.IsNullOrEmpty(parameters.Vendor) ? query.Where(x => x.Vendor != null && x.Vendor.ToUpper().Contains(parameters.Vendor.ToUpper())) : query;
                query = !string.IsNullOrEmpty(parameters.PartNo) ? query.Where(x => x.PartNo != null && x.PartNo.ToUpper().Contains(parameters.PartNo.ToUpper())) : query;
                

                result.totalRecords = await query.CountAsync();
                result.totalPage = (int)Math.Ceiling((decimal)result.totalRecords / parameters.RecordsPerPage);
                var model = await query.OrderBy(x => x.PartNo).Paginate(parameters).ToListAsync();
                result.lstModel = model;
                result.fromRecord = model.Count == 0 ? 0 : (result.currentPage - 1) * result.recordPerPage + 1;
                result.toRecord = (int)Math.Min(result.totalRecords, result.currentPage * result.recordPerPage);
                result.currentPage = result.totalPage < result.currentPage ? result.totalPage : result.currentPage;
                return result;
            }
            catch (Exception e)
            {
                return new TodFcdelOutputShiftDeliveryVolumeModel()
                {
                    currentPage = parameters.Page,
                    recordPerPage = parameters.RecordsPerPage
                };
            }
        }

        [HttpPost("filter-fcdel-lot-volume-{product}")]
        public async Task<TodFcdelOutputLotDeliveryVolumeModel> FilterFcdelLotVolumeIJ([FromRoute]string product, TodFcdelShiftDeliveryParam parameters)
        {
            try
            {
                product = product.ToLower().Trim();
                TodFcdelOutputLotDeliveryVolumeModel result = new TodFcdelOutputLotDeliveryVolumeModel()
                {
                    currentPage = parameters.Page,
                    recordPerPage = parameters.RecordsPerPage
                };
                IQueryable<TodFcdelOutputLotDeliveryVolumeIj> query = context.Set<TodFcdelOutputLotDeliveryVolumeIj>();
                if(product == "ij")
                {
                    query = context.TodFcdelOutputLotDeliveryVolumeIjs.Where(x => x.Active == true);
                }
                else if(product == "lbp")
                {
                    query = context.TodFcdelOutputLotDeliveryVolumeLbps.Where(x => x.Active == true)
                        .Select(x => new TodFcdelOutputLotDeliveryVolumeIj()
                    {
                            Active = x.Active,
                            Bc = x.Bc,
                            BoxPallet = x.BoxPallet,
                            CreatedBy = x.CreatedBy,
                            CreatedDate = x.CreatedDate,
                            DeliveryFrequencyType = x.DeliveryFrequencyType,
                            DeliveryRoute = x.DeliveryRoute,
                            Destination = x.Destination,
                            Id = x.Id,
                            Location = x.Location,
                            Location2 = x.Location2,
                            Location3 = x.Location3,
                            MaxGap = x.MaxGap,
                            Model = x.Model,
                            ModifiedBy = x.ModifiedBy,
                            ModifiedDate = x.ModifiedDate,
                            MoqOrder = x.MoqOrder,
                            PartName = x.PartName,
                            PartNo = x.PartNo,
                            PcsBox = x.PcsBox,
                            PcsPallet = x.PcsPallet,
                            Ratio = x.Ratio,
                            LotDeliveryDate = x.LotDeliveryDate,
                            LotDeliveryDay = x.LotDeliveryDay,
                            LotDeliveryNight = x.LotDeliveryNight,
                            Vendor = x.Vendor,
                            VendorName = x.VendorName
                        });
                }
                if (LstBlockCode.Count > 0)
                {
                    query = query.Where(x => x.Bc != null && LstBlockCode.Contains(x.Bc));
                }
                query = !string.IsNullOrEmpty(parameters.Vendor) ? query.Where(x => x.Vendor != null && x.Vendor.ToUpper().Contains(parameters.Vendor.ToUpper())) : query;
                query = !string.IsNullOrEmpty(parameters.PartNo) ? query.Where(x => x.PartNo != null && x.PartNo.ToUpper().Contains(parameters.PartNo.ToUpper())) : query;
                

                result.totalRecords = await query.CountAsync();
                result.totalPage = (int)Math.Ceiling((decimal)result.totalRecords / parameters.RecordsPerPage);
                var model = await query.OrderBy(x => x.PartNo).Paginate(parameters).ToListAsync();
                result.lstModel = model;
                result.fromRecord = model.Count == 0 ? 0 : (result.currentPage - 1) * result.recordPerPage + 1;
                result.toRecord = (int)Math.Min(result.totalRecords, result.currentPage * result.recordPerPage);
                result.currentPage = result.totalPage < result.currentPage ? result.totalPage : result.currentPage;
                return result;
            }
            catch (Exception e)
            {
                return new TodFcdelOutputLotDeliveryVolumeModel()
                {
                    currentPage = parameters.Page,
                    recordPerPage = parameters.RecordsPerPage
                };
            }
        }

        [HttpPost("filter-fcdel-stock-std-{product}")]
        public async Task<TodFcdelOutputStockStdModel> FilterFcdelStockStdIJ([FromRoute]string product, TodFcdelStockStdParam parameters)
        {
            try
            {
                product = product.ToLower().Trim();
                TodFcdelOutputStockStdModel result = new TodFcdelOutputStockStdModel()
                {
                    currentPage = parameters.Page,
                    recordPerPage = parameters.RecordsPerPage
                };
                IQueryable<TodFcdelOutputStockStdIj> query = context.Set<TodFcdelOutputStockStdIj>();
                if (product == "ij")
                {
                    query = context.TodFcdelOutputStockStdIjs.Where(x => x.Active == true);
                }
                else if (product == "lbp")
                {
                    query = context.TodFcdelOutputStockStdLbps.Where(x => x.Active == true)
                        .Select(x => new TodFcdelOutputStockStdIj()
                        {
                            Active = x.Active,
                            Bc = x.Bc,
                            BoxPallet = x.BoxPallet,
                            CreatedBy = x.CreatedBy,
                            CreatedDate = x.CreatedDate,
                            DeliveryFrequencyType = x.DeliveryFrequencyType,
                            DeliveryRoute = x.DeliveryRoute,
                            Destination = x.Destination,
                            Id = x.Id,
                            Location = x.Location,
                            Location2 = x.Location2,
                            Location3 = x.Location3,
                            MaxGap = x.MaxGap,
                            Model = x.Model,
                            ModifiedBy = x.ModifiedBy,
                            ModifiedDate = x.ModifiedDate,
                            MoqOrder = x.MoqOrder,
                            PartName = x.PartName,
                            PartNo = x.PartNo,
                            PcsBox = x.PcsBox,
                            PcsPallet = x.PcsPallet,
                            Ratio = x.Ratio,
                            StockStdDate = x.StockStdDate,
                            StockStdValue = x.StockStdValue,
                            Vendor = x.Vendor,
                            VendorName = x.VendorName
                        });
                }
                if (LstBlockCode.Count > 0)
                {
                    query = query.Where(x => x.Bc != null && LstBlockCode.Contains(x.Bc));
                }
                query = !string.IsNullOrEmpty(parameters.Vendor) ? query.Where(x => x.Vendor != null && x.Vendor.ToUpper().Contains(parameters.Vendor.ToUpper())) : query;
                query = !string.IsNullOrEmpty(parameters.PartNo) ? query.Where(x => x.PartNo != null && x.PartNo.ToUpper().Contains(parameters.PartNo.ToUpper())) : query;
                

                result.totalRecords = await query.CountAsync();
                result.totalPage = (int)Math.Ceiling((decimal)result.totalRecords / parameters.RecordsPerPage);
                var model = await query.OrderBy(x => x.PartNo).Paginate(parameters).ToListAsync();
                result.lstModel = model;
                result.fromRecord = model.Count == 0 ? 0 : (result.currentPage - 1) * result.recordPerPage + 1;
                result.toRecord = (int)Math.Min(result.totalRecords, result.currentPage * result.recordPerPage);
                result.currentPage = result.totalPage < result.currentPage ? result.totalPage : result.currentPage;
                return result;
            }
            catch (Exception e)
            {
                //SendMailError(e);
                return new TodFcdelOutputStockStdModel()
                {
                    currentPage = parameters.Page,
                    recordPerPage = parameters.RecordsPerPage
                };
            }
        }
        
        [HttpPost("filter-fcdel-demand-delivery-volume-{product}")]
        public async Task<TodFcdelOutputDemandDeliveryVolumeModel> FilterFcdelDemanDeliveryVolumeIJ([FromRoute]string product, TodFcdelDemandDeliveryVolumeParam parameters)
        {
            try
            {
                product = product.ToLower().Trim();
                TodFcdelOutputDemandDeliveryVolumeModel result = new TodFcdelOutputDemandDeliveryVolumeModel()
                {
                    currentPage = parameters.Page,
                    recordPerPage = parameters.RecordsPerPage
                };
                IQueryable<TodFcdelOutputDemandDeliveryVolumeIj> query = context.Set<TodFcdelOutputDemandDeliveryVolumeIj>();
                if (product == "ij")
                {
                    query = context.TodFcdelOutputDemandDeliveryVolumeIjs.Where(x => x.Active == true);
                }
                else if (product == "lbp")
                {
                    query = context.TodFcdelOutputDemandDeliveryVolumeLbps.Where(x => x.Active == true).Select(x => new TodFcdelOutputDemandDeliveryVolumeIj()
                    {
                        Active = x.Active,
                        Bc = x.Bc,
                        BoxPallet = x.BoxPallet,
                        CreatedBy = x.CreatedBy,
                        CreatedDate = x.CreatedDate,
                        DeliveryFrequencyType = x.DeliveryFrequencyType,
                        DeliveryRoute = x.DeliveryRoute,
                        Destination = x.Destination,
                        Id = x.Id,
                        Location = x.Location,
                        Location2 = x.Location2,
                        Location3 = x.Location3,
                        MaxGap = x.MaxGap,
                        Model = x.Model,
                        ModifiedBy = x.ModifiedBy,
                        ModifiedDate = x.ModifiedDate,
                        MoqOrder = x.MoqOrder,
                        PartName = x.PartName,
                        PartNo = x.PartNo,
                        PcsBox = x.PcsBox,
                        PcsPallet = x.PcsPallet,
                        Ratio = x.Ratio,
                        StockStdDate = x.StockStdDate,
                        StockStdDay = x.StockStdDay,
                        StockStdNight = x.StockStdNight,
                        Vendor = x.Vendor,
                        VendorName = x.VendorName
                    });
                }
                if (LstBlockCode.Count > 0)
                {
                    query = query.Where(x => x.Bc != null && LstBlockCode.Contains(x.Bc));
                }
                query = !string.IsNullOrEmpty(parameters.Vendor) ? query.Where(x => x.Vendor != null && x.Vendor.ToUpper().Contains(parameters.Vendor.ToUpper())) : query;
                query = !string.IsNullOrEmpty(parameters.PartNo) ? query.Where(x => x.PartNo != null && x.PartNo.ToUpper().Contains(parameters.PartNo.ToUpper())) : query;
                
                result.totalRecords = await query.CountAsync();
                result.totalPage = (int)Math.Ceiling((decimal)result.totalRecords / parameters.RecordsPerPage);
                var model = await query.OrderBy(x => x.PartNo).Paginate(parameters).ToListAsync();
                result.lstModel = model;
                result.fromRecord = model.Count == 0 ? 0 : (result.currentPage - 1) * result.recordPerPage + 1;
                result.toRecord = (int)Math.Min(result.totalRecords, result.currentPage * result.recordPerPage);
                result.currentPage = result.totalPage < result.currentPage ? result.totalPage : result.currentPage;
                return result;
            }
            catch (Exception e)
            {
                //SendMailError(e);
                return new TodFcdelOutputDemandDeliveryVolumeModel()
                {
                    currentPage = parameters.Page,
                    recordPerPage = parameters.RecordsPerPage
                };
            }
        }

        [HttpPost("filter-fcdel-sumup-by-vendor-{product}")]
        public async Task<TodFcdelOutputSumupVendorModel> FilterFcdelSumUpByVendorIJ([FromRoute] string product, TodFcdelSumUpParam parameters)
        {
            try
            {
                product = product.ToLower().Trim();
                TodFcdelOutputSumupVendorModel result = new TodFcdelOutputSumupVendorModel()
                {
                    currentPage = parameters.Page,
                    recordPerPage = parameters.RecordsPerPage
                };
                IQueryable<TodFcdelOutputSumupVendorIj> query = context.Set<TodFcdelOutputSumupVendorIj>();
                if (product == "ij")
                {
                    query = context.TodFcdelOutputSumupVendorIjs.Where(x => x.Active == true);
                }
                else if (product == "lbp")
                {
                    query = context.TodFcdelOutputSumupVendorLbps.Where(x => x.Active == true)
                        .Select(x => new TodFcdelOutputSumupVendorIj()
                        {
                            Active = x.Active,
                            CreatedBy = x.CreatedBy,
                            CreatedDate = x.CreatedDate,
                            Id = x.Id,
                            ModifiedBy = x.ModifiedBy,
                            ModifiedDate = x.ModifiedDate,
                            VendorName = x.VendorName,
                            DeliveryRoute = x.DeliveryRoute,
                            SumupDate = x.SumupDate,
                            SumupValueDayByLot = x.SumupValueDayByLot,
                            SumupValueDayByShift = x.SumupValueDayByShift,
                            SumupValueNightByLot = x.SumupValueNightByLot,
                            SumupValueNightByShift = x.SumupValueDayByShift,
                            VendorCode = x.VendorCode
                        });
                }
                query = !string.IsNullOrEmpty(parameters.Vendor) ? query.Where(x => x.VendorCode != null && x.VendorCode.ToUpper().Contains(parameters.Vendor.ToUpper())) : query;
                query = !string.IsNullOrEmpty(parameters.RouteDel) ? query.Where(x => x.DeliveryRoute != null && x.DeliveryRoute.ToUpper().Contains(parameters.RouteDel.ToUpper())) : query;
                

                result.totalRecords = await query.CountAsync();
                result.totalPage = (int)Math.Ceiling((decimal)result.totalRecords / parameters.RecordsPerPage);
                var model = await query.OrderBy(x => x.VendorCode).Paginate(parameters).ToListAsync();
                result.lstModel = model;
                result.fromRecord = model.Count == 0 ? 0 : (result.currentPage - 1) * result.recordPerPage + 1;
                result.toRecord = (int)Math.Min(result.totalRecords, result.currentPage * result.recordPerPage);
                result.currentPage = result.totalPage < result.currentPage ? result.totalPage : result.currentPage;
                return result;
            }
            catch (Exception e)
            {
                return new TodFcdelOutputSumupVendorModel()
                {
                    currentPage = parameters.Page,
                    recordPerPage = parameters.RecordsPerPage
                };
            }
        }

        [HttpPost("filter-fcdel-sumup-by-route-{product}")]
        public async Task<TodFcdelOutputSumupRouteModel> FilterFcdelSumUpByRouteIJ([FromRoute] string product, TodFcdelSumUpParam parameters)
        {
            try
            {
                product = product.ToLower().Trim();
                TodFcdelOutputSumupRouteModel result = new TodFcdelOutputSumupRouteModel()
                {
                    currentPage = parameters.Page,
                    recordPerPage = parameters.RecordsPerPage
                };
                IQueryable<TodFcdelOutputSumupRouteIj> query = context.Set<TodFcdelOutputSumupRouteIj>();
                if (product == "ij")
                {
                    query = context.TodFcdelOutputSumupRouteIjs.Where(x => x.Active == true && x.DeliveryRoute != null);
                }
                else if (product == "lbp")
                {
                    query = context.TodFcdelOutputSumupRouteLbps.Where(x => x.Active == true && x.DeliveryRoute != null)
                        .Select(x => new TodFcdelOutputSumupRouteIj()
                        {
                            Active = x.Active,
                            CreatedBy = x.CreatedBy,
                            CreatedDate = x.CreatedDate,
                            Id = x.Id,
                            ModifiedBy = x.ModifiedBy,
                            ModifiedDate = x.ModifiedDate,
                            DeliveryRoute = x.DeliveryRoute,
                            SumupDate = x.SumupDate,
                            SumupValueDayByLot = x.SumupValueDayByLot,
                            SumupValueDayByShift = x.SumupValueDayByShift,
                            SumupValueNightByLot = x.SumupValueNightByLot,
                            SumupValueNightByShift = x.SumupValueDayByShift
                        });
                }
                    
               
                query = !string.IsNullOrEmpty(parameters.RouteDel) ? query.Where(x => x.DeliveryRoute != null && x.DeliveryRoute.ToUpper().Contains(parameters.RouteDel.ToUpper())) : query;
                

                result.totalRecords = await query.CountAsync();
                result.totalPage = (int)Math.Ceiling((decimal)result.totalRecords / parameters.RecordsPerPage);
                var model = await query.OrderBy(x => x.DeliveryRoute).Paginate(parameters).ToListAsync();
                result.lstModel = model;
                result.fromRecord = model.Count == 0 ? 0 : (result.currentPage - 1) * result.recordPerPage + 1;
                result.toRecord = (int)Math.Min(result.totalRecords, result.currentPage * result.recordPerPage);
                result.currentPage = result.totalPage < result.currentPage ? result.totalPage : result.currentPage;
                return result;
            }
            catch (Exception e)
            {
                //SendMailError(e);
                return new TodFcdelOutputSumupRouteModel()
                {
                    currentPage = parameters.Page,
                    recordPerPage = parameters.RecordsPerPage
                };
            }
        }

        [HttpPost("filter-fcdel-sumup-by-location-{product}")]
        public async Task<TodFcdelOutputSumupLocationModel> FilterFcdelSumUpByLocationIJ([FromRoute] string product,TodFcdelSumUpParam parameters)
        {
            try
            {
                product = product.ToLower().Trim();
                TodFcdelOutputSumupLocationModel result = new TodFcdelOutputSumupLocationModel()
                {
                    currentPage = parameters.Page,
                    recordPerPage = parameters.RecordsPerPage
                };
                IQueryable<TodFcdelOutputSumupLocationIj> query = context.Set<TodFcdelOutputSumupLocationIj>();
                if (product == "ij")
                {
                    query = context.TodFcdelOutputSumupLocationIjs.Where(x => x.Active == true && x.Location != null);
                }
                else if (product == "lbp")
                {
                    query = context.TodFcdelOutputSumupLocationLbps.Where(x => x.Active == true && x.Location != null)
                        .Select(x => new TodFcdelOutputSumupLocationIj()
                        {
                            Active = x.Active,
                            CreatedBy = x.CreatedBy,
                            CreatedDate = x.CreatedDate,
                            Id = x.Id,
                            ModifiedBy = x.ModifiedBy,
                            ModifiedDate = x.ModifiedDate,
                            SumupDate = x.SumupDate,
                            SumupValueDayByLot = x.SumupValueDayByLot,
                            SumupValueDayByShift = x.SumupValueDayByShift,
                            SumupValueNightByLot = x.SumupValueNightByLot,
                            SumupValueNightByShift = x.SumupValueDayByShift,
                            Location = x.Location
                        });
                }
                    

                query = !string.IsNullOrEmpty(parameters.Location1) ? query.Where(x => x.Location != null && x.Location.ToUpper().Contains(parameters.Location1.ToUpper())) : query;
                

                result.totalRecords = await query.CountAsync();
                result.totalPage = (int)Math.Ceiling((decimal)result.totalRecords / parameters.RecordsPerPage);
                var model = await query.OrderBy(x => x.Location).Paginate(parameters).ToListAsync();
                result.lstModel = model;
                result.fromRecord = model.Count == 0 ? 0 : (result.currentPage - 1) * result.recordPerPage + 1;
                result.toRecord = (int)Math.Min(result.totalRecords, result.currentPage * result.recordPerPage);
                result.currentPage = result.totalPage < result.currentPage ? result.totalPage : result.currentPage;
                return result;
            }
            catch (Exception e)
            {
                return new TodFcdelOutputSumupLocationModel()
                {
                    currentPage = parameters.Page,
                    recordPerPage = parameters.RecordsPerPage
                };
            }
        }


        [HttpGet("filter-fcdel-total-delivery-demand/{product}")]
        public List<TodFcdelOutputTotalDeliveryVolumeDemand> FilterFcdelTotalDeliveryDemand(string product)
        {
            try
            {
                if (product.ToUpper() != "IJ" && product.ToUpper() != "LBP")
                {
                    product = "IJ+LBP";
                }
                var query = context.TodFcdelOutputTotalDeliveryVolumeDemands.Where(x => x.Active == true && x.Product.ToUpper() == product.ToUpper()).ToList();
                return query;
            }
            catch (Exception e)
            {
                //SendMailError(e);
                return new List<TodFcdelOutputTotalDeliveryVolumeDemand>();
            }
        }

        [HttpGet("get-chart-data-fcdel-total-delivery-demand/{product}/{dateF}/{dateT}")]
        public List<ChartFcdelByTypeByGroupBy> GetChartDataFcdelTotalDeliveryDemand(string product, string dateF, string dateT)
        {
            try
            {
                product = product.ToUpper().Trim();
                var result = new List<ChartFcdelByTypeByGroupBy>();
                var dt1 = DateTime.Parse(dateF);
                var dt2 = DateTime.Parse(dateT);
                var dF = DateOnly.FromDateTime(new DateTime(Math.Min(dt1.Ticks, dt2.Ticks)));
                var dT = DateOnly.FromDateTime(new DateTime(Math.Max(dt1.Ticks, dt2.Ticks)));
                if (product.ToUpper() != "IJ" && product.ToUpper() != "LBP")
                {
                    product = "IJ+LBP";
                }
                var dateRangeResult = new List<DateOnly>();
                for (var iD = dF; iD <= dT; iD = iD.AddDays(1))
                {
                    dateRangeResult.Add(iD);
                }
                var model1 = context.TodFcdelOutputTotalDeliveryVolumeDemands.Where(x => x.Active == true && x.Product.ToUpper() == product.ToUpper()).ToList();
                Random rnd = new Random();
                foreach (var vd in model1)
                {
                    var vendor = vd.Location;
                    var rangeD = dateRangeResult;
                    var lstValueD = new List<double>();
                    Dictionary<DateOnly, double> dicShiftDay = new Dictionary<DateOnly, double>();
                    if (vd.TotalValue != null && vd.TotalValue.Length > 0)
                    {
                        for (int i = 0; i < vd.Date.Length; i++)
                        {
                            dicShiftDay.Add(vd.Date[i], vd.TotalValue[i]);
                        }
                    }

                    for (var iD = dF; iD <= dT; iD = iD.AddDays(1))
                    {
                        double itemValD = 0;
                        try
                        {
                            itemValD += dicShiftDay[iD];
                        }
                        catch (Exception)
                        {

                        }
                        itemValD = Math.Round(itemValD);
                        lstValueD.Add(itemValD);
                    }
                    
                    var cl = "rgb(" + rnd.Next(256) + ", " + rnd.Next(256) + ", " + rnd.Next(256) + ")";
                    if(vendor == "DPS")
                    {
                        cl = "red";
                    }
                    else if(vendor == "LPS")
                    {
                        cl = "green";
                    }
                    result.Add(new ChartFcdelByTypeByGroupBy()
                    {
                        Days = dateRangeResult.ToArray(),
                        Label = vendor ?? "(blank)",
                        Stack = "C",
                        Value = lstValueD.ToArray(),
                        BackgroundColor = cl
                    });

                }
                var model2 = context.TodFcdelMasterAbnormalStocks
                    .Where(x => x.Active == true && x.ApprovalBy != null && x.ApprovalDate != null && product.Contains(x.Product))
                    .GroupBy(o => new { o.StoreDate })
                                .Select(g => new TodFcdelMasterAbnormalStock
                                {
                                    StoreDate = g.Key.StoreDate,
                                    AbnormalDps = g.Sum(o => Convert.ToDouble(o.AbnormalDps ?? 0)),
                                    AdnormalLps = g.Sum(o => Convert.ToDouble(o.AdnormalLps ?? 0)),
                                    StoreCap1 = g.Sum(o => Convert.ToDouble(o.StoreCap1 ?? 0)),
                                    StoreCap2 = g.Sum(o => Convert.ToDouble(o.StoreCap2 ?? 0)),
                                    StoreCap3 = g.Sum(o => Convert.ToDouble(o.StoreCap3 ?? 0)),
                                })
                                .ToList();
                var lstValueAbDps = new List<double>();
                var lstValueAbLps = new List<double>();
                var lstValueCap1 = new List<double>();
                var lstValueCap2 = new List<double>();
                var lstValueCap3 = new List<double>();
                Dictionary<DateOnly, double> dicAbDps = new Dictionary<DateOnly, double>();
                Dictionary<DateOnly, double> dicAbLps = new Dictionary<DateOnly, double>();
                Dictionary<DateOnly, double> dicCap1 = new Dictionary<DateOnly, double>();
                Dictionary<DateOnly, double> dicCap2 = new Dictionary<DateOnly, double>();
                Dictionary<DateOnly, double> dicCap3 = new Dictionary<DateOnly, double>();
                foreach (var item in model2)
                {
                    try
                    {
                        if (item.StoreDate == null) continue;
                        if (item.AbnormalDps.HasValue)  dicAbDps.Add(item.StoreDate.Value, item.AbnormalDps.Value);
                        if (item.AdnormalLps.HasValue)  dicAbLps.Add(item.StoreDate.Value, item.AdnormalLps.Value);
                        if (item.StoreCap1.HasValue)  dicCap1.Add(item.StoreDate.Value, item.StoreCap1.Value);
                        if (item.StoreCap2.HasValue)  dicCap2.Add(item.StoreDate.Value, item.StoreCap2.Value);
                        if (item.StoreCap3.HasValue)  dicCap3.Add(item.StoreDate.Value, item.StoreCap3.Value);
                    }
                    catch (Exception)
                    {

                    }
                }
                for (var iD = dF; iD <= dT; iD = iD.AddDays(1))
                {
                    try
                    {
                        if (dicAbDps.ContainsKey(iD))
                        {
                            lstValueAbDps.Add(dicAbDps[iD]);
                        }
                        else
                        {
                            lstValueAbDps.Add(0);
                        }
                        if (dicAbLps.ContainsKey(iD))
                        {
                            lstValueAbLps.Add(dicAbLps[iD]);
                        }
                        else
                        {
                            lstValueAbLps.Add(0);
                        }
                        if (dicCap1.ContainsKey(iD))
                        {
                            lstValueCap1.Add(dicCap1[iD]);
                        }
                        else
                        {
                            lstValueCap1.Add(0);
                        }
                        if (dicCap2.ContainsKey(iD))
                        {
                            lstValueCap2.Add(dicCap2[iD]);
                        }
                        else
                        {
                            lstValueCap2.Add(0);
                        }
                        if (dicCap3.ContainsKey(iD))
                        {
                            lstValueCap3.Add(dicCap3[iD]);
                        }
                        else
                        {
                            lstValueCap3.Add(0);
                        }
                    }
                    catch (Exception)
                    {
                        lstValueAbDps.Add(0);
                        lstValueAbLps.Add(0);
                        lstValueCap1.Add(0);
                        lstValueCap2.Add(0);
                        lstValueCap3.Add(0);
                    }
                }
                result.Add(new ChartFcdelByTypeByGroupBy()
                {
                    Days = dateRangeResult.ToArray(),
                    Label = "Abnormal DPS",
                    Stack = "C",
                    Value = lstValueAbDps.ToArray(),
                    BackgroundColor = "orange"
                });
                result.Add(new ChartFcdelByTypeByGroupBy()
                {
                    Days = dateRangeResult.ToArray(),
                    Label = "Abnormal LPS",
                    Stack = "C",
                    Value = lstValueAbLps.ToArray(),
                    BackgroundColor = "blue"
                });
                result.Add(new ChartFcdelByTypeByGroupBy()
                {
                    Days = dateRangeResult.ToArray(),
                    Label = "Store Capacity 1",
                    Stack = "D",
                    Value = lstValueCap1.ToArray(),
                    BackgroundColor = "violet"
                });
                result.Add(new ChartFcdelByTypeByGroupBy()
                {
                    Days = dateRangeResult.ToArray(),
                    Label = "Store Capacity 2",
                    Stack = "D",
                    Value = lstValueCap2.ToArray(),
                    BackgroundColor = "brown"
                });
                result.Add(new ChartFcdelByTypeByGroupBy()
                {
                    Days = dateRangeResult.ToArray(),
                    Label = "Store Capacity 3",
                    Stack = "D",
                    Value = lstValueCap3.ToArray(),
                    BackgroundColor = "black"
                });


                var diffDate = Math.Abs(dt2.Subtract(dt1).TotalDays);
                if (diffDate > 30)
                {
                    var total = new ChartFcdelByTypeByGroupBy
                    {
                        Label = "Total",
                        Stack = "true",
                        Days = result?[0].Days,
                        Value = result?.Aggregate(new double[result[0].Days.Length], (acc, item) =>
                        {
                            for (int i = 0; i < item.Value?.Length; i++)
                            {
                                acc[i] += item.Value[i];
                            }
                            return acc;
                        })
                    };
                    var distinctMonth = total.StrMonths.Distinct().ToList();
                    Dictionary<string, (DateOnly, double)> dicMonth = new Dictionary<string, (DateOnly, double)>();
                    for (int i = 0; i < total.Value.Length; i++)
                    {
                        var month = total.StrMonths[i];
                        var day = total.Days[i];
                        var val = total.Value[i];
                        if (!dicMonth.ContainsKey(month))
                        {
                            dicMonth.Add(month, (day, val));
                        }
                        else
                        {
                            if (dicMonth[month].Item2 < val)
                            {
                                dicMonth[month] = (day, val);
                            }
                        }
                    }
                    var arrDo = dicMonth.Select(x => x.Value.Item1).ToArray();
                    var lstResult = new List<ChartFcdelByTypeByGroupBy>();
                    foreach (var item in result)
                    {

                        var newVal = new List<double>();
                        Dictionary<DateOnly, double> dicValByDate = new Dictionary<DateOnly, double>();
                        for (int i = 0; i < item.Value.Length; i++)
                        {
                            try
                            {
                                dicValByDate.Add(item.Days[i], item.Value[i]);
                            }
                            catch (Exception)
                            {

                            }
                        }

                        for (int i = 0; i < arrDo.Length; i++)
                        {
                            newVal.Add(dicValByDate[arrDo[i]]);
                        }
                        var newitem = item;
                        newitem.Days = arrDo;
                        newitem.Value = newVal.ToArray();
                        lstResult.Add(newitem);
                    }
                    if (diffDate <= 365)
                    {
                        return lstResult;
                    }
                    else
                    {
                        total = new ChartFcdelByTypeByGroupBy
                        {
                            BackgroundColor = lstResult[0].BackgroundColor,
                            Label = "Total",
                            Stack = "true",
                            Days = lstResult[0].Days,
                            Value = lstResult.Aggregate(new double[lstResult[0].Value.Length], (acc, item) =>
                            {
                                for (int i = 0; i < item.Value.Length; i++)
                                {
                                    acc[i] += item.Value[i];
                                }
                                return acc;
                            })
                        };
                        var distinctYear = total.StrYears.Distinct().Select(x => Convert.ToInt32(x)).OrderBy(x => x).ToList();
                        lstResult = new List<ChartFcdelByTypeByGroupBy>();
                        Dictionary<string, (double, DateOnly)> dic = new Dictionary<string, (double, DateOnly)>();
                        for (int i = 0; i < total.Value.Length; i++)
                        {
                            dic.Add(total.StrMonths[i], (total.Value[i], total.Days[i]));
                        }
                        foreach (var item in distinctYear)
                        {
                            List<double> lstValueItem0 = new List<double>();
                            List<DateOnly> lstDayItem0 = new List<DateOnly>();
                            for (int i = 1; i <= 12; i++)
                            {
                                var dt = new DateTime(item, i, 1);
                                var strMonthYear = dt.ToString("MMM-yy");
                                if (dic.ContainsKey(strMonthYear))
                                {
                                    lstValueItem0.Add(dic[strMonthYear].Item1);
                                    lstDayItem0.Add(dic[strMonthYear].Item2);
                                }
                                else
                                {
                                    lstValueItem0.Add(0);
                                    lstDayItem0.Add(DateOnly.FromDateTime(dt));
                                }

                            }
                            rnd = new Random();
                            var cl = "rgb(" + rnd.Next(256) + ", " + rnd.Next(256) + ", " + rnd.Next(256) + ")";
                            var result0 = new ChartFcdelByTypeByGroupBy()
                            {
                                BackgroundColor = cl,
                                Days = lstDayItem0.ToArray(),
                                Value = lstValueItem0.ToArray(),
                                Label = item.ToString(),
                                Stack = item == DateTime.Now.Year ? "true" : "false"
                            };
                            lstResult.Add(result0);
                        }
                        return lstResult;
                    }
                }
                return result;
            }
            catch (Exception e)
            {
                //SendMailError(e);
                return new List<ChartFcdelByTypeByGroupBy>();
            }
        }

        [HttpPost("filter-ps-model")]
        public TodFcdelPSModel FilterPsModel(TodFcdelPSModelParam param)
        {
            try
            {
                var lstResult = new List<MasterPsView>();
                TodFcdelPSModel result = new TodFcdelPSModel();

                DateOnly? from = param.From == null? null: DateOnly.Parse(param.From); 
                DateOnly? to = param.To == null ? null : DateOnly.Parse(param.To); ;

                List<TodFcdelPsModel> query = new List<TodFcdelPsModel>();
                var list = context.TodFcdelPsModels.Where(x => x.Active == true).ToList();
                query = !string.IsNullOrEmpty(param.Model) ?list.Where(x => x.ModelName.ToUpper().Contains(param.Model.ToUpper().Trim())).ToList():list;
               
                var lstDate = query.Select(x => x.ModelDate).Distinct().OrderBy(y => y).ToList();
                if (from != null && to == null) 
                {
                    lstDate = lstDate.Where(y => y >= from).ToList();

                }
                if (from == null && to != null) 
                {
                    lstDate = lstDate.Where(y => y <= to).ToList();
                }
                if (from != null && to != null) 
                {
                    lstDate = lstDate.Where(y => y >= from && y <= to).ToList();
                }

                
                var lstModel = query.Select(x => x.ModelName).Distinct().OrderBy(y => y).ToList();
                var model2 = lstDate.Skip((param.Page - 1) * param.RecordsPerPage).Take(param.RecordsPerPage).ToList();
               // List<MasterPsView> lstData = new List<MasterPsView>();
                var lstDataValue = new List<MasterPsView>();
                foreach (var item in model2)
                {
                    List<double?> lstValue = new List<double?>();
                    foreach (var model in lstModel)
                    {
                       var value= query.FirstOrDefault(x => x.ModelDate == item && x.ModelName == model);
                       lstValue.Add(value == null ? null : value.ValueDay);
                       lstValue.Add(value == null ? null : value.ValueNight);
                       lstValue.Add(value == null ? null : value.ValueTotal);
                    }
                    var check = query.FirstOrDefault(x => x.ModelDate == item && x.ApprovalBy != null);

                    lstDataValue.Add(new MasterPsView()
                    {
                        Date = item,
                        LstValue = lstValue,
                        Status = check != null,
                        CreatedDate = check == null ? null : check.CreatedDate
                    });
                }

                lstResult.Add(new MasterPsView()
                {
                    LstModel = lstModel,
                    LstData = lstDataValue
                });

                result.lstModel = lstResult;
                result.toRecord = (int)Math.Min(result.totalRecords, result.currentPage * result.recordPerPage);
                result.totalPage = (int)Math.Ceiling((decimal)lstDate.Count / param.RecordsPerPage);
                result.totalRecords = lstDate.Count;
                result.recordPerPage = param.RecordsPerPage;
                result.currentPage = param.Page;
                result.fromRecord = lstDate.Count == 0 ? 0 : (result.currentPage - 1) * result.recordPerPage + 1;
                return result;

                //return lstData;
            }
            catch (Exception e)
            {
                //SendMailError(e);
                return new TodFcdelPSModel()
                {
                    currentPage = param.Page,
                    recordPerPage = param.RecordsPerPage
                };
            }
        }

        [HttpPost("add-fcdel-master-max-gaplot")]
        public async Task<CommonResponse> AddStructureMasterMaxGaplot([FromBody] TodFcdelMasterMaxGaplotRequest rq)
        {
            CommonResponse res = new CommonResponse()
            {
                Error = true,
                Message = "Can't add new master",
                Status = 400
            };
            var config = new MapperConfiguration(cfg => cfg.CreateMap<TodFcdelMasterMaxGaplotRequest, TodFcdelMasterMaxGaplot>());
            var mapper = config.CreateMapper();
            try
            {
                var u = GetCurrentUser();
                var model = mapper.Map<TodFcdelMasterMaxGaplotRequest, TodFcdelMasterMaxGaplot>(rq);
                if (model != null)
                {
                    model.CreatedBy = u.UserName;
                    context.TodFcdelMasterMaxGaplots.Add(model);

                    int r = await context.SaveChangesAsync();
                    if (r > 0)
                    {
                        res.Status = 200;
                        res.Message = "Sucessful !";
                        res.Error = true;
                    }
                }
            }
            catch (Exception e)
            {
                //SendMailError(e);
                res.Message = e.Message;
                res.Error = true;
                res.Status = 400;
            }
            return res;
        }
        [HttpPost("add-fcdel-master-do-leadtime")]
        public async Task<CommonResponse> AddStructureMasterDoLeadtime([FromBody] TodFcdelMasterDoLeadtimeRequest rq)
        {
            CommonResponse res = new CommonResponse()
            {
                Error = true,
                Message = "Can't add new master",
                Status = 400
            };
            var config = new MapperConfiguration(cfg => cfg.CreateMap<TodFcdelMasterDoLeadtimeRequest, TodFcdelMasterDoLeadtime>());
            var mapper = config.CreateMapper();
            try
            {
                var u = GetCurrentUser();
                var model = mapper.Map<TodFcdelMasterDoLeadtimeRequest, TodFcdelMasterDoLeadtime>(rq);
                if (model != null)
                {
                    model.CreatedBy = u.UserName;
                    context.TodFcdelMasterDoLeadtimes.Add(model);
                    int r = await context.SaveChangesAsync();
                    if (r > 0)
                    {
                        res.Status = 200;
                        res.Message = "Sucessful !";
                        res.Error = true;
                    }
                }
            }
            catch (Exception e)
            {
                //SendMailError(e);
                res.Message = e.Message;
                res.Error = true;
                res.Status = 400;
            }
            return res;
        }
        
        [HttpPut("update-fcdel-master-max-gaplot/{id}")]
        public async Task<CommonResponse> UpdateStructureMasterMerchandise(Guid id, [FromBody] TodFcdelMasterMaxGaplotRequest rq)
        {
            CommonResponse res = new CommonResponse()
            {
                Error = false,
                Message = "Can't update the master",
                Status = 200
            };
            try
            {
                var config = new MapperConfiguration(cfg => cfg.CreateMap<TodFcdelMasterMaxGaplotRequest, TodFcdelMasterMaxGaplot>());
                var mapper = config.CreateMapper();
                var u = GetCurrentUser();
                var model = await context.TodFcdelMasterMaxGaplots.FirstAsync(x => x.Id == id);
                var model1 = mapper.Map<TodFcdelMasterMaxGaplotRequest, TodFcdelMasterMaxGaplot>(rq);
                model1.ApprovalBy = null;
                model1.ApprovalDate = null;
                model1.CreatedBy = u.UserName;
                model1.CreatedDate = DateTime.Now;
                context.TodFcdelMasterMaxGaplots.Remove(model);
                context.TodFcdelMasterMaxGaplots.Add(model1);
                int r = await context.SaveChangesAsync();
                res.Message = r > 0 ? "Successful !" : "Can't update";
            }
            catch (Exception e)
            {
                //SendMailError(e);
                res.Message = e.Message;
                res.Error = true;
                res.Status = 400;
            }
            return res;
        }
        [HttpPut("update-fcdel-master-do-leadtime/{id}")]
        public async Task<CommonResponse> UpdateStructureMasterDoLeadTime(Guid id, [FromBody] TodFcdelMasterDoLeadtimeRequest rq)
        {
            CommonResponse res = new CommonResponse()
            {
                Error = false,
                Message = "Can't update the master",
                Status = 200
            };
            try
            {
                var config = new MapperConfiguration(cfg => cfg.CreateMap<TodFcdelMasterDoLeadtimeRequest, TodFcdelMasterDoLeadtime>());
                var mapper = config.CreateMapper();
                var u = GetCurrentUser();
                var model = await context.TodFcdelMasterDoLeadtimes.FirstAsync(x => x.Id == id);
                var model1 = mapper.Map<TodFcdelMasterDoLeadtimeRequest, TodFcdelMasterDoLeadtime>(rq);
                model1.ApprovalBy = null;
                model1.ApprovalDate = null;
                model1.CreatedBy = u.UserName;
                model1.CreatedDate = DateTime.Now;
                context.TodFcdelMasterDoLeadtimes.Remove(model);
                context.TodFcdelMasterDoLeadtimes.Add(model1);
                int r = await context.SaveChangesAsync();
                res.Message = r > 0 ? "Successful !" : "Can't update";
            }
            catch (Exception e)
            {
                //SendMailError(e);
                res.Message = e.Message;
                res.Error = true;
                res.Status = 400;
            }
            return res;
        }
        
        [HttpGet("approve-fcdel-master-max-gaplot")]
        public async Task<CommonResponse> ApproveMasterMaxGapLot()
        {
            CommonResponse res = new CommonResponse()
            {
                Error = false,
                Message = "",
                Status = (int)HttpStatusCode.BadRequest
            };
            try
            {
                if (HangfireJobList.PreventUpload())
                {
                    res.Error = true;
                    res.Message = "Other jobs processing";
                    res.Status = 400;
                    return res;
                }
                var u = GetCurrentUser();
                //những con approved trc đó thì bỏ hết, vì mình lấy cái mới mà
                var modelOld = await context.TodFcdelMasterMaxGaplots
                    .Where(x => x.Active == true && x.ApprovalDate != null && x.ApprovalBy != null)
                    .ToListAsync();
                modelOld.ForEach(x =>
                {
                    x.Active = false;
                });
                context.UpdateRange(modelOld);
                context.SaveChanges();
                //và approve cho những con mới
                var model = await context.TodFcdelMasterMaxGaplots
                    .Where(x => x.Active == true && x.ApprovalDate == null)
                    .ToListAsync();
                model.ForEach(x =>
                {
                    x.ApprovalBy = u.UserName;
                    x.ApprovalDate = DateTime.Now;

                });
                context.UpdateRange(model);
                context.SaveChanges();
                res.Error = false;
                res.Message = "Successfully !";
                res.Status = (int)HttpStatusCode.OK;
            }
            catch (Exception e)
            {
                res.Error = true;
                res.Message = e.Message;
                res.Status = (int)HttpStatusCode.BadRequest;
                //SendMailError(e);
            }
            return res;
        }
        [HttpGet("reject-fcdel-master-max-gaplot")]
        public async Task<CommonResponse> RejectMasterMaxGapLot()
        {
            CommonResponse res = new CommonResponse()
            {
                Error = false,
                Message = "",
                Status = (int)HttpStatusCode.BadRequest
            };
            try
            {
                if (HangfireJobList.PreventUpload())
                {
                    res.Error = true;
                    res.Message = "Other jobs processing";
                    res.Status = 400;
                    return res;
                }
                var u = GetCurrentUser();
                //những con approved trc đó thì bỏ hết, vì mình lấy cái mới mà
                var modelOld = await context.TodFcdelMasterMaxGaplots
                    .Where(x => x.Active == true && x.ApprovalDate == null)
                    .ToListAsync();
                modelOld.ForEach(x =>
                {
                    x.Active = false;
                    x.ApprovalBy = u.UserName;
                    x.ApprovalDate = DateTime.Now;
                });
                context.UpdateRange(modelOld);
                context.SaveChanges();
                res.Error = false;
                res.Message = "Successfully !";
                res.Status = (int)HttpStatusCode.OK;
            }
            catch (Exception e)
            {
                res.Error = true;
                res.Message = e.Message;
                res.Status = (int)HttpStatusCode.BadRequest;
                //SendMailError(e);
            }
            return res;
        }
        [HttpGet("approve-fcdel-master-do-leadtime")]
        public async Task<CommonResponse> ApproveMasterDoLeadTime()
        {
            CommonResponse res = new CommonResponse()
            {
                Error = false,
                Message = "",
                Status = (int)HttpStatusCode.BadRequest
            };
            try
            {
                if (HangfireJobList.PreventUpload())
                {
                    res.Error = true;
                    res.Message = "Other jobs processing";
                    res.Status = 400;
                    return res;
                }
                var u = GetCurrentUser();

                //những con approved trc đó thì bỏ hết, vì mình lấy cái mới mà
                var modelOld = await context.TodFcdelMasterDoLeadtimes
                    .Where(x => x.Active == true && x.ApprovalDate != null && x.ApprovalBy != null)
                    .ToListAsync();
                modelOld.ForEach(x =>
                {
                    x.Active = false;
                });
                context.UpdateRange(modelOld);
                context.SaveChanges();
                //và approve cho những con mới
                var model = await context.TodFcdelMasterDoLeadtimes
                    .Where(x => x.Active == true && x.ApprovalDate == null)
                    .ToListAsync();
               
                model.ForEach(x =>
                {
                    x.ApprovalBy = u.UserName;
                    x.ApprovalDate = DateTime.Now;
                });
                context.UpdateRange(model);
                await context.SaveChangesAsync();

                res.Error = false;
                res.Message = "Successfully !";
                res.Status = (int)HttpStatusCode.OK;
            }
            catch (Exception e)
            {
                res.Error = true;
                res.Message = e.Message;
                res.Status = (int)HttpStatusCode.BadRequest;
                //SendMailError(e);
            }
            return res;
        }
        [HttpGet("reject-fcdel-master-do-leadtime")]
        public async Task<CommonResponse> RejectMasterDoLeadTime()
        {
            CommonResponse res = new CommonResponse()
            {
                Error = false,
                Message = "",
                Status = (int)HttpStatusCode.BadRequest
            };
            try
            {
                if (HangfireJobList.PreventUpload())
                {
                    res.Error = true;
                    res.Message = "Other jobs processing";
                    res.Status = 400;
                    return res;
                }
                var u = GetCurrentUser();

                //những con approved trc đó thì bỏ hết, vì mình lấy cái mới mà
                var modelOld = await context.TodFcdelMasterDoLeadtimes
                    .Where(x => x.Active == true && x.ApprovalDate == null)
                    .ToListAsync();
                modelOld.ForEach(x =>
                {
                    x.Active = false;
                    x.ApprovalBy = u.UserName;
                    x.ApprovalDate = DateTime.Now;
                });
                context.UpdateRange(modelOld);
                context.SaveChanges();
               
                res.Error = false;
                res.Message = "Successfully !";
                res.Status = (int)HttpStatusCode.OK;
            }
            catch (Exception e)
            {
                res.Error = true;
                res.Message = e.Message;
                res.Status = (int)HttpStatusCode.BadRequest;
                //SendMailError(e);
            }
            return res;
        }
        [HttpGet("approve-fcdel-ps-model")]
        public async Task<CommonResponse> ApprovePsModel()
        {
            CommonResponse res = new CommonResponse()
            {
                Error = false,
                Message = "",
                Status = (int)HttpStatusCode.BadRequest
            };
            try
            {
                if (HangfireJobList.PreventUpload())
                {
                    res.Error = true;
                    res.Message = "Other jobs processing";
                    res.Status = 400;
                    return res;
                }
                var u = GetCurrentUser();

                var model = await context.TodFcdelPsModels
                    .Where(x => x.Active == true && x.ApprovalDate == null)
                    .ToListAsync();
                //foreach (var item in model)
                //{
                //    var exists = context.TodFcdelPsModels.Where(x => x.ModelDate == item.ModelDate
                //    && x.ModelName == item.ModelName).FirstOrDefault();
                //    if (exists != null)
                //    {
                //        exists.Active = false;
                //        context.Update(exists);
                //        await context.SaveChangesAsync();
                //    }
                //}
                model.ForEach(x =>
                {
                    x.ApprovalBy = u.UserName;
                    x.ApprovalDate = DateTime.Now;
                });
                context.UpdateRange(model);
                await context.SaveChangesAsync();

                res.Error = false;
                res.Message = "Successfully !";
                res.Status = (int)HttpStatusCode.OK;
            }
            catch (Exception e)
            {
                res.Error = true;
                res.Message = e.Message;
                res.Status = (int)HttpStatusCode.BadRequest;
                //SendMailError(e);
            }
            return res;
        }
        [HttpGet("reject-fcdel-ps-model")]
        public async Task<CommonResponse> RejectPsModel()
        {
            CommonResponse res = new CommonResponse()
            {
                Error = false,
                Message = "",
                Status = (int)HttpStatusCode.BadRequest
            };
            try
            {
               
                var u = GetCurrentUser();

                var model = await context.TodFcdelPsModels
                    .Where(x => x.Active == true && x.ApprovalDate == null)
                    .ToListAsync();
                
                model.ForEach(x =>
                {
                    x.Active = false;
                    x.ApprovalBy = u.UserName;
                    x.ApprovalDate = DateTime.Now;
                });
                context.UpdateRange(model);
                await context.SaveChangesAsync();

                res.Error = false;
                res.Message = "Successfully !";
                res.Status = (int)HttpStatusCode.OK;
            }
            catch (Exception e)
            {
                res.Error = true;
                res.Message = e.Message;
                res.Status = (int)HttpStatusCode.BadRequest;
                //SendMailError(e);
            }
            return res;
        }
        [HttpGet("approve-abnormal-stock")]
        public async Task<CommonResponse> ApproveAbnormalStock()
        {
            CommonResponse res = new CommonResponse()
            {
                Error = false,
                Message = "",
                Status = (int)HttpStatusCode.BadRequest
            };
            try
            {
                if (HangfireJobList.PreventUpload())
                {
                    res.Error = true;
                    res.Message = "Other jobs processing";
                    res.Status = 400;
                    return res;
                }
                var u = GetCurrentUser();
                var check = context.TodFcdelMasterAbnormalStocks
                         .Any(x => x.Active == true && x.ApprovalDate == null);
                //những con approved trc đó thì bỏ hết, vì mình lấy cái mới mà
                if (check == true)
                {
                    var modelOld = await context.TodFcdelMasterAbnormalStocks
                            .Where(x => x.Active == true && x.ApprovalDate != null && x.ApprovalBy != null)
                            .ToListAsync();
                    modelOld.ForEach(x =>
                    {
                        x.Active = false;
                    });
                    context.UpdateRange(modelOld);
                    context.SaveChanges();
                }
                //và approve cho những con mới
                var model = await context.TodFcdelMasterAbnormalStocks
                        .Where(x => x.Active == true && x.ApprovalDate == null)
                        .ToListAsync();
                model.ForEach(x =>
                {
                    x.ApprovalBy = u.UserName;
                    x.ApprovalDate = DateTime.Now;

                });
                context.UpdateRange(model);
                context.SaveChanges();


                res.Error = false;
                res.Message = "Successfully !";
                res.Status = (int)HttpStatusCode.OK;
                return res;
            }
            catch (Exception e)
            {
                res.Error = true;
                res.Message = e.Message;
                res.Status = (int)HttpStatusCode.BadRequest;
                //SendMailError(e);
                return res;
            }


        }
        [HttpGet("reject-abnormal-stock")]
        public async Task<CommonResponse> RejectAbnormalStock()
        {
            CommonResponse res = new CommonResponse()
            {
                Error = false,
                Message = "",
                Status = (int)HttpStatusCode.BadRequest
            };
            try
            {
               
                var u = GetCurrentUser();
                
                var model = await context.TodFcdelMasterAbnormalStocks
                        .Where(x => x.Active == true && x.ApprovalDate == null)
                        .ToListAsync();
                model.ForEach(x =>
                {
                    x.Active = false;
                    x.ApprovalBy = u.UserName;
                    x.ApprovalDate = DateTime.Now;

                });
                context.UpdateRange(model);
                context.SaveChanges();


                res.Error = false;
                res.Message = "Successfully !";
                res.Status = (int)HttpStatusCode.OK;
                return res;
            }
            catch (Exception e)
            {
                res.Error = true;
                res.Message = e.Message;
                res.Status = (int)HttpStatusCode.BadRequest;
                //SendMailError(e);
                return res;
            }


        }
        [HttpPut("delete-fcdel-master-max-gaplot")]
        public async Task<CommonResponse> DeleteMasterMaxGapLot([FromBody] Guid[] id)
        {
            CommonResponse res = new CommonResponse()
            {
                Error = false,
                Message = "",
                Status = (int)HttpStatusCode.BadRequest
            };
            try
            {
                var u = GetCurrentUser();
                var model = await context.TodFcdelMasterMaxGaplots
                        .Where(x => x.Active == true && x.ApprovalDate == null && id.Contains(x.Id))
                        .ToListAsync();
                context.TodFcdelMasterMaxGaplots.RemoveRange(model);
                context.SaveChanges();
                res.Error = false;
                res.Message = "Successfully !";
                res.Status = (int)HttpStatusCode.OK;
            }
            catch (Exception e)
            {
                res.Error = true;
                res.Message = e.Message;
                res.Status = (int)HttpStatusCode.BadRequest;
                //SendMailError(e);
            }
            return res;
        }
        [HttpPut("delete-fcdel-master-do-leadtime")]
        public async Task<CommonResponse> DeleteMasterDoLeadTime([FromBody] Guid[] id)
        {
            CommonResponse res = new CommonResponse()
            {
                Error = false,
                Message = "",
                Status = (int)HttpStatusCode.BadRequest
            };
            try
            {
                var u = GetCurrentUser();
                var model = await context.TodFcdelMasterDoLeadtimes
                    .Where(x => x.Active == true && x.ApprovalDate == null && id.Contains(x.Id))
                    .ToListAsync();
                context.TodFcdelMasterDoLeadtimes.RemoveRange(model);
                context.SaveChanges();
                res.Error = false;
                res.Message = "Successfully !";
                res.Status = (int)HttpStatusCode.OK;
            }
            catch (Exception e)
            {
                res.Error = true;
                res.Message = e.Message;
                res.Status = (int)HttpStatusCode.BadRequest;
                //SendMailError(e);
            }
            return res;
        }
        [HttpGet("get-link-file-ps-model")]
        public async Task<CommonResponse> GetLinkFilePsModel()
        {
            CommonResponse res = new CommonResponse()
            {
                Error = false,
                Message = "",
                Status = (int)HttpStatusCode.BadRequest
            };
            try
            {
                string folderPath = Path.Combine(pathServer, "PsModel"); // Thay thế bằng đường dẫn thu mục chứa các file
                                                                                                                    // Lấy danh sách tất cả các file có định dạng Output_ALL_
                string[] files = Directory.GetFiles(folderPath, "PsModel_*");
                //Sắp xếp danh sách các file theo thứ tự giảm dần của ngày tạo
                //Array.Sort(files, (a, b) => System.IO.File.GetCreationTime(b).CompareTo(System.IO.File.GetCreationTime(a)));
                string filePath = files.Last();
                if (!System.IO.File.Exists(filePath))
                {
                    res.Error = true;
                    res.Message = "Not found !";
                    res.Status = (int)HttpStatusCode.BadRequest;
                }
                var url = $"{httpContextAccessor.HttpContext.Request.Scheme}://{httpContextAccessor.HttpContext.Request.Host}";
                var routeForDB = url+ "/PsModel/"+ Path.GetFileName(filePath); 
                //string fileUrl = Url.ActionLink(nameof(TodFcdelVolumeController.dow), "File");

                res.Error = false;
                res.Message = routeForDB;
                res.Status = (int)HttpStatusCode.OK;
            }
            catch (Exception e)
            {
                res.Error = true;
                res.Message = e.Message;
                res.Status = (int)HttpStatusCode.BadRequest;
                ////SendMailError(e);
            }
            return res;
        }
        [HttpGet("check-approve-ps-model")]
        public async Task<CommonResponse> CheckApprovePsModel()
        {
            CommonResponse res = new CommonResponse()
            {
                Error = false,
                Message = "",
                Status = (int)HttpStatusCode.BadRequest
            };
            try
            {

                var check = context.TodFcdelPsModels.Any(x => x.ApprovalBy == null && x.ApprovalDate == null);
                if(check == false)
                {
                    res.Error = false;
                    res.Message = "Ok";
                    res.Status = (int)HttpStatusCode.OK;
                }
                else
                {
                    res.Error = true;
                    res.Message = "NG";
                    res.Status = (int)HttpStatusCode.BadRequest;
                }
               
            }
            catch (Exception e)
            {
                res.Error = true;
                res.Message = e.Message;
                res.Status = (int)HttpStatusCode.BadRequest;
                //SendMailError(e);
            }
            return res;
        }
        [HttpGet("update-fc-delivery-after-approve-ps-model")]
        public async Task<IActionResult> UpdateFCAfterApprove()
        {
            CommonResponse res = new CommonResponse()
            {
                Error = false,
                Message = "",
                Status = (int)HttpStatusCode.BadRequest
            };
            try
            {
                //var clockSaveChanges = new Stopwatch();
                //clockSaveChanges.Start();
                await ManualFunc.GatewayAsync("CalculateAction/Fc/IJ");
                await ManualFunc.GatewayAsync("CalculateAction/Fc/LBP");
                //clockSaveChanges.Stop();
                //var spendTime = clockSaveChanges.Elapsed.TotalMinutes + " minute with calculate all (IJ & LBP) FC volume";
                //NoticeFinishJob(spendTime);
                return Content("OK");
            }
            catch (Exception ex)
            {
                NoticeFinishJob(ex.Message);
                return Content("NG");
            }
            
        }



        private bool SendMailError(Exception e)
        {
            try
            {
                string txtContent = "<p>Message: " + e.Message + "</p>\n" +
                "<p>Data: " + e.Data.ToString() + "</p>\n" +
                "<p>StackTrace: " + e.StackTrace + "</p>\n" +
                "<p>HelpLink: " + e.HelpLink ?? "" + "</p>\n" +
                "<p>Source: " + e.Source ?? "" + "</p>\n";
                email.Initial(lstITMail,
                    "Error exception",
                    txtContent);
                return false;
            }
            catch
            {
                return false;
            }
        }
        private UserClaims GetCurrentUser()
        {
            UserClaims userClaims = new UserClaims();
            var identity = HttpContext.User.Identity as ClaimsIdentity;
            if (identity != null)
            {
                userClaims.UserName = identity.FindFirst("user_name") == null ? "Undefined" : identity.FindFirst("user_name").Value;
                userClaims.Id = identity.FindFirst("id") == null ? "Undefined" : identity.FindFirst("id").Value;
                //userClaims.IsIt = identity.FindFirst("isIt") == null ? "0" : identity.FindFirst("isIt").Value;
                userClaims.Departments = identity.FindFirst("deptIds") == null ? "" : identity.FindFirst("deptIds").Value;
                userClaims.Factories = identity.FindFirst("factIds") == null ? "" : identity.FindFirst("factIds").Value;
                userClaims.CostCenter = identity.FindFirst("cost_center") == null ? "" : identity.FindFirst("cost_center").Value;
                userClaims.FullName = identity.FindFirst("full_name") == null ? "" : identity.FindFirst("full_name").Value;
                userClaims.Departments = identity.FindFirst("dept") == null ? "" : identity.FindFirst("dept").Value;
                userClaims.Grade = identity.FindFirst("grade") == null ? "" : identity.FindFirst("grade").Value;
                userClaims.IsAdmin = identity.FindFirst("isAdmin") == null ? "false" : identity.FindFirst("isAdmin").Value;

            }
            return userClaims;
        }

        private void NoticeFinishJob(string note)
        {
            try
            {
                var lstMail = new List<string>();
                
                    lstMail = context.AdmUserInformations.Where(x => x.Active == true
                    && x.AdmDetailUserGroups.Any(y => y.Active == true
                    && y.GroupId == Guid.Parse("99f66340-7ab7-4dac-ac55-fa37bab404d7")))
                        .Include(x => x.AdmDetailUserGroups)
                        .Select(x => x.Email ?? "")
                        .ToList();
                
                email.Initial(lstMail, "[PSI-System] Completed FC output job", @"<p style='font-weight: bold;'>Dear [Mrs/Mr]. All,</p>
<p>You have received a notification about <span style='font-weight: bold; color: red; font-style: italic;'>completed calculate FC volume new output </span>from PDCS System. Please access system and check.</p>
<p style='font-weight: bold;'>1. Time: " + note + @"</p>
<p style='font-weight: bold;'>2. If you have any wrong, please check master structure output at first." + @"<br />
<p>If you encounter any difficulties or need further assistance, please don't hesitate to contact our support team at it-app28@local.canon-vn.com.vn, it-app26@local.canon-vn.com.vn</p>
<p>Thank you for using PDCS.</p>
<p style='font-weight: bold;'>Best regards,</p>
<p style='font-weight: bold;'>(6615) 8702<br />
System Support Team</p>
<p style='font-style: italic;'>This email is automatically sent by PDCS system, please do not reply!</p>");

            }
            catch (Exception)
            {

            }
        }
    }
}
