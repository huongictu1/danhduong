﻿using AutoMapper;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using PDCProjectApi.Common;
using PDCProjectApi.Common.Function;
using PDCProjectApi.Data;
using PDCProjectApi.Model.Chart;
using PDCProjectApi.Model.View;
using PDCProjectApi.Services;
using System.Collections.Generic;
using System.Linq;

namespace PDCProjectApi.Controllers
{
    [Route("api/home")]
    [ApiController]
    [Authorize]
    //[ApiExplorerSettings(IgnoreApi = true)]
    public class HomeController : ControllerBase, IDisposable
    {
        private readonly IHttpContextAccessor httpContextAccessor;
        private readonly PdcsystemContext context;
        private readonly IGlobalVariable global;
        private string Factory = "";
        private bool disposed = false;
        protected virtual void Dispose(bool disposing)
        {
            if (!disposed)
            {
                if (disposing)
                {
                    if (context != null)
                    {
                        context.DisposeAsync();
                    }
                }
                disposed = true;
            }
        }
        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }
        ~HomeController() { Dispose(false); }
        [Obsolete]
        public HomeController(Microsoft.AspNetCore.Hosting.IHostingEnvironment hosting, PdcsystemContext ctx, IHttpContextAccessor httpContextAccessor, IGlobalVariable glo)
        {
            this.httpContextAccessor = httpContextAccessor;
            this.context = ctx;
            this.global = glo;
            this.Factory = this.global.ReturnFactory();
        }
        [HttpGet("get-daily-live-pp-timely")]
        [AllowAnonymous]
       // [ResponseCache(Duration = 3600)]
        public async Task<List<DailyLivePPTimelyByModel>> GetDailyLivePPTimely(string product)
        {
            var result = new List<DailyLivePPTimelyByModel>();
            try
            {
                if(this.Factory != "TS" && this.Factory != "Test")
                {
                    return result;
                }
                var dt = DateTime.Now;
                if (product == "IJ")
                {
                    result = await context.VlinkageHksLivePpIjs.Where(x => x.PalletDate == dt.ToString("dd-MM-yyyy")
                        && x.FromTime.StartsWith(dt.ToString("yyyy-MM-dd")))
                            .GroupBy(o => new { o.FromTime })
                            .Select(g => new DailyLivePPTimelyByModel
                            {
                                FromTime = g.Key.FromTime.Substring(11, 5),
                                Plan = g.Sum(o => Convert.ToDouble(o.PlanQty ?? "0")),
                                Actual = g.Sum(o => Convert.ToDouble(o.Actual ?? "0"))
                            })
                            .ToListAsync();
                }
                else if (product == "LBP")
                {
                    result = await context.VlinkageHksLivePpLbps.Where(x => x.PalletDate == dt.ToString("dd-MM-yyyy")
                        && x.FromTime.StartsWith(dt.ToString("yyyy-MM-dd")))
                            .GroupBy(o => new { o.FromTime })
                            .Select(g => new DailyLivePPTimelyByModel
                            {
                                FromTime = g.Key.FromTime.Substring(11, 5),
                                Plan = g.Sum(o => Convert.ToDouble(o.PlanQty ?? "0")),
                                Actual = g.Sum(o => Convert.ToDouble(o.Actual ?? "0"))
                            })
                            .ToListAsync();
                }
            }
            catch (Exception)
            {

            }
            return result;
        }
        [HttpGet("get-daily-live-pp-timely-by-model")]
        [AllowAnonymous]
        //[ResponseCache(Duration = 3600)]
        public async Task<List<DailyLivePPTimelyByModel>> GetDailyLivePPTimelyByModel(string product, string model)
        {
            var result = new List<DailyLivePPTimelyByModel>();
            try
            {
                if (this.Factory != "TS" && this.Factory != "Test")
                {
                    return result;
                }
                var dt = DateTime.Now;
                if (product == "IJ")
                {
                    result = await context.VlinkageHksLivePpIjs.Where(x => x.ProductCode == model
                        && x.PalletDate.Equals(dt.ToString("dd-MM-yyyy")))
                            .GroupBy(o => new { o.FromTime })
                            .Select(g => new DailyLivePPTimelyByModel
                            {
                                FromTime = g.Key.FromTime.Substring(11, 5),
                                Plan = g.Sum(o => Convert.ToDouble(o.PlanQty ?? "0")),
                                Actual = g.Sum(o => Convert.ToDouble(o.Actual ?? "0"))
                            })
                            .ToListAsync();
                }
                else if (product == "LBP")
                {
                    result = await context.VlinkageHksLivePpLbps.Where(x => x.PalletDate == dt.ToString("dd-MM-yyyy")
                        && x.ProductCode == model
                        && x.PalletDate.Equals(dt.ToString("dd-MM-yyyy")))
                            .GroupBy(o => new { o.FromTime })
                            .Select(g => new DailyLivePPTimelyByModel
                            {
                                FromTime = g.Key.FromTime.Substring(11, 5),
                                Plan = g.Sum(o => Convert.ToDouble(o.PlanQty ?? "0")),
                                Actual = g.Sum(o => Convert.ToDouble(o.Actual ?? "0"))
                            })
                            .ToListAsync();
                }
            }
            catch (Exception)
            {

            }
            result.ForEach(x =>
            {
                x.Plan = Math.Round(x.Plan);
                x.Actual = Math.Round(x.Actual);
            });
            return result;
        }
        [HttpGet("get-daily-live-pp-timely-by-model-date")]
        [AllowAnonymous]
        //[ResponseCache(Duration = 3600)]
        public async Task<List<DailyLivePPTimelyByModel>> GetDailyLivePPTimelyByModelDate(string product, string model, string date)
        {
            var result = new List<DailyLivePPTimelyByModel>();
            try
            {
                if (this.Factory != "TS" && this.Factory != "Test")
                {
                    return result;
                }
                var dt = DateTime.Parse(date);
                // dt = dt.AddDays(1);
                var dt1 = DateTime.Now;
                if (dt.Date == dt1.Date)
                {
                    //if (product == "IJ")
                    //{
                    //    result = await context.VlinkageHksLivePpIjs.Where(x => x.ProductCode == model
                    //        && x.PalletDate.Equals(dt.ToString("dd-MM-yyyy")))
                    //            .GroupBy(o => new { o.FromTime })
                    //            .Select(g => new DailyLivePPTimelyByModel
                    //            {
                    //                FromTime = g.Key.FromTime.Substring(11, 5),
                    //                Plan = g.Sum(o => Convert.ToDouble(o.PlanQty ?? "0")),
                    //                Actual = g.Sum(o => Convert.ToDouble(o.Actual ?? "0"))
                    //            })
                    //            .ToListAsync();
                    //}
                    //else if (product == "LBP")
                    //{
                    //    result = await context.VlinkageHksLivePpLbps.Where(x => x.ProductCode == model
                    //        && x.PalletDate.Equals(dt.ToString("dd-MM-yyyy")))
                    //            .GroupBy(o => new { o.FromTime })
                    //            .Select(g => new DailyLivePPTimelyByModel
                    //            {
                    //                FromTime = g.Key.FromTime.Substring(11, 5),
                    //                Plan = g.Sum(o => Convert.ToDouble(o.PlanQty ?? "0")),
                    //                Actual = g.Sum(o => Convert.ToDouble(o.Actual ?? "0"))
                    //            })
                    //            .ToListAsync();
                    //}
                    if (product == "IJ")
                    {
                        result = await context.MvDailyLivePpIjs.Where(x => x.ProductCode == model
                            && x.PalletDate.Equals(dt.ToString("dd-MM-yyyy")))
                                .GroupBy(o => new { o.FromTime })
                                .Select(g => new DailyLivePPTimelyByModel
                                {
                                    FromTime = g.Key.FromTime.Substring(11, 5),
                                    Plan = g.Sum(o => Convert.ToDouble(o.Plan ?? 0)),
                                    Actual = g.Sum(o => Convert.ToDouble(o.Actual ?? 0))
                                })
                                .ToListAsync();
                        result.SortStartShiftTime();
                    }
                    else if (product == "LBP")
                    {
                        result = await context.MvDailyLivePpLbps.Where(x => x.ProductCode == model
                            && x.PalletDate.Equals(dt.ToString("dd-MM-yyyy")))
                                .GroupBy(o => new { o.FromTime })
                                .Select(g => new DailyLivePPTimelyByModel
                                {
                                    FromTime = g.Key.FromTime.Substring(11, 5),
                                    Plan = g.Sum(o => Convert.ToDouble(o.Plan ?? 0)),
                                    Actual = g.Sum(o => Convert.ToDouble(o.Actual ?? 0))
                                })
                                .ToListAsync();
                        result.SortStartShiftTime();
                    }
                }
                else
                {
                    result = await context.HistoryVlinkageDailyLivePps.Where(x => x.Model == model && x.Product == product
                            && x.PalletDate.Equals(dt.ToString("dd-MM-yyyy")))
                                .GroupBy(o => new { o.FromTime })
                                .Select(g => new DailyLivePPTimelyByModel
                                {
                                    FromTime = g.Key.FromTime.Substring(11, 5),
                                    Plan = g.Sum(o => Convert.ToDouble(o.Plan ?? "0")),
                                    Actual = g.Sum(o => Convert.ToDouble(o.Actual ?? "0"))
                                })
                                .ToListAsync();
                    result.SortStartShiftTime();
                }
            }
            catch (Exception)
            {

            }
            result.ForEach(x =>
            {
                x.Plan = Math.Round(x.Plan);
                x.Actual = Math.Round(x.Actual);
            });
            return result;
        }
        [HttpGet("get-daily-live-pp-shiftly-by-model")]
        [AllowAnonymous]
        //[ResponseCache(Duration = 3600)]
        public async Task<List<DailyLivePPShiftlyByModel>> GetDailyLivePPShiftlyByModel(string product, string model)
        {
            var result = new List<DailyLivePPShiftlyByModel>();
            try
            {
                if (this.Factory != "TS" && this.Factory != "Test")
                {
                    return result;
                }
                var dt = DateTime.Now;
                if (product == "IJ")
                {
                    result = await context.MvDailyLivePpIjs.Where(x => x.ProductCode == model
                        && x.PalletDate.Equals(dt.ToString("dd-MM-yyyy")))
                            .GroupBy(o => new { o.Shift })
                            .Select(g => new DailyLivePPShiftlyByModel
                            {
                                Shift = g.Key.Shift == "D" ? "Dayshift" : "Nightshift",
                                Plan = g.Sum(o => Convert.ToDouble(o.Plan ?? 0)),
                                Actual = g.Sum(o => Convert.ToDouble(o.Actual ?? 0))
                            })
                            .ToListAsync();
                }
                else if (product == "LBP")
                {
                    result = await context.MvDailyLivePpLbps.Where(x => x.ProductCode == model
                        && x.PalletDate.Equals(dt.ToString("dd-MM-yyyy")))
                            .GroupBy(o => new { o.Shift })
                            .Select(g => new DailyLivePPShiftlyByModel
                            {
                                Shift = g.Key.Shift == "D" ? "Dayshift" : "Nightshift",
                                Plan = g.Sum(o => Convert.ToDouble(o.Plan ?? 0)),
                                Actual = g.Sum(o => Convert.ToDouble(o.Actual ?? 0))
                            })
                            .ToListAsync();
                }
            }
            catch (Exception)
            {

            }
            result.ForEach(x =>
            {
                x.Plan = Math.Round(x.Plan);
                x.Actual = Math.Round(x.Actual);
            });
            return result;
        }
        [HttpGet("get-daily-live-pp-shiftly-by-model-date")]
        [AllowAnonymous]
        //[ResponseCache(Duration = 3600)]
        public async Task<List<DailyLivePPShiftlyByModel>> GetDailyLivePPShiftlyByModelDate(string product, string model, string date)
        {
            var result = new List<DailyLivePPShiftlyByModel>();
            try
            {
                if (this.Factory != "TS" && this.Factory != "Test")
                {
                    return result;
                }
                var dt = DateTime.Parse(date);
                // dt = dt.AddDays(1);
                var dt1 = DateTime.Now;
                if (dt.Date == dt1.Date)
                {
                    if (product == "IJ")
                    {
                        result = await context.MvDailyLivePpIjs.Where(x => x.ProductCode == model
                            && x.PalletDate.Equals(dt.ToString("dd-MM-yyyy")))
                                .GroupBy(o => new { o.Shift })
                                .Select(g => new DailyLivePPShiftlyByModel
                                {
                                    Shift = g.Key.Shift == "D" ? "Dayshift" : "Nightshift",
                                    Plan = g.Sum(o => Convert.ToDouble(o.Plan ?? 0)),
                                    Actual = g.Sum(o => Convert.ToDouble(o.Actual ?? 0))
                                })
                                .ToListAsync();
                    }
                    else if (product == "LBP")
                    {
                        result = await context.MvDailyLivePpLbps.Where(x => x.ProductCode == model
                            && x.PalletDate.Equals(dt.ToString("dd-MM-yyyy")))
                                .GroupBy(o => new { o.Shift })
                                .Select(g => new DailyLivePPShiftlyByModel
                                {
                                    Shift = g.Key.Shift == "D" ? "Dayshift" : "Nightshift",
                                    Plan = g.Sum(o => Convert.ToDouble(o.Plan ?? 0)),
                                    Actual = g.Sum(o => Convert.ToDouble(o.Actual ?? 0))
                                })
                                .ToListAsync();
                    }
                }
                else
                {
                    result = await context.HistoryVlinkageDailyLivePps.Where(x => x.Model == model && x.Product == product
                            && x.PalletDate.Equals(dt.ToString("dd-MM-yyyy")))
                                .GroupBy(o => new { o.Shift })
                                .Select(g => new DailyLivePPShiftlyByModel
                                {
                                    Shift = g.Key.Shift == "D" ? "Dayshift" : "Nightshift",
                                    Plan = g.Sum(o => Convert.ToDouble(o.Plan ?? "0")),
                                    Actual = g.Sum(o => Convert.ToDouble(o.Actual ?? "0"))
                                })
                                .ToListAsync();
                }

            }
            catch (Exception)
            {

            }
            result.ForEach(x =>
            {
                x.Plan = Math.Round(x.Plan);
                x.Actual = Math.Round(x.Actual);
            });
            if (!result.Exists(x => x.Shift == "Dayshift"))
            {
                result.Add(new DailyLivePPShiftlyByModel()
                {
                    Shift = "Dayshift",
                    Actual = 0,
                    Plan = 0
                });
            }
            if (!result.Exists(x => x.Shift == "Nightshift"))
            {
                result.Add(new DailyLivePPShiftlyByModel()
                {
                    Shift = "Nightshift",
                    Actual = 0,
                    Plan = 0
                });
            }
            return result;
        }
        [HttpGet("get-daily-live-pp-total-by-model")]
        [AllowAnonymous]
        //[ResponseCache(Duration = 3600)]
        public async Task<List<DailyLivePPTotal>> GetDailyLivePPTotal(string product)
        {
            var result = new List<DailyLivePPTotal>();
            try
            {
                if (this.Factory != "TS" && this.Factory != "Test")
                {
                    return result;
                }
                var dt = DateTime.Now;
                if (product == "IJ")
                {
                    result = await context.MvDailyLivePpIjs.Where(x => x.PalletDate.Equals(dt.ToString("dd-MM-yyyy")))
                            .GroupBy(o => new { o.Shift })
                            .Select(g => new DailyLivePPTotal
                            {
                                Shift = g.Key.Shift == "D" ? "Dayshift" : "Nightshift",
                                Plan = g.Sum(o => Convert.ToDouble(o.Plan ?? 0)),
                                Actual = g.Sum(o => Convert.ToDouble(o.Actual ?? 0))
                            })
                            .ToListAsync();
                }
                else if (product == "LBP")
                {
                    result = await context.MvDailyLivePpLbps.Where(x => x.PalletDate.Equals(dt.ToString("dd-MM-yyyy")))
                            .GroupBy(o => new { o.Shift })
                            .Select(g => new DailyLivePPTotal
                            {
                                Shift = g.Key.Shift == "D" ? "Dayshift" : "Nightshift",
                                Plan = g.Sum(o => Convert.ToDouble(o.Plan ?? 0)),
                                Actual = g.Sum(o => Convert.ToDouble(o.Actual ?? 0))
                            })
                            .ToListAsync();
                }
            }
            catch (Exception)
            {

            }
            result.ForEach(x =>
            {
                x.Plan = Math.Round(x.Plan);
                x.Actual = Math.Round(x.Actual);
            });
            return result;
        }
        [HttpGet("get-daily-live-pp-total-by-model-date")]
        [AllowAnonymous]
        //[ResponseCache(Duration = 3600)]
        public async Task<List<DailyLivePPTotal>> GetDailyLivePPTotalDate(string product, string date)
        {
            var result = new List<DailyLivePPTotal>();
            try
            {
                if (this.Factory != "TS" && this.Factory != "Test")
                {
                    return result;
                }
                var dt = DateTime.Parse(date);
                // dt = dt.AddDays(1);
                var dt1 = DateTime.Now;
                if (dt.Date == dt1.Date)
                {
                    if (product == "IJ")
                    {
                        result = await context.MvDailyLivePpIjs.Where(x => x.PalletDate == dt.ToString("dd-MM-yyyy")
                            /*&& x.PalletDate.Equals(dt.ToString("dd-MM-yyyy"))*/)
                                .GroupBy(o => new { o.Shift })
                                .Select(g => new DailyLivePPTotal
                                {
                                    Shift = g.Key.Shift == "D" ? "Dayshift" : "Nightshift",
                                    Plan = g.Sum(o => Convert.ToDouble(o.Plan ?? 0)),
                                    Actual = g.Sum(o => Convert.ToDouble(o.Actual ?? 0))
                                })
                                .ToListAsync();
                    }
                    else if (product == "LBP")
                    {
                        result = await context.MvDailyLivePpLbps.Where(x => x.PalletDate == dt.ToString("dd-MM-yyyy")
                            /*&& x.PalletDate.StartsWith(dt.ToString("yyyy-MM-dd"))*/)
                                .GroupBy(o => new { o.Shift })
                                .Select(g => new DailyLivePPTotal
                                {
                                    Shift = g.Key.Shift == "D" ? "Dayshift" : "Nightshift",
                                    Plan = g.Sum(o => Convert.ToDouble(o.Plan ?? 0)),
                                    Actual = g.Sum(o => Convert.ToDouble(o.Actual ?? 0))
                                })
                                .ToListAsync();
                    }
                }
                else
                {
                    result = await context.HistoryVlinkageDailyLivePps.Where(x => x.PalletDate == dt.ToString("dd-MM-yyyy")
                            /*&& x.FromTime.StartsWith(dt.ToString("yyyy-MM-dd"))*/ && x.Product == product)
                                .GroupBy(o => new { o.Shift })
                                .Select(g => new DailyLivePPTotal
                                {
                                    Shift = g.Key.Shift == "D" ? "Dayshift" : "Nightshift",
                                    Plan = g.Sum(o => Convert.ToDouble(o.Plan ?? "0")),
                                    Actual = g.Sum(o => Convert.ToDouble(o.Actual ?? "0"))
                                })
                                .ToListAsync();
                }
            }
            catch (Exception)
            {

            }
            result.ForEach(x =>
            {
                x.Plan = Math.Round(x.Plan);
                x.Actual = Math.Round(x.Actual);
            });
            return result;
        }

        [HttpGet("get-monthy-live-pp-date-by-model")]
        [AllowAnonymous]
        //[ResponseCache(Duration = 28800)]
        public async Task<List<MonthyLivePPDateByModel2>> GetMonthyLivePPDateByModel(string product, string model, string date)
        {
            var dt = DateTime.Parse(date);
            var result = new List<MonthyLivePPDateByModel2>();
            try
            {
                if (this.Factory != "TS" && this.Factory != "Test")
                {
                    return result;
                }
                int month = dt.Month; int year = dt.Year;
                if (product == "LBP")
                {
                    var result1 = await context.MvDataOldPpLbps.Where(x => x.ProductCode == model && x.DateTime.EndsWith(dt.ToString("MM-yyyy")))
                            .GroupBy(o => new { o.DateTime })
                            .Select(g => new MonthyLivePPDateByModel2
                            {
                                ProductionDate = g.Key.DateTime,
                                Plan = g.Sum(o => Convert.ToDouble(o.Plan ?? 0)),
                                Actual = g.Sum(o => Convert.ToDouble(o.Actual ?? 0)),
                            })
                            .ToListAsync();
                    for (DateTime i = new DateTime(year, month, 1); i <= new DateTime(year, month + 1, 1).AddDays(-1); i = i.AddDays(1))
                    {
                        string dateDisplay = i.ToString("d-MMM");
                        string dateCalc = i.ToString("dd-MM-yyyy");
                        var hasP = result1.Where(x => x.ProductionDate == dateCalc).FirstOrDefault();
                        result.Add(new MonthyLivePPDateByModel2()
                        {
                            ProductionDate = dateDisplay,
                            Actual = hasP == null ? 0 : hasP.Actual,
                            Plan = hasP == null ? 0 : hasP.Plan,
                            DateComp = DateOnly.FromDateTime(i)
                        }); ;
                    }
                }
                else if (product == "IJ")
                {
                    var result1 = await context.MvDataOldPpIjs.Where(x => x.ProductCode == model && x.DateTime.EndsWith(dt.ToString("MM-yyyy")))
                            .GroupBy(o => new { o.DateTime })
                            .Select(g => new MonthyLivePPDateByModel2
                            {
                                ProductionDate = g.Key.DateTime,
                                Plan = g.Sum(o => Convert.ToDouble(o.Plan ?? 0)),
                                Actual = g.Sum(o => Convert.ToDouble(o.Actual ?? 0))
                            })
                            .ToListAsync();
                    for (DateTime i = new DateTime(year, month, 1); i <= new DateTime(year, month + 1, 1).AddDays(-1); i = i.AddDays(1))
                    {
                        string dateDisplay = i.ToString("d-MMM");
                        string dateCalc = i.ToString("dd-MM-yyyy");
                        var hasP = result1.Where(x => x.ProductionDate == dateCalc).FirstOrDefault();
                        result.Add(new MonthyLivePPDateByModel2()
                        {
                            ProductionDate = dateDisplay,
                            Actual = hasP == null ? 0 : hasP.Actual,
                            Plan = hasP == null ? 0 : hasP.Plan,
                            DateComp = DateOnly.FromDateTime(i)
                        });
                    }
                }
            }
            catch (Exception)
            {

            }
            return result;
        }
        //[HttpGet("get-monthy-live-pp-total")]
        //[AllowAnonymous]
        //public async Task<MonthyLivePPDateByModel> GetMonthyLivePPTotal(string product, DateTime dt)
        //{
        //    var result = new MonthyLivePPDateByModel();
        //    try
        //    {
        //        if (product == "LBP")
        //        {
        //            double plan = 0, actual = 0;
        //            var resultPlan = await context.VlinkageHksTotalPlanLbps.Where(x => x.DateTime.EndsWith(dt.ToString("MM-yyyy")))
        //                    .GroupBy(o => new { o.DateTime })
        //                    .Select(g => new MonthyLivePPDateByModel
        //                    {
        //                        ProductionDate = g.Key.DateTime,
        //                        Plan = g.Sum(o => Convert.ToDouble(o.PlanQty ?? "0")),
        //                    })
        //                    .ToListAsync();
        //            var resultActual = await context.VlinkageHksTotalActualLbps.Where(x => x.DateTime.EndsWith(dt.ToString("MM-yyyy")))
        //                    .GroupBy(o => new { o.DateTime })
        //                    .Select(g => new MonthyLivePPDateByModel
        //                    {
        //                        ProductionDate = g.Key.DateTime,
        //                        Actual = g.Sum(o => Convert.ToDouble(o.Qty ?? "0")),
        //                    })
        //                    .ToListAsync();
        //            plan += resultPlan.Select(x => x.Plan).Sum();
        //            actual += resultActual.Select(x => x.Actual).Sum();
        //            result = new MonthyLivePPDateByModel()
        //            {
        //                Actual = actual,
        //                Plan = plan,
        //                ProductionDate = dt.ToString("MMM-yyyy")
        //            };
        //        }
        //        else if (product == "IJ")
        //        {
        //            double plan = 0, actual = 0;
        //            var resultPlan = await context.VlinkageHksTotalPlanIjs.Where(x => x.DateTime.EndsWith(dt.ToString("MM-yyyy")))
        //                    .GroupBy(o => new { o.DateTime })
        //                    .Select(g => new MonthyLivePPDateByModel
        //                    {
        //                        ProductionDate = g.Key.DateTime,
        //                        Plan = g.Sum(o => Convert.ToDouble(o.PlanQty ?? "0")),
        //                    })
        //                    .ToListAsync();
        //            var resultActual = await context.VlinkageHksTotalActualIjs.Where(x => x.DateTime.EndsWith(dt.ToString("MM-yyyy")))
        //                    .GroupBy(o => new { o.DateTime })
        //                    .Select(g => new MonthyLivePPDateByModel
        //                    {
        //                        ProductionDate = g.Key.DateTime,
        //                        Actual = g.Sum(o => Convert.ToDouble(o.Qty ?? "0")),
        //                    })
        //                    .ToListAsync();
        //            plan += resultPlan.Select(x => x.Plan).Sum();
        //            actual += resultActual.Select(x => x.Actual).Sum();
        //            result = new MonthyLivePPDateByModel()
        //            {
        //                Actual = actual,
        //                Plan = plan,
        //                ProductionDate = dt.ToString("MMM-yyyy")
        //            };
        //        }
        //    }
        //    catch (Exception)
        //    {

        //    }
        //    return result;
        //}
        [HttpGet("get-monthy-live-pp-total-by-model")]
        [AllowAnonymous]
        //[ResponseCache(Duration = 28800)]
        public async Task<MonthyLivePPDateByModel> GetMonthyLivePPTotalByModel(string product, string model, string date)
        {
            var dt = DateTime.Parse(date);
            var result = new MonthyLivePPDateByModel();
            if (this.Factory != "TS" && this.Factory != "Test")
            {
                return result;
            }
            try
            {
                if (product == "LBP")
                {
                    double plan = 0, actual = 0;
                    var result1 = await context.MvDataOldPpLbps.Where(x => x.ProductCode == model && x.DateTime.EndsWith(dt.ToString("MM-yyyy")))
                            .GroupBy(o => new { o.DateTime })
                            .Select(g => new MonthyLivePPDateByModel
                            {
                                ProductionDate = g.Key.DateTime,
                                Plan = g.Sum(o => Convert.ToDouble(o.Plan ?? 0)),
                                Actual = g.Sum(o => Convert.ToDouble(o.Actual ?? 0)),
                            })
                            .ToListAsync();
                    plan += result1.Select(x => x.Plan).Sum();
                    actual += result1.Select(x => x.Actual).Sum();
                    result = new MonthyLivePPDateByModel()
                    {
                        Actual = actual,
                        Plan = plan,
                        ProductionDate = dt.ToString("MMM-yyyy")
                    };
                }
                if (product == "IJ")
                {
                    double plan = 0, actual = 0;
                    var result1 = await context.MvDataOldPpIjs.Where(x => x.ProductCode == model && x.DateTime.EndsWith(dt.ToString("MM-yyyy")))
                            .GroupBy(o => new { o.DateTime })
                            .Select(g => new MonthyLivePPDateByModel
                            {
                                ProductionDate = g.Key.DateTime,
                                Plan = g.Sum(o => Convert.ToDouble(o.Plan ?? 0)),
                                Actual = g.Sum(o => Convert.ToDouble(o.Actual ?? 0)),
                            })
                            .ToListAsync();
                    plan += result1.Select(x => x.Plan).Sum();
                    actual += result1.Select(x => x.Actual).Sum();
                    result = new MonthyLivePPDateByModel()
                    {
                        Actual = actual,
                        Plan = plan,
                        ProductionDate = dt.ToString("MMM-yyyy")
                    };
                }
            }
            catch (Exception)
            {

            }
            return result;
        }
        [HttpGet("get-monthy-live-pp-total-all-model")]
        [AllowAnonymous]
        //[ResponseCache(Duration = 28800)]
        public async Task<List<MonthyLivePPTotalByModel>> GetMonthyLivePPTotalAllModel(string product, string date)
        {
            var dt = DateTime.Parse(date);
            var result = new List<MonthyLivePPTotalByModel>();
            if (this.Factory != "TS" && this.Factory != "Test")
            {
                return result;
            }
            try
            {
                if (product == "LBP")
                {
                    double plan = 0, actual = 0;
                    var result1 = await context.MvDataOldPpLbps.Where(x => x.DateTime.EndsWith(dt.ToString("MM-yyyy")))
                            .GroupBy(o => new { o.ProductCode })
                            .Select(g => new MonthyLivePPTotalByModel
                            {
                                Model = g.Key.ProductCode,
                                Plan = g.Sum(o => Convert.ToDouble(o.Plan ?? 0)),
                                Actual = g.Sum(o => Convert.ToDouble(o.Actual ?? 0)),
                            })
                            .ToListAsync();
                    return result1;
                }
                else if (product == "IJ")
                {
                    double plan = 0, actual = 0;
                    var result1 = await context.MvDataOldPpIjs.Where(x => x.DateTime.EndsWith(dt.ToString("MM-yyyy")))
                            .GroupBy(o => new { o.ProductCode })
                            .Select(g => new MonthyLivePPTotalByModel
                            {
                                Model = g.Key.ProductCode,
                                Plan = g.Sum(o => Convert.ToDouble(o.Plan ?? 0)),
                                Actual = g.Sum(o => Convert.ToDouble(o.Actual ?? 0)),
                            })
                            .ToListAsync();
                    return result1;
                }
            }
            catch (Exception)
            {

            }
            return result;
        }

        [HttpGet("get-yearly-live-pp-month-by-model")]
        [AllowAnonymous]
        //[ResponseCache(Duration = 28800)]
        public async Task<List<MonthyLivePPDateByModel>> GetYearlyLivePPMonth(string product, string model, string date)
        {
            var dt = DateTime.Parse(date);
            var result = new List<MonthyLivePPDateByModel>();
            if (this.Factory != "TS" && this.Factory != "Test")
            {
                return result;
            }
            try
            {
                int year = dt.Year;
                if (product == "LBP")
                {
                    var result1 = await context.MvDataOldPpLbps.Where(x => x.ProductCode == model && x.DateTime.EndsWith(dt.ToString("yyyy")))
                            .GroupBy(o => new { o.DateTime })
                            .Select(g => new MonthyLivePPDateByModel
                            {
                                ProductionDate = g.Key.DateTime,
                                Plan = g.Sum(o => Convert.ToDouble(o.Plan ?? 0)),
                                Actual = g.Sum(o => Convert.ToDouble(o.Actual ?? 0)),
                            })
                            .ToListAsync();
                    for (int i = 1; i <= 12; i++)
                    {
                        var di = new DateTime(year, i, 1);
                        string monthDisplay = di.ToString("MMM");
                        string monthCalc = di.ToString("MM-yyyy");
                        var hasP = result1.Where(x => x.ProductionDate.EndsWith(monthCalc)).ToList();
                        result.Add(new MonthyLivePPDateByModel()
                        {
                            ProductionDate = monthDisplay,
                            Actual = hasP == null ? 0 : hasP.Select(x => x.Actual).Sum(),
                            Plan = hasP == null ? 0 : hasP.Select(x => x.Plan).Sum(),
                        });
                    }
                }
                else if (product == "IJ")
                {
                    var result1 = await context.MvDataOldPpIjs.Where(x => x.ProductCode == model && x.DateTime.EndsWith(dt.ToString("yyyy")))
                            .GroupBy(o => new { o.DateTime })
                            .Select(g => new MonthyLivePPDateByModel
                            {
                                ProductionDate = g.Key.DateTime,
                                Plan = g.Sum(o => Convert.ToDouble(o.Plan ?? 0)),
                                Actual = g.Sum(o => Convert.ToDouble(o.Actual ?? 0)),
                            })
                            .ToListAsync();
                    for (int i = 1; i <= 12; i++)
                    {
                        var di = new DateTime(year, i, 1);
                        string monthDisplay = di.ToString("MMM");
                        string monthCalc = di.ToString("MM-yyyy");
                        var hasP = result1.Where(x => x.ProductionDate.EndsWith(monthCalc)).ToList();
                        result.Add(new MonthyLivePPDateByModel()
                        {
                            ProductionDate = monthDisplay,
                            Actual = hasP == null ? 0 : hasP.Select(x => x.Actual).Sum(),
                            Plan = hasP == null ? 0 : hasP.Select(x => x.Plan).Sum(),
                        });
                    }
                }
            }
            catch (Exception)
            {

            }
            return result;
        }
        [HttpGet("get-yearly-live-pp-total-by-model")]
        [AllowAnonymous]
        //[ResponseCache(Duration = 28800)]
        public async Task<MonthyLivePPTotalByModel> GetYearlyLivePPTotal(string product, string model, string date)
        {
            var dt = DateTime.Parse(date);
            var result = new MonthyLivePPTotalByModel();
            if (this.Factory != "TS" && this.Factory != "Test")
            {
                return result;
            }
            try
            {
                if (product == "LBP")
                {
                    double plan = 0, actual = 0;
                    var resultP = await context.MvDataOldPpLbps.Where(x => x.ProductCode == model && x.DateTime.EndsWith(dt.ToString("yyyy")))
                            .GroupBy(o => new { o.ProductCode })
                            .Select(g => new MonthyLivePPTotalByModel
                            {
                                Model = g.Key.ProductCode,
                                Plan = g.Sum(o => Convert.ToDouble(o.Plan ?? 0)),
                                Actual = g.Sum(o => Convert.ToDouble(o.Actual ?? 0)),
                            })
                            .ToListAsync();
                    plan += resultP.Select(x => x.Plan).Sum();
                    actual += resultP.Select(x => x.Actual).Sum();
                    result = new MonthyLivePPTotalByModel()
                    {
                        Actual = actual,
                        Plan = plan,
                        Model = model
                    };
                }
                else if (product == "IJ")
                {
                    double plan = 0, actual = 0;
                    var resultP = await context.MvDataOldPpIjs.Where(x => x.ProductCode == model && x.DateTime.EndsWith(dt.ToString("yyyy")))
                            .GroupBy(o => new { o.ProductCode })
                            .Select(g => new MonthyLivePPTotalByModel
                            {
                                Model = g.Key.ProductCode,
                                Plan = g.Sum(o => Convert.ToDouble(o.Plan ?? 0)),
                                Actual = g.Sum(o => Convert.ToDouble(o.Actual ?? 0)),
                            })
                            .ToListAsync();
                    plan += resultP.Select(x => x.Plan).Sum();
                    actual += resultP.Select(x => x.Actual).Sum();
                    result = new MonthyLivePPTotalByModel()
                    {
                        Actual = actual,
                        Plan = plan,
                        Model = model
                    };
                }
            }
            catch (Exception)
            {

            }
            return result;
        }
        [HttpGet("get-yearly-live-pp-total-all-model")]
        [AllowAnonymous]
        //[ResponseCache(Duration = 28800)]
        public async Task<List<MonthyLivePPTotalByModel>> GetYearlyLivePPTotalAll(string product, string date)
        {
            var dt = DateTime.Parse(date);
            var result = new List<MonthyLivePPTotalByModel>();
            if (this.Factory != "TS" && this.Factory != "Test")
            {
                return result;
            }
            try
            {
                if (product == "LBP")
                {
                    double plan = 0, actual = 0;
                    var resultP = await context.MvDataOldPpLbps.Where(x => x.DateTime.EndsWith(dt.ToString("yyyy")))
                            .GroupBy(o => new { o.ProductCode })
                            .Select(g => new MonthyLivePPTotalByModel
                            {
                                Model = g.Key.ProductCode,
                                Plan = g.Sum(o => Convert.ToDouble(o.Plan ?? 0)),
                                Actual = g.Sum(o => Convert.ToDouble(o.Actual ?? 0)),
                            })
                            .ToListAsync();
                    return resultP;
                }
                else if (product == "IJ")
                {
                    double plan = 0, actual = 0;
                    var resultP = await context.MvDataOldPpIjs.Where(x => x.DateTime.EndsWith(dt.ToString("yyyy")))
                            .GroupBy(o => new { o.ProductCode })
                            .Select(g => new MonthyLivePPTotalByModel
                            {
                                Model = g.Key.ProductCode,
                                Plan = g.Sum(o => Convert.ToDouble(o.Plan ?? 0)),
                                Actual = g.Sum(o => Convert.ToDouble(o.Actual ?? 0)),
                            })
                            .ToListAsync();
                    return resultP;
                }

            }
            catch (Exception)
            {

            }
            return result;
        }

        [HttpGet("get-list-model-by-product")]
        [AllowAnonymous]
        //[ResponseCache(Duration = 28800)]
        public async Task<List<string>> GetListModelByProduct(string product)
        {
            var result = new List<string>();
            if (this.Factory != "TS" && this.Factory != "Test")
            {
                return result;
            }
            try
            {
                if (product == "LBP")
                {
                    var md = await context.MvDataOldPpLbps
                        .Select(x => x.ProductCode).Distinct().ToListAsync();
                    return md.OrderBy(x => x).ToList();
                }
                else if (product == "IJ")
                {
                    var md = await context.MvDataOldPpIjs
                        .Select(x => x.ProductCode).Distinct().ToListAsync();
                    return md.OrderBy(x => x).ToList();
                }
            }
            catch (Exception)
            {

            }
            return result;
        }

        [HttpGet("get-list-model-by-product-daily")]
        [AllowAnonymous]
        //[ResponseCache(Duration = 28800)]
        public async Task<List<string>> GetListModelByProductDaily(string product, string date)
        {
            var result = new List<string>();
            var dt = DateTime.Parse(date);
            var dt1 = DateTime.Now;
            if (this.Factory != "TS" && this.Factory != "Test")
            {
                return result;
            }
            try
            {
                if (dt.Date == dt1.Date)
                {
                    if (product == "LBP")
                    {
                        var md = await context.VlinkageHksLivePpLbps
                            .Select(x => x.ProductCode).Distinct().ToListAsync();
                        return md.OrderBy(x => x).ToList();
                    }
                    else if (product == "IJ")
                    {
                        var md = await context.VlinkageHksLivePpIjs
                            .Select(x => x.ProductCode).Distinct().ToListAsync();
                        return md.OrderBy(x => x).ToList();
                    }
                }
                else
                {
                    if (product == "LBP")
                    {
                        var md = await context.HistoryVlinkageDailyLivePps.Where(x => x.Product.ToUpper() == "LBP" && x.PalletDate == dt.ToString("dd-MM-yyyy"))
                          .Select(x => x.Model).Distinct().ToListAsync();
                        return md.OrderBy(x => x).ToList();
                    }
                    else if (product == "IJ")
                    {
                        var md = await context.HistoryVlinkageDailyLivePps.Where(x => x.Product.ToUpper() == "IJ" && x.PalletDate == dt.ToString("dd-MM-yyyy"))
                          .Select(x => x.Model).Distinct().ToListAsync();
                        return md.OrderBy(x => x).ToList();
                    }

                }

            }
            catch (Exception)
            {

            }
            return result;
        }




        [HttpGet("get-data-chart-sumup-shift-by-vendor")]
        [AllowAnonymous]
        //[ResponseCache(Duration = 28800)]
        public async Task<List<ChartFcdelByTypeByGroupByDate>> GetDataChartSumupShiftByVendorFC1(string product, string dateF, string dateT)
        {
            var result = new List<ChartFcdelByTypeByGroupByDate>();
            var dt1 = DateTime.Parse(dateF);
            var dt2 = DateTime.Parse(dateT);
            var dF = DateOnly.FromDateTime(new DateTime(Math.Min(dt1.Ticks, dt2.Ticks)));
            var dT = DateOnly.FromDateTime(new DateTime(Math.Max(dt1.Ticks, dt2.Ticks)));
            try
            {
                var lstModel = new List<TodFcdelOutputSumupVendorIj>();
                var config = new MapperConfiguration(cfg => cfg.CreateMap<TodFcdelOutputSumupVendorLbp, TodFcdelOutputSumupVendorIj>());
                var mapper = config.CreateMapper();
                if (product.Equals("IJ") || product.Equals("ALL"))
                {
                    lstModel.AddRange(await context.TodFcdelOutputSumupVendorIjs.Where(x => x.Active == true).OrderBy(x => x.VendorCode).ToListAsync());
                }
                if (product.Equals("LBP") || product.Equals("ALL"))
                {
                    var lstModel1 = await context.TodFcdelOutputSumupVendorLbps.Where(x => x.Active == true).OrderBy(x => x.VendorCode).ToListAsync();
                    lstModel.AddRange(mapper.Map<List<TodFcdelOutputSumupVendorLbp>, List<TodFcdelOutputSumupVendorIj>>(lstModel1));
                }
                var dateRangeResult = new List<string>();
                for (var iD = dF; iD <= dT; iD = iD.AddDays(1))
                {
                    dateRangeResult.Add(iD.ToString("d-MMM"));
                }
                dateRangeResult = dateRangeResult.Distinct().ToList();
                foreach (var vd in lstModel)
                {
                    var vendor = vd.VendorCode;
                    var rangeD = dateRangeResult;
                    var lstValueD = new List<double>();
                    var lstValueN = new List<double>();
                    Dictionary<DateOnly, double> dicShiftDay = new Dictionary<DateOnly, double>();
                    Dictionary<DateOnly, double> dicShiftNight = new Dictionary<DateOnly, double>();
                    if (vd.SumupValueDayByShift != null && vd.SumupValueDayByShift.Length > 0)
                    {
                        for (int i = 0; i < vd.SumupDate.Length; i++)
                        {
                            dicShiftDay.Add(vd.SumupDate[i], vd.SumupValueDayByShift[i]);
                        }
                    }
                    if (vd.SumupValueNightByShift != null && vd.SumupValueNightByShift.Length > 0)
                    {
                        for (int i = 0; i < vd.SumupDate.Length; i++)
                        {
                            dicShiftNight.Add(vd.SumupDate[i], vd.SumupValueNightByShift[i]);
                        }
                    }
                    for (var iD = dF; iD <= dT; iD = iD.AddDays(1))
                    {
                        double itemValD = 0;
                        double itemValN = 0;
                        try
                        {
                            itemValD += dicShiftDay[iD];
                        }
                        catch (Exception)
                        {

                        }
                        try
                        {
                            itemValN += dicShiftNight[iD];
                        }
                        catch (Exception)
                        {

                        }
                        itemValD = Math.Round(itemValD);
                        itemValN = Math.Round(itemValN);
                        lstValueD.Add(itemValD);
                        lstValueN.Add(itemValN);
                    }
                    Random rnd = new Random();
                    var cl = "rgb(" + rnd.Next(256) + ", " + rnd.Next(256) + ", " + rnd.Next(256) + ")";
                    if (!lstValueD.All(x => x == 0))
                    {
                        result.Add(new ChartFcdelByTypeByGroupByDate()
                        {
                            Days = dateRangeResult.ToArray(),
                            Label = "D - " + vendor ?? "",
                            Stack = "D",
                            Value = lstValueD.ToArray(),
                            BackgroundColor = cl
                        });
                    }
                    if (!lstValueN.All(x => x == 0))
                    {
                        result.Add(new ChartFcdelByTypeByGroupByDate()
                        {
                            Days = dateRangeResult.ToArray(),
                            Label = "N - " + vendor ?? "",
                            Stack = "N",
                            Value = lstValueN.ToArray(),
                            BackgroundColor = cl
                        });
                    }
                }
            }
            catch (Exception)
            {

            }
            return result;
        }

        [HttpGet("get-data-chart-sumup-lot-by-vendor")]
        [AllowAnonymous]
        //[ResponseCache(Duration = 28800)]
        public async Task<List<ChartFcdelByTypeByGroupByDate>> GetDataChartSumupLotByVendorFC1(string product, string dateF, string dateT)
        {
            var result = new List<ChartFcdelByTypeByGroupByDate>();
            var dt1 = DateTime.Parse(dateF);
            var dt2 = DateTime.Parse(dateT);
            var dF = DateOnly.FromDateTime(new DateTime(Math.Min(dt1.Ticks, dt2.Ticks)));
            var dT = DateOnly.FromDateTime(new DateTime(Math.Max(dt1.Ticks, dt2.Ticks)));
            try
            {
                var lstModel = new List<TodFcdelOutputSumupVendorIj>();
                var config = new MapperConfiguration(cfg => cfg.CreateMap<TodFcdelOutputSumupVendorLbp, TodFcdelOutputSumupVendorIj>());
                var mapper = config.CreateMapper();
                if (product.Equals("IJ") || product.Equals("ALL"))
                {
                    lstModel.AddRange(await context.TodFcdelOutputSumupVendorIjs.Where(x => x.Active == true).OrderBy(x => x.VendorCode).ToListAsync());
                }
                if (product.Equals("LBP") || product.Equals("ALL"))
                {
                    var lstModel1 = await context.TodFcdelOutputSumupVendorLbps.Where(x => x.Active == true).OrderBy(x => x.VendorCode).ToListAsync();
                    lstModel.AddRange(mapper.Map<List<TodFcdelOutputSumupVendorLbp>, List<TodFcdelOutputSumupVendorIj>>(lstModel1));
                }
                var dateRangeResult = new List<string>();
                for (var iD = dF; iD <= dT; iD = iD.AddDays(1))
                {
                    dateRangeResult.Add(iD.ToString("d-MMM"));
                }
                foreach (var vd in lstModel)
                {
                    var vendor = vd.VendorCode;
                    var rangeD = dateRangeResult;
                    var lstValueD = new List<double>();
                    var lstValueN = new List<double>();
                    Dictionary<DateOnly, double> dicShiftDay = new Dictionary<DateOnly, double>();
                    Dictionary<DateOnly, double> dicShiftNight = new Dictionary<DateOnly, double>();
                    if (vd.SumupValueDayByLot != null && vd.SumupValueDayByLot.Length > 0)
                    {
                        for (int i = 0; i < vd.SumupDate.Length; i++)
                        {
                            dicShiftDay.Add(vd.SumupDate[i], vd.SumupValueDayByLot[i]);
                        }
                    }
                    if (vd.SumupValueNightByLot != null && vd.SumupValueNightByLot.Length > 0)
                    {
                        for (int i = 0; i < vd.SumupDate.Length; i++)
                        {
                            dicShiftNight.Add(vd.SumupDate[i], vd.SumupValueNightByLot[i]);
                        }
                    }
                    for (var iD = dF; iD <= dT; iD = iD.AddDays(1))
                    {
                        double itemValD = 0;
                        double itemValN = 0;
                        try
                        {
                            itemValD += dicShiftDay[iD];
                        }
                        catch (Exception)
                        {

                        }
                        try
                        {
                            itemValN += dicShiftNight[iD];
                        }
                        catch (Exception)
                        {

                        }
                        itemValD = Math.Round(itemValD);
                        itemValN = Math.Round(itemValN);
                        lstValueD.Add(itemValD);
                        lstValueN.Add(itemValN);
                    }
                    Random rnd = new Random();
                    var cl = "rgb(" + rnd.Next(256) + ", " + rnd.Next(256) + ", " + rnd.Next(256) + ")";
                    if (!lstValueD.All(x => x == 0))
                    {
                        result.Add(new ChartFcdelByTypeByGroupByDate()
                        {
                            Days = dateRangeResult.ToArray(),
                            Label = "D - " + vendor ?? "",
                            Stack = "D",
                            Value = lstValueD.ToArray(),
                            BackgroundColor = cl
                        });
                    }
                    if (!lstValueN.All(x => x == 0))
                    {
                        result.Add(new ChartFcdelByTypeByGroupByDate()
                        {
                            Days = dateRangeResult.ToArray(),
                            Label = "N - " + vendor ?? "",
                            Stack = "N",
                            Value = lstValueN.ToArray(),
                            BackgroundColor = cl
                        });
                    }
                }
            }
            catch (Exception)
            {

            }
            return result;
        }



        [HttpGet("get-data-chart-sumup-shift-by-route")]
        [AllowAnonymous]
        //[ResponseCache(Duration = 28800)]
        public async Task<List<ChartFcdelByTypeByGroupByDate>> GetDataChartSumupShiftByRouteFC1(string product, string dateF, string dateT)
        {
            var result = new List<ChartFcdelByTypeByGroupByDate>();
            var dt1 = DateTime.Parse(dateF);
            var dt2 = DateTime.Parse(dateT);
            var dF = DateOnly.FromDateTime(new DateTime(Math.Min(dt1.Ticks, dt2.Ticks)));
            var dT = DateOnly.FromDateTime(new DateTime(Math.Max(dt1.Ticks, dt2.Ticks)));
            try
            {
                var lstModel = new List<TodFcdelOutputSumupRouteIj>();
                var config = new MapperConfiguration(cfg => cfg.CreateMap<TodFcdelOutputSumupRouteLbp, TodFcdelOutputSumupRouteIj>());
                var mapper = config.CreateMapper();
                if (product.Equals("IJ") || product.Equals("ALL"))
                {
                    lstModel.AddRange(await context.TodFcdelOutputSumupRouteIjs.Where(x => x.Active == true).OrderBy(x => x.DeliveryRoute).ToListAsync());
                }
                if (product.Equals("LBP") || product.Equals("ALL"))
                {
                    var lstModel1 = await context.TodFcdelOutputSumupRouteLbps.Where(x => x.Active == true).OrderBy(x => x.DeliveryRoute).ToListAsync();
                    lstModel.AddRange(mapper.Map<List<TodFcdelOutputSumupRouteLbp>, List<TodFcdelOutputSumupRouteIj>>(lstModel1));
                }
                var dateRangeResult = new List<string>();
                for (var iD = dF; iD <= dT; iD = iD.AddDays(1))
                {
                    dateRangeResult.Add(iD.ToString("d-MMM"));
                }
                foreach (var vd in lstModel)
                {
                    var vendor = vd.DeliveryRoute;
                    var rangeD = dateRangeResult;
                    var lstValueD = new List<double>();
                    var lstValueN = new List<double>();
                    Dictionary<DateOnly, double> dicShiftDay = new Dictionary<DateOnly, double>();
                    Dictionary<DateOnly, double> dicShiftNight = new Dictionary<DateOnly, double>();
                    if (vd.SumupValueDayByShift != null && vd.SumupValueDayByShift.Length > 0)
                    {
                        for (int i = 0; i < vd.SumupDate.Length; i++)
                        {
                            dicShiftDay.Add(vd.SumupDate[i], vd.SumupValueDayByShift[i]);
                        }
                    }
                    if (vd.SumupValueNightByShift != null && vd.SumupValueNightByShift.Length > 0)
                    {
                        for (int i = 0; i < vd.SumupDate.Length; i++)
                        {
                            dicShiftNight.Add(vd.SumupDate[i], vd.SumupValueNightByShift[i]);
                        }
                    }
                    for (var iD = dF; iD <= dT; iD = iD.AddDays(1))
                    {
                        double itemValD = 0;
                        double itemValN = 0;
                        try
                        {
                            itemValD += dicShiftDay[iD];
                        }
                        catch (Exception)
                        {

                        }
                        try
                        {
                            itemValN += dicShiftNight[iD];
                        }
                        catch (Exception)
                        {

                        }
                        itemValD = Math.Round(itemValD);
                        itemValN = Math.Round(itemValN);
                        lstValueD.Add(itemValD);
                        lstValueN.Add(itemValN);
                    }
                    Random rnd = new Random();
                    var cl = "rgb(" + rnd.Next(256) + ", " + rnd.Next(256) + ", " + rnd.Next(256) + ")";
                    if (!lstValueD.All(x => x == 0))
                    {
                        result.Add(new ChartFcdelByTypeByGroupByDate()
                        {
                            Days = dateRangeResult.ToArray(),
                            Label = "D - " + vendor ?? "",
                            Stack = "D",
                            Value = lstValueD.ToArray(),
                            BackgroundColor = cl
                        });
                    }
                    if (!lstValueN.All(x => x == 0))
                    {
                        result.Add(new ChartFcdelByTypeByGroupByDate()
                        {
                            Days = dateRangeResult.ToArray(),
                            Label = "N - " + vendor ?? "",
                            Stack = "N",
                            Value = lstValueN.ToArray(),
                            BackgroundColor = cl
                        });
                    }
                }
            }
            catch (Exception)
            {

            }
            return result;
        }


        [HttpGet("get-data-chart-sumup-lot-by-route")]
        [AllowAnonymous]
        //[ResponseCache(Duration = 28800)]
        public async Task<List<ChartFcdelByTypeByGroupByDate>> GetDataChartSumupLotByRouteFC1(string product, string dateF, string dateT)
        {
            var result = new List<ChartFcdelByTypeByGroupByDate>();
            var dt1 = DateTime.Parse(dateF);
            var dt2 = DateTime.Parse(dateT);
            var dF = DateOnly.FromDateTime(new DateTime(Math.Min(dt1.Ticks, dt2.Ticks)));
            var dT = DateOnly.FromDateTime(new DateTime(Math.Max(dt1.Ticks, dt2.Ticks)));
            try
            {
                var lstModel = new List<TodFcdelOutputSumupRouteIj>();
                var config = new MapperConfiguration(cfg => cfg.CreateMap<TodFcdelOutputSumupRouteLbp, TodFcdelOutputSumupRouteIj>());
                var mapper = config.CreateMapper();
                if (product.Equals("IJ") || product.Equals("ALL"))
                {
                    lstModel.AddRange(await context.TodFcdelOutputSumupRouteIjs.Where(x => x.Active == true).OrderBy(x => x.DeliveryRoute).ToListAsync());
                }
                if (product.Equals("LBP") || product.Equals("ALL"))
                {
                    var lstModel1 = await context.TodFcdelOutputSumupRouteLbps.Where(x => x.Active == true).OrderBy(x => x.DeliveryRoute).ToListAsync();
                    lstModel.AddRange(mapper.Map<List<TodFcdelOutputSumupRouteLbp>, List<TodFcdelOutputSumupRouteIj>>(lstModel1));
                }
                var dateRangeResult = new List<string>();
                for (var iD = dF; iD <= dT; iD = iD.AddDays(1))
                {
                    dateRangeResult.Add(iD.ToString("d-MMM"));
                }
                foreach (var vd in lstModel)
                {
                    var vendor = vd.DeliveryRoute;
                    var rangeD = dateRangeResult;
                    var lstValueD = new List<double>();
                    var lstValueN = new List<double>();
                    Dictionary<DateOnly, double> dicShiftDay = new Dictionary<DateOnly, double>();
                    Dictionary<DateOnly, double> dicShiftNight = new Dictionary<DateOnly, double>();
                    if (vd.SumupValueDayByLot != null && vd.SumupValueDayByLot.Length > 0)
                    {
                        for (int i = 0; i < vd.SumupDate.Length; i++)
                        {
                            dicShiftDay.Add(vd.SumupDate[i], vd.SumupValueDayByLot[i]);
                        }
                    }
                    if (vd.SumupValueNightByLot != null && vd.SumupValueNightByLot.Length > 0)
                    {
                        for (int i = 0; i < vd.SumupDate.Length; i++)
                        {
                            dicShiftNight.Add(vd.SumupDate[i], vd.SumupValueNightByLot[i]);
                        }
                    }
                    for (var iD = dF; iD <= dT; iD = iD.AddDays(1))
                    {
                        double itemValD = 0;
                        double itemValN = 0;
                        try
                        {
                            itemValD += dicShiftDay[iD];
                        }
                        catch (Exception)
                        {

                        }
                        try
                        {
                            itemValN += dicShiftNight[iD];
                        }
                        catch (Exception)
                        {

                        }
                        itemValD = Math.Round(itemValD);
                        itemValN = Math.Round(itemValN);
                        lstValueD.Add(itemValD);
                        lstValueN.Add(itemValN);
                    }
                    Random rnd = new Random();
                    var cl = "rgb(" + rnd.Next(256) + ", " + rnd.Next(256) + ", " + rnd.Next(256) + ")";
                    if (!lstValueD.All(x => x == 0))
                    {
                        result.Add(new ChartFcdelByTypeByGroupByDate()
                        {
                            Days = dateRangeResult.ToArray(),
                            Label = "D - " + vendor ?? "",
                            Stack = "D",
                            Value = lstValueD.ToArray(),
                            BackgroundColor = cl
                        });
                    }
                    if (!lstValueN.All(x => x == 0))
                    {
                        result.Add(new ChartFcdelByTypeByGroupByDate()
                        {
                            Days = dateRangeResult.ToArray(),
                            Label = "N - " + vendor ?? "",
                            Stack = "N",
                            Value = lstValueN.ToArray(),
                            BackgroundColor = cl
                        });
                    }
                }
            }
            catch (Exception)
            {

            }
            return result;
        }




        [HttpGet("get-data-chart-sumup-shift-by-location")]
        [AllowAnonymous]
       // [ResponseCache(Duration = 28800)]
        public async Task<List<ChartFcdelByTypeByGroupByDate>> GetDataChartSumupShiftByLocationFC1(string product, string dateF, string dateT)
        {
            var result = new List<ChartFcdelByTypeByGroupByDate>();
            var dt1 = DateTime.Parse(dateF);
            var dt2 = DateTime.Parse(dateT);
            var dF = DateOnly.FromDateTime(new DateTime(Math.Min(dt1.Ticks, dt2.Ticks)));
            var dT = DateOnly.FromDateTime(new DateTime(Math.Max(dt1.Ticks, dt2.Ticks)));
            try
            {
                var lstModel = new List<TodFcdelOutputSumupLocationIj>();
                var config = new MapperConfiguration(cfg => cfg.CreateMap<TodFcdelOutputSumupLocationLbp, TodFcdelOutputSumupLocationIj>());
                var mapper = config.CreateMapper();
                if (product.Equals("IJ") || product.Equals("ALL"))
                {
                    lstModel.AddRange(await context.TodFcdelOutputSumupLocationIjs.Where(x => x.Active == true).OrderBy(x => x.Location).ToListAsync());
                }
                if (product.Equals("LBP") || product.Equals("ALL"))
                {
                    var lstModel1 = await context.TodFcdelOutputSumupLocationLbps.Where(x => x.Active == true).OrderBy(x => x.Location).ToListAsync();
                    lstModel.AddRange(mapper.Map<List<TodFcdelOutputSumupLocationLbp>, List<TodFcdelOutputSumupLocationIj>>(lstModel1));
                }
                var dateRangeResult = new List<string>();
                for (var iD = dF; iD <= dT; iD = iD.AddDays(1))
                {
                    dateRangeResult.Add(iD.ToString("d-MMM"));
                }
                foreach (var vd in lstModel)
                {
                    var vendor = vd.Location;
                    var rangeD = dateRangeResult;
                    var lstValueD = new List<double>();
                    var lstValueN = new List<double>();
                    Dictionary<DateOnly, double> dicShiftDay = new Dictionary<DateOnly, double>();
                    Dictionary<DateOnly, double> dicShiftNight = new Dictionary<DateOnly, double>();
                    if (vd.SumupValueDayByShift != null && vd.SumupValueDayByShift.Length > 0)
                    {
                        for (int i = 0; i < vd.SumupDate.Length; i++)
                        {
                            dicShiftDay.Add(vd.SumupDate[i], vd.SumupValueDayByShift[i]);
                        }
                    }
                    if (vd.SumupValueNightByShift != null && vd.SumupValueNightByShift.Length > 0)
                    {
                        for (int i = 0; i < vd.SumupDate.Length; i++)
                        {
                            dicShiftNight.Add(vd.SumupDate[i], vd.SumupValueNightByShift[i]);
                        }
                    }
                    for (var iD = dF; iD <= dT; iD = iD.AddDays(1))
                    {
                        double itemValD = 0;
                        double itemValN = 0;
                        try
                        {
                            itemValD += dicShiftDay[iD];
                        }
                        catch (Exception)
                        {

                        }
                        try
                        {
                            itemValN += dicShiftNight[iD];
                        }
                        catch (Exception)
                        {

                        }
                        itemValD = Math.Round(itemValD);
                        itemValN = Math.Round(itemValN);
                        lstValueD.Add(itemValD);
                        lstValueN.Add(itemValN);
                    }
                    Random rnd = new Random();
                    var cl = "rgb(" + rnd.Next(256) + ", " + rnd.Next(256) + ", " + rnd.Next(256) + ")";
                    if (!lstValueD.All(x => x == 0))
                    {
                        result.Add(new ChartFcdelByTypeByGroupByDate()
                        {
                            Days = dateRangeResult.ToArray(),
                            Label = "D - " + vendor ?? "(blank)",
                            Stack = "D",
                            Value = lstValueD.ToArray(),
                            BackgroundColor = cl
                        });
                    }
                    if (!lstValueN.All(x => x == 0))
                    {
                        result.Add(new ChartFcdelByTypeByGroupByDate()
                        {
                            Days = dateRangeResult.ToArray(),
                            Label = "N - " + vendor ?? "(blank)",
                            Stack = "N",
                            Value = lstValueN.ToArray(),
                            BackgroundColor = cl
                        });
                    }
                }
            }
            catch (Exception)
            {

            }
            return result;
        }



        [HttpGet("get-data-chart-sumup-lot-by-location")]
        [AllowAnonymous]
        //[ResponseCache(Duration = 28800)]
        public async Task<List<ChartFcdelByTypeByGroupByDate>> GetDataChartSumupLotByLocationFC1(string product, string dateF, string dateT)
        {
            var result = new List<ChartFcdelByTypeByGroupByDate>();
            var dt1 = DateTime.Parse(dateF);
            var dt2 = DateTime.Parse(dateT);
            var dF = DateOnly.FromDateTime(new DateTime(Math.Min(dt1.Ticks, dt2.Ticks)));
            var dT = DateOnly.FromDateTime(new DateTime(Math.Max(dt1.Ticks, dt2.Ticks)));
            try
            {
                var lstModel = new List<TodFcdelOutputSumupLocationIj>();
                var config = new MapperConfiguration(cfg => cfg.CreateMap<TodFcdelOutputSumupLocationLbp, TodFcdelOutputSumupLocationIj>());
                var mapper = config.CreateMapper();
                if (product.Equals("IJ") || product.Equals("ALL"))
                {
                    lstModel.AddRange(await context.TodFcdelOutputSumupLocationIjs.Where(x => x.Active == true).OrderBy(x => x.Location).ToListAsync());
                }
                if (product.Equals("LBP") || product.Equals("ALL"))
                {
                    var lstModel1 = await context.TodFcdelOutputSumupLocationLbps.Where(x => x.Active == true).OrderBy(x => x.Location).ToListAsync();
                    lstModel.AddRange(mapper.Map<List<TodFcdelOutputSumupLocationLbp>, List<TodFcdelOutputSumupLocationIj>>(lstModel1));
                }
                var dateRangeResult = new List<string>();
                for (var iD = dF; iD <= dT; iD = iD.AddDays(1))
                {
                    dateRangeResult.Add(iD.ToString("d-MMM"));
                }
                foreach (var vd in lstModel)
                {
                    var vendor = vd.Location;
                    var rangeD = dateRangeResult;
                    var lstValueD = new List<double>();
                    var lstValueN = new List<double>();
                    Dictionary<DateOnly, double> dicShiftDay = new Dictionary<DateOnly, double>();
                    Dictionary<DateOnly, double> dicShiftNight = new Dictionary<DateOnly, double>();
                    if (vd.SumupValueDayByLot != null && vd.SumupValueDayByLot.Length > 0)
                    {
                        for (int i = 0; i < vd.SumupDate.Length; i++)
                        {
                            dicShiftDay.Add(vd.SumupDate[i], vd.SumupValueDayByLot[i]);
                        }
                    }
                    if (vd.SumupValueNightByLot != null && vd.SumupValueNightByLot.Length > 0)
                    {
                        for (int i = 0; i < vd.SumupDate.Length; i++)
                        {
                            dicShiftNight.Add(vd.SumupDate[i], vd.SumupValueNightByLot[i]);
                        }
                    }
                    for (var iD = dF; iD <= dT; iD = iD.AddDays(1))
                    {
                        double itemValD = 0;
                        double itemValN = 0;
                        try
                        {
                            itemValD += dicShiftDay[iD];
                        }
                        catch (Exception)
                        {

                        }
                        try
                        {
                            itemValN += dicShiftNight[iD];
                        }
                        catch (Exception)
                        {

                        }
                        itemValD = Math.Round(itemValD);
                        itemValN = Math.Round(itemValN);
                        lstValueD.Add(itemValD);
                        lstValueN.Add(itemValN);
                    }
                    Random rnd = new Random();
                    var cl = "rgb(" + rnd.Next(256) + ", " + rnd.Next(256) + ", " + rnd.Next(256) + ")";
                    if (!lstValueD.All(x => x == 0))
                    {
                        result.Add(new ChartFcdelByTypeByGroupByDate()
                        {
                            Days = dateRangeResult.ToArray(),
                            Label = "D - " + vendor ?? "(blank)",
                            Stack = "D",
                            Value = lstValueD.ToArray(),
                            BackgroundColor = cl
                        });
                    }
                    if (!lstValueN.All(x => x == 0))
                    {
                        result.Add(new ChartFcdelByTypeByGroupByDate()
                        {
                            Days = dateRangeResult.ToArray(),
                            Label = "N - " + vendor ?? "(blank)",
                            Stack = "N",
                            Value = lstValueN.ToArray(),
                            BackgroundColor = cl
                        });
                    }
                }
            }
            catch (Exception)
            {

            }
            return result;
        }


        [HttpGet("get-data-chart-sumup-type-by-group-by-date")]
        [AllowAnonymous]
        //[ResponseCache(Duration = 28800)]
        public async Task<List<ChartFcdelByTypeByGroupBy>> GetDataChartSumupTypeByGroupByDate(string type, string group, string product, string dateF, string dateT)
        {
            return await GetChartSumupData(type, group, product, dateF, dateT);
        }
        [HttpGet("get-data-chart-sumup-type-by-group-by-month")]
        [AllowAnonymous]
        //[ResponseCache(Duration = 28800)]
        public async Task<List<ChartFcdelByTypeByGroupBy>> GetDataChartSumupTypeByGroupByMonth(string type, string group, string product, string dateF, string dateT)
        {
            return await GetChartSumupDataMonth(type, group, product, dateF, dateT);
        }
        [HttpGet("get-data-chart-sumup-type-by-group-by-year")]
        [AllowAnonymous]
        //[ResponseCache(Duration = 28800)]
        public async Task<List<ChartFcdelByTypeByGroupBy>> GetDataChartSumupTypeByGroupByYear(string type, string group, string product, string dateF, string dateT)
        {
            Console.WriteLine("bat dau: " + DateTime.Now);
            var lstModel = await GetChartSumupDataMonth(type, group, product, dateF, dateT);
            var total = new ChartFcdelByTypeByGroupBy
            {
                BackgroundColor = lstModel[0].BackgroundColor,
                Label = "Total",
                Stack = "true",
                Days = lstModel[0].Days,
                Value = lstModel.Aggregate(new double[lstModel[0].Value.Length], (acc, item) =>
                {
                    for (int i = 0; i < item.Value.Length; i++)
                    {
                        acc[i] += item.Value[i];
                    }
                    return acc;
                })
            };
            var distinctYear = total.StrYears.Distinct().Select(x => Convert.ToInt32(x)).OrderBy(x => x).ToList();
            var lstResult = new List<ChartFcdelByTypeByGroupBy>();
            Dictionary<string, (double, DateOnly)> dic = new Dictionary<string, (double, DateOnly)>();
            for (int i = 0; i < total.Value.Length; i++)
            {
                dic.Add(total.StrMonths[i], (total.Value[i], total.Days[i]));
            }
            foreach (var item in distinctYear)
            {
                List<double> lstValueItem0 = new List<double>();
                List<DateOnly> lstDayItem0 = new List<DateOnly>();
                for (int i = 1; i <= 12; i++)
                {
                    var dt = new DateTime(item, i, 1);
                    var strMonthYear = dt.ToString("MMM-yy");
                    if (dic.ContainsKey(strMonthYear))
                    {
                        lstValueItem0.Add(dic[strMonthYear].Item1);
                        lstDayItem0.Add(dic[strMonthYear].Item2);
                    }
                    else
                    {
                        lstValueItem0.Add(0);
                        lstDayItem0.Add(DateOnly.FromDateTime(dt));
                    }
                    
                }
                Random rnd = new Random();
                var cl = "rgb(" + rnd.Next(256) + ", " + rnd.Next(256) + ", " + rnd.Next(256) + ")";
                var result0 = new ChartFcdelByTypeByGroupBy()
                {
                    BackgroundColor = cl,
                    Days = lstDayItem0.ToArray(),
                    Value = lstValueItem0.ToArray(),
                    Label = item.ToString(),
                    Stack = item == DateTime.Now.Year ? "true": "false"
                };
                lstResult.Add(result0);
            }
            Console.WriteLine("ket thuc: " + DateTime.Now);
            return lstResult;
        }


        private async Task<List<ChartFcdelByTypeByGroupBy>> GetChartSumupData(string type, string group, string product, string dateF, string dateT)
        {
            var result = new List<ChartFcdelByTypeByGroupBy>();
            var dt1 = DateTime.Parse(dateF);
            var dt2 = DateTime.Parse(dateT);
            var dF = DateOnly.FromDateTime(new DateTime(Math.Min(dt1.Ticks, dt2.Ticks)));
            var dT = DateOnly.FromDateTime(new DateTime(Math.Max(dt1.Ticks, dt2.Ticks)));
            Dictionary<string, string> dicColor = new Dictionary<string, string>();
            var query = context.TodStructureMasterDeliveries.Where(x => x.Active == true && x.ApprovedBy != null && x.ApprovedDate != null);
            var lstDelivery = new List<TodStructureMasterDelivery>();
            if (group == "location")
            {
                lstDelivery = await query.Where(x => x.Location1 != null && x.LocationColor != null && x.LocationColor != "").ToListAsync();
                foreach (var item in lstDelivery)
                {
                    try
                    {
                        if (!dicColor.ContainsKey(item.Location1))
                        {
                            dicColor.Add(item.Location1, item.LocationColor);
                        }
                        
                    }
                    catch (Exception)
                    {

                    }

                }
            }
            else if (group == "vendor")
            {
                lstDelivery = await query.Where(x => x.VendorCode != null && x.VendorColor != null && x.VendorColor != "").ToListAsync();
                foreach (var item in lstDelivery)
                {
                    try
                    {
                        if (!dicColor.ContainsKey(item.VendorCode))
                        {
                            dicColor.Add(item.VendorCode, item.VendorColor);
                        }
                        
                    }
                    catch (Exception)
                    {

                    }

                }
            }
            else if (group == "route")
            {
                lstDelivery = await query.Where(x => x.RouteDelivery != null && x.RouteColor != null && x.RouteColor != "").ToListAsync();
                foreach (var item in lstDelivery)
                {
                    try
                    {
                        if (!dicColor.ContainsKey(item.RouteDelivery))
                        {
                            dicColor.Add(item.RouteDelivery, item.RouteColor);
                        }
                    }
                    catch (Exception)
                    {

                    }

                }
            }
            try
            {
                var lstModel = new List<TodFcdelOutputSumupLocationIj>();
                if ((product.Equals("IJ") || product.Equals("ALL")) && group == "location")
                {
                    lstModel.AddRange(await context.TodFcdelOutputSumupLocationIjs.Where(x => x.Active == true).OrderBy(x => x.Location).ToListAsync());
                }
                else if ((product.Equals("LBP") || product.Equals("ALL")) && group == "location")
                {
                    var config = new MapperConfiguration(cfg => cfg.CreateMap<TodFcdelOutputSumupLocationLbp, TodFcdelOutputSumupLocationIj>());
                    var mapper = config.CreateMapper();
                    var lstModel1 = await context.TodFcdelOutputSumupLocationLbps.Where(x => x.Active == true).OrderBy(x => x.Location).ToListAsync();
                    lstModel.AddRange(mapper.Map<List<TodFcdelOutputSumupLocationLbp>, List<TodFcdelOutputSumupLocationIj>>(lstModel1));
                }
                else if ((product.Equals("LBP") || product.Equals("ALL")) && group == "vendor")
                {
                    var config = new MapperConfiguration(cfg => cfg.CreateMap<TodFcdelOutputSumupVendorLbp, TodFcdelOutputSumupLocationIj>().ForMember(x => x.Location, opt => opt.MapFrom(o => o.VendorCode)));
                    var mapper = config.CreateMapper();
                    var lstModel1 = await context.TodFcdelOutputSumupVendorLbps.Where(x => x.Active == true).OrderBy(x => x.VendorCode).ToListAsync();
                    lstModel.AddRange(mapper.Map<List<TodFcdelOutputSumupVendorLbp>, List<TodFcdelOutputSumupLocationIj>>(lstModel1));
                }
                else if ((product.Equals("IJ") || product.Equals("ALL")) && group == "vendor")
                {
                    var config = new MapperConfiguration(cfg => cfg.CreateMap<TodFcdelOutputSumupVendorIj, TodFcdelOutputSumupLocationIj>().ForMember(x => x.Location, opt => opt.MapFrom(o => o.VendorCode)));
                    var mapper = config.CreateMapper();
                    var lstModel1 = await context.TodFcdelOutputSumupVendorIjs.Where(x => x.Active == true).OrderBy(x => x.VendorCode).ToListAsync();
                    lstModel.AddRange(mapper.Map<List<TodFcdelOutputSumupVendorIj>, List<TodFcdelOutputSumupLocationIj>>(lstModel1));
                }
                else if ((product.Equals("IJ") || product.Equals("ALL")) && group == "route")
                {
                    var config = new MapperConfiguration(cfg => cfg.CreateMap<TodFcdelOutputSumupRouteIj, TodFcdelOutputSumupLocationIj>().ForMember(x => x.Location, opt => opt.MapFrom(o => o.DeliveryRoute)));
                    var mapper = config.CreateMapper();
                    var lstModel1 = await context.TodFcdelOutputSumupRouteIjs.Where(x => x.Active == true).OrderBy(x => x.DeliveryRoute).ToListAsync();
                    lstModel.AddRange(mapper.Map<List<TodFcdelOutputSumupRouteIj>, List<TodFcdelOutputSumupLocationIj>>(lstModel1));
                }
                else if ((product.Equals("LBP") || product.Equals("ALL")) && group == "route")
                {
                    var config = new MapperConfiguration(cfg => cfg.CreateMap<TodFcdelOutputSumupRouteLbp, TodFcdelOutputSumupLocationIj>().ForMember(x => x.Location, opt => opt.MapFrom(o => o.DeliveryRoute)));
                    var mapper = config.CreateMapper();
                    var lstModel1 = await context.TodFcdelOutputSumupRouteLbps.Where(x => x.Active == true).OrderBy(x => x.DeliveryRoute).ToListAsync();
                    lstModel.AddRange(mapper.Map<List<TodFcdelOutputSumupRouteLbp>, List<TodFcdelOutputSumupLocationIj>>(lstModel1));
                }
                var dateRangeResult = new List<DateOnly>();
                for (var iD = dF; iD <= dT; iD = iD.AddDays(1))
                {
                    dateRangeResult.Add(iD);
                }
                foreach (var vd in lstModel)
                {
                    var vendor = vd.Location;
                    var rangeD = dateRangeResult;
                    var lstValueD = new List<double>();
                    var lstValueN = new List<double>();
                    Dictionary<DateOnly, double> dicShiftDay = new Dictionary<DateOnly, double>();
                    Dictionary<DateOnly, double> dicShiftNight = new Dictionary<DateOnly, double>();
                    if (type == "lot")
                    {
                        if (vd.SumupValueDayByLot != null && vd.SumupValueDayByLot.Length > 0)
                        {
                            for (int i = 0; i < vd.SumupDate.Length; i++)
                            {
                                dicShiftDay.Add(vd.SumupDate[i], vd.SumupValueDayByLot[i]);
                            }
                        }
                        if (vd.SumupValueNightByLot != null && vd.SumupValueNightByLot.Length > 0)
                        {
                            for (int i = 0; i < vd.SumupDate.Length; i++)
                            {
                                dicShiftNight.Add(vd.SumupDate[i], vd.SumupValueNightByLot[i]);
                            }
                        }
                    }
                    else if (type == "shift")
                    {
                        if (vd.SumupValueDayByShift != null && vd.SumupValueDayByShift.Length > 0)
                        {
                            for (int i = 0; i < vd.SumupDate.Length; i++)
                            {
                                dicShiftDay.Add(vd.SumupDate[i], vd.SumupValueDayByShift[i]);
                            }
                        }
                        if (vd.SumupValueNightByShift != null && vd.SumupValueNightByShift.Length > 0)
                        {
                            for (int i = 0; i < vd.SumupDate.Length; i++)
                            {
                                dicShiftNight.Add(vd.SumupDate[i], vd.SumupValueNightByShift[i]);
                            }
                        }
                    }

                    for (var iD = dF; iD <= dT; iD = iD.AddDays(1))
                    {
                        double itemValD = 0;
                        double itemValN = 0;
                        try
                        {
                            itemValD += dicShiftDay[iD];
                        }
                        catch (Exception)
                        {

                        }
                        try
                        {
                            itemValN += dicShiftNight[iD];
                        }
                        catch (Exception)
                        {

                        }
                        itemValD = Math.Round(itemValD);
                        itemValN = Math.Round(itemValN);
                        lstValueD.Add(itemValD);
                        lstValueN.Add(itemValN);
                    }
                    Random rnd = new Random();
                    var cl = "rgb(" + rnd.Next(256) + ", " + rnd.Next(256) + ", " + rnd.Next(256) + ")";
                    //try
                    //{
                    //    var clTemp = dicColor[vendor];
                    //    if (!string.IsNullOrEmpty(clTemp))
                    //    {
                    //        cl = clTemp;
                    //    }
                    //}
                    //catch (Exception)
                    //{

                    //}
                    //if (!lstValueD.All(x => x == 0))
                    //{
                        result.Add(new ChartFcdelByTypeByGroupBy()
                        {
                            Days = dateRangeResult.ToArray(),
                            Label = "D - " + vendor ?? "(blank)",
                            Stack = "D",
                            Value = lstValueD.ToArray(),
                            BackgroundColor = cl
                        });
                    //}
                    //if (!lstValueN.All(x => x == 0))
                    //{
                        result.Add(new ChartFcdelByTypeByGroupBy()
                        {
                            Days = dateRangeResult.ToArray(),
                            Label = "N - " + vendor ?? "(blank)",
                            Stack = "N",
                            Value = lstValueN.ToArray(),
                            BackgroundColor = cl
                        });
                    //}
                }
            }
            catch (Exception)
            {

            }
            return result;
        }
        private async Task<List<ChartFcdelByTypeByGroupBy>> GetChartSumupDataMonth(string type, string group, string product, string dateF, string dateT)
        {
            var lstModel = await GetChartSumupData(type, group, product, dateF, dateT);
            if (lstModel?.Count < 1)
            {
                return new List<ChartFcdelByTypeByGroupBy>();
            }
            var total = new ChartFcdelByTypeByGroupBy
            {
                Label = "Total",
                Stack = "true",
                Days = lstModel?[0].Days,
                Value = lstModel?.Aggregate(new double[lstModel[0].Days.Length], (acc, item) =>
                {
                    for (int i = 0; i < item.Value?.Length; i++)
                    {
                        acc[i] += item.Value[i];
                    }
                    return acc;
                })
            };
            var distinctMonth = total.StrMonths.Distinct().ToList();
            Dictionary<string, (DateOnly, double)> dicMonth = new Dictionary<string, (DateOnly, double)>();
            for (int i = 0; i < total.Value.Length; i++)
            {
                var month = total.StrMonths[i];
                var day = total.Days[i];
                var val = total.Value[i];
                if (!dicMonth.ContainsKey(month))
                {
                    dicMonth.Add(month, (day, val));
                }
                else
                {
                    if (dicMonth[month].Item2 < val)
                    {
                        dicMonth[month] = (day, val);
                    }
                }
            }
            var arrDo = dicMonth.Select(x => x.Value.Item1).ToArray();
            var lstResult = new List<ChartFcdelByTypeByGroupBy>();
            foreach (var item in lstModel)
            {

                var newVal = new List<double>();
                Dictionary<DateOnly, double> dicValByDate = new Dictionary<DateOnly, double>();
                for (int i = 0; i < item.Value.Length; i++)
                {
                    try
                    {
                        dicValByDate.Add(item.Days[i], item.Value[i]);
                    }
                    catch (Exception)
                    {

                    }
                }

                for (int i = 0; i < arrDo.Length; i++)
                {
                    newVal.Add(dicValByDate[arrDo[i]]);
                }
                var newitem = item;
                newitem.Days = arrDo;
                newitem.Value = newVal.ToArray();
                lstResult.Add(newitem);
            }
            return lstResult;
        }


        [HttpGet("get-data-calendar-ui")]
        [AllowAnonymous]
        //[ResponseCache(Duration = 28800)]
        public async Task<List<AdmMasterCalendar>> GetCalendarWidget(string product)
        {
            try
            {
                return await context.AdmMasterCalendars.OrderBy(x => x.DateOfDate).ToListAsync();
            }
            catch (Exception)
            {
                return new List<AdmMasterCalendar>();
            }
        }
    }
}
