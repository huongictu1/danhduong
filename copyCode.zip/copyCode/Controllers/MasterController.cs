﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

using PDCProjectApi.Data;
using PDCProjectApi.Model.View;

using System.Net;
using System.Security.Claims;
using PDCProjectApi.Model.Response;
using PDCProjectApi.Model.Request;
using PDCProjectApi.Common;
using System.Linq;
using PDCProjectApi.Helper;
using PDCProjectApi.Common.Job;

namespace PDCProjectApi.Controllers
{
    [Route("api/master")]
    [ApiController]
    [Authorize]
    //[ApiExplorerSettings(IgnoreApi = true)]
    public class MasterController : Controller
    {
        private readonly IConfiguration configuration;
        private readonly PdcsystemContext context;
        private Guid idApproved = Guid.Parse("4abe4e89-b815-426b-b56a-7476924c1191");
        private Guid idChecked= Guid.Parse("96bc4ae5-6b85-48ba-8962-313001532358");
        private Guid idRejected = Guid.Parse("564f7092-51e1-4855-8f56-6dff5062bbbc");
        public MasterController(
            IConfiguration configuration,
            PdcsystemContext context)
        {
            this.configuration = configuration;
            this.context = context;
        }

        #region user
        //get fact of user
        [HttpGet("get-fact-of-user/{idUser}")]
    
        public async Task<List<MasterFactoryView>> GetMasterFactoryOfDept(Guid? idUser)
        {
            try
            {
                var lstResult = new List<MasterFactoryView>();


                var model = await context.AdmDetailUserDepts.Include(x => x.Dept).ThenInclude(x => x.Fact).Where(x => x.Active == true && x.UserId == idUser).ToListAsync();
                var model2 = await context.AdmMasterFactories.Where(x => x.Active == true && model.Select(y => y.Dept.Fact.Id).Contains(x.Id)).Distinct().ToListAsync();



                foreach (var item in model2)
                {

                    lstResult.Add(new MasterFactoryView()
                    {
                        Id = item.Id,
                        FactFullName = item.FactFullName,
                        FactShortName = item.FactShortName,
                    });
                }

                return lstResult;
            }
            catch (Exception)
            {
                return new List<MasterFactoryView>();
            }
        }

        //get dept of user
        [HttpGet("get-dept-of-user/{idUser}")]
    
        public async Task<List<MasterDepartmentView>> GetMasterDeptOfUser(Guid? idUser)
        {
            try
            {
                var lstResult = new List<MasterDepartmentView>();


                var model = await context.AdmDetailUserDepts.Include(x => x.Dept).ThenInclude(x => x.Fact).Where(x => x.Active == true && x.UserId == idUser).ToListAsync();
              


                foreach (var item in model)
                {
                    lstResult.Add(new MasterDepartmentView()
                    {
                        Id = item.Dept.Id,
                        DeptFullName = item.Dept.DeptFullName,
                        DeptShortName = item.Dept.Fact.FactShortName + "-" + item.Dept.DeptShortName + "(" + item.Dept.CostCenter + ")"
                    });
                }

                return lstResult;
            }
            catch (Exception)
            {
                return new List<MasterDepartmentView>();
            }
        }

        //get group of user
        [HttpGet("get-group-of-user/{idUser}")]
    
        public async Task<List<MasterGroupView>> GetMasterGroupOfUser(Guid? idUser)
        {
            try
            {
                var lstResult = new List<MasterGroupView>();


                var model = await context.AdmDetailUserGroups.Include(x => x.Group).Where(x => x.Active == true && x.UserId == idUser ).ToListAsync();



                foreach (var item in model)
                {
                    lstResult.Add(new MasterGroupView()
                    {
                        Id = item.Group.Id,
                       GroupName = item.Group.GroupName,
                    });
                }

                return lstResult;
            }
            catch (Exception)
            {
                return new List<MasterGroupView>();
            }
        }
        
        //filter master factory
        [HttpGet("get-user-by-code/{empCode}")]
        [AllowAnonymous]
        //[ResponseCache(Duration = 28800)]
        public async Task<List<MasterUserInforView>> GetUserByCode(string? empCode)
        {
            try
            {

                var lstResult = new List<MasterUserInforView>();

                var model = await context.AdmUserInformations.Include(x => x.StatusNavigation).Where(x => x.Active == true && x.EmployeeCode != null && x.EmployeeCode.Contains(empCode)).FirstOrDefaultAsync();
                var email = PCMSAPI.GetUserEmails().FirstOrDefault(x => x.code == empCode);
                var user = new MasterUserInforView();
                if(email != null)
                {
                    user.Email = email.email2 == "" ? email.email : email.email2;
                }
                if(model != null)
                {
                    user.Id = model.Id;
                    user.EmployeeCode = model.EmployeeCode;
                    user.FullName = model.FullName;
                    user.IsExist = model.StatusNavigation == null ? false : (model.StatusNavigation.StatusName.Contains("Approved") || model.StatusNavigation.StatusName.Contains("Checked") ? true : false);
                    user.IsOld = true;
                }

                lstResult.Add(user) ;
                

                return lstResult;
            }
            catch (Exception)
            {
                return new List<MasterUserInforView>();
            }
        }

        //filter list all user
        [HttpPost("filter-master-list-all-user")]
        public async Task<MasterUserInforModel> FilterMasterListUser(PaginationParams param)
        {
            try
            {
                param.search = param.search == null ? "" : param.search.ToUpper().Trim();
                var result = new MasterUserInforModel();
                var lstResult = new List<MasterUserInforView>();


                var model = context.AdmUserInformations.Include(x => x.AdmDetailUserGroups).ThenInclude(x => x.Group).Include(x => x.StatusNavigation)
                    .Include(x => x.AdmDetailUserDepts).ThenInclude(x => x.Dept).ThenInclude(x => x.Fact).Where(x => (x.FullName.ToUpper().Contains(param.search)
                    || x.EmployeeCode.ToUpper().Contains(param.search))
                    && x.Active == true);

                var model2 = await model.Skip((param.Page - 1) * param.RecordsPerPage).Take(param.RecordsPerPage).ToListAsync();

                foreach (var item in model2)
                {
                    var deptName = item.AdmDetailUserDepts.Where(x => x.Active == true).Select(x => x.Dept.DeptShortName).ToList();
                    var factName = item.AdmDetailUserDepts.Where(x => x.Active == true).Select(x => x.Dept.Fact.FactShortName).ToList();
                    var groupName = item.AdmDetailUserGroups.Where(x => x.Active == true).Select(x => x.Group.GroupName).ToList();
                    lstResult.Add(new MasterUserInforView()
                    {

                        Id = item.Id,
                        EmployeeCode = item.EmployeeCode,
                        FullName = item.FullName,
                        Email = item.Email,
                        Dept = String.Join(",", deptName),
                        Fact = String.Join(",", factName),
                        Group = String.Join(",", groupName),
                        Status = item.StatusNavigation == null ? null : item.StatusNavigation.StatusName,
                        Approver = item.Approver,
                        ApproveDate = item.ApproveDate == null ? null : item.ApproveDate.Value.UnsetKindUtc().ToString("dd-MMM-yyyy")
                    });
                }
                int countModel = await model.CountAsync();
                result.lstModel = lstResult;
                result.toRecord = (int)Math.Min(result.totalRecords, result.currentPage * result.recordPerPage);
                result.totalPage = (int)Math.Ceiling((decimal)countModel / param.RecordsPerPage);
                result.totalRecords = countModel;
                result.recordPerPage = param.RecordsPerPage;
                result.currentPage = param.Page;
                result.fromRecord = countModel == 0 ? 0 : (result.currentPage - 1) * result.recordPerPage + 1;
                return result;
            }
            catch (Exception)
            {
                return new MasterUserInforModel();
            }
        }

        //filter list user approved or wait approve
        [HttpPost("filter-master-user")]
        public async Task<MasterUserInforModel> FilterMasterUser(PaginationParams param)
        {
            try
            {
                param.search = param.search == null ? "" : param.search.ToUpper().Trim();
                var result = new MasterUserInforModel();
                var lstResult = new List<MasterUserInforView>();
                var user = context.AdmUserInformations.Where(x => x.Active == true);

                var model = context.AdmUserInformations.Include(x => x.AdmDetailUserGroups).ThenInclude(x => x.Group).Include(x => x.StatusNavigation)
                    .Include(x => x.AdmDetailUserDepts).ThenInclude(x => x.Dept).ThenInclude(x => x.Fact).Where(x => (x.FullName.ToUpper().Contains(param.search)
                    || x.EmployeeCode.ToUpper().Contains(param.search))
                    && x.Active == true 
                    && (x.StatusNavigation.StatusName.Contains("Checked")
                    || x.StatusNavigation.StatusName.Contains("Approved")));

                var model2 = await model.Skip((param.Page - 1) * param.RecordsPerPage).Take(param.RecordsPerPage).ToListAsync();
           
                foreach (var item in model2)
                {
                   var isAdmin = item.AdmDetailUserGroups.Any(x => x.Active == true && x.UserId == item.Id && x.GroupId == new Guid("e462d3a8-27fa-4ffa-bac4-512a2ab33bc3"));
                   var deptName =  item.AdmDetailUserDepts.Where(x => x.Active == true).Select(x =>x.Dept.Fact.FactShortName+"-"+x.Dept.DeptShortName).Distinct().ToList();
                   var factName = item.AdmDetailUserDepts.Where(x => x.Active == true).Select(x => x.Dept.Fact.FactShortName).Distinct().ToList();
                   var groupName = item.AdmDetailUserGroups.Where(x => x.Active == true).Select(x => x.Group.GroupName).Distinct().ToList();
                   var registeredBy = await user.FirstOrDefaultAsync(x => x.EmployeeCode != null && x.EmployeeCode.Contains(item.RegisteredBy));
                   lstResult.Add(new MasterUserInforView()
                    {

                        Id = item.Id,
                        EmployeeCode = item.EmployeeCode,
                        FullName = item.FullName,
                        Email = item.Email,
                        Dept = String.Join(",", deptName),
                        Fact = String.Join(",", factName),
                        Group = String.Join(",", groupName),
                        Status = item.StatusNavigation == null ? null : item.StatusNavigation.StatusName,
                        IsAdmin = isAdmin,
                        RegisteredBy = registeredBy == null? item.RegisteredBy:registeredBy.FullName,
                        Purpose = item.Purpose
                        //Approver = item.Approver,
                        //ApproveDate = item.ApproveDate == null ? null :item.ApproveDate.Value.UnsetKindUtc().ToString("dd-MMM-yyyy")
                    }) ; 
                }
                int countModel = await model.CountAsync();
                result.lstModel = lstResult;
                result.toRecord = (int)Math.Min(result.totalRecords, result.currentPage * result.recordPerPage);
                result.totalPage = (int)Math.Ceiling((decimal)countModel / param.RecordsPerPage);
                result.totalRecords = countModel;
                result.recordPerPage = param.RecordsPerPage;
                result.currentPage = param.Page;
                result.fromRecord = countModel == 0 ? 0 : (result.currentPage - 1) * result.recordPerPage + 1;
                return result;
            }
            catch (Exception)
            {
                return new MasterUserInforModel();
            }
        }

        //add user
        [HttpPost("add-master-user-by-admin")]
        public CommonResponse AddMasterUser([FromBody] MasterUserRequest page)
        {
            CommonResponse res = new CommonResponse()
            {
                Error = false,
                Message = "",
                Status = (int)HttpStatusCode.BadRequest
            };
            try
            {
                if(page.IsOld == true)
                {
                    var model = context.AdmUserInformations.FirstOrDefault(x => x.Active == true && x.Id == page.Id);
                    model.IsAdmin = page.IsAdmin;
                    model.StatusId = idApproved;
                    model.Approver = GetCurrentUser().UserName;
                    model.ApproveDate = DateTime.Now.SetKindUtc();
                    context.AdmUserInformations.Update(model);

                    foreach(var dept in page.DeptId)
                    {
                        AdmDetailUserDept detailDept = new AdmDetailUserDept()
                        {
                            Active = true,
                            CreatedBy = GetCurrentUser().UserName,
                            CreatedDate = DateTime.Now.SetKindUtc(),
                            UserId = page.Id,
                            DeptId = dept
                        };
                        context.AdmDetailUserDepts.Add(detailDept);      
                    }

                    if (page.GroupId.Count > 0 && page.GroupId != null)
                    {
                        foreach (var group in page.GroupId)
                        {
                            AdmDetailUserGroup detailGroup = new AdmDetailUserGroup()
                            {
                                Active = true,
                                CreatedBy = GetCurrentUser().UserName,
                                CreatedDate = DateTime.Now.SetKindUtc(),
                                UserId = page.Id,
                                GroupId = group,
                               
                            };
                            context.AdmDetailUserGroups.Add(detailGroup);
                        }

                    }
                    if (!(page.LstPageRO == null || page.LstPageRO.Count == 0))
                    {
                        foreach (var group in page.LstPageRO)
                        {
                            AdmDetailUserPageReadOnly detailGroup = new AdmDetailUserPageReadOnly()
                            {
                                Active = true,
                                CreatedBy = GetCurrentUser().UserName,
                                CreatedDate = DateTime.Now.SetKindUtc(),
                                UserId = page.Id,
                                PageName = group,

                            };
                            context.AdmDetailUserPageReadOnlies.Add(detailGroup);
                        }

                    }

                    context.SaveChanges();
                }
                else
                {
                    string hash = page.EmployeeCode.ToSha256();
                    AdmUserInformation model = new AdmUserInformation()
                    {
                        Active = true,
                        CreatedBy = GetCurrentUser().UserName,
                        CreatedDate = DateTime.Now.SetKindUtc(),
                        EmployeeCode = page.EmployeeCode,
                        FullName = page.FullName,
                        Email = page.Email,
                        IsAdmin = page.IsAdmin,
                        StatusId = idApproved,
                        Password = hash,
                        Approver = GetCurrentUser().UserName,
                        ApproveDate = DateTime.Now.SetKindUtc(),
                    };
                    context.AdmUserInformations.Add(model);
                    context.SaveChanges();

                    foreach (var dept in page.DeptId)
                    {
                        AdmDetailUserDept detailDept = new AdmDetailUserDept()
                        {
                            Active = true,
                            CreatedBy = GetCurrentUser().UserName,
                            CreatedDate = DateTime.Now.SetKindUtc(),
                            UserId = model.Id,
                            DeptId = dept
                        };
                        context.AdmDetailUserDepts.Add(detailDept);
                    }

                    if (page.GroupId.Count > 0)
                    {
                        foreach (var group in page.GroupId)
                        {
                            AdmDetailUserGroup detailGroup = new AdmDetailUserGroup()
                            {
                                Active = true,
                                CreatedBy = GetCurrentUser().UserName,
                                CreatedDate = DateTime.Now.SetKindUtc(),
                                UserId = model.Id,
                                GroupId = group,
                            
                            };
                            context.AdmDetailUserGroups.Add(detailGroup);
                        }

                    }
                    if (!(page.LstPageRO == null || page.LstPageRO.Count == 0))
                    {
                        foreach (var group in page.LstPageRO)
                        {
                            AdmDetailUserPageReadOnly detailGroup = new AdmDetailUserPageReadOnly()
                            {
                                Active = true,
                                CreatedBy = GetCurrentUser().UserName,
                                CreatedDate = DateTime.Now.SetKindUtc(),
                                UserId = page.Id,
                                PageName = group,

                            };
                            context.AdmDetailUserPageReadOnlies.Add(detailGroup);
                        }

                    }
                    context.SaveChanges();

                }
             
                res.Error = false;
                res.Message = "Successfully !";
                res.Status = (int)HttpStatusCode.OK;
            }
            catch (Exception e)
            {
                res.Error = true;
                res.Message = e.Message;
                res.Status = (int)HttpStatusCode.BadRequest;
            }
            return res;
        }

        //register user
        [HttpPost("register-master-user")]
        [AllowAnonymous]
        public CommonResponse RegisterMasterUser([FromBody] MasterUserRequest page)
        {
            CommonResponse res = new CommonResponse()
            {
                Error = false,
                Message = "",
                Status = (int)HttpStatusCode.BadRequest
            };
            try
            {
                if (page.IsOld == true)
                {
                    var model = context.AdmUserInformations.FirstOrDefault(x => x.Active == true && x.Id == page.Id);
                    model.StatusId = idChecked;
                    model.RegisteredBy = page.RegisteredBy;
                    model.Purpose = page.Purpose;
                    context.AdmUserInformations.Update(model);

                    foreach (var dept in page.DeptId)
                    {
                        AdmDetailUserDept detailDept = new AdmDetailUserDept()
                        {
                            Active = true,
                            CreatedDate = DateTime.Now.SetKindUtc(),
                            UserId = page.Id,
                            DeptId = dept
                        };
                        context.AdmDetailUserDepts.Add(detailDept);
                    }

                   
                    context.SaveChanges();
                }
                else
                {
                    string hash = page.EmployeeCode.ToSha256();
                    AdmUserInformation model = new AdmUserInformation()
                    {
                        Active = true,
                        CreatedDate = DateTime.Now.SetKindUtc(),
                        EmployeeCode = page.EmployeeCode,
                        FullName = page.FullName,
                        Password = hash,
                        Email = page.Email,
                        StatusId = idChecked,
                        RegisteredBy = page.RegisteredBy,
                        Purpose = page.Purpose
                };
                    context.AdmUserInformations.Add(model);
                    context.SaveChanges();

                    foreach (var dept in page.DeptId)
                    {
                        AdmDetailUserDept detailDept = new AdmDetailUserDept()
                        {
                            Active = true,
                            CreatedDate = DateTime.Now.SetKindUtc(),
                            UserId = model.Id,
                            DeptId = dept
                        };
                        context.AdmDetailUserDepts.Add(detailDept);
                    }
                    context.SaveChanges();

                }

                res.Error = false;
                res.Message = "Successfully !";
                res.Status = (int)HttpStatusCode.OK;
            }
            catch (Exception e)
            {
                res.Error = true;
                res.Message = e.Message;
                res.Status = (int)HttpStatusCode.BadRequest;
            }
            return res;
        }

        //approve user
        [HttpPut("approve-master-user")]
        public CommonResponse ApproveMasterUser([FromBody] Guid[] id)
        {
            CommonResponse res = new CommonResponse()
            {
                Error = false,
                Message = "",
                Status = (int)HttpStatusCode.BadRequest
            };
            try
            { 
                foreach(var item in id)
                {
                    var model = context.AdmUserInformations.FirstOrDefault(x => x.Active == true && x.Id == item && x.StatusId != idApproved);
                    if(model!= null)
                    {
                        model.StatusId = idApproved;
                        model.Approver = GetCurrentUser().UserName;
                        model.ApproveDate = DateTime.Now.SetKindUtc();
                        context.AdmUserInformations.Update(model);
                        context.SaveChanges();
                    }
                }
                res.Error = false;
                res.Message = "Successfully !";
                res.Status = (int)HttpStatusCode.OK;
            }
            catch (Exception e)
            {
                res.Error = true;
                res.Message = e.Message;
                res.Status = (int)HttpStatusCode.BadRequest;
            }
            return res;
        }

        //reject user
        [HttpPut("reject-master-user/{reason}")]
        public CommonResponse ApproveMasterUser([FromBody] Guid[] id,string? reason)
        {
            CommonResponse res = new CommonResponse()
            {
                Error = false,
                Message = "",
                Status = (int)HttpStatusCode.BadRequest
            };
            try
            {
                foreach (var item in id)
                {
                    var model = context.AdmUserInformations.FirstOrDefault(x => x.Active == true && x.Id == item);
                    if (model != null)
                    {
                        model.StatusId = idRejected;
                        model.Approver = GetCurrentUser().UserName;
                        model.ApproveDate = DateTime.Now.SetKindUtc();
                        context.AdmUserInformations.Update(model);
                        context.SaveChanges();
                    }
                }
                res.Error = false;
                res.Message = "Successfully !";
                res.Status = (int)HttpStatusCode.OK;
            }
            catch (Exception e)
            {
                res.Error = true;
                res.Message = e.Message;
                res.Status = (int)HttpStatusCode.BadRequest;
            }
            return res;
        }

        //edit user
        [HttpPut("edit-master-user")]
        public CommonResponse EditMasterGroup([FromBody] MasterUserRequest page)
        {
            CommonResponse res = new CommonResponse()
            {
                Error = false,
                Message = "",
                Status = (int)HttpStatusCode.BadRequest
            };
            try
            {
                var detail_dept = context.AdmDetailUserDepts.Where(x => x.Active == true && x.UserId == page.Id).ToList();
                context.AdmDetailUserDepts.RemoveRange(detail_dept);

                var detail_group = context.AdmDetailUserGroups.Where(x => x.Active == true && x.UserId == page.Id ).ToList();
                context.AdmDetailUserGroups.RemoveRange(detail_group);
                context.SaveChanges();

                var detail_user_ro = context.AdmDetailUserPageReadOnlies.Where(x => x.Active == true && x.UserId == page.Id).ToList();
                context.AdmDetailUserPageReadOnlies.RemoveRange(detail_user_ro);
                context.SaveChanges();

                var model = context.AdmUserInformations.FirstOrDefault(x => x.Active == true && x.Id == page.Id);
                model.IsAdmin = page.IsAdmin;
                model.ModifiedBy = GetCurrentUser().UserName;
                model.ModifiedDate = DateTime.Now.SetKindUtc();
                model.EmployeeCode = page.EmployeeCode;
                model.FullName = page.FullName;
                context.AdmUserInformations.Update(model);

                foreach (var dept in page.DeptId)
                {
                    AdmDetailUserDept detailDept = new AdmDetailUserDept()
                    {
                        Active = true,
                        CreatedBy = GetCurrentUser().UserName,
                        CreatedDate = DateTime.Now.SetKindUtc(),
                        UserId = page.Id,
                        DeptId = dept
                    };
                    context.AdmDetailUserDepts.Add(detailDept);

                }

                if (page.GroupId.Count > 0)
                {
                    foreach (var group in page.GroupId)
                    {
                        AdmDetailUserGroup detailGroup = new AdmDetailUserGroup()
                        {
                            Active = true,
                            CreatedBy = GetCurrentUser().UserName,
                            CreatedDate = DateTime.Now.SetKindUtc(),
                            UserId = page.Id,
                            GroupId = group,
                           
                        };
                        context.AdmDetailUserGroups.Add(detailGroup);
                    }

                }
                if (!(page.LstPageRO == null || page.LstPageRO.Count == 0))
                {
                    foreach (var group in page.LstPageRO)
                    {
                        AdmDetailUserPageReadOnly detailGroup = new AdmDetailUserPageReadOnly()
                        {
                            Active = true,
                            CreatedBy = GetCurrentUser().UserName,
                            CreatedDate = DateTime.Now.SetKindUtc(),
                            UserId = page.Id,
                            PageName = group,

                        };
                        context.AdmDetailUserPageReadOnlies.Add(detailGroup);
                    }

                }

                context.SaveChanges();
                res.Error = false;
                res.Message = "Successfully !";
                res.Status = (int)HttpStatusCode.OK;
            }
            catch (Exception e)
            {
                res.Error = true;
                res.Message = e.Message;
                res.Status = (int)HttpStatusCode.BadRequest;
            }
            return res;
        }

        [HttpGet("get-page-read-only-user/{id}")]
        [AllowAnonymous]
        public List<string> GetPageReadOnlyUser(string? id)
        {
           
            try
            {
                var uId = new Guid(id);
                var model = context.AdmDetailUserPageReadOnlies.Where(x => x.Active == true && x.UserId == uId).Select(y => y.PageName).ToList();
                return model;
            }
            catch (Exception e)
            {
                return new List<string>();
            }
            
        }


        #endregion

        #region group
        //get all master group
        [HttpGet("get-all-master-group")]
    
        public async Task<List<MasterGroupView>> GetAllMasterGroup()
        {
            try
            {


                var lstResult = new List<MasterGroupView>();


                var model = await context.AdmMasterGroups.Where(x => x.Active == true).OrderBy(x => x.CreatedDate).ToListAsync();



                foreach (var item in model)
                {

                    lstResult.Add(new MasterGroupView()
                    {

                        Id = item.Id,
                        GroupName = item.GroupName,
                    });
                }

                return lstResult;
            }
            catch (Exception)
            {
                return new List<MasterGroupView>();
            }
        }

        //filter  master group
        [HttpPost("filter-master-group")]
        public MasterGroupModel FilterMasterGroup(PaginationParams param)
        {
            try
            {
                param.search = param.search == null ? "" : param.search.ToUpper().Trim();
                var result = new MasterGroupModel();
                var lstResult = new List<MasterGroupView>();


                var model = context.AdmMasterGroups.Where(x => (x.GroupName.ToUpper().Contains(param.search))
                    && x.Active == true).OrderBy(x => x.CreatedDate).ToList();

                var model2 = model.Skip((param.Page - 1) * param.RecordsPerPage).Take(param.RecordsPerPage).ToList();

                foreach (var item in model2)
                {
                   
                    lstResult.Add(new MasterGroupView()
                    {

                        Id = item.Id,
                       GroupName = item.GroupName,
                       CreatedBy = item.CreatedBy,
                       CreatedDate = item.CreatedDate == null? null: item.CreatedDate.Value.UnsetKindUtc().ToString("dd-MMM-yyyy"),
                       Note = item.Note
                    });
                }
                int countModel = model.Count;
                result.lstModel = lstResult;
                result.toRecord = (int)Math.Min(result.totalRecords, result.currentPage * result.recordPerPage);
                result.totalPage = (int)Math.Ceiling((decimal)countModel / param.RecordsPerPage);
                result.totalRecords = countModel;
                result.recordPerPage = param.RecordsPerPage;
                result.currentPage = param.Page;
                result.fromRecord = countModel == 0 ? 0 : (result.currentPage - 1) * result.recordPerPage + 1;
                return result;
            }
            catch (Exception)
            {
                return new MasterGroupModel();
            }
        }

        //add group
        [HttpPost("add-master-group")]
        public CommonResponse AddMasterGroup([FromBody] MasterGroupView page)
        {
            CommonResponse res = new CommonResponse()
            {
                Error = false,
                Message = "",
                Status = (int)HttpStatusCode.BadRequest
            };
            try
            {

                AdmMasterGroup model = new AdmMasterGroup()
                {
                    Active = true,
                    CreatedBy = GetCurrentUser().UserName,
                    CreatedDate = DateTime.Now.SetKindUtc(),
                    GroupName = page.GroupName,
                    Note = page.Note
                };
                context.AdmMasterGroups.Add(model);
                context.SaveChanges();

                res.Error = false;
                res.Message = "Successfully !";
                res.Status = (int)HttpStatusCode.OK;
            }
            catch (Exception e)
            {
                res.Error = true;
                res.Message = e.Message;
                res.Status = (int)HttpStatusCode.BadRequest;
            }
            return res;
        }

        //edit group
        [HttpPut("edit-master-group/{id}")]
        public CommonResponse EditMasterGroup(Guid id, [FromBody] MasterGroupView page)
        {
            CommonResponse res = new CommonResponse()
            {
                Error = false,
                Message = "",
                Status = (int)HttpStatusCode.BadRequest
            };
            try
            {

                var model = context.AdmMasterGroups.FirstOrDefault(x => x.Id == id);
                model.GroupName = page.GroupName;
                model.Note = page.Note;
                model.ModifiedDate = DateTime.Now.SetKindUtc();
                model.ModifiedBy = GetCurrentUser().UserName;
                context.Update(model);
                context.SaveChanges();

                res.Error = false;
                res.Message = "Successfully !";
                res.Status = (int)HttpStatusCode.OK;
            }
            catch (Exception e)
            {
                res.Error = true;
                res.Message = e.Message;
                res.Status = (int)HttpStatusCode.BadRequest;
            }
            return res;
        }

        //active group
        [HttpPut("active-master-group")]
        public CommonResponse ActiveMasterGroup([FromBody] Guid[] id)
        {
            CommonResponse res = new CommonResponse()
            {
                Error = false,
                Message = "",
                Status = (int)HttpStatusCode.BadRequest
            };
            try
            {
                var model = context.AdmMasterGroups.Where(x => id.Contains(x.Id)).ToList();
                model.ForEach(a => a.Active = false);
                model.ForEach(a => a.ModifiedBy = GetCurrentUser().UserName);
                model.ForEach(a => a.ModifiedDate = DateTime.Now.SetKindUtc());
                context.UpdateRange(model);

                var model1 = context.AdmDetailPageGroups.Where(x => id.Contains((Guid)x.GroupId)).ToList();
                model1.ForEach(a => a.Active = false);
                context.UpdateRange(model1);

                var model2 = context.AdmDetailUserGroups.Where(x => id.Contains((Guid)x.GroupId)).ToList();
                model2.ForEach(a => a.Active = false);
                context.UpdateRange(model2);
              
                context.SaveChanges();

                res.Error = false;
                res.Message = "Successfully !";
                res.Status = (int)HttpStatusCode.OK;
            }
            catch (Exception e)
            {
                res.Error = true;
                res.Message = e.Message;
                res.Status = (int)HttpStatusCode.BadRequest;
            }
            return res;
        }
        #endregion

        #region department
        //filter master factory
        [HttpGet("get-master-factory")]
        [AllowAnonymous]
        //[ResponseCache(Duration = 28800)]
        public async Task<List<MasterFactoryView>> FilterMasterFactory()
        {
            try
            {
                
             
                var lstResult = new List<MasterFactoryView>();


                var model = await context.AdmMasterFactories.Where(x => x.Active == true).ToListAsync();

              

                foreach (var item in model)
                {

                    lstResult.Add(new MasterFactoryView()
                    {

                        Id = item.Id,
                        FactFullName = item.FactFullName,
                        FactShortName = item.FactShortName,
                    });
                }
              
                return lstResult;
            }
            catch (Exception)
            {
                return new List<MasterFactoryView>();
            }
        }

        //get master factory by id
        [HttpGet("get-master-factory-by-id/{id}")]
        //[ResponseCache(Duration = 28800)]
        public List<MasterFactoryView> FilterMasterFactById(Guid id)
        {
            try
            {

                var lstResult = new List<MasterFactoryView>();
                var model = context.AdmMasterFactories.Where(x => x.Active == true && x.Id == id).FirstOrDefault();

                    lstResult.Add(new MasterFactoryView()
                    {

                        Id = model.Id,
                        FactFullName = model.FactFullName,
                        FactShortName = model.FactShortName,
                    });
                

                return lstResult;
            }
            catch (Exception)
            {
                return new List<MasterFactoryView>();
            }
        }
        //get dept of fact
        [HttpPost("get-dept-of-fact")]
        [AllowAnonymous]
        //[ResponseCache(Duration = 28800)]
        public async Task<List<MasterDepartmentView>> GetDeptOfFact([FromBody] Guid[] id)
        {
          
            try
            {
                var lstResult = new List<MasterDepartmentView>();

                var model = await context.AdmMasterDepartments.Include(x => x.Fact).Where(x => x.Active == true && id.Contains((Guid)x.FactId)).ToListAsync();

                foreach (var item in model)
                {
                    lstResult.Add(new MasterDepartmentView()
                    {
                        Id = item.Id,
                        DeptFullName = item.DeptFullName,
                        DeptShortName =item.Fact.FactShortName+"-"+item.DeptShortName +"("+item.CostCenter+")",
                    });
                }

                return lstResult;
            }
            catch (Exception e)
            {
                return new List<MasterDepartmentView>();
            }
           
        }     

        //filter master dept
        [HttpPost("filter-master-department")]
        public async Task<MasterDepartmentModel> FilterMasterDepartment(PaginationParams param)
        {
            try
            {
                param.search = param.search == null ? "" : param.search.ToUpper().Trim();
                var result = new MasterDepartmentModel();
                var lstResult = new List<MasterDepartmentView>();


                var model = context.AdmMasterDepartments.Include(x => x.Fact).Where(x => (x.DeptFullName.ToUpper().Contains(param.search)
                || x.DeptShortName.ToUpper().Contains(param.search)
                || x.DeptShortName.ToUpper().Contains(param.search)
                || x.CostCenter.ToUpper().Contains(param.search)
                || x.Division.ToUpper().Contains(param.search)
                || x.Fact.FactShortName.ToUpper().Contains(param.search)
                || x.Fact.FactFullName.ToUpper().Contains(param.search))
                    && x.Active == true).OrderByDescending(x => x.CreatedDate);

                var model2 = await model.Skip((param.Page - 1) * param.RecordsPerPage).Take(param.RecordsPerPage).ToListAsync();

                foreach (var item in model2)
                {

                    lstResult.Add(new MasterDepartmentView()
                    {

                       Id = item.Id,
                       DeptFullName = item.DeptFullName,
                       DeptShortName = item.DeptShortName,
                       Division = item.Division,
                       FactId = item.FactId,
                       CostCenter = item.CostCenter,
                       Factory = item.Fact == null? null : item.Fact.FactShortName
                    });
                }
                int countModel = await model.CountAsync();
                result.lstModel = lstResult;
                result.toRecord = (int)Math.Min(result.totalRecords, result.currentPage * result.recordPerPage);
                result.totalPage = (int)Math.Ceiling((decimal)countModel / param.RecordsPerPage);
                result.totalRecords = countModel;
                result.recordPerPage = param.RecordsPerPage;
                result.currentPage = param.Page;
                result.fromRecord = countModel == 0 ? 0 : (result.currentPage - 1) * result.recordPerPage + 1;
                return result;
            }
            catch (Exception)
            {
                return new MasterDepartmentModel();
            }
        }

        //add dept
        [HttpPost("add-master-dept")]
        public CommonResponse AddMasterDept([FromBody] MasterDepartmentView page)
        {
            CommonResponse res = new CommonResponse()
            {
                Error = false,
                Message = "",
                Status = (int)HttpStatusCode.BadRequest
            };
            try
            {

                AdmMasterDepartment model = new AdmMasterDepartment()
                {
                    Active = true,
                    CreatedBy = GetCurrentUser().UserName,
                    CreatedDate = DateTime.Now.SetKindUtc(),
                    FactId = page.FactId,
                    DeptFullName = page.DeptFullName,
                    DeptShortName = page.DeptShortName,
                    Division = page.Division,
                    CostCenter = page.CostCenter
                };
                context.AdmMasterDepartments.Add(model);
                context.SaveChanges();

                res.Error = false;
                res.Message = "Successfully !";
                res.Status = (int)HttpStatusCode.OK;
            }
            catch (Exception e)
            {
                res.Error = true;
                res.Message = e.Message;
                res.Status = (int)HttpStatusCode.BadRequest;
            }
            return res;
        }

        //edit dept
        [HttpPut("edit-master-dept/{id}")]
        public CommonResponse EditMasterDept(Guid id, [FromBody] MasterDepartmentView page)
        {
            CommonResponse res = new CommonResponse()
            {
                Error = false,
                Message = "",
                Status = (int)HttpStatusCode.BadRequest
            };
            try
            {

                var model = context.AdmMasterDepartments.FirstOrDefault(x => x.Id == id);
                model.DeptFullName = page.DeptFullName;
                model.DeptShortName = page.DeptShortName;
                model.Division = page.Division;
                model.CostCenter = page.CostCenter;
                model.FactId = page.FactId;
                model.ModifiedDate = DateTime.Now.SetKindUtc();
                model.ModifiedBy = GetCurrentUser().UserName;
                context.Update(model);
                context.SaveChanges();

                res.Error = false;
                res.Message = "Successfully !";
                res.Status = (int)HttpStatusCode.OK;
            }
            catch (Exception e)
            {
                res.Error = true;
                res.Message = e.Message;
                res.Status = (int)HttpStatusCode.BadRequest;
            }
            return res;
        }

        //active dept
        [HttpPut("active-master-dept")]
        public CommonResponse ActiveMasterDept([FromBody] Guid[] id)
        {
            CommonResponse res = new CommonResponse()
            {
                Error = false,
                Message = "",
                Status = (int)HttpStatusCode.BadRequest
            };
            try
            {
                var model = context.AdmMasterDepartments.Where(x => id.Contains(x.Id)).ToList();
                model.ForEach(a => a.Active = false);
                model.ForEach(a => a.ModifiedBy = GetCurrentUser().UserName);
                model.ForEach(a => a.ModifiedDate = DateTime.Now.SetKindUtc());
                context.UpdateRange(model);

                var model1 = context.AdmDetailUserDepts.Where(x => id.Contains((Guid)x.DeptId)).ToList();
                model1.ForEach(a => a.Active = false);
                context.UpdateRange(model1);

                context.SaveChanges();

                res.Error = false;
                res.Message = "Successfully !";
                res.Status = (int)HttpStatusCode.OK;
            }
            catch (Exception e)
            {
                res.Error = true;
                res.Message = e.Message;
                res.Status = (int)HttpStatusCode.BadRequest;
            }
            return res;
        }
        #endregion

        #region page

        //get all master page
        [HttpGet("get-all-master-page")]
        //[ResponseCache(Duration = 28800)]
        public async Task<List<MasterPageView>> GetAllMasterPage()
        {
            try
            {
                var lstResult = new List<MasterPageView>();

                var modelsWithNullParent = await context.AdmMasterPages.Where(x => x.Active == true && x.ParentId == null ).OrderBy(x => x.OrderNo).ToListAsync();

                foreach (var item in modelsWithNullParent)
                {
                    var parentPage = new MasterPageView()
                    {
                        Id = item.Id,
                        PageName = item.ParentId == null ? item.PageName : "..." + item.PageName,
                     
                    };

                    lstResult.Add(parentPage);

                    var childPages = GetChildPages(item.Id);
                    lstResult.AddRange(childPages);
                }

                return lstResult;
            }
            catch (Exception)
            {
                return new List<MasterPageView>();
            }
        }
        //get all master page
        [HttpGet("get-master-page-by-id/{id}")]
        public async Task<List<MasterPageView>> GetMasterPageById(Guid? id)
        {
            try
            {
                var lstResult = new List<MasterPageView>();
                var model = await context.AdmMasterPages.Where(x => x.Active == true && x.Id == id).FirstOrDefaultAsync();
                    lstResult.Add(new MasterPageView()
                    {
                        Id = model.Id,
                        PageName = model.ParentId == null ? model.PageName : "..." + model.PageName,
                    });
                return lstResult;
            }
            catch (Exception)
            {
                return new List<MasterPageView>();
            }
        }

        //filter  master page
        [HttpPost("filter-master-page")]
        public async Task<MasterPageModel> FilterMasterPage(PaginationParams param)
        {
            try
            {
                param.search = param.search == null ? "" : param.search.ToUpper().Trim();
                var result = new MasterPageModel();
                var lstResult = new List<MasterPageView>();

                var page = context.AdmMasterPages.Where(x => x.Active == true);
                var model = await page.Where(x => (x.PageName.ToUpper().Contains(param.search))
                    && x.Active == true).OrderBy(x => x.PageName).ToListAsync();

                var model2 = model.Skip((param.Page - 1) * param.RecordsPerPage).Take(param.RecordsPerPage).ToList();

                foreach (var item in model2)
                {
                   var parentPage= page.FirstOrDefault(x => x.Id == item.ParentId);
                    lstResult.Add(new MasterPageView()
                    {

                        Id = item.Id,
                        PageName = item.PageName,
                        Link = item.Link,
                        Icon = item.Icon,
                        OrderNo = item.OrderNo,
                        ParentId = item.ParentId,
                        ParentName = parentPage == null? null:parentPage.PageName
                    });
                }
                int countModel = model.Count;
                result.lstModel = lstResult;
                result.toRecord = (int)Math.Min(result.totalRecords, result.currentPage * result.recordPerPage);
                result.totalPage = (int)Math.Ceiling((decimal)countModel / param.RecordsPerPage);
                result.totalRecords = countModel;
                result.recordPerPage = param.RecordsPerPage;
                result.currentPage = param.Page;
                result.fromRecord = countModel == 0 ? 0 : (result.currentPage - 1) * result.recordPerPage + 1;
                return result;
            }
            catch (Exception)
            {
                return new MasterPageModel();
            }
        }

        [HttpGet("get-master-page")]
        public async Task<List<MasterPageView>> GetMasterPage()
        {
            try
            {

                var u = GetCurrentUser();
                var lstResult = new List<MasterPageView>();

              
                var model = await context.AdmMasterPages.Where(x => x.Active == true).OrderBy(y => y.OrderNo).ToListAsync();


                foreach (var item in model)
                {

                    lstResult.Add(new MasterPageView()
                    {
                        Id = item.Id,
                        PageName = item.PageName,
                        Link = item.Link,
                        Icon = item.Icon,
                        ParentId = item.ParentId,
                        OrderNo = item.OrderNo,
                     
                    });
                }
                var result = GetNestedNodes(null, lstResult);

                return result;
            }
            catch (Exception)
            {
                return new List<MasterPageView>();
            }
        }

        //add page
        [HttpPost("add-master-page")]
        public CommonResponse AddMasterPage([FromBody] MasterPageView page)
        {
            CommonResponse res = new CommonResponse()
            {
                Error = false,
                Message = "",
                Status = (int)HttpStatusCode.BadRequest
            };
            try
            {
                AdmMasterPage model = new AdmMasterPage()
                {
                    Active = true,
                    CreatedBy = GetCurrentUser().UserName,
                    CreatedDate = DateTime.Now.SetKindUtc(),
                    PageName = page.PageName,
                    Link = page.Link,
                    Icon = page.Icon,
                    OrderNo = page.OrderNo,
                    ParentId = page.ParentId
                };
                context.AdmMasterPages.Add(model);
                context.SaveChanges();

                res.Error = false;
                res.Message = "Successfully !";
                res.Status = (int)HttpStatusCode.OK;
            }
            catch (Exception e)
            {
                res.Error = true;
                res.Message = e.Message;
                res.Status = (int)HttpStatusCode.BadRequest;
            }
            return res;
        }

        //edit user
        [HttpPut("edit-master-page/{id}")]
        public CommonResponse EditMasterpage([FromBody] MasterPageView page,Guid? id)
        {
            CommonResponse res = new CommonResponse()
            {
                Error = false,
                Message = "",
                Status = (int)HttpStatusCode.BadRequest
            };
            try
            {

                var model = context.AdmMasterPages.FirstOrDefault(x => x.Active == true && x.Id == id);
                model.PageName = page.PageName;
                model.Link = page.Link;
                model.Icon = page.Icon;
                model.OrderNo = page.OrderNo;
                model.ParentId = page.ParentId;
                model.ModifiedBy = GetCurrentUser().UserName;
                model.ModifiedDate = DateTime.Now.SetKindUtc();
                context.AdmMasterPages.Update(model);
                context.SaveChanges();
                res.Error = false;
                res.Message = "Successfully !";
                res.Status = (int)HttpStatusCode.OK;
            }
            catch (Exception e)
            {
                res.Error = true;
                res.Message = e.Message;
                res.Status = (int)HttpStatusCode.BadRequest;
            }
            return res;
        }

        //active dept
        [HttpPut("active-master-page")]
        public CommonResponse ActiveMasterPage([FromBody] Guid[] id)
        {
            CommonResponse res = new CommonResponse()
            {
                Error = false,
                Message = "",
                Status = (int)HttpStatusCode.BadRequest
            };
            try
            {
                var model = context.AdmMasterPages.Where(x => id.Contains(x.Id)).ToList();
                model.ForEach(a => a.Active = false);
                model.ForEach(a => a.ModifiedBy = GetCurrentUser().UserName);
                model.ForEach(a => a.ModifiedDate = DateTime.Now.SetKindUtc());
                context.UpdateRange(model);

                var model1 = context.AdmDetailPageGroups.Where(x => id.Contains((Guid)x.PageId)).ToList();
                model1.ForEach(a => a.Active = false);
                context.UpdateRange(model1);

                context.SaveChanges();

                res.Error = false;
                res.Message = "Successfully !";
                res.Status = (int)HttpStatusCode.OK;
            }
            catch (Exception e)
            {
                res.Error = true;
                res.Message = e.Message;
                res.Status = (int)HttpStatusCode.BadRequest;
            }
            return res;
        }
         [HttpPost("get-page-of-group")]
        public async Task<List<string>> GetPageOfGroup(Guid?[] grId)
        {
            try
            {
                //var lstResult = new List<string>();

                var pageOfGr = await context.AdmDetailPageGroups.Include(x => x.Page).Where(x => x.Active == true && x.Page != null && x.Group != null && x.Page.Link != null && grId.Contains(x.GroupId)).Select(x => x.Page.Link).ToListAsync();

                return pageOfGr;
            }
            catch (Exception)
            {
                return new List<string>();
            }
        }
        #endregion

        #region permission
        //get permission of group
        [HttpGet("get-permission-of-group/{idGroup}")]
        public async Task<List<MasterPageView>> GetPerMissionOfGroup(Guid? idGroup)
        {
            try
            {


                var lstResult = new List<MasterPageView>();

                var model = await context.AdmDetailPageGroups.Include(x => x.Page).Where(x => x.Active == true && x.GroupId == idGroup).ToListAsync();


                foreach (var item in model)
                {

                    lstResult.Add(new MasterPageView()
                    {

                        Id = item.Page.Id,
                        PageName = item.Page.ParentId == null ? item.Page.PageName : "..." + item.Page.PageName,
                    });
                }

                return lstResult;
            }
            catch (Exception)
            {
                return new List<MasterPageView>();
            }
        }

        //add permission
        [HttpPost("add-master-permission/{idGroup}")]
        public async Task<CommonResponse> AddMasterPermission([FromBody] List<MasterPageView> page,Guid? idGroup)
        {
            CommonResponse res = new CommonResponse()
            {
                Error = false,
                Message = "",
                Status = (int)HttpStatusCode.BadRequest
            };
            try
            {
                if(page.Count > 0)
                {
                    var query = await context.AdmDetailPageGroups.Where(x => x.GroupId == idGroup).ToListAsync();
                    foreach (var item in page)
                    {
                        var check = query.Where(x => x.PageId == item.Id).FirstOrDefault();
                        if(check != null)
                        {
                            check.Active = true;
                            context.AdmDetailPageGroups.Update(check);
                        }
                        else
                        {
                            AdmDetailPageGroup model = new AdmDetailPageGroup()
                            {
                                Active = true,
                                CreatedBy = GetCurrentUser().UserName,
                                CreatedDate = DateTime.Now.SetKindUtc(),
                                PageId = item.Id,
                                GroupId = idGroup
                              
                            };
                            context.AdmDetailPageGroups.Add(model);     
                        }
                    }
                    await context.SaveChangesAsync();
                    var updateFalse = await context.AdmDetailPageGroups.Where(x => x.GroupId == idGroup && !page.Select(x => x.Id).Contains(x.PageId)).ToListAsync();
                    updateFalse.ForEach(x => x.Active = false);
                    context.AdmDetailPageGroups.UpdateRange(updateFalse);
                    await context.SaveChangesAsync();
                }
                else
                {
                    var permission = await context.AdmDetailPageGroups.Where(x => x.GroupId == idGroup).ToListAsync();
                    permission.ForEach(x => x.Active = false);
                    permission.ForEach(x => x.ModifiedBy = GetCurrentUser().UserName);
                    permission.ForEach(x => x.ModifiedDate = DateTime.Now.SetKindUtc());
                    context.AdmDetailPageGroups.UpdateRange(permission);
                    await context.SaveChangesAsync();

                }
                

                res.Error = false;
                res.Message = "Successfully !";
                res.Status = (int)HttpStatusCode.OK;
            }
            catch (Exception e)
            {
                res.Error = true;
                res.Message = e.Message;
                res.Status = (int)HttpStatusCode.BadRequest;
            }
            return res;
        }


        //get permission of user 
        [HttpGet("get-permission-of-user")]
        public async Task<List<MasterPageView>> GetPerMissionOfUser()
        {
            try
            {

                var u = GetCurrentUser();
                var lstResult = new List<MasterPageView>();

                var group = await context.AdmDetailUserGroups.Include(x => x.Group).Where(x => x.Active == true && x.UserId == new Guid(u.Id)).Select(y => y.GroupId).ToListAsync();

                var model = context.AdmDetailPageGroups.Include(x => x.Page).Where(x => x.Active == true && group.Contains(x.GroupId)).OrderBy(y => y.Page.OrderNo).ToList().DistinctBy(x => x.PageId).ToList();


                foreach (var item in model)
                {

                    lstResult.Add(new MasterPageView()
                    {
                        Id = item.Page.Id,
                        PageName =item.Page.PageName,
                        Link = item.Page.Link,
                        Icon = item.Page.Icon,
                        ParentId = item.Page.ParentId

                    });
                }
                var result = GetNestedNodes(null, lstResult);

                return result;
            }
            catch (Exception)
            {
                return new List<MasterPageView>();
            }
        }

        #endregion

        #region run manual job
        [HttpPost("get-list-manual-job")]
    
        public async Task<MasterManualJobModel> GetListManualJob(PaginationParams parameters)
        {
            try
            {

                var u = GetCurrentUser();
               
                MasterManualJobModel result = new MasterManualJobModel()
                {
                    currentPage = parameters.Page,
                    recordPerPage = parameters.RecordsPerPage
                };
                var query = context.MasterManualJobs.Where(x => x.Active == true).AsQueryable();
                query = !string.IsNullOrEmpty(parameters.search) ? query.Where(x => x.JobName != null && x.JobName.ToUpper().Contains(parameters.search.ToUpper())) : query;

                result.totalRecords = await query.CountAsync();
                result.totalPage = (int)Math.Ceiling((decimal)result.totalRecords / parameters.RecordsPerPage);
                var model = await query.Paginate(parameters).ToListAsync();
                result.lstModel = model;
                result.fromRecord = model.Count == 0 ? 0 : (result.currentPage - 1) * result.recordPerPage + 1;
                result.toRecord = (int)Math.Min(result.totalRecords, result.currentPage * result.recordPerPage);
                result.currentPage = result.totalPage < result.currentPage ? result.totalPage : result.currentPage;

                return result;
            }
            catch (Exception)
            {
                return new MasterManualJobModel();
            }
        }
        //add page
        [HttpPost("add-master-manual-job")]
        public CommonResponse AddMasterManualJob([FromBody] MasterManualJob page)
        {
            CommonResponse res = new CommonResponse()
            {
                Error = false,
                Message = "",
                Status = (int)HttpStatusCode.BadRequest
            };
            try
            {
                MasterManualJob model = new MasterManualJob()
                {
                    Active = true,
                    CreatedBy = GetCurrentUser().UserName,
                    CreatedDate = DateTime.Now.SetKindUtc(),
                    JobName = page.JobName,
                    JobLink = page.JobLink
                  
                };
                context.MasterManualJobs.Add(model);
                context.SaveChanges();

                res.Error = false;
                res.Message = "Successfully !";
                res.Status = (int)HttpStatusCode.OK;
            }
            catch (Exception e)
            {
                res.Error = true;
                res.Message = e.Message;
                res.Status = (int)HttpStatusCode.BadRequest;
            }
            return res;
        }
        //edit user
        [HttpPut("edit-master-manual-job/{id}")]
        public CommonResponse EditMasterManualJob([FromBody] MasterManualJob page, Guid? id)
        {
            CommonResponse res = new CommonResponse()
            {
                Error = false,
                Message = "",
                Status = (int)HttpStatusCode.BadRequest
            };
            try
            {

                var model = context.MasterManualJobs.FirstOrDefault(x => x.Active == true && x.Id == id);
                model.JobLink = page.JobLink;
                model.JobName = page.JobName;
                model.ModifiedBy = GetCurrentUser().UserName;
                model.ModifiedDate = DateTime.Now.SetKindUtc();
                context.MasterManualJobs.Update(model);
                context.SaveChanges();
                res.Error = false;
                res.Message = "Successfully !";
                res.Status = (int)HttpStatusCode.OK;
            }
            catch (Exception e)
            {
                res.Error = true;
                res.Message = e.Message;
                res.Status = (int)HttpStatusCode.BadRequest;
            }
            return res;
        }
        //active dept
        [HttpPut("active-master-manual-job")]
        public CommonResponse ActiveMasterManualJob([FromBody] Guid[] id)
        {
            CommonResponse res = new CommonResponse()
            {
                Error = false,
                Message = "",
                Status = (int)HttpStatusCode.BadRequest
            };
            try
            {
                var model = context.MasterManualJobs.Where(x => id.Contains(x.Id)).ToList();
                model.ForEach(a => a.Active = false);
                model.ForEach(a => a.ModifiedBy = GetCurrentUser().UserName);
                model.ForEach(a => a.ModifiedDate = DateTime.Now.SetKindUtc());
                context.UpdateRange(model);

                context.SaveChanges();

                res.Error = false;
                res.Message = "Successfully !";
                res.Status = (int)HttpStatusCode.OK;
            }
            catch (Exception e)
            {
                res.Error = true;
                res.Message = e.Message;
                res.Status = (int)HttpStatusCode.BadRequest;
            }
            return res;
        }
        #endregion

        [HttpGet("check-connection")]
        [AllowAnonymous]
        public CommonResponse CheckConnection()
        {
            CommonResponse res = new CommonResponse()
            {
                Error = false,
                Message = "Successfully",
                Status = (int)HttpStatusCode.OK
            };
            return res;
        }

        private UserClaims GetCurrentUser()
        {
            UserClaims userClaims = new UserClaims();
            var identity = HttpContext.User.Identity as ClaimsIdentity;
            if (identity != null)
            {
                userClaims.UserName = identity.FindFirst("user_name") == null ? "Undefined" : identity.FindFirst("user_name").Value;
                userClaims.Id = identity.FindFirst("id") == null ? "Undefined" : identity.FindFirst("id").Value;
                //userClaims.IsIt = identity.FindFirst("isIt") == null ? "0" : identity.FindFirst("isIt").Value;
                userClaims.Departments = identity.FindFirst("deptIds") == null ? "" : identity.FindFirst("deptIds").Value;
                userClaims.Factories = identity.FindFirst("factIds") == null ? "" : identity.FindFirst("factIds").Value;
                userClaims.CostCenter = identity.FindFirst("cost_center") == null ? "" : identity.FindFirst("cost_center").Value;
                userClaims.FullName = identity.FindFirst("full_name") == null ? "" : identity.FindFirst("full_name").Value;
                userClaims.Departments = identity.FindFirst("dept") == null ? "" : identity.FindFirst("dept").Value;
                userClaims.Grade = identity.FindFirst("grade") == null ? "" : identity.FindFirst("grade").Value;
                userClaims.IsAdmin = identity.FindFirst("isAdmin") == null ? "false" : identity.FindFirst("isAdmin").Value;

            }
            return userClaims;
        }

        //lấy ra các page có parrent id khác null
        //private List<MasterPageView> GetNestedNodes(Guid? parentId, List<MasterPageView> nodes)
        //{
        //    List<MasterPageView> nestedNodes = new List<MasterPageView>();

        //    foreach (var node in nodes)
        //    {
        //        if (node.ParentId == parentId)
        //        {
        //            node.lstChild = GetNestedNodes(node.Id, nodes);
        //            nestedNodes.Add(node);
        //        }
        //    }

        //    return nestedNodes;
        //}
        private List<MasterPageView> GetNestedNodes(Guid? parentId, List<MasterPageView> nodes)
        {
            return nodes
                .Where(node => node.ParentId == parentId)
                .Select(node =>
                {
                    node.lstChild = GetNestedNodes(node.Id, nodes);
                    return node;
                })
                .ToList();
        }

        private List<MasterPageView> GetChildPages(Guid parentId)
        {
            var childPages = context.AdmMasterPages.Where(x => x.Active == true && x.ParentId == parentId).OrderBy(x => x.OrderNo).ToList();
            var result = new List<MasterPageView>();

            foreach (var child in childPages)
            {
                var childPage = new MasterPageView()
                {
                    Id = child.Id,
                    PageName = "..." + child.PageName
                };
                result.Add(childPage);

                var grandChildPages = GetChildPages(child.Id);
                result.AddRange(grandChildPages);
            }

            return result;
        }
    }
}
