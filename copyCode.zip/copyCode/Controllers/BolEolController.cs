﻿using Azure.Core;
using DocumentFormat.OpenXml.EMMA;
using DocumentFormat.OpenXml.Office.CustomUI;
using DocumentFormat.OpenXml.Office2010.CustomUI;
using DocumentFormat.OpenXml.Spreadsheet;
using DocumentFormat.OpenXml.VariantTypes;
using Hangfire;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.IdentityModel.Tokens;
using OfficeOpenXml;
using OfficeOpenXml.Style;
using PDCProjectApi.Common;
using PDCProjectApi.Common.Interface;
using PDCProjectApi.Common.Job;
using PDCProjectApi.Data;
using PDCProjectApi.Model.Request;
using PDCProjectApi.Model.Response;
using PDCProjectApi.Model.View;
using PDCProjectApi.Services;
using System.Composition;
using System.Linq;
using System.Net;
using System.Reflection.PortableExecutable;
using System.Security.Claims;


namespace PDCProjectApi.Controllers
{
    [Route("api/boleol")]
    [ApiController]
    [Authorize]
    public class BolEolController : Controller
    {
        [Obsolete]
        private readonly Microsoft.AspNetCore.Hosting.IHostingEnvironment _hostingEnvironment;
        private readonly IHttpContextAccessor httpContextAccessor;
        private readonly IFileStorageService fileStorageService;
        private readonly PdcsystemContext context;
        private readonly IConfiguration configuration;
        private readonly IEmailService email;
        private readonly IBackgroundJobClient _bgJobClient;
        private readonly IGlobalVariable global = new GlobalVariable();
        private readonly string outputPathOri = "";
        private readonly string DirectoryBrowser = "";
        private readonly string frondEnd = "";
        private string pathServer = "";
        [Obsolete]
        public BolEolController(Microsoft.AspNetCore.Hosting.IHostingEnvironment hosting, PdcsystemContext ctx,
            IHttpContextAccessor httpContextAccessor, IFileStorageService fileService,
            IConfiguration configuration, IEmailService mail, IBackgroundJobClient backgroundJobClient)
        {
            this._hostingEnvironment = hosting;
            this.httpContextAccessor = httpContextAccessor;
            this.context = ctx;
            this.fileStorageService = fileService;
            this.configuration = configuration;
            this.email = mail;
            this._bgJobClient = backgroundJobClient;
            this.outputPathOri = this.global.ReturnPathOutput();
            this.DirectoryBrowser = this.global.ReturnDirectoryBrowser();
            this.frondEnd = this.global.ReturnFrondEndLink();
            this.pathServer = this.global.ReturnPathServer();
        }
        [HttpGet("get-list-department-by-user")]
        public List<string> GetListDepartmentByUser()
        {

            try
            {
                var user = GetCurrentUser();
                var cost = user.CostCenter.Split(",");
                var dept = user.Departments.Split(",");
                List<string> result = new List<string>();
                for (int i = 0; i < cost.Length; i++)
                {
                    result.Add(cost[i] + " - " + dept[i]);
                }
                return result;
            }
            catch (Exception e)
            {
                return new List<string>();
            }
        }
        [HttpGet("get-all-list-department")]
        public List<string> GetAllListDepartment()
        {

            try
            {
                List<string> result = new List<string>();
                var listDept = context.AdmMasterDepartments.Where(x => x.Active == true).ToList();
                foreach (var item in listDept)
                {
                    result.Add(item.CostCenter + " - " + item.DeptShortName);
                }
                return result;
            }
            catch (Exception e)
            {
                return new List<string>();
            }
        }
        [HttpGet("get-list-department-by-machine-request")]
        public List<string> GetListDepartmentByMachineRequest()
        {

            try
            {
                return context.BolMachineRequestInfos.Where(x => x.Active == true).Select(x => x.Department).Distinct().ToList();
            }
            catch (Exception e)
            {
                return new List<string>();
            }
        }
        [HttpGet("get-list-place-by-pdc1-delivery")]
        public List<string> GetListPlaceByPdc1Delivery()
        {

            try
            {
                return context.BolPdc1Deliveries.Where(x => x.Active == true).Select(x => x.Department).Distinct().ToList();
            }
            catch (Exception e)
            {
                return new List<string>();
            }
        }
        [HttpGet("get-list-ship-by-dept-delivery")]
        public List<string> GetListShipByDeptDelivery()
        {

            try
            {
                return context.BolDepartmentDeliveries.Where(x => x.Active == true && x.IsHistory == false).Select(x => x.Department).Distinct().ToList();
            }
            catch (Exception e)
            {
                return new List<string>();
            }
        }
        [HttpGet("get-list-ship-by-dept-delivery-history")]
        public List<string> GetListShipByDeptDeliveryHistory()
        {

            try
            {
                return context.BolDepartmentDeliveries.Where(x => x.Active == true && x.IsHistory == true).Select(x => x.Department).Distinct().ToList();
            }
            catch (Exception e)
            {
                return new List<string>();
            }
        }
        [HttpGet("get-list-request-by-dept-delivery")]
        public List<string> GetListRequestByDeptDelivery()
        {

            try
            {
                return context.BolDepartmentDeliveries.Where(x => x.Active == true && x.IsHistory == false).Select(x => x.ApplicationNo).Distinct().ToList();
            }
            catch (Exception e)
            {
                return new List<string>();
            }
        }
        [HttpGet("get-list-request-by-dept-delivery-history")]
        public List<string> GetListRequestByDeptDeliveryHistory()
        {

            try
            {
                return context.BolDepartmentDeliveries.Where(x => x.Active == true && x.IsHistory == true).Select(x => x.ApplicationNo).Distinct().ToList();
            }
            catch (Exception e)
            {
                return new List<string>();
            }
        }
        [HttpGet("get-list-request-by-pdc1-delivery")]
        public List<string> GetListRequestByPdc1Delivery()
        {

            try
            {
                return context.BolPdc1Deliveries.Where(x => x.Active == true).Select(x => x.ApplicationNo).Distinct().ToList();
            }
            catch (Exception e)
            {
                return new List<string>();
            }
        }

        [HttpGet("get-list-department-by-pdc1-delivery-request")]
        public List<string> GetListDepartmentByPdc1DeliveryRequest()
        {

            try
            {
                return context.BolMachineDeliveryInfos.Where(x => x.Active == true).Select(x => x.Department).Distinct().ToList();
            }
            catch (Exception e)
            {
                return new List<string>();
            }
        }
        private UserClaims GetCurrentUser()
        {
            UserClaims userClaims = new UserClaims();
            var identity = HttpContext.User.Identity as ClaimsIdentity;
            if (identity != null)
            {
                userClaims.UserName = identity.FindFirst("user_name") == null ? "Undefined" : identity.FindFirst("user_name").Value;
                userClaims.Id = identity.FindFirst("id") == null ? "Undefined" : identity.FindFirst("id").Value;
                userClaims.DeptId = identity.FindFirst("dept_id") == null ? "" : identity.FindFirst("dept_id").Value;
                userClaims.Factories = identity.FindFirst("factIds") == null ? "" : identity.FindFirst("factIds").Value;
                userClaims.CostCenter = identity.FindFirst("cost_center") == null ? "" : identity.FindFirst("cost_center").Value;
                userClaims.FullName = identity.FindFirst("full_name") == null ? "" : identity.FindFirst("full_name").Value;
                userClaims.Departments = identity.FindFirst("dept") == null ? "" : identity.FindFirst("dept").Value;
                userClaims.Grade = identity.FindFirst("grade") == null ? "" : identity.FindFirst("grade").Value;
                userClaims.IsAdmin = identity.FindFirst("isAdmin") == null ? "false" : identity.FindFirst("isAdmin").Value;
                userClaims.Email = identity.FindFirst("email") == null ? "" : identity.FindFirst("email").Value;
            }
            return userClaims;
        }
        [HttpPost("import-machine-item")]
        public async Task<CommonResponseMachine> ImportMachineItem([FromForm] ImportMachineParam param)
        {
            var result = new CommonResponseMachine()
            {
                Error = false,
                Message = "",
                Status = (int)HttpStatusCode.BadRequest
            };
            try
            {
                var u = GetCurrentUser();
                List<BolMachineRequestItem> list = new List<BolMachineRequestItem>();

                using (var memoStream = new MemoryStream())
                {
                    param.File.CopyTo(memoStream);
                    ExcelPackage.LicenseContext = LicenseContext.NonCommercial;
                    using (var package = new ExcelPackage(memoStream))
                    {
                        var worksheet = package.Workbook.Worksheets[0];

                        var rowCount = worksheet.Dimension?.Rows;
                        var columnCount = worksheet.Dimension?.Columns;
                        if ((param.Category.Equals("Machine") && columnCount == 6) || (param.Category.Equals("Part-units") && columnCount == 7))
                        {
                            if (rowCount.HasValue && rowCount.Value > 2)
                            {

                                for (int row = 2; row <= rowCount.Value; row++)
                                {
                                    if (param.Category.Equals("Machine"))
                                    {
                                        var codeDestination = Convert.ToString(worksheet.Cells[row, 2].Value);
                                        if (codeDestination.IsNullOrEmpty())
                                        {
                                            result.Status = (int)HttpStatusCode.BadRequest;
                                            result.Message = "Code destination don't be blank";
                                            result.Error = true;
                                            return result;
                                        }
                                        var nameDestination = Convert.ToString(worksheet.Cells[row, 3].Value);
                                        if (nameDestination.IsNullOrEmpty())
                                        {
                                            result.Status = (int)HttpStatusCode.BadRequest;
                                            result.Message = "Name destination don't be blank";
                                            result.Error = true;
                                            return result;
                                        }
                                        var qtyStr = Convert.ToString(worksheet.Cells[row, 4].Value);
                                        double qty = 0;
                                        if (qtyStr.IsNullOrEmpty())
                                        {
                                            result.Status = (int)HttpStatusCode.BadRequest;
                                            result.Message = "Qty don't be blank";
                                            result.Error = true;
                                            return result;
                                        }
                                        else
                                        {
                                            qty = double.Parse(qtyStr);
                                        }
                                        DateOnly? expectedDate = null;
                                        try
                                        {
                                            var date = Convert.ToDateTime(worksheet.Cells[row, 5].Value);
                                            expectedDate = DateOnly.FromDateTime(date);
                                        }
                                        catch (Exception)
                                        {
                                            try
                                            {
                                                double d = (double)worksheet.Cells[row, 5].Value;
                                                var date = DateTime.FromOADate(d);
                                                expectedDate = DateOnly.FromDateTime(date);
                                            }
                                            catch (Exception)
                                            {

                                                result.Status = (int)HttpStatusCode.BadRequest;
                                                result.Message = "Expected date wrong format";
                                                result.Error = true;
                                                return result;
                                            }
                                        }
                                        var remark = Convert.ToString(worksheet.Cells[row, 6].Value);
                                        list.Add(new BolMachineRequestItem()
                                        {
                                            CodeDestination = codeDestination,
                                            NameDestination = nameDestination,
                                            Qty = qty,
                                            ExpectedDate = expectedDate,
                                            Remark = remark
                                        });
                                    }
                                    else
                                    {
                                        var partNo = Convert.ToString(worksheet.Cells[row, 2].Value);
                                        if (partNo.IsNullOrEmpty())
                                        {
                                            result.Status = (int)HttpStatusCode.BadRequest;
                                            result.Message = "Part no don't be blank";
                                            result.Error = true;
                                            return result;
                                        }
                                        var partName = Convert.ToString(worksheet.Cells[row, 3].Value);
                                        if (partName.IsNullOrEmpty())
                                        {
                                            result.Status = (int)HttpStatusCode.BadRequest;
                                            result.Message = "Part name don't be blank";
                                            result.Error = true;
                                            return result;
                                        }
                                        var qtyStr = Convert.ToString(worksheet.Cells[row, 4].Value);
                                        double qty = 0;
                                        if (qtyStr.IsNullOrEmpty())
                                        {
                                            result.Status = (int)HttpStatusCode.BadRequest;
                                            result.Message = "Qty don't be blank";
                                            result.Error = true;
                                            return result;
                                        }
                                        else
                                        {
                                            qty = double.Parse(qtyStr);
                                        }
                                        var partLevel = Convert.ToString(worksheet.Cells[row, 5].Value);
                                        if (partLevel.IsNullOrEmpty())
                                        {
                                            result.Status = (int)HttpStatusCode.BadRequest;
                                            result.Message = "Part level don't be blank";
                                            result.Error = true;
                                            return result;
                                        }
                                        var typeDie = Convert.ToString(worksheet.Cells[row, 6].Value).Trim();
                                        DateOnly? expectedDate = null;
                                        try
                                        {
                                            var date = Convert.ToDateTime(worksheet.Cells[row, 7].Value);
                                            expectedDate = DateOnly.FromDateTime(date);
                                        }
                                        catch (Exception)
                                        {
                                            result.Status = (int)HttpStatusCode.BadRequest;
                                            result.Message = "Expected date wrong format";
                                            result.Error = true;
                                            return result;
                                        }
                                        var remark = Convert.ToString(worksheet.Cells[row, 8].Value);
                                        list.Add(new BolMachineRequestItem()
                                        {
                                            PartNo = partNo,
                                            PartName = partName,
                                            Qty = qty,
                                            PartLevel = partLevel,
                                            TypeDie = typeDie.IsNullOrEmpty() ? null : typeDie,
                                            ExpectedDate = expectedDate,
                                            Remark = remark
                                        });
                                    }

                                }
                            }
                        }
                        else
                        {
                            result.Status = (int)HttpStatusCode.BadRequest;
                            result.Message = "Excel file wrong format";
                            result.Error = true;
                            return result;
                        }


                    }
                }
                result.List = list;
                result.Status = (int)HttpStatusCode.OK;
                result.Message = "Success";
                result.Error = false;
                return result;
            }
            catch (Exception e)
            {
                result.Status = (int)HttpStatusCode.BadRequest;
                result.Message = e.Message;
                result.Error = true;
                return result;
            }
        }
        [HttpPost("create-machine-request")]
        public async Task<CommonResponse> CreateMachineRequest(CreateMachineRequestParam rq)
        {
            var res = new CommonResponse()
            {
                Error = false,
                Message = "Successful !",
                Status = 200
            };
            try
            {
                var user = GetCurrentUser();
                var requestNo = GenerationMachineRequestNo();
                context.BolMachineRequestInfos.Add(new BolMachineRequestInfo()
                {
                    RequestNo = requestNo,
                    Department = rq.Dept,
                    Brand = rq.Brand,
                    Factory = rq.Factory,
                    Model = rq.Model,
                    Phase = rq.Phase,
                    Category = rq.Category,
                    UrgentLevel = rq.Level,
                    Purpose = rq.Purpose,
                    CreatedBy = user.UserName
                });
                List<BolMachineRequestItem> listItem = new List<BolMachineRequestItem>();
                foreach (var item in rq.ListMachine)
                {
                    listItem.Add(new BolMachineRequestItem()
                    {
                        RequestNo = requestNo,
                        CodeDestination = item.CodeDestination,
                        NameDestination = item.NameDestination,
                        Qty = item.Qty,
                        ExpectedDate = DateOnly.FromDateTime(item.ExpectedDate.Value),
                        Remark = item.Remark,
                        PartLevel = item.PartLevel,
                        PartNo = item.PartNo,
                        PartName = item.PartName,
                        TypeDie = item.TypeDie
                    });
                }
                context.BolMachineRequestItems.AddRange(listItem);

                context.BolMachineRequestProcesses.Add(new BolMachineRequestProcess()
                {
                    RequestNo = requestNo,
                    ApproveBy = user.UserName,
                    Step = 1,
                    Next = true,
                    CostCenter = rq.Dept.Split("-").First().Trim(),
                    GroupName = "Dept PIC approver (Machine request)",
                    Acknowledger = "PIC"
                });
                context.BolMachineRequestProcesses.Add(new BolMachineRequestProcess()
                {
                    RequestNo = requestNo,
                    Step = 2,
                    Next = false,
                    CostCenter = rq.Dept.Split("-").First().Trim(),
                    GroupName = "Dept MGR approver (Machine request)",
                    Acknowledger = "MGR"
                });
                if (rq.Phase.Equals("DE") && rq.Category.Equals("Machine"))
                {
                    context.BolMachineRequestProcesses.Add(new BolMachineRequestProcess()
                    {
                        RequestNo = requestNo,
                        Step = 3,
                        Next = false,
                        CostCenter = rq.Dept.Split("-").First().Trim(),
                        GroupName = "Dept GM approver (Machine request)",
                        Acknowledger = "GM"
                    });
                    context.BolMachineRequestProcesses.Add(new BolMachineRequestProcess()
                    {
                        RequestNo = requestNo,
                        Step = 4,
                        Next = false,
                        GroupName = "PDC1 PIC confirm (Machine request)",
                        Acknowledger = "PIC",
                        CostCenter = "TS PDC 1"
                    });
                    context.BolMachineRequestProcesses.Add(new BolMachineRequestProcess()
                    {
                        RequestNo = requestNo,
                        Step = 5,
                        Next = false,
                        GroupName = "PDC1 MGR approver (Machine request)",
                        Acknowledger = "MGR",
                        CostCenter = "TS PDC 1"
                    });
                }
                else
                {
                    context.BolMachineRequestProcesses.Add(new BolMachineRequestProcess()
                    {
                        RequestNo = requestNo,
                        Step = 3,
                        Next = false,
                        GroupName = "PDC1 PIC confirm (Machine request)",
                        Acknowledger = "PIC",
                        CostCenter = "TS PDC 1"
                    });
                    context.BolMachineRequestProcesses.Add(new BolMachineRequestProcess()
                    {
                        RequestNo = requestNo,
                        Step = 4,
                        Next = false,
                        GroupName = "PDC1 MGR approver (Machine request)",
                        Acknowledger = "MGR",
                        CostCenter = "TS PDC 1"
                    });
                }

                context.SaveChanges();
                res.Error = false;
                res.Message = requestNo;
                res.Status = 200;
            }
            catch (Exception e)
            {
                //SendMailError(e);
                res.Error = true;
                res.Message = e.Message;
                res.Status = 400;
            }
            return res;
        }
        private string GenerationMachineRequestNo()
        {
            var date = DateTime.Now.ToString("yyMM");
            var request = context.BolMachineRequestInfos.Where(x => x.Active == true && x.RequestNo.StartsWith("PDC1-" + date)).OrderByDescending(x => x.RequestNo).FirstOrDefault();
            if (request != null)
            {
                var number = int.Parse(request.RequestNo.Split("-").Last()) + 1;
                var numberStr = "";
                for (int i = 0; i < (5 - number.ToString().Length); i++)
                {
                    numberStr += "0";
                }
                return "PDC1-" + date + "-" + numberStr + number.ToString();
            }
            else
            {
                return "PDC1-" + date + "-00001";
            }
        }
        private string GenerationDeliveryRequestNo()
        {
            var date = DateTime.Now.ToString("yyMM");
            var request = context.BolMachineDeliveryInfos.Where(x => x.Active == true && x.RequestNo.StartsWith("PDC1-DLV-" + date)).OrderByDescending(x => x.RequestNo).FirstOrDefault();
            if (request != null)
            {
                var number = int.Parse(request.RequestNo.Split("-").Last()) + 1;
                var numberStr = "";
                for (int i = 0; i < (5 - number.ToString().Length); i++)
                {
                    numberStr += "0";
                }
                return "PDC1-DLV-" + date + "-" + numberStr + number.ToString();
            }
            else
            {
                return "PDC1-DLV-" + date + "-00001";
            }
        }
        private string GenerationDeptDeliveryRequestNo()
        {
            var date = DateTime.Now.ToString("yyMM");
            var request = context.BolDepartmentDeliveryInfos.Where(x => x.Active == true && x.RequestNo.StartsWith("DEPT-DLV-" + date)).OrderByDescending(x => x.RequestNo).FirstOrDefault();
            if (request != null)
            {
                var number = int.Parse(request.RequestNo.Split("-").Last()) + 1;
                var numberStr = "";
                for (int i = 0; i < (5 - number.ToString().Length); i++)
                {
                    numberStr += "0";
                }
                return "DEPT-DLV-" + date + "-" + numberStr + number.ToString();
            }
            else
            {
                return "DEPT-DLV-" + date + "-00001";
            }
        }
        [HttpGet("get-info-machine-request")]
        public MachineRequestInfoView? GetInfoMachineRequest(string requestNo)
        {

            try
            {
                var info = context.BolMachineRequestInfos.FirstOrDefault(x => x.Active == true && x.RequestNo.Equals(requestNo));
                return new MachineRequestInfoView()
                {
                    CreatedDate = info.CreatedDate.Value.ToString("dd-MM-yyyy"),
                    UrgentLevel = info.UrgentLevel,
                    RequestNo = info.RequestNo,
                    Brand = info.Brand,
                    Model = info.Model,
                    Phase = info.Phase,
                    Category = info.Category,
                    Factory = info.Factory,
                    Purpose = info.Purpose,
                    Status = info.Status,
                    Department = info.Department
                };
            }
            catch (Exception e)
            {
                return null;
            }
        }
        [HttpGet("get-info-pdc1-delivery-request")]
        public Pdc1DeliveryRequestInfoView? GetInfoPdc1DeliveryRequest(string requestNo)
        {

            try
            {
                var info = context.BolMachineDeliveryInfos.FirstOrDefault(x => x.Active == true && x.RequestNo.Equals(requestNo));
                return new Pdc1DeliveryRequestInfoView()
                {
                    CreatedDate = info.CreatedDate.Value.ToString("dd-MM-yyyy"),
                    RequestNo = info.RequestNo,
                    Status = info.Status,
                    Department = info.Department,
                    Requester = info.Requester
                };
            }
            catch (Exception e)
            {
                return null;
            }
        }
        [HttpGet("get-info-dept-delivery-request")]
        public Pdc1DeliveryRequestInfoView? GetInfoDeptDeliveryRequest(string requestNo)
        {

            try
            {
                var info = context.BolDepartmentDeliveryInfos.FirstOrDefault(x => x.Active == true && x.RequestNo.Equals(requestNo));
                return new Pdc1DeliveryRequestInfoView()
                {
                    CreatedDate = info.CreatedDate.Value.ToString("dd-MM-yyyy"),
                    RequestNo = info.RequestNo,
                    Status = info.Status,
                    Department = info.Department,
                    Requester = info.Requester
                };
            }
            catch (Exception e)
            {
                return null;
            }
        }
        [HttpGet("get-item-machine-request")]
        public List<MachineRequestItemView>? GetItemMachineRequest(string requestNo)
        {

            try
            {
                var list = context.BolMachineRequestItems.Where(x => x.Active == true && x.RequestNo.Equals(requestNo)).ToList();
                List<MachineRequestItemView> result = new List<MachineRequestItemView>();
                foreach (var item in list)
                {
                    result.Add(new MachineRequestItemView()
                    {
                        RequestNo = item.RequestNo,
                        CodeDestination = item.CodeDestination,
                        NameDestination = item.NameDestination,
                        Qty = item.Qty,
                        ExpectedDate = item.ExpectedDate.Value.ToString("dd-MM-yyyy"),
                        Remark = item.Remark,
                        PartNo = item.PartNo,
                        PartName = item.PartName,
                        PartLevel = item.PartLevel,
                        TypeDie = item.TypeDie
                    });
                }
                return result;
            }
            catch (Exception e)
            {
                return null;
            }
        }
        [HttpGet("get-item-pdc1-delivery-request")]
        public List<Pdc1DeliveryRequestItemView>? GetItemPdc1DeliveryRequest(string requestNo)
        {

            try
            {
                var list = context.BolMachineDeliveryItems.Where(x => x.Active == true && x.RequestNo.Equals(requestNo)).ToList();
                List<Pdc1DeliveryRequestItemView> result = new List<Pdc1DeliveryRequestItemView>();
                foreach (var item in list)
                {
                    result.Add(new Pdc1DeliveryRequestItemView()
                    {
                        RequestNo = item.RequestNo,
                        ApplicationNo = item.ApplicationNo,
                        Department = item.Department,
                        Model = item.Model,
                        Phase = item.Phase,
                        CodeDestination = item.CodeDestination,
                        NameDestination = item.NameDestination,
                        Qty = item.Qty,
                        ExpectedDate = item.ExpectedDate.Value.ToString("dd-MM-yyyy"),
                        DeliveryDate = item.DeliveryDate.Value.ToString("dd-MM-yyyy"),
                        QtyDelivery = item.QtyDelivery,
                        BodyNo = item.BodyNo,
                        Category = item.Category,
                        PartNo = item.PartNo,
                        PartName = item.PartName,
                        PartLevel = item.PartLevel,
                        TypeDie = item.TypeDie
                    });
                }
                return result;
            }
            catch (Exception e)
            {
                return null;
            }
        }
        [HttpGet("get-item-dept-delivery-request")]
        public List<DeptDeliveryRequestItemView>? GetItemDeptDeliveryRequest(string requestNo)
        {

            try
            {
                var list = context.BolDepartmentDeliveryItems.Where(x => x.Active == true && x.RequestNo.Equals(requestNo)).ToList();
                List<DeptDeliveryRequestItemView> result = new List<DeptDeliveryRequestItemView>();
                foreach (var item in list)
                {
                    result.Add(new DeptDeliveryRequestItemView()
                    {
                        RequestNo = item.RequestNo,
                        ApplicationNo = item.ApplicationNo,
                        ApplicationNoDelivery = item.ApplicationNoDelivery,
                        Department = item.Department,
                        Model = item.Model,
                        Phase = item.Phase,
                        CodeDestination = item.CodeDestination,
                        NameDestination = item.NameDestination,
                        Qty = item.Qty,
                        BodyNo = item.BodyNo,
                        DeliveryDate = item.DeliveryDate.Value.ToString("dd-MM-yyyy"),
                        DeliveryPlace = item.DeliveryPlace,
                        QtyDelivery = item.QtyDelivery,
                        QtyRemain = item.QtyRemain,
                        Category = item.Category,
                        PartNo = item.PartNo,
                        PartName = item.PartName,
                        PartLevel = item.PartLevel,
                        TypeDie = item.TypeDie
                    });
                }
                return result;
            }
            catch (Exception e)
            {
                return null;
            }
        }
        [HttpGet("get-process-machine-request")]
        public List<MachineRequestProcessView>? GetProcessMachineRequest(string requestNo)
        {

            try
            {
                var list = context.BolMachineRequestProcesses.Where(x => x.Active == true && x.RequestNo.Equals(requestNo)).OrderBy(x => x.Step).ToList();
                List<MachineRequestProcessView> result = new List<MachineRequestProcessView>();
                foreach (var item in list)
                {
                    var nameDept = GetDeptByCost(item.CostCenter);
                    result.Add(new MachineRequestProcessView()
                    {
                        RequestNo = item.RequestNo,
                        Acknowledger = item.Acknowledger,
                        ApproveBy = item.ApproveBy.IsNullOrEmpty() ? "" : (item.ApproveBy + " - " + GetNameByCode(item.ApproveBy)),
                        Step = item.Step,
                        Next = item.Next,
                        GroupName = item.GroupName,
                        DateConfirm = item.DateConfirm != null ? item.DateConfirm.Value.ToString("dd-MM-yyyy") : "",
                        CostCenter = item.CostCenter + (nameDept.IsNullOrEmpty() ? "" : (" - " + nameDept)),
                        Comment = item.Comment,
                        Status = !item.Comment.IsNullOrEmpty() ? "Rejected" : (item.Next == true ? "Next" : (item.DateConfirm != null ? "Approved" : "Waiting for Approval"))
                    });
                }
                return result;
            }
            catch (Exception e)
            {
                return null;
            }
        }
        [HttpGet("get-process-pdc1-delivery-request")]
        public List<MachineRequestProcessView>? GetProcessPdc1DeliveryRequest(string requestNo)
        {

            try
            {
                var list = context.BolMachineDeliveryProcesses.Where(x => x.Active == true && x.RequestNo.Equals(requestNo)).OrderBy(x => x.Step).ToList();
                List<MachineRequestProcessView> result = new List<MachineRequestProcessView>();
                foreach (var item in list)
                {
                    var nameDept = GetDeptByCost(item.CostCenter);
                    result.Add(new MachineRequestProcessView()
                    {
                        RequestNo = item.RequestNo,
                        Acknowledger = item.Acknowledger,
                        ApproveBy = item.ApproveBy.IsNullOrEmpty() ? "" : (item.ApproveBy + " - " + GetNameByCode(item.ApproveBy)),
                        Step = item.Step,
                        Next = item.Next,
                        GroupName = item.GroupName,
                        DateConfirm = item.DateConfirm != null ? item.DateConfirm.Value.ToString("dd-MM-yyyy") : "",
                        CostCenter = item.CostCenter + (nameDept.IsNullOrEmpty() ? "" : (" - " + nameDept)),
                        Comment = item.Comment,
                        Status = !item.Comment.IsNullOrEmpty() ? "Returned" : (item.Next == true ? "Next" : (item.DateConfirm != null ? "Approved" : "Waiting for Approval"))
                    });
                }
                return result;
            }
            catch (Exception e)
            {
                return null;
            }
        }
        [HttpGet("get-process-dept-delivery-request")]
        public List<MachineRequestProcessView>? GetProcessDeptDeliveryRequest(string requestNo)
        {

            try
            {
                var list = context.BolDepartmentDeliveryProcesses.Where(x => x.Active == true && x.RequestNo.Equals(requestNo)).OrderBy(x => x.Step).ToList();
                List<MachineRequestProcessView> result = new List<MachineRequestProcessView>();
                foreach (var item in list)
                {
                    var nameDept = GetDeptByCost(item.CostCenter);
                    result.Add(new MachineRequestProcessView()
                    {
                        RequestNo = item.RequestNo,
                        Acknowledger = item.Acknowledger,
                        ApproveBy = item.ApproveBy.IsNullOrEmpty() ? "" : (item.ApproveBy + " - " + GetNameByCode(item.ApproveBy)),
                        Step = item.Step,
                        Next = item.Next,
                        GroupName = item.GroupName,
                        DateConfirm = item.DateConfirm != null ? item.DateConfirm.Value.ToString("dd-MM-yyyy") : "",
                        CostCenter = item.CostCenter + (nameDept.IsNullOrEmpty() ? "" : (" - " + nameDept)),
                        Comment = item.Comment,
                        Status = !item.Comment.IsNullOrEmpty() ? "Returned" : (item.Next == true ? "Next" : (item.DateConfirm != null ? "Approved" : "Waiting for Approval"))
                    });
                }
                return result;
            }
            catch (Exception e)
            {
                return null;
            }
        }
        private string GetNameByCode(string? code)
        {

            try
            {
                var user = context.AdmUserInformations.FirstOrDefault(x => x.Active == true && x.EmployeeCode.Equals(code));
                if (user != null)
                {
                    return user.FullName;
                }
                return "";
            }
            catch (Exception e)
            {
                return "";
            }
        }
        private string GetDeptByCost(string? cost)
        {

            try
            {
                var user = context.AdmMasterDepartments.FirstOrDefault(x => x.Active == true && x.CostCenter.Equals(cost));
                if (user != null)
                {
                    return user.DeptShortName;
                }
                return "";
            }
            catch (Exception e)
            {
                return "";
            }
        }
        [HttpPost("check-approve-machine-request")]
        public bool? CheckApproveMachineRequest(MachineRequestProcessView param)
        {

            try
            {
                var user = GetCurrentUser();
                if (!param.ApproveBy.IsNullOrEmpty())
                {
                    if (user.UserName.Equals(param.ApproveBy.Split("-").First().Trim()))
                    {
                        return true;
                    }
                }
                else
                {
                    var listUser = GetListUserByDeptAndGrade(int.TryParse(param.CostCenter.Split("-").First().Trim(), out var number) ? param.CostCenter.Split("-").First().Trim() : null, param.GroupName).Select(x => x.EmployeeCode).ToList();
                    if (listUser.Count() > 0)
                    {
                        if (listUser.Contains(user.UserName))
                        {
                            return true;
                        }
                    }
                }


                return false;
            }
            catch (Exception e)
            {
                return false;
            }
        }
        [HttpPost("check-approve-pdc1-delivery-request")]
        public bool? CheckApprovPdc1DeliveryRequest(MachineRequestProcessView param)
        {

            try
            {
                var user = GetCurrentUser();
                if (!param.ApproveBy.IsNullOrEmpty())
                {
                    if (user.UserName.Equals(param.ApproveBy.Split("-").First().Trim()))
                    {
                        return true;
                    }
                }
                else
                {
                    var listUser = GetListUserByDeptAndGrade(int.TryParse(param.CostCenter.Split("-").First().Trim(), out var number) ? param.CostCenter.Split("-").First().Trim() : null, param.GroupName).Select(x => x.EmployeeCode).ToList();
                    if (listUser.Count() > 0)
                    {
                        if (listUser.Contains(user.UserName))
                        {
                            return true;
                        }
                    }
                }


                return false;
            }
            catch (Exception e)
            {
                return false;
            }
        }
        private List<AdmUserInformation>? GetListUserByDeptAndGrade(string? dept, string grade)
        {

            try
            {
                List<Guid?> listIdDept = new List<Guid?>();
                List<AdmUserInformation> listUser = new List<AdmUserInformation>();
                var group = context.AdmMasterGroups.FirstOrDefault(x => x.GroupName.Equals(grade));
                var listIdGrade = context.AdmDetailUserGroups.Where(x => x.GroupId == group.Id).Select(x => x.UserId).ToList();
                if (dept != null)
                {
                    var deptId = context.AdmMasterDepartments.FirstOrDefault(x => x.Active == true && x.CostCenter.Equals(dept));
                    if (deptId != null)
                    {
                        listIdDept = context.AdmDetailUserDepts.Where(x => deptId.Id.Equals(x.DeptId)).Select(x => x.UserId).ToList();
                    }

                    listUser = context.AdmUserInformations.Where(x => listIdDept.Contains(x.Id) && listIdGrade.Contains(x.Id)).ToList();
                }
                else
                {
                    listUser = context.AdmUserInformations.Where(x => listIdGrade.Contains(x.Id)).ToList();
                }

                return listUser;
            }
            catch (Exception e)
            {
                return new List<AdmUserInformation>();
            }
        }
        [HttpPost("approve-machine-request")]
        public async Task<CommonResponse> ApproveMachineRequest(ApproveParam param)
        {
            var result = new CommonResponse()
            {
                Error = false,
                Message = "",
                Status = (int)HttpStatusCode.BadRequest
            };
            try
            {
                var user = GetCurrentUser();
                var listProcess = context.BolMachineRequestProcesses.Where(x => x.Active == true && x.RequestNo.Equals(param.RequestNo)).ToList();
                var max = listProcess.Count();
                var process = listProcess.FirstOrDefault(x => x.Active == true && x.RequestNo.Equals(param.RequestNo) && x.Step == param.Step);
                process.Next = false;
                process.ApproveBy = user.UserName;
                process.DateConfirm = DateOnly.FromDateTime(DateTime.Now);
                if (max != param.Step)
                {
                    var processNext = listProcess.FirstOrDefault(x => x.Active == true && x.RequestNo.Equals(param.RequestNo) && x.Step == (param.Step + 1));
                    processNext.Next = true;

                    var group = context.AdmMasterGroups.FirstOrDefault(x => x.GroupName.Equals(processNext.GroupName));
                    List<AdmUserInformation> listUser = new List<AdmUserInformation>();
                    if (group != null)
                    {
                        var listUserId = context.AdmDetailUserGroups.Where(x => x.GroupId == group.Id).Select(x => x.UserId).ToList();
                        List<Guid?> listIdDept = new List<Guid?>();
                        if (int.TryParse(processNext.CostCenter.Split("-").First().Trim(), out var number))
                        {
                            var deptId = context.AdmMasterDepartments.FirstOrDefault(x => x.Active == true && x.CostCenter.Equals(processNext.CostCenter));
                            if (deptId != null)
                            {
                                listIdDept = context.AdmDetailUserDepts.Where(x => deptId.Id.Equals(x.DeptId)).Select(x => x.UserId).ToList();
                            }
                        }
                        if (listIdDept.Count() > 0)
                        {
                            listUser = context.AdmUserInformations.Where(x => listIdDept.Contains(x.Id) && listUserId.Contains(x.Id)).ToList();
                        }
                        else
                        {

                            listUser = context.AdmUserInformations.Where(x => listUserId.Contains(x.Id)).ToList();
                        }
                        var link = this.frondEnd + "/#/detail-machine-request/" + param.RequestNo;
                        string content = "<p style='font-weight: bold;'>Dear Mr/Mrs,</p>";
                        content += "<p>This is notification from PSI SYSTEM- MACHINE REQUEST</p>";
                        content += "<p>Have one request that you need approve:</p>";
                        content += "<p>-\t Request no: " + param.RequestNo + "</p>";
                        content += "<p>Link system: <a href=\"" + link + "\">Click here</a></p>";
                        new EmailService().Initial(listUser.Select(x => x.Email).ToList(), "PSI SYSTEM - MACHINE REQUEST", content);
                    }
                    else
                    {
                        result.Status = (int)HttpStatusCode.BadRequest;
                        result.Message = "Not found '" + processNext.GroupName + "'";
                        result.Error = true;
                        return result;
                    }

                }
                else
                {
                    List<BolPdc1Delivery> listAdd = new List<BolPdc1Delivery>();
                    var listItem = context.BolMachineRequestItems.Where(x => x.Active == true && x.RequestNo.Equals(param.RequestNo)).ToList();
                    var info = context.BolMachineRequestInfos.FirstOrDefault(x => x.Active == true && x.RequestNo.Equals(param.RequestNo));
                    info.Status = 1;
                    foreach (var item in listItem)
                    {
                        if (info.Category.Equals("Machine"))
                        {
                            for (int i = 0; i < item.Qty; i++)
                            {
                                listAdd.Add(new BolPdc1Delivery()
                                {
                                    ApplicationNo = item.RequestNo,
                                    Department = info.Department,
                                    Model = info.Model,
                                    Phase = info.Phase,
                                    CodeDestination = item.CodeDestination,
                                    NameDestination = item.NameDestination,
                                    Qty = 1,
                                    ExpectedDate = item.ExpectedDate,
                                    Category = info.Category,
                                    Brand = info.Brand
                                });
                            }
                        }
                        else
                        {
                            listAdd.Add(new BolPdc1Delivery()
                            {
                                ApplicationNo = item.RequestNo,
                                Department = info.Department,
                                Model = info.Model,
                                Phase = info.Phase,
                                PartNo = item.PartNo,
                                PartName = item.PartName,
                                PartLevel = item.PartLevel,
                                TypeDie = item.TypeDie,
                                Qty = item.Qty,
                                ExpectedDate = item.ExpectedDate,
                                Category = info.Category,
                                Brand = info.Brand
                            });
                        }

                    }
                    context.BolPdc1Deliveries.AddRange(listAdd);
                }

                context.SaveChanges();
                result.Status = (int)HttpStatusCode.OK;
                result.Message = "Success";
                result.Error = false;
                return result;
            }
            catch (Exception e)
            {
                result.Status = (int)HttpStatusCode.BadRequest;
                result.Message = e.Message;
                result.Error = true;
                return result;
            }
        }
        [HttpPost("approve-pdc1-delivery-request")]
        public async Task<CommonResponse> ApprovePdc1DeliveryRequest(ApproveParam param)
        {
            var result = new CommonResponse()
            {
                Error = false,
                Message = "",
                Status = (int)HttpStatusCode.BadRequest
            };
            try
            {
                var user = GetCurrentUser();
                var listProcess = context.BolMachineDeliveryProcesses.Where(x => x.Active == true && x.RequestNo.Equals(param.RequestNo)).ToList();
                var max = listProcess.Count();
                var process = listProcess.FirstOrDefault(x => x.Active == true && x.RequestNo.Equals(param.RequestNo) && x.Step == param.Step);
                process.Next = false;
                process.ApproveBy = user.UserName;
                process.DateConfirm = DateOnly.FromDateTime(DateTime.Now);
                if (max != param.Step)
                {
                    var processNext = listProcess.FirstOrDefault(x => x.Active == true && x.RequestNo.Equals(param.RequestNo) && x.Step == (param.Step + 1));
                    processNext.Next = true;

                    var group = context.AdmMasterGroups.FirstOrDefault(x => x.GroupName.Equals(processNext.GroupName));
                    List<AdmUserInformation> listUser = new List<AdmUserInformation>();
                    if (group != null)
                    {
                        var listUserId = context.AdmDetailUserGroups.Where(x => x.GroupId == group.Id).Select(x => x.UserId).ToList();
                        List<Guid?> listIdDept = new List<Guid?>();
                        if (int.TryParse(processNext.CostCenter.Split("-").First().Trim(), out var number))
                        {
                            var deptId = context.AdmMasterDepartments.FirstOrDefault(x => x.Active == true && x.CostCenter.Equals(processNext.CostCenter));
                            if (deptId != null)
                            {
                                listIdDept = context.AdmDetailUserDepts.Where(x => deptId.Id.Equals(x.DeptId)).Select(x => x.UserId).ToList();
                            }
                        }
                        if (listIdDept.Count() > 0)
                        {
                            listUser = context.AdmUserInformations.Where(x => listIdDept.Contains(x.Id) && listUserId.Contains(x.Id)).ToList();
                        }
                        else
                        {

                            listUser = context.AdmUserInformations.Where(x => listUserId.Contains(x.Id)).ToList();
                        }
                        var link = this.frondEnd + "/#/detail-pdc1-delivery-request/" + param.RequestNo;
                        string content = "<p style='font-weight: bold;'>Dear Mr/Mrs,</p>";
                        content += "<p>This is notification from PSI SYSTEM - PDC1 DElIVERY REQUEST</p>";
                        content += "<p>Have one request that you need approve:</p>";
                        content += "<p>-\t Request no: " + param.RequestNo + "</p>";
                        content += "<p>Link system: <a href=\"" + link + "\">Click here</a></p>";
                        new EmailService().Initial(listUser.Select(x => x.Email).ToList(), "PSI SYSTEM - PDC1 DElIVERY REQUEST", content);
                    }
                    else
                    {
                        result.Status = (int)HttpStatusCode.BadRequest;
                        result.Message = "Not found '" + processNext.GroupName + "'";
                        result.Error = true;
                        return result;
                    }

                }
                else
                {
                    List<BolDepartmentDelivery> listAdd = new List<BolDepartmentDelivery>();
                    List<BolDiscardControl> listDiscard = new List<BolDiscardControl>();
                    var listItemId = context.BolMachineDeliveryItems.Where(x => x.Active == true && x.RequestNo.Equals(param.RequestNo)).Select(x => x.Pdc1DeliveryId).ToList();
                    var listItem = context.BolPdc1Deliveries.Where(x => x.Active == true && listItemId.Contains(x.Id)).ToList();
                    var info = context.BolMachineDeliveryInfos.FirstOrDefault(x => x.Active == true && x.RequestNo.Equals(param.RequestNo));
                    info.Status = 1;
                    foreach (var item in listItem)
                    {
                        if (item.Category.Equals("Machine"))
                        {
                            for (int i = 0; i < item.Qty; i++)
                            {
                                listAdd.Add(new BolDepartmentDelivery()
                                {
                                    ApplicationNo = item.ApplicationNo,
                                    Department = item.Department,
                                    Model = item.Model,
                                    Phase = item.Phase,
                                    CodeDestination = item.CodeDestination,
                                    NameDestination = item.NameDestination,
                                    BodyNo = item.BodyNo,
                                    Qty = item.QtyDelivery,
                                    QtyDelivery = item.QtyDelivery,
                                    QtyRemain = item.QtyDelivery,
                                    Category = item.Category,
                                    Brand = item.Brand,
                                    RequestNo = param.RequestNo
                                });
                            }
                            listDiscard.Add(new BolDiscardControl()
                            {
                                ApplicationNo = item.ApplicationNo,
                                Department = item.Department,
                                Model  = item.Model,
                                Phase = item.Phase,
                                CodeDestination = item.CodeDestination,
                                NameDestination = item.NameDestination,
                                Qty = item.QtyDelivery,
                                ReceivedDate = item.DeliveryDate,
                                BodyNo = item.BodyNo,
                                Category = item.Category,
                                Brand = item.Brand,
                                ApplicationDlvNo = param.RequestNo,
                                CreatedBy = user.UserName
                            });
                        }
                        else
                        {
                            listAdd.Add(new BolDepartmentDelivery()
                            {
                                ApplicationNo = item.ApplicationNo,
                                Department = item.Department,
                                Model = item.Model,
                                Phase = item.Phase,
                                PartNo = item.PartNo,
                                PartName = item.PartName,
                                PartLevel = item.PartLevel,
                                TypeDie = item.TypeDie,
                                Qty = item.QtyDelivery,
                                Category = item.Category,
                                QtyRemain = item.QtyDelivery,
                                Brand = item.Brand,
                                RequestNo = param.RequestNo
                            });
                            listDiscard.Add(new BolDiscardControl()
                            {
                                ApplicationNo = item.ApplicationNo,
                                Department = item.Department,
                                Model = item.Model,
                                Phase = item.Phase,
                                PartNo = item.PartNo,
                                PartName = item.PartName,
                                Qty = item.QtyDelivery,
                                PartLevel = item.PartLevel,
                                TypeDie = item.TypeDie,
                                ReceivedDate = item.DeliveryDate,
                                Category = item.Category,
                                Brand = item.Brand,
                                ApplicationDlvNo = param.RequestNo,
                                CreatedBy = user.UserName
                            });
                        }

                    }
                    context.BolDepartmentDeliveries.AddRange(listAdd);

                }

                context.SaveChanges();
                result.Status = (int)HttpStatusCode.OK;
                result.Message = "Success";
                result.Error = false;
                return result;
            }
            catch (Exception e)
            {
                result.Status = (int)HttpStatusCode.BadRequest;
                result.Message = e.Message;
                result.Error = true;
                return result;
            }
        }
        [HttpPost("approve-dept-delivery-request")]
        public async Task<CommonResponse> ApproveDeptDeliveryRequest(ApproveParam param)
        {
            var result = new CommonResponse()
            {
                Error = false,
                Message = "",
                Status = (int)HttpStatusCode.BadRequest
            };
            try
            {
                var user = GetCurrentUser();
                var listProcess = context.BolDepartmentDeliveryProcesses.Where(x => x.Active == true && x.RequestNo.Equals(param.RequestNo)).ToList();
                var max = listProcess.Count();
                var process = listProcess.FirstOrDefault(x => x.Active == true && x.RequestNo.Equals(param.RequestNo) && x.Step == param.Step);
                process.Next = false;
                process.ApproveBy = user.UserName;
                process.DateConfirm = DateOnly.FromDateTime(DateTime.Now);
                if (max != param.Step)
                {
                    var processNext = listProcess.FirstOrDefault(x => x.Active == true && x.RequestNo.Equals(param.RequestNo) && x.Step == (param.Step + 1));
                    processNext.Next = true;

                    var group = context.AdmMasterGroups.FirstOrDefault(x => x.GroupName.Equals(processNext.GroupName));
                    List<AdmUserInformation> listUser = new List<AdmUserInformation>();
                    if (group != null)
                    {
                        var listUserId = context.AdmDetailUserGroups.Where(x => x.GroupId == group.Id).Select(x => x.UserId).ToList();
                        List<Guid?> listIdDept = new List<Guid?>();
                        if (int.TryParse(processNext.CostCenter.Split("-").First().Trim(), out var number))
                        {
                            var deptId = context.AdmMasterDepartments.FirstOrDefault(x => x.Active == true && x.CostCenter.Equals(processNext.CostCenter));
                            if (deptId != null)
                            {
                                listIdDept = context.AdmDetailUserDepts.Where(x => deptId.Id.Equals(x.DeptId)).Select(x => x.UserId).ToList();
                            }
                        }
                        if (listIdDept.Count() > 0)
                        {
                            listUser = context.AdmUserInformations.Where(x => listIdDept.Contains(x.Id) && listUserId.Contains(x.Id)).ToList();
                        }
                        else
                        {

                            listUser = context.AdmUserInformations.Where(x => listUserId.Contains(x.Id)).ToList();
                        }
                        var link = this.frondEnd + "/#/detail-department-delivery-request/" + param.RequestNo;
                        string content = "<p style='font-weight: bold;'>Dear Mr/Mrs,</p>";
                        content += "<p>This is notification from PSI SYSTEM - DEPARTMENT DELIVERY REQUEST</p>";
                        content += "<p>Have one request that you need approve:</p>";
                        content += "<p>-\t Request no: " + param.RequestNo + "</p>";
                        content += "<p>Link system: <a href=\"" + link + "\">Click here</a></p>";
                        new EmailService().Initial(listUser.Select(x => x.Email).ToList(), "PSI SYSTEM - DEPARTMENT DElIVERY REQUEST", content);
                    }
                    else
                    {
                        result.Status = (int)HttpStatusCode.BadRequest;
                        result.Message = "Not found '" + processNext.GroupName + "'";
                        result.Error = true;
                        return result;
                    }

                }
                else
                {
                    List<BolDepartmentDelivery> listAdd = new List<BolDepartmentDelivery>();
                    var listItemId = context.BolDepartmentDeliveryItems.Where(x => x.Active == true && x.RequestNo.Equals(param.RequestNo)).Select(x => x.DeptDeliveryId).ToList();
                    var listItem = context.BolDepartmentDeliveries.Where(x => x.Active == true && listItemId.Contains(x.Id)).ToList();
                    var info = context.BolMachineDeliveryInfos.FirstOrDefault(x => x.Active == true && x.RequestNo.Equals(param.RequestNo));
                    info.Status = 1;
                    var listDiscard = context.BolDiscardControls.Where(x => x.Active == true).ToList();
                    foreach (var item in listItem)
                    {
                        item.IsHistory = true;
                        if (item.Category.Equals("Machine"))
                        {
                            for (int i = 0; i < item.Qty; i++)
                            {
                                listAdd.Add(new BolDepartmentDelivery()
                                {
                                    ApplicationNo = item.ApplicationNo,
                                    RequestNo = param.RequestNo,                                 
                                    Department = item.DeliveryPlace,
                                    Model = item.Model,
                                    Phase = item.Phase,
                                    CodeDestination = item.CodeDestination,
                                    NameDestination = item.NameDestination,
                                    BodyNo = item.BodyNo,
                                    Qty = item.QtyDelivery,
                                    QtyDelivery = item.QtyDelivery,
                                    Category = item.Category,
                                    Brand = item.Brand
                                });
                            }
                            var dis = listDiscard.FirstOrDefault(x => x.BodyNo.Equals(item.BodyNo) && x.ApplicationDlvNo.Equals(item.RequestNo));
                            if(dis != null)
                            {
                                dis.Department = item.DeliveryPlace;
                                dis.ApplicationDlvNo = param.RequestNo;
                                dis.ReceivedDate = item.DeliveryDate;
                                dis.ModifiedDate = DateTime.Now.SetKindUtc();
                                dis.ModifiedBy = user.UserName;
                            }
                        }
                        else
                        {
                            listAdd.Add(new BolDepartmentDelivery()
                            {
                                ApplicationNo = item.ApplicationNo,
                                RequestNo = param.RequestNo,
                                Department = item.DeliveryPlace,
                                Model = item.Model,
                                Phase = item.Phase,
                                PartNo = item.PartNo,
                                PartName = item.PartName,
                                PartLevel = item.PartLevel,
                                TypeDie = item.TypeDie,
                                Qty = item.QtyDelivery,
                                QtyRemain = item.QtyDelivery,
                                Category = item.Category,
                                Brand = item.Brand,
                            });
                            var dis = listDiscard.FirstOrDefault(x => x.PartNo.Equals(item.PartNo) && x.ApplicationDlvNo.Equals(item.RequestNo) && x.TypeDie.Equals(item.TypeDie) && x.Qty == item.QtyDelivery);
                            if (dis != null)
                            {
                                dis.Department = item.DeliveryPlace;
                                dis.ApplicationDlvNo = param.RequestNo;
                                dis.ReceivedDate = item.DeliveryDate;
                                dis.ModifiedDate = DateTime.Now.SetKindUtc();
                                dis.ModifiedBy = user.UserName;
                            }
                            else
                            {
                                var dis1 = listDiscard.FirstOrDefault(x => x.PartNo.Equals(item.PartNo) && x.ApplicationDlvNo.Equals(item.RequestNo) && x.TypeDie.Equals(item.TypeDie));
                                if(dis1 != null)
                                {
                                    context.BolDiscardControls.Add(new BolDiscardControl()
                                    {
                                        ApplicationNo = dis1.ApplicationNo,
                                        ApplicationDlvNo = dis1.ApplicationDlvNo,
                                        Department = dis1.Department,
                                        Model = dis1.Model,
                                        Phase = dis1.Phase,
                                        PartNo = dis1.PartNo,
                                        PartName = dis1.PartName,
                                        Qty = dis1.Qty - item.QtyDelivery,
                                        PartLevel = dis1.PartLevel,
                                        TypeDie = dis1.TypeDie,
                                        ReceivedDate = dis1.ReceivedDate,
                                        DeadlineDisposal = dis1.DeadlineDisposal,
                                        CreatedBy = user.UserName
                                    });
                                    dis1.Department = item.DeliveryPlace;
                                    dis1.ApplicationDlvNo = param.RequestNo;
                                    dis1.Qty = item.QtyDelivery;
                                    dis1.ReceivedDate = item.DeliveryDate;
                                    dis1.ModifiedDate = DateTime.Now.SetKindUtc();
                                    dis1.ModifiedBy = user.UserName;
                                }
                               
                            }
                        }

                    }
                    context.BolDepartmentDeliveries.AddRange(listAdd);
                }

                context.SaveChanges();
                result.Status = (int)HttpStatusCode.OK;
                result.Message = "Success";
                result.Error = false;
                return result;
            }
            catch (Exception e)
            {
                result.Status = (int)HttpStatusCode.BadRequest;
                result.Message = e.Message;
                result.Error = true;
                return result;
            }
        }
        [HttpPost("filter-machine-request-summary")]
        public MachineRequestSummaryModel FilterMachineRequestSummary(SummaryParam param)
        {
            try
            {
                var result = new MachineRequestSummaryModel();
                var lstResult = new List<MachineRequestSummary>();

                var model = context.BolMachineRequestInfos.Where(x => x.Active == true).OrderByDescending(x => x.RequestNo).AsQueryable();
                if (!string.IsNullOrEmpty(param.Department)) { model = model.Where(x => x.Department.ToUpper().Equals(param.Department.ToUpper())); }
                if (!string.IsNullOrEmpty(param.Brand)) { model = model.Where(x => x.Brand.ToUpper().Equals(param.Brand.ToUpper())); }
                if (!string.IsNullOrEmpty(param.Factory)) { model = model.Where(x => x.Factory.ToLower().Equals(param.Factory.ToLower())); }
                if (!string.IsNullOrEmpty(param.Model)) { model = model.Where(x => x.Model.ToLower().Contains(param.Model.ToLower())); }
                if (!string.IsNullOrEmpty(param.Phase)) { model = model.Where(x => x.Phase.ToLower().Equals(param.Phase.ToLower())); }
                if (!string.IsNullOrEmpty(param.Category)) { model = model.Where(x => x.Category.ToLower().Contains(param.Category.ToLower())); }
                if (!string.IsNullOrEmpty(param.Status))
                {
                    var ser = param.Status.Equals("Pending") ? 0 : (param.Status.Equals("Finished") ? 1 : (param.Status.Equals("Returned") ? 2 : 3));
                    model = model.Where(x => x.Status == ser);
                }


                var model2 = model.Skip((param.Page - 1) * param.RecordsPerPage).Take(param.RecordsPerPage).ToList();
                var ItemMachine = context.BolMachineRequestItems.Where(x => x.Active == true).AsQueryable();
                var listPdc1 = context.BolPdc1Deliveries.Where(x => x.Active == true).ToList();
                var InfoDelivery = context.BolMachineDeliveryInfos.Where(x => x.Active == true).ToList();
                var ItemDelivery = context.BolMachineDeliveryItems.Where(x => x.Active == true).ToList();

                foreach (var item in model2)
                {

                    var process = context.BolMachineRequestProcesses.Where(x => x.Active == true && x.Next == true && x.RequestNo.Equals(item.RequestNo)).FirstOrDefault();
                    var statusDelivery = "";
                    if (item.Status == 1)
                    {
                        var y = item.Category.Equals("Machine") ? listPdc1.Where(x => x.ApplicationNo.Equals(item.RequestNo)).Count() : ItemMachine.Where(x => x.RequestNo.Equals(item.RequestNo)).Count();
                        var listInfoDelivery = InfoDelivery.Where(x => x.ApplicationNo.Contains(item.RequestNo) && x.Status == 1).Select(x => x.RequestNo).ToList();
                        var x = 0;
                        if (item.Category.Equals("Machine"))
                        {
                            x = ItemDelivery.Where(x => listInfoDelivery.Contains(x.RequestNo) && x.Category.Equals("Machine")).Count();
                            var listDel = listPdc1.Where(x => x.IsDelete == true && x.ApplicationNo.Equals(item.RequestNo)).ToList();
                            x += listDel.Count();
                        }
                        else
                        {
                            var listItem = ItemMachine.Where(x => x.RequestNo.Equals(item.RequestNo)).ToList();
                            var listItemDelivery = ItemDelivery.Where(x => listInfoDelivery.Contains(x.RequestNo) && !x.Category.Equals("Machine")).ToList();
                            var listDel = listPdc1.Where(x => x.IsDelete == true && x.ApplicationNo.Equals(item.RequestNo)).ToList();
                            foreach (var ele in listItem)
                            {
                                var qty = ele.Qty;
                                var qtyDelivery = listItemDelivery.Where(x => x.PartNo.Equals(ele.PartNo)).Sum(x => x.QtyDelivery);
                                var qtyDel = listDel.Where(x => x.PartNo.Equals(ele.PartNo)).Sum(x => x.QtyDelivery != null ? x.QtyDelivery : x.QtyRemain);
                                if (qty == (qtyDelivery + qtyDel))
                                {
                                    x++;
                                }
                            }
                        }
                        statusDelivery = "Finished " + x + "/" + y;
                    }

                    lstResult.Add(new MachineRequestSummary()
                    {
                        ApplicationNo = item.RequestNo,
                        Department = item.Department,
                        Model = item.Model,
                        Phase = item.Phase,
                        NextApproval = process != null ? ((process.CostCenter.Contains("PDC") ? "PDC1 " : "Department ") + process.Acknowledger + " approval") : "",
                        StatusRequest = item.Status == 0 ? "Pending" : (item.Status == 1 ? "Finished" : (item.Status == 2 ? "Returned" : "Rejected")),
                        StatusDelivery = statusDelivery
                    });
                }

                var c = model.Count();
                result.lstModel = lstResult;
                result.toRecord = (int)Math.Min(result.totalRecords, result.currentPage * result.recordPerPage);
                result.totalPage = (int)Math.Ceiling((decimal)c / param.RecordsPerPage);
                result.totalRecords = c;
                result.recordPerPage = param.RecordsPerPage;
                result.currentPage = param.Page;
                result.fromRecord = c == 0 ? 0 : (result.currentPage - 1) * result.recordPerPage + 1;
                return result;
            }
            catch (Exception)
            {
                return new MachineRequestSummaryModel();
            }
        }
        [HttpPost("filter-pdc1-delivery-request")]
        public MachineRequestSummaryModel FilterPdc1DeliveryRequest(Pdc1DeliveryParam param)
        {
            try
            {
                var result = new MachineRequestSummaryModel();
                var lstResult = new List<MachineRequestSummary>();

                var model = context.BolMachineDeliveryInfos.Where(x => x.Active == true).OrderByDescending(x => x.RequestNo).AsQueryable();
                if (!string.IsNullOrEmpty(param.Department)) { model = model.Where(x => x.Department.ToUpper().Equals(param.Department.ToUpper())); }
                if (!string.IsNullOrEmpty(param.ApplicationNo)) { model = model.Where(x => x.RequestNo.ToLower().Contains(param.ApplicationNo.ToLower())); }
                if (!string.IsNullOrEmpty(param.Status))
                {
                    var ser = param.Status.Equals("Pending") ? 0 : (param.Status.Equals("Finished") ? 1 : 3);
                    model = model.Where(x => x.Status == ser && x.RequestNo.ToLower().Contains(param.ApplicationNo.ToLower()));
                }


                var model2 = model.Skip((param.Page - 1) * param.RecordsPerPage).Take(param.RecordsPerPage).ToList();
                foreach (var item in model2)
                {

                    var process = context.BolMachineDeliveryProcesses.Where(x => x.Active == true && x.Next == true && x.RequestNo.Equals(item.RequestNo)).FirstOrDefault();

                    lstResult.Add(new MachineRequestSummary()
                    {
                        ApplicationNo = item.RequestNo,
                        Department = item.Department,
                        NextApproval = process != null ? ((process.CostCenter.Contains("PDC") ? "PDC1 " : "Department ") + process.Acknowledger + " approval") : "",
                        StatusRequest = item.Status == 0 ? "Pending" : (item.Status == 1 ? "Finished" : "Returned"),
                    });
                }

                var c = model.Count();
                result.lstModel = lstResult;
                result.toRecord = (int)Math.Min(result.totalRecords, result.currentPage * result.recordPerPage);
                result.totalPage = (int)Math.Ceiling((decimal)c / param.RecordsPerPage);
                result.totalRecords = c;
                result.recordPerPage = param.RecordsPerPage;
                result.currentPage = param.Page;
                result.fromRecord = c == 0 ? 0 : (result.currentPage - 1) * result.recordPerPage + 1;
                return result;
            }
            catch (Exception)
            {
                return new MachineRequestSummaryModel();
            }
        }
        [HttpPost("filter-dept-delivery-request")]
        public MachineRequestSummaryModel FilterDeptDeliveryRequest(Pdc1DeliveryParam param)
        {
            try
            {
                var result = new MachineRequestSummaryModel();
                var lstResult = new List<MachineRequestSummary>();

                var model = context.BolDepartmentDeliveryInfos.Where(x => x.Active == true).OrderByDescending(x => x.RequestNo).AsQueryable();
                if (!string.IsNullOrEmpty(param.Department)) { model = model.Where(x => x.Department.ToUpper().Equals(param.Department.ToUpper())); }
                if (!string.IsNullOrEmpty(param.ApplicationNo)) { model = model.Where(x => x.RequestNo.ToLower().Contains(param.ApplicationNo.ToLower())); }
                if (!string.IsNullOrEmpty(param.Status))
                {
                    var ser = param.Status.Equals("Pending") ? 0 : (param.Status.Equals("Finished") ? 1 : 3);
                    model = model.Where(x => x.Status == ser && x.RequestNo.ToLower().Contains(param.ApplicationNo.ToLower()));
                }


                var model2 = model.Skip((param.Page - 1) * param.RecordsPerPage).Take(param.RecordsPerPage).ToList();
                foreach (var item in model2)
                {

                    var process = context.BolDepartmentDeliveryProcesses.Where(x => x.Active == true && x.Next == true && x.RequestNo.Equals(item.RequestNo)).FirstOrDefault();

                    lstResult.Add(new MachineRequestSummary()
                    {
                        ApplicationNo = item.RequestNo,
                        Department = item.Department,
                        NextApproval = process != null ? ((process.CostCenter.Contains("PDC") ? "PDC1 " : "Department ") + process.Acknowledger + " approval") : "",
                        StatusRequest = item.Status == 0 ? "Pending" : (item.Status == 1 ? "Finished" : "Returned"),
                    });
                }

                var c = model.Count();
                result.lstModel = lstResult;
                result.toRecord = (int)Math.Min(result.totalRecords, result.currentPage * result.recordPerPage);
                result.totalPage = (int)Math.Ceiling((decimal)c / param.RecordsPerPage);
                result.totalRecords = c;
                result.recordPerPage = param.RecordsPerPage;
                result.currentPage = param.Page;
                result.fromRecord = c == 0 ? 0 : (result.currentPage - 1) * result.recordPerPage + 1;
                return result;
            }
            catch (Exception)
            {
                return new MachineRequestSummaryModel();
            }
        }
        [HttpPost("return-machine-request")]
        public async Task<CommonResponse> ReturnMachineRequest(ApproveParam param)
        {
            var result = new CommonResponse()
            {
                Error = false,
                Message = "",
                Status = (int)HttpStatusCode.BadRequest
            };
            try
            {
                var user = GetCurrentUser();
                var listProcess = context.BolMachineRequestProcesses.Where(x => x.Active == true && x.RequestNo.Equals(param.RequestNo)).ToList();
                var max = listProcess.Count();
                var process = listProcess.FirstOrDefault(x => x.Active == true && x.RequestNo.Equals(param.RequestNo) && x.Step == param.Step);
                process.Next = false;
                process.ApproveBy = user.UserName;
                process.DateConfirm = DateOnly.FromDateTime(DateTime.Now);
                process.Comment = param.Comment;

                var info = context.BolMachineRequestInfos.FirstOrDefault(x => x.Active == true && x.RequestNo.Equals(param.RequestNo));
                info.Status = 2;

                var processFirst = listProcess.FirstOrDefault(x => x.Step == 1);
                process.Next = true;
                process.DateConfirm = null;

                var listUser = context.AdmUserInformations.FirstOrDefault(x => processFirst.ApproveBy.Equals(x.EmployeeCode));

                var link = this.frondEnd + "/#/detail-machine-request/" + param.RequestNo;
                string content = "<p style='font-weight: bold;'>Dear Mr/Mrs,</p>";
                content += "<p>This is notification from PSI SYSTEM- MACHINE REQUEST</p>";
                content += "<p>Have one request that you need approve:</p>";
                content += "<p>-\t Request no: " + param.RequestNo + "</p>";
                content += "<p>Link system: <a href=\"" + link + "\">Click here</a></p>";
                new EmailService().Initial(new List<string>() { listUser.Email }, "PSI SYSTEM - MACHINE REQUEST", content);

                context.SaveChanges();
                result.Status = (int)HttpStatusCode.OK;
                result.Message = "Success";
                result.Error = false;
                return result;
            }
            catch (Exception e)
            {
                result.Status = (int)HttpStatusCode.BadRequest;
                result.Message = e.Message;
                result.Error = true;
                return result;
            }
        }
        [HttpPost("create-machine-request-edit")]
        public async Task<CommonResponse> CreateMachineRequestEdit(CreateMachineRequestParam rq)
        {
            var res = new CommonResponse()
            {
                Error = false,
                Message = "Successful !",
                Status = 200
            };
            try
            {
                var user = GetCurrentUser();
                var requestNo = GenerationMachineRequestNo();
                //var info = context.BolMachineRequestInfos.FirstOrDefault(x => x.Active == true && x.RequestNo.Equals(requestNo));
                //if(info != null)
                //{
                //    info.Department = rq.Dept;
                //    info.Brand = rq.Brand;
                //    info.Factory = rq.Factory;
                //    info.Model = rq.Model;
                //    info.Phase = rq.Phase;
                //    info.Category = rq.Category;
                //    info.UrgentLevel = rq.Level;
                //    info.Purpose = rq.Purpose;
                //    info.ModifiedBy = user.UserName;
                //    info.ModifiedDate = DateTime.Now.SetKindUtc();
                //    info.Status = 0;
                //}
                context.BolMachineRequestInfos.Add(new BolMachineRequestInfo()
                {
                    RequestNo = requestNo,
                    Department = rq.Dept,
                    Brand = rq.Brand,
                    Factory = rq.Factory,
                    Model = rq.Model,
                    Phase = rq.Phase,
                    Category = rq.Category,
                    UrgentLevel = rq.Level,
                    Purpose = rq.Purpose,
                    CreatedBy = user.UserName
                });
                //var itemDel = context.BolMachineRequestItems.Where(x => x.Active == true && x.RequestNo.Equals(requestNo)).ToList();
                //itemDel.ForEach(x => x.Active = false);
                //var processDel = context.BolMachineRequestProcesses.Where(x => x.Active == true && x.RequestNo.Equals(requestNo)).ToList();
                //processDel.ForEach(x => x.Active = false);

                List<BolMachineRequestItem> listItem = new List<BolMachineRequestItem>();
                foreach (var item in rq.ListMachine)
                {
                    listItem.Add(new BolMachineRequestItem()
                    {
                        RequestNo = requestNo,
                        CodeDestination = item.CodeDestination,
                        NameDestination = item.NameDestination,
                        Qty = item.Qty,
                        ExpectedDate = DateOnly.FromDateTime(item.ExpectedDate.Value),
                        Remark = item.Remark,
                        PartLevel = item.PartLevel,
                        PartNo = item.PartNo,
                        PartName = item.PartName,
                        TypeDie = item.TypeDie
                    });
                }
                context.BolMachineRequestItems.AddRange(listItem);

                context.BolMachineRequestProcesses.Add(new BolMachineRequestProcess()
                {
                    RequestNo = requestNo,
                    ApproveBy = user.UserName,
                    Step = 1,
                    Next = true,
                    CostCenter = rq.Dept.Split("-").First().Trim(),
                    GroupName = "Dept PIC approver (Machine request)",
                    Acknowledger = "PIC"
                });
                context.BolMachineRequestProcesses.Add(new BolMachineRequestProcess()
                {
                    RequestNo = requestNo,
                    Step = 2,
                    Next = false,
                    CostCenter = rq.Dept.Split("-").First().Trim(),
                    GroupName = "Dept MGR approver (Machine request)",
                    Acknowledger = "MGR"
                });
                if (rq.Phase.Equals("DE") && rq.Category.Equals("Machine"))
                {
                    context.BolMachineRequestProcesses.Add(new BolMachineRequestProcess()
                    {
                        RequestNo = requestNo,
                        Step = 3,
                        Next = false,
                        CostCenter = rq.Dept.Split("-").First().Trim(),
                        GroupName = "Dept GM approver (Machine request)",
                        Acknowledger = "GM"
                    });
                    context.BolMachineRequestProcesses.Add(new BolMachineRequestProcess()
                    {
                        RequestNo = requestNo,
                        Step = 4,
                        Next = false,
                        GroupName = "PDC1 PIC confirm (Machine request)",
                        Acknowledger = "PIC",
                        CostCenter = "TS PDC 1"
                    });
                    context.BolMachineRequestProcesses.Add(new BolMachineRequestProcess()
                    {
                        RequestNo = requestNo,
                        Step = 5,
                        Next = false,
                        GroupName = "PDC1 MGR approver (Machine request)",
                        Acknowledger = "MGR",
                        CostCenter = "TS PDC 1"
                    });
                }
                else
                {
                    context.BolMachineRequestProcesses.Add(new BolMachineRequestProcess()
                    {
                        RequestNo = requestNo,
                        Step = 3,
                        Next = false,
                        GroupName = "PDC1 PIC confirm (Machine request)",
                        Acknowledger = "PIC",
                        CostCenter = "TS PDC 1"
                    });
                    context.BolMachineRequestProcesses.Add(new BolMachineRequestProcess()
                    {
                        RequestNo = requestNo,
                        Step = 4,
                        Next = false,
                        GroupName = "PDC1 MGR approver (Machine request)",
                        Acknowledger = "MGR",
                        CostCenter = "TS PDC 1"
                    });
                }

                context.SaveChanges();
                res.Error = false;
                res.Message = requestNo;
                res.Status = 200;
            }
            catch (Exception e)
            {
                //SendMailError(e);
                res.Error = true;
                res.Message = e.Message;
                res.Status = 400;
            }
            return res;
        }
        [HttpPost("reject-machine-request")]
        public async Task<CommonResponse> RejectMachineRequest(ApproveParam param)
        {
            var result = new CommonResponse()
            {
                Error = false,
                Message = "",
                Status = (int)HttpStatusCode.BadRequest
            };
            try
            {
                var user = GetCurrentUser();
                var listProcess = context.BolMachineRequestProcesses.Where(x => x.Active == true && x.RequestNo.Equals(param.RequestNo)).ToList();
                var max = listProcess.Count();
                var process = listProcess.FirstOrDefault(x => x.Active == true && x.RequestNo.Equals(param.RequestNo) && x.Step == param.Step);
                process.Next = false;
                process.ApproveBy = user.UserName;
                process.DateConfirm = DateOnly.FromDateTime(DateTime.Now);
                process.Comment = param.Comment;

                var info = context.BolMachineRequestInfos.FirstOrDefault(x => x.Active == true && x.RequestNo.Equals(param.RequestNo));
                info.Status = 3;

                var processFirst = listProcess.FirstOrDefault(x => x.Step == 1);

                var listUser = context.AdmUserInformations.FirstOrDefault(x => processFirst.ApproveBy.Equals(x.EmployeeCode));

                var link = this.frondEnd + "/#/detail-machine-request/" + param.RequestNo;
                string content = "<p style='font-weight: bold;'>Dear Mr/Mrs,</p>";
                content += "<p>This is notification from PSI SYSTEM- MACHINE REQUEST</p>";
                content += "<p>Have one request that you need approve:</p>";
                content += "<p>-\t Request no: " + param.RequestNo + "</p>";
                content += "<p>Link system: <a href=\"" + link + "\">Click here</a></p>";
                new EmailService().Initial(new List<string>() { listUser.Email }, "PSI SYSTEM - MACHINE REQUEST", content);

                context.SaveChanges();
                result.Status = (int)HttpStatusCode.OK;
                result.Message = "Success";
                result.Error = false;
                return result;
            }
            catch (Exception e)
            {
                result.Status = (int)HttpStatusCode.BadRequest;
                result.Message = e.Message;
                result.Error = true;
                return result;
            }
        }
        [HttpPost("reject-pdc11-delivery-request")]
        public async Task<CommonResponse> RejectPdc1DeliveryRequest(ApproveParam param)
        {
            var result = new CommonResponse()
            {
                Error = false,
                Message = "",
                Status = (int)HttpStatusCode.BadRequest
            };
            try
            {
                var user = GetCurrentUser();
                var listProcess = context.BolMachineDeliveryProcesses.Where(x => x.Active == true && x.RequestNo.Equals(param.RequestNo)).ToList();
                var max = listProcess.Count();
                var process = listProcess.FirstOrDefault(x => x.Active == true && x.RequestNo.Equals(param.RequestNo) && x.Step == param.Step);
                process.Next = false;
                process.ApproveBy = user.UserName;
                process.DateConfirm = DateOnly.FromDateTime(DateTime.Now);
                process.Comment = param.Comment;

                var info = context.BolMachineDeliveryInfos.FirstOrDefault(x => x.Active == true && x.RequestNo.Equals(param.RequestNo));
                info.Status = 3;

                var listItem = context.BolMachineDeliveryItems.Where(x => x.Active == true && x.RequestNo.Equals(param.RequestNo));
                var listRemove = new List<Guid>();
                var listBol = context.BolPdc1Deliveries.Where(x => x.Active == true).ToList();
                foreach (var item in listItem)
                {
                    var machine = listBol.FirstOrDefault(x => x.Id == item.Pdc1DeliveryId);
                    if (machine != null)
                    {
                        machine.QtyDelivery = 0;
                        var check = true;
                        var idParent = machine.ParentId;
                        while (check)
                        {
                            var listChild = listBol.FirstOrDefault(x => x.ParentId == idParent);
                            if (listChild == null)
                            {
                                check = false;
                            }
                            else
                            {
                                listRemove.Add(listChild.Id);
                                idParent = listChild.Id;
                            }
                        }
                    }

                }
                var removeMachine = listBol.Where(x => listRemove.Contains(x.Id)).ToList();
                removeMachine.ForEach(x => x.Active = false);

                var processFirst = listProcess.FirstOrDefault(x => x.Step == 1);

                var listUser = context.AdmUserInformations.FirstOrDefault(x => processFirst.ApproveBy.Equals(x.EmployeeCode));

                var link = this.frondEnd + "/#/detail-pdc1-delivery-request/" + param.RequestNo;
                string content = "<p style='font-weight: bold;'>Dear Mr/Mrs,</p>";
                content += "<p>This is notification from PSI SYSTEM- PDC1 DELIVERY REQUEST</p>";
                content += "<p>Have one request that you need approve:</p>";
                content += "<p>-\t Request no: " + param.RequestNo + "</p>";
                content += "<p>Link system: <a href=\"" + link + "\">Click here</a></p>";
                new EmailService().Initial(new List<string>() { listUser.Email }, "PSI SYSTEM - PDC1 DELIVERY REQUEST", content);

                context.SaveChanges();
                result.Status = (int)HttpStatusCode.OK;
                result.Message = "Success";
                result.Error = false;
                return result;
            }
            catch (Exception e)
            {
                result.Status = (int)HttpStatusCode.BadRequest;
                result.Message = e.Message;
                result.Error = true;
                return result;
            }
        }
        [HttpPost("reject-dept-delivery-request")]
        public async Task<CommonResponse> RejectDeptDeliveryRequest(ApproveParam param)
        {
            var result = new CommonResponse()
            {
                Error = false,
                Message = "",
                Status = (int)HttpStatusCode.BadRequest
            };
            try
            {
                var user = GetCurrentUser();
                var listProcess = context.BolDepartmentDeliveryProcesses.Where(x => x.Active == true && x.RequestNo.Equals(param.RequestNo)).ToList();
                var max = listProcess.Count();
                var process = listProcess.FirstOrDefault(x => x.Active == true && x.RequestNo.Equals(param.RequestNo) && x.Step == param.Step);
                process.Next = false;
                process.ApproveBy = user.UserName;
                process.DateConfirm = DateOnly.FromDateTime(DateTime.Now);
                process.Comment = param.Comment;

                var info = context.BolDepartmentDeliveryInfos.FirstOrDefault(x => x.Active == true && x.RequestNo.Equals(param.RequestNo));
                info.Status = 3;

                var listItem = context.BolDepartmentDeliveryItems.Where(x => x.Active == true && x.RequestNo.Equals(param.RequestNo));
                var listRemove = new List<Guid>();
                var listBol = context.BolDepartmentDeliveries.Where(x => x.Active == true).ToList();
                foreach (var item in listItem)
                {
                    var machine = listBol.FirstOrDefault(x => x.Id == item.DeptDeliveryId);
                    if (machine != null)
                    {
                        machine.QtyDelivery = machine.Category.Equals("Machine")? 1: null;
                        machine.QtyRemain = item.QtyDelivery;
                        machine.DeliveryDate = null;
                        machine.DeliveryPlace = null;
                    }

                }

                var processFirst = listProcess.FirstOrDefault(x => x.Step == 1);

                var listUser = context.AdmUserInformations.FirstOrDefault(x => processFirst.ApproveBy.Equals(x.EmployeeCode));

                var link = this.frondEnd + "/#/detail-pdc1-delivery-request/" + param.RequestNo;
                string content = "<p style='font-weight: bold;'>Dear Mr/Mrs,</p>";
                content += "<p>This is notification from PSI SYSTEM- DEPARTMENT DELIVERY REQUEST</p>";
                content += "<p>Have one request that you need approve:</p>";
                content += "<p>-\t Request no: " + param.RequestNo + "</p>";
                content += "<p>Link system: <a href=\"" + link + "\">Click here</a></p>";
                new EmailService().Initial(new List<string>() { listUser.Email }, "PSI SYSTEM - DEPARTMENT DELIVERY REQUEST", content);

                context.SaveChanges();
                result.Status = (int)HttpStatusCode.OK;
                result.Message = "Success";
                result.Error = false;
                return result;
            }
            catch (Exception e)
            {
                result.Status = (int)HttpStatusCode.BadRequest;
                result.Message = e.Message;
                result.Error = true;
                return result;
            }
        }
        [HttpPost("filter-pdc1-delivery-machine")]
        public MachineDeliveryModel FilterPdc1DeliveryMachine(DeliveryParam param)
        {
            try
            {
                var result = new MachineDeliveryModel();
                var lstResult = new List<MachineDelivery>();

                var model = context.BolPdc1Deliveries.Where(x => x.Active == true && x.Category.Equals("Machine")).AsQueryable();
                if (!string.IsNullOrEmpty(param.Model)) { model = model.Where(x => x.Model.ToUpper().Equals(param.Model.ToUpper())); }
                if (!string.IsNullOrEmpty(param.Phase)) { model = model.Where(x => x.Phase.ToLower().Equals(param.Phase.ToLower())); }
                if (!string.IsNullOrEmpty(param.Brand)) { model = model.Where(x => x.Brand.ToUpper().Equals(param.Brand.ToUpper())); }
                if (!string.IsNullOrEmpty(param.DeliveryPlace)) { model = model.Where(x => x.Department.ToLower().Equals(param.DeliveryPlace.ToLower())); }
                if (!string.IsNullOrEmpty(param.CodeDestination)) { model = model.Where(x => x.CodeDestination.ToLower().Contains(param.CodeDestination.ToLower())); }
                if (!string.IsNullOrEmpty(param.ApplicationNo)) { model = model.Where(x => x.ApplicationNo.ToLower().Contains(param.ApplicationNo.ToLower())); }
                if (!string.IsNullOrEmpty(param.DateFrom)) { var TimeFrom = DateOnly.FromDateTime(DateTime.ParseExact(param.DateFrom, "dd-MM-yyyy", null)); model = model.Where(x => x.ExpectedDate >= TimeFrom); }
                if (!string.IsNullOrEmpty(param.DateUntil)) { var TimeFrom = DateOnly.FromDateTime(DateTime.ParseExact(param.DateUntil, "dd-MM-yyyy", null)); model = model.Where(x => x.ExpectedDate <= TimeFrom); }
                var listRequestNo = context.BolMachineDeliveryInfos.Where(x => x.Active == true && (x.Status == 0 || x.Status == 1)).Select(x => x.RequestNo).ToList();
                var listPart = context.BolMachineDeliveryItems.Where(x => x.Active == true && listRequestNo.Contains(x.RequestNo)).Select(x => x.Pdc1DeliveryId).Distinct().ToList();
                if (!string.IsNullOrEmpty(param.Status))
                {
                    if (param.Status.Equals("Finished"))
                    {
                        model = model.Where(x => x.IsDelete == true || listPart.Contains(x.Id));
                    }
                    else if (param.Status.Equals("Delay"))
                    {
                        DateOnly dateNow = DateOnly.FromDateTime(DateTime.Now);
                        model = model.Where(x => x.ExpectedDate < dateNow && x.IsDelete == false && !listPart.Contains(x.Id));
                    }
                    else
                    {
                        DateOnly dateNow = DateOnly.FromDateTime(DateTime.Now);
                        model = model.Where(x => x.ExpectedDate >= dateNow && x.IsDelete == false && !listPart.Contains(x.Id));
                    }
                }


                var model2 = model.Skip((param.Page - 1) * param.RecordsPerPage).Take(param.RecordsPerPage).ToList();

                foreach (var item in model2)
                {
                    List<string> attach = new List<string>();
                    if (!item.Attachment.IsNullOrEmpty())
                    {
                        attach = item.Attachment.Split(';').ToList();
                        attach.RemoveAt(attach.Count - 1);
                    }
                    lstResult.Add(new MachineDelivery()
                    {
                        ApplicationNo = item.ApplicationNo,
                        Department = item.Department,
                        Model = item.Model,
                        Phase = item.Phase,
                        CodeDestination = item.CodeDestination,
                        NameDestination = item.NameDestination,
                        Qty = item.Qty ?? null,
                        ExpectedDate = item.ExpectedDate != null ? item.ExpectedDate.Value.ToString("dd-MMM-yyyy") : "",
                        DeliveryDate = item.DeliveryDate != null ? item.DeliveryDate.Value.ToString("dd-MMM-yyyy") : "",
                        QtyDelivery = item.QtyDelivery ?? null,
                        BodyNo = item.BodyNo,
                        Id = item.Id.ToString(),
                        IsRequest = listPart.Any(x => x == item.Id),
                        IsDelete = item.IsDelete,
                        Reason = item.Reason,
                        Attachment = attach
                    });
                }

                var c = model.Count();
                result.lstModel = lstResult;
                result.toRecord = (int)Math.Min(result.totalRecords, result.currentPage * result.recordPerPage);
                result.totalPage = (int)Math.Ceiling((decimal)c / param.RecordsPerPage);
                result.totalRecords = c;
                result.recordPerPage = param.RecordsPerPage;
                result.currentPage = param.Page;
                result.fromRecord = c == 0 ? 0 : (result.currentPage - 1) * result.recordPerPage + 1;
                return result;
            }
            catch (Exception)
            {
                return new MachineDeliveryModel();
            }
        }
        [HttpPost("filter-department-delivery-machine")]
        public DepartmentDeliveryModel FilterDepartmentDeliveryMachine(DeliveryParam param)
        {
            try
            {
                var result = new DepartmentDeliveryModel();
                var lstResult = new List<DepartmentDelivery>();
                var user = GetCurrentUser();
                var model = context.BolDepartmentDeliveries.Where(x => x.Active == true && x.Category.Equals("Machine") && x.IsHistory == false).AsQueryable();
                if (!user.Departments.Contains("PDC 1") && !user.Departments.Contains("PDC1"))
                {
                    model = model.Where(x => user.CostCenter.Contains(x.Department.Substring(0, 4)));
                }
                if (!string.IsNullOrEmpty(param.Model)) { model = model.Where(x => x.Model.ToUpper().Equals(param.Model.ToUpper())); }
                if (!string.IsNullOrEmpty(param.Phase)) { model = model.Where(x => x.Phase.ToLower().Equals(param.Phase.ToLower())); }
                if (!string.IsNullOrEmpty(param.Brand)) { model = model.Where(x => x.Brand.ToUpper().Equals(param.Brand.ToUpper())); }
                if (!string.IsNullOrEmpty(param.DeliveryPlace)) { model = model.Where(x => x.DeliveryPlace.ToLower().Equals(param.DeliveryPlace.ToLower())); }
                if (!string.IsNullOrEmpty(param.ShipFrom)) { model = model.Where(x => x.Department.ToLower().Equals(param.ShipFrom.ToLower())); }
                if (!string.IsNullOrEmpty(param.CodeDestination)) { model = model.Where(x => x.CodeDestination.ToLower().Contains(param.CodeDestination.ToLower())); }
                if (!string.IsNullOrEmpty(param.ApplicationNo)) { model = model.Where(x => x.ApplicationNo.ToLower().Contains(param.ApplicationNo.ToLower())); }
                if (!string.IsNullOrEmpty(param.DateFrom)) { var TimeFrom = DateOnly.FromDateTime(DateTime.ParseExact(param.DateFrom, "dd-MM-yyyy", null)); model = model.Where(x => x.DeliveryDate >= TimeFrom); }
                if (!string.IsNullOrEmpty(param.DateUntil)) { var TimeFrom = DateOnly.FromDateTime(DateTime.ParseExact(param.DateUntil, "dd-MM-yyyy", null)); model = model.Where(x => x.DeliveryDate <= TimeFrom); }


                var model2 = model.Skip((param.Page - 1) * param.RecordsPerPage).Take(param.RecordsPerPage).ToList();
                var listRequestNo = context.BolDepartmentDeliveryInfos.Where(x => x.Active == true && (x.Status == 0 || x.Status == 1)).Select(x => x.RequestNo).ToList();
                var listPart = context.BolDepartmentDeliveryItems.Where(x => x.Active == true && listRequestNo.Contains(x.RequestNo)).Select(x => x.DeptDeliveryId).Distinct().ToList();

                foreach (var item in model2)
                {
                    lstResult.Add(new DepartmentDelivery()
                    {
                        ApplicationNo = item.ApplicationNo,
                        Department = item.Department,
                        Model = item.Model,
                        Phase = item.Phase,
                        CodeDestination = item.CodeDestination,
                        NameDestination = item.NameDestination,
                        BodyNo = item.BodyNo,
                        QtyDelivery = item.QtyDelivery ?? null,
                        DeliveryDate = item.DeliveryDate != null ? item.DeliveryDate.Value.ToString("dd-MMM-yyyy") : "",
                        ShipFrom = item.ShipFrom,
                        DeliveryPlace = new PlaceObj() { Place = item.DeliveryPlace },
                        Id = item.Id.ToString(),
                        ApplicationNoDelivery = item.RequestNo,
                        IsRequest = listPart.Any(x => x == item.Id),
                    });
                }

                var c = model.Count();
                result.lstModel = lstResult;
                result.toRecord = (int)Math.Min(result.totalRecords, result.currentPage * result.recordPerPage);
                result.totalPage = (int)Math.Ceiling((decimal)c / param.RecordsPerPage);
                result.totalRecords = c;
                result.recordPerPage = param.RecordsPerPage;
                result.currentPage = param.Page;
                result.fromRecord = c == 0 ? 0 : (result.currentPage - 1) * result.recordPerPage + 1;
                return result;
            }
            catch (Exception)
            {
                return new DepartmentDeliveryModel();
            }
        }
        [HttpPost("filter-department-delivery-machine-history")]
        public DepartmentDeliveryModel FilterDepartmentDeliveryMachineHistory(DeliveryParam param)
        {
            try
            {
                var result = new DepartmentDeliveryModel();
                var lstResult = new List<DepartmentDelivery>();
                var user = GetCurrentUser();
                var model = context.BolDepartmentDeliveries.Where(x => x.Active == true && x.Category.Equals("Machine") && x.IsHistory == true).AsQueryable();
                //if (!user.Departments.Contains("PDC 1") && !user.Departments.Contains("PDC1"))
                //{
                //    model = model.Where(x => user.CostCenter.Contains(x.Department.Substring(0, 4)));
                //}
                if (!string.IsNullOrEmpty(param.Model)) { model = model.Where(x => x.Model.ToUpper().Equals(param.Model.ToUpper())); }
                if (!string.IsNullOrEmpty(param.Phase)) { model = model.Where(x => x.Phase.ToLower().Equals(param.Phase.ToLower())); }
                if (!string.IsNullOrEmpty(param.Brand)) { model = model.Where(x => x.Brand.ToUpper().Equals(param.Brand.ToUpper())); }
                if (!string.IsNullOrEmpty(param.DeliveryPlace)) { model = model.Where(x => x.DeliveryPlace.ToLower().Equals(param.DeliveryPlace.ToLower())); }
                if (!string.IsNullOrEmpty(param.ShipFrom)) { model = model.Where(x => x.Department.ToLower().Equals(param.ShipFrom.ToLower())); }
                if (!string.IsNullOrEmpty(param.CodeDestination)) { model = model.Where(x => x.CodeDestination.ToLower().Contains(param.CodeDestination.ToLower())); }
                if (!string.IsNullOrEmpty(param.ApplicationNo)) { model = model.Where(x => x.ApplicationNo.ToLower().Contains(param.ApplicationNo.ToLower())); }
                if (!string.IsNullOrEmpty(param.DateFrom)) { var TimeFrom = DateOnly.FromDateTime(DateTime.ParseExact(param.DateFrom, "dd-MM-yyyy", null)); model = model.Where(x => x.DeliveryDate >= TimeFrom); }
                if (!string.IsNullOrEmpty(param.DateUntil)) { var TimeFrom = DateOnly.FromDateTime(DateTime.ParseExact(param.DateUntil, "dd-MM-yyyy", null)); model = model.Where(x => x.DeliveryDate <= TimeFrom); }


                var model2 = model.Skip((param.Page - 1) * param.RecordsPerPage).Take(param.RecordsPerPage).ToList();
                //var listRequestNo = context.BolDepartmentDeliveryInfos.Where(x => x.Active == true && (x.Status == 0 || x.Status == 1)).Select(x => x.RequestNo).ToList();
                //var listPart = context.BolDepartmentDeliveryItems.Where(x => x.Active == true && listRequestNo.Contains(x.RequestNo)).Select(x => x.DeptDeliveryId).Distinct().ToList();

                foreach (var item in model2)
                {
                    lstResult.Add(new DepartmentDelivery()
                    {
                        ApplicationNo = item.ApplicationNo,
                        Department = item.Department,
                        Model = item.Model,
                        Phase = item.Phase,
                        CodeDestination = item.CodeDestination,
                        NameDestination = item.NameDestination,
                        BodyNo = item.BodyNo,
                        QtyDelivery = item.QtyDelivery ?? null,
                        DeliveryDate = item.DeliveryDate != null ? item.DeliveryDate.Value.ToString("dd-MMM-yyyy") : "",
                        ShipFrom = item.ShipFrom,
                        DeliveryPlaceStr = item.DeliveryPlace,
                        Id = item.Id.ToString(),
                        ApplicationNoDelivery = item.RequestNo,
                        //IsRequest = listPart.Any(x => x == item.Id),
                    });
                }

                var c = model.Count();
                result.lstModel = lstResult;
                result.toRecord = (int)Math.Min(result.totalRecords, result.currentPage * result.recordPerPage);
                result.totalPage = (int)Math.Ceiling((decimal)c / param.RecordsPerPage);
                result.totalRecords = c;
                result.recordPerPage = param.RecordsPerPage;
                result.currentPage = param.Page;
                result.fromRecord = c == 0 ? 0 : (result.currentPage - 1) * result.recordPerPage + 1;
                return result;
            }
            catch (Exception)
            {
                return new DepartmentDeliveryModel();
            }
        }
        [HttpPost("filter-pdc1-delivery-unit")]
        public MachineDeliveryModel FilterPdc1DeliveryUnit(DeliveryParam param)
        {
            try
            {
                var result = new MachineDeliveryModel();
                var lstResult = new List<MachineDelivery>();

                var model = context.BolPdc1Deliveries.Where(x => x.Active == true && !x.Category.Equals("Machine")).AsQueryable();
                if (!string.IsNullOrEmpty(param.Model)) { model = model.Where(x => x.Model.ToUpper().Equals(param.Model.ToUpper())); }
                if (!string.IsNullOrEmpty(param.Phase)) { model = model.Where(x => x.Phase.ToLower().Equals(param.Phase.ToLower())); }
                if (!string.IsNullOrEmpty(param.Brand)) { model = model.Where(x => x.Brand.ToUpper().Equals(param.Brand.ToUpper())); }
                if (!string.IsNullOrEmpty(param.DeliveryPlace)) { model = model.Where(x => x.Department.ToLower().Equals(param.DeliveryPlace.ToLower())); }
                if (!string.IsNullOrEmpty(param.CodeDestination)) { model = model.Where(x => x.PartNo.ToLower().Contains(param.CodeDestination.ToLower())); }
                if (!string.IsNullOrEmpty(param.ApplicationNo)) { model = model.Where(x => x.ApplicationNo.ToLower().Contains(param.ApplicationNo.ToLower())); }
                if (!string.IsNullOrEmpty(param.DateFrom)) { var TimeFrom = DateOnly.FromDateTime(DateTime.ParseExact(param.DateFrom, "dd-MM-yyyy", null)); model = model.Where(x => x.ExpectedDate >= TimeFrom); }
                if (!string.IsNullOrEmpty(param.DateUntil)) { var TimeFrom = DateOnly.FromDateTime(DateTime.ParseExact(param.DateUntil, "dd-MM-yyyy", null)); model = model.Where(x => x.ExpectedDate <= TimeFrom); }
                var listRequestNo = context.BolMachineDeliveryInfos.Where(x => x.Active == true && (x.Status == 0 || x.Status == 1)).Select(x => x.RequestNo).ToList();
                var listPart = context.BolMachineDeliveryItems.Where(x => x.Active == true && listRequestNo.Contains(x.RequestNo)).Select(x => x.Pdc1DeliveryId).Distinct().ToList();
                if (!string.IsNullOrEmpty(param.Status))
                {
                    if (param.Status.Equals("Finished"))
                    {
                        model = model.Where(x => x.IsDelete == true || listPart.Contains(x.Id));
                    }
                    else if (param.Status.Equals("Delay"))
                    {
                        DateOnly dateNow = DateOnly.FromDateTime(DateTime.Now);
                        model = model.Where(x => x.ExpectedDate < dateNow && x.IsDelete == false && !listPart.Contains(x.Id));
                    }
                    else
                    {
                        DateOnly dateNow = DateOnly.FromDateTime(DateTime.Now);
                        model = model.Where(x => x.ExpectedDate >= dateNow && x.IsDelete == false && !listPart.Contains(x.Id));
                    }
                }
                var model2 = model.Skip((param.Page - 1) * param.RecordsPerPage).Take(param.RecordsPerPage).ToList();


                foreach (var item in model2)
                {
                    List<string> attach = new List<string>();
                    if (!item.Attachment.IsNullOrEmpty())
                    {
                        attach = item.Attachment.Split(';').ToList();
                        attach.RemoveAt(attach.Count - 1);
                    }
                    lstResult.Add(new MachineDelivery()
                    {

                        ApplicationNo = item.ApplicationNo,
                        Department = item.Department,
                        Model = item.Model,
                        Phase = item.Phase,
                        PartNo = item.PartNo,
                        PartName = item.PartName,
                        PartLevel = item.PartLevel,
                        TypeDie = item.TypeDie,
                        Qty = item.Qty ?? null,
                        ExpectedDate = item.ExpectedDate != null ? item.ExpectedDate.Value.ToString("dd-MMM-yyyy") : "",
                        DeliveryDate = item.DeliveryDate != null ? item.DeliveryDate.Value.ToString("dd-MMM-yyyy") : "",
                        QtyDelivery = item.QtyDelivery ?? null,
                        BodyNo = item.BodyNo,
                        IsAdd = item.IdAdd,
                        QtyRemain = item.QtyRemain ?? null,
                        Id = item.Id.ToString(),
                        IsRequest = listPart.Any(x => x == item.Id),
                        IsDelete = item.IsDelete,
                        Reason = item.Reason,
                        Attachment = attach
                    });
                }

                var c = model.Count();
                result.lstModel = lstResult;
                result.toRecord = (int)Math.Min(result.totalRecords, result.currentPage * result.recordPerPage);
                result.totalPage = (int)Math.Ceiling((decimal)c / param.RecordsPerPage);
                result.totalRecords = c;
                result.recordPerPage = param.RecordsPerPage;
                result.currentPage = param.Page;
                result.fromRecord = c == 0 ? 0 : (result.currentPage - 1) * result.recordPerPage + 1;
                return result;
            }
            catch (Exception)
            {
                return new MachineDeliveryModel();
            }
        }
        [HttpPost("filter-department-delivery-unit")]
        public DepartmentDeliveryModel FilterDepartmentDeliveryUnit(DeliveryParam param)
        {
            try
            {
                var result = new DepartmentDeliveryModel();
                var lstResult = new List<DepartmentDelivery>();
                var user = GetCurrentUser();
                var model = context.BolDepartmentDeliveries.Where(x => x.Active == true && !x.Category.Equals("Machine") && x.IsHistory == false).AsQueryable();
                if (!user.Departments.Contains("PDC 1") && !user.Departments.Contains("PDC1"))
                {
                    model = model.Where(x => user.CostCenter.Contains(x.Department.Substring(0, 4)));
                }
                if (!string.IsNullOrEmpty(param.Model)) { model = model.Where(x => x.Model.ToUpper().Equals(param.Model.ToUpper())); }
                if (!string.IsNullOrEmpty(param.Phase)) { model = model.Where(x => x.Phase.ToLower().Equals(param.Phase.ToLower())); }
                if (!string.IsNullOrEmpty(param.Brand)) { model = model.Where(x => x.Brand.ToUpper().Equals(param.Brand.ToUpper())); }
                if (!string.IsNullOrEmpty(param.DeliveryPlace)) { model = model.Where(x => x.DeliveryPlace.ToLower().Equals(param.DeliveryPlace.ToLower())); }
                if (!string.IsNullOrEmpty(param.ShipFrom)) { model = model.Where(x => x.Department.ToLower().Equals(param.ShipFrom.ToLower())); }
                if (!string.IsNullOrEmpty(param.CodeDestination)) { model = model.Where(x => x.PartNo.ToLower().Contains(param.CodeDestination.ToLower())); }
                if (!string.IsNullOrEmpty(param.ApplicationNo)) { model = model.Where(x => x.ApplicationNo.ToLower().Contains(param.ApplicationNo.ToLower())); }
                if (!string.IsNullOrEmpty(param.DateFrom)) { var TimeFrom = DateOnly.FromDateTime(DateTime.ParseExact(param.DateFrom, "dd-MM-yyyy", null)); model = model.Where(x => x.DeliveryDate >= TimeFrom); }
                if (!string.IsNullOrEmpty(param.DateUntil)) { var TimeFrom = DateOnly.FromDateTime(DateTime.ParseExact(param.DateUntil, "dd-MM-yyyy", null)); model = model.Where(x => x.DeliveryDate <= TimeFrom); }

                var model2 = model.Skip((param.Page - 1) * param.RecordsPerPage).Take(param.RecordsPerPage).ToList();
                var listRequestNo = context.BolDepartmentDeliveryInfos.Where(x => x.Active == true && (x.Status == 0 || x.Status == 1)).Select(x => x.RequestNo).ToList();
                var listPart = context.BolDepartmentDeliveryItems.Where(x => x.Active == true && listRequestNo.Contains(x.RequestNo)).Select(x => x.DeptDeliveryId).Distinct().ToList();

                foreach (var item in model2)
                {
                    lstResult.Add(new DepartmentDelivery()
                    {

                        ApplicationNo = item.ApplicationNo,
                        Department = item.Department,
                        Model = item.Model,
                        Phase = item.Phase,
                        PartNo = item.PartNo,
                        PartName = item.PartName,
                        Qty = item.Qty ?? null,
                        QtyDelivery = item.QtyDelivery ?? null,
                        QtyRemain = item.QtyRemain ?? null,
                        PartLevel = item.PartLevel,
                        TypeDie = item.TypeDie,
                        DeliveryDate = item.DeliveryDate != null ? item.DeliveryDate.Value.ToString("dd-MMM-yyyy") : "",
                        ShipFrom = item.ShipFrom,
                        DeliveryPlace =new PlaceObj() {Place= item.DeliveryPlace },
                        Id = item.Id.ToString(),
                        ApplicationNoDelivery = item.RequestNo,
                        IsRequest = listPart.Any(x => x == item.Id),
                    });
                }

                var c = model.Count();
                result.lstModel = lstResult;
                result.toRecord = (int)Math.Min(result.totalRecords, result.currentPage * result.recordPerPage);
                result.totalPage = (int)Math.Ceiling((decimal)c / param.RecordsPerPage);
                result.totalRecords = c;
                result.recordPerPage = param.RecordsPerPage;
                result.currentPage = param.Page;
                result.fromRecord = c == 0 ? 0 : (result.currentPage - 1) * result.recordPerPage + 1;
                return result;
            }
            catch (Exception)
            {
                return new DepartmentDeliveryModel();
            }
        }
        [HttpPost("filter-department-delivery-unit-history")]
        public DepartmentDeliveryModel FilterDepartmentDeliveryUnitHistory(DeliveryParam param)
        {
            try
            {
                var result = new DepartmentDeliveryModel();
                var lstResult = new List<DepartmentDelivery>();
                var user = GetCurrentUser();
                var model = context.BolDepartmentDeliveries.Where(x => x.Active == true && !x.Category.Equals("Machine") && x.IsHistory == true).AsQueryable();
                //if (!user.Departments.Contains("PDC 1") && !user.Departments.Contains("PDC1"))
                //{
                //    model = model.Where(x => user.CostCenter.Contains(x.Department.Substring(0, 4)));
                //}
                if (!string.IsNullOrEmpty(param.Model)) { model = model.Where(x => x.Model.ToUpper().Equals(param.Model.ToUpper())); }
                if (!string.IsNullOrEmpty(param.Phase)) { model = model.Where(x => x.Phase.ToLower().Equals(param.Phase.ToLower())); }
                if (!string.IsNullOrEmpty(param.Brand)) { model = model.Where(x => x.Brand.ToUpper().Equals(param.Brand.ToUpper())); }
                if (!string.IsNullOrEmpty(param.DeliveryPlace)) { model = model.Where(x => x.DeliveryPlace.ToLower().Equals(param.DeliveryPlace.ToLower())); }
                if (!string.IsNullOrEmpty(param.ShipFrom)) { model = model.Where(x => x.Department.ToLower().Equals(param.ShipFrom.ToLower())); }
                if (!string.IsNullOrEmpty(param.CodeDestination)) { model = model.Where(x => x.PartNo.ToLower().Contains(param.CodeDestination.ToLower())); }
                if (!string.IsNullOrEmpty(param.ApplicationNo)) { model = model.Where(x => x.ApplicationNo.ToLower().Contains(param.ApplicationNo.ToLower())); }
                if (!string.IsNullOrEmpty(param.DateFrom)) { var TimeFrom = DateOnly.FromDateTime(DateTime.ParseExact(param.DateFrom, "dd-MM-yyyy", null)); model = model.Where(x => x.DeliveryDate >= TimeFrom); }
                if (!string.IsNullOrEmpty(param.DateUntil)) { var TimeFrom = DateOnly.FromDateTime(DateTime.ParseExact(param.DateUntil, "dd-MM-yyyy", null)); model = model.Where(x => x.DeliveryDate <= TimeFrom); }

                var model2 = model.Skip((param.Page - 1) * param.RecordsPerPage).Take(param.RecordsPerPage).ToList();
                //var listRequestNo = context.BolDepartmentDeliveryInfos.Where(x => x.Active == true && (x.Status == 0 || x.Status == 1)).Select(x => x.RequestNo).ToList();
                //var listPart = context.BolDepartmentDeliveryItems.Where(x => x.Active == true && listRequestNo.Contains(x.RequestNo)).Select(x => x.DeptDeliveryId).Distinct().ToList();

                foreach (var item in model2)
                {
                    lstResult.Add(new DepartmentDelivery()
                    {

                        ApplicationNo = item.ApplicationNo,
                        Department = item.Department,
                        Model = item.Model,
                        Phase = item.Phase,
                        PartNo = item.PartNo,
                        PartName = item.PartName,
                        Qty = item.Qty ?? null,
                        QtyDelivery = item.QtyDelivery ?? null,
                        QtyRemain = item.QtyRemain ?? null,
                        PartLevel = item.PartLevel,
                        TypeDie = item.TypeDie,
                        DeliveryDate = item.DeliveryDate != null ? item.DeliveryDate.Value.ToString("dd-MMM-yyyy") : "",
                        ShipFrom = item.ShipFrom,
                        DeliveryPlaceStr =  item.DeliveryPlace,
                        Id = item.Id.ToString(),
                        ApplicationNoDelivery = item.RequestNo,
                        //IsRequest = listPart.Any(x => x == item.Id),
                    });
                }

                var c = model.Count();
                result.lstModel = lstResult;
                result.toRecord = (int)Math.Min(result.totalRecords, result.currentPage * result.recordPerPage);
                result.totalPage = (int)Math.Ceiling((decimal)c / param.RecordsPerPage);
                result.totalRecords = c;
                result.recordPerPage = param.RecordsPerPage;
                result.currentPage = param.Page;
                result.fromRecord = c == 0 ? 0 : (result.currentPage - 1) * result.recordPerPage + 1;
                return result;
            }
            catch (Exception)
            {
                return new DepartmentDeliveryModel();
            }
        }
        [HttpPost("import-pdc1-delivery-machine")]
        public async Task<CommonResponseMachine> ImportPdc1DeliveryMachine([FromForm] ImportMachineParam param)
        {
            var result = new CommonResponseMachine()
            {
                Error = false,
                Message = "",
                Status = (int)HttpStatusCode.BadRequest
            };
            try
            {
                var u = GetCurrentUser();
                List<DeliveryMachineExcel> list = new List<DeliveryMachineExcel>();

                using (var memoStream = new MemoryStream())
                {
                    param.File.CopyTo(memoStream);
                    ExcelPackage.LicenseContext = LicenseContext.NonCommercial;
                    using (var package = new ExcelPackage(memoStream))
                    {
                        var worksheet = package.Workbook.Worksheets[0];

                        var rowCount = worksheet.Dimension?.Rows;
                        var columnCount = worksheet.Dimension?.Columns;

                        if (rowCount.HasValue && rowCount.Value >= 2)
                        {

                            for (int row = 2; row <= rowCount.Value; row++)
                            {

                                var applicationNo = Convert.ToString(worksheet.Cells[row, 1].Value);
                                if (applicationNo.IsNullOrEmpty())
                                {
                                    result.Status = (int)HttpStatusCode.BadRequest;
                                    result.Message = "Application No don't be blank";
                                    result.Error = true;
                                    return result;
                                }
                                var department = Convert.ToString(worksheet.Cells[row, 2].Value);
                                var codeDestination = Convert.ToString(worksheet.Cells[row, 3].Value);
                                if (codeDestination.IsNullOrEmpty())
                                {
                                    result.Status = (int)HttpStatusCode.BadRequest;
                                    result.Message = "Code Destination don't be blank";
                                    result.Error = true;
                                    return result;
                                }
                                var qtyDeliveryStr = Convert.ToString(worksheet.Cells[row, 6].Value);
                                double qtyDelivery = 0;
                                if (qtyDeliveryStr.IsNullOrEmpty())
                                {
                                    result.Status = (int)HttpStatusCode.BadRequest;
                                    result.Message = "Qty delivery don't be blank";
                                    result.Error = true;
                                    return result;
                                }
                                else
                                {
                                    qtyDelivery = double.Parse(qtyDeliveryStr);
                                    if (qtyDelivery > 1)
                                    {
                                        result.Status = (int)HttpStatusCode.BadRequest;
                                        result.Message = "Qty delivery must be less than or equal to 1";
                                        result.Error = true;
                                        return result;
                                    }
                                }
                                DateOnly? deliveryDate = null;
                                try
                                {
                                    var date = Convert.ToDateTime(worksheet.Cells[row, 5].Value);
                                    deliveryDate = DateOnly.FromDateTime(date);
                                }
                                catch (Exception)
                                {
                                    result.Status = (int)HttpStatusCode.BadRequest;
                                    result.Message = "Delivery date wrong format";
                                    result.Error = true;
                                    return result;
                                }
                                var bodyNo = Convert.ToString(worksheet.Cells[row, 7].Value);
                                if (bodyNo.IsNullOrEmpty())
                                {
                                    result.Status = (int)HttpStatusCode.BadRequest;
                                    result.Message = "Body No don't be blank";
                                    result.Error = true;
                                    return result;
                                }

                                list.Add(new DeliveryMachineExcel()
                                {
                                    CodeDestination = codeDestination,
                                    ApplicationNo = applicationNo,
                                    QtyDelivery = qtyDelivery,
                                    DeliveryDate = deliveryDate,
                                    BodyNo = bodyNo
                                });



                            }
                            var listCheck = list.Select(x => x.ApplicationNo + x.CodeDestination).Distinct().ToList();
                            var listDelivery = context.BolPdc1Deliveries.Where(x => x.Active == true).ToList();
                            foreach (var item in listCheck)
                            {
                                var listSame = list.Where(x => (x.ApplicationNo + x.CodeDestination).Equals(item)).ToList();
                                var listUpdate = listDelivery.Where(x => listCheck.Contains((x.ApplicationNo + x.CodeDestination))).ToList();
                                if (listSame.Count() > listUpdate.Count())
                                {
                                    result.Status = (int)HttpStatusCode.BadRequest;
                                    result.Message = "Application: " + listSame.First().ApplicationNo + ", Code destination: " + listSame.First().ApplicationNo + ", redundant data !!!";
                                    result.Error = true;
                                    return result;
                                }
                                else
                                {
                                    for (int i = 0; i < listUpdate.Count(); i++)
                                    {
                                        if (i + 1 > listSame.Count())
                                        {
                                            listUpdate[i].DeliveryDate = null;
                                            listUpdate[i].QtyDelivery = null;
                                            listUpdate[i].BodyNo = null;
                                        }
                                        else
                                        {
                                            listUpdate[i].DeliveryDate = listSame[i].DeliveryDate;
                                            listUpdate[i].QtyDelivery = listSame[i].QtyDelivery;
                                            listUpdate[i].BodyNo = listSame[i].BodyNo;
                                        }
                                    }
                                }
                            }
                            context.SaveChanges();
                        }

                    }
                }
                result.Status = (int)HttpStatusCode.OK;
                result.Message = "Success";
                result.Error = false;
                return result;
            }
            catch (Exception e)
            {
                result.Status = (int)HttpStatusCode.BadRequest;
                result.Message = e.Message;
                result.Error = true;
                return result;
            }
        }
        [HttpPost("save-machine")]
        public CommonResponse SaveMachine([FromBody] SaveMachineParam param)

        {
            CommonResponse res = new CommonResponse()
            {
                Error = false,
                Message = "",
                Status = (int)HttpStatusCode.BadRequest
            };
            try
            {
                var userNow = GetCurrentUser();
                var listMachine = context.BolPdc1Deliveries.Where(x => x.Active == true).ToList();
                foreach (var item in param.ListMachine)
                {
                    var machine = listMachine.FirstOrDefault(x => x.Id.ToString().Equals(item.Id));
                    if (machine != null)
                    {
                        if (item.DeliveryDate != null)
                        {
                            machine.DeliveryDate = DateOnly.FromDateTime(item.DeliveryDate.Value);
                        }
                        machine.QtyDelivery = item.QtyDelivery;
                        machine.BodyNo = item.BodyNo;
                        machine.ModifiedBy = userNow.UserName;
                        machine.ModifiedDate = DateTime.Now.SetKindUtc();
                    }

                }
                foreach (var item in param.ListUnit)
                {
                    List<Guid> listRemove = new List<Guid>();
                    var machine = listMachine.FirstOrDefault(x => x.Id.ToString().Equals(item.Id));

                    if (machine != null)
                    {
                        var check = true;
                        var idParent = machine.Id;
                        while (check)
                        {
                            var listChild = listMachine.FirstOrDefault(x => x.ParentId == idParent);
                            if (listChild == null)
                            {
                                check = false;
                            }
                            else
                            {
                                listRemove.Add(listChild.Id);
                                idParent = listChild.Id;
                            }
                        }
                        var removeMachine = listMachine.Where(x => listRemove.Contains(x.Id)).ToList();
                        removeMachine.ForEach(x => x.Active = false);
                        //context.BolPdc1Deliveries.RemoveRange(removeMachine);
                        if (item.DeliveryDate != null)
                        {
                            machine.DeliveryDate = DateOnly.FromDateTime(item.DeliveryDate.Value);
                        }
                        machine.QtyDelivery = item.QtyDelivery;
                        machine.ModifiedBy = userNow.UserName;
                        machine.ModifiedDate = DateTime.Now.SetKindUtc();
                        if (machine.IdAdd == true)
                        {
                            if (machine.QtyDelivery < machine.QtyRemain)
                            {
                                context.BolPdc1Deliveries.Add(new BolPdc1Delivery()
                                {
                                    ApplicationNo = machine.ApplicationNo,
                                    Department = machine.Department,
                                    Model = machine.Model,
                                    Phase = machine.Phase,
                                    CodeDestination = machine.CodeDestination,
                                    NameDestination = machine.NameDestination,
                                    Qty = machine.Qty,
                                    ExpectedDate = machine.ExpectedDate,
                                    BodyNo = machine.BodyNo,
                                    Category = machine.Category,
                                    Brand = machine.Brand,
                                    PartNo = machine.PartNo,
                                    PartName = machine.PartName,
                                    PartLevel = machine.PartLevel,
                                    TypeDie = machine.TypeDie,
                                    IdAdd = true,
                                    QtyRemain = machine.QtyRemain - machine.QtyDelivery,
                                    ParentId = machine.Id
                                });
                            }
                        }
                        else
                        {
                            if (machine.QtyDelivery < machine.Qty)
                            {
                                context.BolPdc1Deliveries.Add(new BolPdc1Delivery()
                                {
                                    ApplicationNo = machine.ApplicationNo,
                                    Department = machine.Department,
                                    Model = machine.Model,
                                    Phase = machine.Phase,
                                    CodeDestination = machine.CodeDestination,
                                    NameDestination = machine.NameDestination,
                                    Qty = machine.Qty,
                                    ExpectedDate = machine.ExpectedDate,
                                    BodyNo = machine.BodyNo,
                                    Category = machine.Category,
                                    Brand = machine.Brand,
                                    PartNo = machine.PartNo,
                                    PartName = machine.PartName,
                                    PartLevel = machine.PartLevel,
                                    TypeDie = machine.TypeDie,
                                    IdAdd = true,
                                    QtyRemain = machine.Qty - machine.QtyDelivery,
                                    ParentId = machine.Id
                                });
                            }
                        }
                    }

                }


                context.SaveChanges();

                res.Error = false;
                res.Message = "OK";
                res.Status = (int)HttpStatusCode.OK;


            }
            catch (Exception e)
            {
                res.Error = true;
                res.Message = e.Message;
                res.Status = (int)HttpStatusCode.BadRequest;
            }
            return res;
        }
        [HttpPost("create-delivery-request")]
        public CommonResponse CreateDeliveryRequest([FromBody] SaveMachineParam param)

        {
            CommonResponse res = new CommonResponse()
            {
                Error = false,
                Message = "",
                Status = (int)HttpStatusCode.BadRequest
            };
            try
            {
                //save data
                var userNow = GetCurrentUser();
                var listMachine = context.BolPdc1Deliveries.Where(x => x.Active == true).ToList();
                var listApplicationNo = new List<string>();
                foreach (var item in param.ListMachine)
                {
                    listApplicationNo.Add(item.ApplicationNo);
                    var machine = listMachine.FirstOrDefault(x => x.Id.ToString().Equals(item.Id));
                    if (machine != null)
                    {
                        if (item.DeliveryDate != null)
                        {
                            machine.DeliveryDate = DateOnly.FromDateTime(item.DeliveryDate.Value);
                        }
                        machine.QtyDelivery = item.QtyDelivery;
                        machine.BodyNo = item.BodyNo;
                        machine.ModifiedBy = userNow.UserName;
                        machine.ModifiedDate = DateTime.Now.SetKindUtc();
                    }

                }
                //check th cha có đang trong request pending ko 
                var listRequest = context.BolMachineDeliveryInfos.Where(x => x.Active == true && x.Status == 0).Select(x => x.RequestNo).ToList();
                var listItemPart = context.BolMachineDeliveryItems.Where(x => x.Active == true && listRequest.Contains(x.RequestNo)).Select(x => x.Pdc1DeliveryId).Distinct().ToList();
                foreach (var item in param.ListUnit)
                {
                    var machine = listMachine.FirstOrDefault(x => x.Id.ToString().Equals(item.Id));
                    if (machine.ParentId != null)
                    {
                        var parent = listMachine.FirstOrDefault(x => x.Id.Equals(machine.ParentId));
                        if (listItemPart.Any(x => x == parent.Id))
                        {
                            res.Error = true;
                            res.Message = "Item parent still in pending request";
                            res.Status = (int)HttpStatusCode.BadRequest;
                        }
                    }
                }
                foreach (var item in param.ListUnit)
                {

                    listApplicationNo.Add(item.ApplicationNo);
                    List<Guid> listRemove = new List<Guid>();
                    var machine = listMachine.FirstOrDefault(x => x.Id.ToString().Equals(item.Id));

                    if (machine != null)
                    {
                        if (machine.QtyDelivery != item.QtyDelivery)
                        {
                            var check = true;
                            var idParent = machine.Id;
                            while (check)
                            {
                                var listChild = listMachine.FirstOrDefault(x => x.ParentId == idParent);
                                if (listChild == null)
                                {
                                    check = false;
                                }
                                else
                                {
                                    listRemove.Add(listChild.Id);
                                    idParent = listChild.Id;
                                }
                            }
                            var removeMachine = listMachine.Where(x => listRemove.Contains(x.Id)).ToList();
                            removeMachine.ForEach(x => x.Active = false);

                            if (item.DeliveryDate != null)
                            {
                                machine.DeliveryDate = DateOnly.FromDateTime(item.DeliveryDate.Value);
                            }
                            machine.QtyDelivery = item.QtyDelivery;
                            machine.ModifiedBy = userNow.UserName;
                            machine.ModifiedDate = DateTime.Now.SetKindUtc();
                            if (machine.IdAdd == true)
                            {
                                if (machine.QtyDelivery < machine.QtyRemain)
                                {
                                    context.BolPdc1Deliveries.Add(new BolPdc1Delivery()
                                    {
                                        ApplicationNo = machine.ApplicationNo,
                                        Department = machine.Department,
                                        Model = machine.Model,
                                        Phase = machine.Phase,
                                        CodeDestination = machine.CodeDestination,
                                        NameDestination = machine.NameDestination,
                                        Qty = machine.Qty,
                                        ExpectedDate = machine.ExpectedDate,
                                        BodyNo = machine.BodyNo,
                                        Category = machine.Category,
                                        Brand = machine.Brand,
                                        PartNo = machine.PartNo,
                                        PartName = machine.PartName,
                                        PartLevel = machine.PartLevel,
                                        TypeDie = machine.TypeDie,
                                        IdAdd = true,
                                        QtyRemain = machine.QtyRemain - machine.QtyDelivery,
                                        ParentId = machine.Id
                                    });
                                }
                            }
                            else
                            {
                                if (machine.QtyDelivery < machine.Qty)
                                {
                                    context.BolPdc1Deliveries.Add(new BolPdc1Delivery()
                                    {
                                        ApplicationNo = machine.ApplicationNo,
                                        Department = machine.Department,
                                        Model = machine.Model,
                                        Phase = machine.Phase,
                                        CodeDestination = machine.CodeDestination,
                                        NameDestination = machine.NameDestination,
                                        Qty = machine.Qty,
                                        ExpectedDate = machine.ExpectedDate,
                                        BodyNo = machine.BodyNo,
                                        Category = machine.Category,
                                        Brand = machine.Brand,
                                        PartNo = machine.PartNo,
                                        PartName = machine.PartName,
                                        PartLevel = machine.PartLevel,
                                        TypeDie = machine.TypeDie,
                                        IdAdd = true,
                                        QtyRemain = machine.Qty - machine.QtyDelivery,
                                        ParentId = machine.Id
                                    });
                                }
                            }
                        }

                    }



                }
                //create request
                // nếu apply cả 2 list machine và unit thì sẽ có 2 application no , vậy thì khi sinh ra requestno thì lấy của th nào ??

                var requestNo = GenerationDeliveryRequestNo();
                var costDepartment = param.ListMachine.Count() > 0 ? param.ListMachine.First().Department : param.ListUnit.First().Department;
                context.BolMachineDeliveryInfos.Add(new BolMachineDeliveryInfo()
                {
                    RequestNo = requestNo,
                    Requester = userNow.UserName + " - " + GetNameByCode(userNow.UserName),
                    Department = costDepartment,
                    Status = 0,
                    ApplicationNo = string.Join(",", listApplicationNo.Distinct().ToList()),
                    CreatedBy = userNow.UserName
                });
                List<BolMachineDeliveryItem> listItem = new List<BolMachineDeliveryItem>();
                foreach (var item in param.ListMachine)
                {
                    listItem.Add(new BolMachineDeliveryItem()
                    {
                        RequestNo = requestNo,
                        ApplicationNo = item.ApplicationNo,
                        Department = item.Department,
                        Model = item.Model,
                        Phase = item.Phase,
                        CodeDestination = item.CodeDestination,
                        NameDestination = item.NameDestination,
                        Qty = item.Qty,
                        ExpectedDate = DateOnly.FromDateTime(DateTime.ParseExact(item.ExpectedDate, "dd-MMM-yyyy", null)),
                        DeliveryDate = DateOnly.FromDateTime(item.DeliveryDate.Value),
                        QtyDelivery = item.QtyDelivery,
                        BodyNo = item.BodyNo,
                        CreatedBy = userNow.UserName,
                        Pdc1DeliveryId = Guid.Parse(item.Id),
                        Category = "Machine"
                    });
                }
                foreach (var item in param.ListUnit)
                {
                    listItem.Add(new BolMachineDeliveryItem()
                    {
                        RequestNo = requestNo,
                        ApplicationNo = item.ApplicationNo,
                        Department = item.Department,
                        Model = item.Model,
                        Phase = item.Phase,
                        PartNo = item.PartNo,
                        PartName = item.PartName,
                        Qty = item.Qty,
                        PartLevel = item.PartLevel,
                        TypeDie = item.TypeDie,
                        ExpectedDate = DateOnly.FromDateTime(DateTime.ParseExact(item.ExpectedDate, "dd-MMM-yyyy", null)),
                        DeliveryDate = DateOnly.FromDateTime(item.DeliveryDate.Value),
                        QtyDelivery = item.QtyDelivery,
                        CreatedBy = userNow.UserName,
                        Pdc1DeliveryId = Guid.Parse(item.Id),
                        Category = "Part-units"
                    });
                }
                context.BolMachineDeliveryItems.AddRange(listItem);

                context.BolMachineDeliveryProcesses.Add(new BolMachineDeliveryProcess()
                {
                    RequestNo = requestNo,
                    ApproveBy = userNow.UserName,
                    Step = 1,
                    Next = true,
                    CostCenter = "TS PDC 1",
                    GroupName = "PDC1 PIC request (PDC1 delivery request)",
                    Acknowledger = "PIC"
                });
                var checkDE = false;
                if (param.ListMachine.Count() > 0)
                {
                    if (param.ListMachine.Any(x => x.Phase.Equals("DE")))
                    {
                        checkDE = true;
                    }
                }
                if (checkDE)
                {
                    context.BolMachineDeliveryProcesses.Add(new BolMachineDeliveryProcess()
                    {
                        RequestNo = requestNo,
                        Step = 2,
                        Next = false,
                        CostCenter = "TS PDC 1",
                        GroupName = "PDC1 MGR request (PDC1 delivery request)",
                        Acknowledger = "MGR"
                    });
                }
                else
                {
                    context.BolMachineDeliveryProcesses.Add(new BolMachineDeliveryProcess()
                    {
                        RequestNo = requestNo,
                        Step = 2,
                        Next = false,
                        CostCenter = "TS PDC 1",
                        GroupName = "PDC1 G4up request (PDC1 delivery request)",
                        Acknowledger = "G4up"
                    });
                }
                context.BolMachineDeliveryProcesses.Add(new BolMachineDeliveryProcess()
                {
                    RequestNo = requestNo,
                    Step = 3,
                    Next = false,
                    CostCenter = costDepartment.Split("-").First().Trim(),
                    GroupName = "Dept PIC approver (PDC1 delivery request)",
                    Acknowledger = "PIC"
                });
                context.BolMachineDeliveryProcesses.Add(new BolMachineDeliveryProcess()
                {
                    RequestNo = requestNo,
                    Step = 4,
                    Next = false,
                    CostCenter = costDepartment.Split("-").First().Trim(),
                    GroupName = "Dept MGR approver (PDC1 delivery request)",
                    Acknowledger = "MGR"
                });


                context.SaveChanges();

                res.Error = false;
                res.Message = requestNo;
                res.Status = (int)HttpStatusCode.OK;


            }
            catch (Exception e)
            {
                res.Error = true;
                res.Message = e.Message;
                res.Status = (int)HttpStatusCode.BadRequest;
            }
            return res;
        }
        [HttpPost("save-reason-part-unit")]
        public async Task<CommonResponse> SaveReasonPartUnit([FromForm] DeletePartParam param)
        {
            var result = new CommonResponse()
            {
                Error = false,
                Message = "",
                Status = (int)HttpStatusCode.BadRequest
            };
            try
            {
                var user = GetCurrentUser();
                var listDel = context.BolPdc1Deliveries.Where(x => x.Active == true && x.IsDelete == false).ToList();
                string att = "";
                foreach (var item in param.File)
                {
                    var filePath = Path.Combine(this.outputPathOri + "\\10.BOL EOL\\Attachment", item.FileName);
                    using (var stream = new FileStream(filePath, FileMode.Create))
                    {
                        await item.CopyToAsync(stream);
                    }
                    att += this.DirectoryBrowser + "/attachment_bol_eol/" + item.FileName + ";";
                }
                if (param.Id != null)
                {
                    foreach (var item in param.Id)
                    {
                        if (listDel.Any(x => x.ParentId.ToString().Equals(item)))
                        {
                            result.Status = (int)HttpStatusCode.BadRequest;
                            result.Message = "Any seleted part don't be delete";
                            result.Error = true;
                            return result;
                        }
                        else
                        {
                            var del = listDel.FirstOrDefault(x => x.Id.ToString().Equals(item));
                            if (del != null)
                            {
                                del.IsDelete = true;
                                del.Reason = param.Reason;
                                del.Attachment = att;
                                del.ModifiedDate = DateTime.Now.SetKindUtc();
                                del.ModifiedBy = user.UserName;
                            }
                        }
                    }
                }
                if (param.IdMachine != null)
                {
                    foreach (var item in param.IdMachine)
                    {
                        var del = listDel.FirstOrDefault(x => x.Id.ToString().Equals(item));
                        if (del != null)
                        {
                            del.IsDelete = true;
                            del.Reason = param.Reason;
                            del.Attachment = att;
                            del.ModifiedDate = DateTime.Now.SetKindUtc();
                            del.ModifiedBy = user.UserName;
                        }

                    }

                }
                context.SaveChanges();
                result.Status = (int)HttpStatusCode.OK;
                result.Message = "Success";
                result.Error = false;
                return result;
            }
            catch (Exception e)
            {
                result.Status = (int)HttpStatusCode.BadRequest;
                result.Message = e.Message;
                result.Error = true;
                return result;
            }
        }
        [HttpPost("delete-part-unit")]
        public async Task<CommonResponse> DeletePartUnit(List<string> listId)
        {
            var result = new CommonResponse()
            {
                Error = false,
                Message = "",
                Status = (int)HttpStatusCode.BadRequest
            };
            try
            {
                var user = GetCurrentUser();
                var listDel = context.BolPdc1Deliveries.Where(x => x.Active == true).ToList();
                var listRequestNo = context.BolMachineDeliveryInfos.Where(x => x.Active == true && (x.Status == 0 || x.Status == 1)).Select(x => x.RequestNo).ToList();
                var listPart = context.BolMachineDeliveryItems.Where(x => x.Active == true && listRequestNo.Contains(x.RequestNo)).Select(x => x.Pdc1DeliveryId).Distinct().ToList();

                foreach (var item in listId)
                {
                    if (listDel.Any(x => x.ParentId.ToString().Equals(item)))
                    {
                        result.Status = (int)HttpStatusCode.BadRequest;
                        result.Message = "Any seleted part don't be delete";
                        result.Error = true;
                        return result;
                    }
                    else
                    {
                        var parent = listDel.FirstOrDefault(x => x.Id.ToString().Equals(item));
                        if (listPart.Any(x => x == parent.Id))
                        {
                            result.Status = (int)HttpStatusCode.BadRequest;
                            result.Message = "Any seleted part don't be delete";
                            result.Error = true;
                            return result;
                        }
                        else
                        {
                            parent.QtyDelivery = 0;
                            var del = listDel.FirstOrDefault(x => x.Id.ToString().Equals(item));
                            if (del != null)
                            {
                                del.Active = false;
                                del.ModifiedDate = DateTime.Now.SetKindUtc();
                                del.ModifiedBy = user.UserName;
                            }
                        }
                    }
                }

                context.SaveChanges();
                result.Status = (int)HttpStatusCode.OK;
                result.Message = "Success";
                result.Error = false;
                return result;
            }
            catch (Exception e)
            {
                result.Status = (int)HttpStatusCode.BadRequest;
                result.Message = e.Message;
                result.Error = true;
                return result;
            }
        }
        [HttpPost("create-department-delivery-request")]
        public CommonResponse CreateDepartmentDeliveryRequest([FromBody] SaveDeptParam param)

        {
            CommonResponse res = new CommonResponse()
            {
                Error = false,
                Message = "",
                Status = (int)HttpStatusCode.BadRequest
            };
            try
            {
                //save data
                var userNow = GetCurrentUser();
                var listMachine = context.BolDepartmentDeliveries.Where(x => x.Active == true).ToList();
                var listApplicationNo = new List<string>();
                foreach (var item in param.ListMachine)
                {
                    listApplicationNo.Add(item.ApplicationNo);
                    var machine = listMachine.FirstOrDefault(x => x.Id.ToString().Equals(item.Id));
                    if (machine != null)
                    {
                        if (item.DeliveryDate != null)
                        {
                            machine.DeliveryDate = DateOnly.FromDateTime(item.DeliveryDate.Value);
                        }
                        machine.DeliveryPlace = item.DeliveryPlace.Place;
                        machine.ModifiedBy = userNow.UserName;
                        machine.ModifiedDate = DateTime.Now.SetKindUtc();
                    }

                }
                foreach (var item in param.ListUnit)
                {

                    listApplicationNo.Add(item.ApplicationNo);
                    List<Guid> listRemove = new List<Guid>();
                    var machine = listMachine.FirstOrDefault(x => x.Id.ToString().Equals(item.Id));

                    if (machine != null)
                    {
                        if (machine.Qty >= item.QtyDelivery)
                        {
                            //var check = true;
                            //var idParent = machine.Id;
                            //while (check)
                            //{
                            //    var listChild = listMachine.FirstOrDefault(x => x.ParentId == idParent);
                            //    if (listChild == null)
                            //    {
                            //        check = false;
                            //    }
                            //    else
                            //    {
                            //        listRemove.Add(listChild.Id);
                            //        idParent = listChild.Id;
                            //    }
                            //}
                            //var removeMachine = listMachine.Where(x => listRemove.Contains(x.Id)).ToList();
                            //removeMachine.ForEach(x => x.Active = false);

                            if (item.DeliveryDate != null)
                            {
                                machine.DeliveryDate = DateOnly.FromDateTime(item.DeliveryDate.Value);
                            }
                            machine.QtyDelivery = item.QtyDelivery;
                            machine.DeliveryPlace = item.DeliveryPlace.Place;
                            machine.ModifiedBy = userNow.UserName;
                            machine.ModifiedDate = DateTime.Now.SetKindUtc();
                            if (machine.Qty > item.QtyDelivery)
                            {
                                context.BolDepartmentDeliveries.Add(new BolDepartmentDelivery()
                                {
                                    ApplicationNo = machine.ApplicationNo,
                                    RequestNo = machine.RequestNo,
                                    Department = machine.Department,
                                    Model = machine.Model,
                                    Phase = machine.Phase,
                                    PartNo = machine.PartNo,
                                    PartName = machine.PartName,
                                    Qty = machine.Qty,
                                    QtyRemain = machine.Qty - item.QtyDelivery,
                                    PartLevel = machine.PartLevel,
                                    TypeDie = machine.TypeDie,
                                    Category = machine.Category,
                                    Brand = machine.Brand,
                                    ParentId = machine.Id
                                });

                            }

                        }

                    }



                }
                //create request


                var requestNo = GenerationDeptDeliveryRequestNo();
                var costDepartment = param.ListMachine.Count() > 0 ? param.ListMachine.First().Department : param.ListUnit.First().Department;
                var costPlace = param.ListMachine.Count() > 0 ? param.ListMachine.First().DeliveryPlace.Place : param.ListUnit.First().DeliveryPlace.Place;
                context.BolDepartmentDeliveryInfos.Add(new BolDepartmentDeliveryInfo()
                {
                    RequestNo = requestNo,
                    Requester = userNow.UserName + " - " + GetNameByCode(userNow.UserName),
                    Department = costDepartment,
                    Status = 0,
                    ApplicationNo = string.Join(",", listApplicationNo.Distinct().ToList()),
                    CreatedBy = userNow.UserName
                });
                List<BolDepartmentDeliveryItem> listItem = new List<BolDepartmentDeliveryItem>();
                foreach (var item in param.ListMachine)
                {
                    listItem.Add(new BolDepartmentDeliveryItem()
                    {
                        RequestNo = requestNo,
                        ApplicationNo = item.ApplicationNo,
                        ApplicationNoDelivery = item.ApplicationNoDelivery,
                        Department = item.Department,
                        Model = item.Model,
                        Phase = item.Phase,
                        CodeDestination = item.CodeDestination,
                        NameDestination = item.NameDestination,
                        BodyNo = item.BodyNo,
                        QtyDelivery = item.QtyDelivery,
                        Qty = item.Qty,
                        DeliveryDate = DateOnly.FromDateTime(item.DeliveryDate.Value),
                        DeliveryPlace = item.DeliveryPlace.Place,
                        CreatedBy = userNow.UserName,
                        DeptDeliveryId = Guid.Parse(item.Id),
                        Category = "Machine"
                    });
                }
                foreach (var item in param.ListUnit)
                {
                    listItem.Add(new BolDepartmentDeliveryItem()
                    {
                        RequestNo = requestNo,
                        ApplicationNo = item.ApplicationNo,
                        ApplicationNoDelivery = item.ApplicationNoDelivery,
                        Department = item.Department,
                        Model = item.Model,
                        Phase = item.Phase,
                        PartNo = item.PartNo,
                        PartName = item.PartName,
                        Qty = item.Qty,
                        QtyRemain = item.QtyRemain,
                        PartLevel = item.PartLevel,
                        TypeDie = item.TypeDie,
                        DeliveryDate = DateOnly.FromDateTime(item.DeliveryDate.Value),
                        QtyDelivery = item.QtyDelivery,
                        DeliveryPlace = item.DeliveryPlace.Place,
                        CreatedBy = userNow.UserName,
                        DeptDeliveryId = Guid.Parse(item.Id),
                        Category = "Part-units"
                    });
                }
                context.BolDepartmentDeliveryItems.AddRange(listItem);

                context.BolDepartmentDeliveryProcesses.Add(new BolDepartmentDeliveryProcess()
                {
                    RequestNo = requestNo,
                    ApproveBy = userNow.UserName,
                    Step = 1,
                    Next = true,
                    GroupName = "Requester dept PIC approver (Dept delivery request)",
                    CostCenter = costDepartment.Split("-").First().Trim(),
                    Acknowledger = "PIC"
                });
                var checkDE = false;
                if (param.ListMachine.Count() > 0)
                {
                    if (param.ListMachine.Any(x => x.Phase.Equals("DE")))
                    {
                        checkDE = true;
                    }
                }
                if (checkDE)
                {
                    context.BolDepartmentDeliveryProcesses.Add(new BolDepartmentDeliveryProcess()
                    {
                        RequestNo = requestNo,
                        Step = 2,
                        Next = false,
                        CostCenter = costDepartment.Split("-").First().Trim(),
                        GroupName = "Requester dept MGR approver (Dept delivery request)",
                        Acknowledger = "MGR"
                    });
                }
                else
                {
                    context.BolDepartmentDeliveryProcesses.Add(new BolDepartmentDeliveryProcess()
                    {
                        RequestNo = requestNo,
                        Step = 2,
                        Next = false,
                        CostCenter = costDepartment.Split("-").First().Trim(),
                        GroupName = "Requester dept G4up approver (Dept delivery request)",
                        Acknowledger = "G4up"
                    });
                }
                context.BolDepartmentDeliveryProcesses.Add(new BolDepartmentDeliveryProcess()
                {
                    RequestNo = requestNo,
                    Step = 3,
                    Next = false,
                    CostCenter = costPlace.Split("-").First().Trim(),
                    GroupName = "Receiver dept PIC approver (Dept delivery request)",
                    Acknowledger = "PIC"
                });
                if (checkDE)
                {
                    context.BolDepartmentDeliveryProcesses.Add(new BolDepartmentDeliveryProcess()
                    {
                        RequestNo = requestNo,
                        Step = 4,
                        Next = false,
                        CostCenter = costPlace.Split("-").First().Trim(),
                        GroupName = "Receiver dept MGR approver (Dept delivery request)",
                        Acknowledger = "MGR"
                    });
                }
                else
                {
                    context.BolDepartmentDeliveryProcesses.Add(new BolDepartmentDeliveryProcess()
                    {
                        RequestNo = requestNo,
                        Step = 4,
                        Next = false,
                        CostCenter = costPlace.Split("-").First().Trim(),
                        GroupName = "Receiver dept G4up approver (Dept delivery request)",
                        Acknowledger = "G4up"
                    });
                }


                context.SaveChanges();

                res.Error = false;
                res.Message = requestNo;
                res.Status = (int)HttpStatusCode.OK;


            }
            catch (Exception e)
            {
                res.Error = true;
                res.Message = e.Message;
                res.Status = (int)HttpStatusCode.BadRequest;
            }
            return res;
        }
        [HttpPost("get-info-machine-delivery")]
        public InfoMachine? GetInfoMachineDelivery(string bodyNo, string applicationNo)
        {
            
            try
            {
                InfoMachine result = new InfoMachine();
                var listItem = context.BolDepartmentDeliveryItems.Where(x => x.Active == true && x.ApplicationNoDelivery.Equals(applicationNo) && x.BodyNo.Equals(bodyNo)).ToList();
                if(listItem.Count() == 1)
                {
                    var item = listItem.First();
                    result.Model = item.Model;
                    result.Phase = item.Phase;
                    result.CodeDestination = item.CodeDestination;
                    result.NameDestination = item.NameDestination;
                    result.DeliveryPlace = item.DeliveryPlace;
                    result.QtyDelivery = item.QtyDelivery;
                }
                else
                {
                    var listItem1 = context.BolMachineDeliveryItems.Where(x => x.Active == true && x.RequestNo.Equals(applicationNo) && x.BodyNo.Equals(bodyNo)).ToList();
                    if (listItem1.Count() == 1)
                    {
                        var item1 = listItem1.First();
                        result.Model = item1.Model;
                        result.Phase = item1.Phase;
                        result.CodeDestination = item1.CodeDestination;
                        result.NameDestination = item1.NameDestination;
                        result.DeliveryPlace = item1.Department;
                        result.QtyDelivery = item1.QtyDelivery;
                    }
                }
                return result;
            }
            catch (Exception e)
            {
                return new InfoMachine();
            }
        }
        [HttpPost("get-info-part-delivery")]
        public InfoMachine? GetInfoPartDelivery(string partNo, string applicationNo,string? typeDie)
        {

            try
            {
           
                InfoMachine result = new InfoMachine();
                var listItem = context.BolDepartmentDeliveryItems.Where(x => x.Active == true && x.ApplicationNoDelivery.Equals(applicationNo) && x.PartNo.Equals(partNo) && x.TypeDie.Equals(typeDie)).ToList();
                if (listItem.Count() == 1)
                {
                    var item = listItem.First();
                    result.Model = item.Model;
                    result.Phase = item.Phase;
                    result.NameDestination = item.PartName;
                    result.DeliveryPlace = item.DeliveryPlace;
                    result.QtyDelivery = item.QtyDelivery;
                }
                else
                {
                    var listItem1 = context.BolMachineDeliveryItems.Where(x => x.Active == true && x.RequestNo.Equals(applicationNo) && x.PartNo.Equals(partNo) && x.TypeDie.Equals(typeDie)).ToList();
                    if (listItem1.Count() == 1)
                    {
                        var item1 = listItem1.First();
                        result.Model = item1.Model;
                        result.Phase = item1.Phase;
                        result.NameDestination = item1.NameDestination;
                        result.DeliveryPlace = item1.Department;
                        result.QtyDelivery = item1.QtyDelivery;
                    }
                }
                return result;
            }
            catch (Exception e)
            {
                return new InfoMachine();
            }
        }
        [HttpPost("update-external-data")]
        public CommonResponse? UpdateExternalData(List<ExternalDelivery> list)
        {
            CommonResponse res = new CommonResponse()
            {
                Error = false,
                Message = "",
                Status = (int)HttpStatusCode.BadRequest
            };
            try
            {
                var user = GetCurrentUser();
                List<BolExternalDelivery> listAdd = new List<BolExternalDelivery>();
                foreach (var item in list)
                {
                    Guid? idNew = null;
                    if (item.IdOld.IsNullOrEmpty())
                    {
                        var status = "";
                        if (item.Order.Equals("S-Order") && item.Po.IsNullOrEmpty())
                        {
                            status = "Pending PO";
                        }
                        else if (item.InvNo.IsNullOrEmpty())
                        {
                            status = "Pending Invoice";
                        }
                        else
                        {
                            status = "Finished";
                        }
                        idNew = Guid.NewGuid();
                        listAdd.Add(new BolExternalDelivery()
                        {
                            Id = idNew.Value,
                            Model = item.Model.Model,
                            Phase = item.Phase,
                            CodeDestination = item.CodeDestination,
                            NameDestination = item.NameDestination,
                            BodyNo = item.BodyNo,
                            ApplicationDlvNo = item.ApplicationDlvNo,
                            Order = item.Order,
                            SCode = item.SCode,
                            QtyShip = item.QtyShip,
                            ShipFrom = item.ShipFrom != null? item.ShipFrom.Ship:null,
                            DeliveryPlace = item.DeliveryPlace,
                            Dept = item.Dept,
                            Attn = item.Attn,
                            Po = item.Po,
                            InvNo = item.InvNo,
                            Status = status,
                            Category = item.Category,
                            Brand = item.Brand,
                            TypeDie = item.TypeDie,
                            EtaDeliveryPlace = item.EtaDeliveryPlace.IsNullOrEmpty() ? null : DateOnly.FromDateTime(DateTime.ParseExact(item.EtaDeliveryPlace,"dd-MM-yyyy",null)) ,
                            EtdFactory = item.EtdFactory.IsNullOrEmpty() ? null : DateOnly.FromDateTime(DateTime.ParseExact(item.EtdFactory, "dd-MM-yyyy", null)),
                            EtaPort = item.EtaPort.IsNullOrEmpty() ? null : DateOnly.FromDateTime(DateTime.ParseExact(item.EtaPort, "dd-MM-yyyy", null)),
                            EtdPort = item.EtdPort.IsNullOrEmpty() ? null : DateOnly.FromDateTime(DateTime.ParseExact(item.EtdPort, "dd-MM-yyyy", null)),
                            QtyDelivery = item.QtyDelivery,
                            CreatedBy = user.UserName
                           
                        });
                    }
                    else
                    {
                        idNew =Guid.Parse(item.IdOld);
                        var ex = context.BolExternalDeliveries.FirstOrDefault(x => x.Id.ToString().Equals(item.IdOld));
                        if (ex != null)
                        {
                            if(item.QtyShip > ex.QtyDelivery)
                            {
                                res.Error = true;
                                res.Message = "Qty Ship must be less Qty Delivery";
                                res.Status = (int)HttpStatusCode.BadRequest;
                                return res;
                            }
                            ex.Model = item.Model.Model;
                            ex.Phase = item.Phase;
                            ex.CodeDestination = item.CodeDestination;
                            ex.NameDestination = item.NameDestination;
                            ex.BodyNo = item.BodyNo;
                            ex.ApplicationDlvNo = item.ApplicationDlvNo;
                            ex.TypeDie = item.TypeDie;
                            ex.Order = item.Order;
                            ex.SCode = item.SCode;
                            ex.QtyShip = item.QtyShip;
                            ex.ShipFrom = item.ShipFrom != null ? item.ShipFrom.Ship : null;
                            ex.DeliveryPlace = item.DeliveryPlace;
                            ex.Dept = item.Dept;
                            ex.Attn = item.Attn;
                            ex.Po = item.Po;
                            ex.EtaDeliveryPlace = item.EtaDeliveryPlace.IsNullOrEmpty() ? null : DateOnly.FromDateTime(DateTime.ParseExact(item.EtaDeliveryPlace, "dd-MM-yyyy", null));
                            ex.EtdFactory = item.EtdFactory.IsNullOrEmpty() ? null : DateOnly.FromDateTime(DateTime.ParseExact(item.EtdFactory, "dd-MM-yyyy", null));
                            ex.EtaPort = item.EtaPort.IsNullOrEmpty() ? null : DateOnly.FromDateTime(DateTime.ParseExact(item.EtaPort, "dd-MM-yyyy", null));
                            ex.EtdPort = item.EtdPort.IsNullOrEmpty() ? null : DateOnly.FromDateTime(DateTime.ParseExact(item.EtdPort, "dd-MM-yyyy", null));
                            ex.InvNo = item.InvNo;
                            var status = "";
                            if (item.Order.Equals("S-Order") && item.Po.IsNullOrEmpty())
                            {
                                status = "Pending PO";
                            }
                            else if (item.InvNo.IsNullOrEmpty())
                            {
                                status = "Pending Invoice";
                            }
                            else
                            {
                                status = "Finished";
                            }
                            ex.Status = status;
                        }
                    }
                    if (item.Category.Equals("Machine"))
                    {
                        var dis = context.BolDiscardControls.FirstOrDefault(x => x.BodyNo.Equals(item.BodyNo) && x.ApplicationDlvNo.Equals(item.ApplicationDlvNo));
                        if(dis != null)
                        {
                            if (!item.DeliveryPlace.ToLower().Contains("cvn"))
                            {
                                dis.Active = false;
                            }
                            else
                            {
                                dis.Active = true;
                            }
                        }
                        else
                        {
                            if (item.DeliveryPlace.ToLower().Contains("cvn"))
                            {
                                context.BolDiscardControls.Add(new BolDiscardControl()
                                {
                                    ApplicationDlvNo = item.ApplicationDlvNo,
                                    Department = item.ShipFrom.Ship,
                                    Model = item.Model.Model,
                                    Phase = item.Phase,
                                    CodeDestination = item.CodeDestination,
                                    NameDestination = item.NameDestination,
                                    BodyNo = item.BodyNo,
                                    Qty = item.QtyShip,
                                    Category = item.Category,
                                    Brand = item.Brand,
                                    IdDelivery = idNew
                                });
                            }
                        }
                        
                    }
                    else
                    {
                        var dis = context.BolDiscardControls.FirstOrDefault(x => x.PartNo.Equals(item.CodeDestination) && x.ApplicationDlvNo.Equals(item.ApplicationDlvNo) && x.TypeDie.Equals(item.TypeDie));
                        if (dis != null)
                        {

                            if (!item.DeliveryPlace.ToLower().Contains("cvn"))
                            {
                                dis.Active = false;
                            }
                            else
                            {
                                dis.Active = true;
                            }
                        }
                        else
                        {
                            if (item.DeliveryPlace.ToLower().Contains("cvn"))
                            {
                                context.BolDiscardControls.Add(new BolDiscardControl()
                                {
                                    ApplicationDlvNo = item.ApplicationDlvNo,
                                    Department = item.ShipFrom.Ship,
                                    Model = item.Model.Model,
                                    Phase = item.Phase,
                                    PartNo = item.CodeDestination,
                                    PartName = item.NameDestination,
                                    TypeDie = item.TypeDie,
                                    Qty = item.QtyShip,
                                    Category = item.Category,
                                    Brand = item.Brand,
                                    IdDelivery = idNew
                                });
                            }
                        }
                    }
                    
                }
                context.BolExternalDeliveries.AddRange(listAdd);
                context.SaveChanges();

                res.Error = false;
                res.Message = "Successfully";
                res.Status = (int)HttpStatusCode.OK;
            }
            catch (Exception e)
            {
                res.Error = true;
                res.Message = e.Message;
                res.Status = (int)HttpStatusCode.BadRequest;
            }
            return res;
        }
        [HttpPost("filter-external-delivery")]
        public ExternalDeliveryModel FilterExternalDelivery(ExternalDeliveryParam param)
        {
            try
            {
                var result = new ExternalDeliveryModel();
                var lstResult = new List<ExternalDelivery>();

                var model = context.BolExternalDeliveries.Where(x => x.Active == true).AsQueryable();
                if (!string.IsNullOrEmpty(param.Category)) { model = model.Where(x => x.Category.ToUpper().Equals(param.Category.ToUpper())); }
                if (!string.IsNullOrEmpty(param.Model)) { model = model.Where(x => x.Model.ToUpper().Equals(param.Model.ToUpper())); }
                if (!string.IsNullOrEmpty(param.Phase)) { model = model.Where(x => x.Phase.ToLower().Equals(param.Phase.ToLower())); }
                if (!string.IsNullOrEmpty(param.Brand)) { model = model.Where(x => x.Brand.ToUpper().Equals(param.Brand.ToUpper())); }
                if (!string.IsNullOrEmpty(param.ShipFrom)) { model = model.Where(x => x.ShipFrom.ToUpper().Equals(param.ShipFrom.ToUpper())); }
                if (!string.IsNullOrEmpty(param.DeliveryPlace)) { model = model.Where(x => x.DeliveryPlace.ToLower().Equals(param.DeliveryPlace.ToLower())); }
                if (!string.IsNullOrEmpty(param.CodeDestination)) { model = model.Where(x => x.CodeDestination.ToLower().Contains(param.CodeDestination.ToLower())); }
                if (!string.IsNullOrEmpty(param.InvoiceNo)) { model = model.Where(x => x.InvNo.ToLower().Contains(param.InvoiceNo.ToLower())); }
                if (!string.IsNullOrEmpty(param.PoNo)) { model = model.Where(x => x.Po.ToLower().Contains(param.PoNo.ToLower())); }
                if (!string.IsNullOrEmpty(param.Order)) { model = model.Where(x => x.Order.ToLower().Contains(param.Order.ToLower())); }
                if (!string.IsNullOrEmpty(param.Status)) { model = model.Where(x => x.Status.ToLower().Contains(param.Status.ToLower())); }
            
                var model2 = model.Skip((param.Page - 1) * param.RecordsPerPage).Take(param.RecordsPerPage).ToList();


                foreach (var item in model2)
                {                  
                    lstResult.Add(new ExternalDelivery()
                    {

                        Model = new ModelObj() { Model = item.Model },
                        Phase = item.Phase,
                        CodeDestination = item.CodeDestination,
                        NameDestination = item.NameDestination,
                        BodyNo = item.BodyNo,
                        ApplicationDlvNo = item.ApplicationDlvNo,
                        TypeDie = item.TypeDie,
                        Order = item.Order,
                        SCode = item.SCode,
                        QtyShip = item.QtyShip ?? null,
                        ShipFrom = new ShipObj(){ Ship=item.ShipFrom},
                        DeliveryPlace = item.DeliveryPlace,
                        Dept = item.Dept,
                        Attn = item.Attn,
                        Po = item.Po,
                        EtaDeliveryPlace = item.EtaDeliveryPlace != null ? item.EtaDeliveryPlace.Value.ToString("dd/MM/yyyy"):"",
                        EtdFactory = item.EtdFactory != null ? item.EtdFactory.Value.ToString("dd/MM/yyyy") : "",
                        EtaPort = item.EtaPort != null ? item.EtaPort.Value.ToString("dd/MM/yyyy") : "",
                        EtdPort = item.EtdPort != null ? item.EtdPort.Value.ToString("dd/MM/yyyy") : "",
                        InvNo = item.InvNo,
                        QtyDelivery = item.QtyDelivery ?? null,                  
                        IdOld = item.Id.ToString(),
                        IsNew = false,
                        Id = 0,
                        Status = item.Status,
                        Category = item.Category,
                        Brand = item.Brand
                    });
                }

                var c = model.Count();
                result.lstModel = lstResult;
                result.toRecord = (int)Math.Min(result.totalRecords, result.currentPage * result.recordPerPage);
                result.totalPage = (int)Math.Ceiling((decimal)c / param.RecordsPerPage);
                result.totalRecords = c;
                result.recordPerPage = param.RecordsPerPage;
                result.currentPage = param.Page;
                result.fromRecord = c == 0 ? 0 : (result.currentPage - 1) * result.recordPerPage + 1;
                return result;
            }
            catch (Exception)
            {
                return new ExternalDeliveryModel();
            }
        }
        [HttpPost("import-external-delivery")]
        public async Task<CommonResponse> ImportExternalDelivery([FromForm] ImportMachineParam param)
        {
            var result = new CommonResponse()
            {
                Error = false,
                Message = "",
                Status = (int)HttpStatusCode.BadRequest
            };
            try
            {
                var u = GetCurrentUser();
                List<BolExternalDelivery> list = new List<BolExternalDelivery>();

                using (var memoStream = new MemoryStream())
                {
                    param.File.CopyTo(memoStream);
                    ExcelPackage.LicenseContext = LicenseContext.NonCommercial;
                    using (var package = new ExcelPackage(memoStream))
                    {
                        var worksheet = package.Workbook.Worksheets[0];

                        var rowCount = worksheet.Dimension?.Rows;
                       if (rowCount.HasValue && rowCount.Value > 1)
                       {
                           var listDept = context.AdmMasterDepartments.Where(x => x.Active == true).ToList();
                           for (int row = 2; row <= rowCount.Value; row++)
                           {
                               var typeUpload = Convert.ToString(worksheet.Cells[row, 22].Value);
                               if (typeUpload.IsNullOrEmpty())
                               {
                                   result.Status = (int)HttpStatusCode.BadRequest;
                                   result.Message = "Type upload don't be blank";
                                   result.Error = true;
                                   return result;
                               }
                               if (typeUpload.Equals("New"))
                               {
                                    var model = Convert.ToString(worksheet.Cells[row, 2].Value);
                                    if (model.IsNullOrEmpty())
                                    {
                                        result.Status = (int)HttpStatusCode.BadRequest;
                                        result.Message = "Model don't be blank";
                                        result.Error = true;
                                        return result;
                                    }
                                    var phase = Convert.ToString(worksheet.Cells[row, 3].Value);
                                    if (phase.IsNullOrEmpty())
                                    {
                                        result.Status = (int)HttpStatusCode.BadRequest;
                                        result.Message = "Phase don't be blank";
                                        result.Error = true;
                                        return result;
                                    }
                                    var codeDestination = Convert.ToString(worksheet.Cells[row, 4].Value);
                                    if (codeDestination.IsNullOrEmpty())
                                    {
                                        result.Status = (int)HttpStatusCode.BadRequest;
                                        result.Message = "Code destination don't be blank";
                                        result.Error = true;
                                        return result;
                                    }
                                    var nameDestination = Convert.ToString(worksheet.Cells[row, 5].Value);
                                    if (nameDestination.IsNullOrEmpty())
                                    {
                                        result.Status = (int)HttpStatusCode.BadRequest;
                                        result.Message = "Name destination don't be blank";
                                        result.Error = true;
                                        return result;
                                    }
                                    var bodyNo = "";
                                    if (param.Category.Equals("Machine"))
                                    {
                                        bodyNo = Convert.ToString(worksheet.Cells[row, 6].Value);
                                        if (bodyNo.IsNullOrEmpty())
                                        {
                                            result.Status = (int)HttpStatusCode.BadRequest;
                                            result.Message = "Body no don't be blank";
                                            result.Error = true;
                                            return result;
                                        }
                                    }
                                    var applicationNo = Convert.ToString(worksheet.Cells[row, 7].Value);
                                    if (!param.Category.Equals("Machine"))
                                    {
                                        if (applicationNo.IsNullOrEmpty())
                                        {
                                            result.Status = (int)HttpStatusCode.BadRequest;
                                            result.Message = "Application DLV No don't be blank";
                                            result.Error = true;
                                            return result;
                                        }
                                    }
                                    var typeDie = Convert.ToString(worksheet.Cells[row, 8].Value);
                                    //if (typeDie.IsNullOrEmpty() && !param.Category.Equals("Machine"))
                                    //{
                                    //    result.Status = (int)HttpStatusCode.BadRequest;
                                    //    result.Message = "Type Die don't be blank";
                                    //    result.Error = true;
                                    //    return result;
                                    //}
                                    var order = Convert.ToString(worksheet.Cells[row, 9].Value);
                                    if (order.IsNullOrEmpty())
                                    {
                                        result.Status = (int)HttpStatusCode.BadRequest;
                                        result.Message = "Order don't be blank";
                                        result.Error = true;
                                        return result;
                                    }
                                    var sCode = Convert.ToString(worksheet.Cells[row, 10].Value);
                                    var qtyStr = Convert.ToString(worksheet.Cells[row, 11].Value);
                                    double qty = 0;
                                    if (qtyStr.IsNullOrEmpty())
                                    {
                                        result.Status = (int)HttpStatusCode.BadRequest;
                                        result.Message = "Qty don't be blank";
                                        result.Error = true;
                                        return result;
                                    }
                                    else
                                    {
                                        qty = double.Parse(qtyStr);
                                    }
                                    var shipFrom = Convert.ToString(worksheet.Cells[row, 12].Value);
                                    if (shipFrom.IsNullOrEmpty())
                                    {
                                        result.Status = (int)HttpStatusCode.BadRequest;
                                        result.Message = "Ship From don't be blank";
                                        result.Error = true;
                                        return result;
                                    }
                                    else
                                    {
                                        var department = listDept.FirstOrDefault(x => x.CostCenter.Equals(shipFrom));
                                        if(department != null)
                                        {
                                            shipFrom = department.CostCenter + " - " + department.DeptShortName;
                                        }
                                        else
                                        {
                                            result.Status = (int)HttpStatusCode.BadRequest;
                                            result.Message = "Department ("+shipFrom+") is not exist";
                                            result.Error = true;
                                            return result;
                                        }
                                    }
                                    var deliveryPlace = Convert.ToString(worksheet.Cells[row, 13].Value);
                                    if (deliveryPlace.IsNullOrEmpty())
                                    {
                                        result.Status = (int)HttpStatusCode.BadRequest;
                                        result.Message = "Delivery Place don't be blank";
                                        result.Error = true;
                                        return result;
                                    }
                                    var dept = Convert.ToString(worksheet.Cells[row, 14].Value);
                                    var attn = Convert.ToString(worksheet.Cells[row, 15].Value);
                                    var po = Convert.ToString(worksheet.Cells[row, 16].Value);

                                    var etdFactoryStr = Convert.ToString(worksheet.Cells[row, 17].Value);
                                    DateOnly? etdFactory = null;
                                    if (!etdFactoryStr.IsNullOrEmpty())
                                    {
                                        try
                                        {
                                            var date = Convert.ToDateTime(worksheet.Cells[row, 17].Value);
                                            etdFactory = DateOnly.FromDateTime(date);
                                        }
                                        catch (Exception)
                                        {
                                            try
                                            {
                                                double d = (double)worksheet.Cells[row, 17].Value;
                                                var date = DateTime.FromOADate(d);
                                                etdFactory = DateOnly.FromDateTime(date);
                                            }
                                            catch (Exception)
                                            {

                                                result.Status = (int)HttpStatusCode.BadRequest;
                                                result.Message = "ETD Factory wrong format";
                                                result.Error = true;
                                                return result;
                                            }
                                        }
                                    }
                                    var etdPortStr = Convert.ToString(worksheet.Cells[row, 18].Value);
                                    DateOnly? etdPort = null;
                                    if (!etdPortStr.IsNullOrEmpty())
                                    {
                                        try
                                        {
                                            var date = Convert.ToDateTime(worksheet.Cells[row, 18].Value);
                                            etdPort = DateOnly.FromDateTime(date);
                                        }
                                        catch (Exception)
                                        {
                                            try
                                            {
                                                double d = (double)worksheet.Cells[row, 18].Value;
                                                var date = DateTime.FromOADate(d);
                                                etdPort = DateOnly.FromDateTime(date);
                                            }
                                            catch (Exception)
                                            {

                                                result.Status = (int)HttpStatusCode.BadRequest;
                                                result.Message = "ETD Port wrong format";
                                                result.Error = true;
                                                return result;
                                            }
                                        }
                                    }
                                    var etaPortStr = Convert.ToString(worksheet.Cells[row, 19].Value);
                                    DateOnly? etaPort = null;
                                    if (!etaPortStr.IsNullOrEmpty())
                                    {
                                        try
                                        {
                                            var date = Convert.ToDateTime(worksheet.Cells[row, 19].Value);
                                            etaPort = DateOnly.FromDateTime(date);
                                        }
                                        catch (Exception)
                                        {
                                            try
                                            {
                                                double d = (double)worksheet.Cells[row, 19].Value;
                                                var date = DateTime.FromOADate(d);
                                                etaPort = DateOnly.FromDateTime(date);
                                            }
                                            catch (Exception)
                                            {

                                                result.Status = (int)HttpStatusCode.BadRequest;
                                                result.Message = "ETA Port wrong format";
                                                result.Error = true;
                                                return result;
                                            }
                                        }
                                    }
                                    var etaDeliveryStr = Convert.ToString(worksheet.Cells[row, 20].Value);
                                    DateOnly? etaDelivery = null;
                                    if (!etaDeliveryStr.IsNullOrEmpty())
                                    {
                                        try
                                        {
                                            var date = Convert.ToDateTime(worksheet.Cells[row, 20].Value);
                                            etaDelivery = DateOnly.FromDateTime(date);
                                        }
                                        catch (Exception)
                                        {
                                            try
                                            {
                                                double d = (double)worksheet.Cells[row, 20].Value;
                                                var date = DateTime.FromOADate(d);
                                                etaDelivery = DateOnly.FromDateTime(date);
                                            }
                                            catch (Exception)
                                            {

                                                result.Status = (int)HttpStatusCode.BadRequest;
                                                result.Message = "ETA Delivery Place wrong format";
                                                result.Error = true;
                                                return result;
                                            }
                                        }
                                    }
                                    var invNo = Convert.ToString(worksheet.Cells[row, 21].Value);
                                    var status = "";
                                    if (order.Equals("S-Order") && po.IsNullOrEmpty())
                                    {
                                        status = "Pending PO";
                                    }
                                    else if (invNo.IsNullOrEmpty())
                                    {
                                        status = "Pending Invoice";
                                    }
                                    else
                                    {
                                        status = "Finished";
                                    }
                                    list.Add(new BolExternalDelivery()
                                    {
                                        Category = param.Category,
                                        Brand = param.Brand,
                                        Model = model,
                                        Phase = phase,
                                        CodeDestination = codeDestination,
                                        NameDestination = nameDestination,
                                        BodyNo = bodyNo,
                                        ApplicationDlvNo = applicationNo,
                                        TypeDie = typeDie,
                                        Order = order,
                                        SCode =sCode,
                                        QtyShip = qty,
                                        ShipFrom = shipFrom,
                                        DeliveryPlace = deliveryPlace,
                                        Dept = dept,
                                        Attn = attn,
                                        Po = po,
                                        EtdFactory = etdFactory,
                                        EtdPort = etdPort,
                                        EtaPort = etaPort,
                                        EtaDeliveryPlace = etaDelivery,
                                        InvNo = invNo,
                                        CreatedBy = u.UserName,
                                        Status = status,
                                        Id = Guid.NewGuid()
                                    });
                               }
                               else
                               {
                                    if (param.Category.Equals("Machine"))
                                    {
                                        var bodyNo = Convert.ToString(worksheet.Cells[row, 6].Value);
                                        if (bodyNo.IsNullOrEmpty())
                                        {
                                            result.Status = (int)HttpStatusCode.BadRequest;
                                            result.Message = "Body no don't be blank";
                                            result.Error = true;
                                            return result;
                                        }
                                        var applicationNo = Convert.ToString(worksheet.Cells[row, 7].Value);
                                        if (!param.Category.Equals("Machine"))
                                        {
                                            if (applicationNo.IsNullOrEmpty())
                                            {
                                                result.Status = (int)HttpStatusCode.BadRequest;
                                                result.Message = "Application DLV No don't be blank";
                                                result.Error = true;
                                                return result;
                                            }
                                        }
                                        var info = GetInfoMachineDelivery(bodyNo, applicationNo);
                                        var typeDie = Convert.ToString(worksheet.Cells[row, 8].Value);
                                        //if (typeDie.IsNullOrEmpty() && !param.Category.Equals("Machine"))
                                        //{
                                        //    result.Status = (int)HttpStatusCode.BadRequest;
                                        //    result.Message = "Type Die don't be blank";
                                        //    result.Error = true;
                                        //    return result;
                                        //}
                                        var order = Convert.ToString(worksheet.Cells[row, 9].Value);
                                        if (order.IsNullOrEmpty())
                                        {
                                            result.Status = (int)HttpStatusCode.BadRequest;
                                            result.Message = "Order don't be blank";
                                            result.Error = true;
                                            return result;
                                        }
                                        var sCode = Convert.ToString(worksheet.Cells[row, 10].Value);
                                   
                              
                                        var deliveryPlace = Convert.ToString(worksheet.Cells[row, 13].Value);
                                        if (deliveryPlace.IsNullOrEmpty())
                                        {
                                            result.Status = (int)HttpStatusCode.BadRequest;
                                            result.Message = "Delivery Place don't be blank";
                                            result.Error = true;
                                            return result;
                                        }
                                        var dept = Convert.ToString(worksheet.Cells[row, 14].Value);
                                        var attn = Convert.ToString(worksheet.Cells[row, 15].Value);
                                        var po = Convert.ToString(worksheet.Cells[row, 16].Value);

                                        var etdFactoryStr = Convert.ToString(worksheet.Cells[row, 17].Value);
                                        DateOnly? etdFactory = null;
                                        if (!etdFactoryStr.IsNullOrEmpty())
                                        {
                                            try
                                            {
                                                var date = Convert.ToDateTime(worksheet.Cells[row, 17].Value);
                                                etdFactory = DateOnly.FromDateTime(date);
                                            }
                                            catch (Exception)
                                            {
                                                try
                                                {
                                                    double d = (double)worksheet.Cells[row, 17].Value;
                                                    var date = DateTime.FromOADate(d);
                                                    etdFactory = DateOnly.FromDateTime(date);
                                                }
                                                catch (Exception)
                                                {

                                                    result.Status = (int)HttpStatusCode.BadRequest;
                                                    result.Message = "ETD Factory wrong format";
                                                    result.Error = true;
                                                    return result;
                                                }
                                            }
                                        }
                                        var etdPortStr = Convert.ToString(worksheet.Cells[row, 18].Value);
                                        DateOnly? etdPort = null;
                                        if (!etdPortStr.IsNullOrEmpty())
                                        {
                                            try
                                            {
                                                var date = Convert.ToDateTime(worksheet.Cells[row, 18].Value);
                                                etdPort = DateOnly.FromDateTime(date);
                                            }
                                            catch (Exception)
                                            {
                                                try
                                                {
                                                    double d = (double)worksheet.Cells[row, 18].Value;
                                                    var date = DateTime.FromOADate(d);
                                                    etdPort = DateOnly.FromDateTime(date);
                                                }
                                                catch (Exception)
                                                {

                                                    result.Status = (int)HttpStatusCode.BadRequest;
                                                    result.Message = "ETD Port wrong format";
                                                    result.Error = true;
                                                    return result;
                                                }
                                            }
                                        }
                                        var etaPortStr = Convert.ToString(worksheet.Cells[row, 19].Value);
                                        DateOnly? etaPort = null;
                                        if (!etaPortStr.IsNullOrEmpty())
                                        {
                                            try
                                            {
                                                var date = Convert.ToDateTime(worksheet.Cells[row, 19].Value);
                                                etaPort = DateOnly.FromDateTime(date);
                                            }
                                            catch (Exception)
                                            {
                                                try
                                                {
                                                    double d = (double)worksheet.Cells[row, 19].Value;
                                                    var date = DateTime.FromOADate(d);
                                                    etaPort = DateOnly.FromDateTime(date);
                                                }
                                                catch (Exception)
                                                {

                                                    result.Status = (int)HttpStatusCode.BadRequest;
                                                    result.Message = "ETA Port wrong format";
                                                    result.Error = true;
                                                    return result;
                                                }
                                            }
                                        }
                                        var etaDeliveryStr = Convert.ToString(worksheet.Cells[row, 20].Value);
                                        DateOnly? etaDelivery = null;
                                        if (!etaDeliveryStr.IsNullOrEmpty())
                                        {
                                            try
                                            {
                                                var date = Convert.ToDateTime(worksheet.Cells[row, 20].Value);
                                                etaDelivery = DateOnly.FromDateTime(date);
                                            }
                                            catch (Exception)
                                            {
                                                try
                                                {
                                                    double d = (double)worksheet.Cells[row, 20].Value;
                                                    var date = DateTime.FromOADate(d);
                                                    etaDelivery = DateOnly.FromDateTime(date);
                                                }
                                                catch (Exception)
                                                {

                                                    result.Status = (int)HttpStatusCode.BadRequest;
                                                    result.Message = "ETA Delivery Place wrong format";
                                                    result.Error = true;
                                                    return result;
                                                }
                                            }
                                        }
                                        var invNo = Convert.ToString(worksheet.Cells[row, 21].Value);
                                        var status = "";
                                        if (order.Equals("S-Order") && po.IsNullOrEmpty())
                                        {
                                            status = "Pending PO";
                                        }
                                        else if (invNo.IsNullOrEmpty())
                                        {
                                            status = "Pending Invoice";
                                        }
                                        else
                                        {
                                            status = "Finished";
                                        }
                                        list.Add(new BolExternalDelivery()
                                        {
                                            Category = param.Category,
                                            Brand = param.Brand,
                                            Model = info.Model,
                                            Phase = info.Phase,
                                            CodeDestination = info.CodeDestination,
                                            NameDestination = info.NameDestination,
                                            BodyNo = bodyNo,
                                            ApplicationDlvNo = applicationNo,
                                            TypeDie = typeDie,
                                            Order = order,
                                            SCode = sCode,
                                            QtyShip = 1,
                                            ShipFrom = info.DeliveryPlace,
                                            DeliveryPlace = deliveryPlace,
                                            Dept = dept,
                                            Attn = attn,
                                            Po = po,
                                            EtdFactory = etdFactory,
                                            EtdPort = etdPort,
                                            EtaPort = etaPort,
                                            EtaDeliveryPlace = etaDelivery,
                                            InvNo = invNo,
                                            CreatedBy = u.UserName,
                                            Status = status,
                                            QtyDelivery = 1,
                                            Id = Guid.NewGuid()
                                        });
                                    }
                                    else
                                    {
                                        var codeDestination = Convert.ToString(worksheet.Cells[row, 4].Value);
                                        if (codeDestination.IsNullOrEmpty())
                                        {
                                            result.Status = (int)HttpStatusCode.BadRequest;
                                            result.Message = "Part No don't be blank";
                                            result.Error = true;
                                            return result;
                                        }
                                        var applicationNo = Convert.ToString(worksheet.Cells[row, 7].Value);
                                        if (!param.Category.Equals("Machine"))
                                        {
                                            if (applicationNo.IsNullOrEmpty())
                                            {
                                                result.Status = (int)HttpStatusCode.BadRequest;
                                                result.Message = "Application DLV No don't be blank";
                                                result.Error = true;
                                                return result;
                                            }
                                        }
                                        var typeDie = Convert.ToString(worksheet.Cells[row, 8].Value);
                                        var info = GetInfoPartDelivery(codeDestination, applicationNo,typeDie);
                                        //if (typeDie.IsNullOrEmpty() && !param.Category.Equals("Machine"))
                                        //{
                                        //    result.Status = (int)HttpStatusCode.BadRequest;
                                        //    result.Message = "Type Die don't be blank";
                                        //    result.Error = true;
                                        //    return result;
                                        //}
                                        var order = Convert.ToString(worksheet.Cells[row, 9].Value);
                                        if (order.IsNullOrEmpty())
                                        {
                                            result.Status = (int)HttpStatusCode.BadRequest;
                                            result.Message = "Order don't be blank";
                                            result.Error = true;
                                            return result;
                                        }
                                        var qtyStr = Convert.ToString(worksheet.Cells[row, 11].Value);
                                        double qty = 0;
                                        if (qtyStr.IsNullOrEmpty())
                                        {
                                            result.Status = (int)HttpStatusCode.BadRequest;
                                            result.Message = "Qty don't be blank";
                                            result.Error = true;
                                            return result;
                                        }
                                        else
                                        {
                                            qty = double.Parse(qtyStr);
                                            if(qty > info.QtyDelivery)
                                            {
                                                result.Status = (int)HttpStatusCode.BadRequest;
                                                result.Message = "Qty must be less than Qty Delivery";
                                                result.Error = true;
                                                return result;
                                            }
                                        }
                                      
                                        var sCode = Convert.ToString(worksheet.Cells[row, 10].Value);


                                        var deliveryPlace = Convert.ToString(worksheet.Cells[row, 13].Value);
                                        if (deliveryPlace.IsNullOrEmpty())
                                        {
                                            result.Status = (int)HttpStatusCode.BadRequest;
                                            result.Message = "Delivery Place don't be blank";
                                            result.Error = true;
                                            return result;
                                        }
                                        var dept = Convert.ToString(worksheet.Cells[row, 14].Value);
                                        var attn = Convert.ToString(worksheet.Cells[row, 15].Value);
                                        var po = Convert.ToString(worksheet.Cells[row, 16].Value);

                                        var etdFactoryStr = Convert.ToString(worksheet.Cells[row, 17].Value);
                                        DateOnly? etdFactory = null;
                                        if (!etdFactoryStr.IsNullOrEmpty())
                                        {
                                            try
                                            {
                                                var date = Convert.ToDateTime(worksheet.Cells[row, 17].Value);
                                                etdFactory = DateOnly.FromDateTime(date);
                                            }
                                            catch (Exception)
                                            {
                                                try
                                                {
                                                    double d = (double)worksheet.Cells[row, 17].Value;
                                                    var date = DateTime.FromOADate(d);
                                                    etdFactory = DateOnly.FromDateTime(date);
                                                }
                                                catch (Exception)
                                                {

                                                    result.Status = (int)HttpStatusCode.BadRequest;
                                                    result.Message = "ETD Factory wrong format";
                                                    result.Error = true;
                                                    return result;
                                                }
                                            }
                                        }
                                        var etdPortStr = Convert.ToString(worksheet.Cells[row, 18].Value);
                                        DateOnly? etdPort = null;
                                        if (!etdPortStr.IsNullOrEmpty())
                                        {
                                            try
                                            {
                                                var date = Convert.ToDateTime(worksheet.Cells[row, 18].Value);
                                                etdPort = DateOnly.FromDateTime(date);
                                            }
                                            catch (Exception)
                                            {
                                                try
                                                {
                                                    double d = (double)worksheet.Cells[row, 18].Value;
                                                    var date = DateTime.FromOADate(d);
                                                    etdPort = DateOnly.FromDateTime(date);
                                                }
                                                catch (Exception)
                                                {

                                                    result.Status = (int)HttpStatusCode.BadRequest;
                                                    result.Message = "ETD Port wrong format";
                                                    result.Error = true;
                                                    return result;
                                                }
                                            }
                                        }
                                        var etaPortStr = Convert.ToString(worksheet.Cells[row, 19].Value);
                                        DateOnly? etaPort = null;
                                        if (!etaPortStr.IsNullOrEmpty())
                                        {
                                            try
                                            {
                                                var date = Convert.ToDateTime(worksheet.Cells[row, 19].Value);
                                                etaPort = DateOnly.FromDateTime(date);
                                            }
                                            catch (Exception)
                                            {
                                                try
                                                {
                                                    double d = (double)worksheet.Cells[row, 19].Value;
                                                    var date = DateTime.FromOADate(d);
                                                    etaPort = DateOnly.FromDateTime(date);
                                                }
                                                catch (Exception)
                                                {

                                                    result.Status = (int)HttpStatusCode.BadRequest;
                                                    result.Message = "ETA Port wrong format";
                                                    result.Error = true;
                                                    return result;
                                                }
                                            }
                                        }
                                        var etaDeliveryStr = Convert.ToString(worksheet.Cells[row, 20].Value);
                                        DateOnly? etaDelivery = null;
                                        if (!etaDeliveryStr.IsNullOrEmpty())
                                        {
                                            try
                                            {
                                                var date = Convert.ToDateTime(worksheet.Cells[row, 20].Value);
                                                etaDelivery = DateOnly.FromDateTime(date);
                                            }
                                            catch (Exception)
                                            {
                                                try
                                                {
                                                    double d = (double)worksheet.Cells[row, 20].Value;
                                                    var date = DateTime.FromOADate(d);
                                                    etaDelivery = DateOnly.FromDateTime(date);
                                                }
                                                catch (Exception)
                                                {

                                                    result.Status = (int)HttpStatusCode.BadRequest;
                                                    result.Message = "ETA Delivery Place wrong format";
                                                    result.Error = true;
                                                    return result;
                                                }
                                            }
                                        }
                                        var invNo = Convert.ToString(worksheet.Cells[row, 21].Value);
                                        var status = "";
                                        if (order.Equals("S-Order") && po.IsNullOrEmpty())
                                        {
                                            status = "Pending PO";
                                        }
                                        else if (invNo.IsNullOrEmpty())
                                        {
                                            status = "Pending Invoice";
                                        }
                                        else
                                        {
                                            status = "Finished";
                                        }
                                        list.Add(new BolExternalDelivery()
                                        {
                                            Category = param.Category,
                                            Brand = param.Brand,
                                            Model = info.Model,
                                            Phase = info.Phase,
                                            CodeDestination = codeDestination,
                                            NameDestination = info.NameDestination,
                                            ApplicationDlvNo = applicationNo,
                                            TypeDie = typeDie,
                                            Order = order,
                                            SCode = sCode,
                                            QtyShip = qty,
                                            ShipFrom = info.DeliveryPlace,
                                            DeliveryPlace = deliveryPlace,
                                            Dept = dept,
                                            Attn = attn,
                                            Po = po,
                                            EtdFactory = etdFactory,
                                            EtdPort = etdPort,
                                            EtaPort = etaPort,
                                            EtaDeliveryPlace = etaDelivery,
                                            InvNo = invNo,
                                            CreatedBy = u.UserName,
                                            Status = status,
                                            QtyDelivery = info.QtyDelivery,
                                            Id = Guid.NewGuid()
                                        });
                                    }
                               }

                           }
                       }
                        foreach (var item in list)
                        {
                            if (item.Category.Equals("Machine"))
                            {
                                var dis = context.BolDiscardControls.FirstOrDefault(x => x.BodyNo.Equals(item.BodyNo) && x.ApplicationDlvNo.Equals(item.ApplicationDlvNo));
                                if (dis != null)
                                {
                                    if (!item.DeliveryPlace.ToLower().Contains("cvn"))
                                    {
                                        dis.Active = false;
                                    }
                                    else
                                    {
                                        dis.Active = true;
                                    }
                                }
                                else
                                {
                                    if (item.DeliveryPlace.ToLower().Contains("cvn"))
                                    {
                                        context.BolDiscardControls.Add(new BolDiscardControl()
                                        {
                                            ApplicationDlvNo = item.ApplicationDlvNo,
                                            Department = item.ShipFrom,
                                            Model = item.Model,
                                            Phase = item.Phase,
                                            CodeDestination = item.CodeDestination,
                                            NameDestination = item.NameDestination,
                                            BodyNo = item.BodyNo,
                                            Qty = item.QtyShip,
                                            Category = item.Category,
                                            Brand = item.Brand,
                                            IdDelivery = item.Id
                                        });
                                    }
                                }

                            }
                            else
                            {
                                var dis = context.BolDiscardControls.FirstOrDefault(x => x.PartNo.Equals(item.CodeDestination) && x.ApplicationDlvNo.Equals(item.ApplicationDlvNo) && x.TypeDie.Equals(item.TypeDie));
                                if (dis != null)
                                {

                                    if (!item.DeliveryPlace.ToLower().Contains("cvn"))
                                    {
                                        dis.Active = false;
                                    }
                                    else
                                    {
                                        dis.Active = true;
                                    }
                                }
                                else
                                {
                                    if (item.DeliveryPlace.ToLower().Contains("cvn"))
                                    {
                                        context.BolDiscardControls.Add(new BolDiscardControl()
                                        {
                                            ApplicationDlvNo = item.ApplicationDlvNo,
                                            Department = item.ShipFrom,
                                            Model = item.Model,
                                            Phase = item.Phase,
                                            PartNo = item.CodeDestination,
                                            PartName = item.NameDestination,
                                            TypeDie = item.TypeDie,
                                            Qty = item.QtyShip,
                                            Category = item.Category,
                                            Brand = item.Brand,
                                            IdDelivery = item.Id
                                        });
                                    }
                                }
                            }
                        }
                        context.BolExternalDeliveries.AddRange(list);

                    }
                }
                context.SaveChanges();
                result.Status = (int)HttpStatusCode.OK;
                result.Message = "Success";
                result.Error = false;
                return result;
            }
            catch (Exception e)
            {
                result.Status = (int)HttpStatusCode.BadRequest;
                result.Message = e.Message;
                result.Error = true;
                return result;
            }
        }
        [HttpPost("filter-discard-control-machine")]
        public DiscardControlModel FilterDiscardControlMachine(DiscardParam param)
        {
            try
            {
                var result = new DiscardControlModel();
                var lstResult = new List<DiscardControl>();
                var user = GetCurrentUser();
                var model = context.BolDiscardControls.Where(x => x.Active == true && x.Category.Equals("Machine")).AsQueryable();
                if (!user.Departments.Contains("PDC 1") && !user.Departments.Contains("PDC1"))
                {
                    model = model.Where(x => user.CostCenter.Contains(x.Department.Substring(0, 4)));
                }
                if (!string.IsNullOrEmpty(param.Model)) { model = model.Where(x => x.Model.ToUpper().Equals(param.Model.ToUpper())); }
                if (!string.IsNullOrEmpty(param.Phase)) { model = model.Where(x => x.Phase.ToLower().Equals(param.Phase.ToLower())); }
                if (!string.IsNullOrEmpty(param.Brand)) { model = model.Where(x => x.Brand.ToUpper().Equals(param.Brand.ToUpper())); }
                if (!string.IsNullOrEmpty(param.Department)) { model = model.Where(x => x.Department.ToLower().Equals(param.Department.ToLower())); }
                if (!string.IsNullOrEmpty(param.CodeDestination)) { model = model.Where(x => x.CodeDestination.ToLower().Contains(param.CodeDestination.ToLower())); }
                if (!string.IsNullOrEmpty(param.ApplicationNo)) { model = model.Where(x => x.ApplicationNo.ToLower().Contains(param.ApplicationNo.ToLower())); }
                if (!string.IsNullOrEmpty(param.ApplicationDlvNo)) { model = model.Where(x => x.ApplicationDlvNo.ToLower().Contains(param.ApplicationDlvNo.ToLower())); }
                if (!string.IsNullOrEmpty(param.DateFrom)) { var TimeFrom = DateOnly.FromDateTime(DateTime.ParseExact(param.DateFrom, "dd-MM-yyyy", null)); model = model.Where(x => x.DiscardDate >= TimeFrom); }
                if (!string.IsNullOrEmpty(param.DateUntil)) { var TimeFrom = DateOnly.FromDateTime(DateTime.ParseExact(param.DateUntil, "dd-MM-yyyy", null)); model = model.Where(x => x.DiscardDate <= TimeFrom); }


                var model2 = model.Skip((param.Page - 1) * param.RecordsPerPage).Take(param.RecordsPerPage).ToList();
                foreach (var item in model2)
                {
                    lstResult.Add(new DiscardControl()
                    {
                        ApplicationNo = item.ApplicationNo,
                        ApplicationDlvNo = item.ApplicationDlvNo,
                        Department = item.Department,
                        Model = item.Model,
                        Phase = item.Phase,
                        CodeDestination = item.CodeDestination,
                        NameDestination = item.NameDestination,
                        BodyNo = item.BodyNo,
                        Qty = item.Qty ?? null,
                        ReceivedDate = item.ReceivedDate != null ? item.ReceivedDate.Value.ToString("dd-MM-yyyy") : "",
                        RegisterDiscardDate = item.RegisterDiscardDate != null ? item.RegisterDiscardDate.Value.ToString("dd-MM-yyyy") : "",
                        DiscardDate = item.DiscardDate != null ? item.DiscardDate.Value.ToString("dd-MM-yyyy") : "",
                        DiscardLetter = item.DiscardLetter,
                        CreatedBy = item.ModifiedBy != null ? item.ModifiedBy : item.CreatedBy,
                        CreatedDate = item.ModifiedDate != null ? item.ModifiedDate.Value.ToString("dd-MMM-yyyy") : item.CreatedDate.Value.ToString("dd-MMM-yyyy"),
                        Id = item.Id.ToString(),
                        DeadlineDisposal = item.DeadlineDisposal != null ? item.DeadlineDisposal.Value.ToString("dd-MM-yyyy") : "",
                    });
                }

                var c = model.Count();
                result.lstModel = lstResult;
                result.toRecord = (int)Math.Min(result.totalRecords, result.currentPage * result.recordPerPage);
                result.totalPage = (int)Math.Ceiling((decimal)c / param.RecordsPerPage);
                result.totalRecords = c;
                result.recordPerPage = param.RecordsPerPage;
                result.currentPage = param.Page;
                result.fromRecord = c == 0 ? 0 : (result.currentPage - 1) * result.recordPerPage + 1;
                return result;
            }
            catch (Exception)
            {
                return new DiscardControlModel();
            }
        }
        [HttpPost("filter-discard-control-part")]
        public DiscardControlModel FilterDiscardControlPart(DiscardParam param)
        {
            try
            {
                var result = new DiscardControlModel();
                var lstResult = new List<DiscardControl>();
                var user = GetCurrentUser();
                var model = context.BolDiscardControls.Where(x => x.Active == true && !x.Category.Equals("Machine")).AsQueryable();
                if (!user.Departments.Contains("PDC 1") && !user.Departments.Contains("PDC1"))
                {
                    model = model.Where(x => user.CostCenter.Contains(x.Department.Substring(0, 4)));
                }
                if (!string.IsNullOrEmpty(param.Model)) { model = model.Where(x => x.Model.ToUpper().Equals(param.Model.ToUpper())); }
                if (!string.IsNullOrEmpty(param.Phase)) { model = model.Where(x => x.Phase.ToLower().Equals(param.Phase.ToLower())); }
                if (!string.IsNullOrEmpty(param.Brand)) { model = model.Where(x => x.Brand.ToUpper().Equals(param.Brand.ToUpper())); }
                if (!string.IsNullOrEmpty(param.Department)) { model = model.Where(x => x.Department.ToLower().Equals(param.Department.ToLower())); }
                if (!string.IsNullOrEmpty(param.CodeDestination)) { model = model.Where(x => x.PartName.ToLower().Contains(param.CodeDestination.ToLower())); }
                if (!string.IsNullOrEmpty(param.ApplicationNo)) { model = model.Where(x => x.ApplicationNo.ToLower().Contains(param.ApplicationNo.ToLower())); }
                if (!string.IsNullOrEmpty(param.ApplicationDlvNo)) { model = model.Where(x => x.ApplicationDlvNo.ToLower().Contains(param.ApplicationDlvNo.ToLower())); }
                if (!string.IsNullOrEmpty(param.DateFrom)) { var TimeFrom = DateOnly.FromDateTime(DateTime.ParseExact(param.DateFrom, "dd-MM-yyyy", null)); model = model.Where(x => x.DiscardDate >= TimeFrom); }
                if (!string.IsNullOrEmpty(param.DateUntil)) { var TimeFrom = DateOnly.FromDateTime(DateTime.ParseExact(param.DateUntil, "dd-MM-yyyy", null)); model = model.Where(x => x.DiscardDate <= TimeFrom); }


                var model2 = model.Skip((param.Page - 1) * param.RecordsPerPage).Take(param.RecordsPerPage).ToList();
                foreach (var item in model2)
                {
                    lstResult.Add(new DiscardControl()
                    {
                        ApplicationNo = item.ApplicationNo,
                        ApplicationDlvNo = item.ApplicationDlvNo,
                        Department = item.Department,
                        Model = item.Model,
                        Phase = item.Phase,
                        PartNo = item.PartNo,
                        PartName = item.PartName,
                        PartLevel = item.PartLevel,
                        Qty = item.Qty ?? null,
                        TypeDie = item.TypeDie,
                        ReceivedDate = item.ReceivedDate != null ? item.ReceivedDate.Value.ToString("dd-MM-yyyy") : "",
                        RegisterDiscardDate = item.RegisterDiscardDate != null ? item.RegisterDiscardDate.Value.ToString("dd-MM-yyyy") : "",
                        DiscardDate = item.DiscardDate != null ? item.DiscardDate.Value.ToString("dd-MM-yyyy") : "",
                        DiscardLetter = item.DiscardLetter,
                        CreatedBy = item.ModifiedBy != null ? item.ModifiedBy : item.CreatedBy,
                        CreatedDate = item.ModifiedDate != null ? item.ModifiedDate.Value.ToString("dd-MMM-yyyy") : item.CreatedDate.Value.ToString("dd-MMM-yyyy"),
                        Id = item.Id.ToString(),
                        DeadlineDisposal = item.DeadlineDisposal != null ? item.DeadlineDisposal.Value.ToString("dd-MM-yyyy") : "",
                    });
                }

                var c = model.Count();
                result.lstModel = lstResult;
                result.toRecord = (int)Math.Min(result.totalRecords, result.currentPage * result.recordPerPage);
                result.totalPage = (int)Math.Ceiling((decimal)c / param.RecordsPerPage);
                result.totalRecords = c;
                result.recordPerPage = param.RecordsPerPage;
                result.currentPage = param.Page;
                result.fromRecord = c == 0 ? 0 : (result.currentPage - 1) * result.recordPerPage + 1;
                return result;
            }
            catch (Exception)
            {
                return new DiscardControlModel();
            }
        }
        [HttpPost("update-discard-data")]
        public CommonResponse? UpdateDiscardData(UpdateDiscardParam param)
        {
            CommonResponse res = new CommonResponse()
            {
                Error = false,
                Message = "",
                Status = (int)HttpStatusCode.BadRequest
            };
            try
            {
                var user = GetCurrentUser();
                List<BolExternalDelivery> listAdd = new List<BolExternalDelivery>();
                var listDiscard = context.BolDiscardControls.Where(x => x.Active == true).ToList();
                foreach (var item in param.ListMachine)
                {

                    var ex = listDiscard.FirstOrDefault(x => x.Id.ToString().Equals(item.Id));
                    if (ex != null)
                    {
                        if (item.ApplicationDlvNo.IsNullOrEmpty())
                        {
                            ex.ReceivedDate = item.ReceivedDate.IsNullOrEmpty() ? null : DateOnly.FromDateTime(DateTime.ParseExact(item.ReceivedDate, "dd-MM-yyyy", null));
                        }
                        ex.RegisterDiscardDate = item.RegisterDiscardDate.IsNullOrEmpty() ? null : DateOnly.FromDateTime(DateTime.ParseExact(item.RegisterDiscardDate, "dd-MM-yyyy", null));
                        ex.DiscardDate = item.DiscardDate.IsNullOrEmpty() ? null : DateOnly.FromDateTime(DateTime.ParseExact(item.DiscardDate, "dd-MM-yyyy", null));
                        ex.DiscardLetter = item.DiscardLetter;
                        ex.ModifiedBy = user.UserName;
                        ex.ModifiedDate = DateTime.Now.SetKindUtc();
                    }

                }
                foreach (var item in param.ListUnit)
                {

                    var ex = listDiscard.FirstOrDefault(x => x.Id.ToString().Equals(item.Id));
                    if (ex != null)
                    {
                        ex.RegisterDiscardDate = item.RegisterDiscardDate.IsNullOrEmpty() ? null : DateOnly.FromDateTime(DateTime.ParseExact(item.RegisterDiscardDate, "dd-MM-yyyy", null));
                        ex.DiscardDate = item.DiscardDate.IsNullOrEmpty() ? null : DateOnly.FromDateTime(DateTime.ParseExact(item.DiscardDate, "dd-MM-yyyy", null));
                        ex.DiscardLetter = item.DiscardLetter;
                        ex.QtyDiscard = item.QtyDiscard;
                        ex.ModifiedBy = user.UserName;
                        ex.ModifiedDate = DateTime.Now.SetKindUtc();
                    }

                }
                context.SaveChanges();

                res.Error = false;
                res.Message = "Successfully";
                res.Status = (int)HttpStatusCode.OK;
            }
            catch (Exception e)
            {
                res.Error = true;
                res.Message = e.Message;
                res.Status = (int)HttpStatusCode.BadRequest;
            }
            return res;
        }
        [HttpGet("download-discard-control/{category}")]
        public FileResponse DownloadDiscardControl(string category)
        {
            var fs = new FileResponse()
            {
                Error = false,
                Message = "No content",
                Status = 400
            };
            try
            {
                var model = context.BolDiscardControls.Where(x=>x.Active == true && x.Category.Equals(category)).ToList();
                int numberRow = model.Count();
                string filePath =category.Equals("Machine") ? Path.Combine(pathServer, "Sample\\DiscardControlMachine.xlsx"): Path.Combine(pathServer, "Sample\\DiscardControlPart.xlsx");
                FileInfo file = new FileInfo(filePath);
                ExcelPackage.LicenseContext = LicenseContext.NonCommercial;
                using (ExcelPackage excelPackage = new ExcelPackage(file))
                {
                    ExcelWorksheet excelWorksheet = excelPackage.Workbook.Worksheets.First();
                    if (category.Equals("Machine"))
                    {
                        excelWorksheet.Cells["A2:Q" + (numberRow + 1)].Style.Font.Size = 12;
                        excelWorksheet.Cells["A2:Q" + (numberRow + 1)].Style.Font.Name = "Calibri";
                        excelWorksheet.Cells["A2:Q" + (numberRow + 1)].Style.Border.Top.Style = ExcelBorderStyle.Thin;
                        excelWorksheet.Cells["A2:Q" + (numberRow + 1)].Style.Border.Bottom.Style = ExcelBorderStyle.Thin;
                        excelWorksheet.Cells["A2:Q" + (numberRow + 1)].Style.Border.Left.Style = ExcelBorderStyle.Thin;
                        excelWorksheet.Cells["A2:Q" + (numberRow + 1)].Style.Border.Right.Style = ExcelBorderStyle.Thin;

                        for (int i = 0; i < numberRow; i++)
                        {
                            var index = i + 2;
                            excelWorksheet.Cells["A" + index].Value = i + 1;
                            excelWorksheet.Cells["B" + index].Value = model[i].ApplicationNo;
                            excelWorksheet.Cells["C" + index].Value = model[i].ApplicationDlvNo;
                            excelWorksheet.Cells["D" + index].Value = model[i].Department;
                            excelWorksheet.Cells["E" + index].Value = model[i].Model;
                            excelWorksheet.Cells["F" + index].Value = model[i].Phase;
                            excelWorksheet.Cells["G" + index].Value = model[i].CodeDestination;
                            excelWorksheet.Cells["H" + index].Value = model[i].NameDestination;
                            excelWorksheet.Cells["I" + index].Value = model[i].BodyNo;
                            excelWorksheet.Cells["J" + index].Value = model[i].Qty;
                            excelWorksheet.Cells["K" + index].Value = model[i].ReceivedDate != null ? model[i].ReceivedDate.Value.ToString("dd-MM-yyyy") : "";
                            excelWorksheet.Cells["L" + index].Value = model[i].DeadlineDisposal != null ? model[i].DeadlineDisposal.Value.ToString("dd-MM-yyyy") : "";
                            excelWorksheet.Cells["M" + index].Value = model[i].RegisterDiscardDate != null ? model[i].RegisterDiscardDate.Value.ToString("dd-MM-yyyy") : "";
                            excelWorksheet.Cells["N" + index].Value = model[i].DiscardDate != null ? model[i].DiscardDate.Value.ToString("dd-MM-yyyy") : "";
                            excelWorksheet.Cells["O" + index].Value = model[i].DiscardLetter;
                            excelWorksheet.Cells["P" + index].Value = model[i].ModifiedBy != null ? model[i].ModifiedBy : model[i].CreatedBy;
                            excelWorksheet.Cells["Q" + index].Value = model[i].ModifiedDate != null ? model[i].ModifiedDate.Value.ToString("dd-MMM-yyyy") : model[i].CreatedDate.Value.ToString("dd-MMM-yyyy");
                            excelWorksheet.Cells["R" + index].Value = model[i].Id;

                            foreach (var cell in excelWorksheet.Cells["K" + "2" + ":N" + (numberRow + 1)])
                            {
                                if (cell.Value != null)
                                {
                                    if (!cell.Value.Equals(""))
                                    {
                                        string[] date = cell.Value.ToString().Split("-");
                                        cell.Value = new DateTime(int.Parse(date[2]), int.Parse(date[1]), int.Parse(date[0]));
                                    }

                                }
                            }
                            excelWorksheet.Cells["K" + "2" + ":N" + (numberRow + 1)].Style.Numberformat.Format = "dd-MMM-yyyy";

                        }
                    }
                    else
                    {
                        excelWorksheet.Cells["A2:T" + (numberRow + 1)].Style.Font.Size = 12;
                        excelWorksheet.Cells["A2:T" + (numberRow + 1)].Style.Font.Name = "Calibri";
                        excelWorksheet.Cells["A2:T" + (numberRow + 1)].Style.Border.Top.Style = ExcelBorderStyle.Thin;
                        excelWorksheet.Cells["A2:T" + (numberRow + 1)].Style.Border.Bottom.Style = ExcelBorderStyle.Thin;
                        excelWorksheet.Cells["A2:T" + (numberRow + 1)].Style.Border.Left.Style = ExcelBorderStyle.Thin;
                        excelWorksheet.Cells["A2:T" + (numberRow + 1)].Style.Border.Right.Style = ExcelBorderStyle.Thin;

                        for (int i = 0; i < numberRow; i++)
                        {
                            var index = i + 2;
                            excelWorksheet.Cells["A" + index].Value = i + 1;
                            excelWorksheet.Cells["B" + index].Value = model[i].ApplicationNo;
                            excelWorksheet.Cells["C" + index].Value = model[i].ApplicationDlvNo;
                            excelWorksheet.Cells["D" + index].Value = model[i].Department;
                            excelWorksheet.Cells["E" + index].Value = model[i].Model;
                            excelWorksheet.Cells["F" + index].Value = model[i].Phase;
                            excelWorksheet.Cells["G" + index].Value = model[i].PartNo;
                            excelWorksheet.Cells["H" + index].Value = model[i].PartName;
                            excelWorksheet.Cells["I" + index].Value = model[i].Qty;
                            excelWorksheet.Cells["J" + index].Value = model[i].PartLevel;
                            excelWorksheet.Cells["K" + index].Value = model[i].TypeDie;
                            excelWorksheet.Cells["L" + index].Value = model[i].ReceivedDate != null ? model[i].ReceivedDate.Value.ToString("dd-MM-yyyy") : "";
                            excelWorksheet.Cells["M" + index].Value = model[i].DeadlineDisposal != null ? model[i].DeadlineDisposal.Value.ToString("dd-MM-yyyy") : "";
                            excelWorksheet.Cells["N" + index].Value = model[i].RegisterDiscardDate != null ? model[i].RegisterDiscardDate.Value.ToString("dd-MM-yyyy") : "";
                            excelWorksheet.Cells["O" + index].Value = model[i].DiscardDate != null ? model[i].DiscardDate.Value.ToString("dd-MM-yyyy") : "";
                            excelWorksheet.Cells["P" + index].Value = model[i].DiscardLetter;
                            excelWorksheet.Cells["Q" + index].Value = model[i].QtyDiscard;
                            excelWorksheet.Cells["R" + index].Value = model[i].Qty - model[i].QtyDiscard;
                            excelWorksheet.Cells["S" + index].Value = model[i].ModifiedBy != null ? model[i].ModifiedBy : model[i].CreatedBy;
                            excelWorksheet.Cells["T" + index].Value = model[i].ModifiedDate != null ? model[i].ModifiedDate.Value.ToString("dd-MM-yyyy") : model[i].CreatedDate.Value.ToString("dd-MM-yyyy");
                            excelWorksheet.Cells["U" + index].Value = model[i].Id;
                        }
                        foreach (var cell in excelWorksheet.Cells["L" + "2" + ":O" + (numberRow + 1)])
                        {
                            if (cell.Value != null)
                            {
                                if (!cell.Value.Equals(""))
                                {
                                    string[] date = cell.Value.ToString().Split("-");
                                    cell.Value = new DateTime(int.Parse(date[2]), int.Parse(date[1]), int.Parse(date[0]));
                                }

                            }
                        }
                        excelWorksheet.Cells["L" + "2" + ":O" + (numberRow + 1)].Style.Numberformat.Format = "dd-MMM-yyyy";
                    }
                    
                    byte[] fileBytes = excelPackage.GetAsByteArray();
                    MemoryStream ms = new MemoryStream(fileBytes);
                    FileStreamResult result = new FileStreamResult(ms, FileFunction.GetContentType("abc.xlsx"));
                    result.FileDownloadName = "DiscardControlMachine.xlsx";
                    fs = new FileResponse()
                    {
                        File = ManualFunc.ConvertStreamToBase64(result.FileStream),
                        Error = false,
                        Message = "DiscardControlMachine.xlsx",
                        Status = 200
                    };
                }
            }
            catch (Exception e)
            {
                fs = new FileResponse()
                {
                    Error = true,
                    Message = e.Message,
                    Status = 400
                };
            }
            return fs;
        }
        [HttpPost("import-discard-control")]
        public async Task<CommonResponse> ImportDiscardControl([FromForm] ImportMachineParam param)
        {
            var result = new CommonResponse()
            {
                Error = false,
                Message = "",
                Status = (int)HttpStatusCode.BadRequest
            };
            try
            {
                var u = GetCurrentUser();
                List<BolExternalDelivery> list = new List<BolExternalDelivery>();

                using (var memoStream = new MemoryStream())
                {
                    param.File.CopyTo(memoStream);
                    ExcelPackage.LicenseContext = LicenseContext.NonCommercial;
                    using (var package = new ExcelPackage(memoStream))
                    {
                        var worksheet = package.Workbook.Worksheets[0];

                        var rowCount = worksheet.Dimension?.Rows;
                        if (rowCount.HasValue && rowCount.Value > 1)
                        {
                            var listDiscard = context.BolDiscardControls.Where(x => x.Active == true).ToList();
                            for (int row = 2; row <= rowCount.Value; row++)
                            {
                                if (param.Category.Equals("Machine")){

                                    var id = Convert.ToString(worksheet.Cells[row, 18].Value);
                                    if (id.IsNullOrEmpty())
                                    {
                                        result.Status = (int)HttpStatusCode.BadRequest;
                                        result.Message = "ID don't be blank";
                                        result.Error = true;
                                        return result;
                                    }
                                    var applicationDlvNo = Convert.ToString(worksheet.Cells[row, 3].Value);
                                    DateOnly? receivedDate = null;
                                    if (applicationDlvNo.IsNullOrEmpty())
                                    {
                                        var receivedDateStr = Convert.ToString(worksheet.Cells[row, 11].Value);
                                        if (!receivedDateStr.IsNullOrEmpty())
                                        {
                                            try
                                            {
                                                var date = Convert.ToDateTime(worksheet.Cells[row, 11].Value);
                                                receivedDate = DateOnly.FromDateTime(date);
                                            }
                                            catch (Exception)
                                            {
                                                try
                                                {
                                                    double d = (double)worksheet.Cells[row, 11].Value;
                                                    var date = DateTime.FromOADate(d);
                                                    receivedDate = DateOnly.FromDateTime(date);
                                                }
                                                catch (Exception)
                                                {

                                                    result.Status = (int)HttpStatusCode.BadRequest;
                                                    result.Message = "Received Date wrong format";
                                                    result.Error = true;
                                                    return result;
                                                }
                                            }
                                        }
                                        else
                                        {
                                            result.Status = (int)HttpStatusCode.BadRequest;
                                            result.Message = "Received Date don't be blank";
                                            result.Error = true;
                                            return result;
                                        }
                                    }
                                    var RegisterDateStr = Convert.ToString(worksheet.Cells[row, 13].Value);
                                    DateOnly? RegisterDate = null;
                                    if (!RegisterDateStr.IsNullOrEmpty())
                                    {
                                        try
                                        {
                                            var date = Convert.ToDateTime(worksheet.Cells[row, 13].Value);
                                            RegisterDate = DateOnly.FromDateTime(date);
                                        }
                                        catch (Exception)
                                        {
                                            try
                                            {
                                                double d = (double)worksheet.Cells[row, 13].Value;
                                                var date = DateTime.FromOADate(d);
                                                RegisterDate = DateOnly.FromDateTime(date);
                                            }
                                            catch (Exception)
                                            {

                                                result.Status = (int)HttpStatusCode.BadRequest;
                                                result.Message = "Register Discard Date wrong format";
                                                result.Error = true;
                                                return result;
                                            }
                                        }
                                    }
                                    else
                                    {
                                        result.Status = (int)HttpStatusCode.BadRequest;
                                        result.Message = "Register Discard Date don't be blank";
                                        result.Error = true;
                                        return result;
                                    }
                                    var discardDateStr = Convert.ToString(worksheet.Cells[row, 14].Value);
                                    DateOnly? discardDate = null;
                                    if (!discardDateStr.IsNullOrEmpty())
                                    {
                                        try
                                        {
                                            var date = Convert.ToDateTime(worksheet.Cells[row, 14].Value);
                                            discardDate = DateOnly.FromDateTime(date);
                                        }
                                        catch (Exception)
                                        {
                                            try
                                            {
                                                double d = (double)worksheet.Cells[row, 14].Value;
                                                var date = DateTime.FromOADate(d);
                                                discardDate = DateOnly.FromDateTime(date);
                                            }
                                            catch (Exception)
                                            {

                                                result.Status = (int)HttpStatusCode.BadRequest;
                                                result.Message = "Discard Date wrong format";
                                                result.Error = true;
                                                return result;
                                            }
                                        }
                                    }
                                    else
                                    {
                                        result.Status = (int)HttpStatusCode.BadRequest;
                                        result.Message = "Discard Date don't be blank";
                                        result.Error = true;
                                        return result;
                                    }
                                    var discardLetter = Convert.ToString(worksheet.Cells[row, 15].Value);
                                    if (discardLetter.IsNullOrEmpty())
                                    {
                                        result.Status = (int)HttpStatusCode.BadRequest;
                                        result.Message = "Discard Letter don't be blank";
                                        result.Error = true;
                                        return result;
                                    }
                                    var discard = listDiscard.FirstOrDefault(x => x.Id.ToString() == id);
                                    if(discard != null)
                                    {
                                        if (applicationDlvNo.IsNullOrEmpty())
                                        {
                                            discard.ReceivedDate = receivedDate;
                                        }
                                        discard.RegisterDiscardDate = RegisterDate;
                                        discard.DiscardDate = discardDate;
                                        discard.DiscardLetter = discardLetter;
                                        discard.ModifiedBy = u.UserName;
                                        discard.ModifiedDate = DateTime.Now.SetKindUtc();
                                    }
                                }
                                else
                                {
                                    var id = Convert.ToString(worksheet.Cells[row, 21].Value);
                                    if (id.IsNullOrEmpty())
                                    {
                                        result.Status = (int)HttpStatusCode.BadRequest;
                                        result.Message = "ID don't be blank";
                                        result.Error = true;
                                        return result;
                                    }
                                    var RegisterDateStr = Convert.ToString(worksheet.Cells[row, 14].Value);
                                    DateOnly? RegisterDate = null;
                                    if (!RegisterDateStr.IsNullOrEmpty())
                                    {
                                        try
                                        {
                                            var date = Convert.ToDateTime(worksheet.Cells[row, 14].Value);
                                            RegisterDate = DateOnly.FromDateTime(date);
                                        }
                                        catch (Exception)
                                        {
                                            try
                                            {
                                                double d = (double)worksheet.Cells[row, 14].Value;
                                                var date = DateTime.FromOADate(d);
                                                RegisterDate = DateOnly.FromDateTime(date);
                                            }
                                            catch (Exception)
                                            {

                                                result.Status = (int)HttpStatusCode.BadRequest;
                                                result.Message = "Register Discard Date wrong format";
                                                result.Error = true;
                                                return result;
                                            }
                                        }
                                    }
                                    else
                                    {
                                        result.Status = (int)HttpStatusCode.BadRequest;
                                        result.Message = "Register Discard Date don't be blank";
                                        result.Error = true;
                                        return result;
                                    }
                                    var discardDateStr = Convert.ToString(worksheet.Cells[row, 15].Value);
                                    DateOnly? discardDate = null;
                                    if (!discardDateStr.IsNullOrEmpty())
                                    {
                                        try
                                        {
                                            var date = Convert.ToDateTime(worksheet.Cells[row, 15].Value);
                                            discardDate = DateOnly.FromDateTime(date);
                                        }
                                        catch (Exception)
                                        {
                                            try
                                            {
                                                double d = (double)worksheet.Cells[row, 15].Value;
                                                var date = DateTime.FromOADate(d);
                                                discardDate = DateOnly.FromDateTime(date);
                                            }
                                            catch (Exception)
                                            {

                                                result.Status = (int)HttpStatusCode.BadRequest;
                                                result.Message = "Discard Date wrong format";
                                                result.Error = true;
                                                return result;
                                            }
                                        }
                                    }
                                    else
                                    {
                                        result.Status = (int)HttpStatusCode.BadRequest;
                                        result.Message = "Discard Date don't be blank";
                                        result.Error = true;
                                        return result;
                                    }
                                    var discardLetter = Convert.ToString(worksheet.Cells[row, 16].Value);
                                    if (discardLetter.IsNullOrEmpty())
                                    {
                                        result.Status = (int)HttpStatusCode.BadRequest;
                                        result.Message = "Discard Letter don't be blank";
                                        result.Error = true;
                                        return result;
                                    }
                                    var qtyStr = Convert.ToString(worksheet.Cells[row, 17].Value);
                                    double qty = 0;
                                    if (qtyStr.IsNullOrEmpty())
                                    {
                                        result.Status = (int)HttpStatusCode.BadRequest;
                                        result.Message = "Qty Discard don't be blank";
                                        result.Error = true;
                                        return result;
                                    }
                                    else
                                    {
                                        qty = double.Parse(qtyStr);
                                    }
                                    var discard = listDiscard.FirstOrDefault(x => x.Id.ToString() == id);
                                    if (discard != null)
                                    {
                                        discard.RegisterDiscardDate = RegisterDate;
                                        discard.DiscardDate = discardDate;
                                        discard.DiscardLetter = discardLetter;
                                        discard.QtyDiscard = qty;
                                        discard.ModifiedBy = u.UserName;
                                        discard.ModifiedDate = DateTime.Now.SetKindUtc();
                                    }
                                }

                            }
                        }

                    }
                }
                context.SaveChanges();
                result.Status = (int)HttpStatusCode.OK;
                result.Message = "Success";
                result.Error = false;
                return result;
            }
            catch (Exception e)
            {
                result.Status = (int)HttpStatusCode.BadRequest;
                result.Message = e.Message;
                result.Error = true;
                return result;
            }
        }
        [HttpGet("get-all-model-list")]
        public List<string> GetAllModelList()
        {

            try
            {               
                return context.BolModelMasters.Where(x=>x.Active == true).Select(x=>x.Model).Distinct().ToList();
            }
            catch (Exception e)
            {
                return new List<string>();
            }
        }
        [HttpGet("get-list-application-no-by-discard")]
        public List<string> GetListApplicationNoByDiscard()
        {

            try
            {
                return context.BolDiscardControls.Where(x => x.Active == true && !x.ApplicationNo.IsNullOrEmpty() ).Select(x => x.ApplicationNo).Distinct().ToList();
            }
            catch (Exception e)
            {
                return new List<string>();
            }
        }
        [HttpGet("get-list-application-dlv-no-by-discard")]
        public List<string> GetListApplicationDlvNoByDiscard()
        {

            try
            {
                return context.BolDiscardControls.Where(x => x.Active == true && !x.ApplicationDlvNo.IsNullOrEmpty()).Select(x => x.ApplicationDlvNo).Distinct().ToList();
            }
            catch (Exception e)
            {
                return new List<string>();
            }
        }
        [HttpGet("get-list-department-by-discard")]
        public List<string> GetListDepartmentByDiscard()
        {

            try
            {
                return context.BolDiscardControls.Where(x => x.Active == true).Select(x => x.Department).Distinct().ToList();
            }
            catch (Exception e)
            {
                return new List<string>();
            }
        }
    }
}
