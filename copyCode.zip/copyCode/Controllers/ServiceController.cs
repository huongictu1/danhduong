﻿using AutoMapper;
using DocumentFormat.OpenXml.Drawing;
using DocumentFormat.OpenXml.InkML;
using DocumentFormat.OpenXml.Wordprocessing;
using Hangfire;
using Hangfire.Storage;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using OfficeOpenXml;
using PDCProjectApi.BaseClasses;
using PDCProjectApi.Common;
using PDCProjectApi.Common.Job;
using PDCProjectApi.Data;
using PDCProjectApi.Model.Response;
using PDCProjectApi.Services;
using System.Collections.Concurrent;
using System.Text;

namespace PDCProjectApi.Controllers
{
    /// <summary>
    /// cung cấp API cho bên thứ 3 sử dụng
    /// ví dụ như hệ thống truck booking
    /// </summary>
    [Route("api/service")]
    [ApiController]
    [ApiExplorerSettings(IgnoreApi = true)]
    public class ServiceController : ControllerBase
    {
        private readonly PdcsystemContext context;
        private readonly IEmailService email;
        private readonly ISimulation pa;
        private readonly ITodJob tod;
        private readonly IBackgroundJobClient backgroundJobClient;
        private readonly IGlobalVariable global;
        public ServiceController(IEmailService email, PdcsystemContext ctx, ISimulation pa, ITodJob todd, IBackgroundJobClient _backgroundJobClient, IGlobalVariable gl)
        {
            this.context = ctx;
            this.email = email;
            this.pa = pa;
            this.tod = todd;
            backgroundJobClient = _backgroundJobClient;
            global = gl;
        }
        [HttpGet("get-master-structure-ij")]
        [Authorize(Roles = "service")]
        public async Task<List<TodStructureOutputContentIj>> GetMasterStructureIJ()
        {
            try
            {
                return await context.TodStructureOutputContentIjs.Where(x => x.Active == true).ToListAsync();
            }
            catch (Exception)
            {
                return new List<TodStructureOutputContentIj>();
            }
        }
        [HttpGet("get-header-structure/{product}")]
        [Authorize(Roles = "service")]
        public async Task<TodStructureOutputHeader> GetHeaderStructureIJ(string product)
        {
            try
            {
                return await context.TodStructureOutputHeaders.Where(x => x.Active == true && x.Product == product.ToUpper()).FirstAsync();
            }
            catch (Exception)
            {
                return new TodStructureOutputHeader();
            }
        }

        [HttpGet("get-master-structure-lbp")]
        [Authorize(Roles = "service")]
        public async Task<List<TodStructureOutputContentLbp>> GetMasterStructureLBP()
        {
            try
            {
                return await context.TodStructureOutputContentLbps.Where(x => x.Active == true).ToListAsync();
            }
            catch (Exception)
            {
                return new List<TodStructureOutputContentLbp>();
            }
        }

        [HttpGet("get-structure-truck-booking/{product}")]
        [Authorize(Roles = "service")]
        public async Task<List<TruckBookingModel>> GetStructureTruckBooking(string product)
        {
            try
            {
                var result = new List<TruckBookingModel>();
                if (product.ToLower().Contains("ij"))
                {
                    var result1 = await context.TodStructureOutputContentIjs
                        .Where(x => (x.Model45 != null && x.Merchandise46 != null && x.MerCode47 != null && (x.Model45.Contains(",SK") || x.Model45.StartsWith("SK")))
                            || x.MethodDelivery24 == "Milk-run" || x.PartDelMoving29 == "Shikyu TL->TS")
                        .Select(x => new TruckBookingModel()
                        {
                            Bc1 = x.Bc1,
                            Model14 = x.Model45 == null ? "" : string.Join('+', x.Model45.Split(',', StringSplitOptions.TrimEntries).Distinct().ToList()),
                            Bc12 = x.Bc12,
                            BoxPallet37 = x.Boxpl37,
                            Des21 = x.Des21,
                            DoPic43 = x.DoPic43,
                            EcnLevel4 = x.EcnLevel4,
                            Moq35 = x.Moq35,
                            Name20 = x.Name20,
                            PartName11 = x.PartName11,
                            PartNo8 = x.PartNo8,
                            PcsBox36 = x.Pcsbox36,
                            PcsPallet38 = x.Pcspl38,
                            PoPic44 = x.PoPic44,
                            RouteDelivery28 = x.RouteDelivery28,
                            Product = "IJ",
                            Dim9 = x.Dim9,
                            MethodDelivery24 = x.MethodDelivery24,
                            PartDelMoving29 = x.PartDelMoving29,
                            Pr10 = x.Pr10,
                            Ratio18 = x.Ratio18,
                            Type19 = x.Type19,
                            Destination15 = x.Merchandise46 == null ? "" : string.Join('+', x.Merchandise46.Split(',', StringSplitOptions.TrimEntries).Distinct().ToList()),
                            Merchandise16 = x.MerCode47 == null ? "" : string.Join('+', x.MerCode47.Split(',', StringSplitOptions.TrimEntries).Distinct().ToList())
                        })
                        .ToListAsync();
                    result.AddRange(result1);
                }
                if (product.ToLower().Contains("lbp"))
                {
                    var result2 = await context.TodStructureOutputContentLbps
                        .Where(x => (x.Model45 != null && x.Merchandise46 != null && x.MerCode47 != null && (x.Model45.Contains(",SK") || x.Model45.StartsWith("SK")))
                            || x.MethodDelivery24 == "Milk-run"
                            || x.PartDelMoving29 == "Shikyu QV->TS")
                        .Select(x => new TruckBookingModel()
                        {
                            Bc1 = x.Bc1,
                            Model14 = x.Model45 == null ? "": string.Join('+', x.Model45.Split(',', StringSplitOptions.TrimEntries).Distinct().ToList()),
                            Bc12 = x.Bc12,
                            BoxPallet37 = x.Boxpl37,
                            Des21 = x.Des21,
                            DoPic43 = x.DoPic43,
                            EcnLevel4 = x.EcnLevel4,
                            Moq35 = x.Moq35,
                            Name20 = x.Name20,
                            PartName11 = x.PartName11,
                            PartNo8 = x.PartNo8,
                            PcsBox36 = x.Pcsbox36,
                            PcsPallet38 = x.Pcspl38,
                            PoPic44 = x.PoPic44,
                            RouteDelivery28 = x.RouteDelivery28,
                            Product = "LBP",
                            Dim9 = x.Dim9,
                            MethodDelivery24 = x.MethodDelivery24,
                            PartDelMoving29 = x.PartDelMoving29,
                            Pr10 = x.Pr10,
                            Ratio18 = x.Ratio18,
                            Type19 = x.Type19,
                            Destination15 = x.Merchandise46 == null ? "" : string.Join('+', x.Merchandise46.Split(',', StringSplitOptions.TrimEntries).Distinct().ToList()),
                            Merchandise16 = x.MerCode47 == null ? "" : string.Join('+', x.MerCode47.Split(',', StringSplitOptions.TrimEntries).Distinct().ToList())
                        })
                        .ToListAsync();
                    result.AddRange(result2);
                }
                return result;
            }
            catch (Exception)
            {
                return new List<TruckBookingModel>();
            }
        }

        [HttpGet("warning-stopped-service/{serviceName}")]
        [AllowAnonymous]
        public void ServiceStopped(string serverName, string serviceName)
        {
            email.InitialDev("[Warning] Service stopped", "Server name: " + serverName + ", Service: " + serviceName);
        }

        [HttpGet("test-function-demo")]
        [AllowAnonymous]
        public async Task<IActionResult> TestFunctionDemo(string product, string testcase)
        {

            //////////////double[] arrDo = new double[660];
            //////////////Array.Fill(arrDo, 2);
            //////////////Array.Fill(arrDo, 1.8, 550, 659 - 550 + 1);
            //////////////foreach(var i in arrDo)
            //////////////{
            //////////////Console.Write($"\t{((double)480 / 600) * 100}");
            //////////////}
            //////////////var model = context.VSimulationPartDemandByCellLbps.Select(x => $"{x.Model}_{x.LineNo}").Distinct().ToHashSet();
            //////////////foreach (var h in model)
            //////////////{
            //////////////    Console.WriteLine(h);
            //////////////}
            //await pa.PushLeadtime("LBP", "RC4-4258-000_3100_N278_W5-", true, CancellationToken.None);
            //await pa.PushLeadtime("LBP", "", false, CancellationToken.None);
            //Console.WriteLine($"{(5.09).DSim_RemainIncl_RoundNegative1Decimal()}");
            //Console.WriteLine($"{(-5.09).DSim_RemainIncl_RoundNegative1Decimal()}");
            //Console.WriteLine($"{(6.10).DSim_RemainIncl_RoundNegative1Decimal()}");
            //Console.WriteLine($"{(-6.10).DSim_RemainIncl_RoundNegative1Decimal()}");
            //Console.WriteLine($"Ceiling of Abs {(-120.5).DSim_CeilingOfAbs(49.5, 60)}");
            //await ManualFunc.GetQVData("_pdc_receiving_export");
            Console.WriteLine($"Start {DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")}");
            //await pa.PushQV_LivePP(CancellationToken.None);
            //await tod.CalculateTOD_IJ(true, true, true, true, CancellationToken.None);
            //await pa.ExportOp7FC_DO("IJ", CancellationToken.None);
            //await pa.PushLeadtime("LBP", "", false, CancellationToken.None);
            var ip3ExceptIp6 = context.VSimulationIp3TimeTableDeliveryExceptIp6s.Where(x => x.Vendor == "M425" && x.Product == "IJ" && x.Bc == "3100" && x.FromDate == null && x.Status == true).ToList();
            var model = ip3ExceptIp6.MatchShifts1();
           //await pa.PushQV_AITime(CancellationToken.None);
           //await tod.CalculateTOD_LBP(true, true, true, true, CancellationToken.None);
           //var lst1 = QVAPI.GetQVData_VLivePpByBlock10min();
           //await pa.PushLivePp10Minute(new List<Model.View.PcSimulationLivePPView>(), "LBP", CancellationToken.None);
           //await pa.PushPartMaster(new List<Model.View.PcSimulationLivePPView>(), "LBP", CancellationToken.None);
           Console.WriteLine($"Stoped {DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")}");

            ////Console.WriteLine($"Start {DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")}");
            //////var lst2 = QVAPI.GetQVData_VPdcReceivingExport();
            ////Console.WriteLine($"Stoped {DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")}");
            int a = 0;
            //////var lstWorkingTime = QVAPI.GetQVData_VWorkingTime();
            //////var lstLivePp = QVAPI.GetQVData_VLivePpPriority();
            //Console.WriteLine("Nhap product");
            //string product = Console.ReadLine();
            //Console.WriteLine("Nhap test case");
            //string testCase = Console.ReadLine();
            ////await pa.PushLivePp10MinuteWithChangepp("LBP", CancellationToken.None);
            //await pa.PushOp6SimulationTime("IJ", false, false, true, true, true, true, true, "QX2-6844-000_V144_3100", CancellationToken.None);//LBP FC0-0657-000_V008_3100
            //await pa.PushOp6SimulationTime("IJ", false, false, true, true, true, false, true, "", CancellationToken.None);
            //int[] arrInt = new int[] { 113, 116, 201, 234 };
            //var idxPull = arrInt.Where(iii => iii < 106).LastOrDefault();
            //Console.WriteLine($"idxPull = {idxPull}");
            //////await pa.PushOp6SimulationTime("IJ", false, false, true, true, true, true, true, "CO - Parallel_244", CancellationToken.None);
            //await pa.PushLivePp10MinuteWithChangepp("LBP", CancellationToken.None);
            ////////await pa.PushOp9WarningList("LBP", DateTime.Now, "", CancellationToken.None);
            ////////await pa.GetPoKey("LBP");
            ////////await pa.GetPoKey("IJ");
            ////////await pa.PushOp7FCDO("LBP", CancellationToken.None);
            ////////await pa.PushOp7FCDO("IJ", CancellationToken.None);
            //////await pa.PushLeadtime("LBP", CancellationToken.None);
            ///
            //await pa.PushOp6SimulationTime("IJ", true, false, false, true, false, false, false, "", CancellationToken.None);
            //await pa.PushOp7FCDO("LBP", CancellationToken.None);
            //await pa.PushOp8SimulationDate("LBP", CancellationToken.None);
            //await pa.ExportOp71_NPISCondition("LBP", "", "", "B123", "3100", "N-D+1", new DateOnly(2024, 10, 25), CancellationToken.None);
            //////var a = Math.Ceiling(Math.Abs(-328.8 * 100 / 100) / 10) * 10;
            //////Console.WriteLine(a);
            //////var model = await context.VSimulationIp3TimeTableDeliveries.Where(x => x.Product == "LBP" && x.Vendor == "S841").ToListAsync();
            //////var result = model.MatchShifts();
            //////foreach(var item in result)
            //////{
            //////    Console.WriteLine($"{item.EtaN}_{item.RowNumN}_{item.ShiftN}---{item.EtaD}_{item.RowNumD}_{item.ShiftD}");
            //////}
            //////Console.WriteLine("\n");
            //////model = await context.VSimulationIp3TimeTableDeliveries.Where(x => x.Product == "LBP" && x.Vendor == "SAGR").ToListAsync();
            //////result = model.MatchShifts();
            //////foreach (var item in result)
            //////{
            //////    Console.WriteLine($"{item.EtaN}_{item.RowNumN}_{item.ShiftN}---{item.EtaD}_{item.RowNumD}_{item.ShiftD}");
            //////}
            //////Console.WriteLine("\n");

            //////var model = await context.VSimulationIp3TimeTableDeliveries.Where(x => x.Product == "LBP" && x.Vendor == "N278").ToListAsync();
            //////var result = model.MatchShifts();
            //////foreach (var item in result)
            //////{
            //////    Console.WriteLine($"{item.EtaN}_{item.RowNumN}_{item.ShiftN}---{item.EtaD}_{item.RowNumD}_{item.ShiftD}");
            //////}
            //////Console.WriteLine("\n");
            //////await pa.GetPoKey("LBP");
            //await pa.PushOp8SimulationDate("LBP", CancellationToken.None);
            //await pa.ExportOp6SimulationTime("LBP", CancellationToken.None);
            //await pa.PushPartMaster("IJ", CancellationToken.None);
            //backgroundJobClient.Enqueue(() => pa.ExportOp6SimulationTime("LBP", CancellationToken.None));
            //string name = "nvhuong";
            //await tod.ExportOutputTodOutput7FcDo("LBP");
            //backgroundJobClient.Enqueue(() => tod.Number3_Partcontrol_Calculate_All_NoneP99("LBP", false, false, CancellationToken.None));
            //////await tod.Number3_Partcontrol_Calculate_All_NoneP99("LBP", false, false, CancellationToken.None);
            //var strname = name.Split(',');
            //await tod.Number3_Partcontrol_Calculate_FCDO("LBP", CancellationToken.None);
            //await tod.Number3_Partcontrol_Calculate_FCDO("LBP", CancellationToken.None);

            //var ip3 = await context.VSimulationIp3TimeTableDeliveries.Where(x => x.Product == "LBP" && x.Vendor == "N278").ToListAsync();
            //var result = ip3.MatchShifts();
            //foreach(var res in result)
            //{
            //    Console.WriteLine($"res.EtaN:{res.EtaN} res.EtaD:{res.EtaD} res.RowNumN:{res.RowNumN} res.RowNumD:{res.RowNumD} res.ShiftN:{res.ShiftN} res.ShiftD:{res.ShiftD}");
            //}
            //////int[] arr = new int[4] { 1, 2, 3, 4 };
            //////Console.WriteLine($"Sum {arr[0..2].Sum()}");
            //////Console.WriteLine($"Sum {arr[0..0].Sum()}");
            ////////Console.WriteLine($"Sum {arr[0..-1].Sum()}");
            //////Console.WriteLine($"Sum {arr[2..1].Sum()}");

            //await ADO.doChangeAsync("delete from pc_simulation_master_block_time");
            //var startDay = this.global.ReturnDSML_StartDayShift();
            //var endDay = this.global.ReturnDSML_EndDayShift();
            //var startNight = this.global.ReturnDSML_StartNightShift();
            //var endNight = this.global.ReturnDSML_EndNightShift();
            //int i = 1;
            //DateTime dtStart = new DateTime(2024, 10, 18, startDay.Hour, startDay.Minute, 0);
            //DateTime dtEnd = new DateTime(2024, 10, 18, endDay.Hour, endDay.Minute, 0);
            //DateTime ntStart = new DateTime(2024, 10, 18, startNight.Hour, startNight.Minute, 0);
            //DateTime ntEnd = new DateTime(2024, 10, 19, endNight.Hour, endNight.Minute, 0);
            //var lstModel = new List<PcSimulationMasterBlockTime>();
            //for(DateTime day = dtStart; day < dtEnd; day = day.AddMinutes(10))
            //{
            //    lstModel.Add(new PcSimulationMasterBlockTime()
            //    {
            //        Active = true,
            //        CreatedBy = "System",
            //        OrderTime = i,
            //        EndTime = TimeOnly.FromDateTime(day.AddMinutes(10)),
            //        Shift = "D",
            //        StartTime = TimeOnly.FromDateTime(day)
            //    });
            //    i++;
            //}
            //for (DateTime night = ntStart; night < ntEnd; night = night.AddMinutes(10))
            //{
            //    lstModel.Add(new PcSimulationMasterBlockTime()
            //    {
            //        Active = true,
            //        CreatedBy = "System",
            //        OrderTime = i,
            //        EndTime = TimeOnly.FromDateTime(night.AddMinutes(10)),
            //        Shift = "N",
            //        StartTime = TimeOnly.FromDateTime(night)
            //    });
            //    i++;
            //}
            //context.PcSimulationMasterBlockTimes.AddRange(lstModel);
            //context.SaveChanges();
            return Ok();
        }

        
    }
}
