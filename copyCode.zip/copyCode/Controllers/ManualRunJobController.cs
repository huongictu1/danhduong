﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using PDCProjectApi.Data;
using PDCProjectApi.Model.View;
using System.Net;
using System.Security.Claims;
using PDCProjectApi.Model.Response;
using PDCProjectApi.Model.Request;
using PDCProjectApi.Common;
using System.Linq;
using Quartz;
using PDCProjectApi.Common.Job;

namespace PDCProjectApi.Controllers
{
    [Route("api/manualjob")]
    [ApiController]
    [Authorize]
    //[ApiExplorerSettings(IgnoreApi = true)]
    public class ManualRunJobController : Controller
    {
        private readonly IScheduler _scheduler;

        public ManualRunJobController(IScheduler scheduler)
        {
            this._scheduler = scheduler;
        }

        [HttpGet("run-job-calc-ouput-structure-ij")]
        public async Task<IActionResult> RunJobCalcStructureIj()
        {
            try
            {
                // Tạo một instance của job
                IJobDetail job = JobBuilder.Create<UpdateLinkageIJData>()
                    .WithIdentity("JobOutputStructureIJ", "group1")
                    .Build();

                // Tạo một trigger để kích hoạt job ngay lập tức
                ITrigger trigger = TriggerBuilder.Create()
                    .WithIdentity("JobOutputStructureIJ", "group1")
                    .StartNow()
                    .Build();

                // Lên lịch kích hoạt job
                await _scheduler.ScheduleJob(job, trigger);

                return Ok("Job đã được kích hoạt thành công!");
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Lỗi khi kích hoạt job: {ex.Message}");
            }
        }

        [HttpGet("run-job-calc-ouput-structure-lbp")]
        [AllowAnonymous]
        public async Task<IActionResult> RunJobCalcStructureLbp()
        {
            try
            {
                // Tạo một instance của job
                IJobDetail job = JobBuilder.Create<UpdateLinkageLBPData>()
                    .WithIdentity("JobOutputStructureLBP", "group2")
                    .Build();

                // Tạo một trigger để kích hoạt job ngay lập tức
                ITrigger trigger = TriggerBuilder.Create()
                    .WithIdentity("JobOutputStructureLBP", "group2")
                    .StartNow()
                    .Build();

                // Lên lịch kích hoạt job
                await _scheduler.ScheduleJob(job, trigger);

                return Ok("Job đã được kích hoạt thành công!");
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Lỗi khi kích hoạt job: {ex.Message}");
            }
        }

        [HttpGet("run-job-calc-fc-delivery")]
        public async Task<IActionResult> RunJobCalcFCDelivery()
        {
            try
            {
                // Tạo một instance của job
                //IJobDetail job = JobBuilder.Create<FCVolumeCalculate>()
                //    .WithIdentity("JobCalculateFCData", "group3")
                //    .Build();

                //// Tạo một trigger để kích hoạt job ngay lập tức
                //ITrigger trigger = TriggerBuilder.Create()
                //    .WithIdentity("JobCalculateFCData", "group3")
                //    .StartNow()
                //    .Build();

                //// Lên lịch kích hoạt job
                //await _scheduler.ScheduleJob(job, trigger);

                return Ok("Job đã được kích hoạt thành công!");
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Lỗi khi kích hoạt job: {ex.Message}");
            }
        }
        [HttpGet("run-job-insert-b101-ij-to-redis")]
        public async Task<IActionResult> RunJobInsertB101ToRedis()
        {
            try
            {
                // Tạo một instance của job
                IJobDetail job = JobBuilder.Create<GetLinkageB101IJ>()
                    .WithIdentity("JobInsertB101ToRedis", "group4")
                    .Build();

                // Tạo một trigger để kích hoạt job ngay lập tức
                ITrigger trigger = TriggerBuilder.Create()
                    .WithIdentity("JobInsertB101ToRedis", "group4")
                    .StartNow()
                    .Build();

                // Lên lịch kích hoạt job
                await _scheduler.ScheduleJob(job, trigger);

                return Ok("Job đã được kích hoạt thành công!");
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Lỗi khi kích hoạt job: {ex.Message}");
            }
        }
        [HttpGet("run-job-insert-b101-lbp-to-redis")]
        public async Task<IActionResult> RunJobInsertB101LBPToRedis()
        {
            
            try
            {
                // Tạo một instance của job
                IJobDetail job = JobBuilder.Create<GetLinkageB101LBP>()
                    .WithIdentity("JobInsertB101LBPToRedis", "group5")
                    .Build();

                // Tạo một trigger để kích hoạt job ngay lập tức
                ITrigger trigger = TriggerBuilder.Create()
                    .WithIdentity("JobInsertB101LBPToRedis", "group5")
                    .StartNow()
                    .Build();

                // Lên lịch kích hoạt job
                await _scheduler.ScheduleJob(job, trigger);

                return Ok("Job đã được kích hoạt thành công!");
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Lỗi khi kích hoạt job: {ex.Message}");
            }
        }
        [HttpGet("run-job-new-comer")]
        [AllowAnonymous]
        public async Task<IActionResult> RunJobNewComer()
        {

            try
            {
                // Tạo một instance của job
                IJobDetail job = JobBuilder.Create<SynchonizeNewcomer>()
                    .WithIdentity("JobNewComers", "group6")
                    .Build();

                // Tạo một trigger để kích hoạt job ngay lập tức
                ITrigger trigger = TriggerBuilder.Create()
                    .WithIdentity("JobNewComers", "group6")
                    .StartNow()
                    .Build();

                // Lên lịch kích hoạt job
                await _scheduler.ScheduleJob(job, trigger);

                return Ok("Job đã được kích hoạt thành công!");
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Lỗi khi kích hoạt job: {ex.Message}");
            }
        }
        [HttpGet("run-job-department")]
        public async Task<IActionResult> RunJobDepartment()
        {

            try
            {
                // Tạo một instance của job
                IJobDetail job = JobBuilder.Create<SynchonizeDepartment>()
                    .WithIdentity("JobDepartment", "group7")
                    .Build();

                // Tạo một trigger để kích hoạt job ngay lập tức
                ITrigger trigger = TriggerBuilder.Create()
                    .WithIdentity("JobDepartment", "group7")
                    .StartNow()
                    .Build();

                // Lên lịch kích hoạt job
                await _scheduler.ScheduleJob(job, trigger);

                return Ok("Job đã được kích hoạt thành công!");
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Lỗi khi kích hoạt job: {ex.Message}");
            }
        }
        [HttpGet("run-job-email")]
        public async Task<IActionResult> RunJobEmail()
        {

            try
            {
                // Tạo một instance của job
                IJobDetail job = JobBuilder.Create<SynchonizeEmail>()
                    .WithIdentity("JobEmail", "group8")
                    .Build();

                // Tạo một trigger để kích hoạt job ngay lập tức
                ITrigger trigger = TriggerBuilder.Create()
                    .WithIdentity("JobEmail", "group8")
                    .StartNow()
                    .Build();

                // Lên lịch kích hoạt job
                await _scheduler.ScheduleJob(job, trigger);

                return Ok("Job đã được kích hoạt thành công!");
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Lỗi khi kích hoạt job: {ex.Message}");
            }
        }
        [HttpGet("run-job-calc-op-all")]
        public async Task<IActionResult> RunJobCalcOPAll()
        {

            try
            {
                //// Tạo một instance của job
                //IJobDetail job = JobBuilder.Create<CalcOPAll>()
                //    .WithIdentity("JobCalcOpTodAll", "group9")
                //    .Build();

                //// Tạo một trigger để kích hoạt job ngay lập tức
                //ITrigger trigger = TriggerBuilder.Create()
                //    .WithIdentity("JobCalcOpTodAll", "group9")
                //    .StartNow()
                //    .Build();

                //// Lên lịch kích hoạt job
                //await _scheduler.ScheduleJob(job, trigger);

                return Ok("Job đã được kích hoạt thành công!");
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Lỗi khi kích hoạt job: {ex.Message}");
            }
        }
    }
}
