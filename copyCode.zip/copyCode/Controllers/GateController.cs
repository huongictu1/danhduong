﻿using Hangfire;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using PDCProjectApi.Common.Job;
using PDCProjectApi.Common;
using PDCProjectApi.Services;

namespace PDCProjectApi.Controllers
{
    [Route("api/background")]
    [ApiController]
    public class GateController : ControllerBase
    {
        private readonly ITodJob tod;
        private readonly ILeadTimeJob led;
        private readonly IPartAdjustmentJob _pad;
        private readonly ISimulation _sim;
        private readonly IEmailService _email;
        private readonly IManualJob _man;
        public GateController(ITodJob job, ILeadTimeJob l, IEmailService email, IPartAdjustmentJob pad, ISimulation sim, IManualJob manual)
        {
            tod = job;
            led = l;
            _email = email;
            _pad = pad;
            _sim = sim;
            _man = manual;
        }
        
    }
}
