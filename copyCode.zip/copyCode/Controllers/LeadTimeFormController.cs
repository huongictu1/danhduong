﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using PDCProjectApi.Common.Interface;
using PDCProjectApi.Data;
using AutoMapper;
using PDCProjectApi.Model.View;
using PDCProjectApi.Model.Request;
using PDCProjectApi.Common;
using Microsoft.EntityFrameworkCore;
using PDCProjectApi.Helper;
using PDCProjectApi.Model.Response;
using System.Security.Claims;
using System.Net;
using Microsoft.AspNetCore.Authorization;
using Newtonsoft.Json;
using PDCProjectApi.Common.Job;
using StackExchange.Redis;
using PDCProjectApi.Services;
using AutoMapper.QueryableExtensions;
using OfficeOpenXml;
using Hangfire;

namespace PDCProjectApi.Controllers
{
    [Route("api/leadtimeform")]
    [ApiController]
    [Authorize]
    //[ApiExplorerSettings(IgnoreApi = true)]
    public class LeadTimeFormController : Controller
    {
        [Obsolete]
        private readonly Microsoft.AspNetCore.Hosting.IHostingEnvironment _hostingEnvironment;
        private readonly IHttpContextAccessor httpContextAccessor;
        private readonly IFileStorageService fileStorageService;
        private readonly PdcsystemContext context;
        private readonly IConfiguration configuration;
        private readonly IEmailService email;
        private readonly IBackgroundJobClient _bgJobClient;

        [Obsolete]
        public LeadTimeFormController(Microsoft.AspNetCore.Hosting.IHostingEnvironment hosting,
            PdcsystemContext ctx, IHttpContextAccessor httpContextAccessor, IFileStorageService fileService,
            IConfiguration configuration, IEmailService mail, IBackgroundJobClient backgroundJobClient)
        {
            this._hostingEnvironment = hosting;
            this.httpContextAccessor = httpContextAccessor;
            this.context = ctx;
            this.fileStorageService = fileService;
            this.configuration = configuration;
            this.email = mail;
            this._bgJobClient = backgroundJobClient;
        }


        #region form register pdc2 
        [HttpGet("get-request-pdc2-requestno")]
        public List<string> GetRequestPDC2RequestNo()
        {
            try
            {
                var dateNow = DateTime.Now.ToString("yyyy_MM_dd");
                var lstRequest = new List<string>();
                var requestNo = GetNewRequestNo("RQ-" + "FLT-PDC2-" + dateNow, "PDC2");
                lstRequest.Add(requestNo);
                return lstRequest;

            }
            catch (Exception)
            {
                return new List<string>();
            }
        }

        [HttpPost("add-request-form-register-pdc2")]
        public CommonResponse AddRequestFormRegisterPdc2([FromForm] FormRegisterLTRequest rq)

        {
            CommonResponse res = new CommonResponse()
            {
                Error = false,
                Message = "",
                Status = (int)HttpStatusCode.BadRequest
            };
            try
            {
                var u = GetCurrentUser();
                var dateNow = DateTime.Now.ToString("yyyy_MM_dd");
                var lstRequest = new List<string>();
                var requestNo = GetNewRequestNo("RQ-" + "FLT-PDC2-" + dateNow, "PDC2");
                List<LtFormRegistrationPdc2Item> lstAdd = new List<LtFormRegistrationPdc2Item>();

                //var lstMasterItem = context.LtFormRegistrationPdc2Items.Include(x => x.ItemGroup).Where(x => x.Active == true).ToList();
                //var lstUser = context.UserInformations.Include(x => x.DetailUserDepts).ThenInclude(x => x.Dept).Where(x => x.Active == true);

                using (var memoStream = new MemoryStream())
                {
                    rq.ReviseFile[0].CopyTo(memoStream);
                    ExcelPackage.LicenseContext = LicenseContext.NonCommercial;
                    using (var package = new ExcelPackage(memoStream))
                    {
                        var worksheet = package.Workbook.Worksheets[0];
                        var rowCount = worksheet.Dimension?.Rows;

                        if (rowCount.HasValue && rowCount.Value > 14)
                        {

                            int j = 15;

                            for (int row = 1; row <= (rowCount.Value - 14); row++)
                            {

                                if (worksheet.Cells["B" + j].Value != null && worksheet.Cells["B" + j].Value != "")
                                {

                                    var obj8 = worksheet.Cells["K" + j].Value;
                                    DateOnly? effctiveDate = null;
                                    try
                                    {
                                        double d = (double)obj8;
                                        var date = DateTime.FromOADate(d);

                                        effctiveDate = DateOnly.FromDateTime(date); ;
                                    }
                                    catch
                                    {
                                        try
                                        {
                                            effctiveDate = DateOnly.FromDateTime(DateTime.Parse(obj8.ObjToStringAble()));
                                        }
                                        catch
                                        {
                                            effctiveDate = null;
                                        }

                                    }
                                    lstAdd.Add(new LtFormRegistrationPdc2Item
                                    {
                                        CreatedBy = u.UserName,
                                        PartNo = Convert.ToString(worksheet.Cells["B" + j].Value).Trim(),
                                        PartName = Convert.ToString(worksheet.Cells["C" + j].Value),
                                        Vendor = Convert.ToString(worksheet.Cells["D" + j].Value),
                                        PcsBox = Convert.ToString(worksheet.Cells["E" + j].Value),
                                        Model = Convert.ToString(worksheet.Cells["F" + j].Value).Trim(),
                                        Layout = Convert.ToString(worksheet.Cells["G" + j].Value),
                                        Khsx = Convert.ToString(worksheet.Cells["H" + j].Value),
                                        ChangingReason = Convert.ToString(worksheet.Cells["I" + j].Value),
                                        ChangingSupplyGroup = Convert.ToString(worksheet.Cells["J" + j].Value),
                                        RequestEffectiveDate = effctiveDate,
                                        MovingRecStoreSupplyQty = Convert.ToString(worksheet.Cells["L" + j].Value),
                                        MovingRecStoreCycleSupply = Convert.ToString(worksheet.Cells["M" + j].Value),
                                        MovingRecStoreCycleTime = Convert.ToString(worksheet.Cells["N" + j].Value),
                                        MovingRecStoreReceivingTime = Convert.ToString(worksheet.Cells["O" + j].Value),
                                        MovingRecStoreFrom = Convert.ToString(worksheet.Cells["P" + j].Value),
                                        MovingRecStoreTo = Convert.ToString(worksheet.Cells["Q" + j].Value),
                                        MovingRecStoreDistance = Convert.ToString(worksheet.Cells["R" + j].Value),
                                        MovingRecStoreTransportation = Convert.ToString(worksheet.Cells["S" + j].Value),
                                        MovingRecStoreMovingTime = Convert.ToString(worksheet.Cells["T" + j].Value),
                                        MovingRecStoreInputStock = Convert.ToString(worksheet.Cells["U" + j].Value),
                                        MovingAssyStorePickupTime = Convert.ToString(worksheet.Cells["V" + j].Value),
                                        MovingAssyStoreFromLocation = Convert.ToString(worksheet.Cells["W" + j].Value),
                                        MovingAssyStoreFromAddress = Convert.ToString(worksheet.Cells["X" + j].Value),
                                        MovingAssyStoreToLocation = Convert.ToString(worksheet.Cells["Y" + j].Value),
                                        MovingAssyStoreToAddress = Convert.ToString(worksheet.Cells["Z" + j].Value),
                                        MovingAssyStoreDistance = Convert.ToString(worksheet.Cells["AA" + j].Value),
                                        MovingAssyStoreTransportation = Convert.ToString(worksheet.Cells["AB" + j].Value),
                                        MovingAssyStoreCrossPoint = Convert.ToString(worksheet.Cells["AC" + j].Value),
                                        MovingAssyStoreMovingTime = Convert.ToString(worksheet.Cells["AD" + j].Value),
                                        MovingAssyStoreSuppyTime = Convert.ToString(worksheet.Cells["AE" + j].Value),
                                        MovingAssyStoreSafetyQty = Convert.ToString(worksheet.Cells["AF" + j].Value),
                                        TotalLeadtime = Convert.ToString(worksheet.Cells["AG" + j].Value),
                                        Note = Convert.ToString(worksheet.Cells["AH" + j].Value),
                                        RequestNo = requestNo
                                    });
                                }

                                j++;
                            }
                            if (lstAdd.Count == 0)
                            {
                                res.Error = true;
                                res.Message = "Table not have data!";
                                res.Status = (int)HttpStatusCode.BadRequest;
                                return res;
                            }
                            context.LtFormRegistrationPdc2Items.AddRange(lstAdd);
                            context.SaveChanges();

                            //save infor
                            var addInfor = new LtFormRegistrationPdc2Infor
                            {
                                Active = true,
                                RequestNo = requestNo,
                                RequestBy = u.FullName,
                                Note = rq.Note,
                                CreatedBy = u.UserName,
                                Status = null,
                                Department = u.Departments
                            };
                            context.Add(addInfor);
                            context.SaveChanges();

                            //save process
                            var lstGrade = new List<string>() { "Dept. Approval", "PDC1 PIC check", "PDC1 Approval" };
                            var i = 1;
                            foreach (var grade in lstGrade)
                            {
                                var addProcess = new LtFormRegistrationPdc2Process
                                {
                                    Active = true,
                                    RequestNo = requestNo,
                                    Grade = grade,
                                    OrderNo = i,
                                    Next = i == 1 ? true : false,
                                };
                                i++;
                                context.Add(addProcess);
                                context.SaveChanges();
                            }

                            res.Error = false;
                            res.Message = "Successfull!";
                            res.Status = (int)HttpStatusCode.OK;
                        }

                    }
                }

            }
            catch (Exception e)
            {
                res.Error = true;
                res.Message = e.Message;
                res.Status = (int)HttpStatusCode.BadRequest;
            }
            return res;
        }
        //lấy thông tin  request list
        [HttpPost("fillter-request-form-register-pdc2-list/{status}")]
        public LtFormRegistrationPdc2InforModel FillterRequestFormRegisterPdc2(PaginationParams param,string status)
        {
            try
            {
                param.search = param.search.ToUpper().Trim();
                var result = new LtFormRegistrationPdc2InforModel();
                var lstResult = new List<RequestLeadTimeFormInforView>();
                var u = GetCurrentUser();
                int? statusAppr = status == "ALL" ? 3 : (status == "Approved" ? 1:(status == "Checking" ? 0: 2));

                var process = context.LtFormRegistrationPdc2Processes.Where(x => x.Active == true);
                var model = context.LtFormRegistrationPdc2Infors.Where(x => (x.CreatedBy.Contains(param.search) || x.RequestNo.ToUpper().Contains(param.search) || x.RequestBy.ToUpper().Contains(param.search)) 
                && x.Active == true 
                && (statusAppr == 3? x.Active == true : x.Status == statusAppr)
                && (x.Status != null || x.CreatedBy == u.UserName)).OrderByDescending(x => x.CreatedDate).ToList();


                var model2 = model.Skip((param.Page - 1) * param.RecordsPerPage).Take(param.RecordsPerPage).ToList();
                int i = 0;
                foreach (var item in model2)
                {
                    bool? canEdit = false;
                    var isReturn = model.Any(x => x.Status != 1 && x.RequestNo == item.RequestNo);
                    if (isReturn == true)
                    {
                        canEdit = true;
                    }
                    var nextApprove = process.FirstOrDefault(x => x.Next == true && x.RequestNo == item.RequestNo);
                    // var createdBy = context.UserInformations.Where(x => x.EmployeeCode == item.CreatedBy).FirstOrDefault();
                    lstResult.Add(new RequestLeadTimeFormInforView()
                    {
                        Id = item.Id,
                        RequestNo = item.RequestNo,
                        CreatedDate = item.CreatedDate == null ? null : item.CreatedDate.Value.ToString("dd-MMM-yyyy"),
                        CreatedBy = item.CreatedBy,
                        Status = item.Status,
                        CanEdit = canEdit,
                        Department = item.Department,
                        IsCreated = u.UserName == item.CreatedBy,
                        RequestBy = item.RequestBy,
                        NextApprover = nextApprove == null? null: nextApprove.Grade
                    }); i++;
                }
                result.lstModel = lstResult;
                result.toRecord = (int)Math.Min(result.totalRecords, result.currentPage * result.recordPerPage);
                result.totalPage = (int)Math.Ceiling((decimal)model.Count / param.RecordsPerPage);
                result.totalRecords = model.Count;
                result.recordPerPage = param.RecordsPerPage;
                result.currentPage = param.Page;
                result.fromRecord = model.Count == 0 ? 0 : (result.currentPage - 1) * result.recordPerPage + 1;
                //}
                return result;
            }
            catch (Exception)
            {
                return new LtFormRegistrationPdc2InforModel();
            }
        }

        [HttpGet("get-infor-request-form-register-pdc2/{requestNo}")]
        public RequestLeadTimeFormInforView GetInforFormRegisterPdc2(string requestNo)
        {
            try
            {
                var u = GetCurrentUser();
                var model = context.LtFormRegistrationPdc2Infors.Where(x => x.Active == true && x.RequestNo == requestNo).FirstOrDefault();
                var lstMaxPP = context.LtInputMaxPpCells.Where(x => x.Active == true).Select(x => x.Model).ToList();
                var lstModelNotPP = context.LtFormRegistrationPdc2Items.Where(x => x.Active == true && x.RequestNo == requestNo && !lstMaxPP.Contains(x.Model) && x.Model != null && x.Model.Trim() != "").Select(x => x.Model).Distinct().ToList();
                var modelNotPP = lstModelNotPP.Count == 0?null: string.Join(";", lstModelNotPP);
                var infor = new RequestLeadTimeFormInforView
                {
                    RequestNo = model.RequestNo,
                    RequestBy = model.RequestBy,
                    Department = model.Department,
                    CreatedDate = model.CreatedDate.Value.ToString("dd-MMM-yyyy"),
                    Note = model.Note,
                    Status = model.Status,
                    CreatedBy = model.CreatedBy,
                    LstNotMaxPP = modelNotPP
                };
                return infor;

            }
            catch (Exception)
            {
                return new RequestLeadTimeFormInforView(); ;
            }
        }

        [HttpPost("get-item-request-form-register-pdc2/{requestNo}")]
        public async Task<LtFormRegistrationPdc2Model> GetItemFormRegisterPdc2(PaginationParams param, string requestNo)
        {
            try
            {
                try
                {

                    LtFormRegistrationPdc2Model result = new LtFormRegistrationPdc2Model()
                    {
                        currentPage = param.Page,
                        recordPerPage = param.RecordsPerPage
                    };
                    var query = context.LtFormRegistrationPdc2Items.Where(x => x.Active == true && x.RequestNo == requestNo);

                    query = !string.IsNullOrEmpty(param.search) ? query.Where(x => x.PartNo.ToUpper().Contains(param.search.ToUpper()) || x.Model.ToUpper().Contains(param.search.ToUpper()) || x.Vendor.ToUpper().Contains(param.search.ToUpper())) : query;
                    result.totalRecords = await query.CountAsync();
                    result.totalPage = (int)Math.Ceiling((decimal)result.totalRecords / param.RecordsPerPage);
                    var model = await query.ToListAsync();
                    result.lstModel = model;
                    result.fromRecord = model.Count == 0 ? 0 : (result.currentPage - 1) * result.recordPerPage + 1;
                    result.toRecord = (int)Math.Min(result.totalRecords, result.currentPage * result.recordPerPage);
                    result.currentPage = result.totalPage < result.currentPage ? result.totalPage : result.currentPage;
                    return result;
                }
                catch (Exception e)
                {
                    //SendMailError(e);
                    return new LtFormRegistrationPdc2Model()
                    {
                        currentPage = param.Page,
                        recordPerPage = param.RecordsPerPage
                    };
                }
            }
            catch (Exception)
            {
                return new LtFormRegistrationPdc2Model(); ;
            }
        }

        [HttpGet("get-process-request-form-register-pdc2/{requestNo}")]
        public List<LtFormRegistrationPdc2Process> GetProcessFormRegisterPdc2(string requestNo)
        {
            try
            {
                var model = context.LtFormRegistrationPdc2Processes.Where(x => x.Active == true && x.RequestNo == requestNo).OrderBy(x => x.OrderNo).ToList();
                return model;

            }
            catch (Exception)
            {
                return new List<LtFormRegistrationPdc2Process>(); ;
            }
        }

        //kiểm tra xem có phải người đăng nhập đang ở trạng thái được approve không?
        [HttpGet("check-approver-request-form-register-pdc2/{requestNo}")]
        public bool CheckApproverFormRegisterPdc2(string requestNo)
        {
            try
            {
                var u = GetCurrentUser();
                var model = context.LtFormRegistrationPdc2Processes.Where(x => x.Active == true && x.RequestNo == requestNo && x.Next == true).FirstOrDefault();
                if (model != null)
                {
                    bool check = false;
                    if (model.OrderNo == 1)
                    {
                        // group approver pdc2
                        check = context.AdmDetailUserGroups.Any(x => x.Active == true && x.UserId == new Guid(u.Id) && x.GroupId == new Guid("f1184a5a-7024-4f3b-a229-b944eaafe689"));

                    }
                    if (model.OrderNo == 2)
                    {
                        //group pic pdc1
                        check = context.AdmDetailUserGroups.Any(x => x.Active == true && x.UserId == new Guid(u.Id) && x.GroupId == new Guid("56254ddd-e2cd-460d-a245-27d58f8953d4"));

                    }
                    if (model.OrderNo == 3)
                    {
                        //group g6up pdc1
                        check = context.AdmDetailUserGroups.Any(x => x.Active == true && x.UserId == new Guid(u.Id) && x.GroupId == new Guid("62e95f1a-7590-465e-8cf3-ff7932322b2b"));

                    }
                    return check;
                }
                else
                {
                    return false;
                }

            }
            catch (Exception)
            {
                return false;
            }
        }

        [HttpPut("active-request-form-register-pdc2")]
        public CommonResponse ActiveFormRegisterPdc2(string[] requestNo)
        {
            CommonResponse res = new CommonResponse()
            {
                Error = false,
                Message = "",
                Status = (int)HttpStatusCode.BadRequest
            };
            try
            {
                var u = GetCurrentUser();
                var request_no = requestNo[0];
                //active infor
                ADO.doChange("update lt_form_registration_pdc2_infor set active = false where request_no = '" + request_no + "';");

                //active item
                ADO.doChange("update lt_form_registration_pdc2_item set active = false where request_no = '" + request_no + "';");

                //active process
                ADO.doChange("update lt_form_registration_pdc2_process set active = false where request_no = '" + request_no + "';");

                res.Error = false;
                res.Message = "Successfull!";
                res.Status = (int)HttpStatusCode.OK;


            }
            catch (Exception e)
            {
                res.Error = true;
                res.Message = e.Message;
                res.Status = (int)HttpStatusCode.BadRequest;

            }

            return res;
        }

        [HttpGet("send-approver-request-form-register-pdc2/{requestNo}")]
        public CommonResponse SendApproverFormRegisterPdc2(string requestNo)
        {
            CommonResponse res = new CommonResponse()
            {
                Error = false,
                Message = "",
                Status = (int)HttpStatusCode.BadRequest
            };
            try
            {
                var u = GetCurrentUser();
                var model = context.LtFormRegistrationPdc2Infors.Where(x => x.Active == true && x.RequestNo == requestNo).FirstOrDefault();
                model.Status = 0;
                context.Update(model);
                context.SaveChanges();
                //check all member group approver pdc2
                var checkApprovalDept = context.AdmDetailUserGroups.Include(x => x.User).Where(x => x.Active == true && x.GroupId == new Guid("f1184a5a-7024-4f3b-a229-b944eaafe689")).ToList();
                if (checkApprovalDept.Count > 0)
                {
                    var link = "http://cvn-vpsi/#/leadtime/form-register/pdc2-detail/" + requestNo;
                    var lstReceiver = checkApprovalDept.Where(x => x.User.Active == true && x.User.Email != null && x.User.Email != "").Select(y => y.User.Email).ToList();
                    SendMailRemind("form registration for pdc2", u.FullName, lstReceiver, link);
                }

                res.Error = false;
                res.Message = "Successfull!";
                res.Status = (int)HttpStatusCode.OK;

            }
            catch (Exception e)
            {
                res.Error = true;
                res.Message = e.Message;
                res.Status = (int)HttpStatusCode.BadRequest;
            }
            return res;
        }

        [HttpPut("approve-request-form-register-pdc2/{id}")]
        public CommonResponse ApproveFormRegisterPdc2(string[] comment, Guid id)
        {
            CommonResponse res = new CommonResponse()
            {
                Error = false,
                Message = "",
                Status = (int)HttpStatusCode.BadRequest
            };
            try
            {
                var u = GetCurrentUser();
                var cmt = comment[0];
                var model = context.LtFormRegistrationPdc2Processes.FirstOrDefault(x => x.Active == true && x.Id == id);

                if (model != null)
                {
                    var maxOrder = context.LtFormRegistrationPdc2Processes.Where(x => x.Active == true && x.RequestNo == model.RequestNo).Max(y => y.OrderNo);
                    model.Status = 1;
                    model.Approver = u.UserName;
                    model.ApproverName = u.FullName;
                    model.ApprovedDate = DateTime.Now.ToString("dd-MMM-yyyy");
                    model.Next = false;
                    model.Comment = cmt;
                    context.Update(model);
                    if (model.OrderNo == 1)
                    {

                        var nextApprove = context.LtFormRegistrationPdc2Processes.FirstOrDefault(x => x.Active == true && x.RequestNo == model.RequestNo && x.OrderNo == 2);
                        if (nextApprove != null)
                        {
                            nextApprove.Next = true;
                            context.Update(nextApprove);
                            //check all member group pic pdc1
                            var checkApprovalPDC1 = context.AdmDetailUserGroups.Include(x => x.User).Where(x => x.Active == true && x.GroupId == new Guid("56254ddd-e2cd-460d-a245-27d58f8953d4")).ToList();
                            if (checkApprovalPDC1.Count > 0)
                            {
                                var link = "http://cvn-vpsi/#/leadtime/form-register/pdc2-detail/" + model.RequestNo;
                                var lstReceiver = checkApprovalPDC1.Where(x => x.User.Active == true && x.User.Email != null && x.User.Email != "").Select(y => y.User.Email).ToList();
                                SendMailRemind("form registration for pdc2", u.FullName, lstReceiver, link);
                            }
                        }
                    }
                    if (model.OrderNo == 2)
                    {

                        var nextApprove = context.LtFormRegistrationPdc2Processes.FirstOrDefault(x => x.Active == true && x.RequestNo == model.RequestNo && x.OrderNo == maxOrder);
                        if (nextApprove != null)
                        {
                            nextApprove.Next = true;
                            context.Update(nextApprove);
                            //check all member group g6up pdc1
                            var checkApprovalPDC1 = context.AdmDetailUserGroups.Include(x => x.User).Where(x => x.Active == true && x.GroupId == new Guid("62e95f1a-7590-465e-8cf3-ff7932322b2b")).ToList();
                            if (checkApprovalPDC1.Count > 0)
                            {
                                var link = "http://cvn-vpsi/#/leadtime/form-register/pdc2-detail/" + model.RequestNo;
                                var lstReceiver = checkApprovalPDC1.Where(x => x.User.Active == true && x.User.Email != null && x.User.Email != "").Select(y => y.User.Email).ToList();
                                SendMailRemind("form registration for pdc2", u.FullName, lstReceiver, link);
                            }
                        }
                    }
                    if (model.OrderNo == maxOrder)
                    {
                        var infor = context.LtFormRegistrationPdc2Infors.FirstOrDefault(x => x.Active == true && x.RequestNo == model.RequestNo);
                        if (infor != null)
                        {
                            infor.Status = 1;
                            infor.ModifiedDate = DateTime.Now.SetKindUtc();
                            context.Update(infor);

                            var link = "http://cvn-vpsi/#/leadtime/form-register/pdc2-detail/" + model.RequestNo;
                            var user = context.AdmUserInformations.FirstOrDefault(x => x.EmployeeCode == infor.CreatedBy);
                            var receiver = user.FullName;
                            var lstReceiver = user == null ? new List<string>() : new List<string>() { user.Email };
                            SendMailApproved("form registration for pdc2", u.FullName, lstReceiver, receiver, link);

                        }
                        var lstUpdate = context.LtFormRegistrationPdc2Items.Where(x => x.Active == true && x.RequestNo == model.RequestNo).ToList();
                        lstUpdate.ForEach(x => x.ApprovedStatus = 1);
                        context.UpdateRange(lstUpdate);
                    }
                    context.SaveChanges();
                }

                res.Error = false;
                res.Message = "Successfull!";
                res.Status = (int)HttpStatusCode.OK;


            }
            catch (Exception e)
            {
                res.Error = true;
                res.Message = e.Message;
                res.Status = (int)HttpStatusCode.BadRequest;

            }

            return res;
        }

        [HttpPut("reject-request-form-register-pdc2/{id}")]
        public CommonResponse RejectFormRegisterPdc2(string[] comment, Guid id)
        {
            CommonResponse res = new CommonResponse()
            {
                Error = false,
                Message = "",
                Status = (int)HttpStatusCode.BadRequest
            };
            try
            {
                var u = GetCurrentUser();
                var cmt = comment[0];
                var model = context.LtFormRegistrationPdc2Processes.FirstOrDefault(x => x.Active == true && x.Id == id);

                if (model != null)
                {
                    model.Status = 2;
                    model.Approver = u.UserName;
                    model.ApproverName = u.FullName;
                    model.ApprovedDate = DateTime.Now.ToString("dd-MMM-yyyy");
                    model.Next = false;
                    model.Comment = cmt;
                    context.Update(model);

                    var infor = context.LtFormRegistrationPdc2Infors.FirstOrDefault(x => x.Active == true && x.RequestNo == model.RequestNo);
                    infor.Status = 2;
                    infor.ModifiedDate = DateTime.Now.SetKindUtc();
                    context.Update(infor);

                    context.SaveChanges();

                    var link = "http://cvn-vpsi/#/leadtime/form-register/pdc2-detail/" + model.RequestNo;
                    var user = context.AdmUserInformations.FirstOrDefault(x => x.EmployeeCode == infor.CreatedBy);
                    var receiver = user.FullName;
                    var lstReceiver = user == null ? new List<string>() : new List<string>() { user.Email };

                    SendMailRejectd("form registration for pdc2", cmt, u.FullName, lstReceiver, receiver, link);
                    //check approved
                    if (model.OrderNo != 1)
                    {
                        var lstApproved = context.LtFormRegistrationPdc2Processes.Where(x => x.Active == true && x.RequestNo == model.RequestNo && x.OrderNo < model.OrderNo).ToList();
                        foreach (var approved in lstApproved)
                        {
                            var userApproved = context.AdmUserInformations.FirstOrDefault(x => x.EmployeeCode == approved.Approver);
                            var receiverApproved = userApproved.FullName;
                            var lstReceiverApproved = userApproved == null ? new List<string>() : new List<string>() { userApproved.Email };
                            SendMailRejectd("form registration for pdc2", cmt, u.FullName, lstReceiverApproved, receiverApproved, link);
                        }
                    }


                }

                res.Error = false;
                res.Message = "Successfull!";
                res.Status = (int)HttpStatusCode.OK;


            }
            catch (Exception e)
            {
                res.Error = true;
                res.Message = e.Message;
                res.Status = (int)HttpStatusCode.BadRequest;

            }

            return res;
        }
        #endregion

        #region form register log 
        [HttpGet("get-request-log-requestno")]
        public List<string> GetRequestLOGRequestNo()
        {
            try
            {
                var dateNow = DateTime.Now.ToString("yyyy_MM_dd");
                var lstRequest = new List<string>();
                var requestNo = GetNewRequestNo("RQ-" + "FLT-LOG-" + dateNow, "LOG");
                lstRequest.Add(requestNo);
                return lstRequest;

            }
            catch (Exception)
            {
                return new List<string>();
            }
        }

        [HttpPost("add-request-form-register-log")]
        public CommonResponse AddRequestFormRegisterLog([FromForm] FormRegisterLTRequest rq)

        {
            CommonResponse res = new CommonResponse()
            {
                Error = false,
                Message = "",
                Status = (int)HttpStatusCode.BadRequest
            };
            try
            {
                var u = GetCurrentUser();
                var dateNow = DateTime.Now.ToString("yyyy_MM_dd");
                var lstRequest = new List<string>();
                var requestNo = GetNewRequestNo("RQ-" + "FLT-LOG-" + dateNow, "LOG");
                List<LtFormRegistrationLogItem> lstAdd = new List<LtFormRegistrationLogItem>();

                using (var memoStream = new MemoryStream())
                {
                    rq.ReviseFile[0].CopyTo(memoStream);
                    ExcelPackage.LicenseContext = LicenseContext.NonCommercial;
                    using (var package = new ExcelPackage(memoStream))
                    {
                        var worksheet = package.Workbook.Worksheets[0];
                        var rowCount = worksheet.Dimension?.Rows;

                        if (rowCount.HasValue && rowCount.Value > 14)
                        {

                            int j = 15;

                            for (int row = 1; row <= (rowCount.Value - 14); row++)
                            {
                                if (worksheet.Cells["B" + j].Value != null && worksheet.Cells["B" + j].Value != "")
                                {
                                    var obj8 = worksheet.Cells["K" + j].Value;
                                    DateOnly? effctiveDate = null;
                                    try
                                    {
                                        double d = (double)obj8;
                                        var date = DateTime.FromOADate(d);

                                        effctiveDate = DateOnly.FromDateTime(date); ;
                                    }
                                    catch
                                    {
                                        try
                                        {
                                            effctiveDate = DateOnly.FromDateTime(DateTime.Parse(obj8.ObjToStringAble()));
                                        }
                                        catch
                                        {
                                            effctiveDate = null;
                                        }

                                    }
                                    lstAdd.Add(new LtFormRegistrationLogItem
                                    {
                                        CreatedBy = u.UserName,
                                        PartNo = Convert.ToString(worksheet.Cells["B" + j].Value).Trim(),
                                        PartName = Convert.ToString(worksheet.Cells["C" + j].Value),
                                        Vendor = Convert.ToString(worksheet.Cells["D" + j].Value),
                                        PcsBox = Convert.ToString(worksheet.Cells["E" + j].Value),
                                        Model = Convert.ToString(worksheet.Cells["F" + j].Value).Trim(),
                                        Layout = Convert.ToString(worksheet.Cells["G" + j].Value),
                                        Khsx = Convert.ToString(worksheet.Cells["H" + j].Value),
                                        ChangingReason = Convert.ToString(worksheet.Cells["I" + j].Value),
                                        ChangingSupplyGroup = Convert.ToString(worksheet.Cells["J" + j].Value),
                                        RequestEffectiveDate = effctiveDate,
                                        MovingRecStoreSupplyQty = Convert.ToString(worksheet.Cells["L" + j].Value),
                                        MovingRecStoreCycleSupply = Convert.ToString(worksheet.Cells["M" + j].Value),
                                        MovingRecStoreCycleTime = Convert.ToString(worksheet.Cells["N" + j].Value),
                                        MovingRecStoreReceivingTime = Convert.ToString(worksheet.Cells["O" + j].Value),
                                        MovingRecStoreFrom = Convert.ToString(worksheet.Cells["P" + j].Value),
                                        MovingRecStoreTo = Convert.ToString(worksheet.Cells["Q" + j].Value),
                                        MovingRecStoreDistance = Convert.ToString(worksheet.Cells["R" + j].Value),
                                        MovingRecStoreTransportation = Convert.ToString(worksheet.Cells["S" + j].Value),
                                        MovingRecStoreMovingTime = Convert.ToString(worksheet.Cells["T" + j].Value),
                                        MovingRecStoreInputStock = Convert.ToString(worksheet.Cells["U" + j].Value),
                                        MovingAssyStorePickupTime = Convert.ToString(worksheet.Cells["V" + j].Value),
                                        MovingAssyStoreFromLocation = Convert.ToString(worksheet.Cells["W" + j].Value),
                                        MovingAssyStoreFromAddress = Convert.ToString(worksheet.Cells["X" + j].Value),
                                        MovingAssyStoreToLocation = Convert.ToString(worksheet.Cells["Y" + j].Value),
                                        MovingAssyStoreToAddress = Convert.ToString(worksheet.Cells["Z" + j].Value),
                                        MovingAssyStoreDistance = Convert.ToString(worksheet.Cells["AA" + j].Value),
                                        MovingAssyStoreTransportation = Convert.ToString(worksheet.Cells["AB" + j].Value),
                                        MovingAssyStoreCrossPoint = Convert.ToString(worksheet.Cells["AC" + j].Value),
                                        MovingAssyStoreMovingTime = Convert.ToString(worksheet.Cells["AD" + j].Value),
                                        MovingAssyStoreSuppyTime = Convert.ToString(worksheet.Cells["AE" + j].Value),
                                        MovingAssyStoreSafetyQty = Convert.ToString(worksheet.Cells["AF" + j].Value),
                                        TotalLeadtime = Convert.ToString(worksheet.Cells["AG" + j].Value),
                                        Note = Convert.ToString(worksheet.Cells["AH" + j].Value),
                                        RequestNo = requestNo
                                    });
                                }

                                j++;
                            }
                            if (lstAdd.Count == 0)
                            {
                                res.Error = true;
                                res.Message = "Table not have data!";
                                res.Status = (int)HttpStatusCode.BadRequest;
                                return res;
                            }
                            context.AddRange(lstAdd);
                            context.SaveChanges();

                            //save infor
                            var addInfor = new LtFormRegistrationLogInfor
                            {
                                Active = true,
                                RequestNo = requestNo,
                                RequestBy = u.FullName,
                                Note = rq.Note,
                                CreatedBy = u.UserName,
                                Status = null,
                                Department = u.Departments
                            };
                            context.Add(addInfor);
                            context.SaveChanges();

                            //save process
                            var lstGrade = new List<string>() { "Dept. Approval", "PDC1 PIC check", "PDC1 Approval" };
                            var i = 1;
                            foreach (var grade in lstGrade)
                            {
                                var addProcess = new LtFormRegistrationLogProcess
                                {
                                    Active = true,
                                    RequestNo = requestNo,
                                    Grade = grade,
                                    OrderNo = i,
                                    Next = i == 1 ? true : false,
                                };
                                i++;
                                context.Add(addProcess);
                                context.SaveChanges();
                            }

                            res.Error = false;
                            res.Message = "Successfull!";
                            res.Status = (int)HttpStatusCode.OK;
                        }

                    }
                }

            }
            catch (Exception e)
            {
                res.Error = true;
                res.Message = e.Message;
                res.Status = (int)HttpStatusCode.BadRequest;
            }
            return res;
        }
        //lấy thông tin  request list
        //dùng chung model với pdc2 vì giống nhau
        [HttpPost("fillter-request-form-register-log-list/{status}")]
        public LtFormRegistrationPdc2InforModel FillterRequestFormRegisterLog(PaginationParams param, string status)
        {
            try
            {
                param.search = param.search.ToUpper().Trim();
                var result = new LtFormRegistrationPdc2InforModel();
                var lstResult = new List<RequestLeadTimeFormInforView>();
                var u = GetCurrentUser();
                int? statusAppr = status == "ALL" ? 3 : (status == "Approved" ? 1 : (status == "Checking" ? 0 : 2));

                var process = context.LtFormRegistrationLogProcesses.Where(x => x.Active == true);
                var model = context.LtFormRegistrationLogInfors.Where(x => (x.CreatedBy.Contains(param.search) || x.RequestNo.ToUpper().Contains(param.search) || x.RequestBy.ToUpper().Contains(param.search))
                && x.Active == true
                && (statusAppr == 3 ? x.Active == true : x.Status == statusAppr)
                && (x.Status != null || x.CreatedBy == u.UserName)).OrderByDescending(x => x.CreatedDate).ToList();


                var model2 = model.Skip((param.Page - 1) * param.RecordsPerPage).Take(param.RecordsPerPage).ToList();
                int i = 0;
                foreach (var item in model2)
                {
                    bool? canEdit = false;
                    var isReturn = model.Any(x => x.Status != 1 && x.RequestNo == item.RequestNo);
                    if (isReturn == true)
                    {
                        canEdit = true;
                    }
                    var nextApprove = process.FirstOrDefault(x => x.Next == true && x.RequestNo == item.RequestNo);
                    lstResult.Add(new RequestLeadTimeFormInforView()
                    {
                        Id = item.Id,
                        RequestNo = item.RequestNo,
                        CreatedDate = item.CreatedDate == null ? null : item.CreatedDate.Value.ToString("dd-MMM-yyyy"),
                        CreatedBy = item.CreatedBy,
                        Status = item.Status,
                        CanEdit = canEdit,
                        Department = item.Department,
                        IsCreated = u.UserName == item.CreatedBy,
                        RequestBy = item.RequestBy,
                        NextApprover = nextApprove == null ? null : nextApprove.Grade
                    }); i++;
                }
                result.lstModel = lstResult;
                result.toRecord = (int)Math.Min(result.totalRecords, result.currentPage * result.recordPerPage);
                result.totalPage = (int)Math.Ceiling((decimal)model.Count / param.RecordsPerPage);
                result.totalRecords = model.Count;
                result.recordPerPage = param.RecordsPerPage;
                result.currentPage = param.Page;
                result.fromRecord = model.Count == 0 ? 0 : (result.currentPage - 1) * result.recordPerPage + 1;
                //}
                return result;
            }
            catch (Exception)
            {
                return new LtFormRegistrationPdc2InforModel();
            }
        }

        [HttpGet("get-infor-request-form-register-log/{requestNo}")]
        public RequestLeadTimeFormInforView GetInforFormRegisterLog(string requestNo)
        {
            try
            {
                var u = GetCurrentUser();
                var model = context.LtFormRegistrationLogInfors.Where(x => x.Active == true && x.RequestNo == requestNo).FirstOrDefault();
                var lstMaxPP = context.LtInputMaxPpCells.Where(x => x.Active == true).Select(x => x.Model).ToList();
                var lstModelNotPP = context.LtFormRegistrationLogItems.Where(x => x.Active == true && x.RequestNo == requestNo && !lstMaxPP.Contains(x.Model) && x.Model != null && x.Model.Trim() != "").Select(x => x.Model).Distinct().ToList();
                var modelNotPP = lstModelNotPP.Count == 0 ? null : string.Join(";", lstModelNotPP);
                var infor = new RequestLeadTimeFormInforView
                {
                    RequestNo = model.RequestNo,
                    RequestBy = model.RequestBy,
                    Department = model.Department,
                    CreatedDate = model.CreatedDate.Value.ToString("dd-MMM-yyyy"),
                    Note = model.Note,
                    Status = model.Status,
                    CreatedBy = model.CreatedBy,
                    LstNotMaxPP = modelNotPP
                };
                return infor;

            }
            catch (Exception)
            {
                return new RequestLeadTimeFormInforView(); ;
            }
        }

        [HttpPost("get-item-request-form-register-log/{requestNo}")]
        public async Task<LtFormRegistrationLogModel> GetItemFormRegisterLog(PaginationParams param, string requestNo)
        {
            try
            {
                try
                {

                    LtFormRegistrationLogModel result = new LtFormRegistrationLogModel()
                    {
                        currentPage = param.Page,
                        recordPerPage = param.RecordsPerPage
                    };
                    var query = context.LtFormRegistrationLogItems.Where(x => x.Active == true && x.RequestNo == requestNo);

                    query = !string.IsNullOrEmpty(param.search) ? query.Where(x => x.PartNo.ToUpper().Contains(param.search.ToUpper()) || x.Model.ToUpper().Contains(param.search.ToUpper()) || x.Vendor.ToUpper().Contains(param.search.ToUpper())) : query;
                    result.totalRecords = await query.CountAsync();
                    result.totalPage = (int)Math.Ceiling((decimal)result.totalRecords / param.RecordsPerPage);
                    var model = await query.ToListAsync();
                    result.lstModel = model;
                    result.fromRecord = model.Count == 0 ? 0 : (result.currentPage - 1) * result.recordPerPage + 1;
                    result.toRecord = (int)Math.Min(result.totalRecords, result.currentPage * result.recordPerPage);
                    result.currentPage = result.totalPage < result.currentPage ? result.totalPage : result.currentPage;
                    return result;
                }
                catch (Exception e)
                {
                    //SendMailError(e);
                    return new LtFormRegistrationLogModel()
                    {
                        currentPage = param.Page,
                        recordPerPage = param.RecordsPerPage
                    };
                }
            }
            catch (Exception)
            {
                return new LtFormRegistrationLogModel(); ;
            }
        }

        [HttpGet("get-process-request-form-register-log/{requestNo}")]
        public List<LtFormRegistrationLogProcess> GetProcessFormRegisterLog(string requestNo)
        {
            try
            {
                var model = context.LtFormRegistrationLogProcesses.Where(x => x.Active == true && x.RequestNo == requestNo).OrderBy(x => x.OrderNo).ToList();
                return model;

            }
            catch (Exception)
            {
                return new List<LtFormRegistrationLogProcess>(); ;
            }
        }

        //kiểm tra xem có phải người đăng nhập đang ở trạng thái được approve không?
        [HttpGet("check-approver-request-form-register-log/{requestNo}")]
        public bool CheckApproverFormRegisterLog(string requestNo)
        {
            try
            {
                var u = GetCurrentUser();
                var model = context.LtFormRegistrationLogProcesses.Where(x => x.Active == true && x.RequestNo == requestNo && x.Next == true).FirstOrDefault();
                if (model != null)
                {
                    bool check = false;
                    if (model.OrderNo == 1)
                    {
                        // group approver log
                        check = context.AdmDetailUserGroups.Any(x => x.Active == true && x.UserId == new Guid(u.Id) && x.GroupId == new Guid("eb66cd3b-6da4-428a-8710-4fb29f49caaa"));

                    }
                    if (model.OrderNo == 2)
                    {
                        //group pic pdc1
                        check = context.AdmDetailUserGroups.Any(x => x.Active == true && x.UserId == new Guid(u.Id) && x.GroupId == new Guid("56254ddd-e2cd-460d-a245-27d58f8953d4"));

                    }
                    if (model.OrderNo == 3)
                    {
                        //group g6up pdc1
                        check = context.AdmDetailUserGroups.Any(x => x.Active == true && x.UserId == new Guid(u.Id) && x.GroupId == new Guid("62e95f1a-7590-465e-8cf3-ff7932322b2b"));

                    }
                    return check;
                }
                else
                {
                    return false;
                }

            }
            catch (Exception)
            {
                return false;
            }
        }

        [HttpPut("active-request-form-register-log")]
        public CommonResponse ActiveFormRegisterLog(string[] requestNo)
        {
            CommonResponse res = new CommonResponse()
            {
                Error = false,
                Message = "",
                Status = (int)HttpStatusCode.BadRequest
            };
            try
            {
                var u = GetCurrentUser();
                var request_no = requestNo[0];
                //active infor
                ADO.doChange("update lt_form_registration_log_infor set active = false where request_no = '" + request_no + "';");

                //active item
                ADO.doChange("update lt_form_registration_log_item set active = false where request_no = '" + request_no + "';");

                //active process
                ADO.doChange("update lt_form_registration_log_process set active = false where request_no = '" + request_no + "';");

                res.Error = false;
                res.Message = "Successfull!";
                res.Status = (int)HttpStatusCode.OK;


            }
            catch (Exception e)
            {
                res.Error = true;
                res.Message = e.Message;
                res.Status = (int)HttpStatusCode.BadRequest;

            }

            return res;
        }

        [HttpGet("send-approver-request-form-register-log/{requestNo}")]
        public CommonResponse SendApproverFormRegisterLog(string requestNo)
        {
            CommonResponse res = new CommonResponse()
            {
                Error = false,
                Message = "",
                Status = (int)HttpStatusCode.BadRequest
            };
            try
            {
                var u = GetCurrentUser();
                var model = context.LtFormRegistrationLogInfors.Where(x => x.Active == true && x.RequestNo == requestNo).FirstOrDefault();
                model.Status = 0;
                context.Update(model);
                context.SaveChanges();
                //check all member group approver log
                var checkApprovalDept = context.AdmDetailUserGroups.Include(x => x.User).Where(x => x.Active == true && x.GroupId == new Guid("eb66cd3b-6da4-428a-8710-4fb29f49caaa")).ToList();
                if (checkApprovalDept.Count > 0)
                {
                    var link = "http://cvn-vpsi/#/leadtime/form-register/log-detail/" + requestNo;
                    var lstReceiver = checkApprovalDept.Where(x => x.User.Active == true && x.User.Email != null && x.User.Email != "").Select(y => y.User.Email).ToList();
                    SendMailRemind("form registration for log", u.FullName, lstReceiver, link);
                }

                res.Error = false;
                res.Message = "Successfull!";
                res.Status = (int)HttpStatusCode.OK;

            }
            catch (Exception e)
            {
                res.Error = true;
                res.Message = e.Message;
                res.Status = (int)HttpStatusCode.BadRequest;
            }
            return res;
        }

        [HttpPut("approve-request-form-register-log/{id}")]
        public CommonResponse ApproveFormRegisterLog(string[] comment, Guid id)
        {
            CommonResponse res = new CommonResponse()
            {
                Error = false,
                Message = "",
                Status = (int)HttpStatusCode.BadRequest
            };
            try
            {
                var u = GetCurrentUser();
                var cmt = comment[0];
                var model = context.LtFormRegistrationLogProcesses.FirstOrDefault(x => x.Active == true && x.Id == id);

                if (model != null)
                {
                    var maxOrder = context.LtFormRegistrationLogProcesses.Where(x => x.Active == true && x.RequestNo == model.RequestNo).Max(y => y.OrderNo);
                    model.Status = 1;
                    model.Approver = u.UserName;
                    model.ApproverName = u.FullName;
                    model.ApprovedDate = DateTime.Now.ToString("dd-MMM-yyyy");
                    model.Next = false;
                    model.Comment = cmt;
                    context.Update(model);
                    if (model.OrderNo == 1)
                    {

                        var nextApprove = context.LtFormRegistrationLogProcesses.FirstOrDefault(x => x.Active == true && x.RequestNo == model.RequestNo && x.OrderNo == 2);
                        if (nextApprove != null)
                        {
                            nextApprove.Next = true;
                            context.Update(nextApprove);
                            //check all member group pic pdc1
                            var checkApprovalPDC1 = context.AdmDetailUserGroups.Include(x => x.User).Where(x => x.Active == true && x.GroupId == new Guid("56254ddd-e2cd-460d-a245-27d58f8953d4")).ToList();
                            if (checkApprovalPDC1.Count > 0)
                            {
                                var link = "http://cvn-vpsi/#/leadtime/form-register/log-detail/" + model.RequestNo;
                                var lstReceiver = checkApprovalPDC1.Where(x => x.User.Active == true && x.User.Email != null && x.User.Email != "").Select(y => y.User.Email).ToList();
                                SendMailRemind("form registration for log", u.FullName, lstReceiver, link);
                            }
                        }
                    }
                    if (model.OrderNo == 2)
                    {

                        var nextApprove = context.LtFormRegistrationLogProcesses.FirstOrDefault(x => x.Active == true && x.RequestNo == model.RequestNo && x.OrderNo == maxOrder);
                        if (nextApprove != null)
                        {
                            nextApprove.Next = true;
                            context.Update(nextApprove);
                            //check all member group g6up pdc1
                            var checkApprovalPDC1 = context.AdmDetailUserGroups.Include(x => x.User).Where(x => x.Active == true && x.GroupId == new Guid("62e95f1a-7590-465e-8cf3-ff7932322b2b")).ToList();
                            if (checkApprovalPDC1.Count > 0)
                            {
                                var link = "http://cvn-vpsi/#/leadtime/form-register/log-detail/" + model.RequestNo;
                                var lstReceiver = checkApprovalPDC1.Where(x => x.User.Active == true && x.User.Email != null && x.User.Email != "").Select(y => y.User.Email).ToList();
                                SendMailRemind("form registration for log", u.FullName, lstReceiver, link);
                            }
                        }
                    }
                    if (model.OrderNo == maxOrder)
                    {
                        var infor = context.LtFormRegistrationLogInfors.FirstOrDefault(x => x.Active == true && x.RequestNo == model.RequestNo);
                        if (infor != null)
                        {
                            infor.Status = 1;
                            infor.ModifiedDate = DateTime.Now.SetKindUtc();
                            context.Update(infor);

                            var link = "http://cvn-vpsi/#/leadtime/form-register/log-detail/" + model.RequestNo;
                            var user = context.AdmUserInformations.FirstOrDefault(x => x.EmployeeCode == infor.CreatedBy);
                            var receiver = user.FullName;
                            var lstReceiver = user == null ? new List<string>() : new List<string>() { user.Email };
                            SendMailApproved("form registration for log", u.FullName, lstReceiver, receiver, link);

                            var lstUpdate = context.LtFormRegistrationLogItems.Where(x => x.Active == true && x.RequestNo == model.RequestNo).ToList();
                            lstUpdate.ForEach(x => x.ApprovedStatus = 1);
                            context.UpdateRange(lstUpdate);
                        }
                    }
                    context.SaveChanges();
                }

                res.Error = false;
                res.Message = "Successfull!";
                res.Status = (int)HttpStatusCode.OK;


            }
            catch (Exception e)
            {
                res.Error = true;
                res.Message = e.Message;
                res.Status = (int)HttpStatusCode.BadRequest;

            }

            return res;
        }

        [HttpPut("reject-request-form-register-log/{id}")]
        public CommonResponse RejectFormRegisterLog(string[] comment, Guid id)
        {
            CommonResponse res = new CommonResponse()
            {
                Error = false,
                Message = "",
                Status = (int)HttpStatusCode.BadRequest
            };
            try
            {
                var u = GetCurrentUser();
                var cmt = comment[0];
                var model = context.LtFormRegistrationLogProcesses.FirstOrDefault(x => x.Active == true && x.Id == id);

                if (model != null)
                {
                    model.Status = 2;
                    model.Approver = u.UserName;
                    model.ApproverName = u.FullName;
                    model.ApprovedDate = DateTime.Now.ToString("dd-MMM-yyyy");
                    model.Next = false;
                    model.Comment = cmt;
                    context.Update(model);

                    var infor = context.LtFormRegistrationLogInfors.FirstOrDefault(x => x.Active == true && x.RequestNo == model.RequestNo);
                    infor.Status = 2;
                    infor.ModifiedDate = DateTime.Now.SetKindUtc();
                    context.Update(infor);

                    context.SaveChanges();

                    var link = "http://cvn-vpsi/#/leadtime/form-register/log-detail/" + model.RequestNo;
                    var user = context.AdmUserInformations.FirstOrDefault(x => x.EmployeeCode == infor.CreatedBy);
                    var receiver = user.FullName;
                    var lstReceiver = user == null ? new List<string>() : new List<string>() { user.Email };

                    SendMailRejectd("form registration for log", cmt, u.FullName, lstReceiver, receiver, link);
                    //check approved
                    if (model.OrderNo != 1)
                    {
                        var lstApproved = context.LtFormRegistrationLogProcesses.Where(x => x.Active == true && x.RequestNo == model.RequestNo && x.OrderNo < model.OrderNo).ToList();
                        foreach (var approved in lstApproved)
                        {
                            var userApproved = context.AdmUserInformations.FirstOrDefault(x => x.EmployeeCode == approved.Approver);
                            var receiverApproved = userApproved.FullName;
                            var lstReceiverApproved = userApproved == null ? new List<string>() : new List<string>() { userApproved.Email };
                            SendMailRejectd("form registration for log", cmt, u.FullName, lstReceiverApproved, receiverApproved, link);
                        }
                    }


                }

                res.Error = false;
                res.Message = "Successfull!";
                res.Status = (int)HttpStatusCode.OK;


            }
            catch (Exception e)
            {
                res.Error = true;
                res.Message = e.Message;
                res.Status = (int)HttpStatusCode.BadRequest;

            }

            return res;
        }
        #endregion

        #region form register assy 
        [HttpGet("get-request-assy-requestno")]
        public List<string> GetRequestAssyRequestNo()
        {
            try
            {
                var dateNow = DateTime.Now.ToString("yyyy_MM_dd");
                var lstRequest = new List<string>();
                var requestNo = GetNewRequestNo("RQ-" + "FLT-ASSY-" + dateNow, "ASSY");
                lstRequest.Add(requestNo);
                return lstRequest;

            }
            catch (Exception)
            {
                return new List<string>();
            }
        }

        [HttpPost("add-request-form-register-assy")]
        public CommonResponse AddRequestFormRegisterAssy([FromForm] FormRegisterLTRequest rq)

        {
            CommonResponse res = new CommonResponse()
            {
                Error = false,
                Message = "",
                Status = (int)HttpStatusCode.BadRequest
            };
            try
            {
                var u = GetCurrentUser();
                var dateNow = DateTime.Now.ToString("yyyy_MM_dd");
                var lstRequest = new List<string>();
                var requestNo = GetNewRequestNo("RQ-" + "FLT-ASSY-" + dateNow, "ASSY");
               
                List<LtFormRegistrationAssyItem> lstAdd = new List<LtFormRegistrationAssyItem>();

                using (var memoStream = new MemoryStream())
                {
                    rq.ReviseFile[0].CopyTo(memoStream);
                    ExcelPackage.LicenseContext = LicenseContext.NonCommercial;
                    using (var package = new ExcelPackage(memoStream))
                    {
                        var worksheet = package.Workbook.Worksheets[0];
                        var rowCount = worksheet.Dimension?.Rows;

                        if (rowCount.HasValue && rowCount.Value > 14)
                        {

                            int j = 16;

                            for (int row = 1; row <= (rowCount.Value - 15); row++)
                            {
                                if (worksheet.Cells["B" + j].Value != null && worksheet.Cells["B" + j].Value != "")
                                {
                                    var obj8 = worksheet.Cells["G" + j].Value;
                                    DateOnly? effctiveDate = null;
                                    try
                                    {
                                        double d = (double)obj8;
                                        var date = DateTime.FromOADate(d);

                                        effctiveDate = DateOnly.FromDateTime(date); ;
                                    }
                                    catch
                                    {
                                        try
                                        {
                                            effctiveDate = DateOnly.FromDateTime(DateTime.Parse(obj8.ObjToStringAble()));
                                        }
                                        catch
                                        {
                                            effctiveDate = null;
                                        }

                                    }
                                    lstAdd.Add(new LtFormRegistrationAssyItem
                                    {
                                        CreatedBy = u.UserName,
                                        PartNo = Convert.ToString(worksheet.Cells["B" + j].Value).Trim(),
                                        PartName = Convert.ToString(worksheet.Cells["C" + j].Value),
                                        Model = Convert.ToString(worksheet.Cells["D" + j].Value).Trim(),
                                        ChangingReason = Convert.ToString(worksheet.Cells["E" + j].Value),
                                        ChangingMethod = Convert.ToString(worksheet.Cells["F" + j].Value),
                                        RequestEffectiveDate = effctiveDate,
                                        MinQty = Convert.ToString(worksheet.Cells["H" + j].Value),
                                        MaxQty = Convert.ToString(worksheet.Cells["I" + j].Value),
                                        ProcessingArea = Convert.ToString(worksheet.Cells["J" + j].Value),
                                        ProcessWork = Convert.ToString(worksheet.Cells["K" + j].Value),
                                        TotalStation = Convert.ToString(worksheet.Cells["L" + j].Value),
                                        UsingStation = Convert.ToString(worksheet.Cells["M" + j].Value),
                                        UnitStocker = Convert.ToString(worksheet.Cells["N" + j].Value),
                                        SafetyQty = Convert.ToString(worksheet.Cells["O" + j].Value),
                                        SupplyQty = Convert.ToString(worksheet.Cells["P" + j].Value),
                                        PickupTime = Convert.ToString(worksheet.Cells["Q" + j].Value),
                                        FromLocation = Convert.ToString(worksheet.Cells["R" + j].Value),
                                        FromAddress = Convert.ToString(worksheet.Cells["S" + j].Value),
                                        ToLocation = Convert.ToString(worksheet.Cells["T" + j].Value),
                                        ToAddress = Convert.ToString(worksheet.Cells["U" + j].Value),
                                        Distance = Convert.ToString(worksheet.Cells["V" + j].Value),
                                        Transportation = Convert.ToString(worksheet.Cells["W" + j].Value),
                                        CrossPoint = Convert.ToString(worksheet.Cells["X" + j].Value),
                                        SuppyTime = Convert.ToString(worksheet.Cells["Y" + j].Value),
                                        Note = Convert.ToString(worksheet.Cells["Z" + j].Value),
                                        RequestNo = requestNo
                                    });
                                }

                                j++;
                            }
                            if (lstAdd.Count == 0)
                            {
                                res.Error = true;
                                res.Message = "Table not have data!";
                                res.Status = (int)HttpStatusCode.BadRequest;
                                return res;
                            }
                            context.AddRange(lstAdd);
                         

                            //save infor
                            var addInfor = new LtFormRegistrationAssyInfor
                            {
                                Active = true,
                                RequestNo = requestNo,
                                RequestBy = u.FullName,
                                Note = rq.Note,
                                CreatedBy = u.UserName,
                                Status = null,
                                Department = u.Departments
                            };
                            context.Add(addInfor);
                            

                            //save process
                            var approver = rq.Approver.Split("_");
                            var lstGrade = new List<string>() { "Dept. Approval", "PDC1 PIC check", "PDC1 Approval" };
                            var i = 1;
                            foreach (var grade in lstGrade)
                            {
                                var addProcess = new LtFormRegistrationAssyProcess
                                {
                                    Active = true,
                                    RequestNo = requestNo,
                                    Grade = grade,
                                    OrderNo = i,
                                    Next = i == 1 ? true : false,
                                    Approver = i== 1? approver[0]:null,
                                    ApproverName = i == 1 ? approver[1] : null,
                                };
                                i++;
                                context.Add(addProcess);
                               
                            }
                            context.SaveChanges();
                            res.Error = false;
                            res.Message = "Successfull!";
                            res.Status = (int)HttpStatusCode.OK;
                        }

                    }
                }

            }
            catch (Exception e)
            {
                res.Error = true;
                res.Message = e.Message;
                res.Status = (int)HttpStatusCode.BadRequest;
            }
            return res;
        }
        //lấy thông tin  request list
        //dùng chung model với pdc2 vì giống nhau
        [HttpPost("fillter-request-form-register-assy-list/{status}")]
        public LtFormRegistrationPdc2InforModel FillterRequestFormRegisterAssy(PaginationParams param, string status)
        {
            try
            {
                param.search = param.search.ToUpper().Trim();
                var result = new LtFormRegistrationPdc2InforModel();
                var lstResult = new List<RequestLeadTimeFormInforView>();
                var u = GetCurrentUser();
                var process = context.LtFormRegistrationAssyProcesses.Where(x => x.Active == true);
                var lstRq = process.Where(x => x.Approver == u.UserName).Select(x => x.RequestNo).ToList();
                var isAdmin = context.AdmDetailUserGroups.Any(x => x.UserId == new Guid(u.Id) && x.Active == true && (x.GroupId == new Guid("1567cfeb-32fe-4745-bbdc-2ace703099d4") 
                || x.GroupId == new Guid("e462d3a8-27fa-4ffa-bac4-512a2ab33bc3") 
                || x.GroupId == new Guid("62e95f1a-7590-465e-8cf3-ff7932322b2b")
                || x.GroupId == new Guid("56254ddd-e2cd-460d-a245-27d58f8953d4")));

                int? statusAppr = status == "ALL" ? 3 : (status == "Approved" ? 1 : (status == "Checking" ? 0 : 2));

                var model = context.LtFormRegistrationAssyInfors.Where(x => (x.CreatedBy.Contains(param.search) || x.RequestNo.ToUpper().Contains(param.search) || x.RequestBy.ToUpper().Contains(param.search)) 
                && x.Active == true
                    && (statusAppr == 3 ? x.Active == true : x.Status == statusAppr)
                && ((x.Status != null && lstRq.Contains(x.RequestNo)) || x.CreatedBy == u.UserName || isAdmin == true)).OrderByDescending(x => x.CreatedDate).ToList();

                var model2 = model.Skip((param.Page - 1) * param.RecordsPerPage).Take(param.RecordsPerPage).ToList();
                int i = 0;
                foreach (var item in model2)
                {
                    bool? canEdit = false;
                    var isReturn = model.Any(x => x.Status != 1 && x.RequestNo == item.RequestNo);
                    if (isReturn == true)
                    {
                        canEdit = true;
                    }
                    var nextApprove = process.FirstOrDefault(x => x.Next == true && x.RequestNo == item.RequestNo);
                    var deptApprover = process.FirstOrDefault(x => x.Active == true && x.RequestNo == item.RequestNo && x.OrderNo == 1);
                    lstResult.Add(new RequestLeadTimeFormInforView()
                    {
                        Id = item.Id,
                        RequestNo = item.RequestNo,
                        CreatedDate = item.CreatedDate == null ? null : item.CreatedDate.Value.ToString("dd-MMM-yyyy"),
                        CreatedBy = item.CreatedBy,
                        Status = item.Status,
                        CanEdit = canEdit,
                        Department = item.Department,
                        IsCreated = u.UserName == item.CreatedBy,
                        RequestBy = item.RequestBy,
                        NextApprover = nextApprove == null ? null : nextApprove.Grade,
                        DeptApprove = deptApprover == null?false:( deptApprover.Status == 0? false:true)
                    }); i++;
                }
                result.lstModel = lstResult;
                result.toRecord = (int)Math.Min(result.totalRecords, result.currentPage * result.recordPerPage);
                result.totalPage = (int)Math.Ceiling((decimal)model.Count / param.RecordsPerPage);
                result.totalRecords = model.Count;
                result.recordPerPage = param.RecordsPerPage;
                result.currentPage = param.Page;
                result.fromRecord = model.Count == 0 ? 0 : (result.currentPage - 1) * result.recordPerPage + 1;
                //}
                return result;
            }
            catch (Exception)
            {
                return new LtFormRegistrationPdc2InforModel();
            }
        }

        [HttpGet("get-infor-request-form-register-assy/{requestNo}")]
        public RequestLeadTimeFormInforView GetInforFormRegisterAssy(string requestNo)
        {
            try
            {
                var u = GetCurrentUser();
                var model = context.LtFormRegistrationAssyInfors.Where(x => x.Active == true && x.RequestNo == requestNo).FirstOrDefault();
                var lstMaxPP = context.LtInputMaxPpCells.Where(x => x.Active == true).Select(x => x.Model).ToList();
                var lstModelNotPP = context.LtFormRegistrationAssyItems.Where(x => x.Active == true && x.RequestNo == requestNo && !lstMaxPP.Contains(x.Model) && x.Model != null && x.Model.Trim() != "").Select(x => x.Model).Distinct().ToList();
                var modelNotPP = lstModelNotPP.Count == 0 ? null : string.Join(";", lstModelNotPP);
                var infor = new RequestLeadTimeFormInforView
                {
                    RequestNo = model.RequestNo,
                    RequestBy = model.RequestBy,
                    Department = model.Department,
                    CreatedDate = model.CreatedDate.Value.ToString("dd-MMM-yyyy"),
                    Note = model.Note,
                    Status = model.Status,
                    CreatedBy = model.CreatedBy,
                    LstNotMaxPP = modelNotPP
                };
                return infor;

            }
            catch (Exception)
            {
                return new RequestLeadTimeFormInforView(); ;
            }
        }

        [HttpPost("get-item-request-form-register-assy/{requestNo}")]
        public async Task<LtFormRegistrationAssyModel> GetItemFormRegisterAssy(PaginationParams param, string requestNo)
        {
            try
            {
                try
                {

                    LtFormRegistrationAssyModel result = new LtFormRegistrationAssyModel()
                    {
                        currentPage = param.Page,
                        recordPerPage = param.RecordsPerPage
                    };
                    var query = context.LtFormRegistrationAssyItems.Where(x => x.Active == true && x.RequestNo == requestNo);

                    query = !string.IsNullOrEmpty(param.search) ? query.Where(x => x.PartNo.ToUpper().Contains(param.search.ToUpper()) || x.Model.ToUpper().Contains(param.search.ToUpper())) : query;
                    result.totalRecords = await query.CountAsync();
                    result.totalPage = (int)Math.Ceiling((decimal)result.totalRecords / param.RecordsPerPage);
                    var model = await query.ToListAsync();
                    result.lstModel = model;
                    result.fromRecord = model.Count == 0 ? 0 : (result.currentPage - 1) * result.recordPerPage + 1;
                    result.toRecord = (int)Math.Min(result.totalRecords, result.currentPage * result.recordPerPage);
                    result.currentPage = result.totalPage < result.currentPage ? result.totalPage : result.currentPage;
                    return result;
                }
                catch (Exception e)
                {
                    //SendMailError(e);
                    return new LtFormRegistrationAssyModel()
                    {
                        currentPage = param.Page,
                        recordPerPage = param.RecordsPerPage
                    };
                }
            }
            catch (Exception)
            {
                return new LtFormRegistrationAssyModel(); ;
            }
        }

        [HttpGet("get-process-request-form-register-assy/{requestNo}")]
        public List<LtFormRegistrationAssyProcess> GetProcessFormRegisterAssy(string requestNo)
        {
            try
            {
                var model = context.LtFormRegistrationAssyProcesses.Where(x => x.Active == true && x.RequestNo == requestNo).OrderBy(x => x.OrderNo).ToList();
                return model;

            }
            catch (Exception)
            {
                return new List<LtFormRegistrationAssyProcess>(); ;
            }
        }

        //kiểm tra xem có phải người đăng nhập đang ở trạng thái được approve không?
        [HttpGet("check-approver-request-form-register-assy/{requestNo}")]
        public bool CheckApproverFormRegisterAssy(string requestNo)
        {
            try
            {
                var u = GetCurrentUser();
                var model = context.LtFormRegistrationAssyProcesses.Where(x => x.Active == true && x.RequestNo == requestNo && x.Next == true).FirstOrDefault();
                if (model != null)
                {

                    bool check = false;
                    if (model.OrderNo == 1)
                    {
                        // group approver assy
                        check = context.AdmDetailUserGroups.Any(x => x.Active == true && x.UserId == new Guid(u.Id) && x.GroupId == new Guid("545f29a3-3488-40d9-b541-a2a8a04a7545"));

                    }
                    if (model.OrderNo == 2)
                    {
                        //group pic pdc1
                        check = context.AdmDetailUserGroups.Any(x => x.Active == true && x.UserId == new Guid(u.Id) && x.GroupId == new Guid("56254ddd-e2cd-460d-a245-27d58f8953d4"));

                    }
                    if (model.OrderNo == 3)
                    {
                        //group g6up pdc1
                        check = context.AdmDetailUserGroups.Any(x => x.Active == true && x.UserId == new Guid(u.Id) && x.GroupId == new Guid("62e95f1a-7590-465e-8cf3-ff7932322b2b"));

                    }
                    return check;
                }
                else
                {
                    return false;
                }

            }
            catch (Exception)
            {
                return false;
            }
        }

        [HttpPut("active-request-form-register-assy")]
        public CommonResponse ActiveFormRegisterAssy(string[] requestNo)
        {
            CommonResponse res = new CommonResponse()
            {
                Error = false,
                Message = "",
                Status = (int)HttpStatusCode.BadRequest
            };
            try
            {
                var u = GetCurrentUser();
                var request_no = requestNo[0];
                //active infor
                ADO.doChange("update lt_form_registration_assy_infor set active = false where request_no = '" + request_no + "';");

                //active item
                ADO.doChange("update lt_form_registration_assy_item set active = false where request_no = '" + request_no + "';");

                //active process
                ADO.doChange("update lt_form_registration_assy_process set active = false where request_no = '" + request_no + "';");

                res.Error = false;
                res.Message = "Successfull!";
                res.Status = (int)HttpStatusCode.OK;


            }
            catch (Exception e)
            {
                res.Error = true;
                res.Message = e.Message;
                res.Status = (int)HttpStatusCode.BadRequest;

            }

            return res;
        }

        [HttpGet("send-approver-request-form-register-assy/{requestNo}")]
        public CommonResponse SendApproverFormRegisterAssy(string requestNo)
        {
            CommonResponse res = new CommonResponse()
            {
                Error = false,
                Message = "",
                Status = (int)HttpStatusCode.BadRequest
            };
            try
            {
                var u = GetCurrentUser();
                var model = context.LtFormRegistrationAssyInfors.Where(x => x.Active == true && x.RequestNo == requestNo).FirstOrDefault();
                model.Status = 0;
                context.Update(model);
                context.SaveChanges();
                //check all member group approver log
               // var checkApprovalDept = context.AdmDetailUserGroups.Include(x => x.User).Where(x => x.Active == true && x.GroupId == new Guid("545f29a3-3488-40d9-b541-a2a8a04a7545")).ToList();
                var checkApprovalDept = context.LtFormRegistrationAssyProcesses.Where(x => x.Active == true && x.RequestNo == requestNo && x.OrderNo == 1).FirstOrDefault();


                if (checkApprovalDept != null )
                {
                    var link = "http://cvn-vpsi/#/leadtime/form-register/assy-detail/" + requestNo;
                    var user = context.AdmUserInformations.FirstOrDefault(x => x.Active == true && x.EmployeeCode == checkApprovalDept.Approver);
                    var lstReceiver = new List<string>() { user.Email };
                    SendMailRemind("form registration for assy", u.FullName, lstReceiver, link);
                }

                res.Error = false;
                res.Message = "Successfull!";
                res.Status = (int)HttpStatusCode.OK;

            }
            catch (Exception e)
            {
                res.Error = true;
                res.Message = e.Message;
                res.Status = (int)HttpStatusCode.BadRequest;
            }
            return res;
        }

        [HttpPut("approve-request-form-register-assy/{id}")]
        public CommonResponse ApproveFormRegisterAssy(string[] comment, Guid id)
        {
            CommonResponse res = new CommonResponse()
            {
                Error = false,
                Message = "",
                Status = (int)HttpStatusCode.BadRequest
            };
            try
            {
                var u = GetCurrentUser();
                var cmt = comment[0];
                var model = context.LtFormRegistrationAssyProcesses.FirstOrDefault(x => x.Active == true && x.Id == id);

                if (model != null)
                {
                    var maxOrder = context.LtFormRegistrationAssyProcesses.Where(x => x.Active == true && x.RequestNo == model.RequestNo).Max(y => y.OrderNo);
                    model.Status = 1;
                    model.Approver = u.UserName;
                    model.ApproverName = u.FullName;
                    model.ApprovedDate = DateTime.Now.ToString("dd-MMM-yyyy");
                    model.Next = false;
                    model.Comment = cmt;
                    context.Update(model);
                    if (model.OrderNo == 1)
                    {

                        var nextApprove = context.LtFormRegistrationAssyProcesses.FirstOrDefault(x => x.Active == true && x.RequestNo == model.RequestNo && x.OrderNo == 2);
                        if (nextApprove != null)
                        {
                            nextApprove.Next = true;
                            context.Update(nextApprove);
                            //check all member group pic pdc1
                            var checkApprovalPDC1 = context.AdmDetailUserGroups.Include(x => x.User).Where(x => x.Active == true && x.GroupId == new Guid("56254ddd-e2cd-460d-a245-27d58f8953d4")).ToList();
                            if (checkApprovalPDC1.Count > 0)
                            {
                                var link = "http://cvn-vpsi/#/leadtime/form-register/assy-detail/" + model.RequestNo;
                                var lstReceiver = checkApprovalPDC1.Where(x => x.User.Active == true && x.User.Email != null && x.User.Email != "").Select(y => y.User.Email).ToList();
                                SendMailRemind("form registration for assy", u.FullName, lstReceiver, link);
                            }
                        }
                    }
                    if (model.OrderNo == 2)
                    {

                        var nextApprove = context.LtFormRegistrationAssyProcesses.FirstOrDefault(x => x.Active == true && x.RequestNo == model.RequestNo && x.OrderNo == maxOrder);
                        if (nextApprove != null)
                        {
                            nextApprove.Next = true;
                            context.Update(nextApprove);
                            //check all member group g6up pdc1
                            var checkApprovalPDC1 = context.AdmDetailUserGroups.Include(x => x.User).Where(x => x.Active == true && x.GroupId == new Guid("62e95f1a-7590-465e-8cf3-ff7932322b2b")).ToList();
                            if (checkApprovalPDC1.Count > 0)
                            {
                                var link = "http://cvn-vpsi/#/leadtime/form-register/assy-detail/" + model.RequestNo;
                                var lstReceiver = checkApprovalPDC1.Where(x => x.User.Active == true && x.User.Email != null && x.User.Email != "").Select(y => y.User.Email).ToList();
                                SendMailRemind("form registration for assy", u.FullName, lstReceiver, link);
                            }
                        }
                    }
                    if (model.OrderNo == maxOrder)
                    {
                        var infor = context.LtFormRegistrationAssyInfors.FirstOrDefault(x => x.Active == true && x.RequestNo == model.RequestNo);
                        if (infor != null)
                        {
                            infor.Status = 1;
                            infor.ModifiedDate = DateTime.Now.SetKindUtc();
                            context.Update(infor);

                            var link = "http://cvn-vpsi/#/leadtime/form-register/assy-detail/" + model.RequestNo;
                            var user = context.AdmUserInformations.FirstOrDefault(x => x.EmployeeCode == infor.CreatedBy);
                            var receiver = user.FullName;
                            var lstReceiver = user == null ? new List<string>() : new List<string>() { user.Email };
                            SendMailApproved("form registration for assy", u.FullName, lstReceiver, receiver, link);

                            var lstUpdate = context.LtFormRegistrationAssyItems.Where(x => x.Active == true && x.RequestNo == model.RequestNo).ToList();
                            lstUpdate.ForEach(x => x.ApprovedStatus = 1);
                            context.UpdateRange(lstUpdate);
                        }
                    }
                    context.SaveChanges();
                }

                res.Error = false;
                res.Message = "Successfull!";
                res.Status = (int)HttpStatusCode.OK;


            }
            catch (Exception e)
            {
                res.Error = true;
                res.Message = e.Message;
                res.Status = (int)HttpStatusCode.BadRequest;

            }

            return res;
        }

        [HttpPut("reject-request-form-register-assy/{id}")]
        public CommonResponse RejectFormRegisterAssy(string[] comment, Guid id)
        {
            CommonResponse res = new CommonResponse()
            {
                Error = false,
                Message = "",
                Status = (int)HttpStatusCode.BadRequest
            };
            try
            {
                var u = GetCurrentUser();
                var cmt = comment[0];
                var model = context.LtFormRegistrationAssyProcesses.FirstOrDefault(x => x.Active == true && x.Id == id);

                if (model != null)
                {
                    model.Status = 2;
                    model.Approver = u.UserName;
                    model.ApproverName = u.FullName;
                    model.ApprovedDate = DateTime.Now.ToString("dd-MMM-yyyy");
                    model.Next = false;
                    model.Comment = cmt;
                    context.Update(model);

                    var infor = context.LtFormRegistrationAssyInfors.FirstOrDefault(x => x.Active == true && x.RequestNo == model.RequestNo);
                    infor.Status = 2;
                    infor.ModifiedDate = DateTime.Now.SetKindUtc();
                    context.Update(infor);

                    context.SaveChanges();

                    var link = "http://cvn-vpsi/#/leadtime/form-register/assy-detail/" + model.RequestNo;
                    var user = context.AdmUserInformations.FirstOrDefault(x => x.EmployeeCode == infor.CreatedBy);
                    var receiver = user.FullName;
                    var lstReceiver = user == null ? new List<string>() : new List<string>() { user.Email };

                    SendMailRejectd("form registration for assy", cmt, u.FullName, lstReceiver, receiver, link);
                    //check approved
                    if (model.OrderNo != 1)
                    {
                        var lstApproved = context.LtFormRegistrationAssyProcesses.Where(x => x.Active == true && x.RequestNo == model.RequestNo && x.OrderNo < model.OrderNo).ToList();
                        foreach (var approved in lstApproved)
                        {
                            var userApproved = context.AdmUserInformations.FirstOrDefault(x => x.EmployeeCode == approved.Approver);
                            var receiverApproved = userApproved.FullName;
                            var lstReceiverApproved = userApproved == null ? new List<string>() : new List<string>() { userApproved.Email };
                            SendMailRejectd("form registration for assy", cmt, u.FullName, lstReceiverApproved, receiverApproved, link);
                        }
                    }


                }

                res.Error = false;
                res.Message = "Successfull!";
                res.Status = (int)HttpStatusCode.OK;


            }
            catch (Exception e)
            {
                res.Error = true;
                res.Message = e.Message;
                res.Status = (int)HttpStatusCode.BadRequest;

            }

            return res;
        }

        [HttpGet("get-approver-assy")]
        public List<MasterUserInforView> GetApproverAssy()
        {
           
            try
            {
                var result = new List<MasterUserInforView>();
                var model = context.AdmDetailUserGroups.Include(x => x.User).Where(x => x.Active == true && x.GroupId == new Guid("545f29a3-3488-40d9-b541-a2a8a04a7545")).ToList();
                foreach(var item in model)
                {
                    result.Add(new MasterUserInforView
                    {
                        EmployeeCode = item.User.EmployeeCode +"_" +item.User.FullName
                    });
                }
                return result;

            }
            catch (Exception e)
            {
                return new List<MasterUserInforView>();
            }
          
        }

        [HttpPost("forward-approver-assy/{requestNo}")]
        public CommonResponse ForwardApproverAssy(string requestNo, string[] approver)
        {
            CommonResponse res = new CommonResponse()
            {
                Error = false,
                Message = "",
                Status = (int)HttpStatusCode.BadRequest
            };
            try
            {
                var u = GetCurrentUser();
                var process = context.LtFormRegistrationAssyProcesses.FirstOrDefault(x => x.Active == true && x.RequestNo == requestNo && x.OrderNo == 1);
                var newApprover = approver[0].Split("_");
                var oldApprover = context.AdmUserInformations.FirstOrDefault(x => x.Active == true && x.EmployeeCode == process.Approver);
                var currentApprover = context.AdmUserInformations.FirstOrDefault(x => x.Active == true && x.EmployeeCode == newApprover[0]);

                process.Approver = newApprover[0];
                process.ApproverName = newApprover[1];
                context.Update(process);
                context.SaveChanges();
                //send mail for new approver
                var link = "http://cvn-vpsi/#/leadtime/form-register/assy-detail/" + requestNo;
                var lstReceiver = new List<string>() { oldApprover.Email };
                SendMailRemind("form registration for assy", u.FullName, lstReceiver, link);

                //send mail for  old approver
                var lstReceiverNew = new List<string>() { currentApprover.Email };
                SendMailForward(oldApprover.FullName, currentApprover.FullName, u.FullName, lstReceiverNew, requestNo);

                res.Error = false;
                res.Message = "Successfull!";
                res.Status = (int)HttpStatusCode.OK;
            }
            catch (Exception e)
            {
                res.Error = true;
                res.Message = e.Message;
                res.Status = (int)HttpStatusCode.BadRequest;

            }
            return res;

        }
        #endregion

        #region form register in_house 
        [HttpGet("get-request-ih-requestno")]
        public List<string> GetRequestIHRequestNo()
        {
            try
            {
                var dateNow = DateTime.Now.ToString("yyyy_MM_dd");
                var lstRequest = new List<string>();
                var requestNo = GetNewRequestNo("RQ-" + "FLT-IH-" + dateNow, "IH");
                lstRequest.Add(requestNo);
                return lstRequest;

            }
            catch (Exception)
            {
                return new List<string>();
            }
        }

        [HttpPost("add-request-form-register-ih")]
        public CommonResponse AddRequestFormRegisterIH([FromForm] FormRegisterLTRequest rq)

        {
            CommonResponse res = new CommonResponse()
            {
                Error = false,
                Message = "",
                Status = (int)HttpStatusCode.BadRequest
            };
            try
            {
                var u = GetCurrentUser();
                var dateNow = DateTime.Now.ToString("yyyy_MM_dd");
                var lstRequest = new List<string>();
                var requestNo = GetNewRequestNo("RQ-" + "FLT-IH-" + dateNow, "IH");
                List<LtFormRegistrationIhItem> lstAdd = new List<LtFormRegistrationIhItem>();

                using (var memoStream = new MemoryStream())
                {
                    rq.ReviseFile[0].CopyTo(memoStream);
                    ExcelPackage.LicenseContext = LicenseContext.NonCommercial;
                    using (var package = new ExcelPackage(memoStream))
                    {
                        var worksheet = package.Workbook.Worksheets[0];
                        var rowCount = worksheet.Dimension?.Rows;

                        if (rowCount.HasValue && rowCount.Value > 14)
                        {

                            int j = 15;

                            for (int row = 1; row <= (rowCount.Value - 14); row++)
                            {
                                if (worksheet.Cells["B" + j].Value != null && worksheet.Cells["B" + j].Value != "")
                                {
                                    var obj8 = worksheet.Cells["G" + j].Value;
                                    DateOnly? effctiveDate = null;
                                    try
                                    {
                                        double d = (double)obj8;
                                        var date = DateTime.FromOADate(d);

                                        effctiveDate = DateOnly.FromDateTime(date); ;
                                    }
                                    catch
                                    {
                                        try
                                        {
                                            effctiveDate = DateOnly.FromDateTime(DateTime.Parse(obj8.ObjToStringAble()));
                                        }
                                        catch
                                        {
                                            effctiveDate = null;
                                        }

                                    }
                                    lstAdd.Add(new LtFormRegistrationIhItem
                                    {
                                        CreatedBy = u.UserName,
                                        PartNo = Convert.ToString(worksheet.Cells["B" + j].Value).Trim(),
                                        PartName = Convert.ToString(worksheet.Cells["C" + j].Value),
                                        Model = Convert.ToString(worksheet.Cells["D" + j].Value).Trim(),
                                        ChangingReason = Convert.ToString(worksheet.Cells["E" + j].Value),
                                        ChangingMethod = Convert.ToString(worksheet.Cells["F" + j].Value),
                                        RequestEffectiveDate = effctiveDate,
                                        PartMovingRoute = Convert.ToString(worksheet.Cells["H" + j].Value),
                                        DandoriTime = Convert.ToString(worksheet.Cells["J" + j].Value),
                                        CycleTime = Convert.ToString(worksheet.Cells["K" + j].Value),
                                        Cycle1st = Convert.ToString(worksheet.Cells["L" + j].Value),
                                        InsideTransportation = Convert.ToString(worksheet.Cells["M" + j].Value),
                                        OutsideTransportation = Convert.ToString(worksheet.Cells["N" + j].Value),
                                        AssyShift = Convert.ToString(worksheet.Cells["O" + j].Value),
                                        InhouseCapacity = Convert.ToString(worksheet.Cells["P" + j].Value),
                                        McTrouble = Convert.ToString(worksheet.Cells["Q" + j].Value),
                                        StopForMaintaince = Convert.ToString(worksheet.Cells["R" + j].Value),
                                        ProductionSpecial = Convert.ToString(worksheet.Cells["S" + j].Value),
                                        LotSize = Convert.ToString(worksheet.Cells["T" + j].Value),
                                        StockActualFirst = Convert.ToString(worksheet.Cells["U" + j].Value),
                                        StockActualLast = Convert.ToString(worksheet.Cells["V" + j].Value),
                                        RequestNo = requestNo
                                    });
                                }

                                j++;
                            }
                            if (lstAdd.Count == 0)
                            {
                                res.Error = true;
                                res.Message = "Table not have data!";
                                res.Status = (int)HttpStatusCode.BadRequest;
                                return res;
                            }
                            context.AddRange(lstAdd);
                            context.SaveChanges();

                            //save infor
                            var addInfor = new LtFormRegistrationIhInfor
                            {
                                Active = true,
                                RequestNo = requestNo,
                                RequestBy = u.FullName,
                                Note = rq.Note,
                                CreatedBy = u.UserName,
                                Status = null,
                                Department = u.Departments
                            };
                            context.Add(addInfor);
                            context.SaveChanges();

                            //save process
                            var approver = rq.Approver.Split("_");
                            var lstGrade = new List<string>() { "Dept. Approval", "PDC1 PIC check", "PDC1 Approval" };
                            var i = 1;
                            foreach (var grade in lstGrade)
                            {
                                var addProcess = new LtFormRegistrationIhProcess
                                {
                                    Active = true,
                                    RequestNo = requestNo,
                                    Grade = grade,
                                    OrderNo = i,
                                    Next = i == 1 ? true : false,
                                    Approver = i == 1 ? approver[0] : null,
                                    ApproverName= i == 1 ? approver[1] : null,
                                };
                                i++;
                                context.Add(addProcess);
                                context.SaveChanges();
                            }

                            res.Error = false;
                            res.Message = "Successfull!";
                            res.Status = (int)HttpStatusCode.OK;
                        }

                    }
                }

            }
            catch (Exception e)
            {
                res.Error = true;
                res.Message = e.Message;
                res.Status = (int)HttpStatusCode.BadRequest;
            }
            return res;
        }
        //lấy thông tin  request list
        //dùng chung model với pdc2 vì giống nhau
        [HttpPost("fillter-request-form-register-ih-list/{status}")]
        public LtFormRegistrationPdc2InforModel FillterRequestFormRegisterIh(PaginationParams param, string status)
        {
            try
            {
                param.search = param.search.ToUpper().Trim();
                var result = new LtFormRegistrationPdc2InforModel();
                var lstResult = new List<RequestLeadTimeFormInforView>();
                var u = GetCurrentUser();
                var process = context.LtFormRegistrationIhProcesses.Where(x => x.Active == true);
                var lstRq = process.Where(x => x.Approver == u.UserName).Select(x => x.RequestNo).ToList();
                var isAdmin = context.AdmDetailUserGroups.Any(x => x.UserId == new Guid(u.Id) && x.Active == true && (x.GroupId == new Guid("1567cfeb-32fe-4745-bbdc-2ace703099d4")
                   || x.GroupId == new Guid("e462d3a8-27fa-4ffa-bac4-512a2ab33bc3")
                   || x.GroupId == new Guid("62e95f1a-7590-465e-8cf3-ff7932322b2b")
                   || x.GroupId == new Guid("56254ddd-e2cd-460d-a245-27d58f8953d4")));
                int? statusAppr = status == "ALL" ? 3 : (status == "Approved" ? 1 : (status == "Checking" ? 0 : 2));

                var model = context.LtFormRegistrationIhInfors.Where(x => (x.CreatedBy.Contains(param.search) || x.RequestNo.ToUpper().Contains(param.search) || x.RequestBy.ToUpper().Contains(param.search)) 
                && x.Active == true
                    && (statusAppr == 3 ? x.Active == true : x.Status == statusAppr)
                && ((x.Status != null && lstRq.Contains(x.RequestNo)) || x.CreatedBy == u.UserName || isAdmin == true)).OrderByDescending(x => x.CreatedDate).ToList();


                var model2 = model.Skip((param.Page - 1) * param.RecordsPerPage).Take(param.RecordsPerPage).ToList();
                int i = 0;
                foreach (var item in model2)
                {
                    bool? canEdit = false;
                    var isReturn = model.Any(x => x.Status != 1 && x.RequestNo == item.RequestNo);
                    if (isReturn == true)
                    {
                        canEdit = true;
                    }
                    var nextApprove = process.FirstOrDefault(x => x.Next == true && x.RequestNo == item.RequestNo);
                    var deptApprover = process.FirstOrDefault(x => x.Active == true && x.RequestNo == item.RequestNo && x.OrderNo == 1);
                    lstResult.Add(new RequestLeadTimeFormInforView()
                    {
                        Id = item.Id,
                        RequestNo = item.RequestNo,
                        CreatedDate = item.CreatedDate == null ? null : item.CreatedDate.Value.ToString("dd-MMM-yyyy"),
                        CreatedBy = item.CreatedBy,
                        Status = item.Status,
                        CanEdit = canEdit,
                        Department = item.Department,
                        IsCreated = u.UserName == item.CreatedBy,
                        RequestBy = item.RequestBy,
                        NextApprover = nextApprove == null ? null : nextApprove.Grade,
                        DeptApprove = deptApprover == null ? false : (deptApprover.Status == 0 ? false : true)
                    }); i++;
                }
                result.lstModel = lstResult;
                result.toRecord = (int)Math.Min(result.totalRecords, result.currentPage * result.recordPerPage);
                result.totalPage = (int)Math.Ceiling((decimal)model.Count / param.RecordsPerPage);
                result.totalRecords = model.Count;
                result.recordPerPage = param.RecordsPerPage;
                result.currentPage = param.Page;
                result.fromRecord = model.Count == 0 ? 0 : (result.currentPage - 1) * result.recordPerPage + 1;
                //}
                return result;
            }
            catch (Exception)
            {
                return new LtFormRegistrationPdc2InforModel();
            }
        }

        [HttpGet("get-infor-request-form-register-ih/{requestNo}")]
        public RequestLeadTimeFormInforView GetInforFormRegisterIh(string requestNo)
        {
            try
            {
                var u = GetCurrentUser();
                var model = context.LtFormRegistrationIhInfors.Where(x => x.Active == true && x.RequestNo == requestNo).FirstOrDefault();
                var lstMaxPP = context.LtInputMaxPpCells.Where(x => x.Active == true).Select(x => x.Model).ToList();
                var lstModelNotPP = context.LtFormRegistrationIhItems.Where(x => x.Active == true && x.RequestNo == requestNo && !lstMaxPP.Contains(x.Model) && x.Model != null && x.Model.Trim() != "").Select(x => x.Model).Distinct().ToList();
                var modelNotPP = lstModelNotPP.Count == 0 ? null : string.Join(";", lstModelNotPP);
                var infor = new RequestLeadTimeFormInforView
                {
                    RequestNo = model.RequestNo,
                    RequestBy = model.RequestBy,
                    Department = model.Department,
                    CreatedDate = model.CreatedDate.Value.ToString("dd-MMM-yyyy"),
                    Note = model.Note,
                    Status = model.Status,
                    CreatedBy = model.CreatedBy,
                    LstNotMaxPP = modelNotPP
                };
                return infor;

            }
            catch (Exception)
            {
                return new RequestLeadTimeFormInforView(); ;
            }
        }

        [HttpPost("get-item-request-form-register-ih/{requestNo}")]
        public async Task<LtFormRegistrationIhModel> GetItemFormRegisterIh(PaginationParams param, string requestNo)
        {
            try
            {
                try
                {

                    LtFormRegistrationIhModel result = new LtFormRegistrationIhModel()
                    {
                        currentPage = param.Page,
                        recordPerPage = param.RecordsPerPage
                    };
                    var query = context.LtFormRegistrationIhItems.Where(x => x.Active == true && x.RequestNo == requestNo);

                    query = !string.IsNullOrEmpty(param.search) ? query.Where(x => x.PartNo.ToUpper().Contains(param.search.ToUpper()) || x.Model.ToUpper().Contains(param.search.ToUpper())) : query;
                    result.totalRecords = await query.CountAsync();
                    result.totalPage = (int)Math.Ceiling((decimal)result.totalRecords / param.RecordsPerPage);
                    var model = await query.ToListAsync();
                    result.lstModel = model;
                    result.fromRecord = model.Count == 0 ? 0 : (result.currentPage - 1) * result.recordPerPage + 1;
                    result.toRecord = (int)Math.Min(result.totalRecords, result.currentPage * result.recordPerPage);
                    result.currentPage = result.totalPage < result.currentPage ? result.totalPage : result.currentPage;
                    return result;
                }
                catch (Exception e)
                {
                    //SendMailError(e);
                    return new LtFormRegistrationIhModel()
                    {
                        currentPage = param.Page,
                        recordPerPage = param.RecordsPerPage
                    };
                }
            }
            catch (Exception)
            {
                return new LtFormRegistrationIhModel(); ;
            }
        }

        [HttpGet("get-process-request-form-register-ih/{requestNo}")]
        public List<LtFormRegistrationIhProcess> GetProcessFormRegisterIh(string requestNo)
        {
            try
            {
                var model = context.LtFormRegistrationIhProcesses.Where(x => x.Active == true && x.RequestNo == requestNo).OrderBy(x => x.OrderNo).ToList();
                return model;

            }
            catch (Exception)
            {
                return new List<LtFormRegistrationIhProcess>(); ;
            }
        }

        //kiểm tra xem có phải người đăng nhập đang ở trạng thái được approve không?
        [HttpGet("check-approver-request-form-register-ih/{requestNo}")]
        public bool CheckApproverFormRegisterIh(string requestNo)
        {
            try
            {
                var u = GetCurrentUser();
                var model = context.LtFormRegistrationIhProcesses.Where(x => x.Active == true && x.RequestNo == requestNo && x.Next == true).FirstOrDefault();
                if (model != null)
                {

                    bool check = false;
                    if (model.OrderNo == 1)
                    {
                        // group approver inhouse
                        check = context.AdmDetailUserGroups.Any(x => x.Active == true && x.UserId == new Guid(u.Id) && x.GroupId == new Guid("dd22b1b9-119c-483b-98ab-3adcee530965"));

                    }
                    if (model.OrderNo == 2)
                    {
                        //group pic pdc1
                        check = context.AdmDetailUserGroups.Any(x => x.Active == true && x.UserId == new Guid(u.Id) && x.GroupId == new Guid("56254ddd-e2cd-460d-a245-27d58f8953d4"));

                    }
                    if (model.OrderNo == 3)
                    {
                        //group g6up pdc1
                        check = context.AdmDetailUserGroups.Any(x => x.Active == true && x.UserId == new Guid(u.Id) && x.GroupId == new Guid("62e95f1a-7590-465e-8cf3-ff7932322b2b"));

                    }
                    return check;
                }
                else
                {
                    return false;
                }

            }
            catch (Exception)
            {
                return false;
            }
        }

        [HttpPut("active-request-form-register-ih")]
        public CommonResponse ActiveFormRegisterIh(string[] requestNo)
        {
            CommonResponse res = new CommonResponse()
            {
                Error = false,
                Message = "",
                Status = (int)HttpStatusCode.BadRequest
            };
            try
            {
                var u = GetCurrentUser();
                var request_no = requestNo[0];
                //active infor
                ADO.doChange("update lt_form_registration_ih_infor set active = false where request_no = '" + request_no + "';");

                //active item
                ADO.doChange("update lt_form_registration_ih_item set active = false where request_no = '" + request_no + "';");

                //active process
                ADO.doChange("update lt_form_registration_ih_process set active = false where request_no = '" + request_no + "';");

                res.Error = false;
                res.Message = "Successfull!";
                res.Status = (int)HttpStatusCode.OK;


            }
            catch (Exception e)
            {
                res.Error = true;
                res.Message = e.Message;
                res.Status = (int)HttpStatusCode.BadRequest;

            }

            return res;
        }

        [HttpGet("send-approver-request-form-register-ih/{requestNo}")]
        public CommonResponse SendApproverFormRegisterIh(string requestNo)
        {
            CommonResponse res = new CommonResponse()
            {
                Error = false,
                Message = "",
                Status = (int)HttpStatusCode.BadRequest
            };
            try
            {
                var u = GetCurrentUser();
                var model = context.LtFormRegistrationIhInfors.Where(x => x.Active == true && x.RequestNo == requestNo).FirstOrDefault();
                model.Status = 0;
                context.Update(model);
                context.SaveChanges();
                //check all member group approver imhouse
                //var checkApprovalDept = context.AdmDetailUserGroups.Include(x => x.User).Where(x => x.Active == true && x.GroupId == new Guid("dd22b1b9-119c-483b-98ab-3adcee530965")).ToList();
                var checkApprovalDept = context.LtFormRegistrationIhProcesses.Where(x => x.Active == true && x.RequestNo == requestNo && x.OrderNo == 1).FirstOrDefault();


                if (checkApprovalDept != null)
                {
                    var link = "http://cvn-vpsi/#/leadtime/form-register/ih-detail/" + requestNo;
                    //var lstReceiver = checkApprovalDept.Where(x => x.User.Active == true && x.User.Email != null && x.User.Email != "").Select(y => y.User.Email).ToList();
                    var user = context.AdmUserInformations.FirstOrDefault(x => x.Active == true && x.EmployeeCode == checkApprovalDept.Approver);
                    var lstReceiver = new List<string>() { user.Email };
                    SendMailRemind("form registration for inhouse", u.FullName, lstReceiver, link);
                }

                res.Error = false;
                res.Message = "Successfull!";
                res.Status = (int)HttpStatusCode.OK;

            }
            catch (Exception e)
            {
                res.Error = true;
                res.Message = e.Message;
                res.Status = (int)HttpStatusCode.BadRequest;
            }
            return res;
        }

        [HttpPut("approve-request-form-register-ih/{id}")]
        public CommonResponse ApproveFormRegisterIh(string[] comment, Guid id)
        {
            CommonResponse res = new CommonResponse()
            {
                Error = false,
                Message = "",
                Status = (int)HttpStatusCode.BadRequest
            };
            try
            {
                var u = GetCurrentUser();
                var cmt = comment[0];
                var model = context.LtFormRegistrationIhProcesses.FirstOrDefault(x => x.Active == true && x.Id == id);

                if (model != null)
                {
                    var maxOrder = context.LtFormRegistrationIhProcesses.Where(x => x.Active == true && x.RequestNo == model.RequestNo).Max(y => y.OrderNo);
                    model.Status = 1;
                    model.Approver = u.UserName;
                    model.ApproverName = u.FullName;
                    model.ApprovedDate = DateTime.Now.ToString("dd-MMM-yyyy");
                    model.Next = false;
                    model.Comment = cmt;
                    context.Update(model);
                    if (model.OrderNo == 1)
                    {

                        var nextApprove = context.LtFormRegistrationIhProcesses.FirstOrDefault(x => x.Active == true && x.RequestNo == model.RequestNo && x.OrderNo == 2);
                        if (nextApprove != null)
                        {
                            nextApprove.Next = true;
                            context.Update(nextApprove);
                            //check all member group pic pdc1
                            var checkApprovalPDC1 = context.AdmDetailUserGroups.Include(x => x.User).Where(x => x.Active == true && x.GroupId == new Guid("56254ddd-e2cd-460d-a245-27d58f8953d4")).ToList();
                            if (checkApprovalPDC1.Count > 0)
                            {
                                var link = "http://cvn-vpsi/#/leadtime/form-register/ih-detail/" + model.RequestNo;
                                var lstReceiver = checkApprovalPDC1.Where(x => x.User.Active == true && x.User.Email != null && x.User.Email != "").Select(y => y.User.Email).ToList();
                                SendMailRemind("form registration for inhouse", u.FullName, lstReceiver, link);
                            }
                        }
                    }
                    if (model.OrderNo == 2)
                    {

                        var nextApprove = context.LtFormRegistrationIhProcesses.FirstOrDefault(x => x.Active == true && x.RequestNo == model.RequestNo && x.OrderNo == maxOrder);
                        if (nextApprove != null)
                        {
                            nextApprove.Next = true;
                            context.Update(nextApprove);
                            //check all member group g6up pdc1
                            var checkApprovalPDC1 = context.AdmDetailUserGroups.Include(x => x.User).Where(x => x.Active == true && x.GroupId == new Guid("62e95f1a-7590-465e-8cf3-ff7932322b2b")).ToList();
                            if (checkApprovalPDC1.Count > 0)
                            {
                                var link = "http://cvn-vpsi/#/leadtime/form-register/ih-detail/" + model.RequestNo;
                                var lstReceiver = checkApprovalPDC1.Where(x => x.User.Active == true && x.User.Email != null && x.User.Email != "").Select(y => y.User.Email).ToList();
                                SendMailRemind("form registration for inhouse", u.FullName, lstReceiver, link);
                            }
                        }
                    }
                    if (model.OrderNo == maxOrder)
                    {
                        var infor = context.LtFormRegistrationIhInfors.FirstOrDefault(x => x.Active == true && x.RequestNo == model.RequestNo);
                        if (infor != null)
                        {
                            infor.Status = 1;
                            infor.ModifiedDate = DateTime.Now.SetKindUtc();
                            context.Update(infor);

                            var link = "http://cvn-vpsi/#/leadtime/form-register/ih-detail/" + model.RequestNo;
                            var user = context.AdmUserInformations.FirstOrDefault(x => x.EmployeeCode == infor.CreatedBy);
                            var receiver = user.FullName;
                            var lstReceiver = user == null ? new List<string>() : new List<string>() { user.Email };
                            SendMailApproved("form registration for inhouse", u.FullName, lstReceiver, receiver, link);
                            var lstUpdate = context.LtFormRegistrationIhItems.Where(x => x.Active == true && x.RequestNo == model.RequestNo).ToList();
                            lstUpdate.ForEach(x => x.ApprovedStatus = 1);
                            context.UpdateRange(lstUpdate);
                        }
                    }
                    context.SaveChanges();
                }

                res.Error = false;
                res.Message = "Successfull!";
                res.Status = (int)HttpStatusCode.OK;


            }
            catch (Exception e)
            {
                res.Error = true;
                res.Message = e.Message;
                res.Status = (int)HttpStatusCode.BadRequest;

            }

            return res;
        }

        [HttpPut("reject-request-form-register-ih/{id}")]
        public CommonResponse RejectFormRegisterIh(string[] comment, Guid id)
        {
            CommonResponse res = new CommonResponse()
            {
                Error = false,
                Message = "",
                Status = (int)HttpStatusCode.BadRequest
            };
            try
            {
                var u = GetCurrentUser();
                var cmt = comment[0];
                var model = context.LtFormRegistrationIhProcesses.FirstOrDefault(x => x.Active == true && x.Id == id);

                if (model != null)
                {
                    model.Status = 2;
                    model.Approver = u.UserName;
                    model.ApproverName = u.FullName;
                    model.ApprovedDate = DateTime.Now.ToString("dd-MMM-yyyy");
                    model.Next = false;
                    model.Comment = cmt;
                    context.Update(model);

                    var infor = context.LtFormRegistrationIhInfors.FirstOrDefault(x => x.Active == true && x.RequestNo == model.RequestNo);
                    infor.Status = 2;
                    infor.ModifiedDate = DateTime.Now.SetKindUtc();
                    context.Update(infor);

                    context.SaveChanges();

                    var link = "http://cvn-vpsi/#/leadtime/form-register/ih-detail/" + model.RequestNo;
                    var user = context.AdmUserInformations.FirstOrDefault(x => x.EmployeeCode == infor.CreatedBy);
                    var receiver = user.FullName;
                    var lstReceiver = user == null ? new List<string>() : new List<string>() { user.Email };

                    SendMailRejectd("form registration for inhouse", cmt, u.FullName, lstReceiver, receiver, link);
                    //check approved
                    if (model.OrderNo != 1)
                    {
                        var lstApproved = context.LtFormRegistrationIhProcesses.Where(x => x.Active == true && x.RequestNo == model.RequestNo && x.OrderNo < model.OrderNo).ToList();
                        foreach (var approved in lstApproved)
                        {
                            var userApproved = context.AdmUserInformations.FirstOrDefault(x => x.EmployeeCode == approved.Approver);
                            var receiverApproved = userApproved.FullName;
                            var lstReceiverApproved = userApproved == null ? new List<string>() : new List<string>() { userApproved.Email };
                            SendMailRejectd("form registration for inhouse", cmt, u.FullName, lstReceiverApproved, receiverApproved, link);
                        }
                    }


                }

                res.Error = false;
                res.Message = "Successfull!";
                res.Status = (int)HttpStatusCode.OK;


            }
            catch (Exception e)
            {
                res.Error = true;
                res.Message = e.Message;
                res.Status = (int)HttpStatusCode.BadRequest;

            }

            return res;
        }

        [HttpGet("get-approver-inhouse")]
        public List<MasterUserInforView> GetApproverInhouse()
        {
            try
            {
                var result = new List<MasterUserInforView>();
                var model = context.AdmDetailUserGroups.Include(x => x.User).Where(x => x.Active == true && x.GroupId == new Guid("dd22b1b9-119c-483b-98ab-3adcee530965")).ToList();
                foreach (var item in model)
                {
                    result.Add(new MasterUserInforView
                    {
                        EmployeeCode = item.User.EmployeeCode + "_" + item.User.FullName
                    });
                }
                return result;

            }
            catch (Exception e)
            {
                return new List<MasterUserInforView>();
            }

        }

        [HttpPost("forward-approver-inhouse/{requestNo}")]
        public CommonResponse ForwardApproverInhouse(string requestNo, string[] approver)
        {
            CommonResponse res = new CommonResponse()
            {
                Error = false,
                Message = "",
                Status = (int)HttpStatusCode.BadRequest
            };
            try
            {
                var u = GetCurrentUser();
                var process = context.LtFormRegistrationIhProcesses.FirstOrDefault(x => x.Active == true && x.RequestNo == requestNo && x.OrderNo == 1);
                var newApprover = approver[0].Split("_");
                var oldApprover = context.AdmUserInformations.FirstOrDefault(x => x.Active == true && x.EmployeeCode == process.Approver);
                var currentApprover = context.AdmUserInformations.FirstOrDefault(x => x.Active == true && x.EmployeeCode == newApprover[0]);

                process.Approver = newApprover[0];
                process.ApproverName = newApprover[1];
                context.Update(process);
                context.SaveChanges();
                //send mail for new approver
                var link = "http://cvn-vpsi/#/leadtime/form-register/ih-detail/" + requestNo;
                var lstReceiver = new List<string>() { oldApprover.Email };
                SendMailRemind("form registration for inhouse", u.FullName, lstReceiver, link);

                //send mail for new old approver
                var lstReceiverNew = new List<string>() { currentApprover.Email };
                SendMailForward(oldApprover.FullName, currentApprover.FullName, u.FullName, lstReceiverNew, requestNo);

                res.Error = false;
                res.Message = "Successfull!";
                res.Status = (int)HttpStatusCode.OK;
            }
            catch (Exception e)
            {
                res.Error = true;
                res.Message = e.Message;
                res.Status = (int)HttpStatusCode.BadRequest;

            }
            return res;

        }
        #endregion
        #region form register other
        [HttpPost("filter-lt-other-form")]
        public async Task<LtFormRegistrationOtherModel> FilterOtherForm(LtFormRegistrationOtherParam parameters)
        {
            try
            {

                LtFormRegistrationOtherModel result = new LtFormRegistrationOtherModel()
                {
                    currentPage = parameters.Page,
                    recordPerPage = parameters.RecordsPerPage
                };
                DateOnly? effectiveDate = parameters.EffectiveDate.StringToDateAble();

                var query = context.LtFormRegistrationOthers.Where(x => x.Active == true);
                query = !string.IsNullOrEmpty(parameters.Vendor) ? query.Where(x => x.Vendor != null && x.Vendor.ToUpper().Contains(parameters.Vendor.ToUpper())) : query;
                query = !string.IsNullOrEmpty(parameters.PartNo) ? query.Where(x => x.PartNo != null && x.PartNo.ToUpper().Contains(parameters.PartNo.ToUpper())) : query;
                query = parameters.EffectiveDate != null ? query.Where(x => x.EffectiveDate != null && x.EffectiveDate == effectiveDate) : query;
                query = !string.IsNullOrEmpty(parameters.LeadTime) ? query.Where(x => x.LeadTime != null && x.LeadTime.ToUpper().Contains(parameters.LeadTime.ToUpper())) : query;

                result.totalRecords = await query.CountAsync();
                result.totalPage = (int)Math.Ceiling((decimal)result.totalRecords / parameters.RecordsPerPage);
                var model = await query.OrderByDescending(x => x.CreatedDate).Paginate(parameters).ToListAsync();
                result.lstModel = model;
                result.fromRecord = model.Count == 0 ? 0 : (result.currentPage - 1) * result.recordPerPage + 1;
                result.toRecord = (int)Math.Min(result.totalRecords, result.currentPage * result.recordPerPage);
                result.currentPage = result.totalPage < result.currentPage ? result.totalPage : result.currentPage;
                return result;
            }
            catch (Exception e)
            {
                //SendMailError(e);
                return new LtFormRegistrationOtherModel()
                {
                    currentPage = parameters.Page,
                    recordPerPage = parameters.RecordsPerPage
                };
            }
        }

        [HttpGet("approve-lt-other-form")]
        public async Task<CommonResponse> ApproveLtOtherForm()
        {
            CommonResponse res = new CommonResponse()
            {
                Error = false,
                Message = "",
                Status = (int)HttpStatusCode.BadRequest
            };
            try
            {

                var u = GetCurrentUser();
                var model = await context.LtFormRegistrationOthers
                        .Where(x => x.Active == true)
                        .ToListAsync();
                model.ForEach(x =>
                {
                    x.ApprovedBy = u.UserName;
                    x.ApprovedDate = DateTime.Now;

                });
                context.UpdateRange(model);
                context.SaveChanges();


                res.Error = false;
                res.Message = "Successfully !";
                res.Status = (int)HttpStatusCode.OK;
                return res;
            }
            catch (Exception e)
            {
                res.Error = true;
                res.Message = e.Message;
                res.Status = (int)HttpStatusCode.BadRequest;
                //SendMailError(e);
                return res;
            }


        }

        [HttpGet("reject-lt-other-form")]
        public async Task<CommonResponse> RejectLtOtherForm()
        {
            CommonResponse res = new CommonResponse()
            {
                Error = false,
                Message = "",
                Status = (int)HttpStatusCode.BadRequest
            };
            try
            {

                var u = GetCurrentUser();
                var model = await context.LtFormRegistrationOthers
                        .Where(x => x.Active == true && x.ApprovedBy == null)
                        .ToListAsync();
                model.ForEach(x =>
                {
                    x.Active = false;
                    x.ApprovedBy = u.UserName;
                    x.ApprovedDate = DateTime.Now;

                });
                context.UpdateRange(model);
                context.SaveChanges();


                res.Error = false;
                res.Message = "Successfully !";
                res.Status = (int)HttpStatusCode.OK;
                return res;
            }
            catch (Exception e)
            {
                res.Error = true;
                res.Message = e.Message;
                res.Status = (int)HttpStatusCode.BadRequest;
                //SendMailError(e);
                return res;
            }


        }
        #endregion

        #region check job processing
        [HttpGet("check-job-processing")]
        public async Task<CommonResponse> CheckJobProcessing()
        {
            CommonResponse res = new CommonResponse()
            {
                Error = false,
                Message = "",
                Status = (int)HttpStatusCode.BadRequest
            };
            try
            {

                var monitoringApi = JobStorage.Current.GetMonitoringApi();
                var countSucess = monitoringApi.ProcessingCount();
                var enqueuedJobs = monitoringApi.ProcessingJobs(0, (int)countSucess);

                var jobExists = enqueuedJobs.FirstOrDefault(job => job.Value.Job.Method.Name == "UpdateOp2WithFormPDC2" ||
                job.Value.Job.Method.Name == "UpdateOp2WithFormLOG" ||
                job.Value.Job.Method.Name == "UpdateOp2WithFormASSY" ||
                job.Value.Job.Method.Name == "UpdateOp2WithFormInHouse" ||
                job.Value.Job.Method.Name == "UpdateOp2WithFormOther" ||
                job.Value.Job.Method.Name == "UpdateOp2InquiryWithApprove" ||
                job.Value.Job.Method.Name == " UpdateOp2InquiryWithApproveOther");

                if (jobExists.Value != null)
                {
                    res.Error = true;
                    res.Message = "Job " + jobExists.Value.Job.Method.Name + " is processing, please wait complete!";
                    res.Status = (int)HttpStatusCode.BadRequest;
                }
                else
                {
                    res.Error = false;
                    res.Message = "Successfully !";
                    res.Status = (int)HttpStatusCode.OK;
                }
            }
            catch (Exception e)
            {
                res.Error = true;
                res.Message = e.Message;
                res.Status = (int)HttpStatusCode.BadRequest;
                //SendMailError(e);
            }
            return res;


        }

        //check in group pic dept
        [HttpGet("check-in-group-pic")]
        public  List<string?> CheckGroupPic()
        {
            var u = GetCurrentUser();
            var groupDeatail = context.AdmDetailUserGroups.Include(x => x.Group)
                .Where(x => x.Active == true && x.UserId == new Guid(u.Id) &&
                x.Group.Active == true &&
                (x.Group.GroupName.Contains("Pdc1") || x.Group.GroupName.Contains("Pdc2") 
                || x.Group.GroupName.Contains("Log") || x.Group.GroupName.Contains("Assy") 
                || x.Group.GroupName.Contains("Inhouse") || x.Group.GroupName.Contains("Admin")
                || x.Group.GroupName.Contains("administrator")
                || x.Group.GroupName.ToUpper().Equals("PIC"))).ToList();
            var group = groupDeatail.Select(x => x.Group.GroupName).ToList();
            return group;
        }

        #endregion

        #region update output after approve
        [HttpGet("update-op2-after-approve-form-pdc2/{requestNo}")]
        public IActionResult UpdateOp2WithFormPdc2(string? requestNo)
        {
            try
            {
                var monitoringApi = JobStorage.Current.GetMonitoringApi();
                var countSucess = monitoringApi.SucceededListCount();
                var enqueuedJobs = monitoringApi.SucceededJobs(0, (int)countSucess);

                var jobExists = enqueuedJobs.FirstOrDefault(job => job.Value.Job != null && job.Value.Job.Method.Name == "UpdateOp2WithFormPDC2" && job.Value.Job.Arguments[0].Contains(requestNo));
                //var backgroundJobClient = new BackgroundJobClient();
                if (jobExists.Value != null)
                {
                    // Công việc đã được enqueue trước đó thì chỉ việc chạy lại
                    _bgJobClient.Requeue(jobExists.Key);
                }
                else
                {
                    // Công việc chưa được enqueue, tạo mới trong CSDL
                    _bgJobClient.Enqueue<ILeadTimeJob>(x => x.UpdateOp2WithFormPDC2(requestNo));
                }
                return Ok();
            }
            catch (Exception)
            {
                return NoContent();
            }
        }

        [HttpGet("update-op2-after-approve-form-log/{requestNo}")]
        public IActionResult UpdateOp2WithFormLog(string? requestNo)
        {
            try
            {

                var monitoringApi = JobStorage.Current.GetMonitoringApi();
                var countSucess = monitoringApi.SucceededListCount();
                var enqueuedJobs = monitoringApi.SucceededJobs(0, (int)countSucess);

                var jobExists = enqueuedJobs.FirstOrDefault(job => job.Value.Job != null && job.Value.Job.Method.Name == "UpdateOp2WithFormLOG" && job.Value.Job.Arguments[0].Contains(requestNo));
                //var backgroundJobClient = new BackgroundJobClient();
                if (jobExists.Value != null)
                {
                    // Công việc đã được enqueue trước đó thì chỉ việc chạy lại
                    _bgJobClient.Requeue(jobExists.Key);
                }
                else
                {
                    // Công việc chưa được enqueue, tạo mới trong CSDL
                    _bgJobClient.Enqueue<ILeadTimeJob>(x => x.UpdateOp2WithFormLOG(requestNo));
                }
                return Ok();
            }
            catch (Exception)
            {
                return NoContent();
            }
        }

        [HttpGet("update-op2-after-approve-form-assy/{requestNo}")]
        [AllowAnonymous]
        public IActionResult UpdateOp2WithFormAssy(string? requestNo)
        {
            try
            {

                var monitoringApi = JobStorage.Current.GetMonitoringApi();
                var countSucess = monitoringApi.SucceededListCount();
                var enqueuedJobs = monitoringApi.SucceededJobs(0, (int)countSucess);
                var jobExists = enqueuedJobs.FirstOrDefault(job => job.Value.Job != null && job.Value.Job.Method.Name == "UpdateOp2WithFormASSY" && job.Value.Job.Arguments[0].Contains(requestNo));
                
                //var backgroundJobClient = new BackgroundJobClient();
                if (jobExists.Value != null)
                {
                    // Công việc đã được enqueue trước đó thì chỉ việc chạy lại
                    _bgJobClient.Requeue(jobExists.Key);
                 
                }
                else
                {

                    // Công việc chưa được enqueue, tạo mới trong CSDL
                    _bgJobClient.Enqueue<ILeadTimeJob>(x => x.UpdateOp2WithFormASSY(requestNo));
                

                }
                return Ok();
            }
            catch (Exception e)
            {
                  
                return NoContent();
            }
        }

        [HttpGet("update-op2-after-approve-form-ih/{requestNo}")]
        public IActionResult UpdateOp2WithFormIh(string? requestNo)
        {
            try
            {

                var monitoringApi = JobStorage.Current.GetMonitoringApi();
                var countSucess = monitoringApi.SucceededListCount();
                var enqueuedJobs = monitoringApi.SucceededJobs(0, (int)countSucess);

                var jobExists = enqueuedJobs.FirstOrDefault(job => job.Value.Job != null && job.Value.Job.Method.Name == "UpdateOp2WithFormInHouse" && job.Value.Job.Arguments[0].Contains(requestNo));
                //var backgroundJobClient = new BackgroundJobClient();
                if (jobExists.Value != null)
                {
                    // Công việc đã được enqueue trước đó thì chỉ việc chạy lại
                    _bgJobClient.Requeue(jobExists.Key);
                }
                else
                {
                    // Công việc chưa được enqueue, tạo mới trong CSDL
                    _bgJobClient.Enqueue<ILeadTimeJob>(x => x.UpdateOp2WithFormInHouse(requestNo));
                }
                return Ok();
            }
            catch (Exception)
            {
                return NoContent();
            }
        }

        [HttpGet("update-op2-after-approve-form-other")]
        public IActionResult UpdateOp2WithFormOther()
        {
            try
            {

                var monitoringApi = JobStorage.Current.GetMonitoringApi();
                var countSucess = monitoringApi.SucceededListCount();
                var enqueuedJobs = monitoringApi.SucceededJobs(0, (int)countSucess);

                var jobExists = enqueuedJobs.FirstOrDefault(job => job.Value.Job != null && job.Value.Job.Method.Name == "UpdateOp2WithFormOther");
                //var backgroundJobClient = new BackgroundJobClient();
                if (jobExists.Value != null)
                {
                    // Công việc đã được enqueue trước đó thì chỉ việc chạy lại
                    _bgJobClient.Requeue(jobExists.Key);
                }
                else
                {
                    // Công việc chưa được enqueue, tạo mới trong CSDL
                    _bgJobClient.Enqueue<ILeadTimeJob>(x => x.UpdateOp2WithFormOther());
                }
                return Ok();
            }
            catch (Exception)
            {
                return NoContent();
            }
        }

        [HttpGet("update-op2-inquiry-after-approve/{requestNo}")]
        public IActionResult UpdateOp2InquiryAfterApprove(string? requestNo)
        {
            try
            {

                var monitoringApi = JobStorage.Current.GetMonitoringApi();
                var countSucess = monitoringApi.SucceededListCount();
                var enqueuedJobs = monitoringApi.SucceededJobs(0, (int)countSucess);

                var jobExists = enqueuedJobs.FirstOrDefault(job => job.Value.Job != null && job.Value.Job.Method.Name == "UpdateOp2InquiryWithApprove" && job.Value.Job.Arguments[0].Contains(requestNo));                //var backgroundJobClient = new BackgroundJobClient();
                if (jobExists.Value != null)
                {
                    // Công việc đã được enqueue trước đó thì chỉ việc chạy lại
                    _bgJobClient.Requeue(jobExists.Key);
                }
                else
                {
                    // Công việc chưa được enqueue, tạo mới trong CSDL
                    _bgJobClient.Enqueue<ILeadTimeJob>(x => x.UpdateOp2InquiryWithApprove(requestNo));
                }
                return Ok();
            }
            catch (Exception)
            {
                return NoContent();
            }
        }

        [HttpGet("update-op2-inquiry-after-approve-form-other")]
        public IActionResult UpdateOp2InquiryAfterApproveFormOther()
        {
            try
            {

                var monitoringApi = JobStorage.Current.GetMonitoringApi();
                var countSucess = monitoringApi.SucceededListCount();
                var enqueuedJobs = monitoringApi.SucceededJobs(0, (int)countSucess);

                var jobExists = enqueuedJobs.FirstOrDefault(job => job.Value.Job != null && job.Value.Job.Method.Name == "UpdateOp2InquiryWithApproveOther");                //var backgroundJobClient = new BackgroundJobClient();
                if (jobExists.Value != null)
                {
                    // Công việc đã được enqueue trước đó thì chỉ việc chạy lại
                    _bgJobClient.Requeue(jobExists.Key);
                }
                else
                {
                    // Công việc chưa được enqueue, tạo mới trong CSDL
                    _bgJobClient.Enqueue<ILeadTimeJob>(x => x.UpdateOp2InquiryWithApproveOther());
                }
                return Ok();
            }
            catch (Exception)
            {
                return NoContent();
            }
        }
        #endregion

        #region input maxppcell
        [HttpPost("fillter-input-max-pp-cell")]
        public LtInputMaxPPCellModel FillterInputMaxPPCell(PaginationParams param)
        {
            try
            {
                param.search = param.search.ToUpper().Trim();
                var result = new LtInputMaxPPCellModel();
                var lstResult = new List<LtInputMaxPpCell>();
                var u = GetCurrentUser();
               
                var model = context.LtInputMaxPpCells.Where(x => x.Active == true &&  x.Model.ToUpper().Contains(param.search)).ToList();


                var model2 = model.Skip((param.Page - 1) * param.RecordsPerPage).Take(param.RecordsPerPage).ToList();
                int i = 0;
                foreach (var item in model2)
                {
                  lstResult.Add(new LtInputMaxPpCell()
                    {
                       Id = item.Id,
                       CreatedBy  = item.CreatedBy,
                       CreatedDate = item.CreatedDate,
                       Model = item.Model,
                       Cell = item.Cell,
                       Value = item.Value
                    }); 
                }
                result.lstModel = lstResult;
                result.toRecord = (int)Math.Min(result.totalRecords, result.currentPage * result.recordPerPage);
                result.totalPage = (int)Math.Ceiling((decimal)model.Count / param.RecordsPerPage);
                result.totalRecords = model.Count;
                result.recordPerPage = param.RecordsPerPage;
                result.currentPage = param.Page;
                result.fromRecord = model.Count == 0 ? 0 : (result.currentPage - 1) * result.recordPerPage + 1;
                //}
                return result;
            }
            catch (Exception)
            {
                return new LtInputMaxPPCellModel();
            }
        }

        [HttpPost("add-max-pp-cell")]
        public async Task<CommonResponse> AddMaxPPCell([FromBody] MaxPPCellRequest rq)
        {
            CommonResponse res = new CommonResponse()
            {
                Error = true,
                Message = "Can't add new",
                Status = 400
            };
           
            try
            {
             
                var u = GetCurrentUser();

                var add = new LtInputMaxPpCell()
                {
                    CreatedBy = u.UserName,
                    CreatedDate = DateTime.Now.SetKindUtc(),
                    Model = rq.Model,
                    Cell = rq.Cell,
                    Value = rq.Value
                };
                context.Add(add);
                context.SaveChanges();
                
                res.Status = 200;
                res.Message = "Sucessful !";
                res.Error = true;
                    
                
            }
            catch (Exception e)
            {
                //SendMailError(e);
                res.Message = e.Message;
                res.Error = true;
                res.Status = 400;
            }
            return res;
        }

        [HttpPost("edit-max-pp-cell")]
        public async Task<CommonResponse> EditMaxPPCell([FromBody] MaxPPCellRequest rq)
        {
            CommonResponse res = new CommonResponse()
            {
                Error = true,
                Message = "Can't add new",
                Status = 400
            };

            try
            {

                var u = GetCurrentUser();
                var model = context.LtInputMaxPpCells.FirstOrDefault(x => x.Id == rq.Id);
                model.ModifiedBy = u.UserName;
                model.ModifiedDate = DateTime.Now.SetKindUtc();
                model.Model = rq.Model;
                model.Cell = rq.Cell;
                model.Value = rq.Value;               
                context.Update(model);
                context.SaveChanges();

                res.Status = 200;
                res.Message = "Sucessful !";
                res.Error = true;


            }
            catch (Exception e)
            {
                //SendMailError(e);
                res.Message = e.Message;
                res.Error = true;
                res.Status = 400;
            }
            return res;
        }

        [HttpGet("active-max-pp-cell/{id}")]
        public async Task<CommonResponse> ActiveMaxPPCell(Guid id)
        {
            CommonResponse res = new CommonResponse()
            {
                Error = true,
                Message = "Can't add new",
                Status = 400
            };

            try
            {

                var u = GetCurrentUser();
                var model = context.LtInputMaxPpCells.FirstOrDefault(x => x.Id == id);
                model.ModifiedBy = u.UserName;
                model.ModifiedDate = DateTime.Now.SetKindUtc();
                model.Active = false;
                context.Update(model);
                context.SaveChanges();

                res.Status = 200;
                res.Message = "Sucessful !";
                res.Error = true;


            }
            catch (Exception e)
            {
                //SendMailError(e);
                res.Message = e.Message;
                res.Error = true;
                res.Status = 400;
            }
            return res;
        }
        #endregion
        #region approve inquiry
        [HttpGet("approve-lt-inquiry-upload")]
        public async Task<CommonResponse> ApproveLtInquiryUpload()
        {
            CommonResponse res = new CommonResponse()
            {
                Error = false,
                Message = "",
                Status = (int)HttpStatusCode.BadRequest
            };
            try
            {

                var u = GetCurrentUser();
                var lstOld = await context.LtOp2Inquiries
                         .Where(x => x.Active == true && x.ApprovedDate != null).ToListAsync();
                var lstNew = context.LtOp2Inquiries
                         .Where(x => x.Active == true && x.ApprovedDate == null).ToList();
                if (lstNew != null && lstNew.Count > 0)
                {

                    //List<LtOp2Inquiry> lstDel = new List<LtOp2Inquiry>();
                    lstNew.ForEach(x =>
                    {
                        x.ApprovedBy = u.UserName;
                        x.ApprovedDate = DateTime.Now;

                    });
                    var lstPartNoVd = lstNew.Select(x => x.PartNo + "_" + x.Model).ToList();
                    var exists = lstOld.Where(y => lstPartNoVd.Contains(y.PartNo+"_"+y.Model)).ToList();
                    exists.ForEach(x => x.Active = false);

                    context.UpdateRange(lstNew);
                    context.UpdateRange(lstOld);
                    context.SaveChanges();
                   
                }

                res.Error = false;
                res.Message = "Successfully !";
                res.Status = (int)HttpStatusCode.OK;
                return res;
            }
            catch (Exception e)
            {
                res.Error = true;
                res.Message = e.Message;
                res.Status = (int)HttpStatusCode.BadRequest;
                //SendMailError(e);
                return res;
            }


        }

        [HttpGet("reject-lt-inquiry-upload")]
        public async Task<CommonResponse> RejectLtInquiryUpload()
        {
            CommonResponse res = new CommonResponse()
            {
                Error = false,
                Message = "",
                Status = (int)HttpStatusCode.BadRequest
            };
            try
            {

                var u = GetCurrentUser();
                var model = await context.LtOp2Inquiries
                        .Where(x => x.Active == true && x.ApprovedBy == null)
                        .ToListAsync();
                model.ForEach(x =>
                {
                    x.Active = false;
                    x.ApprovedBy = u.UserName;
                    x.ApprovedDate = DateTime.Now;

                });
                context.UpdateRange(model);
                context.SaveChanges();


                res.Error = false;
                res.Message = "Successfully !";
                res.Status = (int)HttpStatusCode.OK;
                return res;
            }
            catch (Exception e)
            {
                res.Error = true;
                res.Message = e.Message;
                res.Status = (int)HttpStatusCode.BadRequest;
                //SendMailError(e);
                return res;
            }


        }
        #endregion

        #region all fuction private
        //gửi mail khi reject
        private bool SendMailRejectd(string type, string reason, string rejectBy, List<string> lstReceive, string receiver, string link)
        {
            try
            {
                string txtContent = "<span style = 'font-weight: bold;'> Dear Mrs/Mr." + receiver + "</span><br><br>" +
                "<span>Your request approve/confirm for</span>: <span style = 'font-weight: bold;'>" + type + " was returned </span><br>" +
                "<span>Reason</span>: <span style = 'font-weight: bold;'>" + reason + "</span><br>" +
                "<span>Returned by</span>: <span style = 'font-weight: bold;'>" + rejectBy + "</span><br>" +
                "<span>Returned date</span>: <span style = 'font-weight: bold;'>" + DateTime.Now.ToString("dd-MMM-yyyy") + "</span><br>" +
                "<span>You can check it at: " + link + "</span><br><br>" +
                "";

                email.Initial(lstReceive,
                    "[PSI-System] Returned request",
                    txtContent);
                return false;
            }
            catch
            {
                return false;
            }
        }
        //gửi mail báo hoàn thành approve
        private bool SendMailApproved(string type, string approveBy, List<string> lstReceive, string receiver, string link)
        {
            try
            {
                string txtContent = "<span style = 'font-weight: bold;'> Dear Mrs/Mr." + receiver + "</span><br><br>" +
                "<span>Your request approve for</span>: <span style = 'font-weight: bold;'>" + type + " was confirmed </span><br>" +
                "<span>Confirm by</span>: <span style = 'font-weight: bold;'>" + approveBy + "</span><br>" +
                "<span>Confirm date</span>: <span style = 'font-weight: bold;'>" + DateTime.Now.ToString("dd-MMM-yyyy") + "</span><br>" +
                "<span>You can check it at: " + link + "</span><br><br>" +
                "";


                email.Initial(lstReceive,
                    "[PSI-System] Completed request",
                    txtContent);
                return false;
            }
            catch
            {
                return false;
            }
        }

        private bool SendMailRemind(string type, string requestedBy, List<string> lstReceive, string link)
        {
            try
            {
                string txtContent = "<span style = 'font-weight: bold;'> Dear Mrs/Mr.All,</span><br><br>" +
                "<span>You have request need approve/confirm for</span>: <span style = 'font-weight: bold;'>" + type + "  </span><br>" +
                "<span>Requested by</span>: <span style = 'font-weight: bold;'>" + requestedBy + "</span><br>" +
                "<span>Requested date</span>: <span style = 'font-weight: bold;'>" + DateTime.Now.ToString("dd-MMM-yyyy") + "</span><br>" +
                "<span>Please check it at: " + link + "</span><br><br>" +
                "";


                email.Initial(lstReceive,
                    "[PSI-System] Check approve request",
                    txtContent);
                return false;
            }
            catch
            {
                return false;
            }
        }

        private bool SendMailError(Exception e)
        {
            try
            {
                string txtContent = "<p>Message: " + e.Message + "</p><br>" +
                "<p>Data: " + e.Data.ToString() + "</p><br>" +
                "<p>StackTrace: " + e.StackTrace + "</p><br>" +
                "<p>HelpLink: " + e.HelpLink ?? "" + "</p><br>" +
                "<p>Source: " + e.Source ?? "" + "</p><br>";
                email.InitialDev(
                    "Error exception",
                    txtContent);
                return false;
            }
            catch
            {
                return false;
            }
        }
        private UserClaims GetCurrentUser()
        {
            UserClaims userClaims = new UserClaims();
            var identity = HttpContext.User.Identity as ClaimsIdentity;
            if (identity != null)
            {
                userClaims.UserName = identity.FindFirst("user_name") == null ? "Undefined" : identity.FindFirst("user_name").Value;
                userClaims.Id = identity.FindFirst("id") == null ? "Undefined" : identity.FindFirst("id").Value;
                //userClaims.IsIt = identity.FindFirst("isIt") == null ? "0" : identity.FindFirst("isIt").Value;
                userClaims.Departments = identity.FindFirst("deptIds") == null ? "" : identity.FindFirst("deptIds").Value;
                userClaims.Factories = identity.FindFirst("factIds") == null ? "" : identity.FindFirst("factIds").Value;
                userClaims.CostCenter = identity.FindFirst("cost_center") == null ? "" : identity.FindFirst("cost_center").Value;
                userClaims.FullName = identity.FindFirst("full_name") == null ? "" : identity.FindFirst("full_name").Value;
                userClaims.Departments = identity.FindFirst("dept") == null ? "" : identity.FindFirst("dept").Value;
                userClaims.Grade = identity.FindFirst("grade") == null ? "" : identity.FindFirst("grade").Value;
                userClaims.IsAdmin = identity.FindFirst("isAdmin") == null ? "false" : identity.FindFirst("isAdmin").Value;

            }
            return userClaims;
        }
        private string GetNewRequestNo(string prefix, string type)
        {
            try
            {
                string rq_no1 = prefix + "00";
                string rq_no2 = rq_no1;
                try
                {
                    if (type.Contains("PDC2"))
                    {
                        rq_no2 = context.LtFormRegistrationPdc2Items.Where(x => x.RequestNo.StartsWith(prefix)).ToList().OrderByDescending(x =>
                        {
                            string numberString = x.RequestNo.Contains("-") ? x.RequestNo.Substring(x.RequestNo.LastIndexOf("-") + 1) : x.RequestNo;
                            if (int.TryParse(numberString, out int number))
                            {
                                return number;
                            }
                            // Xử lý trường hợp không thể chuyển đổi thành số nguyên
                            // Trả về một giá trị mặc định hoặc giá trị tùy ý để sắp xếp
                            return 0;
                        }).FirstOrDefault().RequestNo;
                    }
                    if (type.Contains("LOG"))
                    {
                        rq_no2 = context.LtFormRegistrationLogItems.Where(x => x.RequestNo.StartsWith(prefix)).ToList().OrderByDescending(x =>
                        {
                            string numberString = x.RequestNo.Contains("-") ? x.RequestNo.Substring(x.RequestNo.LastIndexOf("-") + 1) : x.RequestNo;
                            if (int.TryParse(numberString, out int number))
                            {
                                return number;
                            }
                            // Xử lý trường hợp không thể chuyển đổi thành số nguyên
                            // Trả về một giá trị mặc định hoặc giá trị tùy ý để sắp xếp
                            return 0;
                        }).FirstOrDefault().RequestNo;
                    }
                    if (type.Contains("ASSY"))
                    {
                        rq_no2 = context.LtFormRegistrationAssyItems.Where(x => x.RequestNo.StartsWith(prefix)).ToList().OrderByDescending(x =>
                        {
                            string numberString = x.RequestNo.Contains("-") ? x.RequestNo.Substring(x.RequestNo.LastIndexOf("-") + 1) : x.RequestNo;
                            if (int.TryParse(numberString, out int number))
                            {
                                return number;
                            }
                            // Xử lý trường hợp không thể chuyển đổi thành số nguyên
                            // Trả về một giá trị mặc định hoặc giá trị tùy ý để sắp xếp
                            return 0;
                        }).FirstOrDefault().RequestNo;
                    }
                    if (type.Contains("IH"))
                    {
                        rq_no2 = context.LtFormRegistrationIhItems.Where(x => x.RequestNo.StartsWith(prefix)).ToList().OrderByDescending(x =>
                        {
                            string numberString = x.RequestNo.Contains("-") ? x.RequestNo.Substring(x.RequestNo.LastIndexOf("-") + 1) : x.RequestNo;
                            if (int.TryParse(numberString, out int number))
                            {
                                return number;
                            }
                            // Xử lý trường hợp không thể chuyển đổi thành số nguyên
                            // Trả về một giá trị mặc định hoặc giá trị tùy ý để sắp xếp
                            return 0;
                        }).FirstOrDefault().RequestNo;
                    }
                }
                catch
                {
                    rq_no2 = rq_no1;
                }
                int stt = Convert.ToInt32(rq_no2.Split("-").Last());
                string strStt = (stt + 1).ToString();
                return prefix + "-" + strStt;
            }
            catch (Exception)
            {
                return prefix + "-01";
            }
        }

        private bool SendMailForward(string approver, string forwarder,string sender, List<string> lstReceive,string request_no)
        {
            try
            {
                string txtContent = "<span> Dear Mrs/Mr.</span><span style = 'font-weight: bold;'>" + approver+",</span><br><br>" +
                "<span>Your request need approve/confirm was forward for </span>: <span style = 'font-weight: bold;'>" + forwarder + "  </span><br>" +
                "<span>Forward by</span>: <span style = 'font-weight: bold;'>" + sender + "</span><br>" +
                "<span>Forward date</span>: <span style = 'font-weight: bold;'>" + DateTime.Now.ToString("dd-MMM-yyyy") + "</span><br>" +
                "<span>Request_no: " + request_no + "</span><br><br>" +
                "";


                email.Initial(lstReceive,
                    "[PSI-System] Change approve request",
                    txtContent);
                return false;
            }
            catch
            {
                return false;
            }
        }
        #endregion
    }
    public class MaxPPCellRequest
    {
        public Guid? Id { get; set; }
        public string? Model { get; set; }
        public string? Cell { get; set; }
        public double? Value { get; set; }
    }

}
