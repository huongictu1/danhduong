﻿using AutoMapper;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Newtonsoft.Json;
using PDCProjectApi.Common;
using PDCProjectApi.Common.Interface;
using PDCProjectApi.Data;
using PDCProjectApi.Helper;
using PDCProjectApi.Model.Request;
using PDCProjectApi.Model.Response;
using PDCProjectApi.Model.View;
using System.Net;
using System.Security.Claims;
using PDCProjectApi.Common.Job;
using System.Diagnostics;
using AutoMapper.QueryableExtensions;
using PDCProjectApi.Services;
using PDCProjectApi.BaseClasses;
using System.Linq;
using DocumentFormat.OpenXml.Drawing.Charts;
using System.Text.RegularExpressions;

namespace PDCProjectApi.Controllers
{
    [Route("api/todoutput")]
    [ApiController]
    [Authorize]
    //[ApiExplorerSettings(IgnoreApi = true)]
    public class TodOutputController : ControllerBaseAPI, IDisposable
    {
        [Obsolete]
        private readonly Microsoft.AspNetCore.Hosting.IHostingEnvironment _hostingEnvironment;
        private readonly IHttpContextAccessor httpContextAccessor;
        private readonly IFileStorageService fileStorageService;
        private readonly PdcsystemContext context;
        private readonly IEmailService email;
        private readonly IGlobalVariable global;
        private string outputPathOri = "";
        private List<string> lstPDCMail = new List<string>();
        private List<string> lstITMail = new List<string>();
        [Obsolete]
        public TodOutputController(Microsoft.AspNetCore.Hosting.IHostingEnvironment hosting, PdcsystemContext ctx,
            IHttpContextAccessor httpContextAccessor, IFileStorageService fileService,
            IConfiguration configuration, IEmailService mail, IGlobalVariable gl)
        {
            this._hostingEnvironment = hosting;
            this.httpContextAccessor = httpContextAccessor;
            this.context = ctx;
            this.fileStorageService = fileService;
            this.email = mail;
            this.global = gl;
            this.outputPathOri = this.global.ReturnPathOutput();
            this.lstITMail = this.global.ReturnITMail();
            this.lstPDCMail = this.global.ReturnPDCMail();
        }
        private bool disposed = false;
        protected virtual void Dispose(bool disposing)
        {
            if (!disposed)
            {
                if (disposing)
                {
                    if (context != null)
                    {
                        context.DisposeAsync();
                    }
                   
                }
                disposed = true;
            }
        }
        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }
        ~TodOutputController() { Dispose(false); }
        #region master upload
        [HttpPost("filter-tod-output-other-plan")]
        public async Task<TodOtherPlanModel> FilterOtherPlan(TodOtherPlanParam parameters)
        {
            try
            {

                TodOtherPlanModel result = new TodOtherPlanModel()
                {
                    currentPage = parameters.Page,
                    recordPerPage = parameters.RecordsPerPage
                };
                DateOnly? effectiveDate = parameters.EffectiveDate.StringToDateAble();
                DateOnly? clearDate = parameters.ClearDate.StringToDateAble();

                var query = context.TodTodUploadOtherPlans.Where(x => x.Active == true);
                query = !string.IsNullOrEmpty(parameters.Vendor) ? query.Where(x => x.Vendor != null && x.Vendor.ToUpper().Contains(parameters.Vendor.ToUpper())) : query;
                query = !string.IsNullOrEmpty(parameters.PartNo) ? query.Where(x => x.PartNo != null && x.PartNo.ToUpper().Contains(parameters.PartNo.ToUpper())) : query;
                query = parameters.EffectiveDate != null ? query.Where(x => x.EffectiveDate != null && x.EffectiveDate == effectiveDate) : query;
                query = parameters.ClearDate != null ? query.Where(x => x.ClearDate != null && x.ClearDate == clearDate) : query;

                result.totalRecords = await query.CountAsync();
                result.totalPage = (int)Math.Ceiling((decimal)result.totalRecords / parameters.RecordsPerPage);
                var model = await query.OrderByDescending(x => x.CreatedDate).Paginate(parameters).ToListAsync();
                result.lstModel = model;
                result.fromRecord = model.Count == 0 ? 0 : (result.currentPage - 1) * result.recordPerPage + 1;
                result.toRecord = (int)Math.Min(result.totalRecords, result.currentPage * result.recordPerPage);
                result.currentPage = result.totalPage < result.currentPage ? result.totalPage : result.currentPage;
                return result;
            }
            catch (Exception e)
            {
                //SendMailError(e);
                return new TodOtherPlanModel()
                {
                    currentPage = parameters.Page,
                    recordPerPage = parameters.RecordsPerPage
                };
            }
        }

        [HttpPost("filter-tod-output-pp-change")]
        public async Task<TodPPChangeModel> FilterPPChange(TodPPChangeParam parameters)
        {
            try
            {

                TodPPChangeModel result = new TodPPChangeModel()
                {
                    currentPage = parameters.Page,
                    recordPerPage = parameters.RecordsPerPage
                };
                DateOnly? dateChange = parameters.DateChange.StringToDateAble();


                var query = context.TodTodUploadPpChanges.Where(x => x.Active == true);
                query = !string.IsNullOrEmpty(parameters.Model) ? query.Where(x => x.Model != null && x.Model.ToUpper().Contains(parameters.Model.ToUpper())) : query;
                query = !string.IsNullOrEmpty(parameters.Merchandise) ? query.Where(x => x.MerchandiseCode != null && x.MerchandiseCode.ToUpper().Contains(parameters.Merchandise.ToUpper())) : query;
                query = parameters.DateChange != null ? query.Where(x => x.DateChange != null && x.DateChange == dateChange) : query;

                result.totalRecords = await query.CountAsync();
                result.totalPage = (int)Math.Ceiling((decimal)result.totalRecords / parameters.RecordsPerPage);
                var model = await query.OrderByDescending(x => x.CreatedDate).Paginate(parameters).ToListAsync();
                result.lstModel = model;
                result.fromRecord = model.Count == 0 ? 0 : (result.currentPage - 1) * result.recordPerPage + 1;
                result.toRecord = (int)Math.Min(result.totalRecords, result.currentPage * result.recordPerPage);
                result.currentPage = result.totalPage < result.currentPage ? result.totalPage : result.currentPage;
                return result;
            }
            catch (Exception e)
            {
                //SendMailError(e);
                return new TodPPChangeModel()
                {
                    currentPage = parameters.Page,
                    recordPerPage = parameters.RecordsPerPage
                };
            }
        }

        [HttpPost("filter-tod-upload-cont-schedule")]
        public async Task<TodUploadContScheduleModel> FilterContSchedule(TodContScheduleParam parameters)
        {
            try
            {

                TodUploadContScheduleModel result = new TodUploadContScheduleModel()
                {
                    currentPage = parameters.Page,
                    recordPerPage = parameters.RecordsPerPage
                };

                var query = context.TodTodUploadContSchedules.Where(x => x.Active == true);
                query = !string.IsNullOrEmpty(parameters.Vendor) ? query.Where(x => x.Vendor != null && x.Vendor.ToUpper().Contains(parameters.Vendor.ToUpper())) : query;
                query = !string.IsNullOrEmpty(parameters.ContainerNo) ? query.Where(x => x.ContainerNo != null && x.ContainerNo.ToUpper().Contains(parameters.ContainerNo.ToUpper())) : query;
                query = !string.IsNullOrEmpty(parameters.InvoiceNo) ? query.Where(x => x.InvoiceNo != null && x.InvoiceNo.ToUpper().Contains(parameters.InvoiceNo.ToUpper())) : query;
                query = !string.IsNullOrEmpty(parameters.Location) ? query.Where(x => x.Location != null && x.Location.ToUpper().Contains(parameters.Location.ToUpper())) : query;

                result.totalRecords = await query.CountAsync();
                result.totalPage = (int)Math.Ceiling((decimal)result.totalRecords / parameters.RecordsPerPage);
                var model = await query.OrderByDescending(x => x.CreatedDate).Paginate(parameters).ToListAsync();
                result.lstModel = model;
                result.fromRecord = model.Count == 0 ? 0 : (result.currentPage - 1) * result.recordPerPage + 1;
                result.toRecord = (int)Math.Min(result.totalRecords, result.currentPage * result.recordPerPage);
                result.currentPage = result.totalPage < result.currentPage ? result.totalPage : result.currentPage;
                return result;
            }
            catch (Exception e)
            {
                //SendMailError(e);
                return new TodUploadContScheduleModel()
                {
                    currentPage = parameters.Page,
                    recordPerPage = parameters.RecordsPerPage
                };
            }
        }
        [HttpPost("filter-tod-upload-po-change-del")]
        public async Task<TodUploadPoChangeDelModel> FilterPoChangeDel(TodPoChangeDelParam parameters)
        {
            try
            {

                TodUploadPoChangeDelModel result = new TodUploadPoChangeDelModel()
                {
                    currentPage = parameters.Page,
                    recordPerPage = parameters.RecordsPerPage
                };

                var query = context.TodTodUploadPoChangeDels.Where(x => x.Active == true);
                query = !string.IsNullOrEmpty(parameters.PartNo) ? query.Where(x => x.PartNo != null && x.PartNo.ToUpper().Contains(parameters.PartNo.ToUpper())) : query;
                query = !string.IsNullOrEmpty(parameters.Bc) ? query.Where(x => x.Bc != null && x.Bc.ToUpper().Contains(parameters.Bc.ToUpper())) : query;

                result.totalRecords = await query.CountAsync();
                result.totalPage = (int)Math.Ceiling((decimal)result.totalRecords / parameters.RecordsPerPage);
                var model = await query.OrderByDescending(x => x.CreatedDate).Paginate(parameters).ToListAsync();
                result.lstModel = model;
                result.fromRecord = model.Count == 0 ? 0 : (result.currentPage - 1) * result.recordPerPage + 1;
                result.toRecord = (int)Math.Min(result.totalRecords, result.currentPage * result.recordPerPage);
                result.currentPage = result.totalPage < result.currentPage ? result.totalPage : result.currentPage;
                return result;
            }
            catch (Exception e)
            {
                //SendMailError(e);
                return new TodUploadPoChangeDelModel()
                {
                    currentPage = parameters.Page,
                    recordPerPage = parameters.RecordsPerPage
                };
            }
        }
        [HttpPost("filter-tod-upload-lt-revise-po")]
        public async Task<TodUploadLtRevisePoModel> FilterLtRevisePo(TodLtRevisePoParam parameters)
        {
            try
            {

                TodUploadLtRevisePoModel result = new TodUploadLtRevisePoModel()
                {
                    currentPage = parameters.Page,
                    recordPerPage = parameters.RecordsPerPage
                };

                var query = context.TodTodUploadLtRevisePos.Where(x => x.Active == true);
                query = !string.IsNullOrEmpty(parameters.PartNo) ? query.Where(x => x.PartNo != null && x.PartNo.ToUpper().Contains(parameters.PartNo.ToUpper())) : query;
                query = !string.IsNullOrEmpty(parameters.Vendor) ? query.Where(x => x.Vendor != null && x.Vendor.ToUpper().Contains(parameters.Vendor.ToUpper())) : query;

                result.totalRecords = await query.CountAsync();
                result.totalPage = (int)Math.Ceiling((decimal)result.totalRecords / parameters.RecordsPerPage);
                var model = await query.OrderByDescending(x => x.CreatedDate).Paginate(parameters).ToListAsync();
                result.lstModel = model;
                result.fromRecord = model.Count == 0 ? 0 : (result.currentPage - 1) * result.recordPerPage + 1;
                result.toRecord = (int)Math.Min(result.totalRecords, result.currentPage * result.recordPerPage);
                result.currentPage = result.totalPage < result.currentPage ? result.totalPage : result.currentPage;
                return result;
            }
            catch (Exception e)
            {
                //SendMailError(e);
                return new TodUploadLtRevisePoModel()
                {
                    currentPage = parameters.Page,
                    recordPerPage = parameters.RecordsPerPage
                };
            }
        }
        [HttpPost("add-tod-pp-change")]
        public async Task<CommonResponse> AddPPChange(TodPPChangeParam parameters)
        {
            CommonResponse res = new CommonResponse()
            {
                Error = false,
                Message = "",
                Status = (int)HttpStatusCode.BadRequest
            };
            try
            {
                DateOnly dateChange = (DateOnly)parameters.DateChange.StringToDateAble();
                var add = new TodTodUploadPpChange()
                {
                    MerchandiseCode = parameters.Merchandise,
                    Model = parameters.Model,
                    QtyChange = (int)parameters.QtyChange.StringToIntAble(),
                    ReasonChange = parameters.Reason,
                    DateChange = dateChange
                };
                context.Add(add);
                await context.SaveChangesAsync();

                res.Error = false;
                res.Message = "Successfully !";
                res.Status = (int)HttpStatusCode.OK;
                return res;
            }
            catch (Exception e)
            {
                res.Error = true;
                res.Message = e.Message;
                res.Status = (int)HttpStatusCode.BadRequest;
                //SendMailError(e);
                return res;
            }
        }

        [HttpGet("active-tod-pp-change/{id}")]
        public async Task<CommonResponse> ActivePPChange(Guid id)
        {
            CommonResponse res = new CommonResponse()
            {
                Error = false,
                Message = "",
                Status = (int)HttpStatusCode.BadRequest
            };
            try
            {
                var model = context.TodTodUploadPpChanges.First(x => x.Id == id);
                model.Active = false;
                context.Update(model);
                await context.SaveChangesAsync();

                res.Error = false;
                res.Message = "Successfully !";
                res.Status = (int)HttpStatusCode.OK;
                return res;
            }
            catch (Exception e)
            {
                res.Error = true;
                res.Message = e.Message;
                res.Status = (int)HttpStatusCode.BadRequest;
                //SendMailError(e);
                return res;
            }
        }
        #endregion

        #region approve upload
        [HttpGet("approve-other-plan")]
        public async Task<CommonResponse> ApproveOyherPlan()
        {
            CommonResponse res = new CommonResponse()
            {
                Error = false,
                Message = "",
                Status = (int)HttpStatusCode.BadRequest
            };
            try
            {
                //if (HangfireJobList.PreventUpload())
                //{
                //    res.Error = true;
                //    res.Message = "Other jobs processing";
                //    res.Status = 400;
                //    return res;
                //}
                var u = GetCurrentUser();
                var check = context.TodTodUploadOtherPlans
                         .Any(x => x.Active == true && x.ApprovedDate == null);
                //những con approved trc đó thì bỏ hết, vì mình lấy cái mới mà
                if (check == true)
                {
                    var modelOld = await context.TodTodUploadOtherPlans
                            .Where(x => x.Active == true && x.ApprovedDate != null && x.ApprovedBy != null)
                            .ToListAsync();
                    modelOld.ForEach(x =>
                    {
                        x.Active = false;
                    });
                    context.UpdateRange(modelOld);
                    context.SaveChanges();

                    //và approve cho những con mới
                    var model = await context.TodTodUploadOtherPlans
                            .Where(x => x.Active == true && x.ApprovedDate == null)
                            .ToListAsync();
                    model.ForEach(x =>
                    {
                        x.ApprovedBy = u.UserName;
                        x.ApprovedDate = DateTime.Now;
                        var old = modelOld.Where(y => y.Vendor == x.Vendor).FirstOrDefault();
                        if(old != null)
                        {
                            if(old.TransferQty != x.TransferQty || old.EffectiveDate != x.EffectiveDate || old.ClearDate != x.ClearDate)
                            {
                                x.IsChange = true;
                            }
                        }
                        else
                        {
                            x.IsChange = true;
                        }
                    });
                    context.UpdateRange(model);
                    context.SaveChanges();
                }
                else
                {
                    //và approve cho những con mới
                    var model = await context.TodTodUploadOtherPlans
                            .Where(x => x.Active == true && x.ApprovedDate == null)
                            .ToListAsync();
                    model.ForEach(x =>
                    {
                        x.ApprovedBy = u.UserName;
                        x.ApprovedDate = DateTime.Now;
                        x.IsChange = true;
                    });
                    context.UpdateRange(model);
                    context.SaveChanges();
                }

                res.Error = false;
                res.Message = "Successfully !";
                res.Status = (int)HttpStatusCode.OK;
                return res;
            }
            catch (Exception e)
            {
                res.Error = true;
                res.Message = e.Message;
                res.Status = (int)HttpStatusCode.BadRequest;
                //SendMailError(e);
                return res;
            }


        }
        [HttpGet("approve-pp-change")]
        public async Task<CommonResponse> ApprovePPChange()
        {
            CommonResponse res = new CommonResponse()
            {
                Error = false,
                Message = "",
                Status = (int)HttpStatusCode.BadRequest
            };
            try
            {
               
                var u = GetCurrentUser();
                var model = context.TodTodUploadPpChanges
                         .Where(x => x.Active == true ).ToList();
                var checkModel = model.Where(x => x.ApprovedDate == null).ToList();
                
                foreach(var item in checkModel)
                {
                    //bỏ những con tồn tại
                    var checkExists = model.Where(x => x.MerchandiseCode == item.MerchandiseCode && x.Model == item.Model
                    && x.QtyChange == item.QtyChange && x.DateChange == item.DateChange && x.Id != item.Id).ToList();
                    checkExists.ForEach(x => x.Active = false);
                    context.UpdateRange(checkExists);

                    item.ApprovedBy = u.UserName;
                    item.ApprovedDate = DateTime.Now;
                    context.Update(item);
                }
                context.SaveChanges();
                //những con approved trc đó thì bỏ hết, vì mình lấy cái mới mà
                //if (check == true)
                //{
                //    var modelOld = await context.TodTodUploadPpChanges
                //            .Where(x => x.Active == true && x.ApprovedDate != null && x.ApprovedBy != null)
                //            .ToListAsync();
                //    modelOld.ForEach(x =>
                //    {
                //        x.Active = false;
                //    });
                //    context.UpdateRange(modelOld);
                //    context.SaveChanges();

                //    //và approve cho những con mới
                //    var model = await context.TodTodUploadPpChanges
                //            .Where(x => x.Active == true && x.ApprovedDate == null)
                //            .ToListAsync();
                //    model.ForEach(x =>
                //    {
                //        x.ApprovedBy = u.UserName;
                //        x.ApprovedDate = DateTime.Now;
                //        var old = modelOld.Where(y => y.MerchandiseCode == x.MerchandiseCode && y.Model == x.Model).FirstOrDefault();
                //        if (old != null)
                //        {
                //            if (old.QtyChange != x.QtyChange || old.DateChange != x.DateChange)
                //            {
                //                x.IsChange = true;//xem thằng nào thay đổi để chạy part control đúng thằng đó thôi
                //            }
                //        }
                //        else
                //        {
                //            x.IsChange = true;
                //        }
                //    });
                //    context.UpdateRange(model);
                //    context.SaveChanges();
                //}
                //else
                //{
                //    //và approve cho những con mới
                //    var model = await context.TodTodUploadPpChanges
                //            .Where(x => x.Active == true && x.ApprovedDate == null)
                //            .ToListAsync();
                //    model.ForEach(x =>
                //    {
                //        x.ApprovedBy = u.UserName;
                //        x.ApprovedDate = DateTime.Now;
                //        x.IsChange = true;
                //    });
                //    context.UpdateRange(model);
                //    context.SaveChanges();
                //}


                res.Error = false;
                res.Message = "Successfully !";
                res.Status = (int)HttpStatusCode.OK;
                return res;
            }
            catch (Exception e)
            {
                res.Error = true;
                res.Message = e.Message;
                res.Status = (int)HttpStatusCode.BadRequest;
                //SendMailError(e);
                return res;
            }


        }
        [HttpGet("approve-cont-schedule")]
        public async Task<CommonResponse> ApproveContSchedule()
        {
            CommonResponse res = new CommonResponse()
            {
                Error = false,
                Message = "",
                Status = (int)HttpStatusCode.BadRequest
            };
            try
            {
                //if (HangfireJobList.PreventUpload())
                //{
                //    res.Error = true;
                //    res.Message = "Other jobs processing";
                //    res.Status = 400;
                //    return res;
                //}
                var u = GetCurrentUser();
                var check = context.TodTodUploadContSchedules
                         .Any(x => x.Active == true && x.ApprovedDate == null);
                //những con approved trc đó thì bỏ hết, vì mình lấy cái mới mà
                if (check == true)
                {
                    var modelOld = await context.TodTodUploadContSchedules
                            .Where(x => x.Active == true && x.ApprovedDate != null && x.ApprovedBy != null)
                            .ToListAsync();
                    modelOld.ForEach(x =>
                    {
                        x.Active = false;
                    });
                    context.UpdateRange(modelOld);
                    context.SaveChanges();

                    //và approve cho những con mới
                    var model = await context.TodTodUploadContSchedules
                            .Where(x => x.Active == true && x.ApprovedDate == null)
                            .ToListAsync();
                    model.ForEach(x =>
                    {
                        x.ApprovedBy = u.UserName;
                        x.ApprovedDate = DateTime.Now;
                        var old = modelOld.Where(y => y.Vendor == x.Vendor).FirstOrDefault();
                        if (old != null)
                        {
                            if (old.EtaCvn != x.EtaCvn || old.EtaHp != x.EtaHp)
                            {
                                x.IsChange = true;//xem thằng nào thay đổi để chạy part control đúng thằng đó thôi
                            }
                        }
                        else
                        {
                            x.IsChange = true;
                        }
                    });
                    context.UpdateRange(model);
                    context.SaveChanges();
                }
                else
                {
                    //và approve cho những con mới
                    var model = await context.TodTodUploadContSchedules
                            .Where(x => x.Active == true && x.ApprovedDate == null)
                            .ToListAsync();
                    model.ForEach(x =>
                    {
                        x.ApprovedBy = u.UserName;
                        x.ApprovedDate = DateTime.Now;
                        x.IsChange = true;
                    });
                    context.UpdateRange(model);
                    context.SaveChanges();
                }



                res.Error = false;
                res.Message = "Successfully !";
                res.Status = (int)HttpStatusCode.OK;
                return res;
            }
            catch (Exception e)
            {
                res.Error = true;
                res.Message = e.Message;
                res.Status = (int)HttpStatusCode.BadRequest;
                //SendMailError(e);
                return res;
            }


        }
        [HttpGet("approve-po-change-del")]
        public async Task<CommonResponse> ApprovePoChangeDel()
        {
            CommonResponse res = new CommonResponse()
            {
                Error = false,
                Message = "",
                Status = (int)HttpStatusCode.BadRequest
            };
            try
            {
                //if (HangfireJobList.PreventUpload())
                //{
                //    res.Error = true;
                //    res.Message = "Other jobs processing";
                //    res.Status = 400;
                //    return res;
                //}
                var u = GetCurrentUser();
                var check = context.TodTodUploadPoChangeDels
                         .Any(x => x.Active == true && x.ApprovedDate == null);
                //những con approved trc đó thì bỏ hết, vì mình lấy cái mới mà
                if (check == true)
                {
                    var modelOld = await context.TodTodUploadPoChangeDels
                            .Where(x => x.Active == true && x.ApprovedDate != null && x.ApprovedBy != null)
                            .ToListAsync();
                    modelOld.ForEach(x =>
                    {
                        x.Active = false;
                    });
                    context.UpdateRange(modelOld);
                    context.SaveChanges();

                    //và approve cho những con mới
                    var model = await context.TodTodUploadPoChangeDels
                            .Where(x => x.Active == true && x.ApprovedDate == null)
                            .ToListAsync();
                    model.ForEach(x =>
                    {
                        x.ApprovedBy = u.UserName;
                        x.ApprovedDate = DateTime.Now;
                        var old = modelOld.Where(y => y.PartNo == x.PartNo && y.Bc == x.Bc && y.OriDate == x.OriDate && y.AdjDate == x.AdjDate).FirstOrDefault();
                        if (old != null)
                        {
                            if (old.OriQty != x.OriQty || old.AdjQty != x.AdjQty)
                            {
                                x.IsChange = true;//xem thằng nào thay đổi để chạy part control đúng thằng đó thôi
                            }
                        }
                        else
                        {
                            x.IsChange = true;
                        }
                    });
                    context.UpdateRange(model);
                    context.SaveChanges();
                }
                else
                {
                    //và approve cho những con mới
                    var model = await context.TodTodUploadPoChangeDels
                            .Where(x => x.Active == true && x.ApprovedDate == null)
                            .ToListAsync();
                    model.ForEach(x =>
                    {
                        x.ApprovedBy = u.UserName;
                        x.ApprovedDate = DateTime.Now;
                        x.IsChange = true;
                    });
                    context.UpdateRange(model);
                    context.SaveChanges();
                }
                


                res.Error = false;
                res.Message = "Successfully !";
                res.Status = (int)HttpStatusCode.OK;
                return res;
            }
            catch (Exception e)
            {
                res.Error = true;
                res.Message = e.Message;
                res.Status = (int)HttpStatusCode.BadRequest;
                //SendMailError(e);
                return res;
            }


        }
        [HttpGet("approve-leadtime-revise")]
        public async Task<CommonResponse> ApproveLeadtimeRevise()
        {
            CommonResponse res = new CommonResponse()
            {
                Error = false,
                Message = "",
                Status = (int)HttpStatusCode.BadRequest
            };
            try
            {
                //if (HangfireJobList.PreventUpload())
                //{
                //    res.Error = true;
                //    res.Message = "Other jobs processing";
                //    res.Status = 400;
                //    return res;
                //}
                var u = GetCurrentUser();
                var check = context.TodTodUploadLtRevisePos
                         .Any(x => x.Active == true && x.ApprovedDate == null);
                //những con approved trc đó thì bỏ hết, vì mình lấy cái mới mà
                if (check == true)
                {
                    var modelOld = await context.TodTodUploadLtRevisePos
                            .Where(x => x.Active == true && x.ApprovedDate != null && x.ApprovedBy != null)
                            .ToListAsync();
                    modelOld.ForEach(x =>
                    {
                        x.Active = false;
                    });
                    context.UpdateRange(modelOld);
                    context.SaveChanges();

                    var model = await context.TodTodUploadLtRevisePos
                            .Where(x => x.Active == true && x.ApprovedDate == null)
                            .ToListAsync();
                    model.ForEach(x =>
                    {
                        x.ApprovedBy = u.UserName;
                        x.ApprovedDate = DateTime.Now;
                        var old = modelOld.Where(y => y.PartNo == x.PartNo && y.Vendor == x.Vendor).FirstOrDefault();
                        if (old != null)
                        {
                            if (old.LtPull != x.LtPull || old.LtPush != x.LtPush)
                            {
                                x.IsChange = true;//xem thằng nào thay đổi để chạy part control đúng thằng đó thôi
                            }
                        }
                        else
                        {
                            x.IsChange = true;
                        } 
                    });
                    context.UpdateRange(model);
                    context.SaveChanges();
                }
                else
                {
                    //và approve cho những con mới
                    var model = await context.TodTodUploadLtRevisePos
                            .Where(x => x.Active == true && x.ApprovedDate == null)
                            .ToListAsync();
                    model.ForEach(x =>
                    {
                        x.ApprovedBy = u.UserName;
                        x.ApprovedDate = DateTime.Now;
                        x.IsChange = true;
                    });
                    context.UpdateRange(model);
                    context.SaveChanges();
                }
                res.Error = false;
                res.Message = "Successfully !";
                res.Status = (int)HttpStatusCode.OK;
                return res;
            }
            catch (Exception e)
            {
                res.Error = true;
                res.Message = e.Message;
                res.Status = (int)HttpStatusCode.BadRequest;
                //SendMailError(e);
                return res;
            }


        }

        [HttpGet("reject-other-plan")]
        public async Task<CommonResponse> RejectOtherPlan()
        {
            CommonResponse res = new CommonResponse()
            {
                Error = false,
                Message = "",
                Status = (int)HttpStatusCode.BadRequest
            };
            try
            {

                var u = GetCurrentUser();

                var modelOld = await context.TodTodUploadOtherPlans
                        .Where(x => x.Active == true && x.ApprovedDate == null)
                        .ToListAsync();
                modelOld.ForEach(x =>
                {
                    x.Active = false;
                    x.ApprovedBy = u.UserName;
                    x.ApprovedDate = DateTime.Now;
                });
                context.UpdateRange(modelOld);
                context.SaveChanges();


                res.Error = false;
                res.Message = "Successfully !";
                res.Status = (int)HttpStatusCode.OK;
                return res;
            }
            catch (Exception e)
            {
                res.Error = true;
                res.Message = e.Message;
                res.Status = (int)HttpStatusCode.BadRequest;
                //SendMailError(e);
                return res;
            }


        }
        [HttpGet("reject-pp-change")]
        public async Task<CommonResponse> RejectPPChange()
        {
            CommonResponse res = new CommonResponse()
            {
                Error = false,
                Message = "",
                Status = (int)HttpStatusCode.BadRequest
            };
            try
            {

                var u = GetCurrentUser();
                var model = context.TodTodUploadPpChanges
                         .Where(x => x.Active == true && x.ApprovedDate == null).ToList();
                model.ForEach(x =>
                {
                    x.Active = false;
                    x.ApprovedBy = u.UserName;
                    x.ApprovedDate = DateTime.Now;
                });
                context.UpdateRange(model);
                context.SaveChanges();

                res.Error = false;
                res.Message = "Successfully !";
                res.Status = (int)HttpStatusCode.OK;
                return res;
            }
            catch (Exception e)
            {
                res.Error = true;
                res.Message = e.Message;
                res.Status = (int)HttpStatusCode.BadRequest;
                //SendMailError(e);
                return res;
            }


        }
        [HttpGet("reject-cont-schedule")]
        public async Task<CommonResponse> RejectContSchedule()
        {
            CommonResponse res = new CommonResponse()
            {
                Error = false,
                Message = "",
                Status = (int)HttpStatusCode.BadRequest
            };
            try
            {
                var u = GetCurrentUser();
                var modelOld = await context.TodTodUploadContSchedules
                            .Where(x => x.Active == true && x.ApprovedDate == null)
                            .ToListAsync();
                    modelOld.ForEach(x =>
                    {
                        x.ApprovedBy = u.UserName;
                        x.ApprovedDate = DateTime.Now;
                        x.Active = false;
                    });
                    context.UpdateRange(modelOld);
                    context.SaveChanges();

                  



                res.Error = false;
                res.Message = "Successfully !";
                res.Status = (int)HttpStatusCode.OK;
                return res;
            }
            catch (Exception e)
            {
                res.Error = true;
                res.Message = e.Message;
                res.Status = (int)HttpStatusCode.BadRequest;
                //SendMailError(e);
                return res;
            }


        }
        [HttpGet("reject-po-change-del")]
        public async Task<CommonResponse> RejectPoChangeDel()
        {
            CommonResponse res = new CommonResponse()
            {
                Error = false,
                Message = "",
                Status = (int)HttpStatusCode.BadRequest
            };
            try
            {
              
                var u = GetCurrentUser();
              
                    var modelOld = await context.TodTodUploadPoChangeDels
                            .Where(x => x.Active == true && x.ApprovedDate == null)
                            .ToListAsync();
                    modelOld.ForEach(x =>
                    {
                        x.ApprovedBy = u.UserName;
                        x.ApprovedDate = DateTime.Now;
                        x.Active = false;
                    });
                    context.UpdateRange(modelOld);
                    context.SaveChanges();

                   

                res.Error = false;
                res.Message = "Successfully !";
                res.Status = (int)HttpStatusCode.OK;
                return res;
            }
            catch (Exception e)
            {
                res.Error = true;
                res.Message = e.Message;
                res.Status = (int)HttpStatusCode.BadRequest;
                //SendMailError(e);
                return res;
            }


        }
        [HttpGet("reject-leadtime-revise")]
        public async Task<CommonResponse> RejectLeadtimeRevise()
        {
            CommonResponse res = new CommonResponse()
            {
                Error = false,
                Message = "",
                Status = (int)HttpStatusCode.BadRequest
            };
            try
            {
                var u = GetCurrentUser();
                var modelOld = await context.TodTodUploadLtRevisePos
                            .Where(x => x.Active == true && x.ApprovedDate == null)
                            .ToListAsync();
                    modelOld.ForEach(x =>
                    {
                        x.Active = false;
                        x.ApprovedBy = u.UserName;
                        x.ApprovedDate = DateTime.Now;
                    });
                    context.UpdateRange(modelOld);
                    context.SaveChanges();

                  
                res.Error = false;
                res.Message = "Successfully !";
                res.Status = (int)HttpStatusCode.OK;
                return res;
            }
            catch (Exception e)
            {
                res.Error = true;
                res.Message = e.Message;
                res.Status = (int)HttpStatusCode.BadRequest;
                //SendMailError(e);
                return res;
            }


        }
        [HttpGet("run-part-control")]
        public async Task<CommonResponse> RunOutputPartcontrol(string product)
        {
            CommonResponse res = new CommonResponse()
            {
                Error = false,
                Message = "",
                Status = (int)HttpStatusCode.BadRequest
            };
            try
            {
                var u = GetCurrentUser();
                if (HangfireJobList.PreventUpload())
                {
                    res.Error = true;
                    res.Message = "Other jobs processing";
                    res.Status = 400;
                    return res;
                }
                await Task.WhenAll(ManualFunc.GatewayAsync("CalculateAction/Tod/" + product.ToUpper()));
                res.Error = false;
                res.Message = "Successfully ! Waiting mail notice";
                res.Status = (int)HttpStatusCode.OK;
                email.Initial(new List<string>() { u.Email }, "[PSI-System] Run-again part control " + product, @"<p style='font-weight: bold;'>Dear [Mrs/Mr]. All,</p>
<p>You have received a notification about <span style='font-weight: bold; color: red; font-style: italic;'>you have done the recalculation of the part control output </span>. Please wait then check.</p>
<p>If you encounter any difficulties or need further assistance, please don't hesitate to contact our support team at it-app28@local.canon-vn.com.vn, it-app26@local.canon-vn.com.vn</p>
<p>Thank you for using PDCS.</p>
<p style='font-weight: bold;'>Best regards,</p>
<p style='font-weight: bold;'>(6615) 8702<br />
System Support Team</p>
<p style='font-style: italic;'>This email is automatically sent by PDCS system, please do not reply!</p>");
                return res;
            }
            catch (Exception e)
            {
                res.Error = true;
                res.Message = e.Message;
                res.Status = (int)HttpStatusCode.BadRequest;
                //SendMailError(e);
                return res;
            }


        }
        [HttpGet("export-part-control")]
        public async Task<CommonResponse> ExportOutputPartcontrol(string product)
        {
            CommonResponse res = new CommonResponse()
            {
                Error = false,
                Message = "",
                Status = (int)HttpStatusCode.BadRequest
            };
            try
            {
                //if (HangfireJobList.PreventUpload())
                //{
                //    res.Error = true;
                //    res.Message = "Other jobs processing";
                //    res.Status = 400;
                //    return res;
                //}
                product = product.ToUpper();
                await Task.WhenAll(ManualFunc.GatewayAsync("UserExportAction/Tod/"+ product + "/1"), ManualFunc.GatewayAsync("UserExportAction/Tod/"+ product + "/2"), ManualFunc.GatewayAsync("UserExportAction/Tod/"+ product + "/4"));
                res.Error = false;
                res.Message = "Successfully ! Waiting mail notice";
                res.Status = (int)HttpStatusCode.OK;
                return res;
            }
            catch (Exception e)
            {
                res.Error = true;
                res.Message = e.Message;
                res.Status = (int)HttpStatusCode.BadRequest;
                //SendMailError(e);
                return res;
            }


        }
        #endregion

        #region output
        [HttpPost("filter-tod-output0")]
        public async Task<TodOutput0Model> FilterOutputO(TodOutput0Param parameters)
        {
            try
            {

                var config = new MapperConfiguration(cfg => cfg.CreateMap<TodTodOutputPartDemandCpLbp, TodTodOutputPartDemandCpIj>());
                var mapper = config.CreateMapper();
                TodOutput0Model result = new TodOutput0Model()
                {
                    currentPage = parameters.Page,
                    recordPerPage = parameters.RecordsPerPage
                };
                IQueryable<TodTodOutputPartDemandCpIj> query;
                if (parameters.Product.ToUpper() == "IJ")
                {
                    query = context.TodTodOutputPartDemandCpIjs.Where(x => x.Active == true);
                }
                else
                {
                    var outputLbp = context.TodTodOutputPartDemandCpLbps.Where(x => x.Active == true);
                    query = outputLbp.ProjectTo<TodTodOutputPartDemandCpIj>(mapper.ConfigurationProvider);
                }
                //if(LstBlockCode.Count > 0)
                //{
                //    query = query.Where(x => LstBlockCode.Contains(x.UserBy));
                //}
                query = !string.IsNullOrEmpty(parameters.Vendor) ? query.Where(x => x.UserBy != null && x.UserBy.ToUpper().Contains(parameters.Vendor.ToUpper())) : query;
                query = !string.IsNullOrEmpty(parameters.PartNo) ? query.Where(x => x.PartNo != null && x.PartNo.ToUpper().Contains(parameters.PartNo.ToUpper())) : query;
                query = !string.IsNullOrEmpty(parameters.BcUse) ? query.Where(x => x.Bc != null && x.Bc.ToUpper().Contains(parameters.BcUse.ToUpper())) : query;

                result.totalRecords = await query.CountAsync();
                result.totalPage = (int)Math.Ceiling((decimal)result.totalRecords / parameters.RecordsPerPage);
                var model = await query.OrderByDescending(x => x.CreatedDate).Paginate(parameters).ToListAsync();
                //var modelView = mapper.Map<List<TodFcdelOutputStockStdIj>, List<TodFcdelOutputStockStdIj>>(model);
                result.lstModel = model;
                result.fromRecord = model.Count == 0 ? 0 : (result.currentPage - 1) * result.recordPerPage + 1;
                result.toRecord = (int)Math.Min(result.totalRecords, result.currentPage * result.recordPerPage);
                result.currentPage = result.totalPage < result.currentPage ? result.totalPage : result.currentPage;
                return result;
            }
            catch (Exception e)
            {
                //SendMailError(e);
                return new TodOutput0Model()
                {
                    currentPage = parameters.Page,
                    recordPerPage = parameters.RecordsPerPage
                };
            }
        }

        [HttpPost("filter-tod-output1-new/{product}")]
        public async Task<TodOutput1NewModel> FilterOutput1New(TodOutput1Param parameters, string product)
        {
            try
            {

                var config = new MapperConfiguration(cfg => cfg.CreateMap<TodTodOutput1TotalLbp, TodTodOutput1TotalIj>());
                var mapper = config.CreateMapper();
                TodOutput1NewModel result = new TodOutput1NewModel()
                {
                    currentPage = parameters.Page,
                    recordPerPage = parameters.RecordsPerPage
                };

                //var lstPic = !string.IsNullOrEmpty(parameters.Pic) ?parameters.Pic.Split("_")[0]:"";
                IQueryable<TodTodOutput1TotalIj> query;
                if (product.ToUpper() == "IJ")
                {
                    query =  context.TodTodOutput1TotalIjs.Where(x => x.Active == true) ;
                }
                else
                {
                    var outputLbp = context.TodTodOutput1TotalLbps.Where(x => x.Active == true) ;
                    query = outputLbp.ProjectTo<TodTodOutput1TotalIj>(mapper.ConfigurationProvider);
                }
                //if (LstBlockCode.Count > 0)
                //{
                //    query = query.Where(x => x.Bc != null && LstBlockCode.Contains(x.Bc[0]));
                //}
                query = !string.IsNullOrEmpty(parameters.PartNo) ? query.Where(x => (x.PartNo != null && x.PartNo.ToUpper().Contains(parameters.PartNo.ToUpper())) 
                || (x.Alternative != null && x.Alternative.Contains(parameters.PartNo.ToUpper())) || (x.Pair != null && x.Pair.Contains(parameters.PartNo))) : query;//nếu tìm kiếm rơi vào alternative thì phải nhập full part no
                query = !string.IsNullOrEmpty(parameters.Destination) ? query.Where(x => x.Des != null && parameters.Destination.ToUpper().Contains(x.Des.ToUpper())) : query;
                query = !string.IsNullOrEmpty(parameters.Vendor) ? query.Where(x => x.Vendor != null && x.Vendor.Contains(parameters.Vendor)) : query;
                query = !string.IsNullOrEmpty(parameters.BcUse) ? query.Where(x => x.Bc != null && x.Bc.Contains(parameters.BcUse)) : query;
                query = !string.IsNullOrEmpty(parameters.Model) ? query.Where(x => x.Model != null && parameters.Model.ToUpper().Contains(x.Model.ToUpper())) : query;
                query = !string.IsNullOrEmpty(parameters.Pic) ? query.Where(x => x.Pic != null && x.Pic.Contains(parameters.Pic)) : query;

                //var lstData = await query.GroupBy(y => new { y.PartNo, y.Vendor, y.Bc }).ToListAsync();

                result.totalRecords = await query.CountAsync();
                result.totalPage = (int)Math.Ceiling((decimal)result.totalRecords / parameters.RecordsPerPage);
                var model = await query.OrderBy(x => x.Gap).ThenBy(x => x.CalcOrder).Paginate(parameters).ToListAsync();
                //List<TodTodOutput1TotalIjOld> lstModel = new List<TodTodOutput1TotalIjOld>();
                //foreach (var item in model)
                //{
                //    foreach (var i in item.OrderBy(x => x.CalcOrder))
                //    {
                //        lstModel.Add(i);
                //    }
                //}
                result.lstModel = model;
                //result.lstModel = lstModel.Select(x =>
                //{
                //    for (int i = 0; i < x.TodValue.Length; i++)
                //    {
                //        if (double.IsInfinity(x.TodValue[i]) || double.IsNaN(x.TodValue[i]))
                //        {
                //            x.TodValue[i] = 0;
                //        }
                //    }
                //    return x;
                //}).ToList();
                result.fromRecord = model.Count == 0 ? 0 : (result.currentPage - 1) * result.recordPerPage + 1;
                result.toRecord = (int)Math.Min(result.totalRecords, result.currentPage * result.recordPerPage);
                result.currentPage = result.totalPage < result.currentPage ? result.totalPage : result.currentPage;
                return result;
            }
            catch (Exception e)
            {
                ////SendMailError(e);
                return new TodOutput1NewModel()
                {
                    currentPage = parameters.Page,
                    recordPerPage = parameters.RecordsPerPage
                };
            }
        }

        [HttpPost("filter-tod-output1-old/{product}")]
        public async Task<TodOutput1OldModel> FilterOutput1Old(TodOutput1Param parameters, string product)
        {
            try
            {

                var config = new MapperConfiguration(cfg =>
                {
                    cfg.CreateMap<TodTodOutput1TotalLbpOld, TodTodOutput1TotalIjOld>();  
                });
                var mapper = config.CreateMapper();
                TodOutput1OldModel result = new TodOutput1OldModel()
                {
                    currentPage = parameters.Page,
                    recordPerPage = parameters.RecordsPerPage
                };

                //var lstPic = !string.IsNullOrEmpty(parameters.Pic) ? parameters.Pic.Split("_")[0] : "";
                IQueryable<TodTodOutput1TotalIjOld> query;
                if (product.ToUpper() == "IJ")
                {
                    query = context.TodTodOutput1TotalIjOlds.Where(x => x.Active == true);
                }
                else
                {
                    var outputLbp = context.TodTodOutput1TotalLbpOlds.Where(x => x.Active == true);
                    query = outputLbp.ProjectTo<TodTodOutput1TotalIjOld>(mapper.ConfigurationProvider);
                }
                //if (LstBlockCode.Count > 0)
                //{
                //    query = query.Where(x => x.Bc != null && LstBlockCode.Contains(x.Bc[0]));
                //}
                query = !string.IsNullOrEmpty(parameters.PartNo) ? query.Where(x => (x.PartNo != null && x.PartNo.ToUpper().Contains(parameters.PartNo.ToUpper()))
                || (x.Alternative != null && x.Alternative.Contains(parameters.PartNo.ToUpper())) || (x.Pair != null && x.Pair.Contains(parameters.PartNo))) : query;//nếu tìm kiếm rơi vào alternative thì phải nhập full part no
                query = !string.IsNullOrEmpty(parameters.Destination) ? query.Where(x => x.Des != null && parameters.Destination.ToUpper().Contains(x.Des.ToUpper())) : query;
                query = !string.IsNullOrEmpty(parameters.Vendor) ? query.Where(x => x.Vendor != null && x.Vendor.Contains(parameters.Vendor)) : query;
                query = !string.IsNullOrEmpty(parameters.BcUse) ? query.Where(x => x.Bc != null && x.Bc.Contains(parameters.BcUse)) : query;
                query = !string.IsNullOrEmpty(parameters.Model) ? query.Where(x => x.Model != null && parameters.Model.ToUpper().Contains(x.Model.ToUpper())) : query;
                query = !string.IsNullOrEmpty(parameters.Pic) ? query.Where(x => x.Pic != null && x.Pic.Contains(parameters.Pic)) : query;


                //var lstData = await query.GroupBy(y => new { y.PartNo, y.Vendor, y.Bc }).ToListAsync();

                result.totalRecords = await query.CountAsync();
                result.totalPage = (int)Math.Ceiling((decimal)result.totalRecords / parameters.RecordsPerPage);
                var model = await query.OrderBy(x => x.Gap).ThenBy(x => x.CalcOrder).Paginate(parameters).ToListAsync();
                //List<TodTodOutput1TotalIjOld> lstModel = new List<TodTodOutput1TotalIjOld>();
                //foreach (var item in model)
                //{
                //    foreach (var i in item.OrderBy(x => x.CalcOrder))
                //    {
                //        lstModel.Add(i);
                //    }
                //}
                result.lstModel = model;
                //result.lstModel = lstModel.Select(x =>
                //{
                //    for (int i = 0; i < x.TodValue.Length; i++)
                //    {
                //        if (double.IsInfinity(x.TodValue[i]) || double.IsNaN(x.TodValue[i]))
                //        {
                //            x.TodValue[i] = 0;
                //        }
                //    }
                //    return x;
                //}).ToList();
                result.fromRecord = model.Count == 0 ? 0 : (result.currentPage - 1) * result.recordPerPage + 1;
                result.toRecord = (int)Math.Min(result.totalRecords, result.currentPage * result.recordPerPage);
                result.currentPage = result.totalPage < result.currentPage ? result.totalPage : result.currentPage;
                return result;
            }
            catch (Exception e)
            {
                ////SendMailError(e);
                return new TodOutput1OldModel()
                {
                    currentPage = parameters.Page,
                    recordPerPage = parameters.RecordsPerPage
                };
            }
        }
        [HttpPost("filter-tod-output1-none/{product}")]
        public async Task<TodOutput1NoneModel> FilterOutput1None(TodOutput1Param parameters, string product)
        {
            try
            {

                var config = new MapperConfiguration(cfg =>
                {
                    cfg.CreateMap<TodTodOutput1TotalLbpNoneInv, TodTodOutput1TotalIjNoneInv>();
                });
                var mapper = config.CreateMapper();
                TodOutput1NoneModel result = new TodOutput1NoneModel()
                {
                    currentPage = parameters.Page,
                    recordPerPage = parameters.RecordsPerPage
                };
                IQueryable<TodTodOutput1TotalIjNoneInv> query;
                if (product.ToUpper() == "IJ")
                {
                    query = context.TodTodOutput1TotalIjNoneInvs.Where(x => x.Active == true);
                }
                else
                {
                    var outputLbp = context.TodTodOutput1TotalLbpNoneInvs.Where(x => x.Active == true);
                    query = outputLbp.ProjectTo<TodTodOutput1TotalIjNoneInv>(mapper.ConfigurationProvider);
                }
                //if (LstBlockCode.Count > 0)
                //{
                //    query = query.Where(x => x.Bc != null && LstBlockCode.Contains(x.Bc[0]));
                //}
                query = !string.IsNullOrEmpty(parameters.PartNo) ? query.Where(x => (x.PartNo != null && x.PartNo.ToUpper().Contains(parameters.PartNo.ToUpper()))
                || (x.Alternative != null && x.Alternative.Contains(parameters.PartNo.ToUpper())) || (x.Pair != null && x.Pair.Contains(parameters.PartNo))) : query;//nếu tìm kiếm rơi vào alternative thì phải nhập full part no
                query = !string.IsNullOrEmpty(parameters.Destination) ? query.Where(x => x.Des != null && parameters.Destination.ToUpper().Contains(x.Des.ToUpper())) : query;
                query = !string.IsNullOrEmpty(parameters.Vendor) ? query.Where(x => x.Vendor != null && x.Vendor.Contains(parameters.Vendor)) : query;
                query = !string.IsNullOrEmpty(parameters.BcUse) ? query.Where(x => x.Bc != null && x.Bc.Contains(parameters.BcUse)) : query;
                query = !string.IsNullOrEmpty(parameters.Model) ? query.Where(x => x.Model != null && parameters.Model.ToUpper().Contains(x.Model.ToUpper())) : query;
                query = !string.IsNullOrEmpty(parameters.Pic) ? query.Where(x => x.Pic != null && x.Pic.Contains(parameters.Pic)) : query;

                result.totalRecords = await query.CountAsync();
                result.totalPage = (int)Math.Ceiling((decimal)result.totalRecords / parameters.RecordsPerPage);
                var model = await query.OrderBy(x => x.Gap).ThenBy(x => x.CalcOrder).Paginate(parameters).ToListAsync();
                result.lstModel = model;
                result.fromRecord = model.Count == 0 ? 0 : (result.currentPage - 1) * result.recordPerPage + 1;
                result.toRecord = (int)Math.Min(result.totalRecords, result.currentPage * result.recordPerPage);
                result.currentPage = result.totalPage < result.currentPage ? result.totalPage : result.currentPage;
                return result;
            }
            catch (Exception e)
            {
                ////SendMailError(e);
                return new TodOutput1NoneModel()
                {
                    currentPage = parameters.Page,
                    recordPerPage = parameters.RecordsPerPage
                };
            }
        }

        [HttpPost("filter-tod-output-part-deadline/{product}")]
        public async Task<TodOutputPartDeadlineModel> FilterOutputPartDeadline(TodOutput1Param parameters, string product)
        {
            try
            {

                var config = new MapperConfiguration(cfg => cfg.CreateMap<TodTodOutput2DeadlineLbp, TodTodOutput2DeadlineIj>());
                var mapper = config.CreateMapper();
                TodOutputPartDeadlineModel result = new TodOutputPartDeadlineModel()
                {
                    currentPage = parameters.Page,
                    recordPerPage = parameters.RecordsPerPage
                };
                IQueryable<TodTodOutput2DeadlineIj> query;
                if (product.ToUpper() == "IJ")
                {
                    query = context.TodTodOutput2DeadlineIjs.Where(x => x.Active == true && (x.DeadlineActual != null || x.DeadlinePlan != null || x.DeadlineIncl != null));
                }
                else
                {
                    var outputLbp = context.TodTodOutput2DeadlineLbps.Where(x => x.Active == true && (x.DeadlineActual != null || x.DeadlinePlan != null || x.DeadlineIncl != null));
                    query = outputLbp.ProjectTo<TodTodOutput2DeadlineIj>(mapper.ConfigurationProvider);
                }
                //if (LstBlockCode.Count > 0)
                //{
                //    query = query.Where(x => x.Bc != null && LstBlockCode.Contains(x.Bc));
                //}
                query = !string.IsNullOrEmpty(parameters.PartNo) ? query.Where(x => x.PartNo != null && x.PartNo.ToUpper().Contains(parameters.PartNo.ToUpper())) : query;
                query = !string.IsNullOrEmpty(parameters.Destination) ? query.Where(x => x.Destination != null && x.Destination.ToUpper().Contains(parameters.Destination.ToUpper())) : query;
                query = !string.IsNullOrEmpty(parameters.Vendor) ? query.Where(x => x.Vendor != null && x.Vendor.ToUpper().Contains(parameters.Vendor.ToUpper())) : query;
                query = !string.IsNullOrEmpty(parameters.BcUse) ? query.Where(x => x.Bc != null &&  x.Bc.ToUpper().Contains(parameters.BcUse.ToUpper())) : query;
                query = !string.IsNullOrEmpty(parameters.Model) ? query.Where(x => x.Model != null && x.Model.ToUpper().Contains(parameters.Model.ToUpper())) : query;
                query = !string.IsNullOrEmpty(parameters.FromDate) ? query.Where(x => x.DeadlineIncl != null && Convert.ToDouble(x.DeadlineIncl) >= parameters.FromDate.ObjToDoubleAble()) : query;
                query = !string.IsNullOrEmpty(parameters.ToDate) ? query.Where(x => x.DeadlineIncl != null && Convert.ToDouble(x.DeadlineIncl) <= parameters.ToDate.ObjToDoubleAble()) : query;
                if (!string.IsNullOrEmpty(parameters.Pic))
                {
                    var lstPic = parameters.Pic.Split(',');
                    if(lstPic != null)
                    {
                        query = query.Where(x => lstPic.Any(y => x.Pic == y));
                    }
                }
               

                result.totalRecords = await query.CountAsync();
                result.totalPage = (int)Math.Ceiling((decimal)result.totalRecords / parameters.RecordsPerPage);
                var model = await query.OrderBy(x => string.IsNullOrEmpty(x.DeadlineIncl)).ThenBy(x => x.DeadlineIncl).Paginate(parameters).ToListAsync();

                //var modelView = mapper.Map<List<TodFcdelOutputStockStdIj>, List<TodFcdelOutputStockStdIj>>(model);
                result.lstModel = model;
                result.fromRecord = model.Count == 0 ? 0 : (result.currentPage - 1) * result.recordPerPage + 1;
                result.toRecord = (int)Math.Min(result.totalRecords, result.currentPage * result.recordPerPage);
                result.currentPage = result.totalPage < result.currentPage ? result.totalPage : result.currentPage;
                return result;
            }
            catch (Exception e)
            {
                //SendMailError(e);
                return new TodOutputPartDeadlineModel()
                {
                    currentPage = parameters.Page,
                    recordPerPage = parameters.RecordsPerPage
                };
            }
        }

        [HttpPost("filter-tod-output-to-summarize/{product}")]
        public async Task<TodOutputToSummarizeModel> FilterOutputToSumarize(TodOutputToSummarizeParam parameters, string product)
        {
            try
            {

                var config = new MapperConfiguration(cfg => cfg.CreateMap<TodTodOutput4CommonLbp, TodTodOutput4CommonIj>());
                var mapper = config.CreateMapper();
                TodOutputToSummarizeModel result = new TodOutputToSummarizeModel()
                {
                    currentPage = parameters.Page,
                    recordPerPage = parameters.RecordsPerPage
                };
                IQueryable<TodTodOutput4CommonIj> query;
                if (product.ToUpper() == "IJ")
                {
                    query = context.TodTodOutput4CommonIjs.Where(x => x.Active == true);
                }
                else
                {
                    var outputLbp = context.TodTodOutput4CommonLbps.Where(x => x.Active == true);
                    query = outputLbp.ProjectTo<TodTodOutput4CommonIj>(mapper.ConfigurationProvider);
                }
                //if (LstBlockCode.Count > 0)
                //{
                //    //query = query.Where(x => x.Bc != null && LstBlockCode.Any(y => x.Bc.Contains(y)));
                //    query = query.Where(x => x.Bc != null).AsEnumerable()
                //        .Where(x => LstBlockCode.Any(y => x.Bc.Contains(y))).AsQueryable();
                //}
                query = !string.IsNullOrEmpty(parameters.PartNo) ? query.Where(x => x.PartNo != null && parameters.PartNo.ToUpper().Contains(x.PartNo.ToUpper())) : query;
                query = !string.IsNullOrEmpty(parameters.Destination) ? query.Where(x => x.Destination != null && parameters.Destination.ToUpper().Contains(x.Destination.ToUpper())) : query;
                query = !string.IsNullOrEmpty(parameters.Vendor) ? query.Where(x => x.Vendor != null && parameters.Vendor.ToUpper().Contains(x.Vendor)) : query;
                query = !string.IsNullOrEmpty(parameters.BcUse) ? query.Where(x => x.Bc != null && x.Bc.ToUpper().Contains(parameters.BcUse.ToUpper())) : query;
                query = !string.IsNullOrEmpty(parameters.Model) ? query.Where(x => x.Model != null && parameters.Model.ToUpper().Contains(x.Model.ToUpper())) : query;
                query = !string.IsNullOrEmpty(parameters.Location1) ? query.Where(x => x.Location1 != null && parameters.Location1.ToUpper().Contains(x.Location1.ToUpper())) : query;
                query = !string.IsNullOrEmpty(parameters.OrderMethod) ? query.Where(x => x.OrderMethod != null && parameters.OrderMethod.ToUpper().Contains(x.OrderMethod.ToUpper())) : query;


                result.totalRecords =  query.Count();
                result.totalPage = (int)Math.Ceiling((decimal)result.totalRecords / parameters.RecordsPerPage);
                var model =  query.OrderByDescending(x => x.CreatedDate).Paginate(parameters).ToList();
                //var modelView = mapper.Map<List<TodFcdelOutputStockStdIj>, List<TodFcdelOutputStockStdIj>>(model);
                result.lstModel = model;
                result.fromRecord = model.Count == 0 ? 0 : (result.currentPage - 1) * result.recordPerPage + 1;
                result.toRecord = (int)Math.Min(result.totalRecords, result.currentPage * result.recordPerPage);
                result.currentPage = result.totalPage < result.currentPage ? result.totalPage : result.currentPage;
                return result;
            }
            catch (Exception e)
            {
                //SendMailError(e);
                return new TodOutputToSummarizeModel()
                {
                    currentPage = parameters.Page,
                    recordPerPage = parameters.RecordsPerPage
                };
            }
        }


        [HttpGet("filter-all-calendar")]
        public async Task<List<AdmMasterCalendar>> FilterMasterCalendar()
        {
            try
            {
                var result = await context.AdmMasterCalendars.ToListAsync();
                return result;
            }
            catch (Exception e)
            {
                //SendMailError(e);
                return new List<AdmMasterCalendar>();
            }
        }
        [HttpGet("filter-list-pic-partcontrol/{product}")]
        public async Task<List<string>> FilterListPic(string product)
        {
            try
            {
                var result = new List<string>();
                if (product.ToUpper() == "IJ")
                {
                    return await context.TodTodOutput2DeadlineIjs.Where(x => x.Pic != null).Select(x => x.Pic ?? "").Distinct().ToListAsync();
                }
                return await context.TodTodOutput2DeadlineLbps.Where(x => x.Pic != null).Select(x => x.Pic ?? "").Distinct().ToListAsync();
            }
            catch (Exception e)
            {
                //SendMailError(e);
                return new List<string>();
            }
        }
        #endregion

        #region find file tod
        [HttpGet("get-file-tod1/{product}/{date}")]
        public List<string> GetFileTod1(string product,string date)
        {
           
            try {
                string folderPath = Path.Combine(this.outputPathOri, @"3. Turnoverday\Output");
                string dateSearch = date;
                string productSearch = product;

                //string pattern = $@"OP1\.{productSearch.ToUpper()}[\s]*{dateSearch}.*\.xlsx";
                //string pattern = $@"OP1\.{productSearch.ToUpper()}[_\s]*{dateSearch}.*\.xlsx";
                string pattern = $@"OP1\.{productSearch.ToUpper()}.*{dateSearch}.*\.xlsx";

                var files = Directory.EnumerateFiles(folderPath)
                   .Where(file => Regex.IsMatch(Path.GetFileName(file), pattern, RegexOptions.CultureInvariant))
                   .OrderByDescending(f => f)
                   .ToList();

                return files;
            }
            catch(Exception e)
            {
                return new List<string>() { e.Message};
            }
        }
        [HttpGet("tod-calculate-again")]
        [AllowAnonymous]
        public async Task<CommonResponse> TodCalculateAgain(string product, string ppChange, string ppChangeDel, string otherPlan)
        {
            CommonResponse res = new CommonResponse()
            {
                Error = false,
                Message = "",
                Status = (int)HttpStatusCode.BadRequest
            };
            try
            {
                var u = GetCurrentUser();
                if (HangfireJobList.PreventUpload())
                {
                    res.Error = true;
                    res.Message = "Other jobs processing";
                    res.Status = 400;
                    return res;
                }
                await ManualFunc.GatewayAsync("UserCalculateAction2/Tod/" + product + "/" + ppChange + "/" + ppChangeDel + "/" + otherPlan);
                res.Error = false;
                res.Message = "Success, Job running";
                res.Status = 200;
                if (!string.IsNullOrEmpty(u.UserName))
                {
                    email.Initial(lstPDCMail, "Run PartControl", $"User {u.UserName} - {u.FullName} run manual to calculate PartControl with route: UserCalculateAction2/Tod/{product}/{ppChange}/{ppChangeDel}/{otherPlan}");
                }
                //                email.Initial(lstPDCMail, "Run-again part control " + product, @"<p style='font-weight: bold;'>Dear [Mrs/Mr]. All,</p>
                //<p>You have received a notification about <span style='font-weight: bold; color: red; font-style: italic;'>you have done the recalculation of the part control output </span>. Please wait then check.</p>
                //");
            }
            catch (Exception ex)
            {
                res.Error = true;
                res.Message = ex.Message;
                res.Status = 400;
            }
            
            return res;
        }
        [HttpGet("tod-calculate-none-again")]
        [AllowAnonymous]
        public async Task<CommonResponse> TodCalculateNoneAgain(string product, string ppChange, string ppChangeDel, string otherPlan)
        {
            CommonResponse res = new CommonResponse()
            {
                Error = false,
                Message = "",
                Status = (int)HttpStatusCode.BadRequest
            };
            try
            {
                var u = GetCurrentUser();
                if (HangfireJobList.PreventUpload())
                {
                    res.Error = true;
                    res.Message = "Other jobs processing";
                    res.Status = 400;
                    return res;
                }
                await ManualFunc.GatewayAsync("UserCalculateAction2/TodFcDo/" + product + "/" + ppChange + "/" + ppChangeDel + "/" + otherPlan);
                res.Error = false;
                res.Message = "Success, Job running";
                res.Status = 200;
                if (!string.IsNullOrEmpty(u.UserName))
                {
                    email.Initial(lstPDCMail, "Run PartControl NoneInventory", $"User {u.UserName} - {u.FullName} run manual to calculate PartControl with route: UserCalculateAction2/TodFcDo/{product}/{ppChange}/{ppChangeDel}/{otherPlan}");
                }
                //                email.Initial(lstPDCMail, "Run-again part control " + product, @"<p style='font-weight: bold;'>Dear [Mrs/Mr]. All,</p>
                //<p>You have received a notification about <span style='font-weight: bold; color: red; font-style: italic;'>you have done the recalculation of the part control output </span>. Please wait then check.</p>
                //");
            }
            catch (Exception ex)
            {
                res.Error = true;
                res.Message = ex.Message;
                res.Status = 400;
            }

            return res;
        }

        [HttpGet("tod-export-again")]
        [AllowAnonymous]
        public async Task<CommonResponse> TodExportAgain(string product)
        {
            CommonResponse res = new CommonResponse()
            {
                Error = false,
                Message = "",
                Status = (int)HttpStatusCode.BadRequest
            };
            try
            {
                var u = GetCurrentUser();
                await ManualFunc.GatewayAsync("UserExportAction/Tod/" + product + "/" + 1);
                await ManualFunc.GatewayAsync("UserExportAction/Tod/" + product + "/" + 2);
                await ManualFunc.GatewayAsync("UserExportAction/Tod/" + product + "/" + 4);
                await ManualFunc.GatewayAsync("UserExportAction/Tod/" + product + "/" + 3);
                res.Error = false;
                res.Message = "Success, Job running";
                res.Status = 200;
//                email.Initial(lstPDCMail, "Export part control " + product, @"<p style='font-weight: bold;'>Dear [Mrs/Mr]. All,</p>
//<p>You have received a notification about <span style='font-weight: bold; color: red; font-style: italic;'>EXPORT part control output </span>. Please wait then check.</p>
//");
            }
            catch (Exception ex)
            {
                res.Error = true;
                res.Message = ex.Message;
                res.Status = 400;
            }

            return res;
        }
        #endregion
        private bool SendMailError(Exception e)
        {
            try
            {
                string txtContent = "<p>Message: " + e.Message + "</p>\n" +
                "<p>Data: " + e.Data.ToString() + "</p>\n" +
                "<p>StackTrace: " + e.StackTrace + "</p>\n" +
                "<p>HelpLink: " + e.HelpLink ?? "" + "</p>\n" +
                "<p>Source: " + e.Source ?? "" + "</p>\n";
                email.Initial(lstITMail,
                    "Error exception",
                    txtContent);
                return false;
            }
            catch
            {
                return false;
            }
        }
        private UserClaims GetCurrentUser()
        {
            UserClaims userClaims = new UserClaims();
            var identity = HttpContext.User.Identity as ClaimsIdentity;
            if (identity != null)
            {
                userClaims.UserName = identity.FindFirst("user_name") == null ? "Undefined" : identity.FindFirst("user_name").Value;
                userClaims.Id = identity.FindFirst("id") == null ? "Undefined" : identity.FindFirst("id").Value;
                //userClaims.IsIt = identity.FindFirst("isIt") == null ? "0" : identity.FindFirst("isIt").Value;
                userClaims.Departments = identity.FindFirst("deptIds") == null ? "" : identity.FindFirst("deptIds").Value;
                userClaims.Factories = identity.FindFirst("factIds") == null ? "" : identity.FindFirst("factIds").Value;
                userClaims.CostCenter = identity.FindFirst("cost_center") == null ? "" : identity.FindFirst("cost_center").Value;
                userClaims.FullName = identity.FindFirst("full_name") == null ? "" : identity.FindFirst("full_name").Value;
                userClaims.Departments = identity.FindFirst("dept") == null ? "" : identity.FindFirst("dept").Value;
                userClaims.Grade = identity.FindFirst("grade") == null ? "" : identity.FindFirst("grade").Value;
                userClaims.IsAdmin = identity.FindFirst("isAdmin") == null ? "false" : identity.FindFirst("isAdmin").Value;
                userClaims.Email = identity.FindFirst("email") == null ? "" : identity.FindFirst("email").Value;
            }
            return userClaims;
        }

        private void NoticeFinishJob(string jobName, string mail, string note)
        {
            try
            {
                var lstMail = new List<string>() { mail };

                email.Initial(lstMail, "" + jobName, @"<p style='font-weight: bold;'>Dear [Mrs/Mr]. All,</p>
<p>You have received a notification about <span style='font-weight: bold; color: red; font-style: italic;'>completed calculate FC volume new output </span>from PDCS System. Please access system and check.</p>
<p style='font-weight: bold;'>1. Time: " + note + @"</p>
<p style='font-weight: bold;'>2. If you have any wrong, please check master at first." + @"<br />");

            }
            catch (Exception)
            {

            }
        }
        [HttpPost("filter-tod-output7/{product}")]
        public async Task<TodOutput7Model> FilterOutput7(TodOutput1Param parameters, string product)
        {
            try
            {

                TodOutput7Model result = new TodOutput7Model()
                {
                    currentPage = parameters.Page,
                    recordPerPage = parameters.RecordsPerPage
                };
                IQueryable<TodTodOutput7Fcdo> query = context.TodTodOutput7Fcdos.Where(x => x.Active == true && x.Product.Equals(product));
               
                query = !string.IsNullOrEmpty(parameters.PartNo) ? query.Where(x => x.PartNo != null && x.PartNo.ToUpper().Contains(parameters.PartNo.ToUpper())) : query;
                query = !string.IsNullOrEmpty(parameters.Vendor) ? query.Where(x => x.Vendor != null && x.Vendor.ToUpper().Contains(parameters.Vendor.ToUpper())) : query;

              


                result.totalRecords = await query.CountAsync();
                result.totalPage = (int)Math.Ceiling((decimal)result.totalRecords / parameters.RecordsPerPage);
                var model = await query.Paginate(parameters).ToListAsync();

                //var modelView = mapper.Map<List<TodFcdelOutputStockStdIj>, List<TodFcdelOutputStockStdIj>>(model);
                result.lstModel = model;
                result.fromRecord = model.Count == 0 ? 0 : (result.currentPage - 1) * result.recordPerPage + 1;
                result.toRecord = (int)Math.Min(result.totalRecords, result.currentPage * result.recordPerPage);
                result.currentPage = result.totalPage < result.currentPage ? result.totalPage : result.currentPage;
                return result;
            }
            catch (Exception e)
            {
                //SendMailError(e);
                return new TodOutput7Model()
                {
                    currentPage = parameters.Page,
                    recordPerPage = parameters.RecordsPerPage
                };
            }
        }
    }


}
