﻿using AutoMapper;
using DocumentFormat.OpenXml.Drawing.Charts;
using DocumentFormat.OpenXml.Office.CustomUI;
using DocumentFormat.OpenXml.Office2019.Presentation;
using DocumentFormat.OpenXml.Spreadsheet;
using Hangfire;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Tokens;
using OfficeOpenXml;
using PDCProjectApi.Common;
using PDCProjectApi.Common.Function;
using PDCProjectApi.Common.Interface;
using PDCProjectApi.Common.Job;
using PDCProjectApi.Data;
using PDCProjectApi.Helper;
using PDCProjectApi.Model.Request;
using PDCProjectApi.Model.Response;
using PDCProjectApi.Model.View;
using PDCProjectApi.Services;
using Quartz.Impl.Triggers;
using System;
using System.Data;
using System.Linq;
using System.Net;
using System.Security.Claims;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using DocumentFormat.OpenXml.Office2010.CustomUI;

namespace PDCProjectApi.Controllers
{ 
    [Route("api/inventory")]
    [ApiController]
    [Authorize] 
    public class InventoryController : Controller, IDisposable
    {
        [Obsolete]
        private readonly Microsoft.AspNetCore.Hosting.IHostingEnvironment _hostingEnvironment;
        private readonly IHttpContextAccessor httpContextAccessor;
        private readonly IFileStorageService fileStorageService;
        private readonly PdcsystemContext context;
        private readonly IConfiguration configuration;
        private readonly IEmailService email;
        private readonly IBackgroundJobClient _bgJobClient;
        private readonly IGlobalVariable global = new GlobalVariable();
        private readonly string outputPathOri = "";
        private readonly string DirectoryBrowser = "";
        private readonly string frondEnd = "";
        [Obsolete]
        public InventoryController(Microsoft.AspNetCore.Hosting.IHostingEnvironment hosting, PdcsystemContext ctx,
            IHttpContextAccessor httpContextAccessor, IFileStorageService fileService,
            IConfiguration configuration, IEmailService mail, IBackgroundJobClient backgroundJobClient)
        {
            this._hostingEnvironment = hosting;
            this.httpContextAccessor = httpContextAccessor;
            this.context = ctx;
            this.fileStorageService = fileService;
            this.configuration = configuration;
            this.email = mail;
            this._bgJobClient = backgroundJobClient;
            this.outputPathOri = this.global.ReturnPathOutput();
            this.DirectoryBrowser = this.global.ReturnDirectoryBrowser();
            this.frondEnd = this.global.ReturnFrondEndLink();
        }
        private bool disposed = false;
        protected virtual void Dispose(bool disposing)
        {
            if (!disposed)
            {
                if (disposing)
                {
                    if (context != null)
                    {
                        context.DisposeAsync();
                    }
                }
                disposed = true;
            }
        }
        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }
        ~InventoryController() { Dispose(false); }
        [HttpPost("filter-calendar-term")]
        public CalendarTermModel FilterCalendarTerm(CalendarTermParam param)
        {
            try
            {
                var result = new CalendarTermModel();
                var lstResult = new List<CalendarTermView>();


                var model = context.InvCalendarTerms.Where(x => x.Active == true).AsQueryable();
                if (!string.IsNullOrEmpty(param.TimeFrom)) { var TimeFrom = DateOnly.FromDateTime(DateTime.ParseExact(param.TimeFrom, "dd-MM-yyyy", null)); model = model.Where(x => x.TimeFrom >= TimeFrom); }
                if (!string.IsNullOrEmpty(param.TimeTo)) { var TimeTo = DateOnly.FromDateTime(DateTime.ParseExact(param.TimeTo, "dd-MM-yyyy", null)); model = model.Where(x => x.TimeTo <= TimeTo); }
                if (!string.IsNullOrEmpty(param.Term)) model = model.Where(x => x.Term.Contains(param.Term));
                var model2 = model.Skip((param.Page - 1) * param.RecordsPerPage).Take(param.RecordsPerPage).ToList();
                foreach (var item in model2)
                {

                    lstResult.Add(new CalendarTermView()
                    {
                        TimeFrom = item.TimeFrom != null ? item.TimeFrom.Value.ToString("dd-MMM-yyyy") : "",
                        TimeTo = item.TimeTo != null ? item.TimeTo.Value.ToString("dd-MMM-yyyy") : "",
                        Term = item.Term
                    });
                }


                var c = model.Count();
                result.lstModel = lstResult;
                result.toRecord = (int)Math.Min(result.totalRecords, result.currentPage * result.recordPerPage);
                result.totalPage = (int)Math.Ceiling((decimal)c / param.RecordsPerPage);
                result.totalRecords = c;
                result.recordPerPage = param.RecordsPerPage;
                result.currentPage = param.Page;
                result.fromRecord = c == 0 ? 0 : (result.currentPage - 1) * result.recordPerPage + 1;
                return result;
            }
            catch (Exception)
            {
                return new CalendarTermModel();
            }
        }
        [HttpPost("add-calendar-term")]
        public async Task<CommonResponse> AddCalendarTerm(CalendarTermParamAdd rq)
        {
            var res = new CommonResponse()
            {
                Error = false,
                Message = "Successful !",
                Status = 200
            };
            try
            {
                var user = GetCurrentUser();
                await context.InvCalendarTerms.AddAsync(new InvCalendarTerm()
                {
                    TimeFrom = DateOnly.FromDateTime(DateTime.ParseExact(rq.TimeFrom, "dd-MM-yyyy", null)),
                    TimeTo = DateOnly.FromDateTime(DateTime.ParseExact(rq.TimeTo, "dd-MM-yyyy", null)),
                    Term = rq.Term,
                    CreatedBy = user.UserName
                });
                context.SaveChanges();
                res.Error = false;
                res.Message = "Successful !";
                res.Status = 200;
            }
            catch (Exception e)
            {
                //SendMailError(e);
                res.Error = true;
                res.Message = e.Message;
                res.Status = 400;
            }
            return res;
        }
        private UserClaims GetCurrentUser()
        {
            UserClaims userClaims = new UserClaims();
            var identity = HttpContext.User.Identity as ClaimsIdentity;
            if (identity != null)
            {
                userClaims.UserName = identity.FindFirst("user_name") == null ? "Undefined" : identity.FindFirst("user_name").Value;
                userClaims.Id = identity.FindFirst("id") == null ? "Undefined" : identity.FindFirst("id").Value;
                userClaims.DeptId = identity.FindFirst("dept_id") == null ? "" : identity.FindFirst("dept_id").Value;
                userClaims.Factories = identity.FindFirst("factIds") == null ? "" : identity.FindFirst("factIds").Value;
                userClaims.CostCenter = identity.FindFirst("cost_center") == null ? "" : identity.FindFirst("cost_center").Value;
                userClaims.FullName = identity.FindFirst("full_name") == null ? "" : identity.FindFirst("full_name").Value;
                userClaims.Departments = identity.FindFirst("dept") == null ? "" : identity.FindFirst("dept").Value;
                userClaims.Grade = identity.FindFirst("grade") == null ? "" : identity.FindFirst("grade").Value;
                userClaims.IsAdmin = identity.FindFirst("isAdmin") == null ? "false" : identity.FindFirst("isAdmin").Value;
                userClaims.Email = identity.FindFirst("email") == null ? "" : identity.FindFirst("email").Value;
            }
            return userClaims;
        }
        [HttpPost("import-calendar-term")]
        public async Task<CommonResponse> ImportCalendarTerm([FromForm] IFormFile file)
        {
            var result = new CommonResponse()
            {
                Error = false,
                Message = "",
                Status = (int)HttpStatusCode.BadRequest
            };
            try
            {
                var u = GetCurrentUser();
                var listCheck = context.InvCalendarTerms.Select(x => x.Term.ToUpper()).ToList();
                //context.InvCalendarTerms.RemoveRange(listRemove);
                using (var memoStream = new MemoryStream())
                {
                    file.CopyTo(memoStream);
                    ExcelPackage.LicenseContext = LicenseContext.NonCommercial;
                    using (var package = new ExcelPackage(memoStream))
                    {
                        var worksheet = package.Workbook.Worksheets[0];

                        var rowCount = worksheet.Dimension?.Rows;

                        if (rowCount.HasValue && rowCount.Value >= 2)
                        {
                            for (int row = 2; row <= rowCount.Value; row++)
                            {
                                DateOnly? timeFrom = null;
                                try
                                {
                                    var date = Convert.ToDateTime(worksheet.Cells["A" + row].Value);
                                    timeFrom = DateOnly.FromDateTime(date); ;
                                }
                                catch (Exception)
                                {
                                    result.Status = (int)HttpStatusCode.BadRequest;
                                    result.Message = "Time from wrong format";
                                    result.Error = true;
                                    return result;
                                }
                                DateOnly? timeTo = null;
                                try
                                {
                                    var date = Convert.ToDateTime(worksheet.Cells["B" + row].Value);
                                    timeTo = DateOnly.FromDateTime(date); ;
                                }
                                catch (Exception)
                                {
                                    result.Status = (int)HttpStatusCode.BadRequest;
                                    result.Message = "Time to wrong format";
                                    result.Error = true;
                                    return result;
                                }
                                var term = Convert.ToString(worksheet.Cells["C" + row].Value);
                                if (listCheck.Contains(term.ToUpper()))
                                {
                                    result.Status = (int)HttpStatusCode.BadRequest;
                                    result.Message = "Term already exist";
                                    result.Error = true;
                                    return result;
                                }

                                var md = new InvCalendarTerm()
                                {
                                    CreatedBy = u.UserName,
                                    TimeFrom = timeFrom,
                                    TimeTo = timeTo,
                                    Term = term
                                };
                                context.InvCalendarTerms.Add(md);
                            }
                        }
                    }
                }
                context.SaveChanges();

                result.Status = (int)HttpStatusCode.OK;
                result.Message = "Success";
                result.Error = false;
                return result;
            }
            catch (Exception e)
            {
                result.Status = (int)HttpStatusCode.BadRequest;
                result.Message = e.Message;
                result.Error = true;
                return result;
            }
        }
        [HttpPost("import-part-list")]
        public async Task<CommonResponse> ImportPartList([FromForm] IFormFile file)
        {
            var result = new CommonResponse()
            {
                Error = false,
                Message = "",
                Status = (int)HttpStatusCode.BadRequest
            };
            try
            {
                var u = GetCurrentUser();
                var listPart = context.InvPartLists.Where(x=>x.Active == true).ToList();
                var listAdd = new List<InvPartList>();
                //context.InvCalendarTerms.RemoveRange(listRemove);
                using (var memoStream = new MemoryStream())
                {
                    file.CopyTo(memoStream);
                    ExcelPackage.LicenseContext = LicenseContext.NonCommercial;
                    using (var package = new ExcelPackage(memoStream))
                    {
                        var worksheet = package.Workbook.Worksheets[0];

                        var rowCount = worksheet.Dimension?.Rows;

                        if (rowCount.HasValue && rowCount.Value > 1)
                        {
                            
                            for (int row = 2; row <= rowCount.Value; row++)
                            {

                                var product = Convert.ToString(worksheet.Cells["A" + row].Value).Trim();
                                var partNo = Convert.ToString(worksheet.Cells["B" + row].Value).Trim();
                                var vendor = Convert.ToString(worksheet.Cells["C" + row].Value).Trim();
                                var schedule = Convert.ToString(worksheet.Cells["D" + row].Value).Trim();
                                if (schedule.Length > 6)
                                {
                                    result.Status = (int)HttpStatusCode.BadRequest;
                                    result.Message = "Schedule wrong format, maximum 5 characters. Example: H1-24";
                                    result.Error = true;
                                    return result;
                                }
                                //DateOnly? schedule = null;
                                //try
                                //{
                                //    var date = Convert.ToDateTime(worksheet.Cells["D" + row].Value);
                                //    schedule = DateOnly.FromDateTime(date); ;
                                //}
                                //catch (Exception)
                                //{
                                //    result.Status = (int)HttpStatusCode.BadRequest;
                                //    result.Message = "Schedule wrong format";
                                //    result.Error = true;
                                //    return result;
                                //}
                                var part = listPart.FirstOrDefault(x =>x.Product.ToUpper().Contains(product.ToUpper()) && x.PartNo.ToUpper().Equals(partNo.ToUpper()) && x.Vender.ToUpper().Equals(vendor.ToUpper()) && x.Schedule.ToUpper().Equals(schedule.ToUpper()));
                                if(part == null)
                                {

                                    listAdd.Add(new InvPartList()
                                    {
                                        CreatedBy = u.UserName,
                                        Product = product,
                                        PartNo = partNo,
                                        Vender = vendor,
                                        Schedule = schedule
                                    });
                                }
                            }
                        }
                    }
                }
                context.InvPartLists.AddRange(listAdd);
                context.SaveChanges();

                result.Status = (int)HttpStatusCode.OK;
                result.Message = "Success";
                result.Error = false;
                return result;
            }
            catch (Exception e)
            {
                result.Status = (int)HttpStatusCode.BadRequest;
                result.Message = e.Message;
                result.Error = true;
                return result;
            }
        }
        [HttpPost("filter-part-list")]
        public PartListModel FilterPartList(PaginationParams param)
        {
            try
            {
                var result = new PartListModel();
                var lstResult = new List<InvPartListView>();


                var model = context.InvPartLists.Where(x => x.Active == true).AsQueryable();
                var model2 = model.Skip((param.Page - 1) * param.RecordsPerPage).Take(param.RecordsPerPage).ToList();
                foreach (var item in model2)
                {
                    lstResult.Add(new InvPartListView()
                    {
                        Product = item.Product,
                        PartNo = item.PartNo,
                        Vender = item.Vender,
                        Schedule = item.Schedule
                    });
                }


                var c = model.Count();
                result.lstModel = lstResult;
                result.toRecord = (int)Math.Min(result.totalRecords, result.currentPage * result.recordPerPage);
                result.totalPage = (int)Math.Ceiling((decimal)c / param.RecordsPerPage);
                result.totalRecords = c;
                result.recordPerPage = param.RecordsPerPage;
                result.currentPage = param.Page;
                result.fromRecord = c == 0 ? 0 : (result.currentPage - 1) * result.recordPerPage + 1;
                return result;
            }
            catch (Exception)
            {
                return new PartListModel();
            }
        }
        [HttpPost("import-snp")]
        public async Task<CommonResponse> ImportSNP([FromForm] IFormFile file)
        {
            var result = new CommonResponse()
            {
                Error = false,
                Message = "",
                Status = (int)HttpStatusCode.BadRequest
            };
            try
            {
                var u = GetCurrentUser();
                //var listRemove = context.InvCalendarTerms.ToList();
                //context.InvCalendarTerms.RemoveRange(listRemove);
                List<InvSnp> listAdd = new List<InvSnp>();
                List<InvSnpDetail> listAddDetail = new List<InvSnpDetail>();
                using (var memoStream = new MemoryStream())
                {
                    file.CopyTo(memoStream);
                    ExcelPackage.LicenseContext = LicenseContext.NonCommercial;
                    using (var package = new ExcelPackage(memoStream))
                    {
                        var worksheet = package.Workbook.Worksheets[0];

                        var rowCount = worksheet.Dimension?.Rows;

                        if (rowCount.HasValue && rowCount.Value > 2)
                        {
                            //DateOnly? dateNow = DateOnly.FromDateTime(DateTime.Now);
                            //var period = context.InvCalendarTerms.FirstOrDefault(x => x.Active == true && x.TimeFrom <= dateNow && dateNow <= x.TimeTo);
                            //if (period == null)
                            //{
                            //    result.Status = (int)HttpStatusCode.BadRequest;
                            //    result.Message = "Not found period";
                            //    result.Error = true;
                            //    return result;
                            //}
                            //var config = new MapperConfiguration(cfg => cfg.CreateMap<TodStructureOutputContentLbp, TodStructureOutputContentIj>());
                            //var mapper = config.CreateMapper();
                            var listPeriod = await context.InvCalendarTerms.AsNoTracking().Where(x => x.Active == true).ToListAsync();
                            var masterStructureIj = await context.TodStructureOutputContentIjs.AsNoTracking().Where(x => x.Active == true).ToListAsync();
                            var masterStructureLBP = await context.TodStructureOutputContentLbps.AsNoTracking().Where(x => x.Active == true).ToListAsync();
                            var listPart = await context.InvPartLists.AsNoTracking().Where(x => x.Active == true).Select(x => x.PartNo+x.Vender+x.Schedule+(x.Product.Contains("IJ")?"IJP":"LBP")).ToListAsync();
                            //var modelLbp = mapper.Map<List<TodStructureOutputContentLbp>, List<TodStructureOutputContentIj>>(masterStructureLBP);
                            //var lstStructure = masterStructureIj.Concat(modelLbp);
                            var listLT = await context.LtOp2Inquiries.AsNoTracking().Where(x => x.Active == true).ToListAsync();
                            var listSnp = await context.InvSnps.Include(x=>x.Period).AsNoTracking().Where(x => x.Active == true).ToListAsync();
                            var listPartCheck = listSnp.Select(x => x.PartNo+"|"+x.Vendor+"|"+x.Period.Term+"|"+x.Product).ToList();
                            var listSnpDetail = await context.InvSnpDetails.Where(x => x.Active == true).ToListAsync();
                            List<InvSnpDetailView> listSnpDetailExcel = new List<InvSnpDetailView>();
                            List<SnpViewImport> listAddSNP = new List<SnpViewImport>();
                            List<SnpViewImport> listAddSNPLBP = new List<SnpViewImport>();
                            for (int row = 3; row <= rowCount.Value; row++)
                            {

                                var partNo = Convert.ToString(worksheet.Cells["B" + row].Value);
                                if (string.IsNullOrEmpty(partNo))
                                {
                                    break;
                                }
                                var vendor = Convert.ToString(worksheet.Cells["C" + row].Value);
                              
                                var snp = Convert.ToDouble(worksheet.Cells["D" + row].Value);
                                var actualCheck = Convert.ToDouble(worksheet.Cells["E" + row].Value);
                                var methodCheck = Convert.ToString(worksheet.Cells["F" + row].Value);
                                var productionLot = "";
                                try
                                {
                                    var date = Convert.ToDateTime(worksheet.Cells["G" + row].Value);
                                    productionLot = date.ToString("dd/MM/yyyy");
                                }
                                catch (Exception)
                                {

                                    productionLot = Convert.ToString(worksheet.Cells["G" + row].Value);
                                }

                                var detectBy = Convert.ToString(worksheet.Cells["H" + row].Value);

                                DateOnly? detectDate = null;
                                try
                                {
                                    var date = Convert.ToDateTime(worksheet.Cells["I" + row].Value);
                                    detectDate = DateOnly.FromDateTime(date);
                                }
                                catch (Exception)
                                {
                                    result.Status = (int)HttpStatusCode.BadRequest;
                                    result.Message = "Detect date wrong format";
                                    result.Error = true;
                                    return result;
                                }
                                var period = listPeriod.FirstOrDefault(x => x.Active == true && x.TimeFrom <= detectDate && detectDate <= x.TimeTo);
                                if (period == null)
                                {
                                    result.Status = (int)HttpStatusCode.BadRequest;
                                    result.Message = detectDate.Value.ToString("dd/MM/yyyy") + " not belong any period";
                                    result.Error = true;
                                    return result;
                                }
                             
                                var snpCheck = listSnp.FirstOrDefault(x => x.PartNo.Equals(partNo) && x.Vendor.Equals(vendor) && x.PeriodId == period.Id);
                                if (snpCheck == null)
                                {
                                   
                                    var part = masterStructureIj.Where(x => x.PartNo8.Equals(partNo)).ToList();
                                    if (part.Count() > 0)
                                    {
                                        listPartCheck.Add(partNo + "|" + vendor + "|" + period.Term + "|" + "IJP");
                                        if (!listPart.Contains(partNo + vendor + period.Term+"IJP"))
                                        {
                                            result.Status = (int)HttpStatusCode.BadRequest;
                                            result.Message = partNo + "( " + vendor + " ) is not exist";
                                            result.Error = true;
                                            return result;
                                        }
                                        var stringModel = string.Join(",", part.Where(x => x.Model45 != null).Select(y => y.Model45).ToList());
                                        var lt = listLT.Where(x => x.PartNo.Equals(partNo)).ToList();
                                        var newId = Guid.NewGuid();
                                        var SnpNewAdd = listAdd.FirstOrDefault(x => x.PartNo.Equals(partNo) && x.Vendor.Equals(vendor));
                                        if (SnpNewAdd != null)
                                        {
                                            newId = SnpNewAdd.Id;
                                        }
                                        else
                                        {
                                            var snpNew = new InvSnp()
                                            {
                                                CreatedBy = u.UserName,
                                                PartNo = partNo,
                                                Vendor = vendor,
                                                MethodCheck = methodCheck,
                                                PeriodId = period.Id,
                                                Model = part.Count() > 0 ? string.Join("+", stringModel.Split(",").Distinct().ToList()) : "",
                                                PartName = part.Count() > 0 ? part.First().PartName11 : "",
                                                KindOfPart = lt.Count() > 0 ? lt.First().KindOfPart : "",
                                                Product = "IJP",
                                                Id = newId
                                            };
                                            listAdd.Add(snpNew);
                                        }
                                        var detailCheckExcel = listSnpDetailExcel.FirstOrDefault(x => x.PartNo == partNo && x.SnpDetail.CheckDate == detectDate && x.SnpDetail.SnpCheck == snp && x.SnpDetail.Actual == actualCheck && x.SnpDetail.ProductionLot.Equals(productionLot));
                                        if(detailCheckExcel == null)
                                        {

                                            var time = 1;
                                            var detail = listAddSNP.Where(x => x.PartNo.Equals(partNo) && x.Vendor.Equals(vendor)).OrderByDescending(x => x.Time).ToList();
                                            if (detail.Count > 0)
                                            {
                                                time = detail.First().Time.Value + 1;
                                            }
                                            var add1 = new InvSnpDetail()
                                            {
                                                CreatedBy = u.UserName,
                                                SnpCheck = snp,
                                                Actual = actualCheck,
                                                Differ = actualCheck - snp,
                                                Ratio = ((actualCheck - snp) / snp) * 100,
                                                ProductionLot = productionLot,
                                                DetectedBy = detectBy,
                                                CheckDate = detectDate,
                                                SnpId = newId,
                                                Time = time
                                            };
                                            var add3 = new InvSnpDetailView()
                                            {
                                                SnpDetail = add1,
                                                PartNo = partNo
                                            };
                                            listAddDetail.Add(add1);
                                            listSnpDetailExcel.Add(add3);
                                            listAddSNP.Add(new SnpViewImport()
                                            {
                                                PartNo = partNo,
                                                Vendor = vendor,
                                                Time = time
                                            });
                                        }
                                    }
                                    else
                                    {
                                        var part1 = masterStructureLBP.Where(x => x.PartNo8.Equals(partNo)).ToList();
                                        if(part1 != null)
                                        {
                                            listPartCheck.Add(partNo + "|" + vendor + "|" + period.Term + "|" + "LBP");
                                            if (!listPart.Contains(partNo + vendor + period.Term + "LBP"))
                                            {
                                                result.Status = (int)HttpStatusCode.BadRequest;
                                                result.Message = partNo + "( " + vendor + " ) is not exist";
                                                result.Error = true;
                                                return result;
                                            }
                                            var stringModel = string.Join(",", part1.Where(x => x.Model45 != null).Select(y => y.Model45).ToList());
                                            var lt = listLT.Where(x => x.PartNo.Equals(partNo)).ToList();
                                            var newId = Guid.NewGuid();
                                            var SnpNewAdd = listAdd.FirstOrDefault(x => x.PartNo.Equals(partNo) && x.Vendor.Equals(vendor));
                                            if (SnpNewAdd != null)
                                            {
                                                newId = SnpNewAdd.Id;
                                            }
                                            else
                                            {
                                                var snpNew = new InvSnp()
                                                {
                                                    CreatedBy = u.UserName,
                                                    PartNo = partNo,
                                                    Vendor = vendor,
                                                    MethodCheck = methodCheck,
                                                    PeriodId = period.Id,
                                                    Model = part1.Count() > 0 ? string.Join("+", stringModel.Split(",").Distinct().ToList()) : "",
                                                    PartName = part1.Count() > 0 ? part1.First().PartName11 : "",
                                                    KindOfPart = lt.Count() > 0 ? lt.First().KindOfPart : "",
                                                    Product = "LBP",
                                                    Id = newId
                                                };
                                                listAdd.Add(snpNew);
                                            }
                                            var detailCheckExcel = listSnpDetailExcel.FirstOrDefault(x => x.PartNo == partNo && x.SnpDetail.CheckDate == detectDate && x.SnpDetail.SnpCheck == snp && x.SnpDetail.Actual == actualCheck && x.SnpDetail.ProductionLot.Equals(productionLot));
                                            if (detailCheckExcel == null)
                                            {
                                                var time = 1;
                                                var detail = listAddSNPLBP.Where(x => x.PartNo.Equals(partNo) && x.Vendor.Equals(vendor)).OrderByDescending(x => x.Time).ToList();
                                                if (detail.Count > 0)
                                                {
                                                    time = detail.First().Time.Value + 1;
                                                }
                                                var add2 = new InvSnpDetail()
                                                {
                                                    CreatedBy = u.UserName,
                                                    SnpCheck = snp,
                                                    Actual = actualCheck,
                                                    Differ = actualCheck - snp,
                                                    Ratio = ((actualCheck - snp) / snp) * 100,
                                                    ProductionLot = productionLot,
                                                    DetectedBy = detectBy,
                                                    CheckDate = detectDate,
                                                    SnpId = newId,
                                                    Time = time
                                                };
                                                var add3 = new InvSnpDetailView()
                                                {
                                                    SnpDetail = add2,
                                                    PartNo = partNo
                                                };
                                                listAddDetail.Add(add2);
                                                listSnpDetailExcel.Add(add3);
                                                listAddSNPLBP.Add(new SnpViewImport()
                                                {
                                                    PartNo = partNo,
                                                    Vendor = vendor,
                                                    Time = time
                                                });
                                            }
                                        }
                                        
                                    }

                                }
                                else
                                {
                                    var detailCheck = listSnpDetail.FirstOrDefault(x => x.SnpId == snpCheck.Id && x.CheckDate == detectDate && x.SnpCheck == snp && x.Actual == actualCheck && x.ProductionLot.Equals(productionLot));
                                    //{
                                    //    detailCheck.ModifiedBy = u.UserName;
                                    //    detailCheck.ModifiedDate = DateTime.Now.SetKindUtc();
                                    //    detailCheck.SnpCheck = snp;
                                    //    detailCheck.Actual = actualCheck;
                                    //    detailCheck.Differ = actualCheck - snp;
                                    //    detailCheck.Ratio = ((actualCheck - snp) / snp) * 100;
                                    //    detailCheck.ProductionLot = productionLot;
                                    //    detailCheck.DetectedBy = detectBy;
                                    //    context.Update(detailCheck);
                                    //}
                                    if (detailCheck == null)
                                    {

                                        var detail = listAddSNP.Where(x => x.PartNo.Equals(partNo) && x.Vendor.Equals(vendor)).OrderByDescending(x => x.Time).ToList();
                                        if (detail.Count > 0)
                                        {
                                            listAddDetail.Add(new InvSnpDetail()
                                            {
                                                CreatedBy = u.UserName,
                                                SnpCheck = snp,
                                                Actual = actualCheck,
                                                Differ = actualCheck - snp,
                                                Ratio = ((actualCheck - snp) / snp) * 100,
                                                ProductionLot = productionLot,
                                                DetectedBy = detectBy,
                                                CheckDate = detectDate,
                                                SnpId = snpCheck.Id,
                                                Time = detail.First().Time + 1
                                            });
                                        }
                                        else
                                        {
                                            var listDetail = listSnpDetail.Where(x => x.SnpId == snpCheck.Id).OrderByDescending(x => x.Time).FirstOrDefault();
                                            listAddDetail.Add(new InvSnpDetail()
                                            {
                                                CreatedBy = u.UserName,
                                                SnpCheck = snp,
                                                Actual = actualCheck,
                                                Differ = actualCheck - snp,
                                                Ratio = ((actualCheck - snp) / snp) * 100,
                                                ProductionLot = productionLot,
                                                DetectedBy = detectBy,
                                                CheckDate = detectDate,
                                                SnpId = snpCheck.Id,
                                                Time = listDetail != null ? (listDetail.Time + 1) : 1
                                            });
                                            listAddSNP.Add(new SnpViewImport()
                                            {
                                                PartNo = partNo,
                                                Vendor = vendor,
                                                Time = listDetail != null ? (listDetail.Time + 1) : 1
                                            });
                                        }
                                    }

                                }
                            }
                            var listZero = context.InvPartLists.Where(x => !listPartCheck.Contains(x.PartNo + "|" + x.Vender + "|" + x.Schedule+"|"+ (x.Product.Contains("IJ") ? "IJP" : "LBP")) && x.Active == true).ToList();
                            foreach (var item in listZero)
                            {
                                var period = listPeriod.FirstOrDefault(x => x.Term.ToUpper().Equals(item.Schedule.ToUpper()));
                                if(period != null)
                                {

                                    var part = masterStructureIj.Where(x => x.PartNo8.Equals(item.PartNo)).ToList();
                                    if (part.Count() > 0)
                                    {

                                        var stringModel = string.Join(",", part.Where(x => x.Model45 != null).Select(y => y.Model45).ToList());
                                        var lt = listLT.Where(x => x.PartNo.Equals(item.PartNo)).ToList();
                                        var newId = Guid.NewGuid();
                
                                            var snpNew = new InvSnp()
                                            {
                                                CreatedBy = u.UserName,
                                                PartNo = item.PartNo,
                                                Vendor = item.Vender,
                                                MethodCheck = "",
                                                PeriodId = period.Id,
                                                Model = part.Count() > 0 ? string.Join("+", stringModel.Split(",").Distinct().ToList()) : "",
                                                PartName = part.Count() > 0 ? part.First().PartName11 : "",
                                                KindOfPart = lt.Count() > 0 ? lt.First().KindOfPart : "",
                                                Product = "IJP",
                                                Id = newId
                                            };
                                            listAdd.Add(snpNew);
                                    
                                 
                                    }
                                    else
                                    {
                                        var part1 = masterStructureLBP.Where(x => x.PartNo8.Equals(item.PartNo)).ToList();
                                        if (part1.Count() > 0)
                                        {
                                            var stringModel = string.Join(",", part1.Where(x => x.Model45 != null).Select(y => y.Model45).ToList());
                                            var lt = listLT.Where(x => x.PartNo.Equals(item.PartNo)).ToList();
                                            var newId = Guid.NewGuid();
                                 
                                            var snpNew = new InvSnp()
                                            {
                                                CreatedBy = u.UserName,
                                                PartNo = item.PartNo,
                                                Vendor = item.Vender,
                                                MethodCheck = "",
                                                PeriodId = period.Id,
                                                Model = part1.Count() > 0 ? string.Join("+", stringModel.Split(",").Distinct().ToList()) : "",
                                                PartName = part1.Count() > 0 ? part1.First().PartName11 : "",
                                                KindOfPart = lt.Count() > 0 ? lt.First().KindOfPart : "",
                                                Product = "LBP",
                                                Id = newId
                                            };
                                            listAdd.Add(snpNew);
                                        }
                                    
                                   
                                    }
                                }
                            }
                        }
                    }
                }
                context.InvSnps.AddRange(listAdd);
                context.InvSnpDetails.AddRange(listAddDetail);
                context.SaveChanges();

                result.Status = (int)HttpStatusCode.OK;
                result.Message = "Success";
                result.Error = false;
                return result;
            }
            catch (Exception e)
            {
                result.Status = (int)HttpStatusCode.BadRequest;
                result.Message = e.Message;
                result.Error = true;
                return result;
            }
        }
        [HttpPost("filter-snp")]
        public SnpModel FilterSnp(SnpParam param)
        {
            try
            {
                var result = new SnpModel();
                var lstResult = new List<SnpTime>();

                var listDetail = context.InvSnpDetails.Where(x => x.Active == true).ToList();
                var model = context.InvSnps.Include(x => x.Period).Where(x => x.Active == true).AsQueryable();

                if (!string.IsNullOrEmpty(param.Product)) { model = model.Where(x => x.Product.ToUpper().Contains(param.Product.ToUpper())); }
                if (!string.IsNullOrEmpty(param.Term)) { model = model.Where(x => x.Period.Term.ToUpper().Contains(param.Term.ToUpper())); }
                if (!string.IsNullOrEmpty(param.PartNo)) { model = model.Where(x => x.PartNo.ToLower().Contains(param.PartNo.ToLower())); }
                if (!string.IsNullOrEmpty(param.Vendor)) { model = model.Where(x => x.Vendor.ToLower().Contains(param.Vendor.ToLower())); }
                if (param.Snp != null) { var listId = listDetail.Where(x => x.SnpCheck.Value.FormatDouble() == param.Snp.Value.FormatDouble()).Select(x => x.SnpId).Distinct().ToList(); model = model.Where(x => listId.Contains(x.Id)); }
                if (param.Actual != null) { var listId = listDetail.Where(x => x.Actual.Value.FormatDouble() == param.Actual.Value.FormatDouble()).Select(x => x.SnpId).Distinct().ToList(); model = model.Where(x => listId.Contains(x.Id)); }
                if (!string.IsNullOrEmpty(param.Method)) { model = model.Where(x => x.MethodCheck.ToLower().Contains(param.Method.ToLower())); }
                if (!string.IsNullOrEmpty(param.ProductionLot)) { var listId = listDetail.Where(x => x.ProductionLot.ToLower().Contains(param.ProductionLot.ToLower())).Select(x => x.SnpId).Distinct().ToList(); model = model.Where(x => listId.Contains(x.Id)); }
                if (!string.IsNullOrEmpty(param.DetectedBy)) { var listId = listDetail.Where(x => x.DetectedBy.ToLower().Contains(param.DetectedBy.ToLower())).Select(x => x.SnpId).Distinct().ToList(); model = model.Where(x => listId.Contains(x.Id)); }
                if (!string.IsNullOrEmpty(param.DetectedDate)) { var DetectDate = DateOnly.FromDateTime(DateTime.ParseExact(param.DetectedDate, "dd-MM-yyyy", null)); var listId = listDetail.Where(x => x.CheckDate == DetectDate).Select(x => x.SnpId).Distinct().ToList(); model = model.Where(x => listId.Contains(x.Id)); }
                var model2 = model.Skip((param.Page - 1) * param.RecordsPerPage).Take(param.RecordsPerPage).ToList();
                List<SnpTemp> listTemp = new List<SnpTemp>();
                var count = 0;
                foreach (var item in model2)
                {
                    var list = listDetail.Where(x => x.SnpId == item.Id).OrderBy(x => x.Time).ToList();
                    if (list.Count > count) { count = list.Count(); };
                    listTemp.Add(new SnpTemp()
                    {
                        Snp = item,
                        SnpDetail = list
                    });
                }
                var no = (param.Page - 1) * param.RecordsPerPage + 1;
                foreach (var item in listTemp)
                {
                    List<string> resultTemp = new List<string>();
                    resultTemp.Add(no.ToString());
                    resultTemp.Add(item.Snp.Period.Term);
                    resultTemp.Add(item.Snp.Model);
                    resultTemp.Add(item.Snp.PartNo);
                    resultTemp.Add(item.Snp.PartName);
                    resultTemp.Add(item.Snp.Vendor);
                    resultTemp.Add(item.Snp.KindOfPart);
                    int timeOk = item.SnpDetail.Where(x => x.Differ == 0).ToList().Count();
                    int timePlus = item.SnpDetail.Where(x => x.Differ > 0).ToList().Count();
                    int timeMinus = item.SnpDetail.Where(x => x.Differ < 0).ToList().Count();
                    var totalRate = (timeOk + timePlus + timeMinus) == 0 ?0 : item.SnpDetail.Select(x => x.Differ).Sum() / item.SnpDetail.Select(x => x.SnpCheck).Sum();
                    resultTemp.Add((timeOk + timePlus + timeMinus).ToString());
                    resultTemp.Add(timeOk.ToString());
                    resultTemp.Add(timePlus.ToString());
                    resultTemp.Add(timeMinus.ToString());
                    resultTemp.Add(totalRate.Value.FormatDouble4().ToString() + " %");
                    var status = "";

                    if (timePlus == 0 && timeOk == 0 && timeMinus == 0)
                    {
                        status = "NY";
                    }
                    else if(timePlus > 0 && timeMinus > 0)
                    {
                        status = "Unstable";
                    }
                    else if (timeOk > 0 && timePlus == 0 && timeMinus == 0)
                    {
                        status = "OK";
                    }
                    else if (timeMinus == 0  && timePlus > 0)
                    {
                        status = "Plus";
                    }
                    else if (timePlus == 0  && timeMinus > 0)
                    {
                        status = "Minus";
                    }
                    resultTemp.Add(status);
                    foreach (var ele in item.SnpDetail)
                    {
                        resultTemp.Add(ele.SnpCheck.ToString());
                        resultTemp.Add(ele.Actual.ToString());
                        resultTemp.Add(ele.Differ.ToString());
                        resultTemp.Add(ele.Ratio.Value.FormatDouble4().ToString() + " %");
                        resultTemp.Add(ele.ProductionLot);
                        resultTemp.Add(ele.DetectedBy);
                        resultTemp.Add(ele.CheckDate.Value.ToString("dd/MM/yyyy"));

                    }
                    var minus = count - item.SnpDetail.Count();
                    if (minus > 0)
                    {
                        for (int i = 0; i < minus * 7; i++)
                        {
                            resultTemp.Add("");
                        }
                    }
                    List<string> listTimeTemp = new List<string>();
                    for (int i = 1; i <= item.SnpDetail.Count(); i++)
                    {
                        listTimeTemp.Add("Time " + i);
                    }
                    lstResult.Add(new SnpTime()
                    {
                        listData = resultTemp,
                        listTime = listTimeTemp
                    });
                    no++;
                }

                var c = model.Count();
                result.count = new int[count];
                result.lstModel = lstResult;
                result.toRecord = (int)Math.Min(result.totalRecords, result.currentPage * result.recordPerPage);
                result.totalPage = (int)Math.Ceiling((decimal)c / param.RecordsPerPage);
                result.totalRecords = c;
                result.recordPerPage = param.RecordsPerPage;
                result.currentPage = param.Page;
                result.fromRecord = c == 0 ? 0 : (result.currentPage - 1) * result.recordPerPage + 1;
                return result;
            }
            catch (Exception)
            {
                return new SnpModel();
            }
        }
        [HttpPost("add-snp")]
        public async Task<CommonResponse> AddSnp(SnpParamAdd rq)
        {
            var res = new CommonResponse()
            {
                Error = false,
                Message = "Successful !",
                Status = 200
            };
            try
            {
                var u = GetCurrentUser();
                DateOnly? dateNow = DateOnly.FromDateTime(DateTime.Now);
                var period = context.InvCalendarTerms.FirstOrDefault(x => x.Active == true && x.TimeFrom <= dateNow && dateNow <= x.TimeTo);
                if (period == null)
                {
                    res.Status = (int)HttpStatusCode.BadRequest;
                    res.Message = "Not found period";
                    res.Error = true;
                    return res;
                }
                //var config = new MapperConfiguration(cfg => cfg.CreateMap<TodStructureOutputContentLbp, TodStructureOutputContentIj>());
                //var mapper = config.CreateMapper();
                var masterStructureIj = context.TodStructureOutputContentIjs.Where(x => x.Active == true).ToList();
                var masterStructureLBP = context.TodStructureOutputContentLbps.Where(x => x.Active == true).ToList();
                //var modelLbp = mapper.Map<List<TodStructureOutputContentLbp>, List<TodStructureOutputContentIj>>(masterStructureLBP);
                //var lstStructure = masterStructureIj.Concat(modelLbp);
                var listLT = context.LtOp2Inquiries.Where(x => x.Active == true).ToList();
                var listSnp = context.InvSnps.Where(x => x.Active == true).ToList();
                var listSnpDetail = context.InvSnpDetails.Where(x => x.Active == true).ToList();
                var snpCheck = listSnp.FirstOrDefault(x => x.PartNo.Equals(rq.partNo) && x.Vendor.Equals(rq.vendor));
                if (snpCheck == null)
                {
                    var part = masterStructureIj.Where(x => x.PartNo8.Equals(rq.partNo)).ToList();
                    if (part.Count() > 0)
                    {
                        var stringModel = string.Join(",", part.Select(x => x.Model45).ToList());
                        var lt = listLT.Where(x => x.PartNo.Equals(rq.partNo));
                        var snpNew = new InvSnp()
                        {
                            CreatedBy = u.UserName,
                            PartNo = rq.partNo,
                            Vendor = rq.vendor,
                            MethodCheck = rq.method,
                            PeriodId = period.Id,
                            Model = part.Count() > 0 ? string.Join("+", stringModel.Split(",").Distinct().ToList()) : "",
                            PartName = part.Count() > 0 ? part.First().PartName11 : "",
                            KindOfPart = lt.Count() > 0 ? lt.First().KindOfPart : "",
                            Product = "IJP"
                        };
                        context.InvSnps.Add(snpNew);
                        context.SaveChanges();
                        context.InvSnpDetails.Add(new InvSnpDetail()
                        {
                            CreatedBy = u.UserName,
                            SnpCheck = rq.snp,
                            Actual = rq.actual,
                            Differ = rq.actual - rq.snp,
                            Ratio = (rq.actual - rq.snp) / rq.snp,
                            ProductionLot = rq.productionLot,
                            DetectedBy = rq.detectedBy,
                            CheckDate = DateOnly.FromDateTime(DateTime.ParseExact(rq.detectedDate, "dd-MM-yyyy", null)),
                            SnpId = snpNew.Id,
                            Time = 1
                        });
                    }
                    else
                    {
                        var stringModel = string.Join(",", part.Select(x => x.Model45).ToList());
                        var part1 = masterStructureLBP.Where(x => x.PartNo8.Equals(rq.partNo)).ToList();
                        var lt = listLT.Where(x => x.PartNo.Equals(rq.partNo));
                        var snpNew = new InvSnp()
                        {
                            CreatedBy = u.UserName,
                            PartNo = rq.partNo,
                            Vendor = rq.vendor,
                            MethodCheck = rq.method,
                            PeriodId = period.Id,
                            Model = part1.Count() > 0 ? string.Join("+", stringModel.Split(",").Distinct().ToList()) : "",
                            PartName = part1.Count() > 0 ? part1.First().PartName11 : "",
                            KindOfPart = lt.Count() > 0 ? lt.First().KindOfPart : "",
                            Product = "LBP"
                        };
                        context.InvSnps.Add(snpNew);
                        context.SaveChanges();
                        context.InvSnpDetails.Add(new InvSnpDetail()
                        {
                            CreatedBy = u.UserName,
                            SnpCheck = rq.snp,
                            Actual = rq.actual,
                            Differ = rq.actual - rq.snp,
                            Ratio = (rq.actual - rq.snp) / rq.snp,
                            ProductionLot = rq.productionLot,
                            DetectedBy = rq.detectedBy,
                            CheckDate = DateOnly.FromDateTime(DateTime.ParseExact(rq.detectedDate, "dd-MM-yyyy", null)),
                            SnpId = snpNew.Id,
                            Time = 1
                        });
                    }
                }
                else
                {
                    var listDetail = listSnpDetail.Where(x => x.SnpId == snpCheck.Id).OrderByDescending(x => x.Time).FirstOrDefault();
                    context.InvSnpDetails.Add(new InvSnpDetail()
                    {
                        CreatedBy = u.UserName,
                        SnpCheck = rq.snp,
                        Actual = rq.actual,
                        Differ = rq.actual - rq.snp,
                        Ratio = (rq.actual - rq.snp) / rq.snp,
                        ProductionLot = rq.productionLot,
                        DetectedBy = rq.detectedBy,
                        CheckDate = DateOnly.FromDateTime(DateTime.ParseExact(rq.detectedDate, "dd-MM-yyyy", null)),
                        SnpId = snpCheck.Id,
                        Time = listDetail != null ? (listDetail.Time + 1) : 1
                    });
                }

                context.SaveChanges();
                res.Error = false;
                res.Message = "Successful !";
                res.Status = 200;
            }
            catch (Exception e)
            {
                //SendMailError(e);
                res.Error = true;
                res.Message = e.Message;
                res.Status = 400;
            }
            return res;
        }


        [HttpPost("filter-ip2-packing")]
        public async Task<Ip2PackingModel> FilterIp2packing(Ip2PackingParam param)
        {
            try
            {
                Ip2PackingModel result = new Ip2PackingModel()
                {
                    currentPage = param.Page,
                    recordPerPage = param.RecordsPerPage
                };

                //DateOnly? ivnDate = param.PiDate.StringToDateAble();
                DateOnly? piDate = param.PiDate.StringToDateAble();
                DateOnly? omittedDate = param.OmittedDate.StringToDateAble();
                DateOnly? urgentDate = param.UrgentDate.StringToDateAble();

                var query = context.InvIp2Packings.Where(x => x.Active == true && x.Product.ToUpper() == param.Product.ToUpper());
                query = !string.IsNullOrEmpty(param.PartNo) ? query.Where(x => x.PartNo != null && x.PartNo.ToUpper().Contains(param.PartNo.ToUpper())) : query;
                query = !string.IsNullOrEmpty(param.Vendor) ? query.Where(x => x.Vendor != null && x.Vendor.ToUpper().Contains(param.Vendor.ToUpper())) : query;
                query = !string.IsNullOrEmpty(param.UrgentQty) ? query.Where(x => x.UrgentQt != null && x.UrgentQt == param.UrgentQty.StringAbleToDouble()) : query;
                query = !string.IsNullOrEmpty(param.PiQty) ? query.Where(x => x.PiQty != null && x.PiQty == param.PiQty.StringAbleToDouble()) : query;
                query = !string.IsNullOrEmpty(param.OmittedQty) ? query.Where(x => x.OmittedQty != null && x.OmittedQty == param.OmittedQty.StringAbleToDouble()) : query;
                query = piDate != null ? query.Where(x => x.PiDate != null && x.PiDate == piDate) : query;
                query = omittedDate != null ? query.Where(x => x.OmittedDate != null && x.OmittedDate == omittedDate) : query;
                query = urgentDate != null ? query.Where(x => x.UrgentDate != null && x.UrgentDate == urgentDate) : query;

                result.totalRecords = await query.CountAsync();
                result.totalPage = (int)Math.Ceiling((decimal)result.totalRecords / param.RecordsPerPage);
                var model = await query.Paginate(param).ToListAsync();
                result.lstModel = model.Select(x =>
                {
                    var im = new Ip2PackingParamAdd();

                    // Project các trường cần thiết, chuyển đổi ngày tháng sang chuỗi string
                    im.Id = x.Id;
                    im.PartNo = x.PartNo;
                    im.Vendor = x.Vendor;
                    im.Product = x.Product;
                    im.PackingMethod = x.PackingMethod;
                    im.InvMethod = x.InvMethod;
                    im.InvDate = x.InvDate.HasValue ? x.InvDate.Value.ToString("yyyy-MM-dd") : string.Empty;
                    im.UrgentQty = x.UrgentQt.ToString();
                    im.UrgentDate = x.UrgentDate.HasValue ? x.UrgentDate.Value.ToString("yyyy-MM-dd") : string.Empty;
                    im.PiQty = x.PiQty.ToString();
                    im.PiDate = x.PiDate.HasValue ? x.PiDate.Value.ToString("yyyy-MM-dd") : string.Empty;
                    im.OmittedQty = x.OmittedQty.ToString();
                    im.OmittedDate = x.OmittedDate.HasValue ? x.OmittedDate.Value.ToString("yyyy-MM-dd") : string.Empty;
                    return im;
                }).ToList();
                //result.lstModel = model;
                result.fromRecord = model.Count == 0 ? 0 : (result.currentPage - 1) * result.recordPerPage + 1;
                result.toRecord = (int)Math.Min(result.totalRecords, result.currentPage * result.recordPerPage);
                result.currentPage = result.totalPage < result.currentPage ? result.totalPage : result.currentPage;
                return result;
            }
            catch (Exception)
            {
                return new Ip2PackingModel()
                {
                    currentPage = param.Page,
                    recordPerPage = param.RecordsPerPage
                };
            }
        }
        [HttpPost("add-ip2-packing")]
        public async Task<CommonResponse> AddIP2Packing(Ip2PackingParamAdd rq)
        {
            var res = new CommonResponse()
            {
                Error = false,
                Message = "Successful !",
                Status = 200
            };
            try
            {

                DateOnly? invDate = rq.InvDate.StringToDateAble();
                DateOnly? piDate = rq.PiDate.StringToDateAble();
                DateOnly? omittedDate = rq.OmittedDate.StringToDateAble();
                DateOnly? urgentDate = rq.UrgentDate.StringToDateAble();
                var u = GetCurrentUser();

                var add = new InvIp2Packing()
                {
                    CreatedBy = u.UserName,
                    PartNo = rq.PartNo,
                    Vendor = rq.Vendor,
                    PackingMethod = rq.PackingMethod,
                    InvMethod = rq.InvMethod,
                    InvDate = invDate,
                    PiDate = piDate,
                    PiQty = rq.PiQty.StringAbleToDouble(),
                    OmittedDate = omittedDate,
                    OmittedQty = rq.OmittedQty.StringAbleToDouble(),
                    UrgentDate = urgentDate,
                    UrgentQt = rq.UrgentQty.StringAbleToDouble(),
                    Product = rq.Product
                };

                context.Add(add);
                context.SaveChanges();

                res.Error = false;
                res.Message = "Successful !";
                res.Status = 200;
            }
            catch (Exception e)
            {
                //SendMailError(e);
                res.Error = true;
                res.Message = e.Message;
                res.Status = 400;
            }
            return res;
        }
        [HttpGet("active-ip2-packing/{id}")]
        public async Task<CommonResponse> ActiveIP2Packing(Guid id)
        {
            var res = new CommonResponse()
            {
                Error = false,
                Message = "Successful !",
                Status = 200
            };
            try
            {

                var model = context.InvIp2Packings.First(x => x.Id == id);
                model.Active = false;
                context.Update(model);
                await context.SaveChangesAsync();

                res.Error = false;
                res.Message = "Successful !";
                res.Status = 200;
            }
            catch (Exception e)
            {
                //SendMailError(e);
                res.Error = true;
                res.Message = e.Message;
                res.Status = 400;
            }
            return res;
        }

        [HttpPost("get-snp-report")]
        public SnpReport GetSnpReport(SnpReportParam param)
        {
            try
            {
                var result = new SnpReport();
                List<List<string>> listResult = new List<List<string>>();
                if (param.Type.Equals("Report Progress by product"))
                {
                    DateOnly FromDate = new DateOnly();
                    DateOnly ToDate = new DateOnly();
                    if (param.Term != null)
                    {
                        var term = context.InvCalendarTerms.FirstOrDefault(x => x.Active == true && x.Term.Equals(param.Term));
                        if (!string.IsNullOrEmpty(param.FromDate) && !string.IsNullOrEmpty(param.ToDate))
                        {
                            FromDate = DateOnly.FromDateTime(DateTime.ParseExact(param.FromDate, "dd-MM-yyyy", null));
                            ToDate = DateOnly.FromDateTime(DateTime.ParseExact(param.ToDate, "dd-MM-yyyy", null));
                        }
                        else
                        {
                            FromDate = term.TimeFrom.Value;
                            ToDate = term.TimeTo.Value;
                        }
                    }
                    else
                    {
                        FromDate = DateOnly.FromDateTime(DateTime.ParseExact(param.FromDate, "dd-MM-yyyy", null));
                        ToDate = DateOnly.FromDateTime(DateTime.ParseExact(param.ToDate, "dd-MM-yyyy", null));
                    }

                    var maxFinal = 0;
                    var listSnp = context.InvSnpDetails.Include(x => x.Snp).Where(x => x.Active == true && FromDate <= x.CheckDate && x.CheckDate <= ToDate).ToList();
                    var listPart = context.InvPartLists.Where(x => x.Active == true).ToList();

                    string[] listProduct = { "IJP", "LBP" };
                    List<SnpView> listGroupIJP = new List<SnpView>();
                    List<SnpView> listGroupLBP = new List<SnpView>();
                    foreach (var item in listProduct)
                    {
                        List<int> listCount = new List<int>();
                        if (param.Term != null)
                        {
                            var listItem = listPart.Where(x => x.Schedule.Equals(param.Term) && item.Contains(x.Product.ToUpper())).ToList();
                            foreach (var item1 in listItem)
                            {
                                listCount.Add(listSnp.Where(x => x.Snp.PartNo.Equals(item1.PartNo) && x.Snp.Vendor.Equals(item1.Vender)).Count());
                            }
                        }
                        else
                        {
                            var listItem = listSnp.Where(x => item.Contains(x.Snp.Product.ToUpper())).DistinctBy(x => x.Snp.PartNo).ToList();
                            foreach (var item1 in listItem)
                            {
                                listCount.Add(listSnp.Where(x => x.Snp.PartNo.Equals(item1.Snp.PartNo) && x.Snp.Vendor.Equals(item1.Snp.Vendor)).Count());
                            }
                        }

                        var listGroup = listCount.GroupBy(p => p).Select(g => new { g.Key, count = g.Count() }).OrderBy(x => x.Key);
                        var max = 0;
                        if (listGroup.Count() > 0)
                        {
                            max = listGroup.Select(x => x.Key).Max();
                            if (max > maxFinal) { maxFinal = max; };
                        }
                        if (item.Equals("IJP"))
                        {
                            foreach (var item2 in listGroup)
                            {
                                listGroupIJP.Add(new SnpView()
                                {
                                    Key = item2.Key,
                                    Count = item2.count
                                });
                            }
                        }
                        else
                        {
                            foreach (var item2 in listGroup)
                            {
                                listGroupLBP.Add(new SnpView()
                                {
                                    Key = item2.Key,
                                    Count = item2.count
                                });
                            }
                        }
                    }
                    foreach (var item in listProduct)
                    {
                        var listGroup = item.Equals("IJP") ? listGroupIJP : listGroupLBP;
                        List<string> listTemp = new List<string>();
                        //var listItem = listPart.Where(x => item.Contains(x.Product.ToUpper())).ToList();
                        var count = 0;
                        if (param.Term != null)
                        {
                            var listItem = listPart.Where(x => x.Schedule.Equals(param.Term) && item.Contains(x.Product.ToUpper())).ToList();
                            listTemp.Add(item);
                            count = listItem.Count();
                            listTemp.Add(count.ToString());
                        }
                        else
                        {
                            var listItem = listSnp.Where(x => item.Contains(x.Snp.Product.ToUpper())).DistinctBy(x => x.Snp.PartNo).ToList();
                            listTemp.Add(item);
                            count = listItem.Count();
                            listTemp.Add(count.ToString());
                        }


                        for (int i = 0; i <= maxFinal; i++)
                        {
                            var temp = listGroup.FirstOrDefault(x => x.Key == i);
                            listTemp.Add(temp != null ? temp.Count.ToString() : "0");
                        }
                        listTemp.Add(count == 0 ? "0 %" : (((((double)listGroup.Where(x => x.Key > 2).Select(x => x.Count).Sum() / (double)count) * 100)).FormatDouble4().ToString() + " %"));
                        listResult.Add(listTemp);

                    }
                    result.CountTime = maxFinal + 1;
                    result.ListData = listResult;
                }
                else if (param.Type.Equals("Report by kind"))
                {
                    DateOnly FromDate = new DateOnly();
                    DateOnly ToDate = new DateOnly();
                    if (param.Term != null)
                    {
                        var term = context.InvCalendarTerms.FirstOrDefault(x => x.Active == true && x.Term.Equals(param.Term));
                        FromDate = term.TimeFrom.Value;
                        ToDate = term.TimeTo.Value;
                    }
                    else
                    {
                        FromDate = DateOnly.FromDateTime(DateTime.ParseExact(param.FromDate, "dd-MM-yyyy", null));
                        ToDate = DateOnly.FromDateTime(DateTime.ParseExact(param.ToDate, "dd-MM-yyyy", null));
                    }
                    var listSnpDetail = context.InvSnpDetails.Include(x => x.Snp).Where(x => x.Active == true && FromDate <= x.CheckDate && x.CheckDate <= ToDate).ToList();
                    var listSnp = context.InvSnps.Where(x => x.Active == true && x.Product.Equals(param.Product)).ToList();
                    List<SnpKindView> listSnpKind = new List<SnpKindView>();
                    foreach (var item in listSnp)
                    {
                        var list = listSnpDetail.Where(x => x.SnpId == item.Id).ToList();
                        int timeOk = list.Where(x => x.Differ == 0).ToList().Count();
                        int timePlus = list.Where(x => x.Differ > 0).ToList().Count();
                        int timeMinus = list.Where(x => x.Differ < 0).ToList().Count();
                        var status = "";

                        if (timePlus == 0 && timeOk == 0 && timeMinus == 0)
                        {
                            status = "NY";
                        }
                        else if (timePlus > 0 && timeMinus > 0)
                        {
                            status = "Unstable";
                        }
                        else if (timeOk > 0 && timePlus == 0 && timeMinus == 0)
                        {
                            status = "OK";
                        }
                        else if (timeMinus == 0 && timePlus > 0)
                        {
                            status = "Plus";
                        }
                        else if (timePlus == 0 && timeMinus > 0)
                        {
                            status = "Minus";
                        }
                        listSnpKind.Add(new SnpKindView()
                        {
                            Kind = item.KindOfPart.ToLower(),
                            Status = status
                        });
                    }
                    int[] arrSum = new int[5] { 0, 0, 0, 0, 0 };
                    string[] listKind = { "Big", "Medium", "Small" };
                    string[] listStatus = { "OK", "Plus", "Minus", "Unstable", "NY" };
                    foreach (var item in listKind)
                    {
                        List<string> listTemp = new List<string>();
                        listTemp.Add(item);
                        int temp = 0;
                        foreach (var item1 in listStatus)
                        {
                            var count = listSnpKind.Where(x => x.Kind.ToLower().Equals(item.ToLower()) && x.Status.Equals(item1)).Count();
                            listTemp.Add(count.ToString());
                            arrSum[temp] += count;
                            temp++;
                        }
                        listResult.Add(listTemp);
                    }
                    List<string> listTotal = new List<string>();
                    listTotal.Add("Total");
                    for (int i = 0; i < 5; i++)
                    {
                        listTotal.Add(arrSum[i].ToString());
                    }
                    listResult.Add(listTotal);
                    result.ListData = listResult;

                }
                else if (param.Type.Equals("Report of vendor ( By item )"))
                {
                    DateOnly FromDate = new DateOnly();
                    DateOnly ToDate = new DateOnly();
                    var idPeriod = "";
                    if (param.Term != null)
                    {
                        var term = context.InvCalendarTerms.FirstOrDefault(x => x.Active == true && x.Term.Equals(param.Term));
                        idPeriod = term.Id.ToString();
                        FromDate = term.TimeFrom.Value;
                        ToDate = term.TimeTo.Value;
                    }
                    else
                    {
                        FromDate = DateOnly.FromDateTime(DateTime.ParseExact(param.FromDate, "dd-MM-yyyy", null));
                        ToDate = DateOnly.FromDateTime(DateTime.ParseExact(param.ToDate, "dd-MM-yyyy", null));
                    }
                    var listSnpDetail = context.InvSnpDetails.Include(x => x.Snp).Where(x => x.Active == true && FromDate <= x.CheckDate && x.CheckDate <= ToDate).ToList();
                    var listSnp = context.InvSnps.Where(x => x.Active == true && x.Product.Equals(param.Product) && x.PeriodId.ToString().Equals(idPeriod)).ToList();
                    List<SnpKindView> listSnpKind = new List<SnpKindView>();
                    foreach (var item in listSnp)
                    {
                        var list = listSnpDetail.Where(x => x.SnpId == item.Id).ToList();
                        int timeOk = list.Where(x => x.Differ == 0).ToList().Count();
                        int timePlus = list.Where(x => x.Differ > 0).ToList().Count();
                        int timeMinus = list.Where(x => x.Differ < 0).ToList().Count();
                        var status = "";

                        if (timePlus == 0 && timeOk == 0 && timeMinus == 0)
                        {
                            status = "NY";
                        }
                        else if (timePlus > 0 && timeMinus > 0)
                        {
                            status = "Unstable";
                        }
                        else if (timeOk > 0 && timePlus == 0 && timeMinus == 0)
                        {
                            status = "OK";
                        }
                        else if (timeMinus == 0 && timePlus > 0)
                        {
                            status = "Plus";
                        }
                        else if (timePlus == 0 && timeMinus > 0)
                        {
                            status = "Minus";
                        }
                        listSnpKind.Add(new SnpKindView()
                        {
                            Kind = item.Vendor.ToLower(),
                            Status = status
                        });
                    }
                    int[] arrSum = new int[5] { 0, 0, 0, 0, 0 };
                    string[] listVendor = listSnp.Select(x => x.Vendor).Distinct().ToArray();
                    string[] listStatus = { "OK", "Plus", "Minus", "Unstable", "NY" };
                    foreach (var item in listVendor)
                    {
                        List<string> listTemp = new List<string>();
                        listTemp.Add(item);
                        int temp = 0;
                        foreach (var item1 in listStatus)
                        {
                            var count = listSnpKind.Where(x => x.Kind.ToLower().Equals(item.ToLower()) && x.Status.Equals(item1)).Count();
                            listTemp.Add(count.ToString());
                            arrSum[temp] += count;
                            temp++;
                        }
                        listResult.Add(listTemp);
                    }
                    List<string> listTotal = new List<string>();
                    listTotal.Add("Total");
                    for (int i = 0; i < 5; i++)
                    {
                        listTotal.Add(arrSum[i].ToString());
                    }
                    listResult.Add(listTotal);
                    result.ListData = listResult;

                }
                else if (param.Type.Equals("Report by time check"))
                {
                    //DateOnly? now = DateOnly.FromDateTime(DateTime.Now);
                    var period = context.InvCalendarTerms.FirstOrDefault(x => x.Active == true && x.Term.Equals(param.Term));
                    var listSnpDetail = context.InvSnpDetails.Include(x => x.Snp).Where(x => x.Active == true && period.TimeFrom <= x.CheckDate && x.CheckDate <= period.TimeTo && x.Snp.Product.Equals(param.Product)).ToList();
                    int? max = listSnpDetail.Select(x => x.Time).Max();
                    List<SnpObject> listValue = new List<SnpObject>();
                    for (var i = period.TimeFrom; ((i.Value.Month <= period.TimeTo.Value.Month && i.Value.Year == period.TimeTo.Value.Year) || i.Value.Year < period.TimeTo.Value.Year); i = i.Value.AddMonths(1))
                    {
                        List<string> listTemp = new List<string>();
                        List<List<string>> listTempValue = new List<List<string>>();
                        var listByMonth = listSnpDetail.Where(x => x.CheckDate.Value.Month == i.Value.Month && x.CheckDate.Value.Year == i.Value.Year);
                        listTemp.Add(">0");
                        var total1 = 0;
                        for (int y = 1; y <= max; y++)
                        {
                            var count = listByMonth.Where(x => x.Differ > 0 && x.Time == y).Count();
                            total1 += count;
                            listTemp.Add(count.ToString());
                        }
                        listTemp.Add(total1.ToString());
                        listTempValue.Add(listTemp);
                        listTemp = new List<string>();

                        listTemp.Add("<0");
                        var total2 = 0;
                        for (int y = 1; y <= max; y++)
                        {
                            var count = listByMonth.Where(x => x.Differ < 0 && x.Time == y).Count();
                            total2 += count;
                            listTemp.Add(count.ToString());
                        }
                        listTemp.Add(total2.ToString());
                        listTempValue.Add(listTemp);
                        listTemp = new List<string>();

                        listTemp.Add("0");
                        var total3 = 0;
                        for (int y = 1; y <= max; y++)
                        {
                            var count = listByMonth.Where(x => x.Differ == 0 && x.Time == y).Count();
                            total3 += count;
                            listTemp.Add(count.ToString());
                        }
                        listTemp.Add(total3.ToString());
                        listTempValue.Add(listTemp);

                        listValue.Add(new SnpObject()
                        {
                            Month = i.Value.ToString("MMM"),
                            ListValue = listTempValue
                        });
                    }
                    result.ListObject = listValue;
                    result.CountTime = max.Value;
                }
                else if (param.Type.Equals("Report of vendor ( By month )"))
                {
                    //DateOnly? now = DateOnly.FromDateTime(DateTime.Now);
                    //var period = context.InvCalendarTerms.FirstOrDefault(x => x.Active == true && x.TimeFrom <= now && now <= x.TimeTo);
                    var period = context.InvCalendarTerms.FirstOrDefault(x => x.Active == true && x.Term.Equals(param.Term));
                    var listSnpDetail = context.InvSnpDetails.Include(x => x.Snp).Where(x => x.Active == true && period.TimeFrom <= x.CheckDate && x.CheckDate <= period.TimeTo && x.Snp.Product.Equals(param.Product)).ToList();
                    var listSnp = context.InvSnps.Where(x => x.Active == true && x.Product.Equals(param.Product)).ToList();
                    var max = 0;
                    var listMonth = new List<string>();
                    for (var i = period.TimeFrom; ((i.Value.Month <= period.TimeTo.Value.Month && i.Value.Year == period.TimeTo.Value.Year) || i.Value.Year <= period.TimeTo.Value.Year); i = i.Value.AddMonths(1))
                    {
                        max += 3;
                        listMonth.Add(i.Value.ToString("MMM-yy"));
                    };
                    result.ListMonth = listMonth;
                    string[] listVendor = listSnp.Select(x => x.Vendor).Distinct().ToArray();
                    string[] listStatus = { "OK", "Plus", "Minus" };
                    int[] arrSum = new int[max];
                    string[] arrStatus = new string[max];
                    for (int i = 0; i < max; i++)
                    {
                        arrSum[i] = 0;
                    }
                    foreach (var item in listVendor)
                    {
                        var listDetailVendor = listSnpDetail.Where(x => x.Snp.Vendor.Equals(item)).ToList();
                        List<string> listTemp = new List<string>();
                        listTemp.Add(item);
                        int temp = 0;
                        int temp1 = 0;
                        for (var i = period.TimeFrom; ((i.Value.Month <= period.TimeTo.Value.Month && i.Value.Year <= period.TimeTo.Value.Year) || i.Value.Year <= period.TimeTo.Value.Year); i = i.Value.AddMonths(1))
                        {
                            var listDetailVendor1 = listDetailVendor.Where(x => x.CheckDate.Value.Month == i.Value.Month && x.CheckDate.Value.Year == i.Value.Year).ToList();
                            foreach (var item1 in listStatus)
                            {
                                var count = 0;
                                if (item1.Equals("OK"))
                                {
                                    count = listDetailVendor1.Where(x => x.Differ == 0).Count();
                                }
                                else if (item1.Equals("Plus"))
                                {
                                    count = listDetailVendor1.Where(x => x.Differ > 0).Count();
                                }
                                else
                                {
                                    count = listDetailVendor1.Where(x => x.Differ < 0).Count();
                                }
                                listTemp.Add(count.ToString());
                                arrSum[temp] += count;
                                temp++;
                            }
                            //var countMonth = 0;
                            //for (int x = temp1; x < temp; x++)
                            //{
                            //    countMonth += arrSum[x];
                            //}
                            temp1 += 3;
                        }

                        listResult.Add(listTemp);
                    }
                    var countMonth = 0;
                    var tong = arrSum[0] + arrSum[1] + arrSum[2];
                    for (int x = 0; x < arrSum.Length; x++)
                    {
                        countMonth++;
                        if (countMonth == 4)
                        {
                            countMonth = 1;
                            tong = arrSum[x] + arrSum[x + 1] + arrSum[x + 2];
                        }

                        arrStatus[x] += (double)tong == 0 ? "0%" : ((((double)arrSum[x] / (double)tong) * 100).FormatDouble().ToString() + "%");
                    }
                    List<string> listTemp1 = new List<string>();
                    listTemp1.Add("Total");
                    foreach (var item in arrSum)
                    {
                        listTemp1.Add(item.ToString());
                    }
                    listResult.Add(listTemp1);
                    listTemp1 = new List<string>();
                    listTemp1.Add("Status");
                    foreach (var item in arrStatus)
                    {
                        listTemp1.Add(item);
                    }
                    listResult.Add(listTemp1);
                    result.ListData = listResult;
                }
                return result;
            }
            catch (Exception e)
            {
                return new SnpReport();
            }
        }
        [HttpPost("edit-calendar-term")]
        public async Task<CommonResponse> EditCalendarTerm(CalendarTermParamAdd rq)
        {
            var res = new CommonResponse()
            {
                Error = false,
                Message = "Successful !",
                Status = 200
            };
            try
            {
                var user = GetCurrentUser();
                var term = context.InvCalendarTerms.FirstOrDefault(x => x.Active == true && x.Term.ToUpper().Equals(rq.Term.ToUpper()));
                if (term != null)
                {
                    term.TimeFrom = DateOnly.FromDateTime(DateTime.ParseExact(rq.TimeFrom, "dd-MM-yyyy", null));
                    term.TimeTo = DateOnly.FromDateTime(DateTime.ParseExact(rq.TimeTo, "dd-MM-yyyy", null));
                    term.ModifiedBy = user.UserName;
                    term.ModifiedDate = DateTime.Now.SetKindUtc();
                }
                context.SaveChanges();
                res.Error = false;
                res.Message = "Successful !";
                res.Status = 200;
            }
            catch (Exception e)
            {
                //SendMailError(e);
                res.Error = true;
                res.Message = e.Message;
                res.Status = 400;
            }
            return res;
        }
        [HttpPost("edit-snp")]
        public async Task<CommonResponse> EditSnp(SnpParamEdit rq)
        {
            var res = new CommonResponse()
            {
                Error = false,
                Message = "Successful !",
                Status = 200
            };
            try
            {
                var user = GetCurrentUser();
                var snp = context.InvSnps.Include(x => x.Period).FirstOrDefault(x => x.Active == true && x.Period.Term.ToUpper().Equals(rq.term) && x.PartNo.ToUpper().Equals(rq.partNo.ToUpper()) && x.Vendor.ToUpper().Equals(rq.vendor.ToUpper()));
                if (snp != null)
                {
                    var snpDetail = context.InvSnpDetails.FirstOrDefault(x => x.Active == true && x.SnpId == snp.Id && x.Time == rq.time);
                    if (snpDetail != null)
                    {
                        snpDetail.SnpCheck = rq.snp;
                        snpDetail.Actual = rq.actual;
                        snpDetail.Differ = rq.actual - rq.snp;
                        snpDetail.Ratio = (rq.actual - rq.snp) / rq.snp;
                        snpDetail.ProductionLot = rq.productionLot;
                        snpDetail.DetectedBy = rq.detectedBy;
                        snpDetail.CheckDate = DateOnly.FromDateTime(DateTime.ParseExact(rq.detectedDate, "dd-MM-yyyy", null));
                        snpDetail.ModifiedBy = user.UserName;
                        snpDetail.ModifiedDate = DateTime.Now.SetKindUtc();
                    }
                }
                else
                {
                    res.Error = true;
                    res.Message = "SNP not exist";
                    res.Status = 400;
                }
                context.SaveChanges();
                res.Error = false;
                res.Message = "Successful !";
                res.Status = 200;
            }
            catch (Exception e)
            {
                //SendMailError(e);
                res.Error = true;
                res.Message = e.Message;
                res.Status = 400;
            }
            return res;
        }

        [HttpGet("excute-calc-op1/{product}")]
        public async Task<CommonResponse> ExcuteCalcOp1(string product)
        {
            var res = new CommonResponse()
            {
                Error = false,
                Message = "Successful !",
                Status = 200
            };
            try
            {
                //var dateNow = DateOnly.FromDateTime(DateTime.Now);
                //var calendarTerm = await context.InvCalendarTerms.FirstOrDefaultAsync(x => x.Active == true && x.TimeFrom <= dateNow && x.TimeTo >= dateNow);

                //if (calendarTerm != null)
                //{
                //invJob.SaveOutput1Inventory(product);
                var monitoringApi = JobStorage.Current.GetMonitoringApi();
                var countSucess = monitoringApi.SucceededListCount();
                var enqueuedJobs = monitoringApi.SucceededJobs(0, (int)countSucess);

                var jobExists = enqueuedJobs.FirstOrDefault(job => job.Value.Job != null && job.Value.Job.Method.Name == "SaveOutput1InventoryHistory" && job.Value.Job.Arguments[0].Contains(product));
                //var backgroundJobClient = new BackgroundJobClient();
                if (jobExists.Value != null)
                {
                    // Công việc đã được enqueue trước đó thì chỉ việc chạy lại
                    _bgJobClient.Requeue(jobExists.Key);
                }
                else
                {
                    // Công việc chưa được enqueue, tạo mới trong CSDL
                    _bgJobClient.Enqueue<IInventorylJob>(x => x.SaveOutput1InventoryHistory(product));
                }
                //}
                //else
                //{
                //    res.Status = (int)HttpStatusCode.BadRequest;
                //    res.Message = "This time is not belong to of the calendar term!";
                //    res.Error = true;
                //    return res;
                //}

                res.Error = false;
                res.Message = "Successful !";
                res.Status = 200;
            }
            catch (Exception e)
            {
                //SendMailError(e);
                res.Error = true;
                res.Message = e.Message;
                res.Status = 400;
            }
            return res;
        }

        [HttpPost("filter-output-part-inv-his")]
        public async Task<OpPartInvHisModel> FilterOpPartInvHis(OpPartInvHisParams param)
        {
            try
            {
                OpPartInvHisModel result = new OpPartInvHisModel()
                {
                    currentPage = param.Page,
                    recordPerPage = param.RecordsPerPage
                };

                var lstResult = new List<OpPartInvHisView>();
                var today = DateOnly.FromDateTime(DateTime.Now);
                var termNow = context.InvCalendarTerms.FirstOrDefault(x => x.Active == true && x.TimeFrom <= today && today <= x.TimeTo);
                var lstTerm = context.InvCalendarTerms.Where(x => x.Term == termNow.Term || x.TimeTo < today).OrderByDescending(x => x.TimeFrom).Take(3).OrderBy(x => x.TimeFrom).ToList();
                var lstOutput = context.InvOutputPartHis.AsNoTracking().Where(x => x.Active == true && x.Product.ToUpper() == param.Product.ToUpper()).ToList();
                //var query = lstOutput.Where(x => x.Active == true && x.Term == termNow.Term && x.Product.ToUpper() == param.Product.ToUpper());
                lstOutput = !string.IsNullOrEmpty(param.PartNo) ? lstOutput.Where(x => x.PartNo != null && x.PartNo.ToUpper().Contains(param.PartNo.ToUpper())).ToList() : lstOutput;
                lstOutput = !string.IsNullOrEmpty(param.Vendor) ? lstOutput.Where(x => x.Vendor != null && x.Vendor.ToUpper().Contains(param.Vendor.ToUpper())).ToList() : lstOutput;
                result.LstTerm = lstTerm.Select(x => x.Term).ToList();
                var query = lstOutput.Where(x => x.Term == termNow.Term).GroupBy(x => new { x.PartNo, x.Vendor, x.Dim }).Select(g => g.First()).ToList();
                var model = query.Paginate(param).ToList();

                var lenghtUrgent = model.Max(x => x.UrgentCase?.Length ?? 0);
                var lstUrgent = new List<string?>();
                for (int i = 0; i < lenghtUrgent; i++)
                {
                    lstUrgent.Add("Date happened " + (i + 1));
                }
                result.LstUrgentDate = lstUrgent;
                foreach (var item in model)
                {
                    var lstSnp = new List<string>();
                    var lstPi = new List<string>();
                    var lstDefect = new List<string>();
                    var lstSOmmited = new List<string>();
                    foreach (var term in lstTerm)
                    {
                        var itemTerm = lstOutput.FirstOrDefault(x => x.Term == term.Term && x.PartNo == item.PartNo && x.Vendor == item.Vendor);
                        lstSnp.Add(itemTerm != null ? itemTerm.SpCheckHis : "");
                        lstPi.Add(itemTerm != null ? itemTerm.PiResultHis : "");
                        lstDefect.Add(itemTerm != null ? itemTerm.DefectHis : "");
                        lstSOmmited.Add(itemTerm != null ? itemTerm.OmmitedHis : "");
                    }
                    var urgentDate = new List<string>();
                    for (int i = 0; i < lenghtUrgent; i++)
                    {
                        urgentDate.Add((item.UrgentCase == null || item.UrgentCase.Length == 0) ? null : item.UrgentCase[i]);
                    }
                    lstResult.Add(new OpPartInvHisView
                    {
                        PartNo = item.PartNo,
                        Dim = item.Dim,
                        Cp = item.Cp,
                        PartName = item.PartName,
                        Vendor = item.Vendor,
                        CoMain = item.CoMain,
                        Model = item.Model,
                        DesCom = item.DesCom,
                        OrderMethod = item.OrderMethod,
                        UnitPrice = item.UnitPrice,
                        SnpBox = item.SnpBox,
                        PackingMethod = item.PackingMethod,
                        KindOfPart = item.KindOfPart,
                        TypeOfPart = item.TypeOfPart,
                        ProcessUsing = item.ProcessUsing,
                        QtyKeepLine = item.QtyKeepLine,
                        TotalLt = item.TotalLt,
                        Sp = item.Sp,
                        InvControlMethod = item.InvControlMethod,
                        SpCheckHis = lstSnp,
                        PiResultHis = lstPi,
                        OmmitedHis = lstSOmmited,
                        UrgentCase = urgentDate,
                        DefectdHis = lstDefect
                    });

                }
                result.lstModel = lstResult;
                result.totalRecords = query.Count;
                result.totalPage = (int)Math.Ceiling((decimal)result.totalRecords / param.RecordsPerPage);
                result.fromRecord = model.Count == 0 ? 0 : (result.currentPage - 1) * result.recordPerPage + 1;
                result.toRecord = (int)Math.Min(result.totalRecords, result.currentPage * result.recordPerPage);
                result.currentPage = result.totalPage < result.currentPage ? result.totalPage : result.currentPage;
                return result;
            }
            catch (Exception)
            {
                return new OpPartInvHisModel()
                {
                    currentPage = param.Page,
                    recordPerPage = param.RecordsPerPage
                };
            }
        }

        [HttpGet("get-file-output-part-his/{product}/{date}")]
        public List<string> GetFileChangingByDate(string product, string date)
        {
            //var time = DateTime.Now.ToString("yyyy-MM-dd");
            string folderPath = Path.Combine(outputPathOri, "8. Inventory\\InvOp1" + product.ToUpper());
            string[] files = Directory.GetFiles(folderPath, "Output_Part_Inv_His_" + product.ToUpper() + "_" + date + "*");

            var sortedFiles = files.OrderByDescending(f => new FileInfo(f).CreationTime).ToList();

            return sortedFiles;
            //  return files.ToList();
        }
        [HttpPost("filter-balance-part-list")]
        public BalancePartListViewModel FilterBalancePartList(BalancePartListParam param)
        {
            try
            {
                var result = new BalancePartListViewModel();
                var lstResult = new List<BalancePartListView>();


                var model = context.InvBalancePartLists.Where(x => x.Active == true).AsQueryable();
                if (!string.IsNullOrEmpty(param.Term)) model = model.Where(x => x.Term.Contains(param.Term));
                if (!string.IsNullOrEmpty(param.Product)) model = model.Where(x => x.Product.Contains(param.Product));
                if (!string.IsNullOrEmpty(param.PartNo)) model = model.Where(x => x.PartNo.Contains(param.PartNo));
                if (!string.IsNullOrEmpty(param.PartName)) model = model.Where(x => x.PartName.Contains(param.PartName));
                if (!string.IsNullOrEmpty(param.Vendor)) model = model.Where(x => x.Vendor.Contains(param.Vendor));
                if (!string.IsNullOrEmpty(param.Sp)) model = model.Where(x => x.Sp.Contains(param.Sp));
                var model2 = model.Skip((param.Page - 1) * param.RecordsPerPage).Take(param.RecordsPerPage).ToList();
                foreach (var item in model2)
                {

                    lstResult.Add(new BalancePartListView()
                    {
                        Term = item.Term,
                        Product = item.Product,
                        PartNo = item.PartNo,
                        PartName = item.PartName,
                        Vendor = item.Vendor,
                        Sp = item.Sp,
                    });
                }


                var c = model.Count();
                result.lstModel = lstResult;
                result.toRecord = (int)Math.Min(result.totalRecords, result.currentPage * result.recordPerPage);
                result.totalPage = (int)Math.Ceiling((decimal)c / param.RecordsPerPage);
                result.totalRecords = c;
                result.recordPerPage = param.RecordsPerPage;
                result.currentPage = param.Page;
                result.fromRecord = c == 0 ? 0 : (result.currentPage - 1) * result.recordPerPage + 1;
                return result;
            }
            catch (Exception)
            {
                return new BalancePartListViewModel();
            }
        }
        [HttpPost("import-balance-part-list")]
        public async Task<CommonResponse> ImportBalancePartList([FromForm] IFormFile file)
        {
            var result = new CommonResponse()
            {
                Error = false,
                Message = "",
                Status = (int)HttpStatusCode.BadRequest
            };
            try
            {
                var u = GetCurrentUser();
                var listCheck = context.InvBalancePartLists.Select(x => x.Term.ToUpper() + x.PartNo + x.Product).ToList();
                //context.InvCalendarTerms.RemoveRange(listRemove);
                using (var memoStream = new MemoryStream())
                {
                    file.CopyTo(memoStream);
                    ExcelPackage.LicenseContext = LicenseContext.NonCommercial;
                    using (var package = new ExcelPackage(memoStream))
                    {
                        var worksheet = package.Workbook.Worksheets[0];

                        var rowCount = worksheet.Dimension?.Rows;

                        if (rowCount.HasValue && rowCount.Value >= 2)
                        {
                            for (int row = 2; row <= rowCount.Value; row++)
                            {

                                var term = Convert.ToString(worksheet.Cells["A" + row].Value);
                                var product = Convert.ToString(worksheet.Cells["B" + row].Value).ToUpper();
                                product = product.Contains("IJ") ? " IJP" : "LBP";
                                var partNo = Convert.ToString(worksheet.Cells["C" + row].Value);
                                if (listCheck.Contains(term.ToUpper()+partNo+product))
                                {
                                    result.Status = (int)HttpStatusCode.BadRequest;
                                    result.Message = "Term already exist";
                                    result.Error = true;
                                    return result;
                                }
                                var partName = Convert.ToString(worksheet.Cells["D" + row].Value);
                                var vendor = Convert.ToString(worksheet.Cells["E" + row].Value);
                                var sp = Convert.ToString(worksheet.Cells["F" + row].Value);

                                var md = new InvBalancePartList()
                                {
                                    CreatedBy = u.UserName,
                                    Term = term,
                                    Product = product,
                                    PartNo = partNo,
                                    PartName = partName,
                                    Vendor = vendor,
                                    Sp = sp,
                                };
                                context.InvBalancePartLists.Add(md);
                            }
                        }
                    }
                }
                context.SaveChanges();

                result.Status = (int)HttpStatusCode.OK;
                result.Message = "Success";
                result.Error = false;
                return result;
            }
            catch (Exception e)
            {
                result.Status = (int)HttpStatusCode.BadRequest;
                result.Message = e.Message;
                result.Error = true;
                return result;
            }
        }
        [HttpPost("add-balance-part-list")]
        public async Task<CommonResponse> AddBalancePartList(BalancePartListParamAdd rq)
        {
            var res = new CommonResponse()
            {
                Error = false,
                Message = "Successful !",
                Status = 200
            };
            try
            {
                var user = GetCurrentUser();
                await context.InvBalancePartLists.AddAsync(new InvBalancePartList()
                {
                    Term = rq.Term,
                    Product = rq.Product,
                    PartNo = rq.PartNo,
                    PartName = rq.PartName,
                    Vendor = rq.Vendor,
                    Sp = rq.Sp,
                    CreatedBy = user.UserName
                });
                context.SaveChanges();
                res.Error = false;
                res.Message = "Successful !";
                res.Status = 200;
            }
            catch (Exception e)
            {
                //SendMailError(e);
                res.Error = true;
                res.Message = e.Message;
                res.Status = 400;
            }
            return res;
        }
        [HttpPost("edit-balance-part-list")]
        public async Task<CommonResponse> EditBalancePartList(BalancePartListParamAdd rq)
        {
            var res = new CommonResponse()
            {
                Error = false,
                Message = "Successful !",
                Status = 200
            };
            try
            {
                var user = GetCurrentUser();
                var term = context.InvBalancePartLists.FirstOrDefault(x => x.Active == true && x.Term.ToUpper().Equals(rq.Term.ToUpper()));
                if (term != null)
                {
                    term.Product = rq.Product;
                    term.PartNo = rq.PartNo;
                    term.PartName = rq.PartName;
                    term.Vendor = rq.Vendor;
                    term.Sp = rq.Sp;
                    term.ModifiedBy = user.UserName;
                    term.ModifiedDate = DateTime.Now.SetKindUtc();
                }
                context.SaveChanges();
                res.Error = false;
                res.Message = "Successful !";
                res.Status = 200;
            }
            catch (Exception e)
            {
                //SendMailError(e);
                res.Error = true;
                res.Message = e.Message;
                res.Status = 400;
            }
            return res;
        }
        [HttpPost("add-department-store")]
        public async Task<CommonResponse> AddDepartmentStore(DepartmentStoreParam rq)
        {
            var res = new CommonResponse()
            {
                Error = false,
                Message = "Successful !",
                Status = 200
            };
            try
            {
                var user = GetCurrentUser();
                var term = context.InvStoreInouts.FirstOrDefault(x => x.Active == true && x.Department.ToUpper().Equals(rq.Department.Trim().ToUpper()));
                if (term != null)
                {
                    term.StoreIn = rq.StoreIn;
                    term.StoreOut = rq.StoreOut;
                    term.ModifiedBy = user.UserName;
                    term.ModifiedDate = DateTime.Now.SetKindUtc();
                }
                else
                {
                    context.InvStoreInouts.Add(new InvStoreInout()
                    {
                        Department = rq.Department.Trim(),
                        StoreOut = rq.StoreOut,
                        StoreIn = rq.StoreIn,
                        CreatedBy = user.UserName,
                        CreatedDate = DateTime.Now.SetKindUtc(),
                        Active = true
                    });
                }
                context.SaveChanges();
                res.Error = false;
                res.Message = "Successful !";
                res.Status = 200;
            }
            catch (Exception e)
            {
                //SendMailError(e);
                res.Error = true;
                res.Message = e.Message;
                res.Status = 400;
            }
            return res;
        }
        [HttpPost("get-list-department")]
        public List<string> GetListDepartment()
        {

            try
            {
                return context.InvStoreInouts.Where(x => x.Active == true).Select(x => x.Department).ToList();
            }
            catch (Exception e)
            {
                return new List<string>();
            }
            return new List<string>();
        }
        [HttpPost("get-format-by-department")]
        public InvStoreInout? GetFormatByDepartment(string department)
        {

            try
            {

                return context.InvStoreInouts.FirstOrDefault(x => x.Active == true && x.Department.Equals(department));
            }
            catch (Exception e)
            {
                return null;
            }
            return null;
        }

        [HttpPost("import-actual-inout")]
        public async Task<CommonResponse> ImportActualInout([FromForm] UpdateActualParam param)
        {
            var result = new CommonResponse()
            {
                Error = false,
                Message = "",
                Status = (int)HttpStatusCode.BadRequest
            };
            try
            {
                var u = GetCurrentUser();
                List<InvUploadActual> listAdd = new List<InvUploadActual>();

                using (var memoStream = new MemoryStream())
                {
                    param.File.CopyTo(memoStream);
                    ExcelPackage.LicenseContext = LicenseContext.NonCommercial;
                    using (var package = new ExcelPackage(memoStream))
                    {
                        var worksheet = package.Workbook.Worksheets[0];

                        var rowCount = worksheet.Dimension?.Rows;

                        if (rowCount.HasValue && rowCount.Value > 3)
                        {

                            var store = context.InvStoreInouts.FirstOrDefault(x => x.Active == true && x.Department.Equals(param.Department));
                            var storeNpis = context.InvStoreInouts.FirstOrDefault(x => x.Active == true && x.Department.Contains("NPIS"));
                            var listActual = context.InvUploadActuals.Where(x => x.Active == true && x.Product.Equals(param.Product) && x.StoreInoutId == store.Id).ToList();
                            var listActualNpis = context.InvUploadActuals.Where(x => x.Active == true && x.Product.Equals(param.Product) && x.StoreInoutId == storeNpis.Id).ToList();
                            for (int row = 3; row <= rowCount.Value; row++)
                            {

                                var partNo = Convert.ToString(worksheet.Cells[row, 2].Value);
                                var vendor = Convert.ToString(worksheet.Cells[row, 3].Value);
                                var remain_last_day = Convert.ToString(worksheet.Cells[row, 3].Value).IsNullOrEmpty() ? 0 : Convert.ToDouble(worksheet.Cells[row, 4].Value);
                                List<double> store_in = new List<double>();
                                List<double> store_out = new List<double>();
                                var temp = 5;
                                foreach (var item in store.StoreIn)
                                {
                                    store_in.Add(Convert.ToDouble(worksheet.Cells[row, temp].Value));
                                    temp++;
                                }
                                foreach (var item in store.StoreOut)
                                {
                                    store_out.Add(Convert.ToDouble(worksheet.Cells[row, temp].Value));
                                    temp++;
                                }
                                var remainCalculate = Convert.ToDouble(worksheet.Cells[row, temp].Value);
                                temp++;
                                var actualRemain = Convert.ToDouble(worksheet.Cells[row, temp].Value);
                                temp++;
                                var differ = Convert.ToDouble(worksheet.Cells[row, temp].Value);
                                temp++;
                                var reason = Convert.ToString(worksheet.Cells[row, temp].Value);
                                temp++;
                                var lendingNo = Convert.ToString(worksheet.Cells[row, temp].Value);
                                temp++;
                                var slipNo = Convert.ToString(worksheet.Cells[row, temp].Value);
                                temp++;
                                DateOnly? fromDate = null;
                                try
                                {
                                    var date = Convert.ToDateTime(worksheet.Cells[row, temp].Value);
                                    fromDate = DateOnly.FromDateTime(date);
                                }
                                catch (Exception)
                                {
                                    result.Status = (int)HttpStatusCode.BadRequest;
                                    result.Message = "From date wrong format";
                                    result.Error = true;
                                    return result;
                                }
                                temp++;
                                DateOnly? toDate = null;
                                try
                                {
                                    var date = Convert.ToDateTime(worksheet.Cells[row, temp].Value);
                                    toDate = DateOnly.FromDateTime(date);
                                }
                                catch (Exception)
                                {
                                    result.Status = (int)HttpStatusCode.BadRequest;
                                    result.Message = "To date wrong format";
                                    result.Error = true;
                                    return result;
                                }
                                if (param.Department.Contains("NPIS"))
                                {
                                    var part = listActual.FirstOrDefault(x =>  x.PartNo.Equals(partNo) && x.FromDate == fromDate && x.ToDate == toDate );
                                    if(part != null)
                                    {
                                        part.ActualRemain = actualRemain;
                                        part.Differ = differ;
                                        part.Reason = reason;
                                        context.InvUploadActuals.Update(part);
                                    }
                                    else
                                    {
                                        listAdd.Add(new InvUploadActual()
                                        {
                                            CreatedDate = DateTime.Now.SetKindUtc(),
                                            CreatedBy = u.UserName,
                                            PartNo = partNo,
                                            Vendor = vendor,
                                            RemainLastDay = remain_last_day,
                                            StoreIn = store_in.ToArray(),
                                            StoreOut = store_out.ToArray(),
                                            StoreInoutId = store.Id,
                                            RemainCalculate = remainCalculate,
                                            ActualRemain = actualRemain,
                                            Differ = differ,
                                            Reason = reason,
                                            LendingNo = lendingNo,
                                            SlipNo = slipNo,
                                            FromDate = fromDate,
                                            ToDate = toDate,
                                            Product = param.Product
                                        });

                                    }

                                }
                                else
                                {
                                    var part = listActual.FirstOrDefault(x => x.PartNo.Equals(partNo) && x.Vendor.Equals(vendor) && x.FromDate == fromDate && x.ToDate == toDate);
                                    var partNPIS = listActualNpis.FirstOrDefault(x => x.PartNo.Equals(partNo) && x.Vendor.Equals(vendor) && x.FromDate == fromDate && x.ToDate == toDate);
                                    if (part != null)
                                    {
                                        if(partNPIS != null)
                                        {
                                            if(partNPIS.ActualRemain == null)
                                            {
                                                part.RemainLastDay = remain_last_day;
                                                part.StoreIn = store_in.ToArray();
                                                part.StoreOut = store_out.ToArray();
                                                part.StoreInoutId = store.Id;
                                                part.RemainCalculate = remainCalculate;
                                                part.ActualRemain = actualRemain;
                                                part.Differ = differ;
                                                part.Reason = reason;
                                                part.LendingNo = lendingNo;
                                                part.SlipNo = slipNo;
                                                context.InvUploadActuals.Update(part);
                                            }
                                        }
                                        else
                                        {
                                            part.RemainLastDay = remain_last_day;
                                            part.StoreIn = store_in.ToArray();
                                            part.StoreOut = store_out.ToArray();
                                            part.StoreInoutId = store.Id;
                                            part.RemainCalculate = remainCalculate;
                                            part.ActualRemain = actualRemain;
                                            part.Differ = differ;
                                            part.Reason = reason;
                                            part.LendingNo = lendingNo;
                                            part.SlipNo = slipNo;
                                            context.InvUploadActuals.Update(part);
                                        }
                                    }
                                    else
                                    {
                                        listAdd.Add(new InvUploadActual()
                                        {
                                            CreatedDate = DateTime.Now.SetKindUtc(),
                                            CreatedBy = u.UserName,
                                            PartNo = partNo,
                                            Vendor = vendor,
                                            RemainLastDay = remain_last_day,
                                            StoreIn = store_in.ToArray(),
                                            StoreOut = store_out.ToArray(),
                                            StoreInoutId = store.Id,
                                            RemainCalculate = remainCalculate,
                                            ActualRemain = actualRemain,
                                            Differ = differ,
                                            Reason = reason,
                                            LendingNo = lendingNo,
                                            SlipNo = slipNo,
                                            FromDate = fromDate,
                                            ToDate = toDate,
                                            Product = param.Product
                                        });
                                    }

                                }
                            }
                        }
                    }
                }
                context.InvUploadActuals.AddRange(listAdd);
                context.SaveChanges();

                result.Status = (int)HttpStatusCode.OK;
                result.Message = "Success";
                result.Error = false;
                return result;
            }
            catch (Exception e)
            {
                result.Status = (int)HttpStatusCode.BadRequest;
                result.Message = e.Message;
                result.Error = true;
                return result;
            }
        }
        [HttpPost("filter-actual-inout")]
        public ActualInoutModel FilterActualInout(ActualInoutParam param)
        {
            try
            {
                var result = new ActualInoutModel();
                var lstResult = new List<List<string>>();
                var c = 0;

                if (param.Department.ToUpper().Contains("NPIS"))
                {
                    if (!string.IsNullOrEmpty(param.Product))
                    {
                        var store = context.InvStoreInouts.FirstOrDefault(x => x.Department.ToUpper().Contains("NPIS"));
                        var model = context.InvUploadActuals.Include(x => x.StoreInout).Where(x => x.Active == true && x.StoreInoutId == store.Id).AsQueryable();
                        if (!string.IsNullOrEmpty(param.Product)) { model = model.Where(x => x.Product.ToUpper().Contains(param.Product.ToUpper())); }
                        if (!string.IsNullOrEmpty(param.PartNo)) { model = model.Where(x => x.PartNo.ToLower().Contains(param.PartNo.ToLower())); }
                        if (!string.IsNullOrEmpty(param.FromDate)) { var TimeFrom = DateOnly.FromDateTime(DateTime.ParseExact(param.FromDate, "dd-MM-yyyy", null)); model = model.Where(x => x.FromDate >= TimeFrom); }
                        if (!string.IsNullOrEmpty(param.ToDate)) { var TimeFrom = DateOnly.FromDateTime(DateTime.ParseExact(param.ToDate, "dd-MM-yyyy", null)); model = model.Where(x => x.ToDate <= TimeFrom); }


                        var model2 = model.Skip((param.Page - 1) * param.RecordsPerPage).Take(param.RecordsPerPage).ToList();
                        var temp = (param.Page - 1) * param.RecordsPerPage + 1;                      

                        foreach (var item in model2)
                        {
                            List<string> listTemp = new List<string>();
                            listTemp.Add(temp.ToString());
                            listTemp.Add(item.PartNo);
                            listTemp.Add(item.Vendor);
                            listTemp.Add(item.RemainLastDay != null ? item.RemainLastDay.Value.FormatDouble().ToString():"");
                            double? totalIn = 0;
                            foreach (var item1 in item.StoreIn)
                            {
                                listTemp.Add(item1.FormatDouble().ToString());
                            }
                            double? totalOut = 0;
                            foreach (var item1 in item.StoreOut)
                            {
                                listTemp.Add(item1.FormatDouble().ToString());
                            }
                            listTemp.Add(item.RemainCalculate!= null ?item.RemainCalculate.Value.FormatDouble().ToString():"0");
                            listTemp.Add(item.ActualRemain!= null ?item.ActualRemain.Value.FormatDouble().ToString():"");
                            listTemp.Add(item.Differ != null ?item.Differ.Value.FormatDouble().ToString():"");
                            listTemp.Add(item.Reason);
                            lstResult.Add(listTemp);
                            temp++;
                        }
                        c = model.Count();
                    }
                    else
                    {
                        c = 0;
                    }

                }
                else
                {
                    var model = context.InvUploadActuals.Include(x => x.StoreInout).Where(x => x.Active == true).AsQueryable();
                    if (!string.IsNullOrEmpty(param.Product)) { model = model.Where(x => x.Product.ToUpper().Contains(param.Product.ToUpper())); }
                    if (!string.IsNullOrEmpty(param.PartNo)) { model = model.Where(x => x.PartNo.ToLower().Contains(param.PartNo.ToLower())); }
                    if (!string.IsNullOrEmpty(param.Department)) { model = model.Where(x => x.StoreInout.Department.ToUpper().Contains(param.Department.Trim().ToUpper())); }
                    if (!string.IsNullOrEmpty(param.FromDate)) { var TimeFrom = DateOnly.FromDateTime(DateTime.ParseExact(param.FromDate, "dd-MM-yyyy", null)); model = model.Where(x => x.FromDate >= TimeFrom); }
                    if (!string.IsNullOrEmpty(param.ToDate)) { var TimeFrom = DateOnly.FromDateTime(DateTime.ParseExact(param.ToDate, "dd-MM-yyyy", null)); model = model.Where(x => x.ToDate <= TimeFrom); }

                    var model2 = model.Skip((param.Page - 1) * param.RecordsPerPage).Take(param.RecordsPerPage).ToList();
                    var temp = (param.Page - 1) * param.RecordsPerPage + 1;
                    foreach (var item in model2)
                    {
                        List<string> listTemp = new List<string>();
                        listTemp.Add(temp.ToString());
                        listTemp.Add(item.PartNo);
                        listTemp.Add(item.Vendor);
                        listTemp.Add(item.RemainLastDay.Value.FormatDouble().ToString());
                        foreach (var item1 in item.StoreIn)
                        {
                            listTemp.Add(item1.ToString());
                        }
                        foreach (var item2 in item.StoreOut)
                        {
                            listTemp.Add(item2.ToString());
                        }
                        listTemp.Add(item.RemainCalculate.Value.FormatDouble().ToString());
                        listTemp.Add(item.ActualRemain.Value.FormatDouble().ToString());
                        listTemp.Add(item.Differ.Value.FormatDouble().ToString());
                        listTemp.Add(item.Reason);
                        listTemp.Add(item.LendingNo);
                        listTemp.Add(item.SlipNo);
                        listTemp.Add(item.CreatedBy);
                        listTemp.Add(item.CreatedDate.Value.UnsetKindUtc().ToString("HH:mm:ss "));
                        listTemp.Add(item.CreatedDate.Value.ToString("dd-MM-yyyy"));
                        lstResult.Add(listTemp);
                        temp++;
                    }
                    c = model.Count();
                }


                result.listData = lstResult;
                result.toRecord = (int)Math.Min(result.totalRecords, result.currentPage * result.recordPerPage);
                result.totalPage = (int)Math.Ceiling((decimal)c / param.RecordsPerPage);
                result.totalRecords = c;
                result.recordPerPage = param.RecordsPerPage;
                result.currentPage = param.Page;
                result.fromRecord = c == 0 ? 0 : (result.currentPage - 1) * result.recordPerPage + 1;
                return result;
            }
            catch (Exception e)
            {
                return new ActualInoutModel();
            }
        }
        [HttpPost("set-time-pick-up")]
        public CommonResponse SetTimePickUp(TimePickUpParam rq)
        {
            var res = new CommonResponse()
            {
                Error = false,
                Message = "Successful !",
                Status = 200
            };
            try
            {
                var user = GetCurrentUser();
                var time = context.InvTimePickUps.FirstOrDefault();
                if (time != null)
                {
                    time.FromTime = DateTime.ParseExact(rq.FromTime, "dd-MM-yyyy HH:mm:ss", null).SetKindUtc();
                    time.ToTime = DateTime.ParseExact(rq.ToTime, "dd-MM-yyyy HH:mm:ss", null).SetKindUtc();
                    time.ModifiedBy = user.UserName;
                    time.ModifiedDate = DateTime.Now.SetKindUtc();
                }
                else
                {
                    context.InvTimePickUps.Add(new InvTimePickUp()
                    {
                        FromTime = DateTime.ParseExact(rq.FromTime, "dd-MM-yyyy HH:mm:ss", null).SetKindUtc(),
                        ToTime = DateTime.ParseExact(rq.ToTime, "dd-MM-yyyy HH:mm:ss", null).SetKindUtc(),
                        CreatedDate = DateTime.Now.SetKindUtc(),
                        CreatedBy = user.UserName,
                        Active = true
                    });
                }

                context.SaveChanges();
                res.Error = false;
                res.Message = "Successful !";
                res.Status = 200;
            }
            catch (Exception e)
            {
                //SendMailError(e);
                res.Error = true;
                res.Message = e.Message;
                res.Status = 400;
            }
            return res;
        }
        [HttpGet("get-time-pick-up")]
        public List<List<int>> GetTimePickUp()
        {

            try
            {
                List<List<int>> result = new List<List<int>>();
                var time = context.InvTimePickUps.FirstOrDefault();
                if (time != null)
                {
                    List<int> temp = new List<int>();
                    temp.Add(int.Parse(time.FromTime.Value.UnsetKindUtc().ToString("yyyy")));
                    temp.Add(int.Parse(time.FromTime.Value.UnsetKindUtc().ToString("MM")) - 1);
                    temp.Add(int.Parse(time.FromTime.Value.UnsetKindUtc().ToString("dd")));
                    temp.Add(int.Parse(time.FromTime.Value.UnsetKindUtc().ToString("HH")));
                    temp.Add(int.Parse(time.FromTime.Value.UnsetKindUtc().ToString("mm")));
                    temp.Add(int.Parse(time.FromTime.Value.UnsetKindUtc().ToString("ss")));
                    result.Add(temp);
                    List<int> temp1 = new List<int>();
                    temp1.Add(int.Parse(time.ToTime.Value.UnsetKindUtc().ToString("yyyy")));
                    temp1.Add(int.Parse(time.ToTime.Value.UnsetKindUtc().ToString("MM")) - 1);
                    temp1.Add(int.Parse(time.ToTime.Value.UnsetKindUtc().ToString("dd")));
                    temp1.Add(int.Parse(time.ToTime.Value.UnsetKindUtc().ToString("HH")));
                    temp1.Add(int.Parse(time.ToTime.Value.UnsetKindUtc().ToString("mm")));
                    temp1.Add(int.Parse(time.ToTime.Value.UnsetKindUtc().ToString("ss")));
                    result.Add(temp1);
                }
                return result;
            }
            catch (Exception e)
            {
                return new List<List<int>>();
            }
            return new List<List<int>>();
        }
        [HttpPost("get-list-term-snp")]
        public SnpTime GetListTermSnp()
        {

            try
            {
                return new SnpTime()
                {
                    listData = context.InvCalendarTerms.Where(x => x.Active == true).Select(x => x.Term).ToList()
                };
            }
            catch (Exception e)
            {
                return new SnpTime();
            }
            return new SnpTime();
        }
        [HttpGet("excute-balance-op1/{product}")]
        [AllowAnonymous]
        public async Task<CommonResponse> ExcuteBalaceOp1(string product)
        {
            var res = new CommonResponse()
            {
                Error = false,
                Message = "Successful !",
                Status = 200
            };
            try
            {
                var config = new MapperConfiguration(cfg => cfg.CreateMap<MvInvE700Lbp1, MvInvE700Ij1>());
                var mapper = config.CreateMapper();
                var listIp2 = await context.InvUploadActuals.AsNoTracking().Where(x => x.Active == true).ToListAsync();
                var timePickup = context.InvTimePickUps.FirstOrDefault();
                //var DateRecently = listIp2.OrderByDescending(x => x.ToDate).First();
                var DateRecently = new InvUploadActual()
                {
                    FromDate = DateOnly.FromDateTime(timePickup.FromTime.Value),
                    ToDate = DateOnly.FromDateTime(timePickup.ToTime.Value)
                };
                var DateRecentlyPast = listIp2.Where(x=>x.ToDate < DateRecently.FromDate).OrderByDescending(x => x.ToDate).First();
                listIp2 = listIp2.Where(x => x.FromDate == DateRecently.FromDate && x.ToDate == DateRecently.ToDate).ToList();
                var listIp1 = await context.InvBalancePartLists.AsNoTracking().Where(x => x.Active == true && x.Product.Equals(product)).ToListAsync();
                //var listD800 = await context.VInvD800s.AsNoTracking().Where(x => x.Product.Equals(product)).ToListAsync();
                var listD800 = await context.InvD800s.AsNoTracking().Where(x => x.Product.Equals(product)).ToListAsync();
                var listStructure = await context.VInvStructures.AsNoTracking().Where(x => x.Product.Equals(product)).ToListAsync();
                var listStore = await context.InvStoreInouts.AsNoTracking().Where(x => x.Active == true && !x.Department.Equals("NPIS movement")).ToListAsync();
                var NPIS = context.InvStoreInouts.FirstOrDefault(x => x.Active == true && x.Department.Equals("NPIS movement"));
                var listNPIS = listIp2.Where(x => x.StoreInoutId == NPIS.Id).ToList();
                //var listLendingAssy = await context.VlinkageLendingPartAssyPcbIjs.ToListAsync();
                //var listLendingPdc = await context.VlinkageLendingPartPdcIjs.ToListAsync();
                var listLendingAssy = await context.InvLendingPartAssyPcbIjs.ToListAsync();
                var listLendingPdc = await context.InvLendingPartPdcIjs.ToListAsync();
                var listE700 = new List<MvInvE700Ij1>();
                var listOp1 = context.InvBalanceOp1s.Where(x => x.Active == true && x.FromDate == DateRecently.FromDate && x.ToDate == DateRecently.ToDate && x.Product.Equals(product));
                var listOp1Past = context.InvBalanceOp1s.Where(x => x.Active == true && x.FromDate == DateRecentlyPast.FromDate && x.ToDate == DateRecentlyPast.ToDate && x.Product.Equals(product));
                if (product.Equals("IJP"))
                {
                    listE700 = await context.MvInvE700Ij1s.ToListAsync();
                }
                else
                {
                    var e700Lbp = await context.MvInvE700Lbp1s.AsNoTracking().ToListAsync();
                    listE700 = mapper.Map<List<MvInvE700Lbp1>, List<MvInvE700Ij1>>(e700Lbp);
                }
                var listTemp = new List<InvBalanceOp1>();
                var listResult = new List<InvBalanceOp1>();
                foreach (var item in listIp1)
                {
                    InvBalanceOp1 result = new InvBalanceOp1();
                    result.PartNo = item.PartNo;
                    result.PartName = item.PartName;
                    result.Vendor = item.Vendor;
                    var eleD800 = listD800.Where(x => x.NoParts.Equals(item.PartNo) && x.NoStockPoi.Equals("3100P00")).OrderByDescending(x=>x.CtAll).FirstOrDefault();
                    result.UnitPrice = eleD800 != null ? eleD800.CtAll : null;
                    var eleStructure = listStructure.FirstOrDefault(x => x.PartNo8.Equals(item.PartNo));
                    result.Set = eleStructure != null ? eleStructure.Comain22 : null;
                    result.FromDate = DateRecently.FromDate;
                    result.ToDate = DateRecently.ToDate;
                    List<string> listDept = new List<string>();
                    List<double> listValue = new List<double>();
                    double total = 0;
                    double? totalLending = 0;
                    double totalSlip = 0;
                    double totalOrther = 0;
                    string slipPending = "";
                    foreach (var ele in listStore)
                    {
                        var ip2 = listIp2.FirstOrDefault(x => x.PartNo.Equals(item.PartNo) && x.StoreInoutId == ele.Id);
                        totalOrther += ip2 != null ? ip2.StoreOut[ip2.StoreOut.Length - 1] : 0;
                        listDept.Add(ele.Department);
                        listValue.Add(ip2 != null ? ip2.ActualRemain.Value : 0);
                        total += ip2 != null ? ip2.ActualRemain.Value : 0;
                        if (ip2 != null)
                        {
                            //var arrLending = ip2.LendingNo.Split("/");
                            //foreach (var arr in arrLending)
                            //{
                            //    var code = arr.Split(":")[0].Trim();
                            //    var lending = listLendingAssy.FirstOrDefault(x => x.PartNumber.Equals(item.PartNo) && x.CodeId.ToString().Equals(code));
                            //    var lending1 = listLendingPdc.FirstOrDefault(x => x.PartNumber.Equals(item.PartNo) && x.CodeId.ToString().Equals(code));
                            //    totalLending += (lending != null ? (lending.QtyBorrow.Value - lending.QtyReturn.Value) : 0) + (lending1 != null ? (lending1.QtyBorrow.Value - lending1.QtyReturn.Value) : 0);
                            //}
                            var arrSlip = ip2.SlipNo.Split("/");
                            foreach (var arr in arrSlip)
                            {
                                var code = arr.Split(":")[0].Trim().IsNullOrEmpty() ?"": arr.Split(":")[0].Trim().Substring(0, 9);
                                var sl = arr.Split(":").Length > 1 ?( arr.Split(":")[1].Trim().IsNullOrEmpty() ? 0 :  int.Parse(arr.Split(":")[1].Trim())) : 0;
                                if (!code.IsNullOrEmpty())
                                {
                                    var fromDate = int.Parse(DateRecently.FromDate.Value.ToString("yyyyMMdd"));
                                    var fromTime = 90000;
                                    var slip = listE700.Where(x => x.NoParts.Equals(item.PartNo) && x.NoSlip.Contains(code) && (x.DtInventFluct < fromDate || x.DtInventFluct == fromDate && x.TmInventFluct < fromTime)).OrderByDescending(x=>x.DtInventFluct).FirstOrDefault();
                                    if (slip == null)
                                    {
                                        if (!string.IsNullOrEmpty(arr))
                                        {

                                            slipPending += arr + ",";
                                        }
                                        //totalSlip += sl;
                                    }
                                    else
                                    {
                                        var toDate = int.Parse(DateRecently.ToDate.Value.ToString("yyyyMMdd"));
                                        var toTime = 90000;
                                        if(slip.DtInventFluct > toDate || (slip.DtInventFluct == toDate && slip.TmInventFluct > toTime))
                                        {
                                            if (!string.IsNullOrEmpty(arr))
                                            {

                                                slipPending += arr + ",";
                                            }
                                        }
                                        totalSlip += slip.QtFluct != null ? (sl - (int)slip.QtFluct.Value) : sl ;
                                    }
                                }
                            }

                        }
                        var op1Past = listOp1Past.FirstOrDefault(x => x.PartNo.Equals(item.PartNo));
                        if(op1Past != null)
                        {
                            if (!op1Past.SlipNoPending.IsNullOrEmpty())
                            {
                                var arrSlip = op1Past.SlipNoPending.Split("/");
                                foreach (var arr in arrSlip)
                                {
                                    var code = arr.Split(":")[0].Trim().IsNullOrEmpty() ? "" : arr.Split(":")[0].Trim().Substring(0, 9);
                                    var sl = arr.Split(":")[1].Trim().IsNullOrEmpty() ? 0 : int.Parse(arr.Split(":")[1].Trim());
                                    if (!code.IsNullOrEmpty())
                                    {
                                        var fromDate = int.Parse(DateRecently.FromDate.Value.ToString("yyyyMMdd"));
                                        var fromTime = 90000;
                                        var slip = listE700.Where(x => x.NoParts.Equals(item.PartNo) && x.NoSlip.Contains(code) && (x.DtInventFluct < fromDate || x.DtInventFluct == fromDate && x.TmInventFluct < fromTime)).OrderByDescending(x => x.DtInventFluct).FirstOrDefault();
                                        if (slip == null)
                                        {
                                            if (!string.IsNullOrEmpty(arr))
                                            {

                                                slipPending += arr + ",";
                                            }
                                            //totalSlip += sl;
                                        }
                                        else
                                        {
                                            var toDate = int.Parse(DateRecently.ToDate.Value.ToString("yyyyMMdd"));
                                            var toTime = 90000;
                                            if (slip.DtInventFluct > toDate || (slip.DtInventFluct == toDate && slip.TmInventFluct > toTime))
                                            {
                                                if (!string.IsNullOrEmpty(arr))
                                                {

                                                    slipPending += arr + ",";
                                                }
                                            }
                                            totalSlip += slip.QtFluct != null ? (sl - (int)slip.QtFluct.Value) : sl;
                                        }
                                    }
                                }
                            }
                        }
                    }
                    //var lending = listLendingAssy.Where(x => x.PartNumber.Equals(item.PartNo) && (x.QtyBorrow - x.QtyReturn - x.QtyDefect) > 0 && x.BorrowDate <= DateRecently.FromDate).ToList();
                    //var lending1 = listLendingPdc.Where(x => x.PartNumber.Equals(item.PartNo) && (x.QtyBorrow - x.QtyReturn) > 0 && x.BorrowDate <= DateRecently.FromDate).ToList();
                    var lending = listLendingAssy.Where(x => x.PartNumber.Equals(item.PartNo) && (x.QtyBorrow - x.QtyReturn - x.QtyDefect) > 0 && x.CreatedDate == DateRecently.ToDate).ToList();
                    var lending1 = listLendingPdc.Where(x => x.PartNumber.Equals(item.PartNo) && (x.QtyBorrow - x.QtyReturn) > 0 && x.CreatedDate == DateRecently.ToDate).ToList();
                    totalLending += (lending.Count() > 0 ? lending.Sum(x=> x.QtyBorrow - x.QtyReturn - x.QtyDefect) : 0) + (lending1.Count()>0 ? lending1.Sum(x=>x.QtyBorrow - x.QtyReturn) : 0);

                    result.Department = listDept.ToArray();
                    result.ActualStock = listValue.ToArray();
                    result.TotalActual = total;
                    result.LendingRemain = totalLending;
                    var ip25 = listNPIS.FirstOrDefault(x => x.PartNo.Equals(item.PartNo));
                    result.NpisStock = ip25 != null ? ip25.ActualRemain : null;
                    var d800 = product.Equals("IJP") ? listD800.FirstOrDefault(x => x.NoParts.Equals(item.PartNo) && x.NoStockPoi.Equals("8888STS")) : listD800.FirstOrDefault(x => x.NoParts.Equals(item.PartNo) && x.NoStockPoi.Equals("3100SPD"));
                    result.SuspenseStock = d800 != null ? d800.QtStock : 0;
                    result.QtySlip = totalOrther - totalSlip;
                    var differQty1 = total + totalLending - ((ip25 != null ? (ip25.ActualRemain ?? 0) : 0) + (d800 != null ? (d800.QtStock ?? 0) : 0) - (totalOrther - totalSlip));
                    var differQty = differQty1.Value.FormatDouble();
                    result.DifferQty = differQty;
                    result.DifferAmount = (differQty1 * (eleD800 != null ? eleD800.CtAll : 0)).Value.FormatDouble();
                    result.SlipNoPending =(totalOrther - totalSlip) == 0 ? "":( string.IsNullOrEmpty(slipPending) ? "" : slipPending.Substring(0, slipPending.Length - 1));
                    result.Product = product;
                    listTemp.Add(result);
                    var del = listOp1.Where(x=>x.PartNo.Equals(item.PartNo) && x.Vendor.Equals(item.Vendor)).ToList();
                    if(del.Count() > 0)
                    {
                        context.InvBalanceOp1s.RemoveRange(del);
                    }
                }
                var sameSet = listTemp.GroupBy(x => x.Set);
                foreach (var item in sameSet)
                {
                    if(item.Key != null)
                    {
                        if (!item.Key.Trim().ToUpper().Equals("CO"))
                        {
                            var listSame = item.ToList();
                            var actualStock = listSame.Select(x => x.ActualStock).Aggregate((x, y) => x.Zip(y, (a, b) => a + b).ToArray());
                            var totalActual = listSame.Sum(x => x.TotalActual);
                            var lendingRemain = listSame.Sum(x => x.LendingRemain);
                            var npisStock = listSame.Sum(x => x.NpisStock);
                            var suspense = listSame.Sum(x => x.SuspenseStock);
                            var slipInput = listSame.Sum(x => x.QtySlip);
                            var differQty = listSame.Sum(x => x.DifferQty);
                            //var differAmount = listSame.Sum(x => x.DifferAmount);
                            int first = 0;
                            foreach (var same in listSame)
                            {
                                if(first == 0)
                                {
                                    same.ActualStock = actualStock;
                                    same.TotalActual = totalActual;
                                    same.LendingRemain = lendingRemain;
                                    same.NpisStock = npisStock;
                                    same.SuspenseStock = suspense;
                                    same.QtySlip = slipInput;
                                    same.DifferQty = differQty;
                                    same.DifferAmount = differQty * same.UnitPrice ;
                                }
                                else
                                {
                                    same.ActualStock = new double[actualStock.Length];
                                    same.TotalActual = 0;
                                    same.LendingRemain = 0;
                                    same.NpisStock = 0;
                                    same.SuspenseStock = 0;
                                    same.QtySlip = 0;
                                    same.DifferQty = 0;
                                    same.DifferAmount = 0;
                                }
                                listResult.Add(same);
                                first++;
                            }
                        }
                        else
                        {
                            listResult.AddRange(item.ToList());
                        }
                    }
                    else
                    {
                        listResult.AddRange(item.ToList());
                    }
                }
                context.InvBalanceOp1s.AddRange(listResult);
                context.SaveChanges();
                res.Error = false;
                res.Message = "Successful !";
                res.Status = 200;
            }
            catch (Exception e)
            {
                //SendMailError(e);
                res.Error = true;
                res.Message = e.Message;
                res.Status = 400;
            }
            return res;
        }
        [HttpPost("filter-balance-op1")]
        public BalanceModel FilterBalanceOp1(BalanceParam param)
        {
            try
            {
                var result = new BalanceModel();
                var lstResult = new List<List<string>>();
                var model = context.InvBalanceOp1s.Where(x => x.Active == true && x.Product.Equals(param.Product)).AsQueryable();
                if (!string.IsNullOrEmpty(param.PartNo)) { model = model.Where(x => x.PartNo.ToLower().Contains(param.PartNo.ToLower())); }
                if (!string.IsNullOrEmpty(param.Vendor)) { model = model.Where(x => x.Vendor.ToLower().Contains(param.Vendor.ToLower())); }
                if (!string.IsNullOrEmpty(param.FromDate) && string.IsNullOrEmpty(param.ToDate)) { var fromdate = DateOnly.FromDateTime(DateTime.ParseExact(param.FromDate, "dd-MM-yyyy", null)); model = model.Where(x => x.FromDate == fromdate && x.ToDate == fromdate); }
                else if (string.IsNullOrEmpty(param.FromDate) && !string.IsNullOrEmpty(param.ToDate)) { var todate = DateOnly.FromDateTime(DateTime.ParseExact(param.ToDate, "dd-MM-yyyy", null)); model = model.Where(x => x.FromDate == todate && x.ToDate == todate); }
                else if (!string.IsNullOrEmpty(param.FromDate) && !string.IsNullOrEmpty(param.ToDate)) { var todate = DateOnly.FromDateTime(DateTime.ParseExact(param.ToDate, "dd-MM-yyyy", null)); var fromdate = DateOnly.FromDateTime(DateTime.ParseExact(param.FromDate, "dd-MM-yyyy", null)); model = model.Where(x => x.FromDate == fromdate && x.ToDate == todate); }
                else
                {
                    var DateRecently = context.InvUploadActuals.AsNoTracking().Where(x => x.Active == true).OrderByDescending(x => x.ToDate).FirstOrDefault();
                    if (DateRecently != null)
                    {
                        model = model.Where(x => x.FromDate == DateRecently.FromDate && x.ToDate == DateRecently.ToDate);
                    }
                }
                var listPart = model.OrderBy(x=>x.Set).ToList().Select(x => x.PartNo).Distinct().ToList();
                var model2 = listPart.Skip((param.Page - 1) * param.RecordsPerPage).Take(param.RecordsPerPage).ToList();

                List<SnpTemp> listTemp = new List<SnpTemp>();
                var listDateStr = model.Where(x => model2.Contains(x.PartNo)).OrderBy(x => x.ToDate).Select(x => x.FromDate == x.ToDate ? (x.FromDate.Value.ToString("dd-MMM-yy") + "|" + x.Department.Length) : (x.FromDate.Value.ToString("dd-MMM-yy") + "|" + x.ToDate.Value.ToString("dd-MMM-yy") + "|" + x.Department.Length)).Distinct().ToList();
                result.listDate = listDateStr;
                List<BalanceDate> listDate = new List<BalanceDate>();
                foreach (var item in listDateStr)
                {
                    var arr = item.Split("|");
                    if (arr.Length > 2)
                    {
                        listDate.Add(new BalanceDate()
                        {
                            FromDate = DateOnly.FromDateTime(DateTime.ParseExact(arr[0], "dd-MMM-yy", null)),
                            ToDate = DateOnly.FromDateTime(DateTime.ParseExact(arr[1], "dd-MMM-yy", null)),
                            Count = int.Parse(arr[2])
                        });
                    }
                    else
                    {
                        listDate.Add(new BalanceDate()
                        {
                            FromDate = DateOnly.FromDateTime(DateTime.ParseExact(arr[0], "dd-MMM-yy", null)),
                            ToDate = DateOnly.FromDateTime(DateTime.ParseExact(arr[0], "dd-MMM-yy", null)),
                            Count = int.Parse(arr[1])
                        });
                    }

                }
                int no = (param.Page - 1) * param.RecordsPerPage + 1;
                List<string> listActual = new List<string>();
                List<string> listDept = new List<string>();
                var check = true;
                foreach (var item in model2)
                {
                    List<string> temp = new List<string>();
                    var op1 = model.FirstOrDefault(x => x.PartNo.Equals(item));
                    temp.Add(no.ToString());
                    temp.Add(item);
                    temp.Add(op1.PartName??"");
                    temp.Add(op1.Vendor??"");
                    temp.Add(op1.UnitPrice != null ? op1.UnitPrice.Value.FormatDouble2().ToString():"");
                    temp.Add(op1.Set??"");
                    foreach (var date in listDate)
                    {
                        if (check)
                        {
                            listActual.Add("Actual stock|" + date.Count + "|1");
                            listActual.Add("Total actual|1|2");
                            listActual.Add("Lending remain|1|2");
                            listActual.Add("NPIS stock|1|2");
                            listActual.Add("Suspense stock|1|2");
                            listActual.Add("Slip NY Input (by q'ty)|1|2");
                            listActual.Add("Differ|2|1");
                            listActual.Add("Reason|1|2");
                            listActual.Add("Slip no pending|1|2");

                            foreach (var dept in op1.Department)
                            {
                                listDept.Add(dept);
                            }
                            listDept.Add("Q'ty");
                            listDept.Add("Amount");
                        }

                        var value = model.FirstOrDefault(x => x.PartNo.Equals(item) && x.FromDate == date.FromDate && x.ToDate == date.ToDate);
                        if (value != null)
                        {
                            foreach (var ele in value.ActualStock)
                            {
                                temp.Add(ele.ToString());
                            }
                            temp.Add(value.TotalActual.ToString());
                            temp.Add(value.LendingRemain.ToString());
                            temp.Add(value.NpisStock.ToString());
                            temp.Add(value.SuspenseStock.ToString());
                            temp.Add(value.QtySlip.ToString());
                            temp.Add(value.DifferQty != null ?value.DifferQty.Value.FormatDouble().ToString():"");
                            temp.Add(value.DifferAmount != null ?value.DifferAmount.Value.FormatDouble().ToString(): "");
                            temp.Add("Reason|" + item + "|" + date.FromDate.Value.ToString("dd-MMM-yy") + "|" + date.ToDate.Value.ToString("dd-MMM-yy") + "|" + value.Reason);
                            temp.Add(value.SlipNoPending);
                        }
                        else
                        {
                            for (int i = 0; i < date.Count; i++)
                            {
                                temp.Add("");
                            }
                            temp.Add("");
                            temp.Add("");
                            temp.Add("");
                            temp.Add("");
                            temp.Add("");
                            temp.Add("");
                            temp.Add("");
                            temp.Add("");
                            temp.Add("");
                        }
                    }
                    check = false;
                    no++;
                    lstResult.Add(temp);
                }

                var c = listPart.Count();
                result.lstModel = lstResult;
                result.listActual = listActual;
                result.listDept = listDept;
                result.toRecord = (int)Math.Min(result.totalRecords, result.currentPage * result.recordPerPage);
                result.totalPage = (int)Math.Ceiling((decimal)c / param.RecordsPerPage);
                result.totalRecords = c;
                result.recordPerPage = param.RecordsPerPage;
                result.currentPage = param.Page;
                result.fromRecord = c == 0 ? 0 : (result.currentPage - 1) * result.recordPerPage + 1;
                return result;
            }
            catch (Exception e)
            {
                return new BalanceModel();
            }
        }
        [HttpPost("import-balance-reason")]
        public async Task<CommonResponse> ImportBalanceReason([FromForm] IFormFile file)
        {
            var result = new CommonResponse()
            {
                Error = false,
                Message = "",
                Status = (int)HttpStatusCode.BadRequest
            };
            try
            {
                var u = GetCurrentUser();

                using (var memoStream = new MemoryStream())
                {
                    file.CopyTo(memoStream);
                    ExcelPackage.LicenseContext = LicenseContext.NonCommercial;
                    using (var package = new ExcelPackage(memoStream))
                    {
                        var worksheet = package.Workbook.Worksheets[0];

                        var rowCount = worksheet.Dimension?.Rows;
                        var colCount = worksheet.Dimension?.Columns;
                        List<int> listIndex = new List<int>();
                        List<DateOnly> listDate = new List<DateOnly>();
                        if (rowCount.HasValue && rowCount.Value >= 4)
                        {
                            var listBalance = context.InvBalanceOp1s.Where(x => x.Active == true).ToList();
                            for (int i = 7; i < colCount; i++)
                            {
                                var title = Convert.ToString(worksheet.Cells[2, i].Value);
                                if (title.Equals("Actual stock"))
                                {

                                    var dateStr = Convert.ToString(worksheet.Cells[1, i].Value);
                                    var arr = dateStr.Split("&");
                                    if (arr.Length > 1)
                                    {
                                        listDate.Add(DateOnly.FromDateTime(DateTime.ParseExact(arr[0].Trim(), "dd-MMM-yy", null)));
                                        listDate.Add(DateOnly.FromDateTime(DateTime.ParseExact(arr[1].Trim(), "dd-MMM-yy", null)));
                                    }
                                    else
                                    {
                                        listDate.Add(DateOnly.FromDateTime(DateTime.ParseExact(arr[0].Trim(), "dd-MMM-yy", null)));
                                        listDate.Add(DateOnly.FromDateTime(DateTime.ParseExact(arr[0].Trim(), "dd-MMM-yy", null)));
                                    }
                                }
                                else if (title.Equals("Reason"))
                                {
                                    listIndex.Add(i);
                                }
                            }

                            for (int row = 4; row <= rowCount.Value; row++)
                            {
                                var partNo = Convert.ToString(worksheet.Cells["B" + row].Value);
                                int indexDate = 0;
                                foreach (var item in listIndex)
                                {
                                    var reason = Convert.ToString(worksheet.Cells[row, item].Value);
                                    var balance = listBalance.FirstOrDefault(x => x.PartNo.Equals(partNo) && x.FromDate == listDate[indexDate] && x.ToDate == listDate[indexDate + 1]);
                                    if (balance != null)
                                    {
                                        balance.Reason = reason;
                                        balance.ModifiedBy = u.UserName;
                                        balance.ModifiedDate = DateTime.Now.SetKindUtc();
                                        context.InvBalanceOp1s.Update(balance);

                                    }
                                    indexDate += 2;
                                }

                            }
                        }
                    }
                }
                context.SaveChanges();

                result.Status = (int)HttpStatusCode.OK;
                result.Message = "Success";
                result.Error = false;
                return result;
            }
            catch (Exception e)
            {
                result.Status = (int)HttpStatusCode.BadRequest;
                result.Message = e.Message;
                result.Error = true;
                return result;
            }
        }
        [HttpPost("edit-reason")]
        public async Task<CommonResponse> EditReason(EditReasonParam rq)
        {
            var res = new CommonResponse()
            {
                Error = false,
                Message = "Successful !",
                Status = 200
            };
            try
            {
                var u = GetCurrentUser();
                var fromDate = DateOnly.FromDateTime(DateTime.ParseExact(rq.FromDate, "dd-MMM-yy", null));
                var toDate = DateOnly.FromDateTime(DateTime.ParseExact(rq.ToDate, "dd-MMM-yy", null));
                var balance = context.InvBalanceOp1s.FirstOrDefault(x => x.PartNo.Equals(rq.PartNo) && x.FromDate == fromDate && x.ToDate == toDate);
                if (balance != null)
                {
                    balance.Reason = rq.Reason;
                    balance.ModifiedBy = u.UserName;
                    balance.ModifiedDate = DateTime.Now.SetKindUtc();
                    context.SaveChanges();
                }

                res.Error = false;
                res.Message = "Successful !";
                res.Status = 200;
            }
            catch (Exception e)
            {
                //SendMailError(e);
                res.Error = true;
                res.Message = e.Message;
                res.Status = 400;
            }
            return res;
        }
        [HttpPost("filter-balance-op2")]
        public BalanceModel FilterBalanceOp2(BalanceParam param)
        {
            try
            {
                var result = new BalanceModel();
                var lstResult = new List<List<string>>();
                var model = context.InvBalanceOp1s.Where(x => x.Active == true && x.Product.Equals(param.Product)).AsQueryable();
                if (!string.IsNullOrEmpty(param.PartNo)) { model = model.Where(x => x.PartNo.ToLower().Contains(param.PartNo.ToLower())); }
                if (!string.IsNullOrEmpty(param.Vendor)) { model = model.Where(x => x.Vendor.ToLower().Contains(param.Vendor.ToLower())); }
                if (!string.IsNullOrEmpty(param.FromDate) && string.IsNullOrEmpty(param.ToDate)) { var fromdate = DateOnly.FromDateTime(DateTime.ParseExact(param.FromDate, "dd-MM-yyyy", null)); model = model.Where(x => x.FromDate == fromdate || x.ToDate == fromdate); }
                else if (string.IsNullOrEmpty(param.FromDate) && !string.IsNullOrEmpty(param.ToDate)) { var todate = DateOnly.FromDateTime(DateTime.ParseExact(param.ToDate, "dd-MM-yyyy", null)); model = model.Where(x => x.FromDate == todate || x.ToDate == todate); }
                else if (!string.IsNullOrEmpty(param.FromDate) && !string.IsNullOrEmpty(param.ToDate)) { var todate = DateOnly.FromDateTime(DateTime.ParseExact(param.ToDate, "dd-MM-yyyy", null)); var fromdate = DateOnly.FromDateTime(DateTime.ParseExact(param.FromDate, "dd-MM-yyyy", null)); model = model.Where(x => x.FromDate == fromdate && x.ToDate == todate); }
                else
                {
                    var fromdate = DateOnly.FromDateTime(DateTime.ParseExact(param.FromDate, "dd-MM-yyyy", null));
                    var todate = DateOnly.FromDateTime(DateTime.ParseExact(param.ToDate, "dd-MM-yyyy", null));
                    model = model.Where(x => (x.FromDate >= fromdate && x.FromDate <= fromdate) || (x.ToDate >= fromdate && x.ToDate <= fromdate));
                }
                var listPart = model.Select(x => x.PartNo).Distinct().ToList();
                var model2 = listPart.Skip((param.Page - 1) * param.RecordsPerPage).Take(param.RecordsPerPage).ToList();

                List<SnpTemp> listTemp = new List<SnpTemp>();
                var listDateStr = model.Where(x => model2.Contains(x.PartNo)).OrderBy(x => x.ToDate).Select(x => x.FromDate == x.ToDate ? x.FromDate.Value.ToString("dd-MMM-yy") : (x.FromDate.Value.ToString("dd-MMM-yy") + "|" + x.ToDate.Value.ToString("dd-MMM-yy"))).Distinct().ToList();
                result.listDate = listDateStr;
                List<BalanceDate> listDate = new List<BalanceDate>();
                foreach (var item in listDateStr)
                {
                    var arr = item.Split("|");
                    if (arr.Length > 1)
                    {
                        listDate.Add(new BalanceDate()
                        {
                            FromDate = DateOnly.FromDateTime(DateTime.ParseExact(arr[0], "dd-MMM-yy", null)),
                            ToDate = DateOnly.FromDateTime(DateTime.ParseExact(arr[1], "dd-MMM-yy", null)),
                            Count = 0
                        });
                    }
                    else
                    {
                        listDate.Add(new BalanceDate()
                        {
                            FromDate = DateOnly.FromDateTime(DateTime.ParseExact(arr[0], "dd-MMM-yy", null)),
                            ToDate = DateOnly.FromDateTime(DateTime.ParseExact(arr[0], "dd-MMM-yy", null)),
                            Count = 0
                        });
                    }

                }
                int no = (param.Page - 1) * param.RecordsPerPage + 1;
                List<string> listActual = new List<string>();
                List<string> listDept = new List<string>();
                var check = true;
                foreach (var item in model2)
                {
                    List<string> temp = new List<string>();
                    var op1 = model.FirstOrDefault(x => x.PartNo.Equals(item));
                    temp.Add(no.ToString());
                    temp.Add(item);
                    temp.Add(op1.PartName);
                    temp.Add(op1.Vendor);
                    temp.Add(op1.UnitPrice.Value.FormatDouble2().ToString());
                    temp.Add(op1.Set);
                    foreach (var date in listDate)
                    {
                        if (check)
                        {
                            listActual.Add("Actual|1|2");
                            listActual.Add("System|1|2");
                            listActual.Add("Differ|2|1");
                            listActual.Add("Reason|1|2");
                            listDept.Add("Q'ty");
                            listDept.Add("Amount");
                        }
                        var value = model.FirstOrDefault(x => x.PartNo.Equals(item) && x.FromDate == date.FromDate && x.ToDate == date.ToDate);
                        if (value != null)
                        {
                            var actual = value.TotalActual + value.LendingRemain;
                            var system = value.NpisStock + value.SuspenseStock - value.QtySlip;

                            temp.Add(actual.ToString());
                            temp.Add(system.ToString());
                            temp.Add((actual - system).ToString());
                            temp.Add(((actual - system) * op1.UnitPrice).ToString());
                            temp.Add(value.Reason);
                        }
                        else
                        {
                            temp.Add("");
                            temp.Add("");
                            temp.Add("");
                            temp.Add("");
                            temp.Add("");
                        }
                    }
                    check = false;
                    no++;
                    lstResult.Add(temp);
                }

                var c = listPart.Count();
                result.lstModel = lstResult;
                result.listActual = listActual;
                result.listDept = listDept;
                result.toRecord = (int)Math.Min(result.totalRecords, result.currentPage * result.recordPerPage);
                result.totalPage = (int)Math.Ceiling((decimal)c / param.RecordsPerPage);
                result.totalRecords = c;
                result.recordPerPage = param.RecordsPerPage;
                result.currentPage = param.Page;
                result.fromRecord = c == 0 ? 0 : (result.currentPage - 1) * result.recordPerPage + 1;
                return result;
            }
            catch (Exception)
            {
                return new BalanceModel();
            }
        }
        [HttpPost("filter-balance-op2-dept")]
        public BalanceModel FilterBalanceOp2Dept(BalanceParam param)
        {
            try
            {
                var result = new BalanceModel();
                var lstResult = new List<List<string>>();
                var model = context.InvBalanceOp1s.Where(x => x.Active == true && x.Product.Equals(param.Product)).AsQueryable();
                if (!string.IsNullOrEmpty(param.PartNo)) { model = model.Where(x => x.PartNo.ToLower().Contains(param.PartNo.ToLower())); }
                if (!string.IsNullOrEmpty(param.Vendor)) { model = model.Where(x => x.Vendor.ToLower().Contains(param.Vendor.ToLower())); }
                if (!string.IsNullOrEmpty(param.FromDate) && string.IsNullOrEmpty(param.ToDate)) { var fromdate = DateOnly.FromDateTime(DateTime.ParseExact(param.FromDate, "dd-MM-yyyy", null)); model = model.Where(x => x.FromDate == fromdate || x.ToDate == fromdate); }
                else if (string.IsNullOrEmpty(param.FromDate) && !string.IsNullOrEmpty(param.ToDate)) { var todate = DateOnly.FromDateTime(DateTime.ParseExact(param.ToDate, "dd-MM-yyyy", null)); model = model.Where(x => x.FromDate == todate || x.ToDate == todate); }
                else if (!string.IsNullOrEmpty(param.FromDate) && !string.IsNullOrEmpty(param.ToDate)) { var todate = DateOnly.FromDateTime(DateTime.ParseExact(param.ToDate, "dd-MM-yyyy", null)); var fromdate = DateOnly.FromDateTime(DateTime.ParseExact(param.FromDate, "dd-MM-yyyy", null)); model = model.Where(x => x.FromDate == fromdate && x.ToDate == todate); }
                else
                {
                    var fromdate = DateOnly.FromDateTime(DateTime.ParseExact(param.FromDate, "dd-MM-yyyy", null));
                    var todate = DateOnly.FromDateTime(DateTime.ParseExact(param.ToDate, "dd-MM-yyyy", null));
                    model = model.Where(x => (x.FromDate >= fromdate && x.FromDate <= fromdate) || (x.ToDate >= fromdate && x.ToDate <= fromdate));
                }
                var listPart = model.Select(x => x.PartNo).Distinct().ToList();
                var model2 = listPart.Skip((param.Page - 1) * param.RecordsPerPage).Take(param.RecordsPerPage).ToList();
                var ListIp2 = context.InvUploadActuals.Where(x => x.Active == true && model2.Contains(x.PartNo)).ToList();
                var dept = context.InvStoreInouts.FirstOrDefault(x => x.Active == true && x.Department.Equals(param.Department));
                List<SnpTemp> listTemp = new List<SnpTemp>();
                var listDateStr = model.Where(x => model2.Contains(x.PartNo)).OrderBy(x => x.ToDate).Select(x => x.FromDate == x.ToDate ? x.FromDate.Value.ToString("dd-MMM-yy") : (x.FromDate.Value.ToString("dd-MMM-yy") + "|" + x.ToDate.Value.ToString("dd-MMM-yy"))).Distinct().ToList();
                result.listDate = listDateStr;
                List<BalanceDate> listDate = new List<BalanceDate>();
                foreach (var item in listDateStr)
                {
                    var arr = item.Split("|");
                    if (arr.Length > 1)
                    {
                        listDate.Add(new BalanceDate()
                        {
                            FromDate = DateOnly.FromDateTime(DateTime.ParseExact(arr[0], "dd-MMM-yy", null)),
                            ToDate = DateOnly.FromDateTime(DateTime.ParseExact(arr[1], "dd-MMM-yy", null)),
                            Count = 0
                        });
                    }
                    else
                    {
                        listDate.Add(new BalanceDate()
                        {
                            FromDate = DateOnly.FromDateTime(DateTime.ParseExact(arr[0], "dd-MMM-yy", null)),
                            ToDate = DateOnly.FromDateTime(DateTime.ParseExact(arr[0], "dd-MMM-yy", null)),
                            Count = 0
                        });
                    }

                }
                int no = (param.Page - 1) * param.RecordsPerPage + 1;
                List<string> listActual = new List<string>();
                List<string> listDept = new List<string>();
                var check = true;
                foreach (var item in model2)
                {
                    List<string> temp = new List<string>();
                    var op1 = model.FirstOrDefault(x => x.PartNo.Equals(item));
                    temp.Add(no.ToString());
                    temp.Add(item);
                    temp.Add(op1.PartName);
                    temp.Add(op1.Vendor);
                    temp.Add(op1.UnitPrice.Value.FormatDouble2().ToString());
                    temp.Add(op1.Set);
                    foreach (var date in listDate)
                    {
                        if (check)
                        {
                            listActual.Add("Actual|1|2");
                            listActual.Add("Cal.|1|2");
                            listActual.Add("Differ|2|1");
                            listActual.Add("Reason|1|2");
                            listDept.Add("Q'ty");
                            listDept.Add("Amount");
                        }
                        var value = ListIp2.FirstOrDefault(x => x.PartNo.Equals(item) && x.FromDate == date.FromDate && x.ToDate == date.ToDate && x.StoreInoutId == dept.Id);
                        if (value != null)
                        {
                            var actual = value.ActualRemain;
                            var cal = value.RemainCalculate;

                            temp.Add(actual.ToString());
                            temp.Add(cal.ToString());
                            temp.Add(value.Differ.ToString());
                            temp.Add((value.Differ * op1.UnitPrice).ToString());
                            temp.Add(value.Reason);
                        }
                        else
                        {
                            temp.Add("");
                            temp.Add("");
                            temp.Add("");
                            temp.Add("");
                            temp.Add("");
                        }
                    }
                    check = false;
                    no++;
                    lstResult.Add(temp);
                }

                var c = listPart.Count();
                result.lstModel = lstResult;
                result.listActual = listActual;
                result.listDept = listDept;
                result.toRecord = (int)Math.Min(result.totalRecords, result.currentPage * result.recordPerPage);
                result.totalPage = (int)Math.Ceiling((decimal)c / param.RecordsPerPage);
                result.totalRecords = c;
                result.recordPerPage = param.RecordsPerPage;
                result.currentPage = param.Page;
                result.fromRecord = c == 0 ? 0 : (result.currentPage - 1) * result.recordPerPage + 1;
                return result;
            }
            catch (Exception)
            {
                return new BalanceModel();
            }
        }
        [HttpGet("excute-npis-movement/{product}")]
        public async Task<CommonResponse> ExcuteNpisMovement(string product)
        {
            var res = new CommonResponse()
            {
                Error = false,
                Message = "Successful !",
                Status = 200
            };
            try
            {
                var u = GetCurrentUser();
                var model = context.InvBalancePartLists.Where(x => x.Active == true).AsQueryable();
                if (!string.IsNullOrEmpty(product)) { model = model.Where(x => x.Product.ToUpper().Contains(product.ToUpper())); }
                var timePickup = context.InvTimePickUps.FirstOrDefault();
                var from = DateOnly.FromDateTime(timePickup.FromTime.Value);
                var to = DateOnly.FromDateTime(timePickup.ToTime.Value);
                var store = context.InvStoreInouts.FirstOrDefault(x => x.Department.ToUpper().Contains("NPIS"));
                var listActual = context.InvUploadActuals.Where(x => x.Active == true && x.StoreInoutId == store.Id).ToList();
                var listE = context.InvUploadActuals.Where(x => x.Active == true && x.FromDate == from && x.ToDate == to && x.StoreInoutId == store.Id).ToList();
                context.InvUploadActuals.RemoveRange(listE);
                var fromDate = int.Parse(timePickup.FromTime.Value.UnsetKindUtc().ToString("yyyyMMdd"));
                var fromTime = int.Parse(timePickup.FromTime.Value.UnsetKindUtc().ToString("HHmmss"));
                var toDate = int.Parse(timePickup.ToTime.Value.UnsetKindUtc().ToString("yyyyMMdd"));
                var toTime = int.Parse(timePickup.ToTime.Value.UnsetKindUtc().ToString("HHmmss"));
                var listView = new List<MvInvE700Ij1>();
                var listViewLast = new List<MvInvE700Ij1>();
                List<int> listDate = new List<int>();
                for (DateTime i = timePickup.FromTime.Value; i.Date <= timePickup.ToTime.Value.Date; i = i.AddDays(1))
                {
                    listDate.Add(int.Parse(i.ToString("yyyyMMdd")));
                }
                if (product.ToUpper().Contains("IJ"))
                {
                    var listView1 = context.MvInvE700Ij1s.Where(x => listDate.Contains(x.DtInventFluct.Value)).ToList();
                    foreach (var item in listView1)
                    {
                        if (((item.DtInventFluct == fromDate && item.TmInventFluct >= fromTime) || item.DtInventFluct > fromDate) && ((item.DtInventFluct == toDate && item.TmInventFluct <= toTime) || item.DtInventFluct < toDate))
                        {
                            listView.Add(item);
                        }
                        else if (item.DtInventFluct == fromDate && item.TmInventFluct < fromTime)
                        {
                            listViewLast.Add(item);
                        }
                    }
                }
                else
                {
                    var listView1 = context.MvInvE700Lbp1s.ToList();
                    var listViewLbp = new List<MvInvE700Lbp1>();
                    var listViewLbpLast = new List<MvInvE700Lbp1>();
                    foreach (var item in listView1)
                    {
                        if (((item.DtInventFluct == fromDate && item.TmInventFluct >= fromTime) || item.DtInventFluct > fromDate) && ((item.DtInventFluct == toDate && item.TmInventFluct <= toTime) || item.DtInventFluct < toDate))
                        {
                            listViewLbp.Add(item);
                        }
                        else if (item.DtInventFluct == fromDate && item.TmInventFluct < fromTime)
                        {
                            listViewLbpLast.Add(item);
                        }
                    }

                    listView = listViewLbp.MapEucE700();
                    listViewLast = listViewLbpLast.MapEucE700();
                }
                foreach (var item in model)
                {
                    InvUploadActual listTemp = new InvUploadActual();
                    listTemp.PartNo = item.PartNo;
                    listTemp.Vendor = item.Vendor;
                    var listValue = listView.Where(x => x.NoParts.Equals(item.PartNo) && (x.NoFlctToStockPoi.Equals("3100P00") || x.NoFlctFrmStockPoi.Equals("3100P00"))).ToList();
                    //var listValue1 = listViewLast.Where(x => x.NoParts.Equals(item.PartNo) && (x.NoFlctToStockPoi.Equals("3100P00") || x.NoFlctFrmStockPoi.Equals("3100P00")) && x.TmInventFluct <= fromTime).OrderByDescending(x => x.DtInventFluct).ThenByDescending(x => x.TmInventFluct).ToList();
                    double? remainCount = 0;
                    //if (listValue1.Count() > 0)
                    //{
                    //    var remain = listValue1.First();
                    //    if (remain.QtFlctAfterFrm != 0)
                    //    {
                    //        listTemp.RemainLastDay=remain.QtFlctAfterFrm;
                    //        remainCount = remain.QtFlctAfterFrm;
                    //    }
                    //    else
                    //    {
                    //        listTemp.RemainLastDay=remain.QtFlctAfterTo;
                    //        remainCount = remain.QtFlctAfterTo;
                    //    }
                    //}
                    //else
                    //{
                    //    listTemp.RemainLastDay=0;
                    //}
                    var timeCheck = DateOnly.FromDateTime(timePickup.FromTime.Value.UnsetKindUtc());
                    var remain = listActual.Where(x => x.PartNo.Equals(item.PartNo) && x.Vendor.Equals(item.Vendor) && x.ToDate <= timeCheck).OrderByDescending(x => x.CreatedDate).FirstOrDefault();
                    if (remain != null)
                    {
                        listTemp.RemainLastDay=remain.ActualRemain;
                        remainCount = remain.ActualRemain;
                    }
                    else
                    {
                        listTemp.RemainLastDay = 0;
                    }
                    double? totalIn = 0;
                    List<double> arrIn = new List<double>();
                    foreach (var item1 in store.StoreIn)
                    {
                        var sum = listValue.Where(x => x.CdInoutStorage.Equals(item1) && x.NoFlctToStockPoi.Equals("3100P00")).Select(x => x.QtFluct).Sum();
                        totalIn += sum;
                        arrIn.Add(sum.Value);
                    }
                    listTemp.StoreIn = arrIn.ToArray();
                    double? totalOut = 0;
                    List<double> arrOut = new List<double>();
                    foreach (var item1 in store.StoreOut)
                    {
                        //cho nay dang loi tuan sau nho su nhe : int.Parse(x.QtFluct)
                        var sum = listValue.Where(x => x.CdInoutStorage.Equals(item1) && x.NoFlctFrmStockPoi.Equals("3100P00")).Select(x => x.QtFluct).Sum();
                        totalOut += sum;
                        arrOut.Add(sum.Value);
                    }
                    listTemp.StoreOut = arrOut.ToArray();
                    listTemp.StoreInoutId = store.Id;
                    listTemp.CreatedBy = u.UserName;
                    listTemp.CreatedDate = DateTime.Now.SetKindUtc();
                    listTemp.RemainCalculate=(totalIn - totalOut + remainCount);
                    listTemp.FromDate = DateOnly.FromDateTime(timePickup.FromTime.Value);
                    listTemp.ToDate = DateOnly.FromDateTime(timePickup.ToTime.Value);
                    listTemp.Product = product;
                    context.InvUploadActuals.Add(listTemp);
                }


                context.SaveChanges();
                res.Error = false;
                res.Message = "Successful !";
                res.Status = 200;
            }
            catch (Exception e)
            {
                //SendMailError(e);
                res.Error = true;
                res.Message = e.Message;
                res.Status = 400;
            }
            return res;
        }
        [HttpPost("filter-visualization-op1")]
        public async Task<InvVisualizationOp1Model> FilterVisualizationOp1(BalanceParam param)
        {
            try
            {
                var result = new InvVisualizationOp1Model();
                var lstResult = new List<InvVisualizationOp1View>();
                string[] listBc1 = { "3100", "3500", "3600" };
                var config = new MapperConfiguration(cfg => cfg.CreateMap<TodStructureOutputContentLbp, TodStructureOutputContentIj>());
                var mapper = config.CreateMapper();
        
                int count = 0;
                List <TodStructureOutputContentIj> listPart = new List<TodStructureOutputContentIj>();
                List<TodStructureOutputContentIj> listPart1 = new List<TodStructureOutputContentIj>();
                if ( string.IsNullOrEmpty(param.FromDate) && string.IsNullOrEmpty(param.ToDate))
                {
                    var dateNowUtc = DateTime.Now;
                    DateTime? dateCheck = null;
                    DateTime? dateCheck1 = null;
                    if(dateNowUtc.Hour >= 8)
                    {
                        dateCheck = new DateTime(dateNowUtc.Year, dateNowUtc.Month, dateNowUtc.Day, 8, 0, 0);
                        var dateNext = dateNowUtc.AddDays(1);
                        dateCheck1 = new DateTime(dateNext.Year, dateNext.Month, dateNext.Day, 7, 59, 59);
                    }
                    else
                    {
                        var dateNext = dateNowUtc.AddDays(-1);
                        dateCheck = new DateTime(dateNext.Year, dateNext.Month, dateNext.Day, 8, 0, 0);
                        dateCheck1 = new DateTime(dateNowUtc.Year, dateNowUtc.Month, dateNowUtc.Day, 7, 59, 59);
                    }
          
                    List<VisualizationView> lstModel1 = new List<VisualizationView>();
                    if (!string.IsNullOrEmpty(param.Product))
                    {
                        if (param.Product.Equals("IJP"))
                        {

                            listPart = await context.TodStructureOutputContentIjs.Where(x => x.Active == true && listBc1.Contains(x.Bc1) && !x.Bc12.Equals("3100")).ToListAsync();
                            listPart = !string.IsNullOrEmpty(param.PartNo) ? listPart.Where(x => x.PartNo8.ToLower().Contains(param.PartNo.ToLower())).ToList() : listPart;
                            listPart = !string.IsNullOrEmpty(param.Vendor) ? listPart.Where(x => x.Bc12.ToLower().Contains(param.Vendor.ToLower())).ToList() : listPart;
                            lstModel1 = listPart.GroupBy(x => new { x.PartNo8 }).Select(g => new VisualizationView { tod = g.First(),Product = "IJP" }).ToList();
                        }
                        else
                        {
                            var partLbp = await context.TodStructureOutputContentLbps.Where(x => x.Active == true && listBc1.Contains(x.Bc1) && !x.Bc12.Equals("3100")).ToListAsync();
                            listPart1 = mapper.Map<List<TodStructureOutputContentLbp>, List<TodStructureOutputContentIj>>(partLbp);
                            listPart1 = !string.IsNullOrEmpty(param.PartNo) ? listPart1.Where(x => x.PartNo8.ToLower().Contains(param.PartNo.ToLower())).ToList() : listPart1;
                            listPart1 = !string.IsNullOrEmpty(param.Vendor) ? listPart1.Where(x => x.Bc12.ToLower().Contains(param.Vendor.ToLower())).ToList() : listPart1;
                            lstModel1 = listPart1.GroupBy(x => new { x.PartNo8 }).Select(g => new VisualizationView { tod = g.First(), Product = "LBP" }).ToList();
                        }
                    }
                    else
                    {
                        listPart = context.TodStructureOutputContentIjs.Where(x => x.Active == true && listBc1.Contains(x.Bc1) && !x.Bc12.Equals("3100")).ToList();
                        listPart = !string.IsNullOrEmpty(param.PartNo) ? listPart.Where(x => x.PartNo8.ToLower().Contains(param.PartNo.ToLower())).ToList() : listPart;
                        listPart = !string.IsNullOrEmpty(param.Vendor) ? listPart.Where(x => x.Bc12.ToLower().Contains(param.Vendor.ToLower())).ToList() : listPart;
                        lstModel1.AddRange(listPart.GroupBy(x => new { x.PartNo8 }).Select(g => new VisualizationView { tod = g.First(), Product = "IJP" }).ToList());
                        var partLbp = await context.TodStructureOutputContentLbps.Where(x => x.Active == true && listBc1.Contains(x.Bc1) && !x.Bc12.Equals("3100")).ToListAsync();
                        listPart1=mapper.Map<List<TodStructureOutputContentLbp>, List<TodStructureOutputContentIj>>(partLbp);
                        listPart1 = !string.IsNullOrEmpty(param.PartNo) ? listPart1.Where(x => x.PartNo8.ToLower().Contains(param.PartNo.ToLower())).ToList() : listPart1;
                        listPart1 = !string.IsNullOrEmpty(param.Vendor) ? listPart1.Where(x => x.Bc12.ToLower().Contains(param.Vendor.ToLower())).ToList() : listPart1;
                        lstModel1.AddRange(listPart1.GroupBy(x => new { x.PartNo8 }).Select(g => new VisualizationView { tod = g.First(), Product = "LBP" }).ToList());


                    }
            
                    //var lstModel1 = listPart.GroupBy(x => new { x.PartNo8 }).Select(g => g.First());

                    //if (!string.IsNullOrEmpty(param.PartNo)) { listPart = listPart.Where(x => x.PartNo8.ToLower().Contains(param.PartNo.ToLower())).ToList(); }
                    //if (!string.IsNullOrEmpty(param.Vendor)) { listPart = listPart.Where(x => x.Bc12.ToLower().Contains(param.Vendor.ToLower())).ToList(); }
                    var model2 = lstModel1.Skip((param.Page - 1) * param.RecordsPerPage).Take(param.RecordsPerPage).ToList();
                    var listPartNo = model2.Select(x => x.tod.PartNo8).ToList();
                    var listStoreIn = context.VlinkageHksStoreInOuts.Where(x => x.IOut == 1 && x.PartNo != null && listPartNo.Contains(x.PartNo)).ToList().GroupBy(x => x.PartNo).ToDictionary(g => g.Key, g => g.ToList());
                    var listStoreOut = context.VlinkageHksStoreInOuts.Where(x => x.IOut == 2 && x.PartNo != null && listPartNo.Contains(x.PartNo)).ToList().GroupBy(x => x.PartNo).ToDictionary(g => g.Key, g => g.ToList());
                    var listVisual = context.InvVisualizationOp1s.Where(x => x.Active == true && listPartNo.Contains(x.PartNo)).ToList().GroupBy(x => x.PartNo).ToDictionary(g => g.Key, g => g.OrderByDescending(x => x.CreatedDate).ToList());
                    var listReceive = context.VlinkageHksReceiveParts.Where(x => listPartNo.Contains(x.PartNo)).ToList().GroupBy(x => x.PartNo).ToDictionary(g => g.Key, g => g.ToList());
                    var listShipping = context.VlinkageHksShippingParts.Where(x => listPartNo.Contains(x.PartNo)).ToList().GroupBy(x => x.PartNo).ToDictionary(g => g.Key, g => g.ToList());
                    var listLending = context.VlinkageLendingPartPdcIjs.Where(x => listPartNo.Contains(x.PartNumber)).ToList().GroupBy(x => x.PartNumber).ToDictionary(g => g.Key, g => g.ToList());
                    var listLendingAssy = context.VlinkageLendingPartAssyPcbIjs.Where(x => listPartNo.Contains(x.PartNumber)).ToList().GroupBy(x => x.PartNumber).ToDictionary(g => g.Key, g => g.ToList());
                    string[] pdc2Lbp = { "TS01", "TS06", "TSB5", "TS18", "TS15", "TSB4" };
                    string[] pdc2Ijp = { "TS07", "TS12", "TS04", "TS19", "TS16", "TS20", "TSA" };
                    string[] logLbp = { "TSB5" };
                    string[] logIjp = { "TSB" };

                    int dem = (param.Page - 1) * param.RecordsPerPage + 1;
                    count = lstModel1.Count();
                    DateOnly dateNow = DateOnly.FromDateTime(DateTime.Now);
                    foreach (var item1 in model2)
                    {
                        var item = item1.tod;
                        var lstSamePart =item1.Product.Equals("IJP")? listPart.Where(x => x.PartNo8.Equals(item.PartNo8)): listPart1.Where(x => x.PartNo8.Equals(item.PartNo8));
                        var model = string.Join(",",lstSamePart.Where(x=>!x.Model45.IsNullOrEmpty()).Select(x => x.Model45).ToList());
                        var merCode = string.Join(",", lstSamePart.Where(x => !x.MerCode47.IsNullOrEmpty()).Select(x => x.MerCode47).ToList());

                        //var listLast = listVisual.Where(x => x.PartNo.Equals(item.PartNo8)).OrderByDescending(x => x.CreatedDate).ToList();
                        listVisual.TryGetValue(item.PartNo8, out var listLast);
                        listLast = listLast ?? new List<InvVisualizationOp1>();
                        var last = listLast.Count() > 0 ? listLast.First() : null;

                        listStoreIn.TryGetValue(item.PartNo8, out var listPartIn);
                        listPartIn = listPartIn != null ? listPartIn.Where(x=>dateCheck <= x.DateEntry && x.DateEntry <= dateCheck1).ToList() : new List<VlinkageHksStoreInOut>();

                        listStoreOut.TryGetValue(item.PartNo8, out var listPartOut);
                        listPartOut = listPartOut != null ? listPartOut.Where(x => dateCheck <= x.DateEntry && x.DateEntry <= dateCheck1).ToList() : new List<VlinkageHksStoreInOut>();

                        var MoLastRemain = last != null ? last.MoRemain.Value.FormatDouble() : 0;
                        var MsdLastRemain = last != null ? last.MsdRemain.Value.FormatDouble() : 0;

                        double? MoStoreIn = 0;
                        double? MoStoreOut = 0;
                        double? MoStoreOutS = 0;
                        double? MsdStoreIn = 0;
                        double? MsdStoreOut = 0;
                        double? MsdStoreOutS = 0;
                        //if (listPartIn.Any(x=>x.DeptName != null && x.DeptName.Contains("MO")))
                        //{
                        //    MoStoreIn = listPartIn.Sum(x => x.Qty);
                        //    MoStoreOut = listPartOut.Where(x => x.Remark == null || (x.Remark != null && !x.Remark.ToLower().Contains("shikyu") && !x.Remark.Contains("Thăng Long"))).Sum(x => x.Qty);
                        //    MoStoreOutS = listPartOut.Where(x => x.Remark != null).ToList().Where(x => x.Remark.ToLower().Contains("shikyu") || x.Remark.Contains("Thăng Long")).Sum(x => x.Qty);

                        //}
                        //else if (listPartIn.Any(x => x.DeptName != null && x.DeptName.Contains("MSD")))
                        //{
                        //    MsdStoreIn = listPartIn.Sum(x => x.Qty);
                        //    MsdStoreOut = listPartOut.Where(x => x.Remark == null || (x.Remark != null && !x.Remark.ToLower().Contains("shikyu") && !x.Remark.Contains("Thăng Long"))).Sum(x => x.Qty);
                        //    MsdStoreOutS = listPartOut.Where(x => x.Remark != null).ToList().Where(x => x.Remark.ToLower().Contains("shikyu") || x.Remark.Contains("Thăng Long")).Sum(x => x.Qty);

                        //}

                            MoStoreIn = listPartIn.Where(x=>!x.DeptName.IsNullOrEmpty()).ToList().Where(x=>x.DeptName.Contains("MO")).Sum(x => x.Qty);
                            MoStoreOut = listPartOut.Where(x => !x.DeptName.IsNullOrEmpty()).ToList().Where(x => x.DeptName.Contains("MO")).Where(x => x.Remark == null || (x.Remark != null && !x.Remark.ToLower().Contains("shikyu") && !x.Remark.Contains("Thăng Long"))).Sum(x => x.Qty);
                            MoStoreOutS = listPartOut.Where(x => !x.DeptName.IsNullOrEmpty()).ToList().Where(x => x.DeptName.Contains("MO")).Where(x => x.Remark != null).ToList().Where(x => x.Remark.ToLower().Contains("shikyu") || x.Remark.Contains("Thăng Long")).Sum(x => x.Qty);

                            MsdStoreIn = listPartIn.Where(x => !x.DeptName.IsNullOrEmpty()).ToList().Where(x => x.DeptName.Contains("MSD")).Sum(x => x.Qty);
                            MsdStoreOut = listPartOut.Where(x => !x.DeptName.IsNullOrEmpty()).ToList().Where(x => x.DeptName.Contains("MSD")).Where(x => x.Remark == null || (x.Remark != null && !x.Remark.ToLower().Contains("shikyu") && !x.Remark.Contains("Thăng Long"))).Sum(x => x.Qty);
                            MsdStoreOutS = listPartOut.Where(x => !x.DeptName.IsNullOrEmpty()).ToList().Where(x => x.DeptName.Contains("MSD")).Where(x => x.Remark != null).ToList().Where(x => x.Remark.ToLower().Contains("shikyu") || x.Remark.Contains("Thăng Long")).Sum(x => x.Qty);

                        
                        ///pdc2
                        listReceive.TryGetValue(item.PartNo8, out var listPartReceive);
                        listPartReceive = listPartReceive != null ?( item1.Product.Equals("IJP")? listPartReceive.Where(x => dateCheck <= x.TimeReceive && x.TimeReceive <= dateCheck1 && pdc2Ijp.Contains(x.Location)).ToList() : listPartReceive.Where(x => dateCheck <= x.TimeReceive && x.TimeReceive <= dateCheck1 && pdc2Lbp.Contains(x.Location)).ToList()) : new List<VlinkageHksReceivePart>();

                        var Pdc2PoReceive = listPartReceive.Sum(x => x.ActQty);

                        listShipping.TryGetValue(item.PartNo8, out var listPartShipping);
                        listPartShipping = listPartShipping != null ? (item1.Product.Equals("IJP") ? listPartShipping.Where(x => x.DeliveryKey != null && !x.DeliveryKey.Substring(0,4).Equals("NGRT") &&  dateCheck <= x.TimeReceive && x.TimeReceive <= dateCheck1 && pdc2Ijp.Contains(x.Location)).ToList() : listPartShipping.Where(x => !x.DeliveryKey.Substring(0, 4).Equals("NGRT") && dateCheck <= x.TimeReceive && x.TimeReceive <= dateCheck1 && pdc2Lbp.Contains(x.Location)).ToList()) : new List<VlinkageHksShippingPart>();

                        var Pdc2Shikyu = listPartShipping.Sum(x => x.ActQty);

                        listLending.TryGetValue(item.PartNo8, out var listPartLending);
                        var dateNowCheck = DateOnly.FromDateTime(DateTime.Now);
                        var listPartLendingBorrow = listPartLending != null ? listPartLending.Where(x => dateNowCheck == x.BorrowDate && (x.BorrowLoc[0].Equals("Z")|| x.BorrowLoc[0].Equals("R")|| x.BorrowLoc[0].Equals("K")) ).ToList() : new List<VlinkageLendingPartPdcIj>();
                        var listPartLendingReturn = listPartLending != null ? listPartLending.Where(x => dateNowCheck == x.ReturnDate && (x.BorrowLoc[0].Equals("Z") || x.BorrowLoc[0].Equals("R") || x.BorrowLoc[0].Equals("K"))).ToList() : new List<VlinkageLendingPartPdcIj>();

                        var Pdc2LendingBorrow = listPartLendingBorrow.Sum(x => x.QtyBorrow);
                        var Pdc2LendingReturn = listPartLendingReturn.Sum(x => x.QtyReturn);
                        //log
                        listReceive.TryGetValue(item.PartNo8, out var listPartReceive1);
                        listPartReceive1 = listPartReceive1 != null ? (item1.Product.Equals("IJP") ? listPartReceive1.Where(x => dateCheck <= x.TimeReceive && x.TimeReceive <= dateCheck1 && logIjp.Contains(x.Location)).ToList() : listPartReceive1.Where(x => dateCheck <= x.TimeReceive && x.TimeReceive <= dateCheck1 && logLbp.Contains(x.Location)).ToList()) : new List<VlinkageHksReceivePart>();

                        var LogPoReceive = listPartReceive1.Sum(x => x.ActQty);

                        //assy
                        listLendingAssy.TryGetValue(item.PartNo8, out var listPartLendingAssy);
                        var listPartLendingAssyBorrow = listPartLendingAssy != null ? listPartLendingAssy.Where(x => dateNowCheck == x.BorrowDate ).ToList() : new List<VlinkageLendingPartAssyPcbIj>();
                        var listPartLendingAssyReturn = listPartLendingAssy != null ? listPartLendingAssy.Where(x => dateNowCheck == x.ReturnDate ).ToList() : new List<VlinkageLendingPartAssyPcbIj>();

                        var AssyLendingBorrow = listPartLendingAssyBorrow.Sum(x => x.QtyBorrow);
                        var AssyLendingReturn = listPartLendingAssyReturn.Sum(x => x.QtyReturn);
                        //
                        var MoRemain = MoLastRemain + MoStoreIn - MoStoreOut - MoStoreOutS;
                        var MsdRemain = MsdLastRemain + MsdStoreIn - MsdStoreOut - MsdStoreOutS;

                        //Pcb
                        var PcbLastRemain = last != null ? last.PcbRemain.Value.FormatDouble() : 0;
                        var PcbStoreIn = 0;
                        var PcbStoreOut = 0;
                        var PcbStoreOutS = 0;
                        var PcbRemain = PcbLastRemain + PcbStoreIn - PcbStoreOut - PcbStoreOutS;
                        //pdc2
                        var Pdc2LastRemain = last != null ? last.Pdc2Remain.Value.FormatDouble() : 0;
                        var Pdc2LastRemainStore = last != null ? last.Pdc2LastRemainStore.Value.FormatDouble() : 0;
                        var Pdc2InhouseTransfer = MoStoreOut+MsdStoreOut+PcbStoreOut;
                        var Pdc2SupplyAssy = 0;
                        var Pdc2Remain = Pdc2LastRemain + Pdc2PoReceive - Pdc2Shikyu;
                        var Pdc2RemainStore = Pdc2LastRemainStore - Pdc2LendingBorrow + Pdc2LendingReturn - Pdc2SupplyAssy;
                        //log
                        var LogLastRemain = last != null ? last.LogRemain.Value.FormatDouble() : 0;
                        var LogLendingBorrow = 0;
                        var LogLendingReturn = 0;
                        var LogSupplyAssy = 0;
                        var LogRemain = LogLastRemain + LogPoReceive - LogLendingBorrow + LogLendingReturn - LogSupplyAssy;
                        //assy
                        var AssyLastRemain = last != null ? last.AssyRemain.Value.FormatDouble() : 0;
                        var AssyPdc2Supply = Pdc2SupplyAssy;
                        var AssyRpMachine = 0;
                        var AssyRemain = AssyLastRemain + AssyPdc2Supply - AssyLendingBorrow + AssyLendingReturn - AssyRpMachine;

                        //lending
                        var TotalRemainLending = listPartLendingAssyReturn.Sum(x => x.QtyBorrow - x.QtyReturn - x.QtyDefect) + listPartLendingReturn.Sum(x => x.QtyBorrow - x.QtyReturn);

                        lstResult.Add(new InvVisualizationOp1View()
                        {
                            No = dem,
                            PartNo = item.PartNo8,
                            PartName = item.PartName11,
                            Model = string.Join(",",model.Split(",").Distinct().ToList()),
                            Dest = string.Join(",", merCode.Split(",").Distinct().ToList()),
                            Date = dateNow.ToString("dd-MMM-yy"),
                            MoLastRemain = MoLastRemain.ToString() ,
                            MoStoreIn = MoStoreIn.ToString(),
                            MoStoreOut = MoStoreOut.ToString(),
                            MoStoreOutS = MoStoreOutS.ToString(),
                            MoRemain = MoRemain.ToString(),
                            MsdLastRemain = MsdLastRemain.ToString(),
                            MsdStoreIn = MsdStoreIn.ToString(),
                            MsdStoreOut = MsdStoreOut.ToString(),
                            MsdStoreOutS = MsdStoreOutS.ToString(),
                            MsdRemain = MsdRemain.ToString(),
                            PcbLastRemain = PcbLastRemain.ToString(),
                            PcbStoreIn = PcbStoreIn.ToString(),
                            PcbStoreOut = PcbStoreOut.ToString(),
                            PcbStoreOutS = PcbStoreOutS.ToString(),
                            PcbRemain = PcbRemain.ToString(),
                            Pdc2LastRemain = Pdc2LastRemain.ToString(),
                            Pdc2LastRemainStore = Pdc2LastRemainStore.ToString(),
                            Pdc2PoReceive = Pdc2PoReceive.ToString(),                      
                            Pdc2InhouseTransfer = Pdc2InhouseTransfer.ToString(),
                            Pdc2Shikyu = Pdc2Shikyu.ToString(),
                            Pdc2LendingBorrow = Pdc2LendingBorrow.ToString(),
                            Pdc2LendingReturn = Pdc2LendingReturn.ToString(),
                            Pdc2SupplyAssy = Pdc2SupplyAssy.ToString(),
                            Pdc2Remain = Pdc2Remain.ToString(),
                            Pdc2RemainStore = Pdc2RemainStore.ToString(),
                            LogLastRemain = LogLastRemain.ToString(),
                            LogPoReceive = LogPoReceive.ToString(),
                            LogLendingBorrow = LogLendingBorrow.ToString(),
                            LogLendingReturn = LogLendingReturn.ToString(),
                            LogSupplyAssy = LogSupplyAssy.ToString(),
                            LogRemain = LogRemain.ToString(),
                            AssyLastRemain = AssyLastRemain.ToString(),
                            AssyPdc2Supply = AssyPdc2Supply.ToString(),
                            AssyLendingBorrow = AssyLendingBorrow.ToString(),
                            AssyLendingReturn = AssyLendingReturn.ToString(),
                            AssyRpMachine = AssyRpMachine.ToString(),
                            AssyRemain = AssyRemain.ToString(),
                            TotalRemainMo = MoRemain.ToString(),
                            TotalRemainMsd = MsdRemain.ToString(),
                            TotalRemainPcb = PcbRemain.ToString(),
                            TotalRemainPdc2Rec = Pdc2Remain.ToString(),
                            TotalRemainPdc2Store = Pdc2RemainStore.ToString(),
                            TotalRemainLog = LogRemain.ToString(),
                            TotalRemainAssy = AssyRemain.ToString(),
                            TotalRemainLending = TotalRemainLending.ToString(),
                            TotalRemainTtl =( MoRemain + MsdRemain + PcbRemain+Pdc2Remain+Pdc2RemainStore+LogRemain+AssyRemain + TotalRemainLending).ToString()
                        });
                        dem++;
                    }

                }
                else
                {
                    var model = context.InvVisualizationOp1s.Where(x => x.Active == true).AsQueryable();
                    if (!string.IsNullOrEmpty(param.Product)) { model = model.Where(x => x.Product.ToLower().Contains(param.Product.ToLower())); }
                    if (!string.IsNullOrEmpty(param.PartNo)) { model = model.Where(x => x.PartNo.ToLower().Contains(param.PartNo.ToLower())); }
                    if (!string.IsNullOrEmpty(param.Vendor)) { model = model.Where(x => x.Vendor.ToLower().Contains(param.Vendor.ToLower())); }
                    if (!string.IsNullOrEmpty(param.FromDate) && string.IsNullOrEmpty(param.ToDate)) { var fromdate = DateOnly.FromDateTime(DateTime.ParseExact(param.FromDate, "dd-MM-yyyy", null)); model = model.Where(x => x.Date == fromdate); }
                    else if (string.IsNullOrEmpty(param.FromDate) && !string.IsNullOrEmpty(param.ToDate)) { var todate = DateOnly.FromDateTime(DateTime.ParseExact(param.ToDate, "dd-MM-yyyy", null)); model = model.Where(x => x.Date == todate); }
                    else if (!string.IsNullOrEmpty(param.FromDate) && !string.IsNullOrEmpty(param.ToDate)) { var todate = DateOnly.FromDateTime(DateTime.ParseExact(param.ToDate, "dd-MM-yyyy", null)); var fromdate = DateOnly.FromDateTime(DateTime.ParseExact(param.FromDate, "dd-MM-yyyy", null)); model = model.Where(x => x.Date >= fromdate && x.Date <= todate); }
                    var model2 = model.Skip((param.Page - 1) * param.RecordsPerPage).Take(param.RecordsPerPage).ToList();
                    int dem = (param.Page - 1) * param.RecordsPerPage + 1;
                    count = model.Count();
                    foreach (var item in model2)
                    {
                        lstResult.Add(new InvVisualizationOp1View()
                        {
                            No = dem,
                            PartNo = item.PartNo,
                            PartName = item.PartName,
                            Model = item.Model,
                            Dest = item.Dest,
                            Date= item.Date.Value.ToString("dd-MMM-yy"),
                            MoLastRemain = item.MoLastRemain.Value.FormatDouble().ToString(),
                            MoStoreIn = item.MoStoreIn.Value.FormatDouble().ToString(),
                            MoStoreOut = item.MoStoreOut.Value.FormatDouble().ToString(),
                            MoStoreOutS = item.MoStoreOutS.Value.FormatDouble().ToString(),
                            MoRemain = item.MoRemain.Value.FormatDouble().ToString(),
                            MsdLastRemain = item.MsdLastRemain.Value.FormatDouble().ToString(),
                            MsdStoreIn = item.MsdStoreIn.Value.FormatDouble().ToString(),
                            MsdStoreOut = item.MsdStoreOut.Value.FormatDouble().ToString(),
                            MsdStoreOutS = item.MsdStoreOutS.Value.FormatDouble().ToString(),
                            MsdRemain = item.MsdRemain.Value.FormatDouble().ToString(),
                            PcbLastRemain = item.PcbLastRemain.Value.FormatDouble().ToString(),
                            PcbStoreIn = item.PcbStoreIn.Value.FormatDouble().ToString(),
                            PcbStoreOut = item.PcbStoreOut.Value.FormatDouble().ToString(),
                            PcbStoreOutS = item.PcbStoreOutS.Value.FormatDouble().ToString(),
                            PcbRemain = item.PcbRemain.Value.FormatDouble().ToString(),
                            Pdc2LastRemain = item.Pdc2LastRemain.Value.FormatDouble().ToString(),
                            Pdc2PoReceive = item.Pdc2PoReceive.Value.FormatDouble().ToString(),
                            Pdc2InhouseTransfer = item.Pdc2InhouseTransfer.Value.FormatDouble().ToString(),
                            Pdc2Shikyu = item.Pdc2Shikyu.Value.FormatDouble().ToString(),
                            Pdc2LendingBorrow = item.Pdc2LendingBorrow.Value.FormatDouble().ToString(),
                            Pdc2LendingReturn = item.Pdc2LendingReturn.Value.FormatDouble().ToString(),
                            Pdc2SupplyAssy = item.Pdc2SupplyAssy.Value.FormatDouble().ToString(),
                            Pdc2Remain = item.Pdc2Remain.Value.FormatDouble().ToString(),
                            LogLastRemain = item.LogLastRemain.Value.FormatDouble().ToString(),
                            LogPoReceive = item.LogPoReceive.Value.FormatDouble().ToString(),
                            LogLendingBorrow = item.LogLendingBorrow.Value.FormatDouble().ToString(),
                            LogLendingReturn = item.LogLendingReturn.Value.FormatDouble().ToString(),
                            LogSupplyAssy = item.LogSupplyAssy.Value.FormatDouble().ToString(),
                            LogRemain= item.LogRemain.Value.FormatDouble().ToString(),
                            AssyLastRemain = item.AssyLastRemain.Value.FormatDouble().ToString(),
                            AssyPdc2Supply = item.AssyPdc2Supply.Value.FormatDouble().ToString(),
                            AssyLendingBorrow = item.AssyLendingBorrow.Value.FormatDouble().ToString(),
                            AssyLendingReturn = item.AssyLendingReturn.Value.FormatDouble().ToString(),
                            AssyRpMachine= item.AssyRpMachine.Value.FormatDouble().ToString(),
                            AssyRemain = item.AssyRemain.Value.FormatDouble().ToString(),
                            TotalRemainMo = item.TotalRemainMo.Value.FormatDouble().ToString(),
                            TotalRemainMsd = item.TotalRemainMsd.Value.FormatDouble().ToString(),
                            TotalRemainPcb = item.TotalRemainPcb.Value.FormatDouble().ToString(),
                            TotalRemainPdc2Rec = item.TotalRemainPdc2Rec.Value.FormatDouble().ToString(),
                            TotalRemainPdc2Store = item.TotalRemainPdc2Store.Value.FormatDouble().ToString(),
                            TotalRemainLog = item.TotalRemainLog.Value.FormatDouble().ToString(),
                            TotalRemainAssy = item.TotalRemainAssy.Value.FormatDouble().ToString(),
                            TotalRemainLending = item.TotalRemainLending.Value.FormatDouble().ToString(),
                            TotalRemainTtl = item.TotalRemainTtl.Value.FormatDouble().ToString()

                        });
                        dem++;
                    }

                }
                   
                result.lstModel = lstResult;
                result.toRecord = (int)Math.Min(result.totalRecords, result.currentPage * result.recordPerPage);
                result.totalPage = (int)Math.Ceiling((decimal)count / param.RecordsPerPage);
                result.totalRecords = count;
                result.recordPerPage = param.RecordsPerPage;
                result.currentPage = param.Page;
                result.fromRecord = count == 0 ? 0 : (result.currentPage - 1) * result.recordPerPage + 1;
                return result;
            }
            catch (Exception e)
            {
                return new InvVisualizationOp1Model();
            }
        }
        [HttpPost("filter-visualization-op2")]
        public async Task<InvVisualizationOp2Model> FilterVisualizationOp2(BalanceParam param)
        {
            try
            {
                var result = new InvVisualizationOp2Model();
                var lstResult = new List<InvVisualizationOp2View>();
                string[] listBc1 = { "3200" };
                var config = new MapperConfiguration(cfg => cfg.CreateMap<TodStructureOutputContentLbp, TodStructureOutputContentIj>());
                var mapper = config.CreateMapper();

                int count = 0;
                List<TodStructureOutputContentIj> listPart = new List<TodStructureOutputContentIj>();
                List<TodStructureOutputContentIj> listPart1 = new List<TodStructureOutputContentIj>();
                if (string.IsNullOrEmpty(param.FromDate) && string.IsNullOrEmpty(param.ToDate))
                {
                    var dateNowUtc = DateTime.Now;
                    DateTime? dateCheck = null;
                    DateTime? dateCheck1 = null;
                    if (dateNowUtc.Hour >= 8)
                    {
                        dateCheck = new DateTime(dateNowUtc.Year, dateNowUtc.Month, dateNowUtc.Day, 8, 0, 0);
                        var dateNext = dateNowUtc.AddDays(1);
                        dateCheck1 = new DateTime(dateNext.Year, dateNext.Month, dateNext.Day, 7, 59, 59);
                    }
                    else
                    {
                        var dateNext = dateNowUtc.AddDays(-1);
                        dateCheck = new DateTime(dateNext.Year, dateNext.Month, dateNext.Day, 8, 0, 0);
                        dateCheck1 = new DateTime(dateNowUtc.Year, dateNowUtc.Month, dateNowUtc.Day, 7, 59, 59);
                    }
                    List<VisualizationView> lstModel1 = new List<VisualizationView>();
                    //var listVisual = context.InvVisualizationOp2s.Where(x => x.Active == true).ToList();
                    if (!string.IsNullOrEmpty(param.Product))
                    {
                        if (param.Product.Equals("IJP"))
                        {

                            listPart = await context.TodStructureOutputContentIjs.Where(x => x.Active == true && listBc1.Contains(x.Bc1) && !x.Bc12.Equals("3200")).ToListAsync();
                            listPart = !string.IsNullOrEmpty(param.PartNo) ? listPart.Where(x => x.PartNo8.ToLower().Contains(param.PartNo.ToLower())).ToList() : listPart;
                            listPart = !string.IsNullOrEmpty(param.Vendor) ? listPart.Where(x => x.Bc12.ToLower().Contains(param.Vendor.ToLower())).ToList() : listPart;
                            lstModel1 = listPart.GroupBy(x => new { x.PartNo8 }).Select(g => new VisualizationView { tod = g.First(), Product = "IJP" }).ToList();
                        }
                        else
                        {
                            var partLbp = await context.TodStructureOutputContentLbps.Where(x => x.Active == true && listBc1.Contains(x.Bc1) && !x.Bc12.Equals("3200")).ToListAsync();
                            listPart1 = mapper.Map<List<TodStructureOutputContentLbp>, List<TodStructureOutputContentIj>>(partLbp);
                            listPart1 = !string.IsNullOrEmpty(param.PartNo) ? listPart1.Where(x => x.PartNo8.ToLower().Contains(param.PartNo.ToLower())).ToList() : listPart1;
                            listPart1 = !string.IsNullOrEmpty(param.Vendor) ? listPart1.Where(x => x.Bc12.ToLower().Contains(param.Vendor.ToLower())).ToList() : listPart1;
                            lstModel1 = listPart1.GroupBy(x => new { x.PartNo8 }).Select(g => new VisualizationView { tod = g.First(), Product = "LBP" }).ToList();
                        }
                    }
                    else
                    {
                        listPart=context.TodStructureOutputContentIjs.Where(x => x.Active == true && listBc1.Contains(x.Bc1) && !x.Bc12.Equals("3200")).ToList();
                        listPart = !string.IsNullOrEmpty(param.PartNo) ? listPart.Where(x => x.PartNo8.ToLower().Contains(param.PartNo.ToLower())).ToList() : listPart;
                        listPart = !string.IsNullOrEmpty(param.Vendor) ? listPart.Where(x => x.Bc12.ToLower().Contains(param.Vendor.ToLower())).ToList() : listPart;
                        lstModel1.AddRange(listPart.GroupBy(x => new { x.PartNo8 }).Select(g => new VisualizationView { tod = g.First(), Product = "IJP" }).ToList());
                        var partLbp = await context.TodStructureOutputContentLbps.Where(x => x.Active == true && listBc1.Contains(x.Bc1) && !x.Bc12.Equals("3200")).ToListAsync();
                        listPart1=mapper.Map<List<TodStructureOutputContentLbp>, List<TodStructureOutputContentIj>>(partLbp);
                        listPart1 = !string.IsNullOrEmpty(param.PartNo) ? listPart1.Where(x => x.PartNo8.ToLower().Contains(param.PartNo.ToLower())).ToList() : listPart1;
                        listPart1 = !string.IsNullOrEmpty(param.Vendor) ? listPart1.Where(x => x.Bc12.ToLower().Contains(param.Vendor.ToLower())).ToList() : listPart1;
                        lstModel1.AddRange(listPart1.GroupBy(x => new { x.PartNo8 }).Select(g => new VisualizationView { tod = g.First(), Product = "LBP" }).ToList());
                    }

                    //if (!string.IsNullOrEmpty(param.PartNo)) { listPart = listPart.Where(x => x.PartNo8.ToLower().Contains(param.PartNo.ToLower())).ToList(); }
                    //if (!string.IsNullOrEmpty(param.Vendor)) { listPart = listPart.Where(x => x.Bc12.ToLower().Contains(param.Vendor.ToLower())).ToList(); }
                    var model2 = lstModel1.Skip((param.Page - 1) * param.RecordsPerPage).Take(param.RecordsPerPage).ToList();

                    var listPartNo = model2.Select(x => x.tod.PartNo8).ToList();
                    var listStoreIn = context.VlinkageHksStoreInOuts.Where(x => x.IOut == 1 && x.PartNo != null && listPartNo.Contains(x.PartNo)).ToList().GroupBy(x => x.PartNo).ToDictionary(g => g.Key, g => g.ToList());
                    var listStoreOut = context.VlinkageHksStoreInOuts.Where(x => x.IOut == 2 && x.PartNo != null && listPartNo.Contains(x.PartNo)).ToList().GroupBy(x => x.PartNo).ToDictionary(g => g.Key, g => g.ToList());
                    var listVisual = context.InvVisualizationOp2s.Where(x => x.Active == true && listPartNo.Contains(x.PartNo)).ToList().GroupBy(x => x.PartNo).ToDictionary(g => g.Key, g => g.OrderByDescending(x => x.CreatedDate).ToList());
                    var listReceive = context.VlinkageHksReceiveParts.Where(x => listPartNo.Contains(x.PartNo)).ToList().GroupBy(x => x.PartNo).ToDictionary(g => g.Key, g => g.ToList());
                    var listShipping = context.VlinkageHksShippingParts.Where(x => listPartNo.Contains(x.PartNo)).ToList().GroupBy(x => x.PartNo).ToDictionary(g => g.Key, g => g.ToList());
                    var listLending = context.VlinkageLendingPartPdcIjs.Where(x => listPartNo.Contains(x.PartNumber)).ToList().GroupBy(x => x.PartNumber).ToDictionary(g => g.Key, g => g.ToList());
                    var listLendingAssy = context.VlinkageLendingPartAssyPcbIjs.Where(x => listPartNo.Contains(x.PartNumber)).ToList().GroupBy(x => x.PartNumber).ToDictionary(g => g.Key, g => g.ToList());
                    string[] pdc2Lbp = { "TS01", "TS06", "TSB5", "TS18", "TS15", "TSB4" };
                    string[] pdc2Ijp = { "TS07", "TS12", "TS04", "TS19", "TS16", "TS20", "TSA" };
                    string[] logLbp = { "TSB5" };
                    string[] logIjp = { "TSB" };

                    int dem = (param.Page - 1) * param.RecordsPerPage + 1;
                    count = lstModel1.Count();
                    DateOnly dateNow = DateOnly.FromDateTime(DateTime.Now);
                    foreach (var item1 in model2)
                    {
                        var item = item1.tod;
                        var lstSamePart = listPart.Where(x => x.PartNo8.Equals(item.PartNo8));
                        var model = string.Join(",", lstSamePart.Where(x => !x.Model45.IsNullOrEmpty()).Select(x => x.Model45).ToList());
                        //var merCode = string.Join(",", lstSamePart.Where(x => !x.MerCode47.IsNullOrEmpty()).Select(x => x.MerCode47).ToList());

                        listVisual.TryGetValue(item.PartNo8, out var listLast);
                        listLast = listLast ?? new List<InvVisualizationOp2>();
                        var last = listLast.Count() > 0 ? listLast.First() : null;

                        listStoreIn.TryGetValue(item.PartNo8, out var listPartIn);
                        listPartIn = listPartIn != null ? listPartIn.Where(x => dateCheck <= x.DateEntry && x.DateEntry <= dateCheck1).ToList() : new List<VlinkageHksStoreInOut>();

                        listStoreOut.TryGetValue(item.PartNo8, out var listPartOut);
                        listPartOut = listPartOut != null ? listPartOut.Where(x => dateCheck <= x.DateEntry && x.DateEntry <= dateCheck1).ToList() : new List<VlinkageHksStoreInOut>();
                        var MoLastRemain = last != null ? last.MoRemain.Value.FormatDouble() : 0;
                        double? MoStoreIn = 0;
                        double? MoStoreOut = 0;
                        
                        if (listPartIn.Any(x => x.DeptName != null && x.DeptName.Contains("MO")))
                        {
                            MoStoreIn = listPartIn.Sum(x => x.Qty);
                            MoStoreOut = listPartOut.Where(x => x.Remark == null || (x.Remark != null && !x.Remark.Contains("Shikyu") && !x.Remark.Contains("Thăng Long"))).Sum(x => x.Qty);
                        }
                        //pcb
                        var dateNowCheck = DateOnly.FromDateTime(DateTime.Now);
                        listLendingAssy.TryGetValue(item.PartNo8, out var listPartLendingAssy);
                        var listPartLendingAssyBorrow = listPartLendingAssy != null ? listPartLendingAssy.Where(x => dateNowCheck == x.BorrowDate).ToList() : new List<VlinkageLendingPartAssyPcbIj>();
                        var listPartLendingAssyReturn = listPartLendingAssy != null ? listPartLendingAssy.Where(x => dateNowCheck == x.ReturnDate).ToList() : new List<VlinkageLendingPartAssyPcbIj>();

                        var AssyLendingBorrow = listPartLendingAssyBorrow.Sum(x => x.QtyBorrow);
                        var AssyLendingReturn = listPartLendingAssyReturn.Sum(x => x.QtyReturn);
                        //pdc
                        listReceive.TryGetValue(item.PartNo8, out var listPartReceive);
                        var listPartReceive1 = listPartReceive != null ? listPartReceive.Where(x => dateCheck <= x.TimeReceive && x.TimeReceive <= dateCheck1).ToList() : new List<VlinkageHksReceivePart>();
                        var listPartReceive2 = listPartReceive != null ?  listPartReceive.Where(x => dateCheck <= x.TimeReceive && x.TimeReceive <= dateCheck1 && x.DeliveryKey.Substring(0,2).Equals("BR")).ToList() : new List<VlinkageHksReceivePart>();

                        var Pdc2PoReceive1 = listPartReceive1.Sum(x => x.ActQty);
                        var Pdc2PoReceive2 = listPartReceive2.Sum(x => x.ActQty);

                        listShipping.TryGetValue(item.PartNo8, out var listPartShipping);
                        listPartShipping = listPartShipping != null ?  listPartShipping.Where(x => x.DeliveryKey != null && x.DeliveryKey.Substring(0, 2).Equals("BR") && dateCheck <= x.TimeReceive && x.TimeReceive <= dateCheck1).ToList() : new List<VlinkageHksShippingPart>();

                        var Pdc2Shikyu = listPartShipping.Sum(x => x.ActQty);

                        listLending.TryGetValue(item.PartNo8, out var listPartLending);
                        var listPartLendingBorrow = listPartLending != null ? listPartLending.Where(x => dateNowCheck == x.BorrowDate && x.BorrowLoc.Contains("PDC2") ).ToList() : new List<VlinkageLendingPartPdcIj>();
                        var listPartLendingReturn = listPartLending != null ? listPartLending.Where(x => dateNowCheck == x.ReturnDate && x.BorrowLoc.Contains("PDC2") ).ToList() : new List<VlinkageLendingPartPdcIj>();

                        var Pdc2LendingBorrow = listPartLendingBorrow.Sum(x => x.QtyBorrow);
                        var Pdc2LendingReturn = listPartLendingReturn.Sum(x => x.QtyReturn);

                        lstResult.Add(new InvVisualizationOp2View()
                        {
                            No = dem,
                            PartNo = item.PartNo8,
                            PartName = item.PartName11,
                            Model = string.Join(",", model.Split(",").Distinct().ToList()),
                            Unit = item.Unit13,
                            Date = dateNow.ToString("dd-MMM-yy"),
                            MoLastRemain = MoLastRemain.ToString(),
                            MoStoreIn = MoStoreIn.ToString(),
                            MoStoreOut = MoStoreOut.ToString(),
                            MoRemain = (MoLastRemain + MoStoreIn - MoStoreOut).ToString(),
                            PcbLastRemain = last != null ? last.PcbRemain.Value.FormatDouble().ToString() : "0",
                            PcbPdc2Supply = "0",
                            PcbLendingBorrow = AssyLendingBorrow.ToString(),
                            PcbLendingReturn = AssyLendingReturn.ToString(),
                            PcbRpUnit = "0",
                            PcbRemain = "0",
                            Pdc2LastRemain = last != null ? last.Pdc2Remain.Value.FormatDouble().ToString() : "0",
                            Pdc2PoReceive = Pdc2PoReceive1.ToString(),
                            Pdc2InhouseSupply = "0",
                            Pdc2TlTransfer = Pdc2PoReceive2.ToString(),
                            Pdc2TsTransfer = Pdc2Shikyu.ToString(),
                            Pdc2LendingBorrow = Pdc2LendingBorrow.ToString(),
                            Pdc2LendingReturn = Pdc2LendingReturn.ToString(),
                            Pdc2SupplyPcb = "0",
                            Pdc2Remain = "0",                           
                            TotalMoStock = "0",
                            TotalPdc2Stock = "0",
                            TotalPcbStock = "0",
                            TotalLending = "0",
                            TotalTtlRemain = "0"
                        });
                        dem++;
                    }

                }
                else
                {
                    var model = context.InvVisualizationOp2s.Where(x => x.Active == true).AsQueryable();
                    if (!string.IsNullOrEmpty(param.Product)) { model = model.Where(x => x.Product.ToLower().Contains(param.Product.ToLower())); }
                    if (!string.IsNullOrEmpty(param.PartNo)) { model = model.Where(x => x.PartNo.ToLower().Contains(param.PartNo.ToLower())); }
                    if (!string.IsNullOrEmpty(param.Vendor)) { model = model.Where(x => x.Vendor.ToLower().Contains(param.Vendor.ToLower())); }
                    if (!string.IsNullOrEmpty(param.FromDate) && string.IsNullOrEmpty(param.ToDate)) { var fromdate = DateOnly.FromDateTime(DateTime.ParseExact(param.FromDate, "dd-MM-yyyy", null)); model = model.Where(x => x.Date == fromdate); }
                    else if (string.IsNullOrEmpty(param.FromDate) && !string.IsNullOrEmpty(param.ToDate)) { var todate = DateOnly.FromDateTime(DateTime.ParseExact(param.ToDate, "dd-MM-yyyy", null)); model = model.Where(x => x.Date == todate); }
                    else if (!string.IsNullOrEmpty(param.FromDate) && !string.IsNullOrEmpty(param.ToDate)) { var todate = DateOnly.FromDateTime(DateTime.ParseExact(param.ToDate, "dd-MM-yyyy", null)); var fromdate = DateOnly.FromDateTime(DateTime.ParseExact(param.FromDate, "dd-MM-yyyy", null)); model = model.Where(x => x.Date >= fromdate && x.Date <= todate); }
                    var model2 = model.Skip((param.Page - 1) * param.RecordsPerPage).Take(param.RecordsPerPage).ToList();
                    int dem = (param.Page - 1) * param.RecordsPerPage + 1;
                    count = model.Count();
                    foreach (var item in model2)
                    {
                        lstResult.Add(new InvVisualizationOp2View()
                        {
                            No = dem,
                            PartNo = item.PartNo,
                            PartName = item.PartName,
                            Model = item.Model,
                            Unit = item.Unit,
                            Date = item.Date.Value.ToString("dd-MMM-yy"),
                            MoLastRemain = item.MoLastRemain.Value.FormatDouble().ToString(),
                            MoStoreIn = item.MoStoreIn.Value.FormatDouble().ToString(),
                            MoStoreOut = item.MoStoreOut.Value.FormatDouble().ToString(),                  
                            MoRemain = item.MoRemain.Value.FormatDouble().ToString(),                       
                            PcbLastRemain = item.PcbLastRemain.Value.FormatDouble().ToString(),
                            PcbPdc2Supply = item.PcbPdc2Supply.Value.FormatDouble().ToString(),
                            PcbLendingBorrow = item.Pdc2LendingBorrow.Value.FormatDouble().ToString(),
                            PcbLendingReturn = item.PcbLendingReturn.Value.FormatDouble().ToString(),
                            PcbRpUnit = item.PcbRpUnit.Value.FormatDouble().ToString(),
                            PcbRemain = item.PcbRemain.Value.FormatDouble().ToString(),
                            Pdc2LastRemain = item.Pdc2LastRemain.Value.FormatDouble().ToString(),
                            Pdc2PoReceive = item.Pdc2PoReceive.Value.FormatDouble().ToString(),
                            Pdc2InhouseSupply = item.Pdc2InhouseSupply.Value.FormatDouble().ToString(),
                            Pdc2TlTransfer = item.Pdc2TlTransfer.Value.FormatDouble().ToString(),
                            Pdc2TsTransfer = item.Pdc2TsTransfer.Value.FormatDouble().ToString(),
                            Pdc2LendingBorrow = item.Pdc2LendingBorrow.Value.FormatDouble().ToString(),
                            Pdc2LendingReturn = item.Pdc2LendingReturn.Value.FormatDouble().ToString(),
                            Pdc2SupplyPcb = item.Pdc2SupplyPcb.Value.FormatDouble().ToString(),
                            Pdc2Remain = item.Pdc2Remain.Value.FormatDouble().ToString(),                         
                            TotalMoStock = item.TotalMoStock.Value.FormatDouble().ToString(),
                            TotalPdc2Stock = item.TotalPdc2Stock.Value.FormatDouble().ToString(),
                            TotalPcbStock = item.TotalPcbStock.Value.FormatDouble().ToString(),
                            TotalLending = item.TotalLending.Value.FormatDouble().ToString(),
                            TotalTtlRemain = item.TotalTtlRemain.Value.FormatDouble().ToString(),                         

                        });
                        dem++;
                    }

                }

                result.lstModel = lstResult;
                result.toRecord = (int)Math.Min(result.totalRecords, result.currentPage * result.recordPerPage);
                result.totalPage = (int)Math.Ceiling((decimal)count / param.RecordsPerPage);
                result.totalRecords = count;
                result.recordPerPage = param.RecordsPerPage;
                result.currentPage = param.Page;
                result.fromRecord = count == 0 ? 0 : (result.currentPage - 1) * result.recordPerPage + 1;
                return result;
            }
            catch (Exception e)
            {
                return new InvVisualizationOp2Model();
            }
        }
        [HttpGet("get-snp-lack/{product}")]
        [AllowAnonymous]
        public CommonResponse GetSNPLack(string product)
        {
            var res = new CommonResponse()
            {
                Error = false,
                Message = "Successful !",
                Status = 200
            };
            try
            {
                var dateNow = DateOnly.FromDateTime(DateTime.Now);
                //var dateNowStr = DateTime.Now.ToString("yyyyMMdd");
                var term = context.InvCalendarTerms.FirstOrDefault(x => x.TimeFrom <= dateNow && dateNow <= x.TimeTo);
                if(term != null)
                {
                    var config = new MapperConfiguration(cfg => cfg.CreateMap<TodStructureOutputContentLbp, TodStructureOutputContentIj>());
                    var mapper = config.CreateMapper();
                    var listStructure = new List<TodStructureOutputContentIj>();
                    if (product.Equals("IJP"))
                    {
                        listStructure =  context.TodStructureOutputContentIjs.ToList();
                    }
                    else
                    {
                        var e700Lbp =  context.TodStructureOutputContentLbps.AsNoTracking().ToList();
                        listStructure = mapper.Map<List<TodStructureOutputContentLbp>, List<TodStructureOutputContentIj>>(e700Lbp);
                    }
                    var partHis = context.InvOutputPartHis.Where(x => x.Active == true).ToList();
                    IConfigurationRoot configuration = new ConfigurationBuilder().SetBasePath(AppDomain.CurrentDomain.BaseDirectory).AddJsonFile("appsettings.json").Build();          
                    var fact = configuration["ListProduct:factory_code"].ObjToStringAble();
                    var listLack = context.InvLackSnps.Where(x => x.Active == true).ToList();
                    var listNo = listLack.Select(x => x.ClaimCardNo).ToList();
                    var listDetail = context.InvSnpDetails.Where(x => x.Active == true).ToList();
                    var listSnp = context.InvSnps.Where(x => x.Active == true && x.Product.Equals(product) && x.PeriodId == term.Id).ToList();
                    var listLackCheck = context.InvLackSnps.Where(x => x.Active == true && x.Product.Equals(product) && x.Term.ToUpper().Equals(term.Term.ToUpper())).ToList();
                    List<InvLackSnp> listAdd = new List<InvLackSnp>();
                    foreach (var item in listSnp)
                    {
                        var structure = listStructure.FirstOrDefault(x => x.PartNo8.Equals(item.PartNo) && x.Bc12.Equals(item.Vendor));
                        var invPart = partHis.Where(x => x.PartNo.Equals(item.PartNo) && x.Vendor.Equals(item.Vendor)).ToList();
                        var listTime = listLack.Where(x => x.PartNo.Equals(item.PartNo) && x.Vendor.Equals(item.Vendor)).OrderByDescending(x=>x.Time).FirstOrDefault();
                        var timeCheck = listTime != null ? listTime.Time : 0;
                        var list = listDetail.Where(x => x.SnpId == item.Id && x.Differ < 0 && x.Time > timeCheck).OrderBy(x => x.Time).ToList();
                        if(list.Count() > 0)
                        {
                            foreach (var item1 in list)
                            {
                                var lack = listLackCheck.FirstOrDefault(x => x.PartNo.Equals(item.PartNo) && x.Vendor.Equals(item.Vendor) && x.Time == item1.Time);
                                if(lack == null)
                                {
                                    //Tạm thời để TS bao giờ build thật thì để là fact
                                    //var predix = fact+"-"+item1.DetectedBy + " " + product + "-" + item1.CheckDate.Value.ToString("yyyyMMdd");
                                    var predix = "TS" + "-" + item1.DetectedBy.Trim() + " " + product + "-" + item1.CheckDate.Value.ToString("yyyyMMdd");
                                    var cardNo = "";
                                    var cardNoMax = listNo.Where(x => x.StartsWith(predix)).OrderByDescending(x => x).FirstOrDefault();
                                    if( cardNoMax != null)
                                    {
                                        var index = int.Parse(cardNoMax.Split("-").Last())+1;
                                        cardNo = predix + "-" + (index < 10 ? ("0" + index) : index.ToString());
                                    }
                                    else
                                    {
                                        cardNo = predix + "-01";
                                    }
                                    listNo.Add(cardNo);
                                    var kind = structure != null ? structure.Location125 : "";
                                    listAdd.Add(new InvLackSnp()
                                    {
                                        Term = term.Term,
                                        ClaimCardNo = cardNo,
                                        DetectedDate = item1.CheckDate,
                                        Vendor = item.Vendor,
                                        KindOfPart = kind,
                                        Sp = invPart.Count() > 0 ? string.Join(",",invPart.Select(x=>x.Sp).Distinct().ToList()) :"",
                                        PartNo = item.PartNo,
                                        PartName = item.PartName,
                                        MmPic = structure != null ? structure.DoPic43 : "",
                                        Snp = item1.SnpCheck,
                                        ActualQty = item1.Actual,
                                        LackingQty = item1.Differ,
                                        ProductionOnDate = item1.ProductionLot,
                                        DeliveryDate = item1.CheckDate,
                                        DetectBy = item1.DetectedBy,
                                        RepeatTime = listLack.Where(x=>x.PartNo.Equals(item.PartNo) && x.Vendor.Equals(item.Vendor)).Count()+1,
                                        Time = listDetail.Where(x => x.SnpId == item.Id).OrderByDescending(x => x.Time).First().Time,
                                        Product = product,
                                        PlanReceive = kind.ToUpper().Equals("DPS") ? DateOnly.FromDateTime(item1.CheckDate.Value.ToDateTime(TimeOnly.MinValue).AddDays(7)) : DateOnly.FromDateTime(item1.CheckDate.Value.ToDateTime(TimeOnly.MinValue).AddDays(14))
                                    });
                                }
                            }
                        
                        }

                    }
                    context.InvLackSnps.AddRange(listAdd);
                }         

                context.SaveChanges();
                res.Error = false;
                res.Message = "Successful !";
                res.Status = 200;
            }
            catch (Exception e)
            {
                //SendMailError(e);
                res.Error = true;
                res.Message = e.Message;
                res.Status = 400;
            }
            return res;
        }
        [HttpPost("filter-lack-snp")]
        public LackSnpModel FilterLackSnp(SnpParam param)
        {
            try
            {
                var result = new LackSnpModel();
                var lstResult = new List<LackSnpView>();

                var model = context.InvLackSnps.Where(x => x.Active == true).OrderByDescending(x=>x.ClaimCardNo).AsQueryable();
                if (!string.IsNullOrEmpty(param.Product)) { model = model.Where(x => x.Product.ToUpper().Contains(param.Product.ToUpper())); }
                if (!string.IsNullOrEmpty(param.Term)) { model = model.Where(x => x.Term.ToUpper().Contains(param.Term.ToUpper())); }
                if (!string.IsNullOrEmpty(param.PartNo)) { model = model.Where(x => x.PartNo.ToLower().Contains(param.PartNo.ToLower()) || x.ClaimCardNo.ToLower().Contains(param.PartNo.ToLower())); }
                if (!string.IsNullOrEmpty(param.DetectedDate)) { var DetectDate = DateOnly.FromDateTime(DateTime.ParseExact(param.DetectedDate, "dd-MM-yyyy", null)); model = model.Where(x => x.DetectedDate == DetectDate); }
                if (!string.IsNullOrEmpty(param.Pic)) { model = model.Where(x => x.MmPic.ToLower().Contains(param.Pic.ToLower())); }
                if (!string.IsNullOrEmpty(param.Finish)) { model = model.Where(x => x.FinalStatus.ToLower().Contains(param.Finish.ToLower())); }
                if (!string.IsNullOrEmpty(param.PurConfirmPlan)) { model = model.Where(x => x.PurConfirmPlan.ToLower().Contains(param.PurConfirmPlan.ToLower())); }


                var model2 = model.Skip((param.Page - 1) * param.RecordsPerPage).Take(param.RecordsPerPage).ToList();

                foreach (var item in model2)
                {
                    lstResult.Add(new LackSnpView()
                    {
                        Id = item.Id.ToString(),
                        Term = item.Term,
                        ClaimCardNo = item.ClaimCardNo,
                        Month = item.DetectedDate != null ? item.DetectedDate.Value.ToString("MMM") : "",
                        DetectedDate = item.DetectedDate != null ?item.DetectedDate.Value.ToString("dd-MM-yyyy"):"",
                        Vendor  = item.Vendor,
                        KindOfPart = item.KindOfPart,
                        PartNoSp = item.PartNo+item.Sp,
                        Sp = item.Sp,
                        PartNo = item.PartNo,
                        PartName = item.PartName,
                        MmPic = item.MmPic,
                        Snp = item.Snp != null ? item.Snp.Value.FormatDouble().ToString():"",
                        ActualQty = item.ActualQty != null ? item.ActualQty.Value.FormatDouble().ToString():"",
                        LackingQty = item.LackingQty != null ? item.LackingQty.Value.FormatDouble().ToString():"",
                        ProductionOnDate = item.ProductionOnDate,
                        DeliveryDate = item.DeliveryDate != null ? item.DeliveryDate.Value.ToString("dd-MM-yyyy") : "",
                        DetectBy = item.DetectBy,
                        IssuedDate = item.IssuedDate != null ? item.IssuedDate.Value.ToString("dd-MM-yyyy") : "",
                        SendingPurDate = item.SendingPurDate != null ? item.SendingPurDate.Value.ToString("dd-MM-yyyy") : "",
                        Issuer = item.Issuer,
                        PlanReceive = item.PlanReceive != null ? item.PlanReceive.Value.ToString("dd-MM-yyyy") : "",
                        ActualReceiveDate = item.ActualReceiveDate != null ? item.ActualReceiveDate.Value.ToString("dd-MM-yyyy") : "",
                        QtyReceive = item.QtyReceive != null ? item.QtyReceive.Value.FormatDouble().ToString():"",
                        NotReplace = item.NotReplace,
                        FinalStatus = item.FinalStatus,
                        Remark = item.Remark,
                        RepeatTime = item.RepeatTime,
                        VendorFeedback = item.VendorFeedback,
                        BuyerConfirm = item.BuyerConfirm,
                        PurConfirmPlan = item.PurConfirmPlan,
                        IsPurStep = item.IsPurStep
                    });
                }
             
                var c = model.Count();
                result.lstModel = lstResult;
                result.toRecord = (int)Math.Min(result.totalRecords, result.currentPage * result.recordPerPage);
                result.totalPage = (int)Math.Ceiling((decimal)c / param.RecordsPerPage);
                result.totalRecords = c;
                result.recordPerPage = param.RecordsPerPage;
                result.currentPage = param.Page;
                result.fromRecord = c == 0 ? 0 : (result.currentPage - 1) * result.recordPerPage + 1;
                return result;
            }
            catch (Exception)
            {
                return new LackSnpModel();
            }
        }
        [HttpGet("get-info-lack-snp/{claimCard}")]
        public LackSnpView? GetInfoLackSnp(string claimCard)
        {
            try
            {
              
                claimCard = claimCard.Replace("_", " ");
                var lack = context.InvLackSnps.FirstOrDefault(x => x.Active == true && x.ClaimCardNo.Equals(claimCard));
                if(lack != null)
                {
                    var listSupplier = context.AdmSupplierDepartments.Where(x => x.Active == true).ToList();
                    var supplierName = "";
                    var supplier = listSupplier.FirstOrDefault(x => x.SupplierCode.Equals(lack.Vendor));
                    if(supplier != null)
                    {
                        supplierName = supplier.SupplierName;
                    }
                    else
                    {

                        if (claimCard.Contains("LBP"))
                        {
                            var j5302 = context.VClaimCardLbpJ5302s.FirstOrDefault(x => x.CdSply.Equals(lack.Vendor));
                            supplierName = j5302 != null ? j5302.NmSplyEng : "";
                        } else {
                            var j5302 = context.VClaimCardIjJ5302s.FirstOrDefault(x => x.CdSply.Equals(lack.Vendor));
                            supplierName = j5302 != null ? j5302.NmSplyEng : "";
                        }
                    }
                    var item = lack;
                    return new LackSnpView()
                    {
                       
                        ClaimCardNo = item.ClaimCardNo,                    
                        Vendor = item.Vendor,                                      
                        PartNo = item.PartNo,
                        PartName = item.PartName,                      
                        Snp = item.Snp != null ? item.Snp.Value.FormatDouble().ToString() : "",
                        ActualQty = item.ActualQty != null ? item.ActualQty.Value.FormatDouble().ToString() : "",
                        LackingQty = item.LackingQty != null ? item.LackingQty.Value.FormatDouble().ToString() : "",
                        ProductionOnDate = item.ProductionOnDate,
                        DeliveryDate = item.DeliveryDate != null ? item.DeliveryDate.Value.ToString("dd-MM-yyyy") : "",
                        DetectedDate = item.DetectedDate != null ? item.DetectedDate.Value.ToString("dd-MM-yyyy") : "",
                        SupplierName = supplierName
                    };
                }
                return null;
            }
            catch (Exception)
            {

                return null;
            }
        }
        [HttpPost("approve-claim-card")]
        [Obsolete]
        public async Task<CommonResponse> ApproveClaimCard([FromForm] ClaimCardParam param)
        {
            var result = new CommonResponse()
            {
                Error = false,
                Message = "",
                Status = (int)HttpStatusCode.BadRequest
            };
            try
            {
                var user = GetCurrentUser();
                if (param.Step == 1)
                {
                   
                    var group = context.AdmMasterGroups.FirstOrDefault(x => x.GroupName.Equals("Checked by PDC1"));
                    if (group != null)
                    {
                        if (param.Image1 != null)
                        {
                            var filePath = Path.Combine(this.outputPathOri +"\\8. Inventory\\ClaimCard", param.Image1.FileName);
                            //using (var stream = new FileStream(filePath, FileMode.Create))
                            //{
                            //await param.Image1.CopyToAsync(stream);
                            //}
                            using (var stream = new FileStream(filePath, FileMode.Create))
                            {
                                byte[] compressedImageBytes = CompressImage(param.Image1, 512000);
                                await stream.WriteAsync(compressedImageBytes, 0, compressedImageBytes.Length);
                            }
                        }
                        if (param.Image2 != null)
                        {
                            var filePath = Path.Combine(this.outputPathOri + "\\8. Inventory\\ClaimCard", param.Image2.FileName);
                            //using (var stream = new FileStream(filePath, FileMode.Create))
                            //{
                            //    await param.Image2.CopyToAsync(stream);
                            //}
                            using (var stream = new FileStream(filePath, FileMode.Create))
                            {
                                byte[] compressedImageBytes = CompressImage(param.Image2, 512000);
                                await stream.WriteAsync(compressedImageBytes, 0, compressedImageBytes.Length);
                            }
                        }
                        if (param.Image3 != null)
                        {
                            var filePath = Path.Combine(this.outputPathOri +"\\8. Inventory\\ClaimCard", param.Image3.FileName);
                            //using (var stream = new FileStream(filePath, FileMode.Create))
                            //{
                            //    await param.Image3.CopyToAsync(stream);
                            //}
                            using (var stream = new FileStream(filePath, FileMode.Create))
                            {
                                byte[] compressedImageBytes = CompressImage(param.Image3, 512000);
                                await stream.WriteAsync(compressedImageBytes, 0, compressedImageBytes.Length);
                            }
                        }
                        if (param.Image4 != null)
                        {
                            var filePath = Path.Combine(this.outputPathOri + "\\8. Inventory\\ClaimCard", param.Image4.FileName);
                            //using (var stream = new FileStream(filePath, FileMode.Create))
                            //{
                            //    await param.Image4.CopyToAsync(stream);
                            //}
                            using (var stream = new FileStream(filePath, FileMode.Create))
                            {
                                byte[] compressedImageBytes = CompressImage(param.Image4, 512000);
                                await stream.WriteAsync(compressedImageBytes, 0, compressedImageBytes.Length);
                            }
                        }
                        var listSupplier = context.AdmSupplierDepartments.Where(x => x.Active == true).ToList();
                        var supplier = listSupplier.FirstOrDefault(x => x.SupplierCode.Equals(param.Vendor));
                        context.InvClaimCardInfos.Add(new InvClaimCardInfo()
                        {
                            ClaimCardNo = param.ClaimCardNo,
                            WhereInfo = param.WhereInfo,
                            WhenInfo = param.WhenInfo,
                            WhoInfo = param.WhoInfo,
                            Image1 = param.Image1 != null ?  this.DirectoryBrowser+"/image_claim_card/" + param.Image1.FileName : null,
                            Image2 = param.Image2 != null ? this.DirectoryBrowser + "/image_claim_card/" + param.Image2.FileName : null,
                            Image3 = param.Image3 != null ? this.DirectoryBrowser+"/image_claim_card/" + param.Image3.FileName : null,
                            Image4 = param.Image4 != null ? this.DirectoryBrowser+"/image_claim_card/" + param.Image4.FileName : null,
                            SupplierRequest = supplier != null ? true : false

                        });

                        var lackSnp = context.InvLackSnps.FirstOrDefault(x => x.Active == true && x.ClaimCardNo.Equals(param.ClaimCardNo));
                        if(lackSnp != null)
                        {
                            lackSnp.IssuedDate = DateOnly.FromDateTime(DateTime.Now);
                            lackSnp.Issuer = user.UserName;
                        }

                        var listUserId = context.AdmDetailUserGroups.Where(x => x.GroupId == group.Id).Select(x => x.UserId).ToList();
                        var listUser = context.AdmUserInformations.Where(x => listUserId.Contains(x.Id)).ToList();
                        context.InvClaimCardProcesses.Add(new InvClaimCardProcess()
                        {
                            ClaimCardNo = param.ClaimCardNo,
                            ApproveBy = user.UserName,
                            DateConfirm = DateOnly.FromDateTime(DateTime.Now),
                            Step = 1,
                            Next = false,
                            IsSupplier = false,
                            GroupName = ""
                        });
                        context.InvClaimCardProcesses.Add(new InvClaimCardProcess()
                        {
                            ClaimCardNo = param.ClaimCardNo,
                            Step = 2,
                            Next = true,
                            IsSupplier = false,
                            GroupName = "Checked by PDC1"
                        });
                        context.InvClaimCardProcesses.Add(new InvClaimCardProcess()
                        {
                            ClaimCardNo = param.ClaimCardNo,
                            Step = 3,
                            Next = false,
                            IsSupplier = false,
                            GroupName = "Approved by PDC1"
                        });                     
                        if(supplier != null)
                        {
                            var listCheckDept = supplier.AccCode.Split(",");
                            var listDept =string.Join(",",context.AdmMasterDepartments.Where(x => x.Active == true && listCheckDept.Contains(x.DeptShortName)).Select(x=>x.Id.ToString()).Distinct().ToList());
                            context.InvClaimCardProcesses.Add(new InvClaimCardProcess()
                            {
                                ClaimCardNo = param.ClaimCardNo,
                                Step = 4,
                                Next = false,
                                IsSupplier = false,
                                GroupName = listDept
                            });
                            context.InvClaimCardProcesses.Add(new InvClaimCardProcess()
                            {
                                ClaimCardNo = param.ClaimCardNo,
                                Step = 5,
                                Next = false,
                                IsSupplier = false,
                                GroupName = listDept
                            });
                            context.InvClaimCardProcesses.Add(new InvClaimCardProcess()
                            {
                                ClaimCardNo = param.ClaimCardNo,
                                Step = 6,
                                Next = false,
                                IsSupplier = false,
                                GroupName = listDept
                            });
                        }
                        else
                        {

                            context.InvClaimCardProcesses.Add(new InvClaimCardProcess()
                            {
                                ClaimCardNo = param.ClaimCardNo,
                                Step = 4,
                                Next = false,
                                IsSupplier = false,
                                GroupName = "Confirm by PUR"
                            });
                            context.InvClaimCardProcesses.Add(new InvClaimCardProcess()
                            {
                                ClaimCardNo = param.ClaimCardNo,
                                Step = 5,
                                Next = false,
                                IsSupplier = false,
                                GroupName = "Checked by PUR"
                            });
                            context.InvClaimCardProcesses.Add(new InvClaimCardProcess()
                            {
                                ClaimCardNo = param.ClaimCardNo,
                                Step = 6,
                                Next = false,
                                IsSupplier = false,
                                GroupName = "Approved by PUR"
                            });
                        }

                        var link = this.frondEnd+"/#/inventory/claim-card/"+param.ClaimCardNo.Replace(" ","_");
                        string content = "<p style='font-weight: bold;'>Dear Checker,</p>";
                        content += "<p>This is notification from PSI SYSTEM- CLAIM CARD</p>";
                        content += "<p>Have one request that you need approve:</p>";
                        content += "<p>-\t Claim card no: "+param.ClaimCardNo+"</p>";
                        content += "<p>-\t To Vendor: "+param.Vendor+"</p>";
                        content += "<p>Link system: <a href=\"" + link + "\">Click here</a></p>";
                        new EmailService().Initial(listUser.Select(x=>x.Email).ToList(), "PSI SYSTEM - CLAIM CARD APPROVE REQUEST – "+param.Vendor, content);
                    }
                    else
                    {
                        result.Status = (int)HttpStatusCode.BadRequest;
                        result.Message = "Not found 'Checked by PDC1' group"; 
                        result.Error = true;
                        return result;
                    }
                    context.SaveChanges();
                }
                else if ( param.Step == 6)
                {                        
                    var process = context.InvClaimCardProcesses.FirstOrDefault(x => x.Active == true && x.ClaimCardNo.Equals(param.ClaimCardNo) && x.Step == param.Step);
                    if (process != null )
                    {
                    
                        process.ApproveBy = user.UserName;
                        process.DateConfirm = DateOnly.FromDateTime(DateTime.Now);
                        process.Next = false;

                    }
                    else
                    {
                        result.Status = (int)HttpStatusCode.BadRequest;
                        result.Message = "Not found process of request";
                        result.Error = true;
                        return result;
                    }
                    
                    context.SaveChanges();
                }
                else
                {
                    if(param.Step == 3)
                    {
                        var lackSnp = context.InvLackSnps.FirstOrDefault(x => x.Active == true && x.ClaimCardNo.Equals(param.ClaimCardNo));
                       
                        if (lackSnp != null)
                        {
                            string finalStatus = "";
                            if (string.IsNullOrEmpty(lackSnp.NotReplace))
                            {
                                if (lackSnp.QtyReceive != null && lackSnp.QtyReceive != 0)
                                {
                                    if (lackSnp.QtyReceive == Math.Abs(lackSnp.LackingQty != null ?lackSnp.LackingQty.Value:0))
                                    {
                                        finalStatus = "Compensated";
                                    }
                                    else
                                    {                                    
                                        finalStatus = "Pending";                                   
                                    }
                                }
                                else
                                {
                                    if (!lackSnp.PurConfirmPlan.IsNullOrEmpty())
                                    {
                                        finalStatus = "Delivery Plan";
                                    }
                                    else
                                    {
                                        var ad = lackSnp.PlanReceive;
                                        var now = DateOnly.FromDateTime(DateTime.Now);
                                        if (ad >= now)
                                        {
                                            finalStatus = "Under invest";
                                        }
                                        else
                                        {
                                            finalStatus = "Pending";
                                        }
                                    }
                                }
                            }
                            else
                            {
                                finalStatus = "Not Replace";
                            }
                            lackSnp.SendingPurDate = DateOnly.FromDateTime(DateTime.Now);
                            lackSnp.PlanReceive = lackSnp.KindOfPart.ToUpper().Equals("DPS") ? DateOnly.FromDateTime(DateTime.Now.AddDays(7)) : DateOnly.FromDateTime(DateTime.Now.AddDays(14));
                            //lackSnp.BuyerConfirm = GetNameByCode(user.UserName);
                            lackSnp.FinalStatus = finalStatus;
                            lackSnp.IsPurStep = true;
                        }
                    }
                    var infor = context.InvClaimCardInfos.FirstOrDefault(x => x.Active == true && x.ClaimCardNo.Equals(param.ClaimCardNo));
                    if(param.Step == 4)
                    {

                        var lackSnp = context.InvLackSnps.FirstOrDefault(x => x.Active == true && x.ClaimCardNo.Equals(param.ClaimCardNo));
                        if(lackSnp != null)
                        {
                            lackSnp.BuyerConfirm = GetNameByCode(user.UserName);
                        }
                        if (param.Attachment != null)
                        {
                            var filePath = Path.Combine(this.outputPathOri + "\\8. Inventory\\Attachment", param.Attachment.FileName);
                            using (var stream = new FileStream(filePath, FileMode.Create))
                            {
                                await param.Attachment.CopyToAsync(stream);
                            }
                        }

                        if (infor != null)
                        {
                            infor.Reason = param.Reason;
                            infor.Countermeasure = param.Countermeasure;
                            infor.Attachment = param.Attachment != null ? this.DirectoryBrowser + "/attachment_claim_card/" + param.Attachment.FileName : null;
                        }
                        else
                        {
                            result.Status = (int)HttpStatusCode.BadRequest;
                            result.Message = "Not found info of request";
                            result.Error = true;
                            return result;
                        }
                    }
                    var process = context.InvClaimCardProcesses.FirstOrDefault(x => x.Active == true && x.ClaimCardNo.Equals(param.ClaimCardNo) && x.Step == param.Step);
                    var processNext = context.InvClaimCardProcesses.FirstOrDefault(x => x.Active == true && x.ClaimCardNo.Equals(param.ClaimCardNo) && x.Step == (param.Step+1));
                    if (process != null && processNext != null)
                    {
                        process.ApproveBy = user.UserName;
                        process.DateConfirm = DateOnly.FromDateTime(DateTime.Now);
                        process.Next = false;
                        if(param.Step == 4 && infor.SupplierRequest == false)
                        {
                            context.InvClaimCardProcesses.Add(new InvClaimCardProcess()
                            {
                                ClaimCardNo = param.ClaimCardNo,
                                ConfirmBy = param.ConfirmBy,
                                CheckBy = param.CheckedBy,
                                ApproveBy = param.ApprovedBy,
                                DateConfirm = DateOnly.FromDateTime(DateTime.ParseExact(param.Date, "dd-MM-yyyy", null)),
                                Step = 7,
                                Next = false,
                                IsSupplier = true,
                                GroupName = ""
                            });
                        }
                        processNext.Next = true;
                        if (infor.SupplierRequest == true && param.Step > 2)
                        {
                            var grade = param.Step == 3 ? "Supplier confirm (Claim card)" : (param.Step == 4 ? "Supplier checked (Claim card)" : "Supplier approved (Claim card)");
                            var listUser = GetListUserByDeptAndGrade(processNext.GroupName,grade);
                            if(listUser.Count() > 0)
                            {

                                var people = param.Step == 3 ? "Confirmer" : (param.Step == 4 ? "Checker" : "Approver");
                                var link = this.frondEnd+"/#/inventory/claim-card/" + param.ClaimCardNo.Replace(" ", "_");
                                string content = "<p style='font-weight: bold;'>Dear " + people + ",</p>";
                                content += "<p>This is notification from PSI SYSTEM- CLAIM CARD</p>";
                                content += "<p>Have one request that you need approve:</p>";
                                content += "<p>-\t Claim card no: " + param.ClaimCardNo + "</p>";
                                content += "<p>-\t To Vendor: " + param.Vendor + "</p>";
                                content += "<p>Link system: <a href=\"" + link + "\">Click here</a></p>";
                                new EmailService().Initial(listUser.Select(x => x.Email).ToList(), "PSI SYSTEM - CLAIM CARD APPROVE REQUEST – " + param.Vendor, content);
                            }
                            else
                            {
                                result.Status = (int)HttpStatusCode.BadRequest;
                                result.Message = "Not found any user belong to "+grade  ;
                                result.Error = true;
                                return result;
                            }
                            
                        }
                        else
                        {
                            var group = context.AdmMasterGroups.FirstOrDefault(x => x.GroupName.Equals(processNext.GroupName));
                            if (group != null)
                            {
                                var listUserId = context.AdmDetailUserGroups.Where(x => x.GroupId == group.Id).Select(x => x.UserId).ToList();
                                var listUser = context.AdmUserInformations.Where(x => listUserId.Contains(x.Id)).ToList();
                                var people = (param.Step == 4) ? "Checker" : ((param.Step == 2 || param.Step == 5) ? "Approver" : "Confirmer");
                                var link = this.frondEnd+"/#/inventory/claim-card/" + param.ClaimCardNo.Replace(" ", "_");
                                string content = "<p style='font-weight: bold;'>Dear " + people + ",</p>";
                                content += "<p>This is notification from PSI SYSTEM- CLAIM CARD</p>";
                                content += "<p>Have one request that you need approve:</p>";
                                content += "<p>-\t Claim card no: " + param.ClaimCardNo + "</p>";
                                content += "<p>-\t To Vendor: " + param.Vendor + "</p>";
                                content += "<p>Link system: <a href=\"" + link + "\">Click here</a></p>";
                                new EmailService().Initial(listUser.Select(x => x.Email).ToList(), "PSI SYSTEM - CLAIM CARD APPROVE REQUEST – " + param.Vendor, content);
                            }
                            else
                            {
                                result.Status = (int)HttpStatusCode.BadRequest;
                                result.Message = "Not found '" + processNext.GroupName + "'";
                                result.Error = true;
                                return result;
                            }
                           
                        }
                        if (param.Step == 3)
                        {
                            var processIssuer = context.InvClaimCardProcesses.FirstOrDefault(x => x.Active == true && x.ClaimCardNo.Equals(param.ClaimCardNo) && x.Step == 1);
                            var issuerCode = context.AdmUserInformations.FirstOrDefault(x => x.Active == true && x.EmployeeCode.Equals(processIssuer.ApproveBy));
                            var people = "Issuer";
                            var link = this.frondEnd + "/#/inventory/claim-card/" + param.ClaimCardNo.Replace(" ", "_");
                            string content = "<p style='font-weight: bold;'>Dear " + people + ",</p>";
                            content += "<p>This is notification from PSI SYSTEM- CLAIM CARD</p>";
                            content += "<p>There’s an approved Claim Card:</p>";
                            content += "<p>-\t Claim card no: " + param.ClaimCardNo + "</p>";
                            content += "<p>View details: <a href=\"" + link + "\">Click here</a></p>";
                            content += "<p>Please kindly login PSI system to take your next action</p>";
                            new EmailService().Initial(new List<string>() { issuerCode.Email }, "PSI SYSTEM - CLAIM CARD APPROVE REQUEST – " + param.Vendor, content);
                        }
                    }
                    else
                    {
                        result.Status = (int)HttpStatusCode.BadRequest;
                        result.Message = "Not found process of request";
                        result.Error = true;
                        return result;
                    }
                   
                    context.SaveChanges();
                }
                result.Status = (int)HttpStatusCode.OK;
                result.Message = "Success";
                result.Error = false;
                return result;
            }
            catch (Exception e)
            {
                result.Status = (int)HttpStatusCode.BadRequest;
                result.Message = e.Message;
                result.Error = true;
                return result;
            }
        }
        private List<AdmUserInformation>? GetListUserByDeptAndGrade(string dept, string grade)
        {

            try
            {
                var arrDept = dept.Split(",");
                var listIdDept = context.AdmDetailUserDepts.Where(x => arrDept.Contains(x.DeptId.ToString())).Select(x=>x.UserId).ToList();
                var group = context.AdmMasterGroups.FirstOrDefault(x => x.GroupName.Equals(grade));
                var listIdGrade = context.AdmDetailUserGroups.Where(x => x.GroupId == group.Id).Select(x => x.UserId).ToList();
                var listUser = context.AdmUserInformations.Where(x => listIdDept.Contains(x.Id) && listIdGrade.Contains(x.Id)).ToList();

                return listUser;
            }
            catch (Exception e)
            {
                return null;
            }
        }
        [HttpPost("get-info-claim-card-request")]
        public InvClaimCardInfo? GetInfoClaimCardRequest(string requestNo)
        {

            try
            {
                return context.InvClaimCardInfos.FirstOrDefault(x => x.Active == true && x.ClaimCardNo.Equals(requestNo));
            }
            catch (Exception e)
            {
                return null;
            }
        }
        [HttpPost("get-process-claim-card-request")]
        public List<ClaimCardProcess>? GetProcessClaimCardRequest(string requestNo)
        {

            try
            {
                List<ClaimCardProcess> result = new List<ClaimCardProcess>();
                var list= context.InvClaimCardProcesses.Where(x => x.Active == true && x.ClaimCardNo.Equals(requestNo)).OrderBy(x=>x.Step).ToList();
                foreach (var item in list)
                {
                    result.Add(new ClaimCardProcess()
                    {
                        Id = item.Id.ToString(),
                        ClaimCardNo = item.ClaimCardNo,
                        ConfirmBy =item.ConfirmBy,
                        CheckBy = item.CheckBy,
                        ApproveBy = item.IsSupplier == true ? item.ApproveBy :GetNameByCode(item.ApproveBy),
                        Step = item.Step,
                        Next = item.Next,
                        IsSupplier = item.IsSupplier,
                        GroupName = item.GroupName,
                        DateConfirm = item.DateConfirm != null ? item.DateConfirm.Value.ToString("dd/MM/yyyy"):""
                    });
                }
                return result;
            }
            catch (Exception e)
            {
                return new List<ClaimCardProcess>();
            }
        }
        private string GetNameByCode(string? code)
        {

            try
            {
                var user = context.AdmUserInformations.FirstOrDefault(x => x.Active == true && x.EmployeeCode.Equals(code));
                if(user != null)
                {
                    return user.FullName;
                }
                return "";
            }
            catch (Exception e)
            {
                return "";
            }
        }
        [HttpPost("check-approve-claim-card")]
        public bool? CheckApproveClaimCard(string groupName,int step,bool request)
        {

            try
            {
                var user = GetCurrentUser();
                if (request && step >= 4)
                {
                    var grade = step == 4 ? "Supplier confirm (Claim card)" : (step == 5 ? "Supplier checked (Claim card)" : (step == 6 ? "Supplier approved (Claim card)" : ""));
                    var listUser1 = GetListUserByDeptAndGrade(groupName, grade).Select(x => x.EmployeeCode).ToList();
                    if (listUser1.Count() > 0)
                    {
                        if (listUser1.Contains(user.UserName))
                        {
                            return true;
                        }
                    }
                }
                else
                {

                    var group = context.AdmMasterGroups.FirstOrDefault(x => x.GroupName.Equals(groupName));
                    if (group != null)
                    {
                        var listUserId = context.AdmDetailUserGroups.Where(x => x.GroupId == group.Id).Select(x => x.UserId).ToList();
                        var listUser = context.AdmUserInformations.Where(x => listUserId.Contains(x.Id)).Select(x=>x.EmployeeCode).ToList();
                        if (listUser.Contains(user.UserName))
                        {
                            return true;
                        }
                    }
                }
              
                return false;
            }
            catch (Exception e)
            {
                return false;
            }
        }

        [HttpPost("reject-claim-card")]
        public async Task<CommonResponse> RejectClaimCard(ClaimCardRejectParam param)
        {
            var result = new CommonResponse()
            {
                Error = false,
                Message = "",
                Status = (int)HttpStatusCode.BadRequest
            };
            try
            {
                var user = GetCurrentUser();
                var processFirst = context.InvClaimCardProcesses.FirstOrDefault(x => x.Active == true && x.ClaimCardNo.Equals(param.ClaimCardNo) && x.Step == 1);
                if (processFirst != null)
                {
                    var infor = context.InvClaimCardInfos.FirstOrDefault(x => x.Active == true && x.ClaimCardNo.Equals(param.ClaimCardNo));
                    infor.Active = false;
                    var listProcess = context.InvClaimCardProcesses.Where(x => x.Active == true && x.ClaimCardNo.Equals(param.ClaimCardNo)).ToList();
                    listProcess.ForEach(x => x.Active = false);

                    var userFisrt = context.AdmUserInformations.FirstOrDefault(x => x.EmployeeCode.Equals(processFirst.ApproveBy));
                    var link = "http://cvn-vpsi/#/inventory/claim-card/" + param.ClaimCardNo.Replace(" ","_");
                    string content = "<p style='font-weight: bold;'>Dear ISSUER,</p>";
                    content += "<p>This is notification from PSI SYSTEM- CLAIM CARD</p>";
                    content += "<p>Have one slip was rejected:</p>";
                    content += "<p>-\t Claim card no: " + param.ClaimCardNo + "</p>";
                    content += "<p>-\t Reason: " + param.Reason + "</p>";
                    content += "<p>-\t Rejected by: " + GetNameByCode(user.UserName) + "</p>";
                    content += "<p>Link system: <a href=\"" + link + "\">Click here</a></p>";
                    new EmailService().Initial(new List<string>() { userFisrt.Email}, "PSI SYSTEM - CLAIM CARD – " + param.ClaimCardNo+" - REJECTED", content);
                    
                    
                }
                else
                {
                    result.Status = (int)HttpStatusCode.BadRequest;
                    result.Message = "Not found process of request";
                    result.Error = true;
                    return result;
                }

                context.SaveChanges();
                
                result.Status = (int)HttpStatusCode.OK;
                result.Message = "Success";
                result.Error = false;
                return result;
            }
            catch (Exception e)
            {
                result.Status = (int)HttpStatusCode.BadRequest;
                result.Message = e.Message;
                result.Error = true;
                return result;
            }
        }
        [HttpPost("save-lack-snp/{isPur}/{isPDC1}")]
        public CommonResponse SaveLackSnp(bool isPur,bool isPDC1,[FromBody] List<LackSnpView> param)

        {
            CommonResponse res = new CommonResponse()
            {
                Error = false,
                Message = "",
                Status = (int)HttpStatusCode.BadRequest
            };
            try
            {
                var userNow = GetCurrentUser();

                foreach (var item in param)
                {
                    var lack = context.InvLackSnps.FirstOrDefault(x => x.Active == true && x.ClaimCardNo.Equals(item.ClaimCardNo));
                    if(lack != null)
                    {
                        if (isPur)
                        {
                            lack.PurConfirmPlan = item.PurConfirmPlan;
                        }
                        if (isPDC1)
                        {

                            lack.NotReplace = item.NotReplace;
                            string finalStatus = "";
                            if (string.IsNullOrEmpty(item.NotReplace))
                            {
                                if (!item.QtyReceive.IsNullOrEmpty() && !item.QtyReceive.Equals("0"))
                                {
                                    if(double.Parse(item.QtyReceive) == Math.Abs(double.Parse(item.LackingQty)))
                                    {
                                        finalStatus = "Compensated";
                                    }
                                    else
                                    {
                                       
                                        finalStatus = "Pending";
                                       
                                    }
                                }
                                else
                                {
                                    if (!item.PurConfirmPlan.IsNullOrEmpty())
                                    {
                                        finalStatus = "Delivery Plan";
                                    }
                                    else
                                    {
                                        var ad = DateOnly.FromDateTime(DateTime.ParseExact(item.PlanReceive, "dd-MM-yyyy", null));
                                        var now = DateOnly.FromDateTime(DateTime.Now);
                                        if (ad >= now)
                                        {
                                            finalStatus = "Under invest";
                                        }
                                        else
                                        {
                                            finalStatus = "Pending";
                                        }
                                    }
                                }
                            }
                            else
                            {
                                finalStatus = "Not Replace";
                            }
                            lack.FinalStatus = finalStatus;
                            lack.Remark = item.Remark;
                            lack.VendorFeedback = item.VendorFeedback;
                            lack.BuyerConfirm = item.BuyerConfirm;
                        }
                        lack.ModifiedBy = userNow.UserName;
                        lack.ModifiedDate = DateTime.Now.SetKindUtc();
                    }

                }


                context.SaveChanges();

                res.Error = false;
                res.Message = "OK";
                res.Status = (int)HttpStatusCode.OK;


            }
            catch (Exception e)
            {
                res.Error = true;
                res.Message = e.Message;
                res.Status = (int)HttpStatusCode.BadRequest;
            }
            return res;
        }
        [HttpGet("test-job")]
        [AllowAnonymous]
        public async Task<CommonResponse> TestJob()

        {
            CommonResponse res = new CommonResponse()
            {
                Error = false,
                Message = "",
                Status = (int)HttpStatusCode.BadRequest
            };
            try
            {
                try
                {
                    var d800Ij = context.VlinkageEucIjD800s.ToList();
                    var d800Lbp = context.VlinkageEucLbpD800s.ToList();
                    List<InvD800> listD800 = new List<InvD800>();
                    foreach (var item in d800Ij)
                    {
                        listD800.Add(new InvD800()
                        {
                            NoParts = item.NoParts,
                            CtAll = item.CtAll,
                            NoStockPoi = item.NoStockPoi,
                            QtStock = item.QtStock,
                            Product = "IJP",
                            DtEntry = item.DtEntry
                        });
                    }
                    foreach (var item in d800Lbp)
                    {
                        listD800.Add(new InvD800()
                        {
                            NoParts = item.NoParts,
                            CtAll = item.CtAll,
                            NoStockPoi = item.NoStockPoi,
                            QtStock = item.QtStock,
                            Product = "LBP",
                            DtEntry = item.DtEntry
                        });
                    }
                    var dateRemove = DateOnly.FromDateTime(DateTime.Now.AddDays(-15));
                    var listRemove = context.InvD800s.Where(x => x.DtEntry == dateRemove).ToList();
                    context.InvD800s.RemoveRange(listRemove);
                    context.InvD800s.AddRange(listD800);
                    //lending
                    var lendingAssy = context.VlinkageLendingPartAssyPcbIjs.ToList();
                    var lendingPdc = context.VlinkageLendingPartPdcIjs.ToList();
                    List<InvLendingPartAssyPcbIj> listLendingAssy = new List<InvLendingPartAssyPcbIj>();
                    foreach (var item in lendingAssy)
                    {
                        listLendingAssy.Add(new InvLendingPartAssyPcbIj()
                        {
                            PartNumber = item.PartNumber,
                            QtyBorrow = item.QtyBorrow,
                            QtyReturn = item.QtyReturn,
                            QtyDefect = item.QtyDefect,
                            BorrowDate = item.BorrowDate,
                        });
                    }
                    List<InvLendingPartPdcIj> listLendingPdc = new List<InvLendingPartPdcIj>();
                    foreach (var item in lendingPdc)
                    {
                        listLendingPdc.Add(new InvLendingPartPdcIj()
                        {
                            PartNumber = item.PartNumber,
                            QtyBorrow = item.QtyBorrow,
                            QtyReturn = item.QtyReturn,
                            BorrowDate = item.BorrowDate,
                        });
                    }
                    context.InvLendingPartAssyPcbIjs.AddRange(listLendingAssy);
                    context.InvLendingPartPdcIjs.AddRange(listLendingPdc);
                    var listRemoveAssy = context.InvLendingPartAssyPcbIjs.Where(x => x.CreatedDate == dateRemove).ToList();
                    context.InvLendingPartAssyPcbIjs.RemoveRange(listRemoveAssy);
                    var listRemovePdc = context.InvLendingPartPdcIjs.Where(x => x.CreatedDate == dateRemove).ToList();
                    context.InvLendingPartPdcIjs.RemoveRange(listRemovePdc);
                    context.SaveChanges();
                }
                catch (Exception e)
                {
                    res.Error = true;
                    res.Message = e.Message;
                    res.Status = (int)HttpStatusCode.BadRequest;

                }

                res.Error = false;
                res.Message = "OK";
                res.Status = (int)HttpStatusCode.OK;


            }
            catch (Exception e)
            {
                res.Error = true;
                res.Message = e.Message;
                res.Status = (int)HttpStatusCode.BadRequest;
            }
            return res;
        }
        [HttpPost("get-receiving-data")]
        public CommonResponse GetReceivingData(string? product, string? term)

        {
            CommonResponse res = new CommonResponse()
            {
                Error = false,
                Message = "",
                Status = (int)HttpStatusCode.BadRequest
            };
            try
            {
                var userNow = GetCurrentUser();
                product = product.IsNullOrEmpty() ? "" : product;
                term = term.IsNullOrEmpty() ? "" : term;
                var listSnp = context.InvLackSnps.ToList();
                if (!product.IsNullOrEmpty()) { listSnp = listSnp.Where(x => x.Product.Equals(product)).ToList(); };
                if (!term.IsNullOrEmpty()) { listSnp = listSnp.Where(x => x.Term.Equals(term)).ToList(); };
                var listPart = listSnp.Select(x => "GBLP-"+x.ClaimCardNo).ToList();
                var listRec = context.VlinkageHksReceiveParts.Where(x => listPart.Contains(x.DeliveryKey)).ToList().GroupBy(x => x.DeliveryKey).ToDictionary(g => g.Key, g => g.ToList());
                foreach (var item in listSnp)
                {
                    
                        var finalStatusCheck = item.FinalStatus ?? "";
                        if (!finalStatusCheck.Equals("Compensated"))
                        {
                            var key = "GBLP-" + item.ClaimCardNo;                      
                            listRec.TryGetValue(key, out var listSameTotal);
                            var listSame = listSameTotal != null ? listSameTotal.FirstOrDefault() : new VlinkageHksReceivePart()  ;
                            //var listSame = listRec.FirstOrDefault(x => x.DeliveryKey.Equals(key));
                            string finalStatus = "";
                            if (!finalStatusCheck.Equals(""))
                            {
                                if (string.IsNullOrEmpty(item.NotReplace))
                                {
                                        if ((listSame.ActQty ?? 0) == Math.Abs(item.LackingQty.Value))
                                        {
                                            finalStatus = "Compensated";
                                        }
                                        else
                                        {
                                            var ad = item.PlanReceive;
                                            if(ad != null)
                                            {

                                                var now = DateOnly.FromDateTime(DateTime.Now);
                                                if (ad >= now)
                                                {
                                                    finalStatus = "Under invest";
                                                }
                                                else
                                                {
                                                    finalStatus = "Pending";
                                                }
                                            }
                                            else
                                            {
                                                finalStatus = "Pending";
                                            }
                                        }
                                }
                                else
                                {
                                    finalStatus = "Not Replace";
                                }
                            }
                            item.QtyReceive = listSame != null ? listSame.ActQty: null;
                            item.ActualReceiveDate = listSame != null ?( listSame.TimeReceive != null ? DateOnly.FromDateTime(listSame.TimeReceive.Value): null): null;
                            item.FinalStatus = finalStatus;
                            item.ModifiedBy = userNow.UserName;
                            item.ModifiedDate = DateTime.Now.SetKindUtc();
                        }
                    
                }
                context.SaveChanges();

                res.Error = false;
                res.Message = "OK";
                res.Status = (int)HttpStatusCode.OK;


            }
            catch (Exception e)
            {
                res.Error = true;
                res.Message = e.Message;
                res.Status = (int)HttpStatusCode.BadRequest;
            }
            return res;
        }
        [HttpGet("get-filter-lack-snp")]
        public FilterLackSnp? GetFilterLackSnp()
        {
            try
            {          
                var lack = context.InvLackSnps.Where(x => x.Active == true).ToList();
                FilterLackSnp res = new FilterLackSnp(){
                    ListPic = lack.Where(x=>!x.MmPic.IsNullOrEmpty()).Select(x=>x.MmPic ).Distinct().ToList(),
                    ListFinish = lack.Where(x => !x.FinalStatus.IsNullOrEmpty()).Select(x=>x.FinalStatus).Distinct().ToList()
                };
                return res;
            }
            catch (Exception)
            {

                return null;
            }
        }

        private  byte[] CompressImage(IFormFile file, int targetSizeInBytes)
        {
            using (var stream = file.OpenReadStream())
            {
                using (var image = Image.FromStream(stream))
                {
                    long imageSizeInBytes = stream.Length;

                    double compressionRatio = (double)targetSizeInBytes / imageSizeInBytes;

                    ImageCodecInfo jpegCodec = GetEncoderInfo("image/jpeg");

                    EncoderParameters encoderParams = new EncoderParameters(1);
                    encoderParams.Param[0] = new EncoderParameter(Encoder.Quality, (long)(compressionRatio * 100));

                    using (MemoryStream ms = new MemoryStream())
                    {
                        image.Save(ms, jpegCodec, encoderParams);
                        return ms.ToArray();
                    }
                }
            }
        }

        private  ImageCodecInfo GetEncoderInfo(string mimeType)
        {
            foreach (ImageCodecInfo codec in ImageCodecInfo.GetImageDecoders())
            {
                if (codec.MimeType == mimeType)
                    return codec;
            }
            return null;
        }
        [HttpPost("revise-image")]
        [Obsolete]
        [AllowAnonymous]
        public async Task<CommonResponse> ReviseImage([FromForm] ClaimCardParam param)
        {
            var result = new CommonResponse()
            {
                Error = false,
                Message = "",
                Status = (int)HttpStatusCode.BadRequest
            };
            try
            {
                var user = GetCurrentUser();

                        if (param.Image1 != null)
                        {
                            var filePath = Path.Combine(this.outputPathOri + "\\8. Inventory\\ClaimCard", param.Image1.FileName);
                            //using (var stream = new FileStream(filePath, FileMode.Create))
                            //{
                            //await param.Image1.CopyToAsync(stream);
                            //}
                            using (var stream = new FileStream(filePath, FileMode.Create))
                            {
                                byte[] compressedImageBytes = CompressImage(param.Image1, 64000);
                                await stream.WriteAsync(compressedImageBytes, 0, compressedImageBytes.Length);
                            }
                        }
                
                result.Status = (int)HttpStatusCode.OK;
                result.Message = "Success";
                result.Error = false;
                return result;
            }
            catch (Exception e)
            {
                result.Status = (int)HttpStatusCode.BadRequest;
                result.Message = e.Message;
                result.Error = true;
                return result;
            }
        }
    }
}
