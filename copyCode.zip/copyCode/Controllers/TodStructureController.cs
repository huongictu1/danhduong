﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using PDCProjectApi.Common.Interface;
using PDCProjectApi.Data;
using AutoMapper;
using PDCProjectApi.Model.View;
using PDCProjectApi.Model.Request;
using PDCProjectApi.Common;
using Microsoft.EntityFrameworkCore;
using PDCProjectApi.Helper;
using PDCProjectApi.Model.Response;
using System.Security.Claims;
using System.Net;
using Microsoft.AspNetCore.Authorization;
using Newtonsoft.Json;
using PDCProjectApi.Common.Job;
using StackExchange.Redis;
using PDCProjectApi.Services;
using OfficeOpenXml;
using OfficeOpenXml.Style;
using Microsoft.AspNetCore.SignalR;
using Hangfire;

namespace PDCProjectApi.Controllers
{
    [Route("api/todstructure")]
    [ApiController]
    [Authorize]
    //[ApiExplorerSettings(IgnoreApi = true)]
    public class TodStructureController : Controller, IDisposable
    {
        [Obsolete]
        private readonly Microsoft.AspNetCore.Hosting.IHostingEnvironment _hostingEnvironment;
        private readonly IHttpContextAccessor httpContextAccessor;
        private readonly IFileStorageService fileStorageService;
        private readonly IManualJob _manual;
        private readonly PdcsystemContext context;
        private readonly IEmailService email;
        private string pathServer = "";
        private List<string> lstBlockCode = new List<string>();
        private readonly IGlobalVariable global;
        private List<string> lstITMail = new List<string>();
        private List<string> lstPDCMail = new List<string>();
        private static ConnectionMultiplexer redis = RedisConnectionManager.GetRedisConnection();
        private static IDatabase database  = redis.GetDatabase();
        private static string date = DateTime.Now.ToString("d-M-yyyy");
        private readonly IHubContext<RealTimeHub> _hubContext;
        private string Factory = "";
        [Obsolete]
        public TodStructureController(Microsoft.AspNetCore.Hosting.IHostingEnvironment hosting, 
            PdcsystemContext ctx, IHttpContextAccessor httpContextAccessor, IFileStorageService fileService, 
            IEmailService mail, IGlobalVariable gl, IManualJob manual, IHubContext<RealTimeHub> hubContext)
        {
            this._hostingEnvironment = hosting;
            this.httpContextAccessor = httpContextAccessor;
            this.context = ctx;
            this.fileStorageService = fileService;
            this.email = mail;
            this.global = gl;
            this.pathServer = this.global.ReturnPathServer();
            this.lstBlockCode = this.global.ReturnBlockCode();
            this.lstITMail = this.global.ReturnITMail();
            this.lstPDCMail = this.global.ReturnPDCMail();
            this._manual = manual;
            this._hubContext = hubContext;
            this.Factory =this.global.ReturnFactory();
           // this.database = RedisConnectionManager.GetDatabase();
        }
        private bool disposed = false;
        protected virtual void Dispose(bool disposing)
        {
            if (!disposed)
            {
                if (disposing)
                {
                    if (_manual != null)
                    {
                        _manual.DisposeAsync();
                    }
                    //if (redis != null)
                    //{
                    //    redis.Dispose();
                    //}
                    if (context != null)
                    {
                        context.DisposeAsync();
                    }
                }
                disposed = true;
            }
        }
        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }
        ~TodStructureController() { Dispose(false); }
        [HttpPost("filter-structure-master-delivery")]
        public async Task<TodStructureMasterDeliveryModel> FilterStructureMasterDelivery(TodMasterStructureMasterDeliveryParam parameters)
        {
            try
            {
                var config = new MapperConfiguration(cfg => cfg.CreateMap<TodStructureMasterDelivery, TodStructureMasterDeliveryView>());
                var mapper = config.CreateMapper();
                TodStructureMasterDeliveryModel result = new TodStructureMasterDeliveryModel()
                {
                    currentPage = parameters.Page,
                    recordPerPage = parameters.RecordsPerPage
                };
                var query = context.TodStructureMasterDeliveries.Where(x => x.Active == true);
                query = !string.IsNullOrEmpty(parameters.MethodDel) ? query.Where(x => x.MethodDelivery != null && x.MethodDelivery.ToUpper().Contains(parameters.MethodDel.ToUpper())) : query;
                query = !string.IsNullOrEmpty(parameters.VendorCode) ? query.Where(x => x.VendorCode != null && x.VendorCode.ToUpper().Contains(parameters.VendorCode.ToUpper())) : query;
                query = !string.IsNullOrEmpty(parameters.Location1) ? query.Where(x => x.Location1 != null && x.Location1.ToUpper().Contains(parameters.Location1.ToUpper())) : query;
                query = !string.IsNullOrEmpty(parameters.Location2) ? query.Where(x => x.Location2 != null && x.Location2.ToUpper().Contains(parameters.Location2.ToUpper())) : query;
                query = !string.IsNullOrEmpty(parameters.Location3) ? query.Where(x => x.Location3 != null && x.Location3.ToUpper().Contains(parameters.Location3.ToUpper())) : query;
                query = !string.IsNullOrEmpty(parameters.RouteDel) ? query.Where(x => x.RouteDelivery != null && x.RouteDelivery.ToUpper().Contains(parameters.RouteDel.ToUpper())) : query;
                query = !string.IsNullOrEmpty(parameters.Product) ? query.Where(x => x.Product != null && x.Product.ToUpper().Contains(parameters.Product.ToUpper())) : query;
                query = parameters.TotalPartOrder != null ? query.Where(x => x.TotalPartOrder != null && x.TotalPartOrder == parameters.TotalPartOrder) : query;
                result.totalRecords = await query.CountAsync();
                result.totalPage = (int)Math.Ceiling((decimal)result.totalRecords / parameters.RecordsPerPage);
                var model = await query.OrderByDescending(x => x.CreatedDate).Paginate(parameters).ToListAsync();
                var modelView = mapper.Map<List<TodStructureMasterDelivery>, List<TodStructureMasterDeliveryView>>(model);
                result.lstModel = modelView;
                result.fromRecord = model.Count == 0 ? 0 : (result.currentPage - 1) * result.recordPerPage + 1;
                result.toRecord = (int)Math.Min(result.totalRecords, result.currentPage * result.recordPerPage);
                result.currentPage = result.totalPage < result.currentPage ? result.totalPage : result.currentPage;
                return result;
            }
            catch (Exception e)
            {
                //SendMailError(e);
                return new TodStructureMasterDeliveryModel()
                {
                    currentPage = parameters.Page,
                    recordPerPage = parameters.RecordsPerPage
                };
            }
        }
        [HttpPost("filter-structure-job-assignment")]
        public async Task<TodStructureMasterJobAssignModel> FilterStructureJobAssignment(TodMasterStructureMasterJobAssignmentParam parameters)
        {
            try
            {
                var config = new MapperConfiguration(cfg => cfg.CreateMap<TodStructureMasterJobAssign, TodStructureMasterJobAssignView>());
                var mapper = config.CreateMapper();
                TodStructureMasterJobAssignModel result = new TodStructureMasterJobAssignModel()
                {
                    currentPage = parameters.Page,
                    recordPerPage = parameters.RecordsPerPage
                };
                var query = context.TodStructureMasterJobAssigns.Where(x => x.Active == true);
                query = !string.IsNullOrEmpty(parameters.VendorCode) ? query.Where(x => x.VendorCode != null && x.VendorCode.ToUpper().Contains(parameters.VendorCode.ToUpper())) : query;
                query = !string.IsNullOrEmpty(parameters.Bc) ? query.Where(x => x.Bc != null && x.Bc.ToUpper().Contains(parameters.Bc.ToUpper())) : query;
                query = !string.IsNullOrEmpty(parameters.DoPic) ? query.Where(x => x.DoPic != null && x.DoPic.ToUpper().Contains(parameters.DoPic.ToUpper())) : query;
                query = !string.IsNullOrEmpty(parameters.PoPic) ? query.Where(x => x.PoPic != null && x.PoPic.ToUpper().Contains(parameters.PoPic.ToUpper())) : query;
                query = !string.IsNullOrEmpty(parameters.DoPic) ? query.Where(x => x.DoPicCode != null && x.DoPicCode.ToUpper().Contains(parameters.DoPic.ToUpper())) : query;
                query = !string.IsNullOrEmpty(parameters.PoPic) ? query.Where(x => x.PoPicCode != null && x.PoPicCode.ToUpper().Contains(parameters.PoPic.ToUpper())) : query;
                query = !string.IsNullOrEmpty(parameters.Product) ? query.Where(x => x.Product != null && x.Product.ToUpper().Contains(parameters.Product.ToUpper())) : query;
                result.totalRecords = await query.CountAsync();
                result.totalPage = (int)Math.Ceiling((decimal)result.totalRecords / parameters.RecordsPerPage);
                var model = await query.OrderByDescending(x => x.CreatedDate).Paginate(parameters).ToListAsync();
                var modelView = mapper.Map<List<TodStructureMasterJobAssign>, List<TodStructureMasterJobAssignView>>(model);
                result.lstModel = modelView;
                result.fromRecord = model.Count == 0 ? 0 : (result.currentPage - 1) * result.recordPerPage + 1;
                result.toRecord = (int)Math.Min(result.totalRecords, result.currentPage * result.recordPerPage);
                result.currentPage = result.totalPage < result.currentPage ? result.totalPage : result.currentPage;
                return result;
            }
            catch (Exception e)
            {
                //SendMailError(e);
                return new TodStructureMasterJobAssignModel()
                {
                    currentPage = parameters.Page,
                    recordPerPage = parameters.RecordsPerPage
                };
            }
        }
        [HttpPost("filter-structure-master-merchandise")]
        public async Task<TodStructureMasterMerchandiseModel> FilterStructureMasterMerchandise(TodMasterStructureMasterMerchandiseParam parameters)
        {
            try
            {
                var config = new MapperConfiguration(cfg => cfg.CreateMap<TodStructureMasterMerchandise, TodStructureMasterMerchandiseView>());
                var mapper = config.CreateMapper();
                TodStructureMasterMerchandiseModel result = new TodStructureMasterMerchandiseModel()
                {
                    currentPage = parameters.Page,
                    recordPerPage = parameters.RecordsPerPage
                };
                DateOnly? startProduction = parameters.StartProduction.StringToDateAble(); ;

                var query = context.TodStructureMasterMerchandises.Where(x => x.Active == true);
                query = !string.IsNullOrEmpty(parameters.DestName) ? query.Where(x => x.DestName != null && x.DestName.ToUpper().Contains(parameters.DestName.ToUpper())) : query;
                query = !string.IsNullOrEmpty(parameters.Product) ? query.Where(x => x.Product != null && x.Product.ToUpper().Contains(parameters.Product.ToUpper())) : query;
                query = !string.IsNullOrEmpty(parameters.FcVolume) ? query.Where(x => x.FcVolumeDel != null && x.FcVolumeDel.ToUpper().Contains(parameters.FcVolume.ToUpper())) : query;
                query = !string.IsNullOrEmpty(parameters.Factory) ? query.Where(x => x.Factory != null && x.Factory.ToUpper().Contains(parameters.Factory.ToUpper())) : query;
                query = !string.IsNullOrEmpty(parameters.Merchandise) ? query.Where(x => x.Merchandise != null && x.Merchandise.ToUpper().Contains(parameters.Merchandise.ToUpper())) : query;
                query = !string.IsNullOrEmpty(parameters.Model) ? query.Where(x => x.Model != null && x.Model.ToUpper().Contains(parameters.Model.ToUpper())) : query;
                query = parameters.StartProduction != null ? query.Where(x => x.StartProductionDate != null && x.StartProductionDate == startProduction) : query;
                result.totalRecords = await query.CountAsync();
                result.totalPage = (int)Math.Ceiling((decimal)result.totalRecords / parameters.RecordsPerPage);
                var model = await query.OrderByDescending(x => x.CreatedDate).Paginate(parameters).ToListAsync();
                var modelView = mapper.Map<List<TodStructureMasterMerchandise>, List<TodStructureMasterMerchandiseView>>(model);

                result.lstModel = modelView;
                result.fromRecord = model.Count == 0 ? 0 : (result.currentPage - 1) * result.recordPerPage + 1;
                result.toRecord = (int)Math.Min(result.totalRecords, result.currentPage * result.recordPerPage);
                result.currentPage = result.totalPage < result.currentPage ? result.totalPage : result.currentPage;
                return result;
            }
            catch (Exception e)
            {
                //SendMailError(e);
                return new TodStructureMasterMerchandiseModel()
                {
                    currentPage = parameters.Page,
                    recordPerPage = parameters.RecordsPerPage
                };
            }
        }
        [HttpPost("filter-structure-master-packing")]
        public async Task<TodStructureMasterPackingModel> FilterStructureMasterPacking(TodMasterStructureMasterPackingParam parameters)
        {
            try
            {
                var config = new MapperConfiguration(cfg => cfg.CreateMap<TodStructureMasterPacking, TodStructureMasterPackingView>());
                var mapper = config.CreateMapper();
                TodStructureMasterPackingModel result = new TodStructureMasterPackingModel()
                {
                    currentPage = parameters.Page,
                    recordPerPage = parameters.RecordsPerPage
                };
                var query = context.TodStructureMasterPackings.Where(x => x.Active == true);
                query = !string.IsNullOrEmpty(parameters.PartNo) ? query.Where(x => x.PartNo != null && x.PartNo.ToUpper().Contains(parameters.PartNo.ToUpper())) : query;
                query = !string.IsNullOrEmpty(parameters.Vendor) ? query.Where(x => x.Vendor != null && x.Vendor.ToUpper().Contains(parameters.Vendor.ToUpper())) : query;
                result.totalRecords = await query.CountAsync();
                result.totalPage = (int)Math.Ceiling((decimal)result.totalRecords / parameters.RecordsPerPage);
                var model = await query.OrderByDescending(x => x.CreatedDate).Paginate(parameters).ToListAsync();
                var modelView = mapper.Map<List<TodStructureMasterPacking>, List<TodStructureMasterPackingView>>(model);
                result.lstModel = modelView;
                result.fromRecord = model.Count == 0 ? 0 : (result.currentPage - 1) * result.recordPerPage + 1;
                result.toRecord = (int)Math.Min(result.totalRecords, result.currentPage * result.recordPerPage);
                result.currentPage = result.totalPage < result.currentPage ? result.totalPage : result.currentPage;
                return result;
            }
            catch (Exception e)
            {
                //SendMailError(e);
                return new TodStructureMasterPackingModel()
                {
                    currentPage = parameters.Page,
                    recordPerPage = parameters.RecordsPerPage
                };
            }
        }
        [HttpPost("filter-structure-temporary-connect")]
        public async Task<TodStructureTemporaryConnectModel> FilterStructureTemporaryConnect(TodMasterTemporaryConnectParam parameters)
        {
            try
            {
                TodStructureTemporaryConnectModel result = new TodStructureTemporaryConnectModel()
                {
                    currentPage = parameters.Page,
                    recordPerPage = parameters.RecordsPerPage
                };
                DateOnly? EffectiveFrom = parameters.EffectiveFrom.StringToDateAble(); 
                DateOnly? EffectiveTo = parameters.EffectiveTo.StringToDateAble(); 
                var query = context.TodStructureTemporaryConnects.Where(x => x.Active == true);
                query = !string.IsNullOrEmpty(parameters.PartNo) ? query.Where(x => x.PartNo != null && x.PartNo.ToUpper().Contains(parameters.PartNo.ToUpper())) : query;
                query = !string.IsNullOrEmpty(parameters.Vendor) ? query.Where(x => x.Vendor != null && x.Vendor.ToUpper().Contains(parameters.Vendor.ToUpper())) : query;
                query = !string.IsNullOrEmpty(parameters.Merchandise) ? query.Where(x => x.Merchandise != null && x.Merchandise.ToUpper().Contains(parameters.Merchandise.ToUpper())) : query;
                query = !string.IsNullOrEmpty(parameters.Model) ? query.Where(x => x.Model != null && x.Model.ToUpper().Contains(parameters.Model.ToUpper())) : query;
                query = !string.IsNullOrEmpty(parameters.PartName) ? query.Where(x => x.PartName != null && x.PartName.ToUpper().Contains(parameters.PartName.ToUpper())) : query;
                query = parameters.EffectiveFrom != null ? query.Where(x => x.EfffectiveFrom != null && x.EfffectiveFrom == EffectiveFrom) : query;
                query = parameters.EffectiveTo != null ? query.Where(x => x.EffectiveTo != null && x.EffectiveTo == EffectiveTo) : query;


                result.totalRecords = await query.CountAsync();
                result.totalPage = (int)Math.Ceiling((decimal)result.totalRecords / parameters.RecordsPerPage);
                var model = await query.OrderByDescending(x => x.CreatedDate).Paginate(parameters).ToListAsync();
                result.lstModel = model;
                result.fromRecord = model.Count == 0 ? 0 : (result.currentPage - 1) * result.recordPerPage + 1;
                result.toRecord = (int)Math.Min(result.totalRecords, result.currentPage * result.recordPerPage);
                result.currentPage = result.totalPage < result.currentPage ? result.totalPage : result.currentPage;
                return result;
            }
            catch (Exception e)
            {
                //SendMailError(e);
                return new TodStructureTemporaryConnectModel()
                {
                    currentPage = parameters.Page,
                    recordPerPage = parameters.RecordsPerPage
                };
            }
        }
        [HttpPost("filter-output-structure-ij")]
        public async Task<TodStructureOutputContentModel> FilterStructureOutputIj(MvOutputStructureParam parameters)
        {
            try
            {
                var config = new MapperConfiguration(cfg => cfg.CreateMap<TodStructureOutputContentIj, TodStructureOutputContentView>());
                var mapper = config.CreateMapper();
                var lstBc = this.lstBlockCode;
                TodStructureOutputContentModel result = new TodStructureOutputContentModel()
                {
                    currentPage = parameters.Page,
                    recordPerPage = parameters.RecordsPerPage
                };

                DateTime? dt_entry = parameters.DateEntry == null ? null : DateTime.Parse(parameters.DateEntry);
                var query = context.TodStructureOutputContentIjs.Where(x => x.Active == true ).AsQueryable();
                query = !string.IsNullOrEmpty(parameters.PartNo) ? query.Where(x => x.PartNo8 != null && x.PartNo8.ToUpper().Contains(parameters.PartNo.ToUpper())) : query;
                query = !string.IsNullOrEmpty(parameters.PartName) ? query.Where(x => x.PartName11 != null && x.PartName11.ToUpper().Contains(parameters.PartName.ToUpper())) : query;
                query = !string.IsNullOrEmpty(parameters.BC) ? query.Where(x => x.Bc1 != null && parameters.BC.Contains(x.Bc1)) : query;
                query = !string.IsNullOrEmpty(parameters.Model) ? query.Where(x => x.Model45 != null && x.Model45.ToUpper().Contains(parameters.Model.ToUpper())) : query;
                query = !string.IsNullOrEmpty(parameters.Destination) ? query.Where(x => x.Merchandise46 != null && x.Merchandise46.ToUpper().Contains(parameters.Destination.ToUpper())) : query;
                query = !string.IsNullOrEmpty(parameters.Vendor) ? query.Where(x => x.Bc12 != null && parameters.Vendor.ToUpper().Contains(x.Bc12)) : query;
                result.totalRecords = await query.CountAsync();
                result.totalPage = (int)Math.Ceiling((decimal)result.totalRecords / parameters.RecordsPerPage);

                var model = await query.OrderBy(x => x.Bc1).Paginate(parameters).ToListAsync();
                var modelView = mapper.Map<List<TodStructureOutputContentIj>, List<TodStructureOutputContentView>>(model);

                var headear = context.TodStructureOutputHeaders.Where(x => x.Active == true && x.Product.Contains("IJ")).First();

                result.lstModel = modelView;
                result.fromRecord = model.Count == 0 ? 0 : (result.currentPage - 1) * result.recordPerPage + 1;
                result.toRecord = (int)Math.Min(result.totalRecords, result.currentPage * result.recordPerPage);
                result.currentPage = result.totalPage < result.currentPage ? result.totalPage : result.currentPage;
                result.lstMod = headear == null ? null : headear.Model;
                result.lstMerName = headear == null ? null : headear.Merchandise;
                result.lstMerCode = headear == null ? null : headear.MerCode;
                return result;
            }
            catch (Exception e)
            {
                //SendMailError(e);
                return new TodStructureOutputContentModel()
                {
                    currentPage = parameters.Page,
                    recordPerPage = parameters.RecordsPerPage
                };
            }
        }
        [HttpPost("filter-output-structure-lbp")]
        public async Task<TodStructureOutputContentLBPModel> FilterStructureOutputLbp(MvOutputStructureParam parameters)
        {
            try
            {
                var config = new MapperConfiguration(cfg => cfg.CreateMap<TodStructureOutputContentLbp, TodStructureOutputContentLBPView>());
                var mapper = config.CreateMapper();
                var lstBc = this.lstBlockCode;
                TodStructureOutputContentLBPModel result = new TodStructureOutputContentLBPModel()
                {
                    currentPage = parameters.Page,
                    recordPerPage = parameters.RecordsPerPage
                };

                DateTime? dt_entry = parameters.DateEntry == null ? null : DateTime.Parse(parameters.DateEntry);
                var query = context.TodStructureOutputContentLbps.Where(x => x.Active == true).AsQueryable();
                query = !string.IsNullOrEmpty(parameters.PartNo) ? query.Where(x => x.PartNo8 != null && x.PartNo8.ToUpper().Contains(parameters.PartNo.ToUpper())) : query;
                query = !string.IsNullOrEmpty(parameters.PartName) ? query.Where(x => x.PartName11 != null && x.PartName11.ToUpper().Contains(parameters.PartName.ToUpper())) : query;
                query = !string.IsNullOrEmpty(parameters.BC) ? query.Where(x => x.Bc1 != null && parameters.BC.Contains(x.Bc1)) : query;
                query = !string.IsNullOrEmpty(parameters.Model) ? query.Where(x => x.Model45 != null && x.Model45.ToUpper().Contains(parameters.Model.ToUpper())) : query;
                query = !string.IsNullOrEmpty(parameters.Destination) ? query.Where(x => x.Merchandise46 != null && x.Merchandise46.ToUpper().Contains(parameters.Destination.ToUpper())) : query;
                query = !string.IsNullOrEmpty(parameters.Vendor) ? query.Where(x => x.Bc12 != null && parameters.Vendor.ToUpper().Contains(x.Bc12)) : query;
                result.totalRecords = await query.CountAsync();
                result.totalPage = (int)Math.Ceiling((decimal)result.totalRecords / parameters.RecordsPerPage);

                var model = await query.OrderBy(x => x.Bc1).Paginate(parameters).ToListAsync();
                var modelView = mapper.Map<List<TodStructureOutputContentLbp>, List<TodStructureOutputContentLBPView>>(model);

                var headear = context.TodStructureOutputHeaders.Where(x => x.Active == true && x.Product.Contains("LBP")).First();

                result.lstModel = modelView;
                result.fromRecord = model.Count == 0 ? 0 : (result.currentPage - 1) * result.recordPerPage + 1;
                result.toRecord = (int)Math.Min(result.totalRecords, result.currentPage * result.recordPerPage);
                result.currentPage = result.totalPage < result.currentPage ? result.totalPage : result.currentPage;
                result.lstMod = headear == null ? null : headear.Model;
                result.lstMerName = headear == null ? null : headear.Merchandise;
                result.lstMerCode = headear == null ? null : headear.MerCode;
                return result;
            }
            catch (Exception e)
            {
                //SendMailError(e);
                return new TodStructureOutputContentLBPModel()
                {
                    currentPage = parameters.Page,
                    recordPerPage = parameters.RecordsPerPage
                };
            }
        }
        [HttpPost("filter-linkage-euc-ij-h445")]
        public async Task<LinkageEucIjH445Model> FilterStructureEucIjH445(PaginationParams parameters)
        {
            try
            {
                LinkageEucIjH445Model result = new LinkageEucIjH445Model()
                {
                    currentPage = parameters.Page,
                    recordPerPage = parameters.RecordsPerPage
                };

                var query = context.MvEucH445s.AsQueryable();
                query = !string.IsNullOrEmpty(parameters.search) ? query.Where(x => x.NoChldParts != null && x.NoChldParts.ToUpper().Contains(parameters.search.ToUpper())) : query;
                result.totalRecords = await query.CountAsync();
                result.totalPage = (int)Math.Ceiling((decimal)result.totalRecords / parameters.RecordsPerPage);
                var model = await query.Paginate(parameters).ToListAsync();
                result.lstModel = model;
                result.fromRecord = model.Count == 0 ? 0 : (result.currentPage - 1) * result.recordPerPage + 1;
                result.toRecord = (int)Math.Min(result.totalRecords, result.currentPage * result.recordPerPage);
                result.currentPage = result.totalPage < result.currentPage ? result.totalPage : result.currentPage;
                return result;
            }
            catch (Exception e)
            {
                //SendMailError(e);
                return new LinkageEucIjH445Model()
                {
                    currentPage = parameters.Page,
                    recordPerPage = parameters.RecordsPerPage
                };
            }
        }
        [HttpPost("filter-linkage-euc-ij-h1202")]
        public async Task<LinkageEucIjH1202Model> FilterStructureEucIj1202(PaginationParams parameters)
        {
            try
            {
                LinkageEucIjH1202Model result = new LinkageEucIjH1202Model()
                {
                    currentPage = parameters.Page,
                    recordPerPage = parameters.RecordsPerPage
                };
                var query = context.MvEucH1202Ijs.AsQueryable();
                query = !string.IsNullOrEmpty(parameters.search) ? query.Where(x => x.NoParts != null && x.NoParts.ToUpper().Contains(parameters.search.ToUpper())) : query;
                result.totalRecords = await query.CountAsync();
                result.totalPage = (int)Math.Ceiling((decimal)result.totalRecords / parameters.RecordsPerPage);
                var model = await query.OrderBy(x => x.DtEntry).Paginate(parameters).ToListAsync();
                result.lstModel = model;
                result.fromRecord = model.Count == 0 ? 0 : (result.currentPage - 1) * result.recordPerPage + 1;
                result.toRecord = (int)Math.Min(result.totalRecords, result.currentPage * result.recordPerPage);
                result.currentPage = result.totalPage < result.currentPage ? result.totalPage : result.currentPage;
                return result;
            }
            catch (Exception e)
            {
                //SendMailError(e);
                return new LinkageEucIjH1202Model()
                {
                    currentPage = parameters.Page,
                    recordPerPage = parameters.RecordsPerPage
                };
            }
        }
        [HttpPost("filter-linkage-euc-ij-h300")]
        public async Task<LinkageEucIjH300Model> FilterStructureEucIj300(PaginationParams parameters)
        {
            try
            {
                LinkageEucIjH300Model result = new LinkageEucIjH300Model()
                {
                    currentPage = parameters.Page,
                    recordPerPage = parameters.RecordsPerPage
                };
                var query = context.MvEucH300Ijs.AsQueryable();
                query = !string.IsNullOrEmpty(parameters.search) ? query.Where(x => x.NoParts != null && x.NoParts.ToUpper().Contains(parameters.search.ToUpper())) : query;

                result.totalRecords = await query.CountAsync();
                result.totalPage = (int)Math.Ceiling((decimal)result.totalRecords / parameters.RecordsPerPage);
                var model = await query.OrderBy(x => x.CdBlock).Paginate(parameters).ToListAsync();
                result.lstModel = model;
                result.fromRecord = model.Count == 0 ? 0 : (result.currentPage - 1) * result.recordPerPage + 1;
                result.toRecord = (int)Math.Min(result.totalRecords, result.currentPage * result.recordPerPage);
                result.currentPage = result.totalPage < result.currentPage ? result.totalPage : result.currentPage;
                return result;
            }
            catch (Exception e)
            {
                //SendMailError(e);
                return new LinkageEucIjH300Model()
                {
                    currentPage = parameters.Page,
                    recordPerPage = parameters.RecordsPerPage
                };
            }
        }
        [HttpPost("filter-linkage-euc-ij-h3001")]
        public async Task<LinkageEucIjH3001Model> FilterStructureEucIj3001(PaginationParams parameters)
        {
            try
            {
                LinkageEucIjH3001Model result = new LinkageEucIjH3001Model()
                {
                    currentPage = parameters.Page,
                    recordPerPage = parameters.RecordsPerPage
                };
                var query = context.MvEucH3001Ijs.AsQueryable();
                query = !string.IsNullOrEmpty(parameters.search) ? query.Where(x => x.NoParts != null && x.NoParts.ToUpper().Contains(parameters.search.ToUpper())) : query;

                result.totalRecords = await query.CountAsync();
                result.totalPage = (int)Math.Ceiling((decimal)result.totalRecords / parameters.RecordsPerPage);
                var model = await query.OrderBy(x => x.CdBlock).Paginate(parameters).ToListAsync();
                result.lstModel = model;
                result.fromRecord = model.Count == 0 ? 0 : (result.currentPage - 1) * result.recordPerPage + 1;
                result.toRecord = (int)Math.Min(result.totalRecords, result.currentPage * result.recordPerPage);
                result.currentPage = result.totalPage < result.currentPage ? result.totalPage : result.currentPage;
                return result;
            }
            catch (Exception e)
            {
                //SendMailError(e);
                return new LinkageEucIjH3001Model()
                {
                    currentPage = parameters.Page,
                    recordPerPage = parameters.RecordsPerPage
                };
            }
        }
        [HttpPost("filter-linkage-euc-ij-h501")]
        public async Task<LinkageEucIjH501Model> FilterStructureEucIj501(PaginationParams parameters)
        {
            try
            {
                LinkageEucIjH501Model result = new LinkageEucIjH501Model()
                {
                    currentPage = parameters.Page,
                    recordPerPage = parameters.RecordsPerPage
                };
                var query = context.MvEucH501Ijs.AsQueryable();
                query = !string.IsNullOrEmpty(parameters.search) ? query.Where(x => x.NoParts != null && x.NoParts.ToUpper().Contains(parameters.search.ToUpper())) : query;

                result.totalRecords = await query.CountAsync();
                result.totalPage = (int)Math.Ceiling((decimal)result.totalRecords / parameters.RecordsPerPage);
                var model = await query.OrderBy(x => x.CdBlock).Paginate(parameters).ToListAsync();
                result.lstModel = model;
                result.fromRecord = model.Count == 0 ? 0 : (result.currentPage - 1) * result.recordPerPage + 1;
                result.toRecord = (int)Math.Min(result.totalRecords, result.currentPage * result.recordPerPage);
                result.currentPage = result.totalPage < result.currentPage ? result.totalPage : result.currentPage;
                return result;
            }
            catch (Exception e)
            {
                //SendMailError(e);
                return new LinkageEucIjH501Model()
                {
                    currentPage = parameters.Page,
                    recordPerPage = parameters.RecordsPerPage
                };
            }
        }
        [HttpPost("filter-linkage-euc-ij-j1001")]
        public async Task<LinkageEucIjJ1001Model> FilterStructureEucIj1001(PaginationParams parameters)
        {
            try
            {
                LinkageEucIjJ1001Model result = new LinkageEucIjJ1001Model()
                {
                    currentPage = parameters.Page,
                    recordPerPage = parameters.RecordsPerPage
                };
                var query = context.MvEucJ1001Ijs.AsQueryable();
                query = !string.IsNullOrEmpty(parameters.search) ? query.Where(x => x.PartsNo != null && x.PartsNo.ToUpper().Contains(parameters.search.ToUpper())) : query;

                result.totalRecords = await query.CountAsync();
                result.totalPage = (int)Math.Ceiling((decimal)result.totalRecords / parameters.RecordsPerPage);
                var model = await query.OrderBy(x => x.PartsNo).Paginate(parameters).ToListAsync();
                result.lstModel = model;
                result.fromRecord = model.Count == 0 ? 0 : (result.currentPage - 1) * result.recordPerPage + 1;
                result.toRecord = (int)Math.Min(result.totalRecords, result.currentPage * result.recordPerPage);
                result.currentPage = result.totalPage < result.currentPage ? result.totalPage : result.currentPage;
                return result;
            }
            catch (Exception e)
            {
                //SendMailError(e);
                return new LinkageEucIjJ1001Model()
                {
                    currentPage = parameters.Page,
                    recordPerPage = parameters.RecordsPerPage
                };
            }
        }
        [HttpPost("filter-linkage-euc-lbp-h1701")]
        public async Task<LinkageEucLbpH1701Model> FilterStructureEucLbp1701(PaginationParams parameters)
        {
            try
            {
                LinkageEucLbpH1701Model result = new LinkageEucLbpH1701Model()
                {
                    currentPage = parameters.Page,
                    recordPerPage = parameters.RecordsPerPage
                };
                var query = context.MvEucH1701s.AsQueryable();
                query = !string.IsNullOrEmpty(parameters.search) ? query.Where(x => x.NoChldParts != null && x.NoChldParts.ToUpper().Contains(parameters.search.ToUpper())) : query;

                result.totalRecords = await query.CountAsync();
                result.totalPage = (int)Math.Ceiling((decimal)result.totalRecords / parameters.RecordsPerPage);
                var model = await query.OrderBy(x => x.CdBlock).Paginate(parameters).ToListAsync();
                result.lstModel = model;
                result.fromRecord = model.Count == 0 ? 0 : (result.currentPage - 1) * result.recordPerPage + 1;
                result.toRecord = (int)Math.Min(result.totalRecords, result.currentPage * result.recordPerPage);
                result.currentPage = result.totalPage < result.currentPage ? result.totalPage : result.currentPage;
                return result;
            }
            catch (Exception e)
            {
                //SendMailError(e);
                return new LinkageEucLbpH1701Model()
                {
                    currentPage = parameters.Page,
                    recordPerPage = parameters.RecordsPerPage
                };
            }
        }
        [HttpPost("filter-linkage-euc-lbp-h300")]
        public async Task<LinkageEucLbpH300Model> FilterStructureEucLbp300(PaginationParams parameters)
        {
            try
            {
                LinkageEucLbpH300Model result = new LinkageEucLbpH300Model()
                {
                    currentPage = parameters.Page,
                    recordPerPage = parameters.RecordsPerPage
                };
                var query = context.MvEucH300Lbps.AsQueryable();
                query = !string.IsNullOrEmpty(parameters.search) ? query.Where(x => x.NoParts != null && x.NoParts.ToUpper().Contains(parameters.search.ToUpper())) : query;

                result.totalRecords = await query.CountAsync();
                result.totalPage = (int)Math.Ceiling((decimal)result.totalRecords / parameters.RecordsPerPage);
                var model = await query.OrderBy(x => x.CdBlock).Paginate(parameters).ToListAsync();
                result.lstModel = model;
                result.fromRecord = model.Count == 0 ? 0 : (result.currentPage - 1) * result.recordPerPage + 1;
                result.toRecord = (int)Math.Min(result.totalRecords, result.currentPage * result.recordPerPage);
                result.currentPage = result.totalPage < result.currentPage ? result.totalPage : result.currentPage;
                return result;
            }
            catch (Exception e)
            {
                //SendMailError(e);
                return new LinkageEucLbpH300Model()
                {
                    currentPage = parameters.Page,
                    recordPerPage = parameters.RecordsPerPage
                };
            }
        }
        [HttpPost("filter-linkage-euc-lbp-h501")]
        public async Task<LinkageEucLbpH501Model> FilterStructureEucLbp501(PaginationParams parameters)
        {
            try
            {
                LinkageEucLbpH501Model result = new LinkageEucLbpH501Model()
                {
                    currentPage = parameters.Page,
                    recordPerPage = parameters.RecordsPerPage
                };
                var query = context.MvEucH501Lbps.AsQueryable();
                query = !string.IsNullOrEmpty(parameters.search) ? query.Where(x => x.NoParts != null && x.NoParts.ToUpper().Contains(parameters.search.ToUpper())) : query;

                result.totalRecords = await query.CountAsync();
                result.totalPage = (int)Math.Ceiling((decimal)result.totalRecords / parameters.RecordsPerPage);
                var model = await query.OrderBy(x => x.CdBlock).Paginate(parameters).ToListAsync();
                result.lstModel = model;
                result.fromRecord = model.Count == 0 ? 0 : (result.currentPage - 1) * result.recordPerPage + 1;
                result.toRecord = (int)Math.Min(result.totalRecords, result.currentPage * result.recordPerPage);
                result.currentPage = result.totalPage < result.currentPage ? result.totalPage : result.currentPage;
                return result;
            }
            catch (Exception e)
            {
                //SendMailError(e);
                return new LinkageEucLbpH501Model()
                {
                    currentPage = parameters.Page,
                    recordPerPage = parameters.RecordsPerPage
                };
            }
        }
        [HttpPost("filter-linkage-euc-lbp-j1001")]
        public async Task<LinkageEucLbpJ1001Model> FilterStructureEucLbp1001(PaginationParams parameters)
        {
            try
            {
                LinkageEucLbpJ1001Model result = new LinkageEucLbpJ1001Model()
                {
                    currentPage = parameters.Page,
                    recordPerPage = parameters.RecordsPerPage
                };
                var query = context.MvEucJ1001Lbps.AsQueryable();
                query = !string.IsNullOrEmpty(parameters.search) ? query.Where(x => x.NoParts != null && x.NoParts.ToUpper().Contains(parameters.search.ToUpper())) : query;

                result.totalRecords = await query.CountAsync();
                result.totalPage = (int)Math.Ceiling((decimal)result.totalRecords / parameters.RecordsPerPage);
                var model = await query.OrderBy(x => x.NoParts).Paginate(parameters).ToListAsync();
                result.lstModel = model;
                result.fromRecord = model.Count == 0 ? 0 : (result.currentPage - 1) * result.recordPerPage + 1;
                result.toRecord = (int)Math.Min(result.totalRecords, result.currentPage * result.recordPerPage);
                result.currentPage = result.totalPage < result.currentPage ? result.totalPage : result.currentPage;
                return result;
            }
            catch (Exception e)
            {
                //SendMailError(e);
                return new LinkageEucLbpJ1001Model()
                {
                    currentPage = parameters.Page,
                    recordPerPage = parameters.RecordsPerPage
                };
            }
        }
        [HttpPost("filter-linkage-euc-lbp-j101")]
        public async Task<LinkageEucLbpJ101Model> FilterStructureEucLbp101(PaginationParams parameters)
        {
            try
            {
                LinkageEucLbpJ101Model result = new LinkageEucLbpJ101Model()
                {
                    currentPage = parameters.Page,
                    recordPerPage = parameters.RecordsPerPage
                };
                var query = context.LinkageEucLbpJ101s.Where(x => x.Active == true).AsQueryable();
                query = !string.IsNullOrEmpty(parameters.search) ? query.Where(x => x.NoParts != null && x.NoParts.ToUpper().Contains(parameters.search.ToUpper())) : query;

                result.totalRecords = await query.CountAsync();
                result.totalPage = (int)Math.Ceiling((decimal)result.totalRecords / parameters.RecordsPerPage);
                var model = await query.OrderBy(x => x.NoParts).Paginate(parameters).ToListAsync();
                result.lstModel = model;
                result.fromRecord = model.Count == 0 ? 0 : (result.currentPage - 1) * result.recordPerPage + 1;
                result.toRecord = (int)Math.Min(result.totalRecords, result.currentPage * result.recordPerPage);
                result.currentPage = result.totalPage < result.currentPage ? result.totalPage : result.currentPage;
                return result;
            }
            catch (Exception e)
            {
                //SendMailError(e);
                return new LinkageEucLbpJ101Model()
                {
                    currentPage = parameters.Page,
                    recordPerPage = parameters.RecordsPerPage
                };
            }
        }
        [HttpGet("filter-master-unique/{product}")]
        public List<TodStructureMasterUniquePart> FilterMasterUnique(string product)
        {
            try
            {
                var query = context.TodStructureMasterUniqueParts.Where(x => x.Active == true && x.Product.ToUpper().Contains(product.ToUpper())).ToList().OrderBy(x => x.Kind).ToList();
                return query;
            }
            catch (Exception e)
            {
                //SendMailError(e);
                return new List<TodStructureMasterUniquePart>();
            }
        }

        [HttpPost("save-master-unique/{product}")]
        public CommonResponse FilterMasterUnique([FromBody] List<TodStructureMasterUniquePart> param, string product)
        {
            CommonResponse res = new CommonResponse()
            {
                Error = true,
                Message = "Default",
                Status = 400
            };
            try
            {
                var lstDel = context.TodStructureMasterUniqueParts.Where(x => x.Active == true && x.Product.ToUpper() == product.ToUpper()).ToList();
                var lstAdd = new List<TodStructureMasterUniquePart>();
                foreach (var item in param)
                {
                    lstAdd.Add(new TodStructureMasterUniquePart
                    {
                        Kind = item.Kind,
                        Merchandise = item.Merchandise,
                        Product = product.ToUpper()
                    });
                }
                context.RemoveRange(lstDel);
                context.AddRange(lstAdd);
                context.SaveChanges();
                
                res.Message = "Successfull!";
                res.Error = false;
                res.Status = 200;

            }
            catch (Exception e)
            {
                res.Message = e.Message;
                res.Error = true;
                res.Status = 400;
            }
            return res;
        }
        [HttpPost("add-structure-master-delivery")]
        public async Task<CommonResponse> AddStructureMasterDelivery([FromBody] TodStructureMasterDeliveryRequest rq)
        {
            CommonResponse res = new CommonResponse()
            {
                Error = true,
                Message = "Can't add new master",
                Status = 400
            };
            var config = new MapperConfiguration(cfg => cfg.CreateMap<TodStructureMasterDeliveryRequest, TodStructureMasterDelivery>());
            var mapper = config.CreateMapper();
            try
            {
                var u = GetCurrentUser();
                var model = mapper.Map<TodStructureMasterDeliveryRequest, TodStructureMasterDelivery>(rq);
                if (model != null)
                {
                    model.CreatedBy = u.UserName;
                    context.TodStructureMasterDeliveries.Add(model);

                    int r = await context.SaveChangesAsync();
                    if (r > 0)
                    {
                        res.Status = 200;
                        res.Message = "Sucessful !";
                        res.Error = true;
                    }
                }
            }
            catch (Exception e)
            {
                //SendMailError(e);
                res.Message = e.Message;
                res.Error = true;
                res.Status = 400;
            }
            return res;
        }
        [HttpPost("add-structure-master-job-assignment")]
        public async Task<CommonResponse> AddStructureMasterJobAssignment([FromBody] TodStructureMasterJobAssignmentRequest rq)
        {
            CommonResponse res = new CommonResponse()
            {
                Error = true,
                Message = "Can't add new master",
                Status = 400
            };
            var config = new MapperConfiguration(cfg => cfg.CreateMap<TodStructureMasterJobAssignmentRequest, TodStructureMasterJobAssign>());
            var mapper = config.CreateMapper();
            try
            {
                var u = GetCurrentUser();
                var model = mapper.Map<TodStructureMasterJobAssignmentRequest, TodStructureMasterJobAssign>(rq);
                if (model != null)
                {
                    model.CreatedBy = u.UserName;
                    context.TodStructureMasterJobAssigns.Add(model);
                    int r = await context.SaveChangesAsync();
                    if (r > 0)
                    {
                        res.Status = 200;
                        res.Message = "Sucessful !";
                        res.Error = true;
                    }
                }
            }
            catch (Exception e)
            {
                //SendMailError(e);
                res.Message = e.Message;
                res.Error = true;
                res.Status = 400;
            }
            return res;
        }
        [HttpPost("add-structure-master-merchandise")]
        public async Task<CommonResponse> AddStructureMasterMerchandise([FromBody] TodStructureMasterMerchandiseRequest rq)
        {
            CommonResponse res = new CommonResponse()
            {
                Error = true,
                Message = "Can't add new master",
                Status = 400
            };
            var config = new MapperConfiguration(cfg => cfg.CreateMap<TodStructureMasterMerchandiseRequest, TodStructureMasterMerchandise>().ForMember(dest => dest.StartProductionDate, opt => opt.Ignore()));
            var mapper = config.CreateMapper();

            try
            {
                DateOnly? startProduction = rq.StartProductionDate.StringToDateAble();
                var u = GetCurrentUser();
                var model = mapper.Map<TodStructureMasterMerchandiseRequest, TodStructureMasterMerchandise>(rq);
                model.StartProductionDate = startProduction;
                if (model != null)
                {
                    model.CreatedBy = u.UserName;
                    context.TodStructureMasterMerchandises.Add(model);
                    int r = await context.SaveChangesAsync();
                    if (r > 0)
                    {
                        res.Status = 200;
                        res.Message = "Sucessful !";
                        res.Error = true;
                    }
                }
            }
            catch (Exception e)
            {
                //SendMailError(e);
                res.Message = e.Message;
                res.Error = true;
                res.Status = 400;
            }
            return res;
        }
        [HttpPost("add-structure-master-packing")]
        public async Task<CommonResponse> AddStructureMasterPacking([FromBody] TodStructureMasterPackingRequest rq)
        {
            CommonResponse res = new CommonResponse()
            {
                Error = true,
                Message = "Can't add new master",
                Status = 400
            };
            var config = new MapperConfiguration(cfg => cfg.CreateMap<TodStructureMasterPackingRequest, TodStructureMasterPacking>());
            var mapper = config.CreateMapper();
            try
            {
                var u = GetCurrentUser();
                var model = mapper.Map<TodStructureMasterPackingRequest, TodStructureMasterPacking>(rq);
                if (model != null)
                {
                    if(model.PcsPallet != null && model.PcsBox != null)
                    {
                        model.BoxPallet = (model.PcsPallet/ model.PcsBox) ;
                    }
                    model.CreatedBy = u.UserName;
                    context.TodStructureMasterPackings.Add(model);
                    int r = await context.SaveChangesAsync();
                    if (r > 0)
                    {
                        res.Status = 200;
                        res.Message = "Sucessful !";
                        res.Error = true;
                    }
                }
            }
            catch (Exception e)
            {
                //SendMailError(e);
                res.Message = e.Message;
                res.Error = true;
                res.Status = 400;
            }
            return res;
        }

        [HttpPost("add-structure-temporary")]
        public async Task<CommonResponse> AddTemporaryStructure([FromBody] TodStructureTemporaryConnectRequest rq)
        {
            CommonResponse res = new CommonResponse()
            {
                Error = true,
                Message = "Can't add new master",
                Status = 400
            };
            var config = new MapperConfiguration(cfg => cfg.CreateMap<TodStructureTemporaryConnectRequest, TodStructureTemporaryConnect>().ForMember(dest => dest.EffectiveTo, opt => opt.Ignore())
                                                                                                                                          .ForMember(dest => dest.EfffectiveFrom, opt => opt.Ignore())); ;
            var mapper = config.CreateMapper();
            try
            {
                DateOnly? from = rq.EffectiveFrom.StringToDateAble();
                DateOnly? to = rq.EffectiveTo.StringToDateAble();
                var u = GetCurrentUser();
                DateTime now = DateTime.Now;
                int millisecondOfDay = (now.Hour * 60 * 60) + (now.Minute * 60) + (now.Second) + now.Millisecond;
                var model = mapper.Map<TodStructureTemporaryConnectRequest, TodStructureTemporaryConnect>(rq);
                if (model != null)
                {
                    model.CreatedBy = u.UserName;
                    model.EffectiveTo = to;
                    model.EfffectiveFrom = (DateOnly)from;
                    model.TempNo = GetNewTempo("Temp_" + DateTime.Now.ToString("yyMMddHH") + "_");
                    context.TodStructureTemporaryConnects.Add(model);
                    int r = await context.SaveChangesAsync();
                    if (r > 0)
                    {
                        res.Status = 200;
                        res.Message = "Sucessful !";
                        res.Error = true;
                    }
                }
            }
            catch (Exception e)
            {
                //SendMailError(e);
                res.Message = e.Message;
                res.Error = true;
                res.Status = 400;
            }
            return res;
        }

        [HttpPut("update-structure-master-merchandise/{id}")]
        public async Task<CommonResponse> UpdateStructureMasterMerchandise(Guid id, [FromBody] TodStructureMasterMerchandiseRequest rq)
        {
            CommonResponse res = new CommonResponse()
            {
                Error = false,
                Message = "Can't update the master",
                Status = 200
            };
            try
            {
                DateOnly? startProduction = rq.StartProductionDate.StringToDateAble();
                var config = new MapperConfiguration(cfg => cfg.CreateMap<TodStructureMasterMerchandiseRequest, TodStructureMasterMerchandise>().ForMember(dest => dest.StartProductionDate, opt => opt.Ignore())
                                                                                                                                          .ForMember(dest => dest.Id, opt => opt.Ignore()));
                var mapper = config.CreateMapper();
                var u = GetCurrentUser();
                var model = await context.TodStructureMasterMerchandises.FirstAsync(x => x.Id == id);
                var model1 = mapper.Map<TodStructureMasterMerchandiseRequest, TodStructureMasterMerchandise>(rq);
                model1.StartProductionDate = startProduction;
                model1.ApprovedBy = null;
                model1.ApprovedDate = null;
                model1.CreatedBy = u.UserName;
                model1.CreatedDate = DateTime.Now;
                context.TodStructureMasterMerchandises.Remove(model);
                context.TodStructureMasterMerchandises.Add(model1);
                int r = await context.SaveChangesAsync();
                res.Message = r > 0 ? "Successful !" : "Can't update";
            }
            catch (Exception e)
            {
                //SendMailError(e);
                res.Message = e.Message;
                res.Error = true;
                res.Status = 400;
            }
            return res;
        }
        [HttpPut("update-structure-master-delivery/{id}")]
        public async Task<CommonResponse> UpdateStructureMasterDelivery(Guid id, [FromBody] TodStructureMasterDeliveryRequest rq)
        {
            CommonResponse res = new CommonResponse()
            {
                Error = false,
                Message = "Can't update the master",
                Status = 200
            };
            try
            {
                var config = new MapperConfiguration(cfg => cfg.CreateMap<TodStructureMasterDeliveryRequest, TodStructureMasterDelivery>());
                var mapper = config.CreateMapper();
                var u = GetCurrentUser();
                var model = await context.TodStructureMasterDeliveries.FirstAsync(x => x.Id == id);
                var model1 = mapper.Map<TodStructureMasterDeliveryRequest, TodStructureMasterDelivery>(rq);
                model1.ApprovedBy = null;
                model1.ApprovedDate = null;
                model1.CreatedBy = u.UserName;
                model1.CreatedDate = DateTime.Now;
                context.TodStructureMasterDeliveries.Remove(model);
                context.TodStructureMasterDeliveries.Add(model1);
                int r = await context.SaveChangesAsync();
                res.Message = r > 0 ? "Successful !" : "Can't update";
            }
            catch (Exception e)
            {
                //SendMailError(e);
                res.Message = e.Message;
                res.Error = true;
                res.Status = 400;
            }
            return res;
        }
        [HttpPut("update-structure-master-packing/{id}")]
        public async Task<CommonResponse> UpdateStructureMasterPacking(Guid id, [FromBody] TodStructureMasterPackingRequest rq)
        {
            CommonResponse res = new CommonResponse()
            {
                Error = false,
                Message = "Can't update the master",
                Status = 200
            };
            try
            {
                var config = new MapperConfiguration(cfg => cfg.CreateMap<TodStructureMasterPackingRequest, TodStructureMasterPacking>());
                var mapper = config.CreateMapper();
                var u = GetCurrentUser();
                var model = await context.TodStructureMasterPackings.FirstAsync(x => x.Id == id);
                var model1 = mapper.Map<TodStructureMasterPackingRequest, TodStructureMasterPacking>(rq);
                model1.ApprovedBy = null;
                model1.ApprovedDate = null;
                model1.CreatedBy = u.UserName;
                model1.CreatedDate = DateTime.Now;
                model1.BoxPallet = (model1.PcsPallet / model1.PcsBox); ;
                context.TodStructureMasterPackings.Remove(model);
                context.TodStructureMasterPackings.Add(model1);
                int r = await context.SaveChangesAsync();
                res.Message = r > 0 ? "Successful !" : "Can't update";
            }
            catch (Exception e)
            {
                //SendMailError(e);
                res.Message = e.Message;
                res.Error = true;
                res.Status = 400;
            }
            return res;
        }
        [HttpPut("update-structure-job-assignment/{id}")]
        public async Task<CommonResponse> UpdateStructureJobAssignment(Guid id, [FromBody] TodStructureMasterJobAssignmentRequest rq)
        {
            CommonResponse res = new CommonResponse()
            {
                Error = false,
                Message = "Can't update the master",
                Status = 200
            };
            try
            {
                var config = new MapperConfiguration(cfg => cfg.CreateMap<TodStructureMasterJobAssignmentRequest, TodStructureMasterJobAssign>());
                var mapper = config.CreateMapper();
                var u = GetCurrentUser();
                var model = await context.TodStructureMasterJobAssigns.FirstAsync(x => x.Id == id);
                var model1 = mapper.Map<TodStructureMasterJobAssignmentRequest, TodStructureMasterJobAssign>(rq);
                model1.ApprovedBy = null;
                model1.ApprovedDate = null;
                model1.CreatedBy = u.UserName;
                model1.CreatedDate = DateTime.Now;
                context.TodStructureMasterJobAssigns.Remove(model);
                context.TodStructureMasterJobAssigns.Add(model1);
                int r = await context.SaveChangesAsync();
                res.Message = r > 0 ? "Successful !" : "Can't update";
            }
            catch (Exception e)
            {
                //SendMailError(e);
                res.Message = e.Message;
                res.Error = true;
                res.Status = 400;
            }
            return res;
        }

        [HttpPut("update-structure-temporary-connect/{id}")]
        public async Task<CommonResponse> UpdateStructureTemporary(Guid id, [FromBody] TodStructureTemporaryConnectRequest rq)
        {
            CommonResponse res = new CommonResponse()
            {
                Error = false,
                Message = "Can't update the master",
                Status = 200
            };
            try
            {
                //var config = new MapperConfiguration(cfg => cfg.CreateMap<TodStructureTemporaryConnect, TodStructureTemporaryConnect>().ForMember(dest => dest.EffectiveTo, opt => opt.Ignore())
                                                                                                                                     //.ForMember(dest => dest.EfffectiveFrom, opt => opt.Ignore())); ;
                DateOnly? from = rq.EffectiveFrom.StringToDateAble();
                DateOnly? to = rq.EffectiveTo.StringToDateAble();
                //var mapper = config.CreateMapper();
                var u = GetCurrentUser();
                var model = await context.TodStructureTemporaryConnects.FirstAsync(x => x.Id == id);
                //var model1 = mapper.Map<TodStructureTemporaryConnect, TodStructureTemporaryConnect>(model);
                model.ApprovedBy = null;
                model.ApprovedDate = null;
                model.ModifiedBy = u.UserName;
                model.ModifiedDate = DateTime.Now;
                //model1.TempNo = "TEMP" + DateTime.Now.ToString("yyMMddHHmmssttt");
                model.EffectiveTo = to;
                model.EfffectiveFrom = (DateOnly)from;
                model.Usage = (double)rq.Usage;
                model.Ratio = (double)rq.Ratio;
                model.Reason = rq.Reason;
                model.InventoryBy = rq.InventoryBy;
                model.EcnLevel = rq.EcnLevel;
                //model.Bc = rq.BC;

                //context.TodStructureTemporaryConnects.Remove(model);
                context.TodStructureTemporaryConnects.Update(model);
                int r = await context.SaveChangesAsync();
                res.Message = r > 0 ? "Successful !" : "Can't update";
            }
            catch (Exception e)
            {
                //SendMailError(e);
                res.Message = e.Message;
                res.Error = true;
                res.Status = 400;
            }
            return res;
        }


        [HttpGet("approve-master-structure/{masterType}")]
        public async Task<CommonResponse> ApproveMasterStructure(string masterType)
        {
            CommonResponse res = new CommonResponse()
            {
                Error = false,
                Message = "",
                Status = (int)HttpStatusCode.BadRequest
            };
            try
            {
                var redis = RedisConnectionManager.GetRedisConnection();
                var database = redis.GetDatabase();
                var u = GetCurrentUser();
                if (masterType.Equals("merchandise"))
                {
                    //những con approved trc đó thì bỏ hết, vì mình lấy cái mới mà
                    var modelOld = await context.TodStructureMasterMerchandises
                        .Where(x => x.Active == true && x.ApprovedDate != null && x.ApprovedBy != null)
                        .ToListAsync();
                    modelOld.ForEach(x =>
                    {
                        x.Active = false;
                    });
                    context.UpdateRange(modelOld);
                    context.SaveChanges();
                    //và approve cho những con mới
                    var model = await context.TodStructureMasterMerchandises
                        .Where(x => x.Active == true && x.ApprovedDate == null)
                        .ToListAsync();
                    model.ForEach(x =>
                    {
                        x.ApprovedBy = u.UserName;
                        x.ApprovedDate = DateTime.Now;

                    });
                    context.UpdateRange(model);
                    context.SaveChanges();
                }
                else if (masterType.Equals("delivery"))
                {
                    //database.KeyDelete("ijDelivery");
                    //những con approved trc đó thì bỏ hết, vì mình lấy cái mới mà
                    var modelOld = await context.TodStructureMasterDeliveries
                        .Where(x => x.Active == true && x.ApprovedDate != null && x.ApprovedBy != null)
                        .ToListAsync();
                    modelOld.ForEach(x =>
                    {
                        x.Active = false;
                        //database.KeyDelete("ijDelivery");
                    });
                    context.UpdateRange(modelOld);
                    context.SaveChanges();
                    //và approve cho những con mới
                    database.KeyDelete("ijDelivery");
                    database.KeyDelete("lbpDelivery");
                    var model = await context.TodStructureMasterDeliveries
                        .Where(x => x.Active == true && x.ApprovedDate == null)
                        .ToListAsync();
                    model.ForEach(x =>
                    {
                        x.ApprovedBy = u.UserName;
                        x.ApprovedDate = DateTime.Now;
                        if (x.Product.ToUpper() == "IJ")
                        {
                            database.HashSet("ijDelivery", x.VendorCode, JsonConvert.SerializeObject(x));
                        }
                        else
                        {
                            database.HashSet("lbpDelivery", x.VendorCode, JsonConvert.SerializeObject(x));
                        }
                    });
                    context.UpdateRange(model);
                    context.SaveChanges();
                }
                else if (masterType.Equals("packing"))
                {
                    //riêng đối với packing thì sẽ disable những thông tin cũ,
                    //tìm những con cũ dựa vào key những con mới
                    var model = await context.TodStructureMasterPackings
                        .Where(x => x.Active == true && x.ApprovedDate == null)
                        .ToListAsync();

                    var packing = context.TodStructureMasterPackings
                        .Where(x => x.Active == true && x.ApprovedDate != null).ToList();
                    List<TodStructureMasterPacking> lstDel = new List<TodStructureMasterPacking>();
                    model.ForEach(x =>
                    {
                        var exists = packing.Where(y => y.Vendor == x.Vendor && y.PartNo == x.PartNo).ToList();

                        lstDel.AddRange(exists);


                        x.ApprovedBy = u.UserName;
                        x.ApprovedDate = DateTime.Now;
                        database.HashSet("ijPacking", x.PartNo + "_" + x.Vendor, JsonConvert.SerializeObject(x));

                    });
                    lstDel.ForEach(x => x.Active = false);
                    //model.ForEach(x =>
                    //{
                    //    x.ApprovedBy = u.UserName;
                    //    x.ApprovedDate = DateTime.Now;
                    //    database.HashSet("ijPacking", x.PartNo + "_" + x.Vendor, JsonConvert.SerializeObject(x));
                    //});
                    context.TodStructureMasterPackings.UpdateRange(lstDel);
                    context.TodStructureMasterPackings.UpdateRange(model);
                    context.SaveChanges();
                }
                else if (masterType.Equals("jobassignment"))
                {
                    //database.KeyDelete("ijJob");
                    //những con approved trc đó thì bỏ hết, vì mình lấy cái mới mà
                    var modelOld = await context.TodStructureMasterJobAssigns
                        .Where(x => x.Active == true && x.ApprovedDate != null && x.ApprovedBy != null)
                        .ToListAsync();
                    modelOld.ForEach(x =>
                    {
                        x.Active = false;
                    });
                    context.UpdateRange(modelOld);
                    context.SaveChanges();
                   
                    //và approve cho những con mới
                    var model = await context.TodStructureMasterJobAssigns
                        .Where(x => x.Active == true && x.ApprovedDate == null)
                        .ToListAsync();
                    model.ForEach(x =>
                    {
                        x.ApprovedBy = u.UserName;
                        x.ApprovedDate = DateTime.Now;
                        if (x.Product.ToUpper() == "IJ")
                        {
                            database.HashSet("ijJob", x.Bc + "_" + x.VendorCode, JsonConvert.SerializeObject(x));
                        }
                        else
                        {
                            database.HashSet("lbpJob", x.Bc + "_" + x.VendorCode, JsonConvert.SerializeObject(x));
                        }

                    });
                    context.UpdateRange(model);
                    context.SaveChanges();
                }
                res.Error = false;
                res.Message = "Successfully !";
                res.Status = (int)HttpStatusCode.OK;
                return res;
            }
            catch (Exception e)
            {
                res.Error = true;
                res.Message = e.Message;
                res.Status = (int)HttpStatusCode.BadRequest;
                //SendMailError(e);
                return res;
            }


        }

        [HttpGet("reject-master-structure/{masterType}")]
        public async Task<CommonResponse> RejectMasterStructure(string masterType)
        {
            CommonResponse res = new CommonResponse()
            {
                Error = false,
                Message = "",
                Status = (int)HttpStatusCode.BadRequest
            };
            try
            {  
                var u = GetCurrentUser();
                if (masterType.Equals("merchandise"))
                {
                    //bỏ những con chưa approve
                    var modelOld = await context.TodStructureMasterMerchandises
                        .Where(x => x.Active == true && x.ApprovedDate == null)
                        .ToListAsync();
                    modelOld.ForEach(x =>
                    {
                        x.Active = false;
                        x.ApprovedBy = u.UserName;
                        x.ApprovedDate = DateTime.Now;
                    });
                    context.UpdateRange(modelOld);
                    context.SaveChanges();
                }
                else if (masterType.Equals("delivery"))
                {
                  
                    var modelOld = await context.TodStructureMasterDeliveries
                        .Where(x => x.Active == true && x.ApprovedDate == null)
                        .ToListAsync();
                    modelOld.ForEach(x =>
                    {
                        x.Active = false;
                        x.ApprovedBy = u.UserName;
                        x.ApprovedDate = DateTime.Now;
                    });
                    context.UpdateRange(modelOld);
                    context.SaveChanges();
                   
                }
                else if (masterType.Equals("packing"))
                { 
                    var model = await context.TodStructureMasterPackings
                        .Where(x => x.Active == true && x.ApprovedDate == null)
                        .ToListAsync();
                    model.ForEach(x =>
                    {
                        x.Active = false;
                        x.ApprovedBy = u.UserName;
                        x.ApprovedDate = DateTime.Now;                  
                    });
                    context.TodStructureMasterPackings.UpdateRange(model);
                    context.SaveChanges();
                }
                else if (masterType.Equals("jobassignment"))
                {
                    
                    var modelOld = await context.TodStructureMasterJobAssigns
                        .Where(x => x.Active == true && x.ApprovedDate == null)
                        .ToListAsync();
                    modelOld.ForEach(x =>
                    {
                        x.Active = false;
                        x.ApprovedBy = u.UserName;
                        x.ApprovedDate = DateTime.Now;
                    });
                    context.UpdateRange(modelOld);
                    context.SaveChanges();
                }
                res.Error = false;
                res.Message = "Successfully !";
                res.Status = (int)HttpStatusCode.OK;
                return res;
            }
            catch (Exception e)
            {
                res.Error = true;
                res.Message = e.Message;
                res.Status = (int)HttpStatusCode.BadRequest;
                //SendMailError(e);
                return res;
            }
        }
        [HttpGet("approve-temporary-structure")]
        public async Task<CommonResponse> ApproveTempStructure()
        {
            var redis = RedisConnectionManager.GetRedisConnection();
            var database = redis.GetDatabase();
            CommonResponse res = new CommonResponse()
            {
                Error = false,
                Message = "",
                Status = (int)HttpStatusCode.BadRequest
            };
            try
            {
                var u = GetCurrentUser();

                var model = await context.TodStructureTemporaryConnects
                    .Where(x => x.Active == true && x.ApprovedDate == null)
                    .ToListAsync();
                List<TodStructureTemporaryConnect> lstDel = new List<TodStructureTemporaryConnect>();
                foreach (var item in model)
                {
                    var exists = context.TodStructureTemporaryConnects.Where(x => x.Vendor == item.Vendor && x.PartNo == item.PartNo && x.Bc == item.Bc
                    && x.Ratio == item.Ratio  && x.Model == item.Model && x.Merchandise == item.Merchandise && x.TempNo != item.TempNo ).ToList();
                    foreach (var ex in exists)
                    {
                        ex.Active = false;
                        lstDel.Add(ex);
                    }                
                }
                context.UpdateRange(lstDel);
                context.SaveChanges();
                model.ForEach(x =>
                {
                    x.ApprovedBy = u.UserName;
                    x.ApprovedDate = DateTime.Now;
                    
                });
                context.UpdateRange(model);
                await context.SaveChangesAsync();

                res.Error = false;
                res.Message = "Successfully !";
                res.Status = (int)HttpStatusCode.OK;
            }
            catch (Exception e)
            {
                res.Error = true;
                res.Message = e.Message;
                res.Status = (int)HttpStatusCode.BadRequest;
                //SendMailError(e);
            }
            return res;
        }
        [HttpGet("reject-temporary-structure")]
        public async Task<CommonResponse> RejectTempStructure()
        {
           
            CommonResponse res = new CommonResponse()
            {
                Error = false,
                Message = "",
                Status = (int)HttpStatusCode.BadRequest
            };
            try
            {
                var u = GetCurrentUser();

                var model = await context.TodStructureTemporaryConnects
                    .Where(x => x.Active == true && x.ApprovedDate == null)
                    .ToListAsync();
               
                model.ForEach(x =>
                {
                    x.ApprovedBy = u.UserName;
                    x.ApprovedDate = DateTime.Now;
                    x.Active = false;
                });
                context.UpdateRange(model);
                await context.SaveChangesAsync();

                res.Error = false;
                res.Message = "Successfully !";
                res.Status = (int)HttpStatusCode.OK;
            }
            catch (Exception e)
            {
                res.Error = true;
                res.Message = e.Message;
                res.Status = (int)HttpStatusCode.BadRequest;
                //SendMailError(e);
            }
            return res;
        }
        [HttpPut("delete-master-structure/{masterType}")]
        public async Task<CommonResponse> DeleteMasterStructure(string masterType, [FromBody] Guid[] id)
        {
            CommonResponse res = new CommonResponse()
            {
                Error = false,
                Message = "",
                Status = (int)HttpStatusCode.BadRequest
            };
            try
            {
                var u = GetCurrentUser();
                if (masterType.Equals("merchandise"))
                {
                    var model = await context.TodStructureMasterMerchandises
                        .Where(x => x.Active == true && x.ApprovedDate == null && id.Contains(x.Id))
                        .ToListAsync();
                    context.TodStructureMasterMerchandises.RemoveRange(model);
                    context.SaveChanges();
                }
                else if (masterType.Equals("delivery"))
                {
                    var model = await context.TodStructureMasterDeliveries
                        .Where(x => x.Active == true && x.ApprovedDate == null && id.Contains(x.Id))
                        .ToListAsync();
                    context.TodStructureMasterDeliveries.RemoveRange(model);
                    context.SaveChanges();
                }
                else if (masterType.Equals("packing"))
                {
                    var model = await context.TodStructureMasterPackings
                        .Where(x => x.Active == true && x.ApprovedDate == null && id.Contains(x.Id))
                        .ToListAsync();
                    context.TodStructureMasterPackings.RemoveRange(model);
                    context.SaveChanges();
                }
                else if (masterType.Equals("jobassignment"))
                {
                    var model = await context.TodStructureMasterJobAssigns
                        .Where(x => x.Active == true && x.ApprovedDate == null && id.Contains(x.Id))
                        .ToListAsync();
                    context.TodStructureMasterJobAssigns.RemoveRange(model);
                    context.SaveChanges();
                }
                res.Error = false;
                res.Message = "Successfully !";
                res.Status = (int)HttpStatusCode.OK;
            }
            catch (Exception e)
            {
                res.Error = true;
                res.Message = e.Message;
                res.Status = (int)HttpStatusCode.BadRequest;
                //SendMailError(e);
            }
            return res;
        }
        [HttpPut("delete-temp-structure")]
        public async Task<CommonResponse> DeleteTempStructure([FromBody] Guid[] id)
        {
            var redis = RedisConnectionManager.GetRedisConnection();
            var database = redis.GetDatabase();
            CommonResponse res = new CommonResponse()
            {
                Error = false,
                Message = "",
                Status = (int)HttpStatusCode.BadRequest
            };
            try
            {
                var u = GetCurrentUser();
                var model = await context.TodStructureTemporaryConnects
                    .Where(x => x.Active == true && x.ApprovedDate == null && id.Contains(x.Id))
                    .ToListAsync();
                model.ForEach(x => database.KeyDelete("temporary_" + x.PartNo));
                context.TodStructureTemporaryConnects.RemoveRange(model);
                context.SaveChanges();
                res.Error = false;
                res.Message = "Successfully !";
                res.Status = (int)HttpStatusCode.OK;
            }
            catch (Exception e)
            {
                res.Error = true;
                res.Message = e.Message;
                res.Status = (int)HttpStatusCode.BadRequest;
                //SendMailError(e);
            }
            return res;
        }

        [HttpGet("update-output-after-approve-master-structure-ij/{masterType}")]
        [AllowAnonymous]
        public async Task<CommonResponse> UpdateOutputAfterApproveMasterStructure(string masterType)
        {
            CommonResponse res = new CommonResponse()
            {
                Error = false,
                Message = "",
                Status = (int)HttpStatusCode.BadRequest
            };
            try
            {
                await ManualFunc.GatewayAsync("UpdateStructureAfterApprove/" + masterType + "/IJ");
                res.Error = false;
                res.Message = "Successfully !";
                res.Status = (int)HttpStatusCode.OK;

            }
            catch (Exception e)
            {
                res.Error = true;
                res.Message = e.Message;
                res.Status = (int)HttpStatusCode.BadRequest;
                //SendMailError(e);

            }
            return res;
        }

        [HttpGet("update-output-after-approve-master-structure-lbp/{masterType}")]
        [AllowAnonymous]
        public async Task<CommonResponse> UpdateOutputAfterApproveMasterStructureLBP(string masterType)
        {
            CommonResponse res = new CommonResponse()
            {
                Error = false,
                Message = "",
                Status = (int)HttpStatusCode.BadRequest
            };
            try
            {
                await ManualFunc.GatewayAsync("UpdateStructureAfterApprove/" + masterType + "/LBP");
                res.Error = false;
                res.Message = "Successfully !";
                res.Status = (int)HttpStatusCode.OK;

            }
            catch (Exception e)
            {
                res.Error = true;
                res.Message = e.Message;
                res.Status = (int)HttpStatusCode.BadRequest;
                //SendMailError(e);

            }
            return res;

        }

        [HttpGet("get-output-unique-part/{product}")]
        public async Task<CommonResponse> GetOutPutUniquePart(string product)
        {
            CommonResponse res = new CommonResponse()
            {
                Error = false,
                Message = "",
                Status = (int)HttpStatusCode.BadRequest
            };
            try
            {
                if (product.ToUpper().Contains("IJ"))
                {
                    await _manual.CalcUniquePartIJ();
                }
                else
                {
                    await _manual.CalcUniquePartLBP();

                }
                res.Error = false;
                res.Message = "Successfully !";
                res.Status = (int)HttpStatusCode.OK;

            }
            catch (Exception e)
            {
                res.Error = true;
                res.Message = e.Message;
                res.Status = (int)HttpStatusCode.BadRequest;
                //SendMailError(e);

            }
            return res;

        }
        [HttpPost("get-file-changing-by-date/{product}")]
        public List<string> GetFileChangingByDate(MvOutputStructureParam parameters, string product)
        {
            DateTime? dt_entry = parameters.DateEntry == null ? DateTime.Now : DateTime.Parse(parameters.DateEntry);
            var date = dt_entry.Value.ToString("yyyy-MM-dd");
            string folderPath = Path.Combine(pathServer, "FileOutPut\\OutPutChangingPoint" + product.ToUpper());
            string[] files = Directory.GetFiles(folderPath, "Output_Changing_Point_"+ product.ToUpper() + "_" + date + "*");
            //foreach(var item in files)
            //{
            //    var a = item;
            //}


            return files.Reverse().ToList();
        }

        [HttpGet("filter-list-pic/{product}")]
        public List<string> FilterListPic(string product)
        {
            try
            {
                var query = context.TodStructureMasterJobAssigns.Where(x => x.Active == true && x.ApprovedBy != null  && x.Product.ToUpper().Contains(product.ToUpper()));
                var poPic = query.Select(y =>y.PoPicCode +"_"+ y.PoPic).ToList();
              
                return poPic.Distinct().ToList();
            }
            catch (Exception e)
            {
                //SendMailError(e);
                return new List<string>();
            }
        }
        [HttpGet("filter-list-pic-deadline/{product}")]
        public async Task<List<string>> FilterListPic1(string product)
        {
            try
            {
                var result = new List<string>();
                if(product == "IJ")
                {
                    result = await context.TodTodOutput2DeadlineIjs.Where(x => x.Active == true && x.Pic != null).Select(x => x.Pic ?? "").Distinct().ToListAsync();
                }
                else if(product == "LBP")
                {
                    result = await context.TodTodOutput2DeadlineLbps.Where(x => x.Active == true && x.Pic != null).Select(x => x.Pic ?? "").Distinct().ToListAsync();
                }

                return result;
            }
            catch (Exception e)
            {
                //SendMailError(e);
                return new List<string>();
            }
        }

        [HttpGet("get-file-merchandise/{product}")]
        public List<string> GetFileMerchandise(string product)
        {
            string folderPath = Path.Combine(pathServer, "FileOutPut\\OutPutMer" + product.ToUpper());
            string[] files = Directory.GetFiles(folderPath,"*");
            //foreach(var item in files)
            //{
            //    var a = item;
            //}


            return files.Reverse().ToList();
        }
        #region check Job Processing
        [HttpGet("check-job-processing")]
        public async Task<CommonResponse> CheckJobProcessing()
        {
            CommonResponse res = new CommonResponse()
            {
                Error = false,
                Message = "",
                Status = (int)HttpStatusCode.BadRequest
            };
            try
            {

                var monitoringApi = JobStorage.Current.GetMonitoringApi();
                var countSucess = monitoringApi.ProcessingCount();
                var enqueuedJobs = monitoringApi.ProcessingJobs(0, (int)countSucess);

                var jobExists = enqueuedJobs.FirstOrDefault(job => job.Value.Job.Method.Name == "UpdateOp2WithFormPDC2" ||
                job.Value.Job.Method.Name == "UpdateOp2WithFormLOG" ||
                job.Value.Job.Method.Name == "UpdateOp2WithFormASSY" ||
                job.Value.Job.Method.Name == "UpdateOp2WithFormInHouse" ||
                job.Value.Job.Method.Name == "UpdateOp2WithFormOther" ||
                job.Value.Job.Method.Name == "UpdateOp2InquiryWithApprove" ||
                job.Value.Job.Method.Name == " UpdateOp2InquiryWithApproveOther");

                if (jobExists.Value != null)
                {
                    res.Error = true;
                    res.Message = "Job " + jobExists.Value.Job.Method.Name + " is processing, please wait complete!";
                    res.Status = (int)HttpStatusCode.BadRequest;
                }
                else
                {
                    res.Error = false;
                    res.Message = "Successfully !";
                    res.Status = (int)HttpStatusCode.OK;
                }
            }
            catch (Exception e)
            {
                res.Error = true;
                res.Message = e.Message;
                res.Status = (int)HttpStatusCode.BadRequest;
                //SendMailError(e);
            }
            return res;


        }

        [HttpGet("excute-export-merchandise/{product}")]
        public async Task<CommonResponse> ExcuteExportMerchandise(string product)
        {
            CommonResponse res = new CommonResponse()
            {
                Error = false,
                Message = "",
                Status = (int)HttpStatusCode.BadRequest
            };
            try
            {
                await ManualFunc.GatewayAsync("ExportMerEuc/" + product);
               
                res.Error = false;
                res.Message = "Successfully !";
                res.Status = (int)HttpStatusCode.OK;
                return res;
            }
            catch (Exception e)
            {
                res.Error = true;
                res.Message = e.Message;
                res.Status = (int)HttpStatusCode.BadRequest;
                //SendMailError(e);
                return res;
            }


        }
        #endregion
        private bool SendMailError(Exception e)
        {
            try
            {
                string txtContent = "<p>Message: " + e.Message + "</p>\n" +
                "<p>Data: " + e.Data.ToString() + "</p>\n" +
                "<p>StackTrace: " + e.StackTrace + "</p>\n" +
                "<p>HelpLink: " + e.HelpLink ?? "" + "</p>\n" +
                "<p>Source: " + e.Source ?? "" + "</p>\n";
                email.Initial(lstITMail,
                    "Error exception",
                    txtContent);
                return false;
            }
            catch
            {
                return false;
            }
        }
        private UserClaims GetCurrentUser()
        {
            UserClaims userClaims = new UserClaims();
            var identity = HttpContext.User.Identity as ClaimsIdentity;
            if (identity != null)
            {
                userClaims.UserName = identity.FindFirst("user_name") == null ? "Undefined" : identity.FindFirst("user_name").Value;
                userClaims.Id = identity.FindFirst("id") == null ? "Undefined" : identity.FindFirst("id").Value;
                //userClaims.IsIt = identity.FindFirst("isIt") == null ? "0" : identity.FindFirst("isIt").Value;
                userClaims.Departments = identity.FindFirst("deptIds") == null ? "" : identity.FindFirst("deptIds").Value;
                userClaims.Factories = identity.FindFirst("factIds") == null ? "" : identity.FindFirst("factIds").Value;
                userClaims.CostCenter = identity.FindFirst("cost_center") == null ? "" : identity.FindFirst("cost_center").Value;
                userClaims.FullName = identity.FindFirst("full_name") == null ? "" : identity.FindFirst("full_name").Value;
                userClaims.Departments = identity.FindFirst("dept") == null ? "" : identity.FindFirst("dept").Value;
                userClaims.Grade = identity.FindFirst("grade") == null ? "" : identity.FindFirst("grade").Value;
                userClaims.IsAdmin = identity.FindFirst("isAdmin") == null ? "false" : identity.FindFirst("isAdmin").Value;

            }
            return userClaims;
        }
        private T GetDeserializedObject<T>(string hashKey, string hashField)
        {
            var redis = RedisConnectionManager.GetRedisConnection();
            var database = redis.GetDatabase();
            var json = database.HashGet(hashKey, hashField);
            if (json.IsNull)
            {
                return default(T);
            }
            else
            {
                return JsonConvert.DeserializeObject<T>(json);
            }
        }

        private void NoticeFinishJob(string? type, string? product)
        {
            //var listMail = new List<string>() {
            //        "pdc-ie2@canon-vn.com.vn",
            //        "tpdc-adm35@canon-vn.com.vn",
            //        "tspdc-mm01@canon-vn.com.vn",
            //        "tpdc-adm47@canon-vn.com.vn",
            //        "ts-pdc1303@local.canon-vn.com.vn"};
            try
            {

                var link = "http://cvn-vpsi/#/turnoverday/structure/output-structure";
                string content = "<p>Hey Sirs,</p>\n";
                content += "<p>Output " + product + " was complete update with new " + type + " data </p>\n";
                content += "<p>Now you can check it at: " + link + "</p>\n";
                email.Initial(lstPDCMail, "[PSI-System] Completed update output " + product, content);

            }
            catch (Exception)
            {

            }
        }

        private void NoticeWarningJob(int? total, int? connect,int? notconnect, List<string> lstReceiver, byte[] attachmentData, string attachmentContentType, string attachmentFileName)
        {
            
            try
            {

                string content = "<p  style = 'font-weight: bold;'>Dear [Mrs/Mr]. All,</p>\n";
                content += "<p>Affter update job assignment have some part lack PO/DO PIC: </p>\n";
                content += "<p>  -Amount part lack PO/DO PIC: "+total+"</p>\n";
                content += "<p>  -Amount part lack PO/DO PIC connect model: " + connect + "</p>\n";
                content += "<p>  -Amount part lack PO/DO PIC not connect model: " + notconnect + "</p>\n";
                email.InitialAttach(lstReceiver, "[PSI-System] Warning update Job Assignment", content, attachmentData, attachmentContentType, attachmentFileName);

            }
            catch (Exception)
            {

            }
        }
        private string GetNewTempo(string prefix)
        {
            try
            {
                string rq_no1 = prefix + "00";
                string rq_no2 = rq_no1;



                try
                {

                    rq_no2 = context.TodStructureTemporaryConnects.Where(x => x.Active == true && x.TempNo.StartsWith(prefix)).OrderByDescending(x => x.TempNo).FirstOrDefault().TempNo;


                }
                catch
                {
                    rq_no2 = rq_no1;
                }
                int stt = Convert.ToInt32(rq_no2.Substring(rq_no2.Length - 2));
                string strStt = (stt + 1).ToString().PadLeft(2, '0');
                return prefix + "-" + strStt;
            }
            catch (Exception)
            {
                return prefix + "-01";
            }
        }
        private async Task SendMessageToClients(string param, string message)
        {
            await _hubContext.Clients.All.SendAsync(param, message);
        }

    }
}






















































































































































































