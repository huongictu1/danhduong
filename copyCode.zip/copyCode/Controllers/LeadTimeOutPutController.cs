﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using PDCProjectApi.Common.Interface;
using PDCProjectApi.Data;
using AutoMapper;
using PDCProjectApi.Model.View;
using PDCProjectApi.Model.Request;
using PDCProjectApi.Common;
using Microsoft.EntityFrameworkCore;
using PDCProjectApi.Helper;
using PDCProjectApi.Model.Response;
using System.Security.Claims;
using System.Net;
using Microsoft.AspNetCore.Authorization;
using Newtonsoft.Json;
using PDCProjectApi.Common.Job;
using StackExchange.Redis;
using PDCProjectApi.Services;
using AutoMapper.QueryableExtensions;
using System.Text.RegularExpressions;

namespace PDCProjectApi.Controllers
{
    [Route("api/leadtimeoutput")]
    [ApiController]
    [Authorize]
    //[ApiExplorerSettings(IgnoreApi = true)]
    public class LeadTimeOutPutController : Controller
    {
        [Obsolete]
        private readonly Microsoft.AspNetCore.Hosting.IHostingEnvironment _hostingEnvironment;
        private readonly IHttpContextAccessor httpContextAccessor;
        private readonly IFileStorageService fileStorageService;
        private readonly PdcsystemContext context;
        private readonly IConfiguration configuration;
        private readonly IEmailService email;
        private readonly string outputPathOri = "";
        private readonly IGlobalVariable global;
        [Obsolete]
        public LeadTimeOutPutController(Microsoft.AspNetCore.Hosting.IHostingEnvironment hosting,
            PdcsystemContext ctx, IHttpContextAccessor httpContextAccessor, IFileStorageService fileService,
            IConfiguration configuration, IEmailService mail, IGlobalVariable gl)
        {
            this._hostingEnvironment = hosting;
            this.httpContextAccessor = httpContextAccessor;
            this.context = ctx;
            this.fileStorageService = fileService;
            this.configuration = configuration;
            this.email = mail;
            this.global = gl;
            this.outputPathOri = this.global.ReturnPathOutput();
        }

        #region filter output
        [HttpPost("filter-lt-output0-part-list/{product}")]
        public async Task<LtOutput0PartListModel> FilterLtOutput0PartList(LtOutput0PartListParam parameters, string product)
        {
            try
            {
                var config = new MapperConfiguration(cfg => cfg.CreateMap<LtOutput0PartListLbp, LtOutput0PartListIj>());
                var mapper = config.CreateMapper();

                LtOutput0PartListModel result = new LtOutput0PartListModel()
                {
                    currentPage = parameters.Page,
                    recordPerPage = parameters.RecordsPerPage
                };

                IQueryable<LtOutput0PartListIj> query;
                if (product.ToUpper() == "IJ")
                {
                    query = context.LtOutput0PartListIjs.Where(x => x.Active == true).OrderBy(x => x.Model);
                }
                else
                {
                    var outputLbp = context.LtOutput0PartListLbps.Where(x => x.Active == true).OrderBy(x => x.Model);
                    query = outputLbp.ProjectTo<LtOutput0PartListIj>(mapper.ConfigurationProvider);
                }


                query = !string.IsNullOrEmpty(parameters.PartNo) ? query.Where(x => x.PartNo != null && x.PartNo.ToUpper().Contains(parameters.PartNo.ToUpper())) : query;
                query = !string.IsNullOrEmpty(parameters.Vendor) ? query.Where(x => x.Vendor != null && x.Vendor.ToUpper().Contains(parameters.Vendor.ToUpper())) : query;
                query = !string.IsNullOrEmpty(parameters.Ratio) ? query.Where(x => x.Ratio != null && x.Ratio.ToUpper().Contains(parameters.Ratio.ToUpper())) : query;
                query = !string.IsNullOrEmpty(parameters.Model) ? query.Where(x => x.Model != null && x.Model.ToUpper().Contains(parameters.Model.ToUpper())) : query;
                query = !string.IsNullOrEmpty(parameters.PartName) ? query.Where(x => x.PartName != null && x.PartName.ToUpper().Contains(parameters.PartName.ToUpper())) : query;
                query = !string.IsNullOrEmpty(parameters.LeadTime) ? query.Where(x => x.LeadTime != null && x.LeadTime.ToUpper().Contains(parameters.LeadTime.ToUpper())) : query;


                result.totalRecords = await query.CountAsync();
                result.totalPage = (int)Math.Ceiling((decimal)result.totalRecords / parameters.RecordsPerPage);
                var model = await query.Paginate(parameters).ToListAsync();
                result.lstModel = model;
                result.fromRecord = model.Count == 0 ? 0 : (result.currentPage - 1) * result.recordPerPage + 1;
                result.toRecord = (int)Math.Min(result.totalRecords, result.currentPage * result.recordPerPage);
                result.currentPage = result.totalPage < result.currentPage ? result.totalPage : result.currentPage;
                return result;
            }
            catch (Exception e)
            {
                //SendMailError(e);
                return new LtOutput0PartListModel()
                {
                    currentPage = parameters.Page,
                    recordPerPage = parameters.RecordsPerPage
                };
            }
        }

        //OP4 sử dụng chung với op2
      
        [HttpPost("filter-lt-output2-form-calc")]
        public async Task<LtOutput2FormCalcModel> FilterLtOutput2Calc(LtOutput2FormCalcParam parameters)
        {
            try
            {


                LtOutput2FormCalcModel result = new LtOutput2FormCalcModel()
                {
                    currentPage = parameters.Page,
                    recordPerPage = parameters.RecordsPerPage
                };

                var query = context.LtOp2Summaries.Where(x => x.Active == true);
                

                query = !string.IsNullOrEmpty(parameters.PartNo) ? query.Where(x => x.PartNo != null && x.PartNo.ToUpper().Contains(parameters.PartNo.ToUpper())) : query;
                query = !string.IsNullOrEmpty(parameters.Vendor) ? query.Where(x => x.Vendor != null && x.Vendor.ToUpper().Contains(parameters.Vendor.ToUpper())) : query;
                query = !string.IsNullOrEmpty(parameters.OrderMethod) ? query.Where(x => x.OrderMethod != null && x.OrderMethod.ToUpper().Contains(parameters.OrderMethod.ToUpper())) : query;
                query = !string.IsNullOrEmpty(parameters.Model) ? query.Where(x => x.Model != null && x.Model.ToUpper().Contains(parameters.Model.ToUpper())) : query;
                query = !string.IsNullOrEmpty(parameters.PartName) ? query.Where(x => x.PartName != null && x.PartName.ToUpper().Contains(parameters.PartName.ToUpper())) : query;
                query = !string.IsNullOrEmpty(parameters.KindOfPart) ? query.Where(x => x.KindOfPart != null && x.KindOfPart.ToUpper().Contains(parameters.KindOfPart.ToUpper())) : query;


                result.totalRecords = await query.CountAsync();
                result.totalPage = (int)Math.Ceiling((decimal)result.totalRecords / parameters.RecordsPerPage);
                var model = await query.Paginate(parameters).ToListAsync();
                result.lstModel = model;
                result.fromRecord = model.Count == 0 ? 0 : (result.currentPage - 1) * result.recordPerPage + 1;
                result.toRecord = (int)Math.Min(result.totalRecords, result.currentPage * result.recordPerPage);
                result.currentPage = result.totalPage < result.currentPage ? result.totalPage : result.currentPage;
                return result;
            }
            catch (Exception e)
            {
                //SendMailError(e);
                return new LtOutput2FormCalcModel()
                {
                    currentPage = parameters.Page,
                    recordPerPage = parameters.RecordsPerPage
                };
            }
        }

        [HttpPost("filter-lt-output5-summary")]
        public async Task<LtOutput5SummaryModel> FilterLtOutput5Summary(PaginationParams parameters)
        {
            try
            {


                LtOutput5SummaryModel result = new LtOutput5SummaryModel()
                {
                    currentPage = parameters.Page,
                    recordPerPage = parameters.RecordsPerPage
                };

                var model = await context.LtOp2Inquiries.Where(x => x.Active == true && (!string.IsNullOrEmpty(parameters.search) ? x.Model == parameters.search : x.Active == true)).ToListAsync();

                var lstAdd = new List<LtOp5SummaryView>();
                var lstModel =  model.OrderBy(x => x.Model).Select(x => x.Model).Distinct().ToList();
                foreach (var item in lstModel)
                {
                    

                    var it = model.Where(x => x.Model == item).ToList();
                    var pdc2Total = it.Any(x => x.Pdc2Total != null && x.Pdc2Total != 0) ? Math.Round((double)it.Where(x => x.Pdc2Total != null && x.Pdc2Total != 0).Average(x => double.IsInfinity((double)x.Pdc2Total) ? 500 : x.Pdc2Total), 2) : 0;
                    var pdc2Rec = it.Any(x => x.Pdc2Rec != null && x.Pdc2Rec != 0) ? Math.Round((double)it.Where(x => x.Pdc2Rec != null && x.Pdc2Rec != 0).Average(x => double.IsInfinity((double)x.Pdc2Rec) ? 500 : x.Pdc2Rec), 2):0;
                    var assyMain = it.Any(x => x.AssyMainTotal != null && x.AssyMainTotal != 0) ? Math.Round((double)it.Where(x => x.AssyMainTotal != null && x.AssyMainTotal != 0).Average(x => double.IsInfinity((double)x.AssyMainTotal) ? 500 : x.AssyMainTotal), 2) : 0;
                    var assyKitting = it.Any(x => x.AssyKittingTotal != null && x.AssyKittingTotal != 0) ? Math.Round((double)it.Where(x => x.AssyKittingTotal != null && x.AssyKittingTotal != 0).Average(x => double.IsInfinity((double)x.AssyKittingTotal) ? 500 : x.AssyKittingTotal), 2) : 0;
                    var assySubc = it.Any(x => x.AssySubcTotal != null && x.AssySubcTotal != 0) ? Math.Round((double)it.Where(x => x.AssySubcTotal != null && x.AssySubcTotal != 0).Average(x => double.IsInfinity((double)x.AssySubcTotal) ? 500 : x.AssySubcTotal), 2) : 0;
                    var assySilk = it.Any(x => x.AssySilkTotal != null && x.AssySilkTotal != 0) ? Math.Round((double)it.Where(x => x.AssySilkTotal != null && x.AssySilkTotal != 0).Average(x => double.IsInfinity((double)x.AssySilkTotal) ? 500 : x.AssySilkTotal), 2) : 0;
                    var assyMedia = it.Any(x => x.AssyMediaTotal != null && x.AssyMediaTotal != 0) ? Math.Round((double)it.Where(x => x.AssyMediaTotal != null && x.AssyMediaTotal != 0).Average(x => double.IsInfinity((double)x.AssyMediaTotal) ? 500 : x.AssyMediaTotal), 2) : 0;
                    var assyMip = it.Any(x => x.AssyMipTotal != null && x.AssyMipTotal != 0) ? Math.Round((double)it.Where(x => x.AssyMipTotal != null && x.AssyMipTotal != 0).Average(x => double.IsInfinity((double)x.AssyMipTotal) ? 500 : x.AssyMipTotal), 2) : 0;
                    var assyCounter = it.Any(x => x.AssyCounterTotal != null && x.AssyCounterTotal != 0) ? Math.Round((double)it.Where(x => x.AssyCounterTotal != null && x.AssyCounterTotal != 0).Average(x => double.IsInfinity((double)x.AssyCounterTotal) ? 500 : x.AssyCounterTotal), 2) : 0;
                    var assySubp = it.Any(x => x.AssySubpTotal != null && x.AssySubpTotal != 0) ? Math.Round((double)it.Where(x => x.AssySubpTotal != null && x.AssySubpTotal != 0).Average(x => double.IsInfinity((double)x.AssySubpTotal) ? 500 : x.AssySubpTotal), 2) : 0;
                    var iH = it.Any(x => x.IhTotal != null && x.IhTotal != 0) ? Math.Round((double)it.Where(x => x.IhTotal != null && x.IhTotal != 0).Average(x => double.IsInfinity((double)x.IhTotal) ? 500 : x.IhTotal), 2) : 0;
                    var other = it.Any(x => x.OtherTotal != null && x.OtherTotal != 0) ? Math.Round((double)it.Where(x => x.OtherTotal != null && x.OtherTotal != 0).Average(x => double.IsInfinity((double)x.OtherTotal) ? 500 : x.OtherTotal), 2) : 0;
                    var element = new LtOp5SummaryView()
                    {
                        
                        Model = item,
                        Pdc2Rec = pdc2Rec,
                        Pdc2Supply = Math.Round((double)it.Where(x => x.Pdc2Total != null && x.Pdc2Total != 0).Average(x => double.IsInfinity((double)x.Pdc2Total) ? 500 : x.Pdc2Total) - pdc2Rec, 2),
                        AssyMain = assyMain,
                        AssyKitting = assyKitting,
                        AssySubc =assySubc, 
                        AssySilk = assySilk,
                        AssyMedia = assyMedia,
                        AssyMip = assyMip,
                        AssyCounter = assyCounter,
                        AssySubp = assySubp,
                        Ih = iH,
                        Other = other
                    };
                    element.Total = Math.Round((double)(element.Pdc2Rec + element.Pdc2Supply + element.AssyMain + element.AssyKitting + element.AssySubc + element.AssySilk + element.AssyMedia +
                        element.AssyMip + element.AssyCounter + element.AssySubc + element.Ih + element.Other), 2);
                    lstAdd.Add(element);
                }

                result.totalRecords = lstAdd.Count();
                result.totalPage = (int)Math.Ceiling((decimal)result.totalRecords / parameters.RecordsPerPage);
                var lstResult =  lstAdd.Paginate(parameters).ToList();
                result.lstModel = lstResult;
                result.fromRecord = model.Count == 0 ? 0 : (result.currentPage - 1) * result.recordPerPage + 1;
                result.toRecord = (int)Math.Min(result.totalRecords, result.currentPage * result.recordPerPage);
                result.currentPage = result.totalPage < result.currentPage ? result.totalPage : result.currentPage;
                return result;
            }
            catch (Exception e)
            {
                //SendMailError(e);
                return new LtOutput5SummaryModel()
                {
                    currentPage = parameters.Page,
                    recordPerPage = parameters.RecordsPerPage
                };
            }
        }

        //OP4 sử dụng chung với op2
        [HttpPost("filter-lt-output4-inquiry")]
        public async Task<LtOutput4FormCalcModel> FilterLtOutput4Calc(LtOutput2FormCalcParam parameters)
        {
            try
            {

                LtOutput4FormCalcModel result = new LtOutput4FormCalcModel()
                {
                    currentPage = parameters.Page,
                    recordPerPage = parameters.RecordsPerPage
                };

                var query = context.LtOp2Inquiries.Where(x => x.Active == true);


                query = !string.IsNullOrEmpty(parameters.PartNo) ? query.Where(x => x.PartNo != null && x.PartNo.ToUpper().Contains(parameters.PartNo.ToUpper())) : query;
                query = !string.IsNullOrEmpty(parameters.Vendor) ? query.Where(x => x.Vendor != null && x.Vendor.ToUpper().Contains(parameters.Vendor.ToUpper())) : query;
                query = !string.IsNullOrEmpty(parameters.OrderMethod) ? query.Where(x => x.OrderMethod != null && x.OrderMethod.ToUpper().Contains(parameters.OrderMethod.ToUpper())) : query;
                query = !string.IsNullOrEmpty(parameters.Model) ? query.Where(x => x.Model != null && x.Model.ToUpper().Contains(parameters.Model.ToUpper())) : query;
                query = !string.IsNullOrEmpty(parameters.PartName) ? query.Where(x => x.PartName != null && x.PartName.ToUpper().Contains(parameters.PartName.ToUpper())) : query;
                query = !string.IsNullOrEmpty(parameters.KindOfPart) ? query.Where(x => x.KindOfPart != null && x.KindOfPart.ToUpper().Contains(parameters.KindOfPart.ToUpper())) : query;


                result.totalRecords = await query.CountAsync();
                result.totalPage = (int)Math.Ceiling((decimal)result.totalRecords / parameters.RecordsPerPage);
                var model = await query.Paginate(parameters).ToListAsync();
              
                result.lstModel = model;
                result.fromRecord = model.Count == 0 ? 0 : (result.currentPage - 1) * result.recordPerPage + 1;
                result.toRecord = (int)Math.Min(result.totalRecords, result.currentPage * result.recordPerPage);
                result.currentPage = result.totalPage < result.currentPage ? result.totalPage : result.currentPage;
                return result;
            }
            catch (Exception e)
            {
                //SendMailError(e);
                return new LtOutput4FormCalcModel()
                {
                    currentPage = parameters.Page,
                    recordPerPage = parameters.RecordsPerPage
                };
            }
        }
        #endregion


        #region filter inquiry item
        [HttpPost("get-item-inquiry-pdc2/{status}")]
        public async Task<LtFormRegistrationPdc2Model> GetItemInquiryPdc2(PaginationParams param,string status)
        {
            try
            {
                try
                {

                    LtFormRegistrationPdc2Model result = new LtFormRegistrationPdc2Model()
                    {
                        currentPage = param.Page,
                        recordPerPage = param.RecordsPerPage
                    };
                    var statusAppr = status == "Approved" ? 1 : (status == "Checking" ? 0 : 2);
                    var lstRequest = context.LtFormRegistrationPdc2Infors.Where(x => x.Active == true && x.Status != null && x.Status  == statusAppr).Select(y => y.RequestNo).ToList();
                    var query = context.LtFormRegistrationPdc2Items.Where(x => x.Active == true && lstRequest.Contains(x.RequestNo) && (x.ApprovedStatus== 1 || x.ApprovedStatus == 0)).OrderByDescending(x => x.RequestEffectiveDate);

                    query = !string.IsNullOrEmpty(param.search) ? query.Where(x =>x.PartNo.ToUpper().Contains(param.search.ToUpper())).OrderByDescending(x => x.RequestEffectiveDate) : query;
                    result.totalRecords = await query.CountAsync();
                    result.totalPage = (int)Math.Ceiling((decimal)result.totalRecords / param.RecordsPerPage);
                    var model = await query.Paginate(param).ToListAsync();
                    result.lstModel = model;
                    result.fromRecord = model.Count == 0 ? 0 : (result.currentPage - 1) * result.recordPerPage + 1;
                    result.toRecord = (int)Math.Min(result.totalRecords, result.currentPage * result.recordPerPage);
                    result.currentPage = result.totalPage < result.currentPage ? result.totalPage : result.currentPage;
                    return result;
                }
                catch (Exception e)
                {
                    //SendMailError(e);
                    return new LtFormRegistrationPdc2Model()
                    {
                        currentPage = param.Page,
                        recordPerPage = param.RecordsPerPage
                    };
                }
            }
            catch (Exception)
            {
                return new LtFormRegistrationPdc2Model(); ;
            }
        }

        [HttpPost("get-item-inquiry-log/{status}")]
        public async Task<LtFormRegistrationLogModel> GetItemInquiryLog(PaginationParams param, string status)
        {
            try
            {
                try
                {

                    LtFormRegistrationLogModel result = new LtFormRegistrationLogModel()
                    {
                        currentPage = param.Page,
                        recordPerPage = param.RecordsPerPage
                    };
                    var statusAppr = status == "Approved" ? 1 : (status == "Checking" ? 0 : 2);
                    var lstRequest = context.LtFormRegistrationLogInfors.Where(x => x.Active == true && x.Status != null && x.Status == statusAppr).Select(y => y.RequestNo).ToList();
                    var query = context.LtFormRegistrationLogItems.Where(x => x.Active == true && lstRequest.Contains(x.RequestNo) && (x.ApprovedStatus == 1 || x.ApprovedStatus == 0)).OrderByDescending(x => x.RequestEffectiveDate);

                    query = !string.IsNullOrEmpty(param.search) ? query.Where(x => x.PartNo.ToUpper().Contains(param.search.ToUpper())).OrderByDescending(x => x.RequestEffectiveDate) : query;
                    
                    result.totalRecords = await query.CountAsync();
                    result.totalPage = (int)Math.Ceiling((decimal)result.totalRecords / param.RecordsPerPage);
                    var model = await query.Paginate(param).ToListAsync();
                    result.lstModel = model;
                    result.fromRecord = model.Count == 0 ? 0 : (result.currentPage - 1) * result.recordPerPage + 1;
                    result.toRecord = (int)Math.Min(result.totalRecords, result.currentPage * result.recordPerPage);
                    result.currentPage = result.totalPage < result.currentPage ? result.totalPage : result.currentPage;
                    return result;
                }
                catch (Exception e)
                {
                    //SendMailError(e);
                    return new LtFormRegistrationLogModel()
                    {
                        currentPage = param.Page,
                        recordPerPage = param.RecordsPerPage
                    };
                }
            }
            catch (Exception)
            {
                return new LtFormRegistrationLogModel(); ;
            }
        }

        [HttpPost("get-item-inquiry-assy/{status}")]
        public async Task<LtFormRegistrationAssyModel> GetItemInquiryAssy(PaginationParams param, string status)
        {
            try
            {
                try
                {

                    LtFormRegistrationAssyModel result = new LtFormRegistrationAssyModel()
                    {
                        currentPage = param.Page,
                        recordPerPage = param.RecordsPerPage
                    };
                    var statusAppr = status == "Approved" ? 1 : (status == "Checking" ? 0 : 2);
                    var lstRequest = context.LtFormRegistrationAssyInfors.Where(x => x.Active == true && x.Status != null && x.Status == statusAppr).Select(y => y.RequestNo).ToList();
                    var query = context.LtFormRegistrationAssyItems.Where(x => x.Active == true && lstRequest.Contains(x.RequestNo) && (x.ApprovedStatus == 1 || x.ApprovedStatus == 0)).OrderByDescending(x => x.RequestEffectiveDate);

                    query = !string.IsNullOrEmpty(param.search) ? query.Where(x => x.PartNo.ToUpper().Contains(param.search.ToUpper())).OrderByDescending(x => x.RequestEffectiveDate) : query;
                    result.totalRecords = await query.CountAsync();
                    result.totalPage = (int)Math.Ceiling((decimal)result.totalRecords / param.RecordsPerPage);
                    var model = await query.Paginate(param).ToListAsync();
                    result.lstModel = model;
                    result.fromRecord = model.Count == 0 ? 0 : (result.currentPage - 1) * result.recordPerPage + 1;
                    result.toRecord = (int)Math.Min(result.totalRecords, result.currentPage * result.recordPerPage);
                    result.currentPage = result.totalPage < result.currentPage ? result.totalPage : result.currentPage;
                    return result;
                }
                catch (Exception e)
                {
                    //SendMailError(e);
                    return new LtFormRegistrationAssyModel()
                    {
                        currentPage = param.Page,
                        recordPerPage = param.RecordsPerPage
                    };
                }
            }
            catch (Exception)
            {
                return new LtFormRegistrationAssyModel(); ;
            }
        }


        [HttpPost("get-item-inquiry-ih/{status}")]
        public async Task<LtFormRegistrationIhModel> GetItemInquiryIh(PaginationParams param, string status)
        {
            try
            {
                try
                {

                    LtFormRegistrationIhModel result = new LtFormRegistrationIhModel()
                    {
                        currentPage = param.Page,
                        recordPerPage = param.RecordsPerPage
                    };
                    var statusAppr = status == "Approved" ? 1 : (status == "Checking" ? 0 : 2);
                    var lstRequest = context.LtFormRegistrationIhInfors.Where(x => x.Active == true && x.Status != null && x.Status == statusAppr).Select(y => y.RequestNo).ToList();
                    var query = context.LtFormRegistrationIhItems.Where(x => x.Active == true && lstRequest.Contains(x.RequestNo) && (x.ApprovedStatus == 1 || x.ApprovedStatus == 0)).OrderByDescending(x => x.RequestEffectiveDate);

                    query = !string.IsNullOrEmpty(param.search) ? query.Where(x => x.PartNo.ToUpper().Contains(param.search.ToUpper())).OrderByDescending(x => x.RequestEffectiveDate) : query;
                    result.totalRecords = await query.CountAsync();
                    result.totalPage = (int)Math.Ceiling((decimal)result.totalRecords / param.RecordsPerPage);
                    var model = await query.Paginate(param).ToListAsync();
                    result.lstModel = model;
                    result.fromRecord = model.Count == 0 ? 0 : (result.currentPage - 1) * result.recordPerPage + 1;
                    result.toRecord = (int)Math.Min(result.totalRecords, result.currentPage * result.recordPerPage);
                    result.currentPage = result.totalPage < result.currentPage ? result.totalPage : result.currentPage;
                    return result;
                }
                catch (Exception e)
                {
                    //SendMailError(e);
                    return new LtFormRegistrationIhModel()
                    {
                        currentPage = param.Page,
                        recordPerPage = param.RecordsPerPage
                    };
                }
            }
            catch (Exception)
            {
                return new LtFormRegistrationIhModel(); ;
            }
        }

        #endregion
        #region changing
        //get all date of file
        [HttpGet("get-list-date-file-changing-lt")]
        public List<string> GetListDateOfFileChangingLT()
        {
            string folderPath = this.outputPathOri + "\\4. Leadtime\\OP4.LT Changing";
            // Lấy danh sách các file trong thư mục
            string[] files = Directory.GetFiles(folderPath);

            // Lấy danh sách ngày tạo của các file
            var fileDates = files.OrderByDescending(x => new FileInfo(x).CreationTime).Select(file => new FileInfo(file).CreationTime.ToString("yyyy-MM-dd")).Distinct().ToList();

            return fileDates;
        }

        [HttpGet("get-file-changing-lt/{date}")]
        public List<string> GetFileChangingLT(string date)
        {
            string folderPath = this.outputPathOri + "\\4. Leadtime\\OP4.LT Changing";


            string[] files = Directory.GetFiles(folderPath, "OP4.Changing Inquiry_*_" + date + ".xlsx");

            return files.Reverse().ToList();
        }
        #endregion

        #region private function
        private bool SendMailError(Exception e)
        {
            try
            {
                string txtContent = "<p>Message: " + e.Message + "</p><br>" +
                "<p>Data: " + e.Data.ToString() + "</p><br>" +
                "<p>StackTrace: " + e.StackTrace + "</p><br>" +
                "<p>HelpLink: " + e.HelpLink ?? "" + "</p><br>" +
                "<p>Source: " + e.Source ?? "" + "</p><br>";
                email.InitialDev(
                    "Error exception",
                    txtContent);
                return false;
            }
            catch
            {
                return false;
            }
        }
        private UserClaims GetCurrentUser()
        {
            UserClaims userClaims = new UserClaims();
            var identity = HttpContext.User.Identity as ClaimsIdentity;
            if (identity != null)
            {
                userClaims.UserName = identity.FindFirst("user_name") == null ? "Undefined" : identity.FindFirst("user_name").Value;
                userClaims.Id = identity.FindFirst("id") == null ? "Undefined" : identity.FindFirst("id").Value;
                //userClaims.IsIt = identity.FindFirst("isIt") == null ? "0" : identity.FindFirst("isIt").Value;
                userClaims.Departments = identity.FindFirst("deptIds") == null ? "" : identity.FindFirst("deptIds").Value;
                userClaims.Factories = identity.FindFirst("factIds") == null ? "" : identity.FindFirst("factIds").Value;
                userClaims.CostCenter = identity.FindFirst("cost_center") == null ? "" : identity.FindFirst("cost_center").Value;
                userClaims.FullName = identity.FindFirst("full_name") == null ? "" : identity.FindFirst("full_name").Value;
                userClaims.Departments = identity.FindFirst("dept") == null ? "" : identity.FindFirst("dept").Value;
                userClaims.Grade = identity.FindFirst("grade") == null ? "" : identity.FindFirst("grade").Value;
                userClaims.IsAdmin = identity.FindFirst("isAdmin") == null ? "false" : identity.FindFirst("isAdmin").Value;

            }
            return userClaims;
        }
        #endregion

    }
}
