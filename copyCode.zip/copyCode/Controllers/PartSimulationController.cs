﻿
using AutoMapper;
using AutoMapper.QueryableExtensions;
using DocumentFormat.OpenXml.Office.CustomUI;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Newtonsoft.Json;
using OfficeOpenXml;
using PDCProjectApi.Common;
using PDCProjectApi.Common.Function;
using PDCProjectApi.Common.Job;
using PDCProjectApi.Data;
using PDCProjectApi.Helper;
using PDCProjectApi.Model.Request;
using PDCProjectApi.Model.Response;
using PDCProjectApi.Model.View;
using PDCProjectApi.Services;
using System;
using System.Net;
using System.Security.Claims;
using System.Text.RegularExpressions;

namespace PDCProjectApi.Controllers
{
    [Route("api/partSimulation")]
    [ApiController]

    public class PartSimulationController : ControllerBase, IDisposable
    {
        private readonly IEmailService _email;
        private readonly PdcsystemContext context;
        private string outputPathOri = "";
        private readonly IGlobalVariable global;
        private readonly List<string> lstMailReceive = new List<string>() { };
        public PartSimulationController(IEmailService email, PdcsystemContext ctx, IGlobalVariable gl)
        {
            _email = email;
            context = ctx;
            this.global = gl;
            this.outputPathOri = this.global.ReturnPathOutput();
            this.lstMailReceive = this.global.ReturnPDCMail();
        }

        private bool disposed = false;
        protected virtual void Dispose(bool disposing)
        {
            if (!disposed)
            {
                if (disposing)
                {
                    if (context != null)
                    {
                        context.DisposeAsync();
                    }

                }
                disposed = true;
            }
        }
        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }
        ~PartSimulationController() { Dispose(false); }


        #region pp change
        [HttpPost("filter-simulation-pp-change")]
        public async Task<PartSMLPPChangeModel> FilterSimulationPPChange(PcSimulationPPChangeParam parameters)
        {
            try
            {
                PartSMLPPChangeModel result = new PartSMLPPChangeModel()
                {
                    currentPage = parameters.Page,
                    recordPerPage = parameters.RecordsPerPage
                };
                DateOnly? fromDate = parameters.FromDate.StringToDateAble();
                DateOnly? toDate = parameters.ToDate.StringToDateAble();

                var query = context.PcSimulationMasterPpChanges.Where(x => x.Active == true && x.Product.ToUpper() == parameters.Product);
                query = !string.IsNullOrEmpty(parameters.Model) ? query.Where(x => x.Model != null && x.Model.ToUpper().Contains(parameters.Model.ToUpper())) : query;
                query = !string.IsNullOrEmpty(parameters.LineNo) ? query.Where(x => x.LineNo != null && x.LineNo.ToUpper().Contains(parameters.LineNo.ToUpper())) : query;
                query = !string.IsNullOrEmpty(parameters.Merchandise) ? query.Where(x => x.Merchandise != null && x.Merchandise.ToUpper().Contains(parameters.Merchandise.ToUpper())) : query;
                query = !string.IsNullOrEmpty(parameters.Qty) ? query.Where(x => x.AdjQty != null && x.AdjQty == parameters.Qty.StringAbleToDouble()) : query;
                query = !string.IsNullOrEmpty(parameters.Shift) ? query.Where(x => x.Shift != null && x.Shift.ToUpper().Contains(parameters.Shift.ToUpper())) : query;
                query = !string.IsNullOrEmpty(parameters.FromDate) ? query.Where(x => x.FromDate != null && DateOnly.FromDateTime(x.FromDate) >= fromDate) : query;
                query = !string.IsNullOrEmpty(parameters.ToDate) ? query.Where(x => x.ToDate != null && DateOnly.FromDateTime(x.ToDate) <= toDate) : query;
                result.totalRecords = await query.CountAsync();
                result.totalPage = (int)Math.Ceiling((decimal)result.totalRecords / parameters.RecordsPerPage);
                var model = await query.OrderByDescending(x => x.CreatedDate).Paginate(parameters).ToListAsync();

                result.lstModel = model;
                result.fromRecord = model.Count == 0 ? 0 : (result.currentPage - 1) * result.recordPerPage + 1;
                result.toRecord = (int)Math.Min(result.totalRecords, result.currentPage * result.recordPerPage);
                result.currentPage = result.totalPage < result.currentPage ? result.totalPage : result.currentPage;
                return result;
            }
            catch (Exception e)
            {
                //SendMailError(e);
                return new PartSMLPPChangeModel()
                {
                    currentPage = parameters.Page,
                    recordPerPage = parameters.RecordsPerPage
                };
            }
        }
        [HttpPost("add-simulation-pp-change")]
        public async Task<CommonResponse> AddSimulationPPChange([FromBody] PartSMLMasterPPChangeRequest rq)
        {
            CommonResponse res = new CommonResponse()
            {
                Error = true,
                Message = "Can't add new master",
                Status = 400
            };

            try
            {
                DateTime from = DateTime.Parse(rq.FromDate);
                DateTime to = DateTime.Parse(rq.ToDate);
                var u = GetCurrentUser();

                var add = new PcSimulationMasterPpChange()
                {
                    Model = rq.Model,
                    Merchandise = rq.Merchandise,
                    LineNo = rq.LineNo,
                    AdjQty = rq.Qty,
                    Shift = rq.Shift,
                    FromDate = from,
                    ToDate = to,
                    Reason = rq.Reason,
                    Step = rq.Step,
                    CreatedBy = u.UserName,
                    CreatedDate = DateTime.Now.SetKindUtc(),
                    Product = rq.Product
                };
                context.Add(add);
                context.SaveChanges();
                res.Status = 200;
                res.Message = "Sucessful !";
                res.Error = true;
            }
            catch (Exception e)
            {
                //SendMailError(e);
                res.Message = e.Message;
                res.Error = true;
                res.Status = 400;
            }
            return res;
        }

        [HttpPost("edit-simulation-pp-change/{id}")]
        public async Task<CommonResponse> EditSimulationPPChange([FromBody] PartSMLMasterPPChangeRequest rq, Guid id)
        {
            CommonResponse res = new CommonResponse()
            {
                Error = true,
                Message = "Can't add new master",
                Status = 400
            };

            try
            {
                DateTime from = DateTime.Parse(rq.FromDate);
                DateTime to = DateTime.Parse(rq.ToDate);
                var u = GetCurrentUser();
                var model = context.PcSimulationMasterPpChanges.FirstOrDefault(x => x.Active == true && x.Id == id);
                if (model != null)
                {

                    model.Model = rq.Model;
                    model.Merchandise = rq.Merchandise;
                    model.LineNo = rq.LineNo;
                    model.AdjQty = rq.Qty;
                    model.Shift = rq.Shift;
                    model.FromDate = from;
                    model.ToDate = to;
                    model.Reason = rq.Reason;
                    model.Step = rq.Step;
                    model.ModifiedBy = u.UserName;
                    model.ModifiedDate = DateTime.Now.SetKindUtc();
                    model.ApprovedBy = null;
                    model.ApprovedDate = null;
                    model.Product = rq.Product;
                }
                context.Update(model);
                context.SaveChanges();

                res.Status = 200;
                res.Message = "Sucessful !";
                res.Error = true;
            }
            catch (Exception e)
            {
                //SendMailError(e);
                res.Message = e.Message;
                res.Error = true;
                res.Status = 400;
            }
            return res;
        }

        [HttpGet("active-simulation-pp-change/{id}")]
        public async Task<CommonResponse> ActiveSimulationPPChange(Guid id)
        {
            CommonResponse res = new CommonResponse()
            {
                Error = true,
                Message = "Can't add new master",
                Status = 400
            };

            try
            {

                var u = GetCurrentUser();
                var model = context.PcSimulationMasterPpChanges.FirstOrDefault(x => x.Active == true && x.Id == id);
                if (model != null)
                {
                    model.Active = false;
                    model.ModifiedBy = u.UserName;
                    model.ModifiedDate = DateTime.Now.SetKindUtc();

                }
                context.Update(model);
                context.SaveChanges();

                res.Status = 200;
                res.Message = "Sucessful !";
                res.Error = true;
            }
            catch (Exception e)
            {
                //SendMailError(e);
                res.Message = e.Message;
                res.Error = true;
                res.Status = 400;
            }
            return res;
        }

        [HttpGet("approve-sml-pp-change/{product}")]
        public async Task<CommonResponse> ApproveSMLPPChange(string product)
        {
            CommonResponse res = new CommonResponse()
            {
                Error = false,
                Message = "",
                Status = (int)HttpStatusCode.BadRequest
            };
            try
            {

                var u = GetCurrentUser();

                //tìm những con cũ dựa vào key những con mới
                var model = await context.PcSimulationMasterPpChanges
                    .Where(x => x.Active == true && x.ApprovedDate == null && x.Product == product)
                    .ToListAsync();

                var ppChange = context.PcSimulationMasterPpChanges
                    .Where(x => x.Active == true && x.ApprovedDate != null && x.Product == product).ToList();
                ppChange.ForEach(x => {
                    x.Active = false;
                    x.ModifiedBy = u.UserName;
                });
                //List<PcSimulationMasterDoChangeTime> lstDel = new List<PcSimulationMasterDoChangeTime>();
                model.ForEach(x =>
                {
                    x.ApprovedBy = u.UserName;
                    x.ApprovedDate = DateTime.Now;
                });


                context.UpdateRange(ppChange);
                context.UpdateRange(model);
                context.SaveChanges();

                res.Error = false;
                res.Message = "Successfully !";
                res.Status = (int)HttpStatusCode.OK;
                return res;
            }
            catch (Exception e)
            {
                res.Error = true;
                res.Message = e.Message;
                res.Status = (int)HttpStatusCode.BadRequest;
                //SendMailError(e);
                return res;
            }


        }

        [HttpGet("reject-sml-pp-change/{product}")]
        public async Task<CommonResponse> RejectSMLPPChange(string product)
        {
            CommonResponse res = new CommonResponse()
            {
                Error = false,
                Message = "",
                Status = (int)HttpStatusCode.BadRequest
            };
            try
            {

                var u = GetCurrentUser();

                var model = await context.PcSimulationMasterPpChanges
                    .Where(x => x.Active == true && x.ApprovedDate == null && x.Product == product)
                    .ToListAsync();

                model.ForEach(x =>
                {
                    x.Active = false;
                    x.ApprovedBy = u.UserName;
                    x.ApprovedDate = DateTime.Now;
                });

                context.UpdateRange(model);
                context.SaveChanges();

                res.Error = false;
                res.Message = "Successfully !";
                res.Status = (int)HttpStatusCode.OK;
                return res;
            }
            catch (Exception e)
            {
                res.Error = true;
                res.Message = e.Message;
                res.Status = (int)HttpStatusCode.BadRequest;
                //SendMailError(e);
                return res;
            }


        }
        #endregion
        #region do change
        [HttpPost("filter-simulation-do-change")]
        public async Task<PartSMLDoChangeModel> FilterSimulationDoChange(PcSimulationDoChangeParam parameters)
        {
            try
            {
                PartSMLDoChangeModel result = new PartSMLDoChangeModel()
                {
                    currentPage = parameters.Page,
                    recordPerPage = parameters.RecordsPerPage
                };
                DateOnly? delvDate = parameters.DelvDate.StringToDateAble();


                var query = context.PcSimulationMasterDoChangeTimes.Where(x => x.Active == true && x.Product.ToUpper() == parameters.Product);
                query = !string.IsNullOrEmpty(parameters.Bc) ? query.Where(x => x.Bc != null && x.Bc.ToUpper().Contains(parameters.Bc.ToUpper())) : query;
                query = !string.IsNullOrEmpty(parameters.PartNo) ? query.Where(x => x.PartNo != null && x.PartNo.ToUpper().Contains(parameters.PartNo.ToUpper())) : query;
                query = !string.IsNullOrEmpty(parameters.Vendor) ? query.Where(x => x.Vendor != null && x.Vendor.ToUpper().Contains(parameters.Vendor.ToUpper())) : query;
                query = !string.IsNullOrEmpty(parameters.AdjQty) ? query.Where(x => x.AdjQty != null && x.AdjQty == parameters.AdjQty.StringAbleToDouble()) : query;
                query = !string.IsNullOrEmpty(parameters.DelvDate) ? query.Where(x => x.DeliveryDate != null && x.DeliveryDate == delvDate) : query;
                query = !string.IsNullOrEmpty(parameters.DelvTime) ? query.Where(x => x.DeliveryTime != null && x.DeliveryTime.ToUpper().Contains(parameters.DelvTime.ToUpper())) : query;

                result.totalRecords = await query.CountAsync();
                result.totalPage = (int)Math.Ceiling((decimal)result.totalRecords / parameters.RecordsPerPage);
                var model = await query.Select(x => new PcSimulationMasterDoChangeTimeView
                {
                    Id = x.Id,
                    Bc = x.Bc,
                    PartNo = x.PartNo,
                    Vendor = x.Vendor,
                    AdjQty = x.AdjQty,
                    DeliveryDate = x.DeliveryDate.ToString(),
                    DeliveryTime = x.DeliveryTime,
                    ApprovedDate = x.ApprovedDate == null ? null : x.ApprovedDate.Value.ToString("yyyy-MM-dd"),
                    ApprovedBy = x.ApprovedBy,
                    CreatedDate = x.CreatedDate
                }).OrderByDescending(x => x.CreatedDate).Paginate(parameters).ToListAsync();

                result.lstModel = model;
                result.fromRecord = model.Count == 0 ? 0 : (result.currentPage - 1) * result.recordPerPage + 1;
                result.toRecord = (int)Math.Min(result.totalRecords, result.currentPage * result.recordPerPage);
                result.currentPage = result.totalPage < result.currentPage ? result.totalPage : result.currentPage;
                return result;
            }
            catch (Exception e)
            {
                //SendMailError(e);
                return new PartSMLDoChangeModel()
                {
                    currentPage = parameters.Page,
                    recordPerPage = parameters.RecordsPerPage
                };
            }
        }
        [HttpPost("add-simulation-do-change")]
        public async Task<CommonResponse> AddSimulationDoChange([FromBody] PartSMLMasterDoChangeRequest rq)
        {
            CommonResponse res = new CommonResponse()
            {
                Error = true,
                Message = "Can't add new master",
                Status = 400
            };

            try
            {

                DateOnly delvDate = DateOnly.Parse(rq.DelvDate);
                var u = GetCurrentUser();

                var add = new PcSimulationMasterDoChangeTime()
                {
                    Bc = rq.Bc,
                    PartNo = rq.PartNo,
                    Vendor = rq.Vendor,
                    AdjQty = rq.AdjQty,
                    DeliveryDate = delvDate,
                    DeliveryTime = rq.DelvTime,
                    Product = rq.Product,
                    CreatedBy = u.UserName,
                    CreatedDate = DateTime.Now.SetKindUtc()
                };
                context.Add(add);
                context.SaveChanges();
                res.Status = 200;
                res.Message = "Sucessful !";
                res.Error = true;
            }
            catch (Exception e)
            {
                //SendMailError(e);
                res.Message = e.Message;
                res.Error = true;
                res.Status = 400;
            }
            return res;
        }

        [HttpPost("edit-simulation-do-change/{id}")]
        public async Task<CommonResponse> EditSimulationDoChange([FromBody] PartSMLMasterDoChangeRequest rq, Guid id)
        {
            CommonResponse res = new CommonResponse()
            {
                Error = true,
                Message = "Can't add new master",
                Status = 400
            };

            try
            {
                DateOnly delvDate = DateOnly.Parse(rq.DelvDate);

                var u = GetCurrentUser();
                var model = context.PcSimulationMasterDoChangeTimes.FirstOrDefault(x => x.Active == true && x.Id == id);
                if (model != null)
                {

                    model.Bc = rq.Bc;
                    model.PartNo = rq.PartNo;
                    model.Vendor = rq.Vendor;
                    model.AdjQty = rq.AdjQty;
                    model.DeliveryDate = (DateOnly)delvDate;
                    model.DeliveryTime = rq.DelvTime;
                    model.Product = rq.Product;
                    model.ModifiedBy = u.UserName;
                    model.ModifiedDate = DateTime.Now.SetKindUtc();
                    model.ApprovedBy = null;
                    model.ApprovedDate = null;
                }
                context.Update(model);
                context.SaveChanges();

                res.Status = 200;
                res.Message = "Sucessful !";
                res.Error = true;
            }
            catch (Exception e)
            {
                //SendMailError(e);
                res.Message = e.Message;
                res.Error = true;
                res.Status = 400;
            }
            return res;
        }

        [HttpGet("active-simulation-do-change/{id}")]
        public async Task<CommonResponse> ActiveSimulationDoChange(Guid id)
        {
            CommonResponse res = new CommonResponse()
            {
                Error = true,
                Message = "Can't add new master",
                Status = 400
            };

            try
            {

                var u = GetCurrentUser();
                var model = context.PcSimulationMasterDoChangeTimes.FirstOrDefault(x => x.Active == true && x.Id == id);
                if (model != null)
                {
                    model.Active = false;
                    model.ModifiedBy = u.UserName;
                    model.ModifiedDate = DateTime.Now.SetKindUtc();

                }
                context.Update(model);
                context.SaveChanges();

                res.Status = 200;
                res.Message = "Sucessful !";
                res.Error = true;
            }
            catch (Exception e)
            {
                //SendMailError(e);
                res.Message = e.Message;
                res.Error = true;
                res.Status = 400;
            }
            return res;
        }

        [HttpGet("approve-sml-do-change/{product}")]
        public async Task<CommonResponse> ApproveSMLDoChange(string product)
        {
            CommonResponse res = new CommonResponse()
            {
                Error = false,
                Message = "",
                Status = (int)HttpStatusCode.BadRequest
            };
            try
            {

                var u = GetCurrentUser();

                //tìm những con cũ dựa vào key những con mới
                var model = await context.PcSimulationMasterDoChangeTimes
                    .Where(x => x.Active == true && x.ApprovedDate == null && x.Product == product)
                    .ToListAsync();

                var doChange = context.PcSimulationMasterDoChangeTimes
                    .Where(x => x.Active == true && x.ApprovedDate != null && x.Product == product).ToList();
                doChange.ForEach(x => { 
                    x.Active = false;
                    x.ModifiedBy = u.UserName;
                });
                //List<PcSimulationMasterDoChangeTime> lstDel = new List<PcSimulationMasterDoChangeTime>();
                model.ForEach(x =>
                {
                    x.ApprovedBy = u.UserName;
                    x.ApprovedDate = DateTime.Now;
                });


                context.UpdateRange(doChange);
                context.UpdateRange(model);
                context.SaveChanges();

                res.Error = false;
                res.Message = "Successfully !";
                res.Status = (int)HttpStatusCode.OK;
                return res;
            }
            catch (Exception e)
            {
                res.Error = true;
                res.Message = e.Message;
                res.Status = (int)HttpStatusCode.BadRequest;
                // SendMailError(e);
                return res;
            }


        }
        [HttpGet("reject-sml-do-change/{product}")]
        public async Task<CommonResponse> RejectSMLDoChange(string product)
        {
            CommonResponse res = new CommonResponse()
            {
                Error = false,
                Message = "",
                Status = (int)HttpStatusCode.BadRequest
            };
            try
            {

                var u = GetCurrentUser();

                var model = await context.PcSimulationMasterDoChangeTimes
                    .Where(x => x.Active == true && x.ApprovedDate == null && x.Product == product)
                    .ToListAsync();

                
                model.ForEach(x =>
                {
                    x.Active = false;
                    x.ApprovedBy = u.UserName;
                    x.ApprovedDate = DateTime.Now;
                });


                context.UpdateRange(model);
                context.SaveChanges();

                res.Error = false;
                res.Message = "Successfully !";
                res.Status = (int)HttpStatusCode.OK;
                return res;
            }
            catch (Exception e)
            {
                res.Error = true;
                res.Message = e.Message;
                res.Status = (int)HttpStatusCode.BadRequest;
                // SendMailError(e);
                return res;
            }


        }
        #endregion
        #region time table
        [HttpPost("filter-simulation-time-table")]
        public async Task<PartSMLTimeTableModel> FilterSimulationTimeTable(PcSimulationTimeTableParam parameters)
        {
            try
            {
                PartSMLTimeTableModel result = new PartSMLTimeTableModel()
                {
                    currentPage = parameters.Page,
                    recordPerPage = parameters.RecordsPerPage
                };

                var query = context.PcSimulationMasterTimetableDeliveries.Where(x => x.Active == true);
                query = !string.IsNullOrEmpty(parameters.Route) ? query.Where(x => x.Route != null && x.Route.ToUpper().Contains(parameters.Route.ToUpper())) : query;
                query = !string.IsNullOrEmpty(parameters.Gate) ? query.Where(x => x.Gate != null && x.Gate.ToUpper().Contains(parameters.Gate.ToUpper())) : query;
                query = !string.IsNullOrEmpty(parameters.Vendor) ? query.Where(x => x.Vendor != null && x.Vendor.ToUpper().Contains(parameters.Vendor.ToUpper())) : query;
                query = !string.IsNullOrEmpty(parameters.LotNo) ? query.Where(x => x.LotNo != null && x.LotNo.ToUpper().Contains(parameters.LotNo.ToUpper())) : query;
                query = !string.IsNullOrEmpty(parameters.Eta) ? query.Where(x => x.Eta != null && x.Eta.ToUpper().Contains(parameters.Eta.ToUpper())) : query;
                query = !string.IsNullOrEmpty(parameters.Shift) ? query.Where(x => x.Shift != null && x.Shift.ToUpper().Contains(parameters.Shift.ToUpper())) : query;
                query = !string.IsNullOrEmpty(parameters.Product) ? query.Where(x => x.Product != null && x.Product.ToUpper().Contains(parameters.Product.ToUpper())) : query;


                result.totalRecords = await query.CountAsync();
                result.totalPage = (int)Math.Ceiling((decimal)result.totalRecords / parameters.RecordsPerPage);
                var model = await query.OrderByDescending(x => x.CreatedDate).Paginate(parameters).ToListAsync();
                var lstResult = new List<PartSMLTimeTableView>();
                foreach (var item in model)
                {
                    lstResult.Add(new PartSMLTimeTableView
                    {
                        Route = item.Route,
                        Gate = item.Gate,
                        Vendor = item.Vendor,
                        LotNo = item.LotNo,
                        Eta = item.Eta,
                        Shift = item.Shift,
                        Product = item.Product,
                        ApprovedDate = item.ApprovedDate,
                        ApprovedBy = item.ApprovedBy,
                        FromDate = item.FromDate?.ToString("yyyy-MM-dd"),
                        ToDate = item.FromDate?.ToString("yyyy-MM-dd"),
                        Status = item.Status,
                        Bc = item.Bc
                    });
                }
                result.lstModel = lstResult;
                result.fromRecord = model.Count == 0 ? 0 : (result.currentPage - 1) * result.recordPerPage + 1;
                result.toRecord = (int)Math.Min(result.totalRecords, result.currentPage * result.recordPerPage);
                result.currentPage = result.totalPage < result.currentPage ? result.totalPage : result.currentPage;
                return result;
            }
            catch (Exception e)
            {
                //SendMailError(e);
                return new PartSMLTimeTableModel()
                {
                    currentPage = parameters.Page,
                    recordPerPage = parameters.RecordsPerPage
                };
            }
        }
        [HttpPost("add-simulation-time-table")]
        public async Task<CommonResponse> AddSimulationTimeTable([FromBody] PartSMLMasterTimeTableRequest rq)
        {
            CommonResponse res = new CommonResponse()
            {
                Error = true,
                Message = "Can't add new master",
                Status = 400
            };

            try
            {


                var u = GetCurrentUser();

                var add = new PcSimulationMasterTimetableDelivery()
                {
                    Route = rq.Route,
                    Gate = rq.Gate,
                    Vendor = rq.Vendor,
                    LotNo = rq.LotNo,
                    Eta = rq.Eta,
                    Shift = rq.Shift,
                    Product = rq.Product,
                    CreatedBy = u.UserName,
                    CreatedDate = DateTime.Now.SetKindUtc()
                };
                context.Add(add);
                context.SaveChanges();
                res.Status = 200;
                res.Message = "Sucessful !";
                res.Error = true;
            }
            catch (Exception e)
            {
                //SendMailError(e);
                res.Message = e.Message;
                res.Error = true;
                res.Status = 400;
            }
            return res;
        }

        [HttpPost("edit-simulation-time-table/{id}")]
        public async Task<CommonResponse> EditSimulationTimeTable([FromBody] PartSMLMasterTimeTableRequest rq, Guid id)
        {
            CommonResponse res = new CommonResponse()
            {
                Error = true,
                Message = "Can't add new master",
                Status = 400
            };

            try
            {


                var u = GetCurrentUser();
                var model = context.PcSimulationMasterTimetableDeliveries.FirstOrDefault(x => x.Active == true && x.Id == id);
                if (model != null)
                {

                    model.Route = rq.Route;
                    model.Gate = rq.Gate;
                    model.Vendor = rq.Vendor;
                    model.LotNo = rq.LotNo;
                    model.Eta = rq.Eta;
                    model.Shift = rq.Shift;
                    model.Product = rq.Product;
                    model.ModifiedBy = u.UserName;
                    model.ModifiedDate = DateTime.Now.SetKindUtc();
                    model.ApprovedBy = null;
                    model.ApprovedDate = null;
                }
                context.Update(model);
                context.SaveChanges();

                res.Status = 200;
                res.Message = "Sucessful !";
                res.Error = true;
            }
            catch (Exception e)
            {
                //SendMailError(e);
                res.Message = e.Message;
                res.Error = true;
                res.Status = 400;
            }
            return res;
        }

        [HttpGet("active-simulation-time-table/{id}")]
        public async Task<CommonResponse> ActiveSimulationTimeTable(Guid id)
        {
            CommonResponse res = new CommonResponse()
            {
                Error = true,
                Message = "Can't add new master",
                Status = 400
            };

            try
            {

                var u = GetCurrentUser();
                var model = context.PcSimulationMasterTimetableDeliveries.FirstOrDefault(x => x.Active == true && x.Id == id);
                if (model != null)
                {
                    model.Active = false;
                    model.ModifiedBy = u.UserName;
                    model.ModifiedDate = DateTime.Now.SetKindUtc();

                }
                context.Update(model);
                context.SaveChanges();

                res.Status = 200;
                res.Message = "Sucessful !";
                res.Error = true;
            }
            catch (Exception e)
            {
                //SendMailError(e);
                res.Message = e.Message;
                res.Error = true;
                res.Status = 400;
            }
            return res;
        }

        [HttpGet("approve-sml-time-table/{product}")]
        public async Task<CommonResponse> ApproveSMLTimeTable(string product)
        {
            CommonResponse res = new CommonResponse()
            {
                Error = false,
                Message = "",
                Status = (int)HttpStatusCode.BadRequest
            };
            try
            {

                var u = GetCurrentUser();

                //tìm những con cũ dựa vào key những con mới
                var model = await context.PcSimulationMasterTimetableDeliveries
                    .Where(x => x.Active == true && x.ApprovedDate == null && x.Product == product)
                    .ToListAsync();

                var timeTable = context.PcSimulationMasterTimetableDeliveries
                    .Where(x => x.Active == true && x.ApprovedDate != null && x.Product == product).ToList();
                timeTable.ForEach(x => {
                    x.Active = false;
                    x.ModifiedBy = u.UserName;
                });
                //List<PcSimulationMasterDoChangeTime> lstDel = new List<PcSimulationMasterDoChangeTime>();
                model.ForEach(x =>
                {
                    x.ApprovedBy = u.UserName;
                    x.ApprovedDate = DateTime.Now;
                });


                context.UpdateRange(timeTable);
                context.UpdateRange(model);
                context.SaveChanges();

                res.Error = false;
                res.Message = "Successfully !";
                res.Status = (int)HttpStatusCode.OK;
                return res;
            }
            catch (Exception e)
            {
                res.Error = true;
                res.Message = e.Message;
                res.Status = (int)HttpStatusCode.BadRequest;
                // SendMailError(e);
                return res;
            }


        }
        [HttpGet("reject-sml-time-table/{product}")]
        public async Task<CommonResponse> RejectSMLTimeTable(string product)
        {
            CommonResponse res = new CommonResponse()
            {
                Error = false,
                Message = "",
                Status = (int)HttpStatusCode.BadRequest
            };
            try
            {

                var u = GetCurrentUser();

               
                var model = await context.PcSimulationMasterTimetableDeliveries
                    .Where(x => x.Active == true && x.ApprovedDate == null && x.Product == product)
                    .ToListAsync();

                
                model.ForEach(x =>
                {
                    x.Active = false;
                    x.ApprovedBy = u.UserName;
                    x.ApprovedDate = DateTime.Now;
                });


                context.UpdateRange(model);
                context.SaveChanges();

                res.Error = false;
                res.Message = "Successfully !";
                res.Status = (int)HttpStatusCode.OK;
                return res;
            }
            catch (Exception e)
            {
                res.Error = true;
                res.Message = e.Message;
                res.Status = (int)HttpStatusCode.BadRequest;
                // SendMailError(e);
                return res;
            }


        }
        #endregion
        #region ip5 Off Line PP
        [HttpPost("filter-simulation-off-livepp/{product}")]
        public async Task<PcSimulationIP5OffLivePPModel> FilterSimulationOffLivepp(PaginationParams param,string product)
        {
            try
            {
                param.search = param.search.ToUpper().Trim();
                var u = GetCurrentUser();
                var result = new PcSimulationIP5OffLivePPModel();
                var model = context.PcSimulationIp5OffLivepps.Where(x => x.Active == true && x.Product == product && x.Cell.ToUpper().Contains(param.search)).ToList();


                var model2 = model.Skip((param.Page - 1) * param.RecordsPerPage).Take(param.RecordsPerPage).ToList();
                
                result.lstModel = model2;
                result.toRecord = (int)Math.Min(result.totalRecords, result.currentPage * result.recordPerPage);
                result.totalPage = (int)Math.Ceiling((decimal)model.Count / param.RecordsPerPage);
                result.totalRecords = model.Count;
                result.recordPerPage = param.RecordsPerPage;
                result.currentPage = param.Page;
                result.fromRecord = model.Count == 0 ? 0 : (result.currentPage - 1) * result.recordPerPage + 1;
                //}
                return result;
            }
            catch (Exception e)
            {
                //SendMailError(e);
                return new PcSimulationIP5OffLivePPModel();
            }
        }

        [HttpGet("approve-sml-off-livepp/{product}")]
        public async Task<CommonResponse> ApproveSMLOffLivePP(string product)
        {
            CommonResponse res = new CommonResponse()
            {
                Error = false,
                Message = "",
                Status = (int)HttpStatusCode.BadRequest
            };
            try
            {

                var u = GetCurrentUser();

                //tìm những con cũ dựa vào key những con mới
                var model = await context.PcSimulationIp5OffLivepps
                    .Where(x => x.Active == true && x.ApprovalDate == null && x.Product == product)
                    .ToListAsync();

                var timeTable = context.PcSimulationIp5OffLivepps
                    .Where(x => x.Active == true && x.ApprovalDate != null && x.Product == product).ToList();
                timeTable.ForEach(x => {
                    x.Active = false;
                    x.ModifiedBy = u.UserName;
                });
                //List<PcSimulationMasterDoChangeTime> lstDel = new List<PcSimulationMasterDoChangeTime>();
                model.ForEach(x =>
                {
                    x.ApprovalBy = u.UserName;
                    x.ApprovalDate = DateTime.Now;
                });


                context.UpdateRange(timeTable);
                context.UpdateRange(model);
                context.SaveChanges();

                res.Error = false;
                res.Message = "Successfully !";
                res.Status = (int)HttpStatusCode.OK;
                return res;
            }
            catch (Exception e)
            {
                res.Error = true;
                res.Message = e.Message;
                res.Status = (int)HttpStatusCode.BadRequest;
                // SendMailError(e);
                return res;
            }


        }
        [HttpGet("reject-sml-off-livepp/{product}")]
        public async Task<CommonResponse> RejectSMLOffLivePP(string product)
        {
            CommonResponse res = new CommonResponse()
            {
                Error = false,
                Message = "",
                Status = (int)HttpStatusCode.BadRequest
            };
            try
            {

                var u = GetCurrentUser();

                var model = await context.PcSimulationIp5OffLivepps
                    .Where(x => x.Active == true && x.ApprovalDate == null && x.Product == product)
                    .ToListAsync();

               
                model.ForEach(x =>
                {
                    x.Active = false;
                    x.ApprovalBy = u.UserName;
                    x.ApprovalDate = DateTime.Now;
                });


                context.UpdateRange(model);
                context.SaveChanges();

                res.Error = false;
                res.Message = "Successfully !";
                res.Status = (int)HttpStatusCode.OK;
                return res;
            }
            catch (Exception e)
            {
                res.Error = true;
                res.Message = e.Message;
                res.Status = (int)HttpStatusCode.BadRequest;
                // SendMailError(e);
                return res;
            }


        }
        #endregion
        #region ip6 divide po
        [HttpPost("filter-simulation-divide-po")]
        public async Task<PcSimulationIp6DividePoModel> FilterSimulationDividePo(PcSimulationIp6DividePoParam parameters)
        {
            try
            {
                PcSimulationIp6DividePoModel result = new PcSimulationIp6DividePoModel()
                {
                    currentPage = parameters.Page,
                    recordPerPage = parameters.RecordsPerPage
                };
                var ratioDs = parameters.RatioDs.StringAbleToDouble();
                var ratioNs = parameters.RatioNs.StringAbleToDouble();
                var query = context.PcSimulationMasterDivideDos.Where(x => x.Active == true && x.Product == parameters.Product);
                query = !string.IsNullOrEmpty(parameters.PartNo) ? query.Where(x => x.PartNo != null && x.PartNo.ToUpper().Contains(parameters.PartNo.ToUpper())) : query;
                query = !string.IsNullOrEmpty(parameters.Vendor) ? query.Where(x => x.Vendor != null && x.Vendor.ToUpper().Contains(parameters.Vendor.ToUpper())) : query;
                query = !string.IsNullOrEmpty(parameters.Bc) ? query.Where(x => x.Bc != null && x.Bc.ToUpper().Contains(parameters.Bc.ToUpper())) : query;
                query = !string.IsNullOrEmpty(parameters.Case) ? query.Where(x => x.Case != null && x.Case.ToUpper().Contains(parameters.Case.ToUpper())) : query;
                query = !string.IsNullOrEmpty(parameters.Model) ? query.Where(x => x.Model != null && x.Model.ToUpper().Contains(parameters.Model.ToUpper())) : query;
                query = !string.IsNullOrEmpty(parameters.DelvLocation) ? query.Where(x => x.DeliveryLocation != null && x.DeliveryLocation.ToUpper().Contains(parameters.DelvLocation.ToUpper())) : query;
                query = !string.IsNullOrEmpty(parameters.RatioDs) ? query.Where(x => x.RatioDs != null && x.RatioDs == ratioDs) : query;
                query = !string.IsNullOrEmpty(parameters.RatioNs) ? query.Where(x => x.RatioNs != null && x.RatioNs == ratioNs) : query;


                result.totalRecords = await query.CountAsync();
                result.totalPage = (int)Math.Ceiling((decimal)result.totalRecords / parameters.RecordsPerPage);
                var model = await query.OrderByDescending(x => x.CreatedDate).Paginate(parameters).ToListAsync();
               
                result.lstModel = model;
                result.fromRecord = model.Count == 0 ? 0 : (result.currentPage - 1) * result.recordPerPage + 1;
                result.toRecord = (int)Math.Min(result.totalRecords, result.currentPage * result.recordPerPage);
                result.currentPage = result.totalPage < result.currentPage ? result.totalPage : result.currentPage;
                return result;
            }
            catch (Exception e)
            {
                //SendMailError(e);
                return new PcSimulationIp6DividePoModel()
                {
                    currentPage = parameters.Page,
                    recordPerPage = parameters.RecordsPerPage
                };
            }
        }
      
        [HttpGet("approve-sml-divide-po/{product}")]
        public async Task<CommonResponse> ApproveSMLDividePo(string product)
        {
            CommonResponse res = new CommonResponse()
            {
                Error = false,
                Message = "",
                Status = (int)HttpStatusCode.BadRequest
            };
            try
            {

                var u = GetCurrentUser();

                //tìm những con cũ dựa vào key những con mới
                var model = await context.PcSimulationMasterDivideDos
                    .Where(x => x.Active == true && x.ApprovedDate == null && x.Product == product)
                    .ToListAsync();

                var dividePo = context.PcSimulationMasterDivideDos
                    .Where(x => x.Active == true && x.ApprovedDate != null && x.Product == product).ToList();
                dividePo.ForEach(x => {
                    x.Active = false;
                    x.ModifiedBy = u.UserName;
                });
                //List<PcSimulationMasterDoChangeTime> lstDel = new List<PcSimulationMasterDoChangeTime>();
                model.ForEach(x =>
                {
                    x.ApprovedBy = u.UserName;
                    x.ApprovedDate = DateTime.Now.SetKindUtc();
                });


                context.UpdateRange(dividePo);
                context.UpdateRange(model);
                context.SaveChanges();

                res.Error = false;
                res.Message = "Successfully !";
                res.Status = (int)HttpStatusCode.OK;
                return res;
            }
            catch (Exception e)
            {
                res.Error = true;
                res.Message = e.Message;
                res.Status = (int)HttpStatusCode.BadRequest;
                // SendMailError(e);
                return res;
            }


        }
        [HttpGet("reject-sml-divide-po/{product}")]
        public async Task<CommonResponse> RejectSMLDividePo(string product)
        {
            CommonResponse res = new CommonResponse()
            {
                Error = false,
                Message = "",
                Status = (int)HttpStatusCode.BadRequest
            };
            try
            {

                var u = GetCurrentUser();


                var model = await context.PcSimulationMasterDivideDos
                    .Where(x => x.Active == true && x.ApprovedDate == null && x.Product == product)
                    .ToListAsync();


                model.ForEach(x =>
                {
                    x.Active = false;
                    x.ApprovedBy = u.UserName;
                    x.ApprovedDate = DateTime.Now.SetKindUtc();
                });


                context.UpdateRange(model);
                context.SaveChanges();

                res.Error = false;
                res.Message = "Successfully !";
                res.Status = (int)HttpStatusCode.OK;
                return res;
            }
            catch (Exception e)
            {
                res.Error = true;
                res.Message = e.Message;
                res.Status = (int)HttpStatusCode.BadRequest;
                // SendMailError(e);
                return res;
            }


        }
        [HttpGet("active-sml-divide-po/{product}")]
        public async Task<CommonResponse> ActiveSMLDividePo(string product)
        {
            CommonResponse res = new CommonResponse()
            {
                Error = false,
                Message = "",
                Status = (int)HttpStatusCode.BadRequest
            };
            try
            {

                var u = GetCurrentUser();


                var model = await context.PcSimulationMasterDivideDos
                    .Where(x => x.Active == true &&  x.Product == product)
                    .ToListAsync();


                model.ForEach(x =>
                {
                    x.Active = false;
                    x.ApprovedBy = u.UserName;
                    x.ApprovedDate = DateTime.Now.SetKindUtc();
                });


                context.UpdateRange(model);
                context.SaveChanges();

                res.Error = false;
                res.Message = "Successfully !";
                res.Status = (int)HttpStatusCode.OK;
                return res;
            }
            catch (Exception e)
            {
                res.Error = true;
                res.Message = e.Message;
                res.Status = (int)HttpStatusCode.BadRequest;
                // SendMailError(e);
                return res;
            }


        }
        #endregion
        #region output
        [HttpPost("filter-simulation-op1-by-line")]
        public async Task<PartSMLOP1ByLineModel> FilterSimulationByLine(PcSimulationOp1ByLineParam parameters)
        {
            try
            {
                var config = new MapperConfiguration(cfg => cfg.CreateMap<PcSimulationPpLineLbp, PcSimulationPpLineIj>());
                var mapper = config.CreateMapper();
                PartSMLOP1ByLineModel result = new PartSMLOP1ByLineModel()
                {
                    currentPage = parameters.Page,
                    recordPerPage = parameters.RecordsPerPage
                };

                IQueryable<PcSimulationPpLineIj> query;
                if (parameters.Product.ToUpper() == "IJ")
                {
                    query = context.PcSimulationPpLineIjs.Where(x => x.Active == true);
                }
                else
                {
                    var outputLbp = context.PcSimulationPpLineLbps.Where(x => x.Active == true);
                    query = outputLbp.ProjectTo<PcSimulationPpLineIj>(mapper.ConfigurationProvider);
                }
                var blockTime = await context.PcSimulationMasterBlockTimes.Where(x => x.Active == true).OrderBy(x => x.OrderTime).ToListAsync();

                query = !string.IsNullOrEmpty(parameters.Model) ? query.Where(x => x.Model != null && x.Model.ToUpper().Contains(parameters.Model.ToUpper())) : query;
                query = !string.IsNullOrEmpty(parameters.Merchandise) ? query.Where(x => x.Destination != null && x.Destination.ToUpper().Contains(parameters.Merchandise.ToUpper())) : query;
                query = !string.IsNullOrEmpty(parameters.PalletDate) ? query.Where(x => x.PalletDate != null && x.PalletDate.ToUpper().Contains(parameters.PalletDate.ToUpper())) : query;


                result.totalRecords = await query.CountAsync();
                result.totalPage = (int)Math.Ceiling((decimal)result.totalRecords / parameters.RecordsPerPage);
                var model = await query.OrderByDescending(x => x.CreatedDate).Paginate(parameters).ToListAsync();
                result.LstBlock = blockTime.Select(x => x.StartTime.ToString("HH:mm")).ToList();
                result.lstModel = model;
                result.fromRecord = model.Count == 0 ? 0 : (result.currentPage - 1) * result.recordPerPage + 1;
                result.toRecord = (int)Math.Min(result.totalRecords, result.currentPage * result.recordPerPage);
                result.currentPage = result.totalPage < result.currentPage ? result.totalPage : result.currentPage;
                return result;
            }
            catch (Exception e)
            {
                //SendMailError(e);
                return new PartSMLOP1ByLineModel()
                {
                    currentPage = parameters.Page,
                    recordPerPage = parameters.RecordsPerPage
                };
            }
        }
        [HttpPost("filter-simulation-op1-by-line-pp-change")]
        public async Task<PartSMLOP1ByLinePPChangeModel> FilterSimulationByLinePPChange(PcSimulationOp1ByLineParam parameters)
        {
            try
            {
                var config = new MapperConfiguration(cfg => cfg.CreateMap<PcSimulationPpLineChangeppLbp, PcSimulationPpLineChangeppIj>());
                var mapper = config.CreateMapper();
                PartSMLOP1ByLinePPChangeModel result = new PartSMLOP1ByLinePPChangeModel()
                {
                    currentPage = parameters.Page,
                    recordPerPage = parameters.RecordsPerPage
                };

                IQueryable<PcSimulationPpLineChangeppIj> query;
                if (parameters.Product.ToUpper() == "IJ")
                {
                    query = context.PcSimulationPpLineChangeppIjs.Where(x => x.Active == true);
                }
                else
                {
                    var outputLbp = context.PcSimulationPpLineChangeppLbps.Where(x => x.Active == true);
                    query = outputLbp.ProjectTo<PcSimulationPpLineChangeppIj>(mapper.ConfigurationProvider);
                }
                var blockTime = await context.PcSimulationMasterBlockTimes.Where(x => x.Active == true).OrderBy(x => x.OrderTime).ToListAsync();

                query = !string.IsNullOrEmpty(parameters.Model) ? query.Where(x => x.Model != null && x.Model.ToUpper().Contains(parameters.Model.ToUpper())) : query;
                query = !string.IsNullOrEmpty(parameters.Merchandise) ? query.Where(x => x.Destination != null && x.Destination.ToUpper().Contains(parameters.Merchandise.ToUpper())) : query;
                query = !string.IsNullOrEmpty(parameters.PalletDate) ? query.Where(x => x.PalletDate != null && x.PalletDate.ToUpper().Contains(parameters.PalletDate.ToUpper())) : query;


                result.totalRecords = await query.CountAsync();
                result.totalPage = (int)Math.Ceiling((decimal)result.totalRecords / parameters.RecordsPerPage);
                var model = await query.OrderByDescending(x => x.CreatedDate).Paginate(parameters).ToListAsync();
                result.LstBlock = blockTime.Select(x => x.StartTime.ToString("HH:mm")).ToList();
                result.lstModel = model;
                result.fromRecord = model.Count == 0 ? 0 : (result.currentPage - 1) * result.recordPerPage + 1;
                result.toRecord = (int)Math.Min(result.totalRecords, result.currentPage * result.recordPerPage);
                result.currentPage = result.totalPage < result.currentPage ? result.totalPage : result.currentPage;
                return result;
            }
            catch (Exception e)
            {
                //SendMailError(e);
                return new PartSMLOP1ByLinePPChangeModel()
                {
                    currentPage = parameters.Page,
                    recordPerPage = parameters.RecordsPerPage
                };
            }
        }

        [HttpPost("filter-simulation-op2-part-master")]
        public async Task<PartSMLOP2PartMasterModel> FilterSimulationPartMaster(PcSimulationOp2PartMasterParam parameters)
        {
            try
            {
                var config = new MapperConfiguration(cfg => cfg.CreateMap<PcSimulationPartMasterLbp, PcSimulationPartMasterIj>());
                var mapper = config.CreateMapper();
                PartSMLOP2PartMasterModel result = new PartSMLOP2PartMasterModel()
                {
                    currentPage = parameters.Page,
                    recordPerPage = parameters.RecordsPerPage
                };

                IQueryable<PcSimulationPartMasterIj> query;
                if (parameters.Product.ToUpper() == "IJ")
                {
                    query = context.PcSimulationPartMasterIjs.Where(x => x.Active == true);
                }
                else
                {
                    var outputLbp = context.PcSimulationPartMasterLbps.Where(x => x.Active == true);
                    query = outputLbp.ProjectTo<PcSimulationPartMasterIj>(mapper.ConfigurationProvider);
                }

                var blockByDate = context.PcSimulationDetailBlocktimeBydates.Where(x => x.Active == true && x.Product == parameters.Product).OrderByDescending(x => x.CreatedDate).FirstOrDefault();
                //var lstItemBlock = blockByDate.BlockTime.ToList().Where(x => x.ToString().Contains(parameters.Date == null ? "": parameters.Date)).ToList();
                var blockTime = blockByDate.BlockTime.Select(x => x.ToString("HH:mm")).ToList();
                var lstDate = blockByDate.BlockTime.Select(x => x.ToString("yyyy-MM-dd")).ToList();
                //var indexes = blockByDate.BlockTime.Select((item, index) => new { Item = item, Index = index })
                //                     .Where(pair => lstItemBlock.Contains(pair.Item))
                //                     .Select(pair => pair.Index)
                //                     .ToList();
                query = !string.IsNullOrEmpty(parameters.PartNo) ? query.Where(x => x.PartNo != null && x.PartNo.ToUpper().Contains(parameters.PartNo.ToUpper())) : query;
                query = !string.IsNullOrEmpty(parameters.Vendor) ? query.Where(x => x.Vendor != null && x.Vendor.ToUpper().Contains(parameters.Vendor.ToUpper())) : query;
                //query = !string.IsNullOrEmpty(parameters.Date) ? query.Where(x => x.PalletDate != null && x.PalletDate.ToUpper().Contains(parameters.PalletDate.ToUpper())) : query;
                result.totalRecords = await query.CountAsync();
                result.totalPage = (int)Math.Ceiling((decimal)result.totalRecords / parameters.RecordsPerPage);
                var model = await query.OrderByDescending(x => x.CreatedDate).Paginate(parameters).ToListAsync();
                var lstResult = new List<PartSMLOP2PartMasterView>();
                foreach (var item in model)
                {
                    //var lstValue = item.PpValue
                    //            .Select((item, index) => new { Item = item, Index = index })
                    //            .Where(pair => indexes.Contains(pair.Index))
                    //            .Select(pair => pair.Item)
                    //            .ToList();
                    lstResult.Add(new PartSMLOP2PartMasterView
                    {
                        PartnoBc = item.PartnoBc,

                        PartNo = item.PartNo,
                        Dim = item.Dim,
                        Pr = item.Pr,
                        PartName = item.PartName,
                        Vendor = item.Vendor,
                        Unit = item.Unit,
                        Model = item.Model,
                        Destination = item.Destination,
                        Merchandise = item.Merchandise,
                        Factory = item.Factory,
                        Ratio = item.Ratio,
                        EffectivedateChange = item.EffectivedateChange,
                        RatioChange = item.RatioChange,
                        DoPic = item.DoPic,
                        PoPic = item.PoPic,
                        PpValue = item.PpValue.ToList(),
                        Pair = item.Pair
                    });
                }

                result.LstBlock = blockTime;
                result.lstModel = lstResult;
                result.LstDate = lstDate;
                result.fromRecord = model.Count == 0 ? 0 : (result.currentPage - 1) * result.recordPerPage + 1;
                result.toRecord = (int)Math.Min(result.totalRecords, result.currentPage * result.recordPerPage);
                result.currentPage = result.totalPage < result.currentPage ? result.totalPage : result.currentPage;
                return result;
            }
            catch (Exception e)
            {
                //SendMailError(e);
                return new PartSMLOP2PartMasterModel()
                {
                    currentPage = parameters.Page,
                    recordPerPage = parameters.RecordsPerPage
                };
            }
        }
        [HttpPost("filter-simulation-op2-part-master-pp-change")]
        public async Task<PartSMLOP2PartMasterModel> FilterSimulationPartMasterPPChange(PcSimulationOp2PartMasterParam parameters)
        {
            try
            {
                var config = new MapperConfiguration(cfg => cfg.CreateMap<PcSimulationPartMasterChangeppLbp, PcSimulationPartMasterChangeppIj>());
                var mapper = config.CreateMapper();
                PartSMLOP2PartMasterModel result = new PartSMLOP2PartMasterModel()
                {
                    currentPage = parameters.Page,
                    recordPerPage = parameters.RecordsPerPage
                };

                IQueryable<PcSimulationPartMasterChangeppIj> query;
                if (parameters.Product.ToUpper() == "IJ")
                {
                    query = context.PcSimulationPartMasterChangeppIjs.Where(x => x.Active == true);
                }
                else
                {
                    var outputLbp = context.PcSimulationPartMasterChangeppLbps.Where(x => x.Active == true);
                    query = outputLbp.ProjectTo<PcSimulationPartMasterChangeppIj>(mapper.ConfigurationProvider);
                }

                var blockByDate = context.PcSimulationDetailBlocktimeBydates.Where(x => x.Active == true && x.Product == parameters.Product).OrderByDescending(x => x.CreatedDate).FirstOrDefault();
                //var lstItemBlock = blockByDate.BlockTime.ToList().Where(x => x.ToString().Contains(parameters.Date == null ? "": parameters.Date)).ToList();
                var blockTime = blockByDate.BlockTime.Select(x => x.ToString("HH:mm")).ToList();
                var lstDate = blockByDate.BlockTime.Select(x => x.ToString("yyyy-MM-dd")).ToList();
                //var indexes = blockByDate.BlockTime.Select((item, index) => new { Item = item, Index = index })
                //                     .Where(pair => lstItemBlock.Contains(pair.Item))
                //                     .Select(pair => pair.Index)
                //                     .ToList();
                query = !string.IsNullOrEmpty(parameters.PartNo) ? query.Where(x => x.PartNo != null && x.PartNo.ToUpper().Contains(parameters.PartNo.ToUpper())) : query;
                query = !string.IsNullOrEmpty(parameters.Vendor) ? query.Where(x => x.Vendor != null && x.Vendor.ToUpper().Contains(parameters.Vendor.ToUpper())) : query;
                //query = !string.IsNullOrEmpty(parameters.Date) ? query.Where(x => x.PalletDate != null && x.PalletDate.ToUpper().Contains(parameters.PalletDate.ToUpper())) : query;
                result.totalRecords = await query.CountAsync();
                result.totalPage = (int)Math.Ceiling((decimal)result.totalRecords / parameters.RecordsPerPage);
                var model = await query.OrderByDescending(x => x.CreatedDate).Paginate(parameters).ToListAsync();
                var lstResult = new List<PartSMLOP2PartMasterView>();
                foreach (var item in model)
                {
                    //var lstValue = item.PpValue
                    //            .Select((item, index) => new { Item = item, Index = index })
                    //            .Where(pair => indexes.Contains(pair.Index))
                    //            .Select(pair => pair.Item)
                    //            .ToList();
                    lstResult.Add(new PartSMLOP2PartMasterView
                    {
                        PartnoBc = item.PartnoBc,

                        PartNo = item.PartNo,
                        Dim = item.Dim,
                        Pr = item.Pr,
                        PartName = item.PartName,
                        Vendor = item.Vendor,
                        Unit = item.Unit,
                        Model = item.Model,
                        Destination = item.Destination,
                        Merchandise = item.Merchandise,
                        Factory = item.Factory,
                        Ratio = item.Ratio,
                        EffectivedateChange = item.EffectivedateChange,
                        RatioChange = item.RatioChange,
                        DoPic = item.DoPic,
                        PoPic = item.PoPic,
                        PpValue = item.PpValue.ToList(),
                        Pair = item.Pair
                    });
                }

                result.LstBlock = blockTime;
                result.lstModel = lstResult;
                result.LstDate = lstDate;
                result.fromRecord = model.Count == 0 ? 0 : (result.currentPage - 1) * result.recordPerPage + 1;
                result.toRecord = (int)Math.Min(result.totalRecords, result.currentPage * result.recordPerPage);
                result.currentPage = result.totalPage < result.currentPage ? result.totalPage : result.currentPage;
                return result;
            }
            catch (Exception e)
            {
                //SendMailError(e);
                return new PartSMLOP2PartMasterModel()
                {
                    currentPage = parameters.Page,
                    recordPerPage = parameters.RecordsPerPage
                };
            }
        }

        [HttpPost("filter-simulation-op3-count-line")]
        public async Task<PartSMLOP2PartMasterModel> FilterSimulationCounLine(PcSimulationOp2PartMasterParam parameters)
        {
            try
            {
                var config = new MapperConfiguration(cfg => cfg.CreateMap<PcSimulationCountlineLbp, PcSimulationCountlineIj>());
                var mapper = config.CreateMapper();
                PartSMLOP2PartMasterModel result = new PartSMLOP2PartMasterModel()
                {
                    currentPage = parameters.Page,
                    recordPerPage = parameters.RecordsPerPage
                };

                IQueryable<PcSimulationCountlineIj> query;
                if (parameters.Product.ToUpper() == "IJ")
                {
                    query = context.PcSimulationCountlineIjs.Where(x => x.Active == true);
                }
                else
                {
                    var outputLbp = context.PcSimulationCountlineLbps.Where(x => x.Active == true);
                    query = outputLbp.ProjectTo<PcSimulationCountlineIj>(mapper.ConfigurationProvider);
                }

                var blockByDate = context.PcSimulationDetailBlocktimeBydates.Where(x => x.Active == true && x.Product == parameters.Product).OrderByDescending(x => x.CreatedDate).FirstOrDefault();
                // var lstItemBlock = blockByDate.BlockTime.ToList().Where(x => x.ToString().Contains(parameters.Date == null ? "" : parameters.Date)).ToList();
                var blockTime = blockByDate.BlockTime.Select(x => x.ToString("HH:mm")).ToList();
                var lstDate = blockByDate.BlockTime.Select(x => x.ToString("yyyy-MM-dd")).ToList();
                //var indexes = blockByDate.BlockTime.Select((item, index) => new { Item = item, Index = index })
                //                     .Where(pair => lstItemBlock.Contains(pair.Item))
                //                     .Select(pair => pair.Index)
                //                     .ToList();
                query = !string.IsNullOrEmpty(parameters.PartNo) ? query.Where(x => x.PartNo != null && x.PartNo.ToUpper().Contains(parameters.PartNo.ToUpper())) : query;
                query = !string.IsNullOrEmpty(parameters.Vendor) ? query.Where(x => x.Vendor != null && x.Vendor.ToUpper().Contains(parameters.Vendor.ToUpper())) : query;
                //query = !string.IsNullOrEmpty(parameters.Date) ? query.Where(x => x.PalletDate != null && x.PalletDate.ToUpper().Contains(parameters.PalletDate.ToUpper())) : query;
                result.totalRecords = await query.CountAsync();
                result.totalPage = (int)Math.Ceiling((decimal)result.totalRecords / parameters.RecordsPerPage);
                var model = await query.OrderByDescending(x => x.CreatedDate).Paginate(parameters).ToListAsync();
                var lstResult = new List<PartSMLOP2PartMasterView>();
                foreach (var item in model)
                {
                    //var lstValue = item.CountValue
                    //            .Select((item, index) => new { Item = item, Index = index })
                    //            .Where(pair => indexes.Contains(pair.Index))
                    //            .Select(pair => pair.Item)
                    //            .ToList();
                    lstResult.Add(new PartSMLOP2PartMasterView
                    {
                        //PartnoBc = item.pa,

                        PartNo = item.PartNo,
                        Dim = item.Dim,
                        // Pr = item.Pr,
                        PartName = item.PartName,
                        Vendor = item.Vendor,
                        // Unit = item.Unit,
                        Model = item.Model,
                        Destination = item.Destination,
                        Merchandise = item.Merchandise,
                        Factory = item.Factory,
                        Ratio = item.Ratio,
                        EffectivedateChange = item.EffectiveDateChange,
                        RatioChange = item.RatioChange,
                        DoPic = item.DoPic,
                        PoPic = item.PoPic,
                        PpValue = item.CountValue.ToList(),
                        // Pair = item.Pair
                    });
                }

                result.LstBlock = blockTime;
                result.lstModel = lstResult;
                result.LstDate = lstDate;
                result.fromRecord = model.Count == 0 ? 0 : (result.currentPage - 1) * result.recordPerPage + 1;
                result.toRecord = (int)Math.Min(result.totalRecords, result.currentPage * result.recordPerPage);
                result.currentPage = result.totalPage < result.currentPage ? result.totalPage : result.currentPage;
                return result;
            }
            catch (Exception e)
            {
                //SendMailError(e);
                return new PartSMLOP2PartMasterModel()
                {
                    currentPage = parameters.Page,
                    recordPerPage = parameters.RecordsPerPage
                };
            }
        }

        [HttpPost("filter-simulation-op4-lead-time")]
        public async Task<PartSMLOP4LeadTimeModel> FilterSimulationLeadTime(PcSimulationOp2PartMasterParam parameters)
        {
            try
            {
                var LstType = new List<string>() { "Has Plan", "Leadtime", "QtyKeepCell", "TotalLeadtime", };
                var config = new MapperConfiguration(cfg => cfg.CreateMap<PcSimulationLeadtimeLbp, PcSimulationLeadtimeIj>());
                var mapper = config.CreateMapper();
                PartSMLOP4LeadTimeModel result = new PartSMLOP4LeadTimeModel()
                {
                    currentPage = parameters.Page,
                    recordPerPage = parameters.RecordsPerPage
                };

                IQueryable<PcSimulationLeadtimeIj> query;
                if (parameters.Product.ToUpper() == "IJ")
                {
                    query = context.PcSimulationLeadtimeIjs.Where(x => x.Active == true);
                }
                else
                {
                    var outputLbp = context.PcSimulationLeadtimeLbps.Where(x => x.Active == true);
                    query = outputLbp.ProjectTo<PcSimulationLeadtimeIj>(mapper.ConfigurationProvider);
                }

                var blockByDate = context.PcSimulationDetailBlocktimeBydates.Where(x => x.Active == true && x.Product == parameters.Product).OrderByDescending(x => x.CreatedDate).FirstOrDefault();
                var blockTime = blockByDate.BlockTime.Select(x => x.ToString("HH:mm")).ToList();
                var lstDate = blockByDate.BlockTime.Select(x => x.ToString("yyyy-MM-dd")).ToList();

                query = !string.IsNullOrEmpty(parameters.PartNo) ? query.Where(x => x.PartNo != null && x.PartNo.ToUpper().Contains(parameters.PartNo.ToUpper())) : query;
                query = !string.IsNullOrEmpty(parameters.Vendor) ? query.Where(x => x.Vendor != null && x.Vendor.ToUpper().Contains(parameters.Vendor.ToUpper())) : query;
                result.totalRecords = await query.CountAsync();
                result.totalPage = (int)Math.Ceiling((decimal)result.totalRecords / parameters.RecordsPerPage);
                var model = await query.OrderByDescending(x => x.CreatedDate).Paginate(parameters).ToListAsync();
                var lstResult = new List<PartSMLOP4LeadTimeView>();
                var properties = new Func<PcSimulationLeadtimeIj, List<string>>[]
                     {
                        item => item.HasPlan.Select(x => x.ToString()).ToList(),
                        item => item.LtValue.Select(x => Math.Round(x,2).ToString()).ToList(),
                        item => item.QtyKeepArr.Select(x => Math.Round(x,2).ToString()).ToList(),
                        item => item.TotalLt.Select(x => Math.Round(x,2).ToString()).ToList(),
                 };
                foreach (var item in model)
                {
                    var i = 0;
                   
                    foreach (var type in LstType)
                    {
                        var add = new PartSMLOP4LeadTimeView
                        {
                            //PartnoBc = "",
                            PartNo = item.PartNo,
                            Dim = item.Dim,
                            PartName = item.PartName,
                            Vendor = item.Vendor,
                            Model = item.Model,
                            Destination = item.Destination,
                            Factory = "",
                            Ratio = item.Ratio,
                            EffectivedateChange = item.RatioChangeEffectiveDate,
                            RatioChange = item.RatioChangeRatio,
                            DoPic = item.PicDo,
                            PoPic = item.PicPo,
                            Cell = item.Cell,
                            QtyKeepCellBl = item.QtyKeepCell.ToString(),
                            LeadTimeBl = item.Leadtime.ToString()
                            //lstValue = item.TotalLt.ToList(),
                        };
                        add.Type = type;
                        add.lstValue = properties[i](item);
                        add.Order = i;
                        lstResult.Add(add);
                        i++;
                    }
                }

                result.LstBlock = blockTime;
                result.lstModel = lstResult;
                result.LstDate = lstDate;
                result.fromRecord = model.Count == 0 ? 0 : (result.currentPage - 1) * result.recordPerPage + 1;
                result.toRecord = (int)Math.Min(result.totalRecords, result.currentPage * result.recordPerPage);
                result.currentPage = result.totalPage < result.currentPage ? result.totalPage : result.currentPage;
                return result;
            }
            catch (Exception e)
            {
                //SendMailError(e);
                return new PartSMLOP4LeadTimeModel()
                {
                    currentPage = parameters.Page,
                    recordPerPage = parameters.RecordsPerPage
                };
            }
        }

        [HttpPost("filter-simulation-op5-do")]
        public async Task<PartSMLOP5DoModel> FilterSimulationDo(PcSimulationOp5DoParam parameters)
        {
            try
            {
                var config = new MapperConfiguration(cfg => cfg.CreateMap<PcSimulationNpisPdoLbp, PcSimulationNpisPdoIj>());
                var mapper = config.CreateMapper();
                PartSMLOP5DoModel result = new PartSMLOP5DoModel()
                {
                    currentPage = parameters.Page,
                    recordPerPage = parameters.RecordsPerPage
                };

                IQueryable<PcSimulationNpisPdoIj> query;
                if (parameters.Product.ToUpper() == "IJ")
                {
                    query = context.PcSimulationNpisPdoIjs.Where(x => x.Active == true);
                }
                else
                {
                    var outputLbp = context.PcSimulationNpisPdoLbps.Where(x => x.Active == true);
                    query = outputLbp.ProjectTo<PcSimulationNpisPdoIj>(mapper.ConfigurationProvider);
                }


                query = !string.IsNullOrEmpty(parameters.PartNo) ? query.Where(x => x.PartNo != null && x.PartNo.ToUpper().Contains(parameters.PartNo.ToUpper())) : query;
                query = !string.IsNullOrEmpty(parameters.Vendor) ? query.Where(x => x.Vendor != null && x.Vendor.ToUpper().Contains(parameters.Vendor.ToUpper())) : query;
                query = !string.IsNullOrEmpty(parameters.Date) ? query.Where(x => x.DateDelivery != null && x.DateDelivery.ToUpper().Contains(parameters.Date.ToUpper())) : query;
                result.totalRecords = await query.CountAsync();
                result.totalPage = (int)Math.Ceiling((decimal)result.totalRecords / parameters.RecordsPerPage);
                var model = await query.OrderByDescending(x => x.CreatedDate).Paginate(parameters).ToListAsync();



                result.lstModel = model;

                result.fromRecord = model.Count == 0 ? 0 : (result.currentPage - 1) * result.recordPerPage + 1;
                result.toRecord = (int)Math.Min(result.totalRecords, result.currentPage * result.recordPerPage);
                result.currentPage = result.totalPage < result.currentPage ? result.totalPage : result.currentPage;
                return result;
            }
            catch (Exception e)
            {
                //SendMailError(e);
                return new PartSMLOP5DoModel()
                {
                    currentPage = parameters.Page,
                    recordPerPage = parameters.RecordsPerPage
                };
            }
        }

        [HttpPost("filter-simulation-op7-fcdo")]
        public async Task<PartSMLOP7FcDoModel> FilterSimulationOp7FCDo(PcSimulationOp7FCDoParam parameters)
        {
            try
            {
                var config = new MapperConfiguration(cfg => cfg.CreateMap<PcSimulationFcdoLbp, PcSimulationFcdoIj>());
                var mapper = config.CreateMapper();
                PartSMLOP7FcDoModel result = new PartSMLOP7FcDoModel()
                {
                    currentPage = parameters.Page,
                    recordPerPage = parameters.RecordsPerPage
                };

                IQueryable<PcSimulationFcdoIj> query;
                var lstDateOnly = new List<DateOnly>();
                if (parameters.Product.ToUpper() == "IJ")
                {
                    query = context.PcSimulationFcdoIjs.Where(x => x.Active == true);
                    lstDateOnly = await context.VWorkingDateIj121s.Select(x => x.DateOfDate.Value).ToListAsync();
                }
                else
                {
                    var outputLbp = context.PcSimulationFcdoLbps.Where(x => x.Active == true);
                    query = outputLbp.ProjectTo<PcSimulationFcdoIj>(mapper.ConfigurationProvider);
                    lstDateOnly = await context.VWorkingDateLbp121s.Select(x => x.DateOfDate.Value).ToListAsync();
                }
                DateOnly? issDate = parameters.IssueDate.StringToDateAble();
                var s1 = issDate?.ToString("yyyy-MM-dd");
                var s12 = issDate?.AddDays(1).ToString("yyyy-MM-dd");
                var s2 = issDate?.AddDays(1).ToString("yyyy-MM-dd");
                if (issDate < lstDateOnly.Last())
                {
                    var checks2 = lstDateOnly.Where(x => x > issDate).First();
                    s2 = checks2.ToString("yyyy-MM-dd");
                }

                query = !string.IsNullOrEmpty(parameters.PartNo) ? query.Where(x => x.PartNo != null && x.PartNo.ToUpper().Contains(parameters.PartNo.ToUpper())) : query;
                query = !string.IsNullOrEmpty(parameters.Vendor) ? query.Where(x => x.Vendor != null && x.Vendor.ToUpper().Contains(parameters.Vendor.ToUpper())) : query;
                query = !string.IsNullOrEmpty(parameters.Date) ? query.Where(x => x.DateDelivery != null && x.DateDelivery.ToUpper().Contains(parameters.Date.ToUpper())) : query;
                query = !string.IsNullOrEmpty(parameters.Bc) ? query.Where(x => x.Bc != null && x.Bc.ToUpper().Contains(parameters.Bc.ToUpper())) : query;
                query = !string.IsNullOrEmpty(parameters.Time) ? query.Where(x => x.TimeDelivery != null && x.TimeDelivery.ToUpper().Contains(parameters.Time.ToUpper())) : query;
                query = !string.IsNullOrEmpty(parameters.Pic) ? query.Where(x => x.DoPic != null && x.DoPic.ToUpper().Contains(parameters.Pic.ToUpper())) : query;
                query = !string.IsNullOrEmpty(parameters.PoKey) ? query.Where(x => x.PoKey != null && x.PoKey.ToUpper().Contains(parameters.PoKey.ToUpper())) : query;
                query = !string.IsNullOrEmpty(parameters.Term) ? query.Where(x => x.TermIssue != null && x.TermIssue.ToUpper().Contains(parameters.Term.ToUpper())) : query;
                //query = !string.IsNullOrEmpty(parameters.IssueDate) ? query.Where(x => x.DateDelivery != null && x.DateDelivery.ToUpper().Contains(parameters.IssueDate.ToUpper())) : query;
                if(parameters.IssueDate != null)
                {
                    //if (parameters.Term == "N-D+1")
                    //{
                    //    query =  query.AsEnumerable().Where(x => (x.DateDelivery == s1 && x.TimeDelivery.StringToIntAble() > 2000) || (x.DateDelivery == s2 && x.TimeDelivery.StringToIntAble() < 2000)).AsQueryable();
                    //}
                    //else
                    //{
                    //    query = query.AsEnumerable().Where(x => (x.DateDelivery == s1 && x.TimeDelivery.StringToIntAble() > 700) || (x.DateDelivery == s2 && x.TimeDelivery.StringToIntAble() < 700)).AsQueryable();
                    //}
                    if (parameters.Term == "N-D+1")
                    {
                        query = query.AsEnumerable().Where(x => (x.DateDelivery == s1 && x.TimeDelivery.ObjToIntAble() > 2000) || (x.DateDelivery == s12 && x.TimeDelivery.ObjToIntAble() < 800) || (x.DateDelivery == s2 && x.TimeDelivery.ObjToIntAble() < 2000)).AsQueryable();
                    }
                    else
                    {
                        query = query.AsEnumerable().Where(x => (x.DateDelivery == s1 && x.TimeDelivery.ObjToIntAble() > 800) || (x.DateDelivery == s12 && x.TimeDelivery.ObjToIntAble() < 800)).AsQueryable();
                    }
                }
               
                result.totalRecords =  query.Count();
                result.totalPage = (int)Math.Ceiling((decimal)result.totalRecords / parameters.RecordsPerPage);
                var model =  query.OrderBy(x => x.PartNo).ThenBy(x => x.Vendor).ThenBy(x => x.DateDelivery).ThenBy(x => x.TimeDelivery).Paginate(parameters).ToList();



                result.lstModel = model;

                result.fromRecord = model.Count == 0 ? 0 : (result.currentPage - 1) * result.recordPerPage + 1;
                result.toRecord = (int)Math.Min(result.totalRecords, result.currentPage * result.recordPerPage);
                result.currentPage = result.totalPage < result.currentPage ? result.totalPage : result.currentPage;
                return result;
            }
            catch (Exception e)
            {
                //SendMailError(e);
                return new PartSMLOP7FcDoModel()
                {
                    currentPage = parameters.Page,
                    recordPerPage = parameters.RecordsPerPage
                };
            }
        }

        [HttpPost("filter-simulation-op9-war-list")]
        public async Task<PartSMLOP9WarnListModel> FilterSimulationOp9WarnList(PcSimulationOp9WarnListParam parameters)
        {
            try
            {
                var config = new MapperConfiguration(cfg => cfg.CreateMap<PcSimulationWarningListOp9Lbp, PcSimulationWarningListOp9Ij>());
                var mapper = config.CreateMapper();
                PartSMLOP9WarnListModel result = new PartSMLOP9WarnListModel()
                {
                    currentPage = parameters.Page,
                    recordPerPage = parameters.RecordsPerPage
                };

                IQueryable<PcSimulationWarningListOp9Ij> query;
                if (parameters.Product.ToUpper() == "IJ")
                {
                    query = context.PcSimulationWarningListOp9Ijs.Where(x => x.Active == true);
                }
                else
                {
                    var outputLbp = context.PcSimulationWarningListOp9Lbps.Where(x => x.Active == true);
                    query = outputLbp.ProjectTo<PcSimulationWarningListOp9Ij>(mapper.ConfigurationProvider);
                }
                DateOnly? date = parameters.Date == null ? null : DateOnly.Parse(parameters.Date);

                query = !string.IsNullOrEmpty(parameters.PartNo) ? query.Where(x => x.PartNo != null && x.PartNo.ToUpper().Contains(parameters.PartNo.ToUpper())) : query;
                query = !string.IsNullOrEmpty(parameters.Vendor) ? query.Where(x => x.Vendor != null && x.Vendor.ToUpper().Contains(parameters.Vendor.ToUpper())) : query;
                query = !string.IsNullOrEmpty(parameters.Model) ? query.Where(x => x.Model != null && x.Model.ToUpper().Contains(parameters.Model.ToUpper())) : query;
                query = !string.IsNullOrEmpty(parameters.Pic) ? query.Where(x => x.DoPic != null && x.DoPic.ToUpper().Contains(parameters.Pic.ToUpper())) : query;
                query = !string.IsNullOrEmpty(parameters.Merchandise) ? query.Where(x => x.Destination != null && x.Destination.ToUpper().Contains(parameters.Merchandise.ToUpper())) : query;
                query = !string.IsNullOrEmpty(parameters.Reason) ? query.Where(x => x.Reason != null && x.Reason.ToUpper().Contains(parameters.Reason.ToUpper())) : query;
                query = !string.IsNullOrEmpty(parameters.Action) ? query.Where(x => x.Action != null && x.Action.ToUpper().Contains(parameters.Action.ToUpper())) : query;
                query = date != null ? query.Where(x => x.DeadlineDate != null && x.DeadlineDate == date) : query;

                result.totalRecords = await query.CountAsync();
                result.totalPage = (int)Math.Ceiling((decimal)result.totalRecords / parameters.RecordsPerPage);
                var model = await query.OrderByDescending(x => x.CreatedDate).Paginate(parameters).ToListAsync();
                var lstResult = new List<PartSMLOP9WarnListView>();
                foreach (var item in model)
                {
                    lstResult.Add(new PartSMLOP9WarnListView
                    {
                        Bc = RemoveDuplicate(item.Bc),
                        PartNo = RemoveDuplicate(item.PartNo),
                        Dim = RemoveDuplicate(item.Dim),
                        PartName = RemoveDuplicate(item.PartName),
                        Vendor = RemoveDuplicate(item.Vendor),
                        Model = RemoveDuplicate(item.Model),
                        Destination = RemoveDuplicate(item.Destination),
                        Factory = RemoveDuplicate(item.Factory),
                        DoPic = RemoveDuplicate(item.DoPic),
                        PoPic = RemoveDuplicate(item.PoPic),
                        DeadlineDate = item.DeadlineDate.ToString(),
                        DeadlineTime = item.DeadlineTime?.ToString("HH:mm"),
                        DeadlineLackQty = item.DeadlineLackQty,
                        Reason = item.Reason,
                        Action = item.Action,
                        DeadlineInclDate = item.DeadlineInclDate.ToString(),
                        DeadlineInclTime = item.DeadlineInclTime?.ToString("HH:mm"),
                        DeadlineInclLackQty = item.DeadlineInclLackQty,
                        Highlight = item.Highlight
                    });

                }



                result.lstModel = lstResult;

                result.fromRecord = model.Count == 0 ? 0 : (result.currentPage - 1) * result.recordPerPage + 1;
                result.toRecord = (int)Math.Min(result.totalRecords, result.currentPage * result.recordPerPage);
                result.currentPage = result.totalPage < result.currentPage ? result.totalPage : result.currentPage;
                return result;
            }
            catch (Exception e)
            {
                //SendMailError(e);
                return new PartSMLOP9WarnListModel()
                {
                    currentPage = parameters.Page,
                    recordPerPage = parameters.RecordsPerPage
                };
            }
        }

        [HttpPost("filter-pic-op9/{product}")]
        public async Task<List<string>> FilterPicOp9(string product)
        {
            try
            {
                var lstResult = new List<string>();
                
                if (product.ToUpper() == "IJ")
                {
                    lstResult = await context.PcSimulationWarningListOp9Ijs.Where(x => x.Active == true).Select(x => x.DoPic).Distinct().ToListAsync();
                }
                else
                {
                    lstResult = await context.PcSimulationWarningListOp9Lbps.Where(x => x.Active == true).Select(x => x.DoPic).Distinct().ToListAsync();

                }
               
                return lstResult;
            }
            catch (Exception e)
            {
                //SendMailError(e);
                return new List<string>();
            }
        }
        [HttpPost("filter-simulation-op8-sml-date")]
        public async Task<PartSMLOP8SMLDateModel> FilterSimulationOp8SMlDate(PcSimulationOp9WarnListParam parameters)
        {
            try
            {
                var config = new MapperConfiguration(cfg => cfg.CreateMap<PcSimulationSmTimeOp8Lbp, PcSimulationSmTimeOp8Ij>());
                var mapper = config.CreateMapper();
                PartSMLOP8SMLDateModel result = new PartSMLOP8SMLDateModel()
                {
                    currentPage = parameters.Page,
                    recordPerPage = parameters.RecordsPerPage
                };

                IQueryable<PcSimulationSmTimeOp8Ij> query;
                if (parameters.Product.ToUpper() == "IJ")
                {
                    query = context.PcSimulationSmTimeOp8Ijs.Where(x => x.Active == true);
                }
                else
                {
                    var outputLbp = context.PcSimulationSmTimeOp8Lbps.Where(x => x.Active == true);
                    query = outputLbp.ProjectTo<PcSimulationSmTimeOp8Ij>(mapper.ConfigurationProvider);
                }
                DateOnly? date = parameters.Date == null ? null : DateOnly.Parse(parameters.Date);

                query = !string.IsNullOrEmpty(parameters.PartNo) ? query.Where(x => x.PartNo != null && x.PartNo.ToUpper().Contains(parameters.PartNo.ToUpper())) : query;
                query = !string.IsNullOrEmpty(parameters.Vendor) ? query.Where(x => x.Vendor != null && x.Vendor.ToUpper().Contains(parameters.Vendor.ToUpper())) : query;
                query = !string.IsNullOrEmpty(parameters.Model) ? query.Where(x => x.Model != null && x.Model.ToUpper().Contains(parameters.Model.ToUpper())) : query;
                query = !string.IsNullOrEmpty(parameters.Pic) ? query.Where(x => x.DoPic != null && x.DoPic.ToUpper().Contains(parameters.Pic.ToUpper())) : query;
                query = !string.IsNullOrEmpty(parameters.Merchandise) ? query.Where(x => x.Destination != null && x.Destination.ToUpper().Contains(parameters.Merchandise.ToUpper())) : query;
                query = !string.IsNullOrEmpty(parameters.Reason) ? query.Where(x => x.Reason != null && x.Reason.ToUpper().Contains(parameters.Reason.ToUpper())) : query;
                query = !string.IsNullOrEmpty(parameters.Action) ? query.Where(x => x.Action != null && x.Action.ToUpper().Contains(parameters.Action.ToUpper())) : query;
                query = date != null ? query.Where(x => x.DeadlineDate != null && x.DeadlineDate == date) : query;

                result.totalRecords = await query.CountAsync();
                result.totalPage = (int)Math.Ceiling((decimal)result.totalRecords / parameters.RecordsPerPage);
                var model = await query.OrderByDescending(x => x.CreatedDate).Paginate(parameters).ToListAsync();
                var lstResult = new List<PartSMLOP8SMLDateView>();
                foreach (var item in model)
                {
                    lstResult.Add(new PartSMLOP8SMLDateView
                    {
                        Bc = RemoveDuplicate(item.Bc),
                        PartNo = RemoveDuplicate(item.PartNo),
                        Dim = RemoveDuplicate(item.Dim),
                        PartMovingRoute = item.PartMovingRoute,
                        PartName = RemoveDuplicate(item.PartName),
                        Vendor = RemoveDuplicate(item.Vendor),
                        MoqOrder = RemoveDuplicate(item.MoqOrder),
                        Model = RemoveDuplicate(item.Model),
                        Destination = RemoveDuplicate(item.Destination),
                        MainAlt = RemoveDuplicate(item.MainAlt),
                        Factory = RemoveDuplicate(item.PartMovingRoute),
                        Ratio = RemoveDuplicate(item.Ratio),
                        EffectivedateChange = item.EffectivedateChange,
                        RatioChange = item.RatioChange,
                        DoPic = RemoveDuplicate(item.DoPic),
                        PoPic = RemoveDuplicate(item.PoPic),
                        Pair = RemoveDuplicate(item.Pair),
                        DeadlineDate = item.DeadlineDate.ToString(),
                        DeadlineTime = item.DeadlineTime?.ToString("HH:mm"),
                        Reason = item.Reason,
                        Action = item.Action,
                        DateRange = item.DateRange,
                        DsStock = item.DsStock,
                        DsPp = item.DsPp,
                        DsDo = item.DsDo,
                        DsRemain = item.DsRemain,
                        NsPp = item.NsPp,
                        NsDo = item.NsDo,
                        NsRemain = item.NsRemain,
                        DateDeadline = item.DateDeadline,
                        DsLackover = item.DsLackover,
                        NsLackover = item.NsLackover,
                        HightLight = item.Hightlight
                    });

                }



                result.lstModel = lstResult;
                result.lstDate = model.FirstOrDefault().DateRange.Select(x => x.ToString()).ToList();
                result.fromRecord = model.Count == 0 ? 0 : (result.currentPage - 1) * result.recordPerPage + 1;
                result.toRecord = (int)Math.Min(result.totalRecords, result.currentPage * result.recordPerPage);
                result.currentPage = result.totalPage < result.currentPage ? result.totalPage : result.currentPage;
                return result;
            }
            catch (Exception e)
            {
                //SendMailError(e);
                return new PartSMLOP8SMLDateModel()
                {
                    currentPage = parameters.Page,
                    recordPerPage = parameters.RecordsPerPage
                };
            }
        }
        [HttpPost("filter-pic-op8/{product}")]
        public async Task<List<string>> FilterPicOp8(string product)
        {
            try
            {
                var lstResult = new List<string>();

                if (product.ToUpper() == "IJ")
                {
                    lstResult = await context.PcSimulationSmTimeOp8Ijs.Where(x => x.Active == true).Select(x => x.DoPic).Distinct().ToListAsync();
                }
                else
                {
                    lstResult = await context.PcSimulationSmTimeOp8Lbps.Where(x => x.Active == true).Select(x => x.DoPic).Distinct().ToListAsync();

                }

                return lstResult;
            }
            catch (Exception e)
            {
                //SendMailError(e);
                return new List<string>();
            }
        }

        [HttpPost("filter-simulation-op6-sml-by-time")]
        public async Task<PartSMLOP6SMLByTimeModel> FilterSimulationOp6SMlByTime(PcSimulationOp6ByTimeParam parameters)
        {
            try
            {
                var LstType = new List<string>() {"Demand","Demand CP","Other Order","DO","Leadtime","Remain", "Remain Incl LT", "Abnormal stock by pcs", "Abnormal stock by pallet"}; 
                var config = new MapperConfiguration(cfg => cfg.CreateMap<PcSimulationSmTimeOp6Lbp, PcSimulationSmTimeOp6Ij>());
                var mapper = config.CreateMapper();
                PartSMLOP6SMLByTimeModel result = new PartSMLOP6SMLByTimeModel()
                {
                    currentPage = parameters.Page,
                    recordPerPage = parameters.RecordsPerPage
                };

                IQueryable<PcSimulationSmTimeOp6Ij> query;
                if (parameters.Product.ToUpper() == "IJ")
                {
                    query = context.PcSimulationSmTimeOp6Ijs.Where(x => x.Active == true);
                }
                else
                {
                    var outputLbp = context.PcSimulationSmTimeOp6Lbps.Where(x => x.Active == true);
                    query = outputLbp.ProjectTo<PcSimulationSmTimeOp6Ij>(mapper.ConfigurationProvider);
                }
                DateOnly? date = parameters.Date == null ? null : DateOnly.Parse(parameters.Date);

                var blockByDate = context.PcSimulationDetailBlocktimeBydates.Where(x => x.Active == true && x.Product == parameters.Product).OrderByDescending(x => x.CreatedDate).FirstOrDefault();
                var blockTime = blockByDate.BlockTime.Select(x => x.ToString("HH:mm")).ToList();
                var lstDate = blockByDate.BlockTime.Select(x => x.ToString("yyyy-MM-dd")).ToList();

                query = !string.IsNullOrEmpty(parameters.PartNo) ? query.Where(x => x.PartNo != null && x.PartNo.ToUpper().Contains(parameters.PartNo.ToUpper())) : query;
                query = !string.IsNullOrEmpty(parameters.Vendor) ? query.Where(x => x.Vendor != null && x.Vendor.ToUpper().Contains(parameters.Vendor.ToUpper())) : query;
                query = !string.IsNullOrEmpty(parameters.Model) ? query.Where(x => x.Model != null && x.Model.ToUpper().Contains(parameters.Model.ToUpper())) : query;
                query = !string.IsNullOrEmpty(parameters.Pic) ? query.Where(x => x.DoPic != null && x.DoPic.ToUpper().Contains(parameters.Pic.ToUpper())) : query;
                query = !string.IsNullOrEmpty(parameters.Merchandise) ? query.Where(x => x.Destination != null && x.Destination.ToUpper().Contains(parameters.Merchandise.ToUpper())) : query;
                query = !string.IsNullOrEmpty(parameters.Bc) ? query.Where(x => x.Bc != null && x.Bc.ToUpper().Contains(parameters.Bc.ToUpper())) : query;

                result.totalRecords = await query.CountAsync();
                result.totalPage = (int)Math.Ceiling((decimal)result.totalRecords / parameters.RecordsPerPage);
                var model = await query.OrderByDescending(x => x.CreatedDate).Paginate(parameters).ToListAsync();
                var lstResult = new List<PartSMLOP6SMLByTimeView>();
                var properties = new Func<PcSimulationSmTimeOp6Ij, List<double>>[]
                      {
                        item => item.Demand.ToList(),
                        item => item.DemandCp.ToList(),
                        item => item.OtherOrder.ToList(),
                        item => item.DoVal.ToList(),
                        item => item.LeadTime.ToList(),
                        item => item.Remain.ToList(),
                        item => item.RemainIncl.ToList(),
                        item => item.AbnormalPcs.ToList(),
                        item => item.AbnormalPallet.ToList()
                  };
                foreach (var item in model)
                {                 
                    var i = 0;
                    foreach(var type in LstType)
                    {
                      
                        var lstVal = properties[i](item);
                        lstResult.Add(new PartSMLOP6SMLByTimeView
                        {
                            PartNo = RemoveDuplicate(item.PartNo),
                            Bc = RemoveDuplicate(item.Bc) ,
                            Vendor = RemoveDuplicate(item.Vendor),
                            Destination = RemoveDuplicate(item.Destination),
                            Dim = RemoveDuplicate(item.Dim) ,
                            Model = RemoveDuplicate(item.Model) ,
                            MoqOrder = RemoveDuplicate(item.MoqOrder) ,
                            Inventory = item.Inventory ,
                            Order = i,
                            Type = type,
                            LstValue = lstVal
                        });
                        i++;
                    }
                               
                }



                result.lstModel = lstResult;
                result.lstDate = lstDate;
                result.LstBlock = blockTime;
                result.fromRecord = model.Count == 0 ? 0 : (result.currentPage - 1) * result.recordPerPage + 1;
                result.toRecord = (int)Math.Min(result.totalRecords, result.currentPage * result.recordPerPage);
                result.currentPage = result.totalPage < result.currentPage ? result.totalPage : result.currentPage;
                return result;
            }
            catch (Exception e)
            {
                //SendMailError(e);
                return new PartSMLOP6SMLByTimeModel()
                {
                    currentPage = parameters.Page,
                    recordPerPage = parameters.RecordsPerPage
                };
            }
        }
        [HttpPost("filter-pic-op6/{product}")]
        public async Task<List<string>> FilterPicOp6(string product)
        {
            try
            {
                var lstResult = new List<string>();

                if (product.ToUpper() == "IJ")
                {
                    lstResult = await context.PcSimulationSmTimeOp6Ijs.Where(x => x.Active == true).Select(x => x.DoPic).Distinct().ToListAsync();
                }
                else
                {
                    lstResult = await context.PcSimulationSmTimeOp6Lbps.Where(x => x.Active == true).Select(x => x.DoPic).Distinct().ToListAsync();

                }

                return lstResult;
            }
            catch (Exception e)
            {
                //SendMailError(e);
                return new List<string>();
            }
        }
       
        [HttpGet("get-file-sml-op/{number}/{product}/{date}")]
        public List<string> GetFileSMLOp6(string number,string product,string date)
        {
            string folderPath = this.outputPathOri + @"\7. Digital Simulation\Output\"+product.ToUpper()+@"\" ;
            string dateSearch = date; // Ví dụ
            string numberOP = "OP" + number;


            // Biểu thức chính quy để tìm kiếm
            //string pattern = $"{numberOP}.*{dateSearch}.*\\.xlsx$";
            string pattern = $@"\b{numberOP}\b.*{dateSearch}.*\.xlsx$";
            // Tìm kiếm và lọc
            var files = Directory.EnumerateFiles(folderPath)
                .Where(file => Regex.IsMatch(Path.GetFileName(file), pattern, RegexOptions.IgnoreCase))
                .Reverse()
                .ToList();

            return files;
        }
        [HttpPost("filter-simulation-op10-warn-over")]
        public async Task<PartSMLOP10WarnOverModel> FilterSimulationOp10WarnOver(PcSimulationOp9WarnListParam parameters)
        {
            try
            {
                var config = new MapperConfiguration(cfg => cfg.CreateMap<PcSimulationWarningOverOp10Lbp, PcSimulationWarningOverOp10Ij>());
                var mapper = config.CreateMapper();
                PartSMLOP10WarnOverModel result = new PartSMLOP10WarnOverModel()
                {
                    currentPage = parameters.Page,
                    recordPerPage = parameters.RecordsPerPage
                };

                IQueryable<PcSimulationWarningOverOp10Ij> query;
                if (parameters.Product.ToUpper() == "IJ")
                {
                    query = context.PcSimulationWarningOverOp10Ijs.Where(x => x.Active == true);
                }
                else
                {
                    var outputLbp = context.PcSimulationWarningOverOp10Lbps.Where(x => x.Active == true);
                    query = outputLbp.ProjectTo<PcSimulationWarningOverOp10Ij>(mapper.ConfigurationProvider);
                }
                DateOnly? date = parameters.Date == null ? null : DateOnly.Parse(parameters.Date);

                query = !string.IsNullOrEmpty(parameters.PartNo) ? query.Where(x => x.PartNo != null && x.PartNo.ToUpper().Contains(parameters.PartNo.ToUpper())) : query;
                query = !string.IsNullOrEmpty(parameters.Vendor) ? query.Where(x => x.Vendor != null && x.Vendor.ToUpper().Contains(parameters.Vendor.ToUpper())) : query;
                query = !string.IsNullOrEmpty(parameters.Model) ? query.Where(x => x.Model != null && x.Model.ToUpper().Contains(parameters.Model.ToUpper())) : query;
                query = !string.IsNullOrEmpty(parameters.Pic) ? query.Where(x => x.DoPic != null && x.DoPic.ToUpper().Contains(parameters.Pic.ToUpper())) : query;
                query = !string.IsNullOrEmpty(parameters.Merchandise) ? query.Where(x => x.Destination != null && x.Destination.ToUpper().Contains(parameters.Merchandise.ToUpper())) : query;
                query = !string.IsNullOrEmpty(parameters.Reason) ? query.Where(x => x.Reason != null && x.Reason.ToUpper().Contains(parameters.Reason.ToUpper())) : query;
                query = !string.IsNullOrEmpty(parameters.Action) ? query.Where(x => x.Action != null && x.Action.ToUpper().Contains(parameters.Action.ToUpper())) : query;
                query = date != null ? query.Where(x => x.DeadlineInclDate != null && x.DeadlineInclDate == date) : query;

                result.totalRecords = await query.CountAsync();
                result.totalPage = (int)Math.Ceiling((decimal)result.totalRecords / parameters.RecordsPerPage);
                var model = await query.OrderByDescending(x => x.CreatedDate).Paginate(parameters).ToListAsync();
                var lstResult = new List<PartSMLOP10WarnOverView>();
                foreach (var item in model)
                {
                    lstResult.Add(new PartSMLOP10WarnOverView
                    {
                        Bc = item.Bc,
                        PartNo = item.PartNo,
                        Dim = item.Dim,
                        PartName = item.PartName,
                        Vendor = item.Vendor,
                        Model = item.Model,
                        Destination = item.Destination,
                        Factory = item.Factory,
                        DoPic = item.DoPic,
                        PoPic = item.PoPic,
                        DeadlineDate = item.DeadlineDate.ToString(),
                        DeadlineTime = item.DeadlineTime?.ToString("HH:mm"),
                        DeadlineOverQty = item.DeadlineOverQty,
                        Reason = item.Reason,
                        Action = item.Action,
                        DeadlineInclDate = item.DeadlineInclDate.ToString(),
                        DeadlineInclTime = item.DeadlineInclTime?.ToString("HH:mm") ,
                        DeadlineOverPallet = item.DeadlineOverPallet,
                      
                    });

                }



                result.lstModel = lstResult;

                result.fromRecord = model.Count == 0 ? 0 : (result.currentPage - 1) * result.recordPerPage + 1;
                result.toRecord = (int)Math.Min(result.totalRecords, result.currentPage * result.recordPerPage);
                result.currentPage = result.totalPage < result.currentPage ? result.totalPage : result.currentPage;
                return result;
            }
            catch (Exception e)
            {
                //SendMailError(e);
                return new PartSMLOP10WarnOverModel()
                {
                    currentPage = parameters.Page,
                    recordPerPage = parameters.RecordsPerPage
                };
            }
        }

        [HttpPost("filter-pic-op10/{product}")]
        public async Task<List<string>> FilterPicOp10(string product)
        {
            try
            {
                var lstResult = new List<string>();

                if (product.ToUpper() == "IJ")
                {
                    lstResult = await context.PcSimulationWarningOverOp10Ijs.Where(x => x.Active == true).Select(x => x.DoPic).Distinct().ToListAsync();
                }
                else
                {
                    lstResult = await context.PcSimulationWarningOverOp10Lbps.Where(x => x.Active == true).Select(x => x.DoPic).Distinct().ToListAsync();

                }

                return lstResult;
            }
            catch (Exception e)
            {
                //SendMailError(e);
                return new List<string>();
            }
        }
        [HttpPost("filter-simulation-op11-auto-adjust-do")]
        public async Task<PartSMLOP11AutoAdjustDoModel> FilterSimulationOp11AutoAdjustDo(PcSimulationOp7FCDoParam parameters)
        {
            try
            {
                var config = new MapperConfiguration(cfg => cfg.CreateMap<PcSimulationAdjustDoOp11Lbp, PcSimulationAdjustDoOp11Ij>());
                var mapper = config.CreateMapper();
                PartSMLOP11AutoAdjustDoModel result = new PartSMLOP11AutoAdjustDoModel()
                {
                    currentPage = parameters.Page,
                    recordPerPage = parameters.RecordsPerPage
                };

                IQueryable<PcSimulationAdjustDoOp11Ij> query;
                if (parameters.Product.ToUpper() == "IJ")
                {
                    query = context.PcSimulationAdjustDoOp11Ijs.Where(x => x.Active == true);
                }
                else
                {
                    var outputLbp = context.PcSimulationAdjustDoOp11Lbps.Where(x => x.Active == true);
                    query = outputLbp.ProjectTo<PcSimulationAdjustDoOp11Ij>(mapper.ConfigurationProvider);
                }


                query = !string.IsNullOrEmpty(parameters.PartNo) ? query.Where(x => x.PartNo != null && x.PartNo.ToUpper().Contains(parameters.PartNo.ToUpper())) : query;
                query = !string.IsNullOrEmpty(parameters.Vendor) ? query.Where(x => x.Vendor != null && x.Vendor.ToUpper().Contains(parameters.Vendor.ToUpper())) : query;
                query = !string.IsNullOrEmpty(parameters.Date) ? query.Where(x => x.DateDelivery != null && x.DateDelivery.ToUpper().Contains(parameters.Date.ToUpper())) : query;
                query = !string.IsNullOrEmpty(parameters.AdjQty) ? query.Where(x => x.AdjustQty != null && x.AdjustQty == parameters.AdjQty.ObjToDoubleAble()) : query;
                query = !string.IsNullOrEmpty(parameters.Time) ? query.Where(x => x.TimeDelivery != null && x.TimeDelivery.ToUpper().Contains(parameters.Time.ToUpper())) : query;
                query = !string.IsNullOrEmpty(parameters.PoKey) ? query.Where(x => x.PoKey != null && x.PoKey.ToUpper().Contains(parameters.PoKey.ToUpper())) : query;

                result.totalRecords = await query.CountAsync();
                result.totalPage = (int)Math.Ceiling((decimal)result.totalRecords / parameters.RecordsPerPage);
                var model = await query.OrderByDescending(x => x.CreatedDate).Paginate(parameters).ToListAsync();



                result.lstModel = model;

                result.fromRecord = model.Count == 0 ? 0 : (result.currentPage - 1) * result.recordPerPage + 1;
                result.toRecord = (int)Math.Min(result.totalRecords, result.currentPage * result.recordPerPage);
                result.currentPage = result.totalPage < result.currentPage ? result.totalPage : result.currentPage;
                return result;
            }
            catch (Exception e)
            {
                //SendMailError(e);
                return new PartSMLOP11AutoAdjustDoModel()
                {
                    currentPage = parameters.Page,
                    recordPerPage = parameters.RecordsPerPage
                };
            }
        }

        [HttpPost("filter-simulation-master-parallel")]
        public async Task<PartSMLMasterParallelModel> FilterSimulationMasterParallel(PCSMLMasterParallelParam parameters)
        {
            try
            {
                PartSMLMasterParallelModel result = new PartSMLMasterParallelModel()
                {
                    currentPage = parameters.Page,
                    recordPerPage = parameters.RecordsPerPage
                };
                DateOnly? date = parameters.Date == null ? null : DateOnly.Parse(parameters.Date);
                var query = context.PcSimulationMasterParallels.Where(x => x.Active == true && x.Product == parameters.Product);
                query = !string.IsNullOrEmpty(parameters.PartNo) ? query.Where(x => x.PartNo != null && x.PartNo.ToUpper().Contains(parameters.PartNo.ToUpper())) : query;
                query = !string.IsNullOrEmpty(parameters.Vendor) ? query.Where(x => x.Vendor != null && x.Vendor.ToUpper().Contains(parameters.Vendor.ToUpper())) : query;
                query = !string.IsNullOrEmpty(parameters.Date) ? query.Where(x => x.PlanDate != null && x.PlanDate == date) : query;

                result.totalRecords = await query.CountAsync();
                result.totalPage = (int)Math.Ceiling((decimal)result.totalRecords / parameters.RecordsPerPage);
                var model = await query.OrderByDescending(x => x.CreatedDate).ThenBy(x => x.PartNo).ThenBy(x => x.PlanDate).Paginate(parameters).Select(x =>new PcSimulationMasterParallelView
                {
                    PartNo = x.PartNo,
                    Vendor = x.Vendor,
                    Bc = x.Bc,
                    DoQty = x.DoQty,
                    PlanDate = x.PlanDate.ToString("yyyy-MM-dd"),
                    Ratio = x.Ratio,
                    ApprovedBy = x.ApprovalBy
                }).ToListAsync();

                result.lstModel = model;

                result.fromRecord = model.Count == 0 ? 0 : (result.currentPage - 1) * result.recordPerPage + 1;
                result.toRecord = (int)Math.Min(result.totalRecords, result.currentPage * result.recordPerPage);
                result.currentPage = result.totalPage < result.currentPage ? result.totalPage : result.currentPage;
                return result;
            }
            catch (Exception)
            {
                return new PartSMLMasterParallelModel()
                {
                    currentPage = parameters.Page,
                    recordPerPage = parameters.RecordsPerPage
                };
            }
        }

        [HttpGet("approve-simulation-master-parallel/{product}")]
        public async Task<CommonResponse> ApproveSMLMasterParallel(string product)
        {
            CommonResponse res = new CommonResponse()
            {
                Error = false,
                Message = "",
                Status = (int)HttpStatusCode.BadRequest
            };
            try
            {

                var u = GetCurrentUser();

                //tìm những con cũ dựa vào key những con mới
                var model = await context.PcSimulationMasterParallels
                    .Where(x => x.Active == true && x.ApprovalDate == null && x.Product == product)
                    .ToListAsync();

                var lstUpdate = await context.PcSimulationMasterParallels
                    .Where(x => x.Active == true && x.ApprovalDate != null && x.Product == product).ToListAsync();
                if(model.Count != 0)
                {
                    lstUpdate.ForEach(x => {
                        x.Active = false;
                        x.ModifiedBy = u.UserName;
                    });
                }
               
                //List<PcSimulationMasterDoChangeTime> lstDel = new List<PcSimulationMasterDoChangeTime>();
                model.ForEach(x =>
                {
                    x.ApprovalBy = u.UserName;
                    x.ApprovalDate = DateTime.Now.SetKindUtc();
                });


                context.UpdateRange(lstUpdate);
                context.UpdateRange(model);
                context.SaveChanges();

                res.Error = false;
                res.Message = "Successfully !";
                res.Status = (int)HttpStatusCode.OK;
                return res;
            }
            catch (Exception e)
            {
                res.Error = true;
                res.Message = e.Message;
                res.Status = (int)HttpStatusCode.BadRequest;
                // SendMailError(e);
                return res;
            }


        }
        [HttpGet("reject-simulation-master-parallel/{product}")]
        public async Task<CommonResponse> RejectSMLMasterParallel(string product)
        {
            CommonResponse res = new CommonResponse()
            {
                Error = false,
                Message = "",
                Status = (int)HttpStatusCode.BadRequest
            };
            try
            {
                var u = GetCurrentUser();
                var model = await context.PcSimulationMasterParallels
                    .Where(x => x.Active == true && x.ApprovalDate == null && x.Product == product)
                    .ToListAsync();

                
                model.ForEach(x =>
                {
                    x.Active = false;
                    x.ApprovalBy = u.UserName;
                    x.ApprovalDate = DateTime.Now.SetKindUtc();
                });

                context.UpdateRange(model);
                context.SaveChanges();

                res.Error = false;
                res.Message = "Successfully !";
                res.Status = (int)HttpStatusCode.OK;
                return res;
            }
            catch (Exception e)
            {
                res.Error = true;
                res.Message = e.Message;
                res.Status = (int)HttpStatusCode.BadRequest;
                // SendMailError(e);
                return res;
            }


        }
        [HttpPost("filter-simulation-op6-sml-by-time-urgent")]
        public async Task<PartSMLOP6SMLByTimeModel> FilterSimulationOp6SMlByTimeUrgent(PcSimulationOp6ByTimeParam parameters)
        {
            try
            {
                var LstType = new List<string>() { "Demand", "DO", "Remain", "Remain Incl LT" };
                var config = new MapperConfiguration(cfg => cfg.CreateMap<PcSimulationSmTimeOp6Lbp, PcSimulationSmTimeOp6Ij>());
                var mapper = config.CreateMapper();
                PartSMLOP6SMLByTimeModel result = new PartSMLOP6SMLByTimeModel()
                {
                    currentPage = parameters.Page,
                    recordPerPage = parameters.RecordsPerPage
                };

                IQueryable<PcSimulationSmTimeOp6Ij> query;
                if (parameters.Product.ToUpper() == "IJ")
                {
                    query = context.PcSimulationSmTimeOp6Ijs.Where(x => x.Active == true);
                }
                else
                {
                    var outputLbp = context.PcSimulationSmTimeOp6Lbps.Where(x => x.Active == true);
                    query = outputLbp.ProjectTo<PcSimulationSmTimeOp6Ij>(mapper.ConfigurationProvider);
                }
                DateOnly? date = parameters.Date == null ? null : DateOnly.Parse(parameters.Date);

                var blockByDate = context.PcSimulationDetailBlocktimeBydates.Where(x => x.Active == true && x.Product == parameters.Product).OrderByDescending(x => x.CreatedDate).FirstOrDefault();
                var blockTime = blockByDate.BlockTime.Select(x => x.ToString("HH:mm")).ToList();
                var lstDate = blockByDate.BlockTime.Select(x => x.ToString("yyyy-MM-dd")).ToList();
                var dictDeadLine = blockByDate.BlockTime.Select((x,index) => new {  Date = x,Index = index }).ToDictionary(x => x.Index, x => x.Date.ToString("yyyy-MM-dd HH:mm"));

                query = !string.IsNullOrEmpty(parameters.PartNo) ? query.Where(x => x.PartNo != null && x.PartNo.ToUpper().Contains(parameters.PartNo.ToUpper())) : query;
                query = !string.IsNullOrEmpty(parameters.Vendor) ? query.Where(x => x.Vendor != null && x.Vendor.ToUpper().Contains(parameters.Vendor.ToUpper())) : query;
                query = !string.IsNullOrEmpty(parameters.Model) ? query.Where(x => x.Model != null && x.Model.ToUpper().Contains(parameters.Model.ToUpper())) : query;
                query = !string.IsNullOrEmpty(parameters.Pic) ? query.Where(x => x.DoPic != null && x.DoPic.ToUpper().Contains(parameters.Pic.ToUpper())) : query;
                query = !string.IsNullOrEmpty(parameters.Merchandise) ? query.Where(x => x.Destination != null && x.Destination.ToUpper().Contains(parameters.Merchandise.ToUpper())) : query;
                query = !string.IsNullOrEmpty(parameters.Bc) ? query.Where(x => x.Bc != null && x.Bc.ToUpper().Contains(parameters.Bc.ToUpper())) : query;

                result.totalRecords = await query.CountAsync();
                result.totalPage = (int)Math.Ceiling((decimal)result.totalRecords / parameters.RecordsPerPage);
                var model = await query.OrderByDescending(x => x.CreatedDate).Paginate(parameters).ToListAsync();
                var lstResult = new List<PartSMLOP6SMLByTimeView>();
                var properties = new Func<PcSimulationSmTimeOp6Ij, List<double>>[]
                      {
                        item => (item.Demand.Zip(item.DemandCp, (a, b) => a + b).Zip(item.OtherOrder, (a, b) => a + b)).ToList(),
                        item => item.DoVal.ToList(),
                        item => item.Remain.ToList(),
                        item => item.RemainIncl.ToList(), 
                  };
                foreach (var item in model)
                {
                    var i = 0;
                    var deadLine = "";
                    var deadLineInc = "";
                    foreach (var type in LstType)
                    {
                        var lstVal = properties[i](item);
                        if (i == 2)
                        {
                            var index = lstVal.FindIndex(x => x <= -0.1);
                            dictDeadLine.TryGetValue(index, out deadLine);
                        }
                        if (i == 3)
                        {
                            var index = lstVal.FindIndex(x => x <= -0.1);
                            dictDeadLine.TryGetValue(index, out deadLineInc);
                        }
                        lstResult.Add(new PartSMLOP6SMLByTimeView
                        {
                            PartNo = RemoveDuplicate(item.PartNo),
                            Bc = RemoveDuplicate(item.Bc),
                            Vendor = RemoveDuplicate(item.Vendor),
                            Destination = RemoveDuplicate(item.Destination),
                            Dim = RemoveDuplicate(item.Dim),
                            Model = RemoveDuplicate(item.Model),
                            MoqOrder = RemoveDuplicate(item.MoqOrder),
                            Inventory = item.Inventory,
                            Order = i,
                            Type = type,
                            LstValue = lstVal,
                            Deadline = deadLine,
                            DeadlineInc = deadLineInc
                        });
                        i++;
                    }

                }



                result.lstModel = lstResult;
                result.lstDate = lstDate;
                result.LstBlock = blockTime;
                result.fromRecord = model.Count == 0 ? 0 : (result.currentPage - 1) * result.recordPerPage + 1;
                result.toRecord = (int)Math.Min(result.totalRecords, result.currentPage * result.recordPerPage);
                result.currentPage = result.totalPage < result.currentPage ? result.totalPage : result.currentPage;
                return result;
            }
            catch (Exception e)
            {
                //SendMailError(e);
                return new PartSMLOP6SMLByTimeModel()
                {
                    currentPage = parameters.Page,
                    recordPerPage = parameters.RecordsPerPage
                };
            }
        }
        [HttpPost("export-sim-op6-urgent/{product}")]
        [AllowAnonymous]
        public async Task<CommonResponse> TodCalculateAgain([FromBody] string? paramsList,string product)
        {
            CommonResponse res = new CommonResponse()
            {
                Error = false,
                Message = "",
                Status = (int)HttpStatusCode.BadRequest
            };
            try
            {
                var u = GetCurrentUser();
                if (HangfireJobList.PreventProcessing($"ExportOp6Urgent/{product.ToUpper()}"))
                {
                    res.Error = true;
                    res.Message = "Other jobs processing";
                    res.Status = 400;
                    return res;
                }
                if (HangfireJobList.PreventProcessing($"ExportOp6Urgent/{product.ToUpper()}"))
                {
                    res.Error = true;
                    res.Message = "Other jobs processing";
                    res.Status = 400;
                    return res;
                }
                //string jsonParams = JsonConvert.SerializeObject(paramsList);
                await ManualFunc.GatewayAsyncPost($"ExportOp6Urgent/{product.ToUpper()}/{u.UserName}", paramsList);
                res.Error = false;
                res.Message = "Success, Job running, please check email to follow!";
                res.Status = 200;
                
            }
            catch (Exception ex)
            {
                res.Error = true;
                res.Message = ex.Message;
                res.Status = 400;
            }

            return res;
        }
        //[HttpGet("get-sim-part-urgent/{product}")]
        //[AllowAnonymous]
        //public async Task<List<PcSimulationMasterPartUrgent>> GetPartToRunUrgent(string product)
        //{
           
        //    try
        //    {
        //        var u = GetCurrentUser();
        //        if(product == "IJ")
        //        {
        //            var model =await context.VStructureIjSimulations.Select(x => new PcSimulationMasterPartUrgent { 
        //                PartNo = x.PartNo,
        //                Vendor= x.Vendor,
        //                Bc = x.Bc,
        //                Display = x.PartNo+"_" + x.Vendor + "_" + x.Bc}).ToListAsync();
        //            return model;
        //        }
        //        else
        //        {
        //            var model = await context.VStructureLbpSimulations.Select(x => new PcSimulationMasterPartUrgent
        //            {
        //                PartNo = x.PartNo,
        //                Vendor = x.Vendor,
        //                Bc = x.Bc,
        //                Display = x.PartNo + "_" + x.Vendor + "_" + x.Bc
        //            }).ToListAsync();
        //            return model;
        //        }

        //    }
        //    catch (Exception ex)
        //    {
        //        return new List<PcSimulationMasterPartUrgent>();
        //    }

            
        //}
        #endregion


        [HttpGet("sim-calculate-again")]
        [AllowAnonymous]
        public async Task<CommonResponse> TodCalculateAgain(string product, bool runAll, bool doNpis, bool autoDo, bool demandChange, bool otherOrder, bool doChange, bool fcDo)
        {
            CommonResponse res = new CommonResponse()
            {
                Error = false,
                Message = "",
                Status = (int)HttpStatusCode.BadRequest
            };
            try
            {
                var u = GetCurrentUser();
                if (HangfireJobList.PreventProcessing($"CalculateAction/Simulation/{product.ToUpper()}"))
                {
                    res.Error = true;
                    res.Message = "Other jobs processing";
                    res.Status = 400;
                    return res;
                }
                if (HangfireJobList.PreventProcessing($"UserCalculateSimulation/{product.ToUpper()}"))
                {
                    res.Error = true;
                    res.Message = "Other jobs processing";
                    res.Status = 400;
                    return res;
                }
                await ManualFunc.GatewayAsync($"UserCalculateSimulation/{product}/{runAll}/{doNpis}/{autoDo}/{demandChange}/{otherOrder}/{doChange}/{fcDo}");
                res.Error = false;
                res.Message = "Success, Job running";
                res.Status = 200;
                if (!string.IsNullOrEmpty(u.UserName))
                {
                    _email.Initial(lstMailReceive, "Run Digital Simulation", $"User {u.UserName} - {u.FullName} run manual to calculate Digital Simulation with route: UserCalculateSimulation/product={product}/runAll={runAll}/doNpis={doNpis}/autoDo={autoDo}/demandChange={demandChange}/otherOrder={otherOrder}/doChange={doChange}/fcDo={fcDo}");
                }
            }
            catch (Exception ex)
            {
                res.Error = true;
                res.Message = ex.Message;
                res.Status = 400;
            }

            return res;
        }
        [HttpGet("sim-push-pokey-again")]
        [AllowAnonymous]
        public async Task<CommonResponse> TodPushPOKeyAgain(string product)
        {
            CommonResponse res = new CommonResponse()
            {
                Error = false,
                Message = "",
                Status = (int)HttpStatusCode.BadRequest
            };
            try
            {
                var u = GetCurrentUser();
                if (HangfireJobList.PreventProcessing($"UserCalculateAction/SimulationPushPOKey/{product}"))
                {
                    res.Error = true;
                    res.Message = "Other jobs processing";
                    res.Status = 400;
                    return res;
                }
                await ManualFunc.GatewayAsync($"UserCalculateAction/SimulationPushPOKey/{product}");
                res.Error = false;
                res.Message = "Success, Job running";
                res.Status = 200;
                if (!string.IsNullOrEmpty(u.UserName))
                {
                    _email.Initial(lstMailReceive, "Push POKey Again", $"User {u.UserName} - {u.FullName} run manual to calculate Digital Simulation with route: UserCalculateAction/SimulationPushPOKey/{product}");
                }
            }
            catch (Exception ex)
            {
                res.Error = true;
                res.Message = ex.Message;
                res.Status = 400;
            }

            return res;
        }
        [HttpGet("sim-calculate-debug")]
        [AllowAnonymous]
        public async Task<CommonResponse> TodCalculateDebug(string product, bool runAll, bool doNpis, bool autoDo, bool demandChange, bool otherOrder, bool doChange, string testCase)
        {
            CommonResponse res = new CommonResponse()
            {
                Error = false,
                Message = "",
                Status = (int)HttpStatusCode.BadRequest
            };
            try
            {
                var u = GetCurrentUser();
                await ManualFunc.GatewayAsync($"UserDebugSimulation/{product}/{runAll}/{doNpis}/{autoDo}/{demandChange}/{otherOrder}/{doChange}/{testCase}");
                res.Error = false;
                res.Message = "Success, Job running";
                res.Status = 200;
                if (!string.IsNullOrEmpty(u.UserName))
                {
                    _email.Initial(lstMailReceive, "Debug Digital Simulation", $"User {u.UserName} - {u.FullName} run debug to investigate Digital Simulation with route: /api/hangfire/UserCalculateSimulation/{product}/{runAll}/{doNpis}/{autoDo}/{demandChange}/{otherOrder}/{doChange}/{testCase}");
                }
            }
            catch (Exception ex)
            {
                res.Error = true;
                res.Message = ex.Message;
                res.Status = 400;
            }

            return res;
        }

        [HttpGet("sim-export-again")]
        [AllowAnonymous]
        public async Task<CommonResponse> TodExportAgain(string product)
        {
            CommonResponse res = new CommonResponse()
            {
                Error = false,
                Message = "",
                Status = (int)HttpStatusCode.BadRequest
            };
            try
            {
                //if (HangfireJobList.PreventProcessing($"UserExportAction/Simulation/{product.ToUpper()}/0"))
                //{
                //    res.Error = true;
                //    res.Message = "Other jobs processing";
                //    res.Status = 400;
                //    return res;
                //}
                //var u = GetCurrentUser();
                //await ManualFunc.GatewayAsync($"UserExportAction/Simulation/{product.ToUpper()}/0");
                res.Error = false;
                res.Message = "Failed, no active export manual";
                res.Status = 400;
            }
            catch (Exception ex)
            {
                res.Error = true;
                res.Message = ex.Message;
                res.Status = 400;
            }

            return res;
        }
        [HttpGet("check-group-input-sml/{product}")]
        public bool CheckGroupInputSML(string product)
        {
            
            try
            {
                var u = GetCurrentUser();
                bool check = false;
                if(product.ToUpper() == "IJ")
                {
                    check = context.AdmDetailUserGroups.Any(x => x.UserId == Guid.Parse(u.Id) && 
                    (x.GroupId == new Guid("29b89944-874b-43e4-9046-8eff24122f3c")
                    || x.GroupId == new Guid("e462d3a8-27fa-4ffa-bac4-512a2ab33bc3")
                    || x.GroupId == new Guid("1567cfeb-32fe-4745-bbdc-2ace703099d4")
                    ));
                }
                else
                {
                    check = context.AdmDetailUserGroups.Any(x => x.UserId == Guid.Parse(u.Id) && 
                    (x.GroupId == new Guid("1567cfeb-32fe-4745-bbdc-2ace703099d4")
                       || x.GroupId == new Guid("e462d3a8-27fa-4ffa-bac4-512a2ab33bc3")
                       || x.GroupId == new Guid("c8071be4-ca2b-4615-ba02-3d0f73ebaa87")
                    ));
                }
                
                return check;
            }
            catch (Exception)
            {
                return false;
            }

           
        }
        private UserClaims GetCurrentUser()
        {
            UserClaims userClaims = new UserClaims();
            var identity = HttpContext.User.Identity as ClaimsIdentity;
            if (identity != null)
            {
                userClaims.UserName = identity.FindFirst("user_name") == null ? "Undefined" : identity.FindFirst("user_name").Value;
                userClaims.Id = identity.FindFirst("id") == null ? "Undefined" : identity.FindFirst("id").Value;
                //userClaims.IsIt = identity.FindFirst("isIt") == null ? "0" : identity.FindFirst("isIt").Value;
                userClaims.Departments = identity.FindFirst("deptIds") == null ? "" : identity.FindFirst("deptIds").Value;
                userClaims.Factories = identity.FindFirst("factIds") == null ? "" : identity.FindFirst("factIds").Value;
                userClaims.CostCenter = identity.FindFirst("cost_center") == null ? "" : identity.FindFirst("cost_center").Value;
                userClaims.FullName = identity.FindFirst("full_name") == null ? "" : identity.FindFirst("full_name").Value;
                userClaims.Departments = identity.FindFirst("dept") == null ? "" : identity.FindFirst("dept").Value;
                userClaims.Grade = identity.FindFirst("grade") == null ? "" : identity.FindFirst("grade").Value;
                userClaims.IsAdmin = identity.FindFirst("isAdmin") == null ? "false" : identity.FindFirst("isAdmin").Value;

            }
            return userClaims;
        }
        private string? RemoveDuplicate(string? txt)
        {
            try
            {
                string?[] lstTxt = txt.Split(new char[] { ',', ';' });
                string?[] hashTxt = lstTxt?.Distinct().ToArray();
                string? resultModel = hashTxt == null ? null : string.Join(",", hashTxt);
                return resultModel;

            }
            catch
            {
                return null;
            }
        }

    }
}
